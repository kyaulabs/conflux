#!/usr/bin/env python3
"""Root-run, source-bound synthetic ownership-history regression. No processes.

Compiles selected REAL nested functions and the REAL cleanup classification
assignments. /proc, clocks and UID are synthetic. No signal/child/host boundary
is invoked. The first check exercises the old functional argv-loss defect.
"""
import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
import types


BASE = Path(__file__).resolve().parent
SOURCE_HASHES = {
    "before": "b5850f5106c3155f782adfaf482e5461104df0b29549673ea32a0ded2db21775",
    "after": "ae7090fe141d5e61618de5b3c10817c2e43bfa95e287f5c735ddeee8921e6408",
}
PATCH_SHA256 = "d1c44412a01bfac3cf3d8b8a6fdd97d0c1c13d9ab23212d61af4d808fe4847e0"
SERVICE = ["/fixture/python", "-B", "/fixture/service.py", "--runtime", "/fixture/runtime", "--model", "/fixture/model", "--backend", "vulkan", "--threads", "2"]
RUNTIME = ["/fixture/runtime", "--model", "/fixture/model", "--backend", "vulkan", "--threads", "2"]


def require(value, message):
    if not value:
        raise AssertionError(message)


def expect_error(action, text):
    try:
        action()
    except RuntimeError as error:
        require(text in str(error), "Unexpected exception: " + str(error))
        return
    raise AssertionError("Expected bounded rejection: " + text)


def identity(pid, start, group, parent, command):
    return dict(pid=pid, start_ticks=start, group=group, session=group, ppid=parent,
                command=list(command), state="R", observed_monotonic_ns=1)


class World:
    """Only the fixed synthetic tree and /proc leaves used by these functions."""
    def __init__(self):
        self.records = {101: identity(101, 11, 101, 1, ["/fixture/driver"]),
                        202: identity(202, 22, 202, 101, SERVICE),
                        303: identity(303, 33, 202, 202, RUNTIME)}
        self.children = {101: [202], 202: [303], 303: []}
        self.calls = {}; self.hook = None; self.uid = 1000; self.now = 0
    def tick(self):
        self.now += 1
        return self.now
    def read(self, pid):
        self.calls[pid] = self.calls.get(pid, 0) + 1
        value = copy.deepcopy(self.records[pid])
        value["observed_monotonic_ns"] = self.tick()
        return self.hook(pid, self.calls[pid], value) if self.hook else value
    def path(self, value):
        world = self
        class ProcPath:
            def __init__(self, name): self.name = str(name)
            def __truediv__(self, leaf): return ProcPath(self.name.rstrip("/") + "/" + str(leaf))
            def pid(self):
                require(self.name.startswith("/proc/"), "Unexpected non-proc path")
                return int(self.name.split("/")[2])
            def stat(self): return types.SimpleNamespace(st_uid=world.uid)
            def iterdir(self): return [self / "1"]
            def read_text(self):
                pid = self.pid()
                if self.name.endswith("/children"):
                    return " ".join(map(str, world.children[pid]))
                require(self.name.endswith("/stat"), "Unexpected proc text leaf")
                row = world.records[pid]
                fields = ["0"] * 20
                for index, key in ((0, "state"), (1, "ppid"), (2, "group"), (3, "session"), (19, "start_ticks")):
                    fields[index] = str(row[key])
                return f"{pid} (synthetic) " + " ".join(fields)
            def read_bytes(self):
                require(self.name.endswith("/cmdline"), "Unexpected proc binary leaf")
                return b"\0".join(value.encode() for value in world.records[self.pid()]["command"]) + b"\0"
        return ProcPath(value)


def load(tree, world):
    run = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "run_live")
    available = {node.name: node for node in ast.walk(run) if isinstance(node, ast.FunctionDef)}
    class Lift(ast.NodeTransformer):
        def visit_Nonlocal(self, node):
            return ast.copy_location(ast.Global(names=node.names), node)
    names = {"same_identity", "remember_owned", "process_record", "service_matches",
             "record_ownership_loss", "remember_command", "proven_command_snapshots"}
    nodes = [Lift().visit(copy.deepcopy(available[name])) for name in names if name in available]
    class FixedPath:
        def __str__(self): return "/fixture/python"
        def resolve(self): return self
    ns = dict(Path=world.path, time=types.SimpleNamespace(monotonic_ns=world.tick),
        os=types.SimpleNamespace(getuid=lambda: 1000), child=types.SimpleNamespace(pid=101),
        root_identity=copy.deepcopy(world.records[101]), owned={}, observed_groups=set(),
        ownership_complete=True, command_history={}, ownership_failures=[],
        ownership_failure_count=0, ownership_failure_overflow=False,
        assets={"python": FixedPath()}, service_path="/fixture/service.py",
        runtime_path="/fixture/runtime", model_path="/fixture/model")
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), "<real-history-functions>", "exec"), ns)
    ns["real_process_record"] = ns["process_record"]
    ns["process_record"] = world.read
    assignment_names = {"snapshots", "services", "runtimes", "service_groups", "engine_observed"}
    assignments = sorted((copy.deepcopy(node) for node in ast.walk(run)
        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id in assignment_names for target in node.targets)), key=lambda node: node.lineno)
    require(any(isinstance(target, ast.Name) and target.id == "engine_observed" for node in assignments for target in node.targets),
            "Actual cleanup classifier not found")
    classification = compile(ast.fix_missing_locations(ast.Module(body=assignments, type_ignores=[])), "<real-cleanup-classification>", "exec")
    def classify():
        exec(classification, ns)
        return ns["engine_observed"]
    ns["classify"] = classify
    return ns


def all_checks(tree):
    checks = []
    def check(name, action):
        action(); checks.append(name)
    def history_regression():
        world = World(); ns = load(tree, world)
        ns["remember_owned"]()
        require(ns["classify"](), "Initial proven service/runtime classifier did not accept real argv")
        world.records[303].update(command=[], state="Z")
        ns["remember_owned"]()
        require(ns["owned"][(303, 33)]["command"] == [], "Latest liveness record was not refreshed")
        require(ns["classify"](), "Functional regression: same-identity zombie argv erased already proven runtime/service evidence")
        snapshots = ns["proven_command_snapshots"]()
        runtime = next(row for row in snapshots if row["command"] == RUNTIME)
        require(runtime["state"] == "R" and runtime["observed_monotonic_ns"] > 0 and
                runtime["parent_identity"]["pid"] == 202 and runtime["parent_identity"]["start_ticks"] == 22,
                "Retained argv lost its proved parent/state/time context")
        ns["owned"].clear()
        require(ns["classify"](), "Cleanup classification still depends on latest-only liveness map")
    check("proven runtime argv survives same-identity empty argv; actual classifier uses history", history_regression)
    def distinct_identities():
        world = World(); ns = load(tree, world); ns["remember_owned"]()
        original = copy.deepcopy(world.records[303])
        for changes in (dict(start_ticks=34), dict(group=404, session=404)):
            changed = dict(original, command=[], **changes)
            ns["remember_command"](changed, world.records[202])
            key = tuple(changed[name] for name in ("pid", "start_ticks", "group", "session"))
            require([row["command"] for row in ns["command_history"][key]] == [[]],
                    "New full identity inherited an old argv proof")
        require(any(row["command"] == RUNTIME for row in ns["command_history"][(303, 33, 202, 202)]),
                "Historical identity was overwritten")
    check("changed start/group/session receive separate history, without inherited argv", distinct_identities)
    def proof_loss(mode, reason):
        world = World(); ns = load(tree, world)
        def hook(pid, count, row):
            if mode == "wrong-parent" and pid == 303: row["ppid"] = 999
            if mode == "parent-start" and pid == 202 and count >= 3: row["start_ticks"] += 1
            if mode == "parent-group" and pid == 202 and count >= 3: row.update(group=404, session=404)
            if mode == "child-start" and pid == 303 and count >= 2: row["start_ticks"] += 1
            if mode == "vanished-parent" and pid == 202 and count >= 3: raise FileNotFoundError("synthetic parent vanished")
            if mode == "vanished-child" and pid == 303: raise FileNotFoundError("synthetic child vanished")
            return row
        world.hook = hook; ns["remember_owned"]()
        require(not ns["ownership_complete"] and ns["ownership_failure_count"] == 1,
                "Ownership loss did not remain sticky/countable")
        require(len(ns["ownership_failures"]) == 1 and ns["ownership_failures"][0]["reason"] == reason and
                ns["ownership_failures"][0]["pid"] == 303 and ns["ownership_failures"][0]["parent_proof"]["pid"] == 202,
                "Ownership loss reason/context was not preserved")
        require(not any(row["pid"] == 303 for row in ns["proven_command_snapshots"]()),
                "Unproved descendant acquired argv history")
        world.hook = None; world.calls.clear(); ns["remember_owned"]()
        require(not ns["ownership_complete"], "A later successful walk repaired sticky failure")
    for mode, reason in (("wrong-parent", "parent_pid_changed_before_walk"),
        ("parent-start", "parent_identity_changed_before_walk"), ("parent-group", "parent_identity_changed_before_walk"),
        ("child-start", "identity_changed_during_walk"),
        ("vanished-parent", "process_or_parent_disappeared_during_walk"),
        ("vanished-child", "process_or_parent_disappeared_during_walk")):
        check("proof loss: " + mode, lambda mode=mode, reason=reason: proof_loss(mode, reason))
    def argv_bound():
        world = World(); ns = load(tree, world); row = world.records[303]
        for count in range(8): ns["remember_command"](dict(row, command=[str(count)]), world.records[202])
        ns["remember_command"](dict(row, command=["0"]), world.records[202])
        expect_error(lambda: ns["remember_command"](dict(row, command=["ninth"]), world.records[202]), "fixed8")
        require(len(ns["command_history"][(303, 33, 202, 202)]) == 8 and not ns["ownership_complete"] and
                ns["ownership_failures"][0]["reason"] == "command_history_argv_bound", "Argv bound mutated history or hid loss")
    check("eight distinct argv bound rejects ninth; duplicate does not consume capacity", argv_bound)
    def identity_bound():
        world = World(); ns = load(tree, world)
        for count in range(64): ns["remember_command"](dict(world.records[303], pid=1000 + count), world.records[202])
        expect_error(lambda: ns["remember_command"](dict(world.records[303], pid=2000), world.records[202]), "fixed64")
        require(len(ns["command_history"]) == 64 and ns["ownership_failures"][0]["reason"] == "command_history_identity_bound", "Identity bound lost")
    check("64 full-identity history bound rejects growth", identity_bound)
    def loss_bound():
        world = World(); ns = load(tree, world)
        for count in range(128): ns["record_ownership_loss"]("synthetic", 303, world.records[202], world.records[303])
        expect_error(lambda: ns["record_ownership_loss"]("overflow", 303), "fixed128")
        require(len(ns["ownership_failures"]) == 128 and ns["ownership_failure_count"] == 129 and
                ns["ownership_failure_overflow"] and not ns["ownership_complete"], "Failure overflow not bounded/sticky")
    check("128 loss-record bound retains total and overflow flag", loss_bound)
    def real_snapshot():
        world = World(); ns = load(tree, world)
        row = ns["real_process_record"](303)
        require(row["command"] == RUNTIME and row["state"] == "R" and row["observed_monotonic_ns"] > 0,
                "Actual snapshot omitted state/clock/argv")
        world.uid = 1001
        expect_error(lambda: ns["real_process_record"](303), "UID")
        world.uid = 1000; world.records[303]["command"] = ["x" * 65537]
        expect_error(lambda: ns["real_process_record"](303), "bound")
    check("real process_record has bounded argv/state/time and rejects foreign UID", real_snapshot)
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--source", type=Path, default=BASE.parents[1] / "tools/experiments/run_manual_playback_soak.py")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if not args.run:
        print(json.dumps(dict(status="plan_only", native_started=False, allowed_source_hashes=SOURCE_HASHES)))
        return 0
    require(args.output is not None and not args.output.exists(), "Supply fresh --output JSON")
    raw = args.source.read_bytes(); source_sha = hashlib.sha256(raw).hexdigest()
    require(source_sha in SOURCE_HASHES.values(), "Source is neither frozen before nor proposed after bytes")
    require(hashlib.sha256((BASE / "short-live-ownership-history.patch").read_bytes()).hexdigest() == PATCH_SHA256, "Draft patch changed")
    receipt = dict(schema=1, native_started=False, source={"path": str(args.source), "sha256": source_sha, "bytes": len(raw)},
        patch_sha256=PATCH_SHA256, scope="Synthetic real-function regression; no proc/process/signal/host/audio query or cleanup certification")
    try:
        checks = all_checks(ast.parse(raw))
        receipt.update(status="offline_checks_passed", checks=checks, check_count=len(checks)); result = 0
    except Exception as error:
        receipt.update(status="offline_checks_failed", error=f"{type(error).__name__}: {error}"); result = 1
    with args.output.open("x") as stream: json.dump(receipt, stream, indent=2); stream.write("\n")
    print(json.dumps(receipt, indent=2))
    return result


if __name__ == "__main__":
    raise SystemExit(main())
