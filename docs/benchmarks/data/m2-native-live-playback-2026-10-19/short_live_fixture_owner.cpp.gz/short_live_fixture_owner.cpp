// SPDX-License-Identifier: AGPL-3.0-or-later
// Ignored private-daemon setup for the existing --live-stems native path.
#define main inheritedPreparationControllerMain
#include "../../tools/experiments/preparation_controller_check.cpp"
#undef main
#include "library/StemEngineSupport.hpp"
#include "audio/StemRateConverter.hpp"
#include <QCryptographicHash>
#include <QProcessEnvironment>
#include <exception>

namespace {
volatile std::sig_atomic_t shortOwnerStop = 0;
void stopShortOwner(int) { shortOwnerStop = 1; }
QJsonObject shortObject(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly) || file.size() > 1024 * 1024)
        throw std::runtime_error("Cannot read bounded native result");
    const auto document = QJsonDocument::fromJson(file.readAll());
    if (!document.isObject()) throw std::runtime_error("Native result is not one JSON object");
    return document.object();
}
QString shortSha(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly) || file.size() <= 0 || file.size() > 128 * 1024 * 1024)
        throw std::runtime_error("Cannot hash bounded generated input/tool");
    QCryptographicHash hash(QCryptographicHash::Sha256);
    if (!hash.addData(&file)) throw std::runtime_error("Cannot hash complete generated input/tool");
    return QString::fromLatin1(hash.result().toHex());
}
void shortDirectory(const QString& path)
{
    if (QFileInfo::exists(path) || !QDir().mkdir(path) || ::chmod(QFile::encodeName(path).constData(), 0700))
        throw std::runtime_error("Need fresh mode0700 short-live directory");
}
} // namespace

int main(int argc, char** argv)
{
    QJsonArray checks;
    QJsonObject observations;
    QString error, report;
    bool passed = false;
    auto require = [&](bool value, const char* message) {
        if (!value) throw std::runtime_error(message);
        checks.append(message);
    };
    try {
        if (argc != 3 && (argc != 4 || std::string_view(argv[3]) != "--functional-only"))
            throw std::runtime_error("Usage: short-live-fixture-owner PRIVATE_RUNTIME EMPTY_RECORDING_DIR [--functional-only]");
        const rlimit noCore{0, 0};
        require(::setrlimit(RLIMIT_CORE, &noCore) == 0 && ::prctl(PR_SET_DUMPABLE, 0) == 0,
                "Private fixture owner disables core dumps");
        const std::filesystem::path runtime(argv[1]), recording(argv[2]);
        validatePrivate(runtime, recording);
        std::signal(SIGINT, stopShortOwner); std::signal(SIGTERM, stopShortOwner);
        QCoreApplication app(argc, argv);
        const auto output = QString::fromStdString(recording.string());
        const auto parent = QFileInfo(output).absolutePath();
        report = QDir(parent).filePath("fixture-owner-result.json");
        const auto fixtures = QDir(parent).filePath("fixture-inputs");
        shortDirectory(fixtures); shortDirectory(output + "/cache");
        const auto a = QDir(fixtures).filePath("tiny-live-a.wav"), b = QDir(fixtures).filePath("quiet-peer-b.wav");
        writeFixture(a, 8192, -4096, 211, 44100); // .25/-.125, independent fake roles are k/4 of this.
        writeFixture(b, 1, -1, 30 * 48000, 48000); // Quiet finite peer; private output only.
        const auto fixture = conflux::test::makeStemServiceFixture(fixtures);
        const auto binary = QStringLiteral(CONFLUX_SOURCE_DIR "/build/dev/conflux-manual-playback-soak");
        require(QFileInfo(binary).isExecutable(), "Actual existing native soak binary is available");
        observations["native_binary"] = binary;
        observations["native_binary_sha256"] = shortSha(binary);
        observations["source_sha256"] = shortSha(a);
        observations["peer_sha256"] = shortSha(b);
        observations["source_frames44100"] = 211;
        const auto expectedFrames = conflux::audio::StemRateConverter::countFrames(211, 4096).outputFrames();
        observations["expected_output_frames48000"] = qint64(expectedFrames);
        pw_init(nullptr, nullptr);
        // Existing Sink is an endpoint owner here. Its constant .125/-.0625
        // sample oracle is deliberately unarmed for changing live/quiet audio.
        Sink sink("conflux-short-live-test-sink");
        ServiceTrace services(fixture); // Fallback only after the proof checks below.
        bool groupsGone = true;
        conflux::library::detail::OwnedStemProcess owned(groupsGone);
        auto& child = owned.process();
        auto env = QProcessEnvironment::systemEnvironment();
        env.insert("XDG_CACHE_HOME", output + "/cache");
        env.insert("QT_QPA_PLATFORM", "offscreen"); env.insert("QT_QUICK_BACKEND", "software");
        env.insert("QT_QUICK_CONTROLS_STYLE", "Basic"); env.remove("CONFLUX_ALLOW_HOST_SOAK");
        child.setProcessEnvironment(env);
        child.setStandardOutputFile(QDir(parent).filePath("native.stdout.log"));
        child.setStandardErrorFile(QDir(parent).filePath("native.stderr.log"));
        const auto stopFile = output + "/STOP";
        std::exception_ptr primary;
        try {
            child.start(binary, {"--live-stems", a, b, output, "3", stopFile,
                fixture.engine.pythonExecutable, fixture.engine.exporterPath, fixture.engine.workerPath,
                fixture.service, fixture.engine.runtimePath, fixture.engine.modelPath});
            require(child.waitForStarted(3000) && owned.group() > 1,
                    "Native live child starts in one independently owned process group");
            observations["native_pid"] = child.processId(); observations["native_group"] = owned.group();
            const auto deadline = Clock::now() + std::chrono::seconds(65);
            while (child.state() != QProcess::NotRunning) {
                QCoreApplication::processEvents(QEventLoop::AllEvents, 5);
                services.capture();
                if (shortOwnerStop) throw std::runtime_error("Private fixture owner stopped");
                if (Clock::now() >= deadline) throw std::runtime_error("Private native fixture exceeded65s setup/playback bound");
                QThread::msleep(2);
            }
        } catch (...) { primary = std::current_exception(); }
        // A failed owner still requests cooperative native shutdown, then uses
        // the existing bounded known-group finish. Never delete cache charges.
        if (child.state() != QProcess::NotRunning) {
            QFile stop(stopFile); const bool requested = stop.open(QIODevice::WriteOnly | QIODevice::NewOnly);
            if (requested) { stop.write("private-owner-stop\n"); stop.close(); }
            const auto grace = Clock::now() + std::chrono::seconds(10);
            while (child.state() != QProcess::NotRunning && Clock::now() < grace) {
                QCoreApplication::processEvents(QEventLoop::AllEvents, 5); QThread::msleep(2);
            }
        }
        const bool groupClean = owned.finish();
        observations["native_group_gone"] = groupClean && groupsGone;
        observations["native_exit"] = child.exitCode();
        observations["native_normal_exit"] = child.exitStatus() == QProcess::NormalExit;
        services.capture(); observations["services"] = services.identities();
        bool serviceClean = services.size() == 1;
        for (std::size_t i = 0; i < services.size(); ++i) serviceClean = services.gone(i) && serviceClean;
        observations["service_and_job_gone_before_fallback"] = serviceClean;
        observations["sink_name"] = QString::fromStdString(sink.name());
        observations["sink_constant_sample_oracle_armed"] = false;
        if (QFileInfo::exists(output + "/native-result.json")) observations["native"] = shortObject(output + "/native-result.json");
        if (primary) std::rethrow_exception(primary);
        require(groupClean && groupsGone && child.exitStatus() == QProcess::NormalExit && child.exitCode() == 0,
                "Native live child exits0 and its known group is gone before fallback cleanup");
        require(serviceClean, "One observed fake-service identity and its live job disappear before safety cleanup");
        require(services.count(0, "command", "load") == 1 && services.count(0, "fixture", "runtime") == 1 &&
                services.count(0, "command", "seek") >= 1,
                "EOF replay uses one persistent fake service/runtime rather than reloading a process");
        const auto native = observations["native"].toObject();
        require(native["passed"].toBool() && native["error"].toString().isEmpty() &&
                native["functional_only"].toBool() && !native["host_audio"].toBool() &&
                native["mode"].toString() == "live-stems" && native["requested_seconds"].toInt() == 3 &&
                native["shutdown_completed"].toBool() && native["last_recovery_complete"].toBool(),
                "Actual three-second native live mode completes only as private functional evidence");
        const auto setup = native["setup"].toObject(), counters = native["observation_counters"].toObject();
        require(setup["source_token"].toInteger() > 0 && setup["input_frames"].toInteger() == 211 &&
                setup["output_frames"].toInteger() == qint64(expectedFrames) &&
                setup["source_sha256"].toString() == observations["source_sha256"].toString() &&
                setup["model_sha256"].toString() == shortSha(fixture.engine.modelPath) &&
                setup["runtime_sha256"].toString() == shortSha(fixture.engine.runtimePath) &&
                setup["service_sha256"].toString() == shortSha(fixture.service),
                "Native live metadata binds the actual tiny source, exact conversion count and fake tool identities");
        require(native["first_advance_observed_ns"].toInteger() > 0 && native["eof_count"].toInteger() > 0 &&
                native["replay_count"].toInteger() > 0 && native["steady_starved_frames"].toInteger() == 0 &&
                counters["producer_finished"].toBool() && counters["attempted"].toInteger() == counters["retained"].toInteger() &&
                counters["retained"].toInteger() > 0 && !counters["dropped"].toInteger() && !counters["invalid_clock_reads"].toInteger(),
                "Actual live advancement, EOF replay and complete loss-free observation retirement are observed");
        const auto recorded = native["recorded_audio"].toObject(), writer = native["recording"].toObject();
        require(recorded["frames"].toInteger() > 0 && recorded["nonzero_samples"].toInteger() > 0 &&
                writer["acceptedFrames"].toInteger() == recorded["frames"].toInteger() &&
                writer["writtenFrames"].toInteger() == recorded["frames"].toInteger() && !writer["overflowFrames"].toInteger(),
                "Native finite float-WAV recording retains exact accepted/written counts without overflow");
        passed = true;
    } catch (const std::exception& failure) { error = QString::fromUtf8(failure.what()); }
    const QJsonObject result{{"passed", passed}, {"error", error}, {"checks", checks},
        {"execution_deadline_gate", false}, {"observations", observations},
        {"scope", "Private3s actual native live path with generated211-frame source, quiet finite peer and fake service. Sink owns routing endpoint only; native recording/metadata/progress oracles remain active. No model, host audio, physical latency, sustained or musical qualification."}};
    if (!report.isEmpty() && !save(report, result)) {
        std::cerr << "Cannot save fixture-owner-result.json\n";
        return 1;
    }
    std::cout << QJsonDocument(result).toJson(QJsonDocument::Compact).constData() << '\n';
    return passed ? 0 : 1;
}
