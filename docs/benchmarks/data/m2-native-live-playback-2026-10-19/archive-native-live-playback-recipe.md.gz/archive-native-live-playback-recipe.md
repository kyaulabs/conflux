# Native live playback evidence archive

Root is the sole execution owner. The author has written only this ignored source, named-input manifest, recipe and freeze; no archive, scanner, Git command, workload or test has been executed by the author.

Review `archive_native_live_playback.py` and the 90-entry `archive-native-live-playback-inputs.json` manifest before running. Default invocation prints a dry plan and reads no evidence or Git metadata:

```sh
python3 -B benchmarks-local/m2-live-delivery-2026-10-19/archive_native_live_playback.py
```

After independent source review, root may execute exactly:

```sh
python3 -B benchmarks-local/m2-live-delivery-2026-10-19/archive_native_live_playback.py --run --head d59d6316c7153b7fc6b38bb68b06f90baa157cde
```

The run verifies the three exact valid signed kyau source commits, current selected harness/converter bytes and their historical per-run source/binary bindings. Other dirty documentation is permitted; selected code must match the final signed source. Historical binary SHA values come from the original closed run and build receipts; replaced historical binaries are not purported to be freshly rehashed.

Both failed native host runs remain failures. Run 01's visibility interruption and incomplete old interval accounting are retained, together with the later human explanation. Run 02 retains its completed 120-second workload, strict 4095ms misses, steady/control/outside interval starvation, and `cleanup_proven=false`. Known groups disappeared, but its missing ownership/runtime proof remains a blocker. The later synthetic ownership-history fix cannot certify the earlier run. The archiver never deletes or reads run 02's preserved cache.

Initial 32-case offline and 10-case CLI checks, actual private fixture evidence, reporting STOP RED/GREEN, history RED/GREEN, generated converter v2 and baseline/medium/baseline results are named explicitly. Private execution receipts already contain the original native and fixture-owner results; those are not duplicated into extra files. Source-only candidate conversion quality remains separate from production and listening acceptance.

The archive contains exactly 100 files: 90 named source/evidence inputs, this script/manifest/freeze/recipe, three exact signed Git source snapshots, two scanner outputs and the generated verification manifest. All selected payloads are UTF-8 text and deterministic gzip streams, except the plain generated verification JSON. Media, recordings, models, executable binaries, caches, local future listening assets and unrelated older benchmarks are excluded. The signed product converter baseline is read with exact `git show`, verified against SHA256 `482c55e043847adb75b42bdd25fd8859cd97e106208d46170ba1f84c897f9294` and archived without inventing a prior local baseline-copy operation.

The aggregate named raw text is bounded to 128 MiB. Fresh ignored staging/raw directories are `native-live-playback-archive-stage` and `native-live-playback-archive-raw` under this directory; existing paths are rejected. Gitleaks scans the uncompressed named inputs with redacted output and must return zero with an empty findings array. There are no suppressions or normalization steps. On failure, root retains staging/raw evidence for inspection; the script does not publish the canonical directory.

After scanning, every archived hash and gzip round trip is checked, every origin is reread and compared, and selected source/HEAD stability is rechecked. The stage is atomically renamed to `docs/benchmarks/data/m2-native-live-playback-2026-10-19` only after these checks. The final manifest records M2 open, failed playback, incomplete earlier cleanup and the lack of new CI or qualification claims. Review scanner output and the canonical verification file after root execution before committing evidence.
