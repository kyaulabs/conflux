# Private short live fixture owner

This ignored helper includes `preparation_controller_check.cpp` with its original main renamed. It reuses `Sink`, `writeFixture`, private-runtime validation and identity-safe `ServiceTrace` cleanup. `OwnedStemProcess` supplies the existing known-group teardown. It adds no permanent target or dependency.

Apply the separately reviewed two-file short-live experiment patch first. Root then builds the existing native target and this helper. The flags and static-library order below come from `CMakeLists.txt` and the normal preparation target's `build/dev/build.ninja` compile/link statements. The helper has no `Q_OBJECT`, so it needs no new moc step; the existing UI archive supplies its own generated metaobjects.

```sh
conflux_task_root="$PWD"
conflux_task_base="$conflux_task_root/benchmarks-local/m2-live-delivery-2026-10-19"
cmake --build build/dev --target conflux-manual-playback-soak --parallel 2
/bin/c++ -O2 -g -DNDEBUG -std=c++20 -Wall -Wextra -Wpedantic \
  -mno-direct-extern-access -D_REENTRANT -fno-strict-aliasing -fno-strict-overflow \
  -DQT_CONCURRENT_LIB -DQT_CORE_LIB -DQT_NO_DEBUG \
  "-DCONFLUX_SOURCE_DIR=\"$conflux_task_root\"" -I"$conflux_task_root/src" \
  $(pkg-config --cflags Qt6Core Qt6Concurrent libpipewire-0.3) \
  "$conflux_task_base/short_live_fixture_owner.cpp" \
  "$conflux_task_root/build/dev/libconflux-ui.a" \
  $(pkg-config --libs Qt6Concurrent) \
  "$conflux_task_root/build/dev/libconflux-audio-live.a" \
  $(pkg-config --libs libpipewire-0.3) \
  "$conflux_task_root/build/dev/libconflux-library.a" \
  $(pkg-config --libs Qt6Core) \
  "$conflux_task_root/build/dev/libconflux-audio.a" \
  $(pkg-config --libs sndfile samplerate) -pthread \
  -o "$conflux_task_base/short-live-fixture-owner"
sha256sum "$conflux_task_base/short_live_fixture_owner.cpp" \
  "$conflux_task_base/short-live-fixture-owner" \
  build/dev/conflux-manual-playback-soak tests/StemServiceFixture.hpp \
  tools/experiments/preparation_controller_check.cpp
QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software QT_QUICK_CONTROLS_STYLE=Basic \
  python3 -B tools/experiments/private_routing_check.py \
  "$conflux_task_base/short-live-fixture-owner" \
  "$conflux_task_base/short-live-private-01"
```

The wrapper creates and owns the private 0700 runtime, socket, client configuration and dummy driver. The helper accepts its runtime/empty-recordings argv contract. It creates persistent `fixture-inputs` beside `recordings`, including the actual stdlib fake service, a 211-frame 44.1 kHz PCM16 source (.25/-.125) and a 30-second 48 kHz quiet peer (1/-1 PCM16). Only generated media are written. Child cache is exactly `recordings/cache`; all private-runtime and offscreen environment checks remain active. No host launcher, real model or GPU work is selected.

The sink name is exactly `conflux-short-live-test-sink`. Its existing constant-sample oracle stays unarmed for changing tiny-source/quiet-peer playback; this helper makes no independent sink-quality claim. The native's existing finite float-WAV, frame/overflow, configured-gain, source/peer, EOF/replay and loss-free observation checks remain required. The owner additionally binds source/tool hashes and exact converter frame count, one observed persistent fake service/runtime, its replay seeks, direct child group and service/job disappearance before safety fallback.

The child has a 65-second setup/playback bound, then up to ten seconds for stop-file shutdown before existing bounded group finish. These are functional-test cleanup bounds. The outer wrapper retains its normal 90-second guard; the helper and native report functional-only scope. `incomplete_generation_seek_submitted` may be false for this tiny source and is not forced by a sleep.

Keep the entire fresh run, including failures: wrapper `result.json`, `check.stdout.json`, logs and graph dumps; `fixture-owner-result.json`; generated fixture scripts/markers/trace; and the native `recordings/native-result.json`, observations JSONL, progress, recording and cache. The native stdout/stderr are separate bounded-workload logs beside them. The helper never deletes retained cache charges on failure. The wrapper's final graph dump independently verifies sink/link cleanup after the fixture owner exits. No result here qualifies real-model, host playback, physical latency, sustained p99, fallback or musical quality. Neither these commands nor a workload were executed by the draft author.
