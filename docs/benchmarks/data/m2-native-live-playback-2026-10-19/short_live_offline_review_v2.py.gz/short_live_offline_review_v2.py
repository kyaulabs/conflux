#!/usr/bin/env python3
"""Root-run offline checks of the frozen short-live draft; never starts a child.

Only the selected source functions are compiled.  The launcher fault cases use
real small private temporary files but replace every process, signal, selector,
clock and host-query boundary.  The review author has not executed this file.
"""
import argparse
import ast
import contextlib
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import types
from unittest import mock


BASE = Path(__file__).resolve().parent
PINS = {
    "short-live-playback-implementation-v2.patch": "6e0457823060351f2eb7c2ce10be5b6b612b6a55641b2a4719f1ebb04230eb3e",
    "short-live-v2-run_manual_playback_soak.py": "b5850f5106c3155f782adfaf482e5461104df0b29549673ea32a0ded2db21775",
    "short-live-manual_playback_soak.cpp": "d20bba5df58ac5cc63fd7b375977d7bfdda32cdd190b067ccfe659d7e4d40c9e",
}
CHECKS = []


def require(value, message):
    if not value:
        raise AssertionError(message)


def checked(name, action):
    action()
    CHECKS.append(name)


def rejects(action, text=None):
    try:
        action()
    except (RuntimeError, ValueError, KeyError, TypeError) as error:
        if text is not None:
            require(text in str(error), f"Wrong rejection: {error!s}")
        return
    raise AssertionError("Expected rejection")


def functions(tree, names, namespace, replacement=None, nested=False):
    class LiftNonlocal(ast.NodeTransformer):
        def visit_Nonlocal(self, node):
            return ast.copy_location(ast.Global(names=node.names), node)
    parent = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "run_live") if nested else tree
    selected = []
    for node in parent.body:
        if isinstance(node, ast.FunctionDef) and node.name in names:
            node = copy.deepcopy(node)
            if nested:
                node = LiftNonlocal().visit(node)
            if replacement is not None:
                node = replacement(node)
            selected.append(node)
    require({node.name for node in selected} == set(names), "Selected source functions missing")
    module = ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[]))
    exec(compile(module, "<frozen-short-live-functions>", "exec"), namespace)


def common_namespace():
    return dict(json=json, math=math, hashlib=hashlib, stat=stat, os=os, Path=Path,
                datetime=datetime, timezone=timezone, time=__import__("time"),
                shutil=shutil, signal=signal, subprocess=subprocess)


def record(kind, **fields):
    row = dict(kind=kind, ordinal=0, observed_ns=0, epoch=1, generation=1,
        command_id=0, request_id=0, lease_sequence=0, input_first=0,
        input_frames=0, output_first=0, output_frames=0, final=False,
        validated_ns=0, packet_ready_ns=0, full_observed=False, first_full_ns=0,
        publish_begin_ns=0, publish_end_ns=0, worker_ready_seconds=10.0,
        service_published_seconds=10.01, hop_service_present=False,
        hop_service_ms=0.0, telemetry_dropped_present=False, telemetry_dropped=0)
    row.update(fields)
    return row


def finish_rows(rows):
    for index, row in enumerate(rows):
        row["ordinal"] = 400 + index  # The contract deliberately has no origin.
        row["observed_ns"] = 1000 + index * 100
        if row["kind"] == 5:
            row["validated_ns"] = row["observed_ns"] + 10
        if row["kind"] == 6:
            row.update(packet_ready_ns=row["observed_ns"] - 30,
                       publish_begin_ns=row["observed_ns"] - 20,
                       publish_end_ns=row["observed_ns"] - 10)
    return rows


def basic_rows():
    return finish_rows([
        record(2), record(3, command_id=1), record(4, command_id=1),
        record(5, request_id=1, lease_sequence=1, input_frames=211, final=True),
        record(8, input_first=211), record(9, input_first=211, output_first=230),
        record(6, output_frames=230, final=True), record(10, input_first=211),
    ])


def summary_checks(tree, root):
    ns = common_namespace()
    functions(tree, {"pin", "summarize_live_observations"}, ns)
    path = root / "observations.jsonl"
    def summarize(rows=None, n=211, m=230, controls=None, counters=None):
        rows = copy.deepcopy(basic_rows() if rows is None else rows)
        native = dict(setup=dict(input_frames=n, output_frames=m,
            factory_entry_ns=1, input_captured_ns=2, count_complete_ns=3,
            factory_committed_ns=4), load_issued_ns=5, first_advance_observed_ns=6,
            controls=controls or [], observation_counters=dict(producer_finished=True,
            dropped=0, invalid_clock_reads=0, retained=len(rows), attempted=len(rows)))
        if counters:
            native["observation_counters"].update(counters)
        path.write_text("".join(json.dumps(row) + "\n" for row in
            [dict(type="setup", context=native["setup"])] + rows))
        return ns["summarize_live_observations"](path, native)
    checked("summary: complete finite source and non-origin ordinal sequence", lambda: require(
        summarize()["epochs"][1]["final"], "Complete source not final"))
    checked("summary: absent optional hop is not a complete metric population", lambda: require(
        summarize()["service_hops"]["complete"] is False and
        summarize()["service_hops"]["nearest_rank_p99_ms"] is None, "Missing optional timing falsely complete"))
    def strict_hop():
        rows = basic_rows(); rows[3].update(hop_service_present=True, hop_service_ms=4095.0)
        value = summarize(rows)["service_hops"]
        require(value["complete"] and value["at_or_above_target"] == 1, "Strict target equality falsely passed")
    checked("summary: 4095 ms equality is a strict miss", strict_hop)
    def mixed_hop_population():
        n = 257985 + 211
        m = (n * 48000 + 44099) // 44100
        rows = finish_rows([record(2), record(3, command_id=1), record(4, command_id=1),
            record(5, request_id=1, lease_sequence=1, input_frames=257985,
                hop_service_present=True, hop_service_ms=4000.0),
            record(5, request_id=2, lease_sequence=2, input_first=257985, input_frames=211, final=True),
            record(8, input_first=n), record(10, input_first=n)])
        value = summarize(rows, n=n, m=m)
        require(value["kind_counts"]["ChunkValidated"] == 2 and value["service_hops"]["count"] == 1 and
                value["service_hops"]["complete"] is False,
                "Mixed optional timing presence falsely claims the complete population")
        rows[4].update(hop_service_present=True, hop_service_ms=4100.0)
        complete = summarize(rows, n=n, m=m)["service_hops"]
        require(complete["count"] == 2 and complete["complete"] is True and complete["at_or_above_target"] == 1,
                "Complete timing population or strict miss count is wrong")
    checked("summary: mixed hop presence is incomplete; all present restores completeness", mixed_hop_population)
    def service_loss():
        rows = basic_rows(); rows[4].update(telemetry_dropped_present=True, telemetry_dropped=2)
        value = summarize(rows)
        require(not value["service_metrics_complete"] and not value["service_hops"]["complete"], "Service loss masked")
    checked("summary: service loss retained and measurement incomplete", service_loss)
    for label, index, field, value in (
        ("ordinal gap", 4, "ordinal", 999),
        ("wrong lease generation", 3, "generation", 2),
        ("wrong lease epoch", 3, "epoch", 2),
        ("invalid optional hop", 3, "hop_service_ms", float("nan")),
        ("invalid Python-domain interval", 3, "service_published_seconds", 9.0),
        ("packet output gap", 6, "output_first", 1),
        ("wrong raw completion endpoint", 4, "input_first", 210),
    ):
        def fail(index=index, field=field, value=value):
            rows = basic_rows(); rows[index][field] = value
            if field == "hop_service_ms": rows[index]["hop_service_present"] = True
            rejects(lambda: summarize(rows))
        checked("summary rejects: " + label, fail)
    checked("summary rejects: observation queue loss", lambda: rejects(lambda: summarize(counters={"dropped": 1})))
    checked("summary rejects: producer clock loss", lambda: rejects(lambda: summarize(counters={"invalid_clock_reads": 1})))
    def repeated_sequence():
        n = 257985 + 211
        rows = finish_rows([record(2), record(3, command_id=1), record(4, command_id=1),
            record(5, request_id=1, lease_sequence=1, input_frames=257985),
            record(5, request_id=2, lease_sequence=1, input_first=257985, input_frames=211, final=True)])
        rejects(lambda: summarize(rows, n=n))
    checked("summary rejects: repeated lease sequence", repeated_sequence)
    def canceled_gap():
        n = 257985 + 211
        m = (n * 48000 + 44099) // 44100
        rows = [record(2), record(3, command_id=1), record(4, command_id=1),
            record(5, request_id=1, lease_sequence=1, input_frames=257985),
            record(2, epoch=2), record(3, epoch=2, command_id=2),
            record(4, epoch=2, command_id=2, generation=2),
            # Sequence 2 validation was intentionally unobserved during cancellation.
            record(5, epoch=2, generation=2, request_id=3, lease_sequence=3, input_frames=257985),
            record(5, epoch=2, generation=2, request_id=4, lease_sequence=4, input_first=257985, input_frames=211, final=True),
            record(8, epoch=2, generation=2, input_first=n),
            record(9, epoch=2, generation=2, input_first=n, output_first=m)]
        rows.extend(record(6, epoch=2, generation=2, output_first=first,
            output_frames=min(4096, m - first), final=first + 4096 >= m) for first in range(0, m, 4096))
        rows.append(record(10, epoch=2, generation=2, input_first=n)); finish_rows(rows)
        value = summarize(rows, n=n, m=m)
        require(value["epochs"][2]["final"], "Legitimate canceled-validation sequence gap rejected")
        old_packet = record(6, output_frames=4096)
        rows.insert(7, old_packet); finish_rows(rows)
        rejects(lambda: summarize(rows, n=n, m=m))
    checked("summary: canceled validation gap allowed, old packet after new demand rejected", canceled_gap)
    def raw_endpoint_without_validation():
        n = 257985 + 211
        rows = finish_rows([record(2), record(3, command_id=1), record(4, command_id=1),
            record(5, request_id=1, lease_sequence=1, input_frames=257985), record(8, input_first=n), record(10, input_first=n)])
        value = summarize(rows, n=n)
        epoch = value["epochs"][1]
        require(epoch["validated_end"] == 257985 and epoch["raw_service_endpoint"] == n,
                "Raw endpoint fabricated a validated prefix")
        rows.insert(-1, record(9, input_first=n, output_first=230)); finish_rows(rows)
        rejects(lambda: summarize(rows, n=n))
    checked("summary: raw service endpoint does not invent validated converter coverage", raw_endpoint_without_validation)
    def seek_classification():
        rows = basic_rows(); completed = rows[4]["observed_ns"]
        before = summarize(rows, controls=[dict(kind="incomplete_generation_seek", previous_generation=1, issued_ns=completed - 1)])
        after = summarize(rows, controls=[dict(kind="incomplete_generation_seek", previous_generation=1, issued_ns=completed + 1)])
        require(before["incomplete_generation_seek"]["exercised"] and not after["incomplete_generation_seek"]["exercised"],
                "Seek classification ignores retrospective RawComplete")
    checked("summary: incomplete seek uses retrospective same-domain stamps", seek_classification)


def readiness_checks(tree, root):
    fixed = datetime(2026, 10, 19, tzinfo=timezone.utc)
    class Clock(datetime):
        @classmethod
        def now(cls, tz=None): return fixed
    ns = common_namespace(); ns["datetime"] = Clock
    functions(tree, {"pin", "live_readiness"}, ns)
    path = root / "readiness.json"
    base = dict(schema=1, decision="ready", ready_for_run="review-run", AC_power=True,
        lid_open=True, visible_window=True, screen_awake=True, human_reply="Ready",
        recorded_at_utc=fixed.isoformat())
    def call(changes=None):
        value = dict(base); value.update(changes or {}); path.write_text(json.dumps(value))
        return ns["live_readiness"](path, "review-run")
    checked("readiness: matching physical decision accepted", lambda: require(call()["age_seconds"] == 0, "Bad readiness age"))
    for label, delta in (("wrong label", dict(ready_for_run="old-run")),
        ("stale", dict(recorded_at_utc=(fixed - timedelta(seconds=901)).isoformat())),
        ("future", dict(recorded_at_utc=(fixed + timedelta(seconds=1)).isoformat())),
        ("closed lid", dict(lid_open=False)), ("nonboolean AC", dict(AC_power=1))):
        checked("readiness rejects: " + label, lambda delta=delta: rejects(lambda: call(delta)))


class TickClock:
    def __init__(self): self.current = 0.0
    def monotonic(self):
        self.current += .25
        return self.current


class FakePipe:
    def __init__(self, fd): self.fd, self.closed = fd, False
    def fileno(self): return self.fd
    def close(self): self.closed = True


class FakeChild:
    pid = 400001
    def __init__(self, already_dead=False):
        self.returncode = 7 if already_dead else None
        self.stdout, self.stderr = FakePipe(800001), FakePipe(800002)
        self.waits = 0
    def poll(self): return self.returncode
    def wait(self, timeout=None):
        self.waits += 1
        require(self.returncode is not None, "Fake child was not stopped before wait")
        return self.returncode


def launcher_fault_checks(tree, root):
    # Only host/proc discovery helpers are replaced.  Popen publication, exception
    # routing, direct-child authority, finish waits, group probes and preservation
    # all execute from the actual source function.
    def replace(node):
        for child in ast.walk(node):
            if isinstance(child, ast.FunctionDef) and child.name in ("process_record", "live_guard", "remember_owned"):
                args = [ast.Name(id="pid", ctx=ast.Load())] if child.name == "process_record" else []
                child.body = [ast.Return(value=ast.Call(func=ast.Name(id="injected_" + child.name, ctx=ast.Load()), args=args, keywords=[]))]
        return node
    def scenario(name, mode):
        directory = root / name; directory.mkdir()
        repo = directory / "repo"; runner = repo / "tools/experiments/runner.py"
        runner.parent.mkdir(parents=True); runner.write_text("# fake source fixture\n")
        for leaf in ("qml/Main.qml", "qml/DeckSurface.qml", "qml/MixerSurface.qml", "qml/DeckButton.qml", "qml/SurfaceKnob.qml", "qml/StereoMeter.qml",
            "brand/integration/qtquick/ConfluxTheme.qml", "brand/integration/qtquick/qmldir",
            "brand/assets/logos/conflux-horizontal-dark.svg", "brand/assets/logos/conflux-horizontal-light.svg",
            "brand/assets/fonts/Barlow-Regular.ttf", "brand/assets/fonts/BarlowCondensed-SemiBold.ttf", "brand/assets/fonts/JetBrainsMono-Regular.ttf"):
            path = repo / leaf; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(b"fixture")
        files = {}
        for key in ("binary", "track_a", "track_b", "python", "exporter", "worker", "service", "runtime", "model", "guard_script", "guard_unit"):
            files[key] = directory / key; files[key].write_bytes(key.encode())
        if mode == "fifo":
            files["track_a"].unlink(); os.mkfifo(files["track_a"], 0o600)
        output = directory / "evidence"
        readiness = directory / "ready.json"
        readiness.write_text(json.dumps(dict(schema=1, decision="ready", ready_for_run=output.name,
            AC_power=True, lid_open=True, visible_window=True, screen_awake=True,
            human_reply="Offline fabricated decision only", recorded_at_utc=datetime.now(timezone.utc).isoformat())))
        args = types.SimpleNamespace(**files, output=output, readiness_decision=readiness, seconds=120)
        child = FakeChild(already_dead=mode == "dead-group")
        spawned, signals, queries = [], [], []
        class Selector:
            def register(self, *_): raise RuntimeError("injected pipe registration failure")
            def select(self, *_): return []
            def get_map(self): return {}
            def close(self): pass
        def popen(*values, **options):
            require(options.get("start_new_session") is True, "Direct group not created")
            spawned.append(values); return child
        def killpg(group, number):
            require(group == child.pid, "Unexpected group signal/probe")
            if number == 0:
                queries.append(group)
                if mode != "dead-group" and child.returncode is not None: raise ProcessLookupError()
            else:
                signals.append((group, number)); child.returncode = -number
        def process_record(pid):
            if mode == "proc": raise RuntimeError("injected proc identity failure")
            return dict(pid=pid, start_ticks=77, group=pid, session=pid, ppid=1, command=[str(files["binary"])])
        safe_os = types.SimpleNamespace(**{key: getattr(os, key) for key in dir(os) if not key.startswith("__")})
        safe_os.killpg, safe_os.getpgrp, safe_os.set_blocking = killpg, lambda: 999999, lambda *_: None
        safe_signal = types.SimpleNamespace(SIGINT=signal.SIGINT, SIGTERM=signal.SIGTERM,
            SIGKILL=signal.SIGKILL, SIG_IGN=signal.SIG_IGN, signal=lambda *_: None)
        ns = common_namespace()
        ns.update(__file__=str(runner), os=safe_os, signal=safe_signal, time=TickClock(),
            shutil=types.SimpleNamespace(disk_usage=lambda *_: types.SimpleNamespace(free=16 * 1024**3), rmtree=shutil.rmtree),
            subprocess=types.SimpleNamespace(Popen=popen, PIPE=-1, DEVNULL=-3, TimeoutExpired=subprocess.TimeoutExpired),
            injected_process_record=process_record, injected_live_guard=lambda: {"fixed": "guard"},
            injected_remember_owned=lambda: None, read_command=lambda *_args, **_kwargs: "[]",
            power_state=lambda: dict(ac_online=True, lid_open=True), sensor_paths=lambda: ["fixture"],
            observation=lambda *_: {"temperatures_millidegrees_C": {"fixture": 42000}},
            owned_objects=lambda *_: [], thermal_summary=lambda *_: {},
            FLASH_RUNTIME_SHA256=hashlib.sha256(b"runtime").hexdigest(),
            FLASH_MODEL_SHA256=hashlib.sha256(b"model").hexdigest())
        functions(tree, {"pin", "save", "live_readiness", "run_live"}, ns, replace)
        fake_selectors = types.SimpleNamespace(DefaultSelector=Selector, EVENT_READ=1)
        with mock.patch.dict(sys.modules, {"selectors": fake_selectors}), contextlib.redirect_stdout(io.StringIO()):
            exit_code = ns["run_live"](args)
        result = json.loads((output / "result.json").read_text())
        require(exit_code != 0 and not result["passed"], "Injected failure passed")
        if mode == "fifo":
            require(not spawned and "regular file" in result["error"], "FIFO reached process/host boundary")
        else:
            require(len(spawned) == 1 and child.waits and child.stdout.closed and child.stderr.closed, "Child/pipe ownership lost")
            require(result["cache_preserved"] and not result["cleanup_proven"], "Unproven cleanup removed cache")
            if mode == "dead-group":
                require(not signals and queries and result["cleanup"]["owned_group_absent"][str(child.pid)] is False,
                        "Reaped leader authorized a bare group signal or missing group probe")
            else:
                require(signals and child.returncode is not None, "Unpublished direct child was not stopped")
    for label, mode in (("FIFO rejected before Popen", "fifo"), ("proc failure after Popen", "proc"),
                        ("pipe registration failure after Popen", "selector"), ("dead leader and surviving unproven group", "dead-group")):
        checked("launcher: " + label, lambda mode=mode: scenario(mode, mode))


def ownership_checks(tree):
    root_identity = dict(pid=101, start_ticks=11, group=101, session=101, ppid=1, command=["root"])
    child_identity = dict(pid=202, start_ticks=22, group=202, session=202, ppid=101, command=["service"])
    class ProcPath:
        def __init__(self, value): self.value = str(value)
        def __truediv__(self, value): return ProcPath(self.value.rstrip("/") + "/" + str(value))
        def iterdir(self): return [self / "1"]
        def read_text(self): return "202" if self.value == "/proc/101/task/1/children" else ""
    calls = {101: 0}
    def process_record(pid):
        if pid == 101:
            calls[101] += 1
            return dict(root_identity, start_ticks=99) if calls[101] >= 3 else dict(root_identity)
        return dict(child_identity)
    ns = dict(Path=ProcPath, child=types.SimpleNamespace(pid=101), root_identity=root_identity,
        ownership_complete=True, owned={}, observed_groups=set(), process_record=process_record)
    functions(tree, {"same_identity", "remember_owned"}, ns, nested=True)
    def broken_parent():
        ns["remember_owned"]()
        require(not ns["ownership_complete"] and (202, 22) not in ns["owned"] and 202 not in ns["observed_groups"],
                "Reused parent authorized unrelated descendant/group")
    checked("ownership: broken parent identity cannot adopt descendant", broken_parent)
    def signal_case(alive, matches):
        signals = []
        ns = dict(child=types.SimpleNamespace(pid=101, poll=lambda: None if alive else 0),
            live_owned=lambda: matches, os=types.SimpleNamespace(killpg=lambda *pair: signals.append(pair), getpgrp=lambda: 999))
        functions(tree, {"signal_owned"}, ns, nested=True)
        ns["signal_owned"](signal.SIGTERM)
        return signals
    checked("ownership: unreaped direct child authorizes fallback", lambda: require(
        signal_case(True, {}) == [(101, signal.SIGTERM)], "Direct fallback lost"))
    checked("ownership: matched descendant authorizes owned group", lambda: require(
        signal_case(False, {202: dict(child_identity, group=101, session=101)}) == [(101, signal.SIGTERM)], "Matched member not used"))
    checked("ownership: reaped leader without matching member cannot signal", lambda: require(
        signal_case(False, {}) == [], "Bare reused group was signaled"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if not args.run:
        print(json.dumps(dict(status="plan_only", native_started=False, source_pins=PINS)))
        return 0
    require(args.output is not None and not args.output.exists(), "Supply a fresh --output JSON")
    for name, expected in PINS.items():
        require(hashlib.sha256((BASE / name).read_bytes()).hexdigest() == expected, "Source changed: " + name)
    tree = ast.parse((BASE / "short-live-v2-run_manual_playback_soak.py").read_text())
    with tempfile.TemporaryDirectory(prefix="conflux-short-live-offline-") as name:
        root = Path(name)
        summary_checks(tree, root)
        readiness_checks(tree, root)
        launcher_fault_checks(tree, root)
        ownership_checks(tree)
    receipt = dict(schema=1, status="offline_checks_passed", native_started=False,
        source_pins=PINS, check_count=len(CHECKS), checks=CHECKS,
        scope="AST-selected actual source with synthetic observations and mocked process/host boundaries; no real child, host query, model, audio or playback qualification",
        limitations=["Native private playback and host CLI success path are root-owned separate checks",
                     "No arbitrary SIGKILL guarantee; unknown group survival preserves cache",
                     "Synthetic canceled validation shows summary semantics; it is not an actual cancellation latency measurement"])
    with args.output.open("x") as stream: json.dump(receipt, stream, indent=2); stream.write("\n")
    print(json.dumps(dict(status=receipt["status"], check_count=len(CHECKS), receipt=str(args.output))))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
