# Converter medium-quality diagnostic candidate

`StemRateConverter-medium-candidate.cpp` is an exact byte copy of production `src/audio/StemRateConverter.cpp` with its single `SRC_SINC_BEST_QUALITY` token replaced by `SRC_SINC_MEDIUM_QUALITY`. The shared state factory supplies both frame counting and all four role conversions. Production source remains unchanged. The frozen microprofile v2, generated PCM recipe, N=1031940, M=1123201 gate, target0/280800, preroll, output staging, finite/EOF checks and timing code all stay unchanged.

The candidate converter object uses the existing CMake audio-object compile flags; the profiler link uses the exact previous v2 flags, replacing only the audio archive with this converter object. No new target, dependency, configuration or product path. Do not link both the candidate object and the production audio archive.

```sh
conflux_task_root="$PWD"
conflux_task_base="$conflux_task_root/benchmarks-local/m2-live-delivery-2026-10-19"
/bin/c++ -O2 -g -DNDEBUG -std=c++20 -Wall -Wextra -Wpedantic \
  -I"$conflux_task_root/src" $(pkg-config --cflags samplerate) \
  -c "$conflux_task_base/StemRateConverter-medium-candidate.cpp" \
  -o "$conflux_task_base/StemRateConverter-medium-candidate.o"
/bin/c++ -O2 -g -DNDEBUG -std=c++20 -Wall -Wextra -Wpedantic \
  -mno-direct-extern-access -D_REENTRANT -fno-strict-aliasing -fno-strict-overflow \
  -DQT_CORE_LIB -DQT_NO_DEBUG -I"$conflux_task_root/src" \
  $(pkg-config --cflags Qt6Core samplerate) \
  "$conflux_task_base/stem_converter_microprofile_v2.cpp" \
  "$conflux_task_base/StemRateConverter-medium-candidate.o" \
  $(pkg-config --libs Qt6Core samplerate) -pthread \
  -o "$conflux_task_base/stem-converter-microprofile-v2-medium"
sha256sum src/audio/StemRateConverter.cpp src/audio/StemRateConverter.hpp \
  "$conflux_task_base/StemRateConverter-medium-candidate.cpp" \
  "$conflux_task_base/StemRateConverter-medium-candidate.o" \
  "$conflux_task_base/stem_converter_microprofile_v2.cpp" \
  "$conflux_task_base/stem-converter-microprofile-v2" \
  "$conflux_task_base/stem-converter-microprofile-v2-medium"
# Each result path must be fresh; root records command/source/binary pins,
# before/after power-profile observations and exit codes for all three runs.
timeout --signal=TERM --kill-after=5s 60s \
  "$conflux_task_base/stem-converter-microprofile-v2" \
  "$conflux_task_base/stem-converter-quality-baseline-before-01.json"
timeout --signal=TERM --kill-after=5s 60s \
  "$conflux_task_base/stem-converter-microprofile-v2-medium" \
  "$conflux_task_base/stem-converter-quality-medium-01.json"
timeout --signal=TERM --kill-after=5s 60s \
  "$conflux_task_base/stem-converter-microprofile-v2" \
  "$conflux_task_base/stem-converter-quality-baseline-after-01.json"
```

The deterministic source-generation shape remains valid for either filter quality, and each candidate computes its own exact count plan consistently. The public API does not guarantee that changing filter quality preserves exact M on every input. Keep the existing M=1123201 assertion and every EOF/preroll check; if the candidate fails one, preserve that result and investigate rather than changing the gate. Expected waveform hashes will change with filter quality; use the unchanged generated-input hash to bind comparisons. A successful count/finite/geometry profile does not establish musical quality or full-versus-seek numerical equivalence.

Baseline-before, medium, baseline-after reduce simple ordering ambiguity but are still short converter CPU diagnostics, potentially under different thermal, power or desktop conditions. Retain all results, profiles and failures; do not average away changing conditions or claim the4095ms service target has passed. Root may stop after any failure and inspect it. No services, models, user audio, hardware audio, UI or GPU selected. This draft author has not compiled or run the candidate. If effective, adoption requires separate numerical/regression review and a real-track listening comparison before any product change; prior Flash acceptance does not cover this resampler change.
