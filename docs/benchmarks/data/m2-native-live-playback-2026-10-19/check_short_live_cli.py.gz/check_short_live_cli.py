"""Reuse the bounded isolated CLI runner for short-live admission failures only."""
import hashlib,json,os,pathlib,runpy,sys,time
b=pathlib.Path('benchmarks-local/m2-live-delivery-2026-10-19')
ns=runpy.run_path(str(b/'check_controller_live_cli.py'),run_name='bounded_cli_helpers')
case=ns['run_case'];g=case.__globals__;output=b/'short-live-cli';output.mkdir(mode=0o700);g['OUTPUT']=output
native=pathlib.Path('build/dev/conflux-manual-playback-soak').resolve()
launcher=str(pathlib.Path('tools/experiments/run_manual_playback_soak.py').resolve())
rows=[];deadline=time.monotonic()+90
old={name:os.environ.get(name) for name in ['CONFLUX_PRIVATE_ROUTING_CHECK','CONFLUX_ALLOW_HOST_SOAK']}
def argv(five,service,seconds='120'):
 root=pathlib.Path(five[1]).parent.parent
 return ['--allow-host-audio','--live-stems','--binary',str(native),'--track-a',str(root/'absent-a'),'--track-b',str(root/'absent-b'),'--output',str(root/'forbidden-output'),'--seconds',seconds,*[v for flag in ['python','exporter','worker','service','runtime','model','readiness-decision'] for v in ['--'+flag,str(root/('absent-'+flag))]]]
def native_args(five,service,seconds):
 root=pathlib.Path(five[1]).parent.parent;out=root/'native-output';out.mkdir(mode=0o700);(out/'cache').mkdir(mode=0o700)
 return ['--live-stems',str(root/'absent-a'),str(root/'absent-b'),str(out),seconds,str(root/'stop'),*[str(root/('absent-'+flag)) for flag in ['python','exporter','worker','service','runtime','model']]]
cases=[('native-missing',native,lambda f,s:['--live-stems'],False,'Usage:'),('native-private-short',native,lambda f,s:native_args(f,s,'0'),True,None),('native-private-long',native,lambda f,s:native_args(f,s,'11'),True,None),('native-host-offscreen',native,lambda f,s:native_args(f,s,'120'),False,None),('launcher-short',pathlib.Path(sys.executable),lambda f,s:[launcher,*argv(f,s,'119')],False,'Live mode requires'),('launcher-long',pathlib.Path(sys.executable),lambda f,s:[launcher,*argv(f,s,'181')],False,'Live mode requires'),('launcher-missing-tools',pathlib.Path(sys.executable),lambda f,s:[launcher,*argv(f,s)[:13]],False,None),('launcher-relative-tools',pathlib.Path(sys.executable),lambda f,s:[launcher,*argv(f,s),'--python','relative-python'],False,'Live mode requires'),('launcher-offscreen',pathlib.Path(sys.executable),lambda f,s:[launcher,*argv(f,s)],False,'rejects private/offscreen'),('launcher-private',pathlib.Path(sys.executable),lambda f,s:[launcher,*argv(f,s)],True,'rejects private/offscreen')]
try:
 for name,binary,args,private,message in cases:
  if private:os.environ['CONFLUX_PRIVATE_ROUTING_CHECK']='1'
  else:os.environ.pop('CONFLUX_PRIVATE_ROUTING_CHECK',None)
  os.environ['CONFLUX_ALLOW_HOST_SOAK']='1'
  row=case(binary,name,args,2,deadline)
  if message:
   text=(output/(name+'.stderr.txt')).read_text();row['expected_diagnostic_present']=message in text;row['passed'] &= row['expected_diagnostic_present']
  rows.append(row)
  if not row['passed']:break
finally:
 for name,value in old.items():
  if value is None:os.environ.pop(name,None)
  else:os.environ[name]=value
result={'passed':len(rows)==len(cases) and all(x['passed'] for x in rows),'cases':rows,'scope':'Isolated admission rejections only; bounded64KiB streams and no LOAD/native-model/host output. Reused reviewed CLI helper; all admitted commands must exit2.'}
p=b/'short-live-cli-result.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'cases':len(rows),'failed':[r['name'] for r in rows if not r['passed']]}));raise SystemExit(0 if result['passed'] else 1)
