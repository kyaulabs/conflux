# Private measured STOP reporting regression

This ignored variant preserves `short_live_fixture_owner.cpp`. It uses the same existing private wrapper, sink, fake service, tiny source and owned cleanup. Build with the original short-live-fixture-owner recipe compile/link argv, substituting `short_live_stop_fixture_owner.cpp` and output binary `short-live-stop-fixture-owner` only. Build the current native target before RED; do not apply the reporting fix until root retains the failed result and source/binary pins.

Run once per fresh output directory:

```sh
QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software QT_QUICK_CONTROLS_STYLE=Basic \
  python3 -B tools/experiments/private_routing_check.py \
  benchmarks-local/m2-live-delivery-2026-10-19/short-live-stop-fixture-owner \
  benchmarks-local/m2-live-delivery-2026-10-19/short-live-private-stop-red-01
```

The child has a ten-second private measurement maximum. The owner records the first native progress pulse in `steady`, `replay_recovery` or `incomplete_generation_seek`, then waits for a distinct later measured pulse with both a greater monotonic timestamp and output frame. It creates STOP exactly once using a new file and records both pulses and the issuing clock. This uses existing nominal two-second progress updates; it does not sleep to force an inference/recovery phase. The ordinary two-millisecond owner event-loop polling and preexisting65-second wall/ten-second cleanup bounds remain unchanged. No exact source phase, replay count or recovery completion is required.

The helper requires native normal exit2, explicit cancelled true/passed false, the exact graceful stop error, private functional scope, and completed shutdown. New flat report fields are `measurement_begin_output_frame`, `measurement_end_output_frame` and `measurement_intervals_closed`; every interval includes boolean `aborted`. The nonempty measured range must be covered exactly by ordered contiguous intervals, each frame count must equal its output-end minus output-begin, and the final interval must be aborted and end at `measurement_end_output_frame`. A final individual interval can legitimately contain zero frames when stopping immediately after a boundary; the entire measured range must advance. Missing fields on old native source are the intended RED, not a CLI/build failure.

The original hash/geometry, loss-free observation retirement, single persistent fake-service/runtime, pre-fallback service/job disappearance, direct owned process-group cleanup and recording counts/overflow checks remain. The owner independently reopens the actual WAV, validates bounded float32 stereo48k geometry, reads every sample and requires finite PCM and exact total frame count. No host audio/model/GPU workload, real p99, recovery/preemption or music-quality claim. The wrapper separately retains final graph/daemon cleanup evidence. Preserve every RED/GREEN directory; use a fresh `...-green-01` path after the root reporting-only patch. No compile or workload was run by this draft author.
