// SPDX-License-Identifier: AGPL-3.0-or-later
// Ignored local diagnostic: generated PCM and existing converter API only.
#include "audio/StemRateConverter.hpp"
#include <QCryptographicHash>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <span>
#include <stdexcept>
#include <time.h>
#include <vector>

namespace {
using Converter = conflux::audio::StemRateConverter;
constexpr std::uint64_t inputFrames = 1031940, expectedOutputFrames = 1123201;
constexpr std::uint64_t softBudgetNs = 55ULL * 1000000000;
void require(bool value, const char* error) { if (!value) throw std::runtime_error(error); }
std::uint64_t clockNs(clockid_t id)
{
    timespec value{};
    require(::clock_gettime(id, &value) == 0 && value.tv_sec >= 0 && value.tv_nsec >= 0 && value.tv_nsec < 1000000000,
            "Cannot read a valid monotonic/thread-CPU clock");
    return std::uint64_t(value.tv_sec) * 1000000000 + std::uint64_t(value.tv_nsec);
}
struct Stamp { std::uint64_t wall, cpu; };
Stamp stamp() { return {clockNs(CLOCK_MONOTONIC), clockNs(CLOCK_THREAD_CPUTIME_ID)}; }
QJsonObject span(Stamp first, Stamp last)
{
    require(last.wall >= first.wall && last.cpu >= first.cpu, "Profile clock moved backwards");
    return {{"wall_ns", qint64(last.wall - first.wall)}, {"thread_cpu_ns", qint64(last.cpu - first.cpu)}};
}
QJsonObject stats(std::vector<std::uint64_t> values)
{
    if (values.empty()) return {{"count", 0}};
    std::sort(values.begin(), values.end());
    const auto rank = [&](std::size_t numerator) { return values[(numerator * values.size() + 99) / 100 - 1]; };
    std::uint64_t sum = 0; for (auto value : values) sum += value;
    return {{"count", qint64(values.size())}, {"sum_ns", qint64(sum)}, {"minimum_ns", qint64(values.front())},
        {"p50_nearest_rank_ns", qint64(rank(50))}, {"p95_nearest_rank_ns", qint64(rank(95))},
        {"p99_nearest_rank_ns", qint64(rank(99))}, {"maximum_ns", qint64(values.back())}};
}
void checkBudget(std::uint64_t start)
{ require(clockNs(CLOCK_MONOTONIC) - start < softBudgetNs, "Generated diagnostic exceeded55s soft total budget"); }
using Input = std::array<std::vector<float>, Converter::stems>;
QJsonObject scenario(const Converter::FramePlan& plan, const Input& pcm, std::uint64_t target, std::uint64_t totalStart)
{
    checkBudget(totalStart);
    const auto constructStart = stamp(); Converter converter(plan, target); const auto constructEnd = stamp();
    const auto anchor = converter.inputStartFrame();
    const auto cell = target / Converter::outputGrid;
    const auto expectedAnchor = (cell > Converter::prerollCells ? cell - Converter::prerollCells : 0) * Converter::inputGrid;
    require(anchor == expectedAnchor && anchor <= inputFrames && anchor % Converter::inputGrid == 0,
            "Actual input anchor differs from exact converter preroll geometry");
    const auto anchorOutput = anchor / Converter::inputGrid * Converter::outputGrid;
    require(target >= anchorOutput, "Hidden preroll geometry is negative");
    std::array<std::array<float, Converter::blockFrames * 2>, Converter::stems> staging{};
    std::array<std::array<float, 2>, Converter::stems> eofProbe{};
    QJsonArray steps, packetRows;
    std::vector<std::uint64_t> stepWall, stepCpu, packetPreparationWall;
    QCryptographicHash outputHash(QCryptographicHash::Sha256);
    std::uint64_t cursor = anchor, visible = 0, packetFrames = 0, nextPacket = target;
    std::uint64_t eofCalls = 0, finishCalls = 0, inputCalls = 0, callsWithNoVisibleOutput = 0;
    std::uint64_t zeroProgressCalls = 0;
    std::uint64_t firstReadyNs = 0, reserveReadyNs = 0, lastReadyNs = 0;
    std::size_t pending = 0;
    bool finished = false;
    const auto reserveEnd = target + std::min<std::uint64_t>(262144, plan.outputFrames() - target);
    const auto loopStart = stamp();
    auto packetReady = [&] {
        require(pending > 0 && pending <= Converter::blockFrames && nextPacket + pending <= plan.outputFrames(),
                "Generated packet violates exact frame geometry");
        const auto now = clockNs(CLOCK_MONOTONIC);
        if (!firstReadyNs) firstReadyNs = now;
        if (!reserveReadyNs && nextPacket + pending >= reserveEnd) reserveReadyNs = now;
        if (lastReadyNs) packetPreparationWall.push_back(now - lastReadyNs);
        lastReadyNs = now;
        for (std::size_t role = 0; role < Converter::stems; ++role) {
            const auto data = std::span<const float>(staging[role]).first(pending * 2);
            require(std::ranges::all_of(data, [](float value) { return std::isfinite(value); }),
                    "Generated conversion emitted nonfinite PCM");
            outputHash.addData(QByteArrayView(reinterpret_cast<const char*>(data.data()), qsizetype(data.size_bytes())));
        }
        packetRows.append(QJsonObject{{"first_output_frame", qint64(nextPacket)}, {"frames", qint64(pending)},
            {"ready_from_loop_start_ns", qint64(now - loopStart.wall)}, {"final", finished && nextPacket + pending == plan.outputFrames()}});
        packetFrames += pending; nextPacket += pending; pending = 0;
    };
    for (std::size_t ordinal = 1; !finished; ++ordinal) {
        checkBudget(totalStart); require(ordinal <= 16384, "Generated conversion exceeded fixed step bound");
        const auto offered = std::size_t(std::min<std::uint64_t>(Converter::blockFrames, inputFrames - cursor));
        const bool eof = !offered;
        const bool probe = pending == Converter::blockFrames;
        require(!probe || (eof && nextPacket + pending == plan.outputFrames()),
                "Full final packet probe appeared before exact input EOF");
        const auto capacity = probe ? std::size_t(1) : Converter::blockFrames - pending;
        std::array<std::span<const float>, Converter::stems> in;
        std::array<std::span<float>, Converter::stems> out;
        for (std::size_t role = 0; role < Converter::stems; ++role) {
            in[role] = std::span<const float>(pcm[role]).subspan(cursor * 2, offered * 2);
            out[role] = probe ? std::span<float>(eofProbe[role]) : std::span<float>(staging[role]).subspan(pending * 2);
        }
        const auto before = stamp(); const auto step = converter.process(in, out, eof); const auto after = stamp();
        require(after.wall >= before.wall && after.cpu >= before.cpu && step.inputFramesUsed <= offered &&
                step.outputFrames <= capacity && (!probe || !step.outputFrames) &&
                step.firstOutputFrame == target + visible, "Bounded step lost exact input/output/clock geometry");
        // Zero-progress is not an error in the public API. Retain the exact
        // input/pending output and retry under the fixed call/time budgets.
        if (!step.inputFramesUsed && !step.outputFrames && !step.finished) ++zeroProgressCalls;
        stepWall.push_back(after.wall - before.wall); stepCpu.push_back(after.cpu - before.cpu);
        if (eof) ++eofCalls; else ++inputCalls;
        if (!step.outputFrames) ++callsWithNoVisibleOutput;
        cursor += step.inputFramesUsed; visible += step.outputFrames; pending += step.outputFrames;
        finished = step.finished;
        if (finished) { ++finishCalls; require(eof && !step.outputFrames && cursor == inputFrames,
                "Completion lacks actual zero-output EOF and exact consumed input"); }
        steps.append(QJsonObject{{"ordinal", qint64(ordinal)}, {"input_offered", qint64(offered)},
            {"input_used", qint64(step.inputFramesUsed)}, {"output_capacity", qint64(capacity)},
            {"output_frames", qint64(step.outputFrames)}, {"first_output_frame", qint64(step.firstOutputFrame)},
            {"eof", eof}, {"finished", finished}, {"wall_ns", qint64(after.wall - before.wall)},
            {"thread_cpu_ns", qint64(after.cpu - before.cpu)}});
        if (pending == Converter::blockFrames && nextPacket + pending < plan.outputFrames()) packetReady();
        if (finished && pending) packetReady();
    }
    const auto loopEnd = stamp();
    require(cursor == inputFrames && visible == plan.outputFrames() - target && packetFrames == visible &&
            nextPacket == plan.outputFrames() && !pending && firstReadyNs && reserveReadyNs && finishCalls == 1,
            "Final visible/packet/input counts differ from reused exact plan");
    return {{"target_output_frame", qint64(target)}, {"actual_input_anchor", qint64(anchor)},
        {"expected_input_anchor", qint64(expectedAnchor)}, {"input_frames_consumed", qint64(cursor - anchor)},
        {"expected_hidden_preroll_output_frames", qint64(target - anchorOutput)},
        {"preroll_scope", "Expected exact geometry, not a public per-step observed hidden counter; finished validates converter internal discard/global count."},
        {"visible_output_frames", qint64(visible)}, {"expected_visible_output_frames", qint64(plan.outputFrames() - target)},
        {"packet_frames", qint64(packetFrames)}, {"packet_count", packetRows.size()},
        {"input_calls", qint64(inputCalls)}, {"eof_calls", qint64(eofCalls)}, {"finished_calls", qint64(finishCalls)},
        {"calls_without_visible_output", qint64(callsWithNoVisibleOutput)}, {"zero_progress_calls", qint64(zeroProgressCalls)},
        {"constructor", span(constructStart, constructEnd)},
        {"conversion_envelope", span(loopStart, loopEnd)}, {"process_steps_wall", stats(stepWall)},
        {"process_steps_thread_cpu", stats(stepCpu)}, {"packet_ready_spacing_wall", stats(packetPreparationWall)},
        {"first_packet_ready_from_loop_start_ns", qint64(firstReadyNs - loopStart.wall)},
        {"reserve_ready_from_loop_start_ns", qint64(reserveReadyNs - loopStart.wall)},
        {"first_packet_to_reserve_ready_ns", qint64(reserveReadyNs - firstReadyNs)},
        {"output_packet_role_order_sha256", QString::fromLatin1(outputHash.result().toHex())},
        {"steps", steps}, {"packets", packetRows}};
}
} // namespace

int main(int argc, char** argv)
{
    if (argc != 2) { std::cerr << "Usage: stem-converter-microprofile FRESH_ABSOLUTE_RESULT.json\n"; return 2; }
    const QString report = QString::fromLocal8Bit(argv[1]);
    if (!QFileInfo(report).isAbsolute() || QFileInfo::exists(report) || !QFileInfo(QFileInfo(report).absolutePath()).isDir()) return 2;
    QJsonObject result{{"schema", 1}, {"passed", false}, {"qualified", false},
        {"scope", "Generated all-raw-available converter diagnostic only; no service/model/audio/UI or host benchmark qualification."},
        {"clock_scope", "CLOCK_MONOTONIC wall and CLOCK_THREAD_CPUTIME_ID calling-thread CPU; per-process-step clocks bracket converter.process only."},
        {"envelope_scope", "Envelopes also include diagnostic JSON rows, finite output checks, hashing and clock overhead; process sums exclude these. Direct generated spans omit bridge raw lease validation/pread/wire decoding, OS scheduling remains observable."},
        {"input_frames44100", qint64(inputFrames)}, {"expected_output_frames48000", qint64(expectedOutputFrames)},
        {"soft_total_budget_seconds", 55}, {"hard_budget_scope", "Root must run under timeout60s with kill-after5s; no internal watchdog thread."}};
    QString error;
    const auto totalStart = stamp();
    try {
        require(std::endian::native == std::endian::little && sizeof(float) == 4, "Diagnostic hash encoding requires laptop float32 little endian");
        Input pcm;
        QCryptographicHash inputHash(QCryptographicHash::Sha256);
        const auto generationStart = stamp();
        for (std::size_t role = 0; role < Converter::stems; ++role) {
            pcm[role].resize(inputFrames * 2);
            for (std::uint32_t frame = 0; frame < inputFrames; ++frame)
                for (std::uint32_t channel = 0; channel < 2; ++channel) {
                    const auto word = frame * std::uint32_t(1103515245) + std::uint32_t(12345) +
                        std::uint32_t(role) * std::uint32_t(2654435761U) + channel * std::uint32_t(2246822519U);
                    const auto value = std::int32_t((word >> 16) & 65535U) - 32768;
                    pcm[role][frame * 2 + channel] = float(value) / 131072.F;
                }
            inputHash.addData(QByteArrayView(reinterpret_cast<const char*>(pcm[role].data()), qsizetype(pcm[role].size() * sizeof(float))));
        }
        result["generated_pcm"] = QJsonObject{{"recipe", "uint32 wrap(frame*1103515245+12345+role*2654435761+channel*2246822519); ((word>>16)&65535)-32768 scaled by1/131072"},
            {"sha256_role_major_stereo_f32le", QString::fromLatin1(inputHash.result().toHex())}, {"generation", span(generationStart, stamp())}};
        checkBudget(totalStart.wall);
        const auto countStart = stamp(); const auto plan = Converter::countFrames(inputFrames, 1200000); const auto countEnd = stamp();
        result["count"] = span(countStart, countEnd);
        require(plan.inputFrames() == inputFrames && plan.outputFrames() == expectedOutputFrames, "Single count plan differs from closed actual-player exact geometry");
        result["counted_output_frames48000"] = qint64(plan.outputFrames());
        QJsonArray scenarios;
        for (auto target : {std::uint64_t(0), std::uint64_t(280800)}) {
            scenarios.append(scenario(plan, pcm, target, totalStart.wall)); result["scenarios"] = scenarios;
        }
        result["passed"] = true;
    } catch (const std::exception& failure) { error = QString::fromUtf8(failure.what()); }
    result["error"] = error; result["total"] = span(totalStart, stamp());
    QSaveFile output(report); const auto document = QJsonDocument(result).toJson();
    if (!output.open(QIODevice::WriteOnly) || output.write(document) != document.size() || !output.commit()) {
        std::cerr << "Cannot publish microprofile result\n"; return 1;
    }
    std::cout << QJsonDocument(QJsonObject{{"passed", result["passed"]}, {"qualified", false}, {"error", error}, {"result", report}}).toJson(QJsonDocument::Compact).constData() << '\n';
    return result["passed"].toBool() ? 0 : 1;
}
