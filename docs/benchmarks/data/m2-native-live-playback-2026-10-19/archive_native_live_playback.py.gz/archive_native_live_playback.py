#!/usr/bin/env python3
"""Root-run named UTF-8 archive of failed native playback and CPU diagnostics.

Default is a dry plan. This script launches no test, model, audio or UI workload.
"""
import argparse
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
DEST = ROOT / 'docs/benchmarks/data/m2-native-live-playback-2026-10-19'
HEAD = 'd59d6316c7153b7fc6b38bb68b06f90baa157cde'
INITIAL = 'c0639edfc2815a0de1359a62494dd5717cd7dc2b'
REPORTING = 'f18383805de3680ceb72200d2afa2de95bef1210'
SIGNER = 'F621F658D66098CBE9E5C55D66788CCBB5E215AC'
CPP = 'tools/experiments/manual_playback_soak.cpp'
PYTHON = 'tools/experiments/run_manual_playback_soak.py'
CONVERTER = 'src/audio/StemRateConverter.cpp'
INITIAL_CPP = 'd20bba5df58ac5cc63fd7b375977d7bfdda32cdd190b067ccfe659d7e4d40c9e'
FINAL_CPP = 'ed78d0036e0b8413259505e0436b2315fa7c2e32189ec694ca69dabbf680b944'
INITIAL_PYTHON = 'b5850f5106c3155f782adfaf482e5461104df0b29549673ea32a0ded2db21775'
FINAL_PYTHON = 'ae7090fe141d5e61618de5b3c10817c2e43bfa95e287f5c735ddeee8921e6408'
CONVERTER_SHA = '482c55e043847adb75b42bdd25fd8859cd97e106208d46170ba1f84c897f9294'
MANIFEST_SHA = '7e63f60ab47de1754a9563b44f14424ed7a2b461902b359844fd4e76075f7d38'
MANIFEST = BASE / 'archive-native-live-playback-inputs.json'
FREEZE = BASE / 'archive-native-live-playback-freeze.json'
RECIPE = BASE / 'archive-native-live-playback-recipe.md'


def require(value, message):
    if not value:
        raise RuntimeError(message)


def meta(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read(path):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= 64 * 1024 * 1024,
            'Unsafe/oversized named text input: ' + str(path))
    data = path.read_bytes()
    after = path.lstat()
    identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns)
    require(identity(before) == identity(after) and len(data) == before.st_size,
            'Named text input changed: ' + str(path))
    require(b'\0' not in data, 'Binary payload prohibited: ' + str(path))
    data.decode('utf-8')
    return data


def load(path):
    return json.loads(read(path))


def command(argv, timeout=20):
    result = subprocess.run(argv, cwd=ROOT, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    require(result.returncode == 0, 'Read-only metadata command failed: ' + repr(argv))
    return result.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--head')
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({'status': 'dry_plan_only', 'destination': str(DEST),
            'required_head': HEAD, 'scope': 'No input, Git, binary, model or host reads in dry mode'}))
        return 0
    require(args.head == HEAD, 'Exact final signed source --head is required')
    manifest_data = read(MANIFEST)
    require(meta(manifest_data)['sha256'] == MANIFEST_SHA, 'Reviewed named-input manifest changed')
    expected = json.loads(manifest_data)['named_inputs']
    require(len(expected) == 90, 'Named input count differs')
    for name, pin in expected.items():
        relative = Path(name)
        require(not relative.is_absolute() and '..' not in relative.parts and name not in ('', '.'),
                'Unsafe named origin')
        require(meta(read(BASE / name)) == pin, 'Frozen named input changed: ' + name)
    frozen = load(FREEZE)
    for key, path in [('script', Path(__file__).resolve()), ('recipe', RECIPE), ('manifest', MANIFEST)]:
        require(meta(read(path)) == {field: frozen[key][field] for field in ('bytes', 'sha256')},
                'Archiver source/freeze input differs: ' + key)

    signatures = {}
    for revision in (INITIAL, REPORTING, HEAD):
        text = command(['git', 'show', '-s', '--format=%H %G? %GF %ae', revision]).decode().strip()
        require(text.split() == [revision, 'G', SIGNER, 'kyau@kyau.net'], 'Valid exact kyau signature required')
        signatures[revision] = text
    for before, after in ((INITIAL, REPORTING), (REPORTING, HEAD)):
        command(['git', 'merge-base', '--is-ancestor', before, after])
    require(command(['git', 'rev-parse', 'HEAD']).decode().strip() == HEAD, 'Current HEAD differs')
    require(command(['git', 'diff', HEAD, '--', CPP, PYTHON, CONVERTER]) == b'', 'Selected code differs from signed source')
    source_hashes = {(INITIAL, CPP): INITIAL_CPP, (INITIAL, PYTHON): INITIAL_PYTHON,
        (REPORTING, CPP): FINAL_CPP, (REPORTING, PYTHON): INITIAL_PYTHON,
        (HEAD, CPP): FINAL_CPP, (HEAD, PYTHON): FINAL_PYTHON, (HEAD, CONVERTER): CONVERTER_SHA}
    signed_sources = {}
    for (revision, name), digest in source_hashes.items():
        data = command(['git', 'show', revision + ':' + name])
        require(meta(data)['sha256'] == digest, 'Historical signed source hash differs')
        signed_sources[(revision, name)] = data
    for name, digest in ((CPP, FINAL_CPP), (PYTHON, FINAL_PYTHON), (CONVERTER, CONVERTER_SHA)):
        require(meta(read(ROOT / name))['sha256'] == digest, 'Current selected source changed')

    root_report = load(BASE / 'short-live-native-root-report.json')
    require(root_report['source_head'] == HEAD and root_report['milestone'] == 'M2' and
        root_report['m2_open'] is True and root_report['integrated_live_playback_qualified'] is False and
        root_report['actual_run02_passed'] is False and root_report['actual_run02_cleanup_proven'] is False,
        'Root report must preserve M2-open and failed/unproven run02 decisions')
    require(root_report['source_signatures'] == signatures, 'Root report signature provenance differs')

    actual = {}
    for label, revision, cpp_sha, binary_sha, hop_count in [
        ('01', INITIAL, INITIAL_CPP, '86c095c4f8986d155191676959b77d80a5e132fde32f29be1c23c0f4d8983b03', 1),
        ('02', REPORTING, FINAL_CPP, 'b3f7f362c7c6458fe8fe26b2d1b9f4fee0f999a5f9f2af70d985dfe31c5f1446', 18)]:
        directory = BASE / ('short-live-actual-model-' + label)
        result, native = load(directory / 'result.json'), load(directory / 'native-result.json')
        require(result.get('finished_at_utc') and result['passed'] is False and result['qualified'] is False and
            result['native_exit'] == 1 and result['native'] == native and result['pins_unchanged'] is True and
            result['pins_before'] == result['pins_after'] and result['within_wall_budget'] is True and
            result['requested_seconds'] == 120 and native['passed'] is False and native['qualified'] is False,
            'Actual run is not closed with its original failure: ' + label)
        require(result['pins_before']['binary']['sha256'] == binary_sha and
            result['pins_before']['runner']['sha256'] == INITIAL_PYTHON and
            root_report['actual_runs'][label]['source_head'] == revision and
            meta(signed_sources[(revision, CPP)])['sha256'] == cpp_sha, 'Historical per-run source/binary binding differs')
        readiness = load(BASE / ('short-live-actual-model-' + label + '-readiness.json'))
        require(readiness['decision'] == 'ready' and readiness['ready_for_run'] == directory.name and
            all(readiness[key] is True for key in ('AC_power', 'lid_open', 'visible_window', 'screen_awake')),
            'Original human readiness scope differs')
        rows = [json.loads(line) for line in read(directory / 'observations.jsonl').splitlines()]
        records = [row for row in rows if row['type'] == 'record']
        counters = native['observation_counters']
        require([row['ordinal'] for row in records] == list(range(1, len(records) + 1)) and
            counters['attempted'] == counters['retained'] == len(records) and counters['dropped'] == 0 and
            counters['invalid_clock_reads'] == 0 and counters['producer_finished'] is True,
            'Actual native observation population is incomplete')
        chunks = [row for row in records if row['kind'] == 5]
        hops = [row['hop_service_ms'] for row in chunks if row['hop_service_present']]
        require(len(chunks) == len(hops) == hop_count and all(math.isfinite(value) and value >= 0 for value in hops),
            'Actual service-hop population differs')
        summary = result['observations']['service_hops']
        require(summary['count'] == len(hops) and summary['complete'] is True and
            summary['nearest_rank_p99_ms'] == sorted(hops)[math.ceil(.99 * len(hops)) - 1] and
            summary['at_or_above_target'] == sum(value >= 4095 for value in hops) and summary['strict_target_ms'] == 4095,
            'Actual strict target or uncensored population differs')
        cleanup = result['cleanup']
        require(not cleanup['remaining_known_processes'] and cleanup['remaining_pipewire_count'] == 0 and
            not cleanup['remaining_live_jobs'] and all(cleanup['owned_group_absent'].values()) and
            cleanup['cooperative_native_shutdown'] is True and cleanup['leader_reaped'] is True,
            'Known process/graph cleanup evidence differs')
        if label == '01':
            require(native['error'] == 'Live window hidden or not presenting' and native['measured_wall_ms'] == 1712 and
                result['cleanup_proven'] is True, 'Interrupted initial failure differs')
        else:
            require(native['error'] == 'Steady playback starved; control intervals retained separately' and
                native['measured_wall_ms'] >= 120000 and native['steady_starved_frames'] == 11264 and
                native['control_starved_frames'] == 1806336 and native['starved_frames_outside_measured_intervals'] == 2816 and
                native['starved_frames_including_controls'] == 1820416 and native['measurement_intervals_closed'] is True and
                result['cleanup_proven'] is False and result['cache_preserved'] is True and
                cleanup['ownership_complete'] is False and cleanup['engine_processes_observed'] is False,
                'Completed failed playback or unproven cleanup was altered')
        actual[label] = {'source_head': revision, 'binary_sha256': binary_sha, 'passed': False,
            'cleanup_proven': result['cleanup_proven'], 'native_error': native['error'], 'service_hops': summary}

    offline, cli = load(BASE / 'short-live-offline-review-v2-result.json'), load(BASE / 'short-live-cli-result.json')
    require(offline['status'] == 'offline_checks_passed' and offline['check_count'] == 32 and
        cli['passed'] is True and len(cli['cases']) == 10 and all(row['passed'] for row in cli['cases']), 'Initial focused checks failed')
    private = load(BASE / 'short-live-private-01/result.json')
    require(private['passed'] and private['check_exit'] == 0 and private['daemon_reaped'] and
        not private['cleanup']['remaining_nodes_or_links'] and len(private['check']['checks']) == 10,
        'Initial private functional evidence differs')
    for name, exit_code in [('short-live-stop-red-01', 1), ('short-live-stop-green-01', 0), ('short-live-private-reporting-fixed-01', 0)]:
        execution = load(BASE / (name + '.execution.json'))
        require(execution['exit'] == exit_code and execution['timed_out'] is False and execution['pins_unchanged'] is True,
                'Actual reporting RED/GREEN execution differs')
        wrapped = execution['result.json']
        require(wrapped['check_exit'] == exit_code and wrapped['daemon_reaped'] is True and
            not wrapped['cleanup']['remaining_nodes_or_links'], 'Private known graph cleanup failed')
        if name == 'short-live-stop-red-01':
            require('beginning/end output clocks and closed intervals' in wrapped['check']['error'], 'Actual reporting RED differs')
        elif name == 'short-live-stop-green-01':
            stopped = wrapped['check']['observations']['native']
            require(stopped['cancelled'] is True and stopped['passed'] is False and stopped['measurement_intervals_closed'] is True and
                stopped['intervals'][-1]['aborted'] is True and sum(row['frames'] for row in stopped['intervals']) ==
                stopped['measurement_end_output_frame'] - stopped['measurement_begin_output_frame'], 'Actual STOP GREEN coverage differs')
    red, green = load(BASE / 'short-live-ownership-history-red.json'), load(BASE / 'short-live-ownership-history-green.json')
    require(red['status'] == 'offline_checks_failed' and 'same-identity zombie argv' in red['error'] and
        red['source']['sha256'] == INITIAL_PYTHON and green['status'] == 'offline_checks_passed' and
        green['check_count'] == 12 and green['source']['sha256'] == FINAL_PYTHON and
        red['patch_sha256'] == green['patch_sha256'] and not red['native_started'] and not green['native_started'],
        'Actual history RED/GREEN provenance differs')

    series = load(BASE / 'stem-converter-quality-series-01.json')
    require(series['qualified'] is False and series['all_three_completed'] is True and series['pins_unchanged'] is True and
        series['pins_before'] == series['pins_after'] and [row['name'] for row in series['stages']] ==
        ['baseline-before', 'medium', 'baseline-after'], 'Generated converter series is incomplete')
    for stage, name in zip(series['stages'], ['baseline-before', 'medium', 'baseline-after']):
        path = BASE / ('stem-converter-quality-' + name + '-01.json')
        result = load(path)
        require(stage['exit'] == 0 and stage['passed'] is True and stage['result_sha256'] == meta(read(path))['sha256'] and
            result['passed'] is True and result['qualified'] is False and len(result['scenarios']) == 2 and
            result['input_frames44100'] == 1031940 and result['counted_output_frames48000'] == 1123201 and
            all(row['finished_calls'] == 1 for row in result['scenarios']), 'Generated converter geometry/execution differs')
    candidate = load(BASE / 'stem-converter-medium-candidate-freeze.json')
    require(candidate['production_source']['sha256'] == CONVERTER_SHA and
        read(BASE / 'StemRateConverter-medium-candidate.cpp').replace(b'SRC_SINC_MEDIUM_QUALITY', b'SRC_SINC_BEST_QUALITY') ==
        signed_sources[(HEAD, CONVERTER)], 'Local candidate differs beyond frozen quality choice')

    stage, raw = BASE / 'native-live-playback-archive-stage', BASE / 'native-live-playback-archive-raw'
    require(not any(os.path.lexists(path) for path in (DEST, stage, raw)), 'Fresh canonical/staging/raw paths required')
    stage.mkdir(mode=0o700); raw.mkdir(mode=0o700)
    files, origins, uncompressed = {}, {}, {}
    total = 0
    def add(data, name, origin):
        nonlocal total
        require('/' not in name and name not in files and b'\0' not in data, 'Unsafe/duplicate/binary archive payload')
        data.decode('utf-8'); total += len(data)
        require(total <= 128 * 1024 * 1024, 'Named archive exceeds128MiB')
        (raw / name).write_bytes(data)
        packed = gzip.compress(data, mtime=0)
        filename = name + '.gz'; (stage / filename).write_bytes(packed)
        files[filename], uncompressed[filename], origins[filename] = meta(packed), meta(data), origin
    for name in expected:
        add(read(BASE / name), name.replace('/', '--'), {'path': str((BASE / name).relative_to(ROOT)), **expected[name]})
    for path in (Path(__file__).resolve(), MANIFEST, FREEZE, RECIPE):
        data = read(path); add(data, path.name, {'path': str(path.relative_to(ROOT)), **meta(data)})
    for name, archive_name in ((CPP, 'signed-final-manual_playback_soak.cpp'), (PYTHON, 'signed-final-run_manual_playback_soak.py'),
        (CONVERTER, 'signed-product-baseline-StemRateConverter.cpp')):
        data = signed_sources[(HEAD, name)]
        add(data, archive_name, {'git_commit': HEAD, 'git_path': name, **meta(data)})
    scan_log, scan_report = BASE / 'native-live-playback-archive-gitleaks.log', BASE / 'native-live-playback-archive-gitleaks-findings.json'
    require(not os.path.lexists(scan_log) and not os.path.lexists(scan_report), 'Fresh scanner outputs required')
    scanned_bytes = total
    with scan_log.open('xb') as stream:
        scan = subprocess.run(['gitleaks', 'dir', str(raw), '--redact', '--no-color', '--report-format', 'json',
            '--report-path', str(scan_report)], cwd=ROOT, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, timeout=90)
    require(scan.returncode == 0 and load(scan_report) == [], 'Raw secret scan failed; canonical publication prohibited')
    for path in (scan_log, scan_report):
        data = read(path); add(data, path.name, {'path': str(path.relative_to(ROOT)), **meta(data)})
    for name, pin in files.items():
        require(meta((stage / name).read_bytes()) == pin and meta(gzip.decompress((stage / name).read_bytes())) == uncompressed[name],
                'Packed hash/UTF-8 roundtrip failed')
    for origin in origins.values():
        data = command(['git', 'show', origin['git_commit'] + ':' + origin['git_path']]) if 'git_commit' in origin else read(ROOT / origin['path'])
        require(meta(data) == {field: origin[field] for field in ('bytes', 'sha256')}, 'Origin changed during archive')
    require(command(['git', 'rev-parse', 'HEAD']).decode().strip() == HEAD and
        command(['git', 'diff', HEAD, '--', CPP, PYTHON, CONVERTER]) == b'', 'Selected signed source changed during archive')
    verification = {'schema': 'conflux.m2-native-live-playback.v1', 'status': 'failed_native_playback_evidence_preserved',
        'source_head': HEAD, 'source_signatures': signatures, 'm2_open': True, 'integrated_live_playback_qualified': False,
        'actual_runs': actual, 'historical_source_hashes_verified': True,
        'binary_binding_scope': 'Each closed run retains its original binary SHA and source/build provenance. Historical binaries were rebuilt; payloads are excluded and are not rehashed as original executable bytes.',
        'raw_secret_scan_exit': 0, 'raw_scanned_input_bytes': scanned_bytes, 'files': files, 'origins': origins,
        'uncompressed': uncompressed, 'limits': [
            'Run02 failed strict4095ms timing and steady source continuity; all observed hops remain included.',
            'Known groups vanished, but run02 ownership_complete and engine_processes_observed were false; cleanup remains unproven and its cache was preserved.',
            'Post-run synthetic history fix cannot retroactively certify run02.',
            'Run01 was interrupted; original incomplete interval reporting and human explanation are retained.',
            'Private functional checks and generated converter CPU diagnostics do not qualify host latency, musical quality or endurance.',
            'Converter medium-quality candidate is an ignored copy; signed product converter remains unchanged.',
            'No media, models, executable binaries, caches, listening assets or unrelated older benchmark archives are included.',
            'Scan covers named raw inputs before scanner-output and generated-verification packaging; no suppressions.',
            'New PR/CI success is not inferred; root report preserves its pre-PR observation time.']}
    require(len(files) + 1 == 100, 'Unexpected canonical file count')
    (stage / 'verification.json').write_text(json.dumps(verification, indent=2, allow_nan=False) + '\n')
    require(not os.path.lexists(DEST), 'Canonical destination appeared before publication')
    stage.rename(DEST)
    print(json.dumps({'status': verification['status'], 'destination': str(DEST), 'files': len(files) + 1,
        'm2_open': True, 'actual_run02_cleanup_proven': False}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
