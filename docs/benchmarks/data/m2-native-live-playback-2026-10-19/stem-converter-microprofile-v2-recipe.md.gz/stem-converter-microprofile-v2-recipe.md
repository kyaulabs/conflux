# Generated converter microprofile

This ignored standalone source uses the installed Qt Core reporter and the existing `StemRateConverter` object from `libconflux-audio.a`; no permanent target or dependency. Compile only after root review. The flags derive from the existing audio target; only Qt Core and libsamplerate need linking because the static archive selects its converter object.

```sh
conflux_task_root="$PWD"
conflux_task_base="$conflux_task_root/benchmarks-local/m2-live-delivery-2026-10-19"
/bin/c++ -O2 -g -DNDEBUG -std=c++20 -Wall -Wextra -Wpedantic \
  -mno-direct-extern-access -D_REENTRANT -fno-strict-aliasing -fno-strict-overflow \
  -DQT_CORE_LIB -DQT_NO_DEBUG -I"$conflux_task_root/src" \
  $(pkg-config --cflags Qt6Core samplerate) \
  "$conflux_task_base/stem_converter_microprofile_v2.cpp" \
  "$conflux_task_root/build/dev/libconflux-audio.a" \
  $(pkg-config --libs Qt6Core samplerate) -pthread \
  -o "$conflux_task_base/stem-converter-microprofile-v2"
sha256sum "$conflux_task_base/stem_converter_microprofile_v2.cpp" \
  "$conflux_task_base/stem-converter-microprofile-v2" build/dev/libconflux-audio.a \
  src/audio/StemRateConverter.cpp src/audio/StemRateConverter.hpp
# Root-owned fresh result path; preserve even failed runs and capture timeout exit.
timeout --signal=TERM --kill-after=5s 60s \
  "$conflux_task_base/stem-converter-microprofile-v2" \
  "$conflux_task_base/stem-converter-microprofile-v2-01.json"
```

The source generates deterministic bounded float32 stereo PCM for four distinct roles in memory; no user audio is read or written. It counts N=1031940 once, requires the previously observed exact M=1123201 and reuses that immutable plan for cursors0 and280800. Each scenario offers at most4096 input frames and stages4096-frame output packets, retaining final output until actual zero-output EOF proof. It checks contiguous packet/visible/input counts, finite output and exact completion. The seek must anchor at253281; its expected hidden preroll is5120outputframes (32*147rawframes). The public API has no per-step hidden-generation counter; expected geometry is clearly separated from842401observed visible frames and the library's internal finished/discard proof.

CLOCK_MONOTONIC wall and CLOCK_THREAD_CPUTIME_ID measure count, constructors, process envelopes and every converter.process call. The JSON retains raw step rows, per-step nearest-rank summaries, packet preparation clocks, first packet and262144-frame reserve timings and generated/output hashes. Process-call sums exclude reporter/finite-check/hash work; envelope clocks include it. Direct in-memory spans intentionally exclude bridge file reads, lease validation, wire decoding, service/model waits and ring backpressure. Wall minus calling-thread CPU is descriptive, not proof of a particular scheduler or thermal cause.

There are exactly two scenarios. A55-second soft bound is checked between bounded converter calls; the outer60-second timeout with5-second kill escalation supplies the hard root-owned wall budget. No internal watchdog/background thread, sleeps, host audio, UI, model, GPU or service process. This isolates a candidate conversion contribution to the actual player's5.327-second before-ready interval; it is a diagnostic with qualified=false, not an endurance or latency-target pass. Current power conditions may differ from the closed actual-player run. Preserve source, binary/library pins, compile output and closed result; do not overwrite or selectively discard a failure. The draft author has not compiled or executed this source.

This immutable v2 preserves the unexecuted v1 source/recipe/freeze. It removes only the unsupported per-step positive-progress requirement and reports `zero_progress_calls`; exact input/pending buffers remain unchanged on0/0/false. The16384-step/55-second bounds still reject persistent nonprogress, and final input/visible/packet/EOF geometry remains required. Root confirmed v1 had not been compiled or executed when requesting this correction.
