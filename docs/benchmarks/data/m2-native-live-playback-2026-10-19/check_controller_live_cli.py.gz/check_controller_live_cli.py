#!/usr/bin/env python3
"""Temporary isolated CLI check. No LOAD command, model or native inference."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import stat
import subprocess
import tempfile
import time

BASE = Path(__file__).resolve().parent
OUTPUT = BASE / "controller-live-cli"
REPORT = BASE / "controller-live-cli-result.json"
CAP = 65536
STOP = False


def stopping(_signum, _frame):
    global STOP
    STOP = True  # Non-raising, including through Popen publication and cleanup.


def digest(path, deadline):
    value = hashlib.sha256()
    with path.open("rb") as source:
        while block := source.read(65536):
            if time.monotonic() >= deadline or STOP:
                raise RuntimeError("CLI check stopped before pin verification completed")
            value.update(block)
    return value.hexdigest()


def group_exists(group):
    try:
        os.killpg(group, 0)
        return True
    except ProcessLookupError:
        return False


def finish(child):
    result = {"term_sent": False, "kill_sent": False,
              "leader_reaped": False, "process_group_gone": False}
    # Always probe the known new-session group, even after its leader exits.
    for kind, grace in ((signal.SIGTERM, 1.0), (signal.SIGKILL, 2.0)):
        if group_exists(child.pid):
            try:
                os.killpg(child.pid, kind)
                result["term_sent" if kind == signal.SIGTERM else "kill_sent"] = True
            except ProcessLookupError:
                pass
        until = time.monotonic() + grace
        while time.monotonic() < until:
            child.poll()  # Reap the direct leader before probing its group.
            if child.returncode is not None and not group_exists(child.pid):
                break
            time.sleep(.01)
        if child.returncode is not None and not group_exists(child.pid):
            break
    if child.returncode is not None:
        child.wait(timeout=.1)
        result["leader_reaped"] = True
    result["process_group_gone"] = not group_exists(child.pid)
    return result


def collect(selector, buffers, observed, exceeded, timeout):
    for key, _mask in selector.select(timeout):
        name, stream = key.data
        try:
            block = os.read(stream.fileno(), min(4096, CAP - len(buffers[name]) + 1))
        except BlockingIOError:
            continue
        if not block:
            selector.unregister(stream)
            stream.close()
            continue
        observed[name] += len(block)
        remaining = CAP - len(buffers[name])
        buffers[name].extend(block[:remaining])
        if len(block) > remaining:
            exceeded.add(name)
            selector.unregister(stream)
            stream.close()


def run_case(binary, name, suffix, expected_exit, deadline):
    positive = expected_exit is None
    row = {"name": name, "passed": False, "process_started": False,
           "expectation": {"alive_seconds": 1.0} if positive else {"exit": expected_exit},
           "environment_removed": False}
    buffers = {"stdout": bytearray(), "stderr": bytearray()}
    observed = {"stdout": 0, "stderr": 0}
    exceeded = set()
    root = child = selector = None
    started = time.monotonic()
    try:
        if STOP or started >= deadline - 4:
            raise RuntimeError("CLI check cancelled or has no case/cleanup budget")
        root = Path(tempfile.mkdtemp(prefix=name + "-", dir=OUTPUT))
        root.chmod(0o700)
        row["environment_root"] = str(root)
        environment = os.environ.copy()
        for variable, leaf in (("XDG_RUNTIME_DIR", "runtime"), ("XDG_DATA_HOME", "data"),
                               ("XDG_CACHE_HOME", "cache"), ("XDG_CONFIG_HOME", "config")):
            directory = root / leaf
            directory.mkdir(mode=0o700)
            environment[variable] = str(directory)
        environment.update({"QT_QPA_PLATFORM": "offscreen", "QT_QUICK_BACKEND": "software",
            "QSG_RENDER_LOOP": "basic", "PIPEWIRE_RUNTIME_DIR": str(root / "runtime"),
            "PIPEWIRE_REMOTE": "conflux-cli-unavailable",
            "XDG_CONFIG_DIRS": str(root / "no-config-dirs"),
            "DBUS_SESSION_BUS_ADDRESS": "unix:path=" + str(root / "no-session-bus"),
            "DBUS_SYSTEM_BUS_ADDRESS": "unix:path=" + str(root / "no-system-bus")})
        for variable in ("CONFLUX_M0_REPAINT_MS", "PIPEWIRE_PROPS", "PIPEWIRE_NO_CONFIG",
                         "PIPEWIRE_CONFIG_DIR", "PIPEWIRE_CONFIG_NAME", "PIPEWIRE_CONFIG_PREFIX"):
            environment.pop(variable, None)
        assets = root / "dummy assets"  # Deliberately absent, never executable.
        five = [value for flag, leaf in (("python", "python"), ("exporter", "export.py"),
                ("worker", "worker.py"), ("runtime", "runtime"), ("model", "model.gguf"))
                for value in ("--stem-" + flag, str(assets / leaf))]
        service = ["--stem-service", str(assets / "service.py")]
        argv = [str(binary), *suffix(five, service)]
        row["argv"] = argv
        child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, env=environment, start_new_session=True)
        spawned = time.monotonic()
        row.update(process_started=True, owned_process_group=child.pid,
                   process_spawned_monotonic=spawned)
        selector = selectors.DefaultSelector()
        for name_, stream in (("stdout", child.stdout), ("stderr", child.stderr)):
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, (name_, stream))
        until = min(spawned + (1.0 if positive else 5.0), deadline - 3)
        while time.monotonic() < until:
            if STOP:
                raise RuntimeError("CLI check interrupted")
            collect(selector, buffers, observed, exceeded, min(.025, max(0, until - time.monotonic())))
            if exceeded:
                raise RuntimeError("CLI output exceeded its per-stream byte cap")
            if child.poll() is not None:
                break
        row["observed_exit_before_stop"] = child.poll()
        row["observed_seconds"] = time.monotonic() - spawned
        row["passed"] = (row["observed_exit_before_stop"] is None and row["observed_seconds"] >= 1.0
                         if positive else row["observed_exit_before_stop"] == expected_exit)
        if not row["passed"]:
            row["error"] = "Did not satisfy the requested CLI exit/liveness contract"
    except BaseException as error:
        row["error"] = type(error).__name__ + ": " + str(error)
        row["passed"] = False
    finally:
        if child is not None:
            try:
                row["cleanup"] = finish(child)
            except BaseException as error:
                row["cleanup"] = {"leader_reaped": False, "process_group_gone": False,
                                  "error": type(error).__name__ + ": " + str(error)}
            if selector is not None:
                try:
                    end = time.monotonic() + .25
                    while selector.get_map() and time.monotonic() < end:
                        collect(selector, buffers, observed, exceeded, .01)
                except (OSError, ValueError) as error:
                    row["capture_error"] = str(error)
                finally:
                    selector.close()
            for stream in (child.stdout, child.stderr):
                if stream is not None:
                    stream.close()
        else:
            row["cleanup"] = {"leader_reaped": True, "process_group_gone": True,
                              "scope": "No successfully published child"}
        clean = row["cleanup"]["leader_reaped"] and row["cleanup"]["process_group_gone"]
        if clean:
            try:
                if root is not None:
                    shutil.rmtree(root)
                row["environment_removed"] = True
            except OSError as error:
                row["capture_error"] = "Environment cleanup: " + str(error)
        row["output_limit_exceeded"] = sorted(exceeded)
        for name_ in buffers:
            path = OUTPUT / (name + "." + name_ + ".txt")
            path.write_bytes(buffers[name_])
            row[name_] = {"path": path.name, "bytes_retained": len(buffers[name_]),
                          "bytes_observed_lower_bound": observed[name_], "limit_bytes": CAP,
                          "sha256": hashlib.sha256(buffers[name_]).hexdigest()}
        row["passed"] = row["passed"] and clean and not exceeded and "capture_error" not in row
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path, help="absolute path to the built CONFLUX application")
    args = parser.parse_args()
    if not args.binary.is_absolute():
        parser.error("binary must be absolute")
    binary = args.binary.resolve(strict=True)
    info = binary.stat()
    if not stat.S_ISREG(info.st_mode) or not 0 < info.st_size <= 512 * 1024 * 1024 or not os.access(binary, os.X_OK):
        parser.error("binary must be a bounded executable regular file")
    if os.path.lexists(REPORT) or os.path.lexists(REPORT.with_suffix(".json.tmp")):
        parser.error("CLI result path must be fresh")
    OUTPUT.mkdir(mode=0o700, exist_ok=False)
    previous = {kind: signal.signal(kind, stopping) for kind in (signal.SIGINT, signal.SIGTERM)}
    deadline = time.monotonic() + 90
    result = {"schema": 1, "status": "incomplete", "passed": False, "binary": str(binary),
        "cases": [], "cleanup_complete": False,
        "scope": "CLI parsing/liveness only; offscreen isolated unavailable PipeWire/DBus, no LOAD, native/model inference or playback",
        "case_work_budget_seconds": 90, "cleanup_allowance_seconds_per_case": 3,
        "nul_argv": {"application_case_executed": False,
                     "reason": "OS argv cannot represent an embedded NUL; no synthetic application pass"}}
    try:
        before = digest(binary, deadline)
        result["binary_sha256_before"] = before
        source = BASE.parent.parent / "src/main.cpp"
        if not 0 < source.stat().st_size <= 256 * 1024:
            raise RuntimeError("CLI source guard input is unexpectedly sized")
        source_bytes = source.read_bytes()
        guard = b"service.contains(QChar(u'\\0'))" in source_bytes
        result["nul_argv"]["source_review"] = {"path": "src/main.cpp", "guard_present": guard,
            "source_sha256": hashlib.sha256(source_bytes).hexdigest(), "scope": "Source guard only, not an executed NUL argument"}
        cases = [
            ("service-alone", lambda f, s: s, 2),
            ("incomplete-five", lambda f, s: f[:-2] + s, 2),
            ("relative-service", lambda f, s: f + ["--stem-service", "relative/service.py"], 2),
            ("empty-service", lambda f, s: f + ["--stem-service", ""], 2),
            ("missing-service-value", lambda f, s: f + ["--stem-service"], 1),
            ("service-with-smoke", lambda f, s: f + s + ["--smoke-test"], 2),
            ("invalid-backend", lambda f, s: f + s + ["--stem-backend", "invalid"], 2),
            ("absolute-service", lambda f, s: f + s, None),
            ("five-only", lambda f, s: f, None),
        ]
        for name, suffix, expected_exit in cases:
            row = run_case(binary, name, suffix, expected_exit, deadline)
            result["cases"].append(row)
            if STOP or not row["cleanup"]["process_group_gone"] or not row["cleanup"]["leader_reaped"]:
                break
        result["binary_sha256_after"] = digest(binary, deadline)
        result["pins_unchanged"] = result["binary_sha256_after"] == before
        result["cleanup_complete"] = all(row["cleanup"]["leader_reaped"] and row["cleanup"]["process_group_gone"]
                                         and row["environment_removed"] for row in result["cases"])
        result["passed"] = (len(result["cases"]) == len(cases) and guard and result["pins_unchanged"]
                            and result["cleanup_complete"] and all(row["passed"] for row in result["cases"]))
        result["status"] = "passed" if result["passed"] else "cancelled" if STOP else "failed"
    except BaseException as error:
        result.update(status="cancelled" if STOP else "incomplete", error=type(error).__name__ + ": " + str(error))
    finally:
        try:
            temporary = REPORT.with_suffix(".json.tmp")
            temporary.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
            os.replace(temporary, REPORT)
        finally:
            for kind, handler in previous.items():
                signal.signal(kind, handler)
    print(json.dumps({"status": result["status"], "cases": len(result["cases"]),
                      "result": str(REPORT)}, allow_nan=False))
    return 0 if result["passed"] else 130 if STOP else 1


if __name__ == "__main__":
    raise SystemExit(main())
