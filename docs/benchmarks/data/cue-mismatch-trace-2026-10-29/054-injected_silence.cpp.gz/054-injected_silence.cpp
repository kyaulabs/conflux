#define main preparation_full_main
#include "/home/kyau/projects/kyaulabs/conflux/build/m2-eq-cue-followup-01/injected-silence-source.cpp"
#undef main

int main(int argc, char** argv)
{
    QJsonArray checks, rounds;
    QJsonObject observations;
    bool passed = false;
    QString error;
    auto require = [&](bool condition, const char* message) {
        if (!condition) throw std::runtime_error(message);
        checks.append(message);
    };
    try {
        require(argc >= 3, "Private runtime and empty recording directory are required");
        const std::filesystem::path runtime(argv[1]), output(argv[2]);
        validatePrivate(runtime, output);
        const rlimit noCore{0, 0};
        require(::setrlimit(RLIMIT_CORE, &noCore) == 0, "Private failures cannot create a core dump");
        require(qputenv("XDG_CACHE_HOME", QByteArray::fromStdString((runtime / "cache").string())) &&
                qputenv("XDG_DATA_HOME", QByteArray::fromStdString((runtime / "data").string())),
                "Cache and persistent library data remain private");
        QCoreApplication app(argc, argv);
        app.setOrganizationName("CONFLUX");
        app.setApplicationName("eq-cue-boundary-check");
        QTemporaryDir fixtures(QString::fromStdString((runtime / "eq-fixtures-XXXXXX").string()));
        require(fixtures.isValid(), "Generated fixtures have a temporary owner");
        const auto a = fixtures.filePath("generated-a.wav"), b = fixtures.filePath("generated-b.wav");
        writeFixture(a, 4096, -2048);
        writeFixture(b, 2048, 3072);
        pw_init(nullptr, nullptr);
        const auto deadline = Clock::now() + std::chrono::seconds(180);
        for (int round = 0; round < 20; ++round) {
            require(Clock::now() < deadline, "Original EQ-only diagnostic budget exhausted");
            const auto path = output / ("round-" + std::to_string(round));
            require(std::filesystem::create_directory(path), "Each EQ round has a fresh output directory");
            runEqController(path, a, b, require, observations);
            rounds.append(QString::fromStdString(path.string()));
            require(save(QString::fromStdString((output / "progress.json").string()),
                         {{"completed_rounds", rounds}}), "Completed rounds are retained");
        }
        passed = true;
    } catch (const std::exception& failure) {
        error = QString::fromUtf8(failure.what());
    }
    const QJsonObject report{{"passed", passed}, {"error", error}, {"checks", checks},
        {"completed_rounds", rounds}, {"observations", observations}, {"execution_deadline_gate", false},
        {"scope", "Bounded repeated generated EQ/cue routing-rebuild diagnostic; no model, GPU, physical audio or latency qualification."}};
    std::cout << QJsonDocument(report).toJson(QJsonDocument::Compact).constData() << '\n';
    return passed ? 0 : 1;
}
