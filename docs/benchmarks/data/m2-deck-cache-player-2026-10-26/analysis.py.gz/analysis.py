"""Retain failed comparison verdicts and independently check service/audio data."""
from array import array
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import resource
import statistics
import struct
import sys

resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
resource.setrlimit(resource.RLIMIT_CPU, (35, 40))
BASE = Path(__file__).resolve().parent / 'comparison-03'
PHASES = ('source_read_ms', 'request_ms', 'overlap_ms', 'native_elapsed_ms',
          'native_inference_wall_ms', 'native_inference_cpu_ms', 'native_frontend_ms',
          'native_graph_ms', 'native_graph_upload_ms', 'native_graph_compute_ms',
          'native_graph_readback_ms', 'native_postprocess_ms', 'native_graph_rebuild_ms')


def read(path):
    return json.loads(path.read_text())


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def scan_wave(path, native):
    wav = path.read_bytes()
    assert wav[:4] == b'RIFF' and wav[8:12] == b'WAVE'
    assert int.from_bytes(wav[4:8], 'little') + 8 == len(wav)
    offset, data, fmt = 12, None, None
    while offset + 8 <= len(wav):
        kind, size = wav[offset:offset+4], int.from_bytes(wav[offset+4:offset+8], 'little')
        start = offset + 8
        assert start + size <= len(wav)
        if kind == b'fmt ': fmt = struct.unpack_from('<HHIIHH', wav, start)
        if kind == b'data':
            assert data is None
            data = wav[start:start+size]
        offset = start + size + (size & 1)
    assert offset == len(wav) and fmt[0:3] == (3, 2, 48000) and fmt[5] == 32
    assert data is not None and len(data) % 8 == 0
    samples = array('f'); samples.frombytes(data)
    if sys.byteorder != 'little': samples.byteswap()
    assert all(math.isfinite(x) for x in samples)
    frames, nonzero = len(samples)//2, sum(x != 0 for x in samples)
    peaks = [max(map(abs, samples[c::2]), default=0) for c in (0, 1)]
    expected, writer = native['recorded_audio'], native['recording']
    assert frames == expected['frames'] == writer['acceptedFrames'] == writer['writtenFrames']
    assert nonzero == expected['nonzero_samples']
    assert peaks == [expected['peak_left'], expected['peak_right']]
    assert writer['overflowFrames'] == 0 and writer['status'] == 'Complete' and writer['error'] == ''
    return dict(path=str(path), bytes=len(wav), sha256=hashlib.sha256(wav).hexdigest(),
                frames=frames, samples=len(samples), sample_rate=48000, channels=2,
                all_samples_finite=True, nonzero_samples=nonzero, peaks=peaks,
                matches_native_counts_and_peaks=True, recording_overflow_frames=0)


def summarize_threads(host):
    threads, batches, costs = {}, [], []
    for observation in host:
        trace = observation['process_cpu_read_only']; hz = trace['ticks_per_second']
        costs.append(trace['scan_thread_cpu_ns'])
        for batch in trace['native_thread_cpu']:
            batches.append(batch)
            for row in batch['threads']:
                key = (batch['pid'], batch['process_start_ticks'], row['pid'], row['start_ticks'])
                item = threads.setdefault(key, dict(process_pid=batch['pid'], tid=row['pid'],
                    process_start_ticks=batch['process_start_ticks'], thread_start_ticks=row['start_ticks'],
                    comm=row['comm'], main_thread=row['pid'] == batch['pid'],
                    first_ticks=row['cpu_ticks'], first_ns=row['observed_monotonic_ns'],
                    ticks_per_second=hz, samples=0))
                assert item['ticks_per_second'] == hz and row['cpu_ticks'] >= item['first_ticks']
                item.update(last_ticks=row['cpu_ticks'], last_ns=row['observed_monotonic_ns'], samples=item['samples']+1)
    for row in threads.values():
        row['observed_span_cpu_seconds'] = (row['last_ticks']-row['first_ticks'])/row['ticks_per_second']
        row['observed_span_wall_seconds'] = (row['last_ns']-row['first_ns'])/1e9
    return dict(native_thread_capture_batches=len(batches), complete_batches=sum(b['complete'] for b in batches),
                capture_errors=sum(len(b['errors']) for b in batches),
                scope='Per-lifetime sampled CPU deltas. Spans differ and exclude boundary CPU; names do not identify pooled functions or prove causality.',
                threads_by_observed_span_cpu=sorted(threads.values(), key=lambda r:r['observed_span_cpu_seconds'], reverse=True),
                observer_thread_cpu_seconds=sum(costs)/1e9,
                observer_mean_thread_cpu_ms=statistics.mean(costs)/1e6,
                observer_maximum_thread_cpu_ms=max(costs)/1e6)


summary = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(), qualified=False,
               strict_service_target_ms=4095, order=['baseline', 'candidate'],
               scope='One fixed-order, two-minute run per arm. Each original ordinary assessment is retained; no causal speedup, sustained, musical or physical-output-latency qualification.',
               UI_profiler_enabled=False, power_ceiling_W=15, guard_unchanged=True, arms={})
for arm in summary['order']:
    directory = BASE/'cases'/arm
    result = read(directory/'output-01/result.json'); native = result['native']
    assessment = read(directory/'diagnostic-assessment.json'); closure = read(directory/'root-finished-01.json')
    assert closure['cleanup_complete'] and native['shutdown_completed']
    if closure['requested120s_complete'] is not True:
        assert assessment['diagnostic_complete'] is False
        assert result['cleanup_proven'] is False
        assert result['cleanup']['ownership_complete'] is False
        assert closure['original_public_ownership_complete'] is False
    observations = result['observations']; metrics = observations['service_hops']
    hops = observations['chunk_phases']['hops']; fields = observations['chunk_phases']['fields']
    assert metrics['complete'] and observations['service_metrics_complete']
    assert len(hops) == metrics['count'] == observations['kind_counts']['ChunkValidated']
    assert set(fields) == set(PHASES)
    assert all(fields[k]['count'] == len(hops) and fields[k]['present_for_all_chunks'] for k in PHASES)
    assert all(type(row[k]) in (int,float) and math.isfinite(row[k]) and row[k] >= 0 for row in hops for k in PHASES)
    loss = observations['service_telemetry_loss']
    assert loss[-1]['kind'] == 'ServiceClosed' and all(row['dropped'] == 0 for row in loss)
    times = sorted(row['hop_service_ms'] for row in hops)
    assert all(math.isfinite(x) and x >= 0 for x in times)
    p99 = times[math.ceil(.99*len(times))-1]
    assert p99 == metrics['nearest_rank_p99_ms'] == assessment['ordinary_assessment']['nearest_rank_p99_ms']
    assert sum(x >= 4095 for x in times) == metrics['at_or_above_target']
    assert native['measurement_intervals_closed'] and native['last_recovery_complete']
    assert 120000 <= native['measured_wall_ms'] <= 122000
    wave = scan_wave(directory/'output-01/master.wav', native)
    controls = [dict(kind=r['kind'], previous_generation=r['previous_generation'],
                     issued_ns=r['issued_ns'], recovered_cursor_observed_ns=r.get('recovered_cursor_observed_ns'),
                     recovered=r.get('recovered_cursor_observed_ns') is not None,
                     poll_observed_recovery_upper_seconds=(r['recovered_cursor_observed_ns']-r['issued_ns'])/1e9
                         if r.get('recovered_cursor_observed_ns') is not None else None) for r in native['controls']]
    audio = dict(schema=1, qualified=False, cache_arm=arm,
                 original_ordinary_assessment=assessment['ordinary_assessment'],
                 original_diagnostic_complete=assessment['diagnostic_complete'],
                 original_public_cleanup_proven=result['cleanup_proven'],
                 original_public_ownership_complete=result['cleanup']['ownership_complete'],
                 original_public_ownership_failures=result['cleanup']['ownership_failures'],
                 physical_cleanup_independently_verified=closure['cleanup_complete'],
                 native_120s_measurement_complete=True,
                 source_head=read(directory/'plan.json')['source_head'],
                 complete_service_population=True, all13_service_fields_complete=True,
                 hop_count=len(hops), median_ms=statistics.median(times), nearest_rank_p99_ms=p99,
                 maximum_ms=max(times), at_or_above_4095_ms=sum(x >= 4095 for x in times),
                 measured_wall_ms=native['measured_wall_ms'], native_error=native['error'], wrapper_error=result.get('error'),
                 steady_starved_frames=native['steady_starved_frames'], steady_starved_seconds=native['steady_starved_frames']/48000,
                 control_starved_frames=native['control_starved_frames'], control_starved_seconds=native['control_starved_frames']/48000,
                 peer_starved_frames=sum(row['starved_b'] for row in native['intervals']),
                 cancellation_scope='Generation invalidation and recovery evidence only; executing GPU request may finish then be discarded. No hard GPU preemption claim.',
                 control_recoveries=controls, manual_controls=len(native['manual_controls']),
                 manual_acknowledgements=sum(r['acknowledged'] for r in native['manual_controls']),
                 manual_controls_complete=native['manual_controls_complete'],
                 callback_execution_deadline_misses=native['execution_deadline_misses'], invalid_buffers=native['invalid_buffers'],
                 rejected_commands=native['rejected_commands'], source_read_failures=native['source_read_failures'],
                 driver_timing=native['timing'], UI=native['ui_coverage'], WAV=wave,
                 diagnostic_tail=native['diagnostic_tail'], thermal_summary=result['thermal_summary'])
    host = [json.loads(line) for line in (directory/'output-01/host-observations.jsonl').read_text().splitlines()]
    cpu = summarize_threads(host)
    cpu['guard_messages'] = [r['MESSAGE'] for r in read(directory/'root-guard-journal-01.json')['records']]
    save(directory/'root-audio-results-01.json', audio)
    save(directory/'root-thread-cpu-analysis-01.json', cpu)
    summary['arms'][arm] = dict(**{k:audio[k] for k in ('hop_count','median_ms','nearest_rank_p99_ms','at_or_above_4095_ms',
        'steady_starved_seconds','control_starved_seconds','peer_starved_frames','control_recoveries','manual_acknowledgements','UI','WAV')},
        original_diagnostic_complete=assessment['diagnostic_complete'],
        original_public_cleanup_proven=result['cleanup_proven'],
        original_public_ownership_complete=result['cleanup']['ownership_complete'],
        original_public_ownership_failures=result['cleanup']['ownership_failures'],
        physical_cleanup_independently_verified=closure['cleanup_complete'],
        main_thread=[r for r in cpu['threads_by_observed_span_cpu'] if r['main_thread']],
        top_threads=cpu['threads_by_observed_span_cpu'][:5], guard_messages=cpu['guard_messages'],
        thermal_summary=audio['thermal_summary'],
        inputs=[pin(directory/name) for name in ('output-01/result.json','diagnostic-assessment.json','root-finished-01.json',
            'root-audio-results-01.json','root-thread-cpu-analysis-01.json')])
    print(json.dumps(dict(arm=arm, p99_ms=p99, hops=len(hops), late_hops=audio['at_or_above_4095_ms'],
        steady_starved_seconds=audio['steady_starved_seconds'], control_starved_seconds=audio['control_starved_seconds'],
        manual_acknowledgements=audio['manual_acknowledgements'], WAV_frames=wave['frames'], all_samples_finite=True,
        UI_healthy=audio['UI']['visible_healthy_checks'], main_thread=summary['arms'][arm]['main_thread'])))
save(BASE/'root-comparison-results-01.json', summary)
