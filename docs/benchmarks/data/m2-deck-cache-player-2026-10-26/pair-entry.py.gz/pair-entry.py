"""Dispatch one fixed comparison arm; dry by default, preserving one pair clock."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

ENTRY_MONOTONIC = time.monotonic()
ENTRY_UTC = datetime.now(timezone.utc).isoformat()
BASE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def pin(row):
    path = Path(row['path'])
    assert path.resolve(strict=True) == path and path.is_file()
    assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], str(path)


def show(unit):
    result = subprocess.run(['systemctl', '--user', 'show', unit,
        '--property=LoadState,ActiveState,SubState,InvocationID,MainPID,Result,ExecMainStatus,ControlGroup'],
        capture_output=True, text=True, timeout=5)
    return dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--arm', choices=('baseline', 'candidate'), required=True)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--question-item-id')
    parser.add_argument('--human-reply')
    args = parser.parse_args()
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    directory = BASE / 'cases' / args.arm
    assert not any((directory / name).exists() for name in
                   ('readiness.json', 'output-01', 'root-unit-dispatch-01.json', 'dispatch-01.json'))
    assert shutil.disk_usage(BASE).free >= 2 * 1024**3, 'Need2GiB free for both short runs'
    launch_path, clearance_path = (directory / name for name in
                                   ('root-launch-plan-01.json', 'root-launch-clearance-01.json'))
    launch, clearance = read(launch_path), read(clearance_path)
    for row in (clearance['launch_plan'], clearance['packet_review'], clearance['case_plan'],
                clearance['root_dispatch_script'], clearance['human_readiness_template'],
                clearance['publication_complete'], launch['prior_run_cleanup']):
        pin(row)
    published = read(Path(clearance['publication_complete']['path']))
    assert published['all9_push_PR_postmerge_jobs_passed'] is True
    assert published['source'] == launch['source_head']
    assert clearance['source_publication_complete'] is True
    assert read(Path(launch['prior_run_cleanup']['path']))['cleanup_complete'] is True
    plan = read(directory / 'plan.json')
    assert plan['status'] == 'frozen_pending_fresh_readiness'
    assert plan['source_head'] == launch['source_head'] and plan['operator_seconds'] == 1200
    assert clearance['case_plan'] == launch['plan']
    work = Path(plan['source_root'])
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip()
    assert head == launch['source_head']
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=work, text=True) == ''
    before, guard = show(launch['unit']), show('thermal-guard.service')
    assert before['LoadState'] == 'not-found' and before['MainPID'] == '0'
    assert guard['ActiveState'] == 'active' and guard['SubState'] == 'running'
    elapsed = time.monotonic() - ENTRY_MONOTONIC
    assert elapsed <= 20, 'Entry exceeded20s; no clock renewal or dispatch permitted'
    if not args.run:
        assert args.question_item_id is None and args.human_reply is None
        name = next(f'root-single-step-entry-check-{index:02d}.json' for index in range(1, 100)
                    if not (directory / f'root-single-step-entry-check-{index:02d}.json').exists())
        save(directory / name, dict(schema=1, passed=True, elapsed_seconds=elapsed,
            maximum_pre_dispatch_seconds=20, native_started=False, readiness_created=False,
            source_head=head, unit_before=before))
        print(json.dumps(dict(status='verified_unarmed', arm=args.arm, entry_seconds=elapsed)))
        return
    original_path = BASE / 'pair-readiness-received-01.json'
    if args.arm == 'baseline':
        assert not original_path.exists()
        assert type(args.human_reply) is str and 0 < len(args.human_reply) <= 8192
        item = json.loads(args.question_item_id)
        assert len(item) == 3 and item[0] == 'request_user_input_async' and item[2] == 0
        original = dict(schema=1, original_readiness_utc=ENTRY_UTC,
            original_readiness_monotonic=ENTRY_MONOTONIC,
            operator_deadline_monotonic=ENTRY_MONOTONIC + 1200,
            operator_seconds=1200, question_item_id=args.question_item_id,
            human_reply=args.human_reply, order=['baseline', 'candidate'], retries=False)
        save(original_path, original)
    else:
        assert args.question_item_id is None and args.human_reply is None, 'Reuse the original pair record only'
        original = read(original_path)
        assert original['operator_seconds'] == 1200 and original['order'] == ['baseline', 'candidate']
        assert original['operator_deadline_monotonic'] == original['original_readiness_monotonic'] + 1200
        first = BASE / 'cases/baseline'
        closed = read(first / 'root-finished-01.json')
        assert closed['cleanup_complete'] is True and closed['requested120s_complete'] is True
        assert closed['operator_deadline_monotonic'] == original['operator_deadline_monotonic']
        assert read(first / 'diagnostic-assessment.json')['diagnostic_complete'] is True
        assert original['operator_deadline_monotonic'] - time.monotonic() >= 600, 'Insufficient original pair room; no retry'
    # Both arms use the first reply's UTC and monotonic origins. The second
    # arm receives no new condition timestamp or renewed operator budget.
    assert original['operator_deadline_monotonic'] - time.monotonic() >= 600
    human = read(directory / 'root-human-readiness-template-01.json')
    human.update(recorded_at_utc=original['original_readiness_utc'],
        recorded_at_monotonic=original['original_readiness_monotonic'],
        human_reply=original['human_reply'], question_item_id=original['question_item_id'])
    save(directory / 'readiness.json', human)
    dispatch = dict(schema=1, arm=args.arm,
        original_readiness_utc=original['original_readiness_utc'],
        original_readiness_monotonic=original['original_readiness_monotonic'],
        operator_deadline_monotonic=original['operator_deadline_monotonic'],
        original_operator_seconds=1200, pair_readiness_sha256=digest(original_path),
        launch_plan_sha256=digest(launch_path), launch_clearance_sha256=digest(clearance_path),
        case_plan_sha256=clearance['case_plan']['sha256'],
        unit=launch['unit'], command=launch['command'], unit_before=before,
        guard_before=guard, worktree_head_at_dispatch=head,
        automatic_retries=False, prior_run_cleanup=launch['prior_run_cleanup'],
        pre_dispatch_elapsed_seconds=time.monotonic() - ENTRY_MONOTONIC,
        original_operator_elapsed_seconds=time.monotonic() - original['original_readiness_monotonic'],
        idle_registration_reserve_seconds=8, entry_maximum_seconds=20)
    assert dispatch['pre_dispatch_elapsed_seconds'] <= 20
    result = subprocess.run(launch['command'], text=True, capture_output=True, timeout=10)
    after = show(launch['unit'])
    dispatch.update(launch_returncode=result.returncode, launch_stdout=result.stdout,
        launch_stderr=result.stderr, unit_after_launch=after,
        original_owned_cgroup=after.get('ControlGroup', ''))
    if int(after.get('MainPID', '0')):
        pid = int(after['MainPID'])
        fields = Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()
        dispatch['owner_identity'] = dict(pid=pid, start_ticks=int(fields[19]),
            group=int(fields[2]), session=int(fields[3]), ppid=int(fields[1]))
    save(directory / 'root-unit-dispatch-01.json', dispatch)
    assert result.returncode == 0 and after['ActiveState'] == 'active'
    assert dispatch['original_owned_cgroup'] and dispatch.get('owner_identity')
    print(json.dumps(dict(status='launched_once', arm=args.arm, unit=launch['unit'],
        original_operator_elapsed_seconds=time.monotonic() - original['original_readiness_monotonic'],
        owner=dispatch['owner_identity'])))


if __name__ == '__main__':
    main()
