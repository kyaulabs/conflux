#!/usr/bin/python3.14 -I
"""Dry by default; fixed whole-command owner for the private actual-player diagnostic.

Ownership walk/signalling follows retained run_drm_player.py; no name-based kill.
Only --run reads frozen inputs, /proc, starts or signals an owned process.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
LAUNCHER = BASE/'run_host_player.py'
LAUNCHER_SHA = '01d7766e58f8a5247c95eaf47d5c142cc4be43b3d7adbfb31eaef5427388e6d3'
TERM_AT, KILL_AT, MAXIMUM = 525, 537, 540
STREAM_LIMIT = 256*1024
LIVE_LIMIT, HISTORY_LIMIT, HISTORY_BYTES = 64, 768, 2*1024*1024


def require(ok, message):
    if not ok: raise ValueError(message)


def load_driver():
    # Verify before importing; its module body is stdlib/constants only.
    require(LAUNCHER.resolve(strict=True) == LAUNCHER and LAUNCHER.is_file() and
            0 < LAUNCHER.stat().st_size <= 256*1024, 'Fixed launcher type/size differs')
    raw = LAUNCHER.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == LAUNCHER_SHA, 'Frozen launcher differs')
    spec = importlib.util.spec_from_file_location('host_pcm_owned_driver', LAUNCHER)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    exec(compile(raw,str(LAUNCHER),'exec'),module.__dict__)
    return module


def process_record(pid):
    root = Path('/proc')/str(pid)
    require(pid > 1 and root.stat().st_uid == os.getuid(), 'Owned PID/user differs')
    raw = (root/'stat').read_bytes()
    require(len(raw) <= 16384, 'Owned stat exceeds bound')
    fields = raw.rsplit(b')',1)[1].split()
    command = (root/'cmdline').read_bytes()
    require(len(command) <= 16384, 'Owned command exceeds bound')
    return {'pid':pid,'start_ticks':int(fields[19]),'group':int(fields[2]),'session':int(fields[3]),
            'ppid':int(fields[1]),'command':[v.decode(errors='replace') for v in command.split(b'\0') if v]}


def verify_idle_inhibition(driver,plan,deadline):
    started=time.monotonic();limit=min(deadline,started+8)
    binary=Path('/usr/bin/busctl')
    driver.pin_read(binary,plan['helpers']['native_profile_binary'],deadline=limit)
    command=[str(binary),'--user','--timeout=2s','--json=short','call',
        'org.kde.Solid.PowerManagement.PolicyAgent','/org/kde/Solid/PowerManagement/PolicyAgent',
        'org.kde.Solid.PowerManagement.PolicyAgent','ListInhibitions']
    reason=str(Path(__file__).resolve())
    # PowerDevil 6.8.1 schedules inhibition enforcement five seconds later.
    # Wait within this one original bound; a malformed/failed query is fatal.
    for attempt in range(1,9):
        remaining=limit-time.monotonic()
        require(remaining>0,'Idle-inhibition verification deadline exhausted')
        result=subprocess.run(command,capture_output=True,check=True,timeout=min(2,remaining))
        require(len(result.stdout)<=65536 and len(result.stderr)<=16384,'Idle-inhibition response exceeds bound')
        value=driver.decode(result.stdout)
        require(type(value) is dict and set(value)=={'type','data'} and value['type']=='aas'
            and type(value['data']) is list and len(value['data'])==1 and type(value['data'][0]) is list,
            'KDE idle-inhibition response shape differs')
        rows=value['data'][0]
        require(len(rows)<=1024 and all(type(row) is list and len(row)==2 and
            all(type(item) is str and len(item)<=8192 for item in row) for row in rows),
            'KDE idle-inhibition entries malformed')
        matched=sum(row[1]==reason for row in rows)
        if matched:
            require(time.monotonic()<limit,'Idle-inhibition verification deadline exhausted')
            return {'reason':reason,'matching_entries':matched,'native_command':command,
                'started_monotonic':started,'sampled_monotonic':time.monotonic(),
                'maximum_wait_seconds':8,'attempts':attempt,'other_application_details_retained':False}
        time.sleep(max(0,min(1,limit-time.monotonic())))
    raise ValueError('Scoped KDE idle inhibition absent within original8s; no player may start')


def same_identity(first, second):
    return all(first[k] == second[k] for k in ('pid','start_ticks','group','session'))


def identity_failure(failures, expected, error):
    value = {'phase':'owned_identity_observation','pid':expected.get('pid'),
             'start_ticks':expected.get('start_ticks'),'message':str(error)[:1024]}
    if len(failures) < 64 and value not in failures: failures.append(value)


def live_owned(owned, failures):
    matches = {}
    for key, expected in owned.items():
        try:
            if same_identity(process_record(expected['pid']),expected): matches[key] = expected
        except (FileNotFoundError,ProcessLookupError): pass
        except Exception as error: identity_failure(failures,expected,error)
    return matches


def children_of(pid):
    tasks = list((Path('/proc')/str(pid)/'task').iterdir())
    require(len(tasks) <= 256, 'Owned process exceeds256threads')
    children = set()
    for task in tasks:
        try:
            raw = (task/'children').read_text()
            require(len(raw) <= 16384, 'Owned children exceeds bound')
            children.update(int(v) for v in raw.split())
        except (FileNotFoundError,ProcessLookupError): pass
    return children


def require_live_capacity(owned, deadline):
    # Historical helpers are retained for lineage, not counted as still live.
    # Only definite exit or a different lifetime frees a live slot.
    count = 0
    for expected in owned.values():
        require(time.monotonic() < deadline, 'Owner observation deadline exhausted')
        try: current = process_record(expected['pid'])
        except (FileNotFoundError,ProcessLookupError): continue
        if current['start_ticks'] != expected['start_ticks']: continue
        require(same_identity(current,expected), 'Owned lifetime group/session changed')
        count += 1
        require(count < LIVE_LIMIT, 'Owned live history exceeds64')


def remember_owned(child, root_identity, owned, groups, deadline):
    """Adopt only current descendants while each exact parent identity lives."""
    pending, visited = [(child.pid,None)], set()
    while pending:
        require(time.monotonic() < deadline, 'Owner observation deadline exhausted')
        pid,parent = pending.pop()
        if pid in visited: continue
        visited.add(pid); require(len(visited) <= LIVE_LIMIT, 'Owned tree exceeds64')
        try:
            current = process_record(pid)
            if parent is None:
                require(same_identity(current,root_identity), 'Launcher identity changed')
            else:
                require(current['ppid'] == parent['pid'] and same_identity(process_record(parent['pid']),parent),
                        'Owned parent changed before walk')
            children = children_of(pid)
            require(same_identity(process_record(pid),current), 'Owned identity changed during walk')
            if parent is not None:
                require(same_identity(process_record(parent['pid']),parent), 'Owned parent changed during walk')
            key = (pid,current['start_ticks'])
            if key in owned:
                require(same_identity(current,owned[key]), 'Owned lifetime group/session changed')
            else:
                require(len(owned) < HISTORY_LIMIT, f'Owned history exceeds {HISTORY_LIMIT} identities')
                require_live_capacity(owned,deadline)
            snapshot = {**current,'parent_identity':None if parent is None else
                        {k:parent[k] for k in ('pid','start_ticks','group','session','ppid')}}
            if owned.get(key) != snapshot:
                rows = [snapshot if prior == key else value for prior,value in owned.items()]
                if key not in owned: rows.append(snapshot)
                require(len(json.dumps(rows,indent=2).encode()) <= HISTORY_BYTES, f'Owned history exceeds {HISTORY_BYTES} bytes')
                require(time.monotonic() < deadline, 'Owner observation deadline exhausted')
            require(current['group'] in groups or len(groups) < HISTORY_LIMIT, f'Owned group history exceeds {HISTORY_LIMIT} groups')
            owned[key] = snapshot; groups.add(current['group'])
            pending.extend((pid,current) for pid in children)
        except (FileNotFoundError,ProcessLookupError):
            # A short-lived helper may exit during observation. Nothing is
            # adopted without a still-live parent proof; completion also needs
            # the launcher's cooperative native cleanup receipt.
            continue


def signal_owned(child, root_identity, owned, number, already_sent=frozenset(), failures=None):
    failures = [] if failures is None else failures
    matches = live_owned(owned,failures)
    # The direct unreaped Popen also remains owned when first /proc capture fails.
    if child is not None and child.poll() is None:
        if root_identity is None:
            try:
                require(os.getpgid(child.pid) == child.pid and os.getsid(child.pid) == child.pid,
                        'Uncaptured direct launcher group/session differs')
                matches[(child.pid,0)] = {'pid':child.pid,'group':child.pid,'session':child.pid}
            except (FileNotFoundError,ProcessLookupError): pass
            except Exception as error: identity_failure(failures,{'pid':child.pid},error)
        else:
            try:
                current = process_record(child.pid)
                require(same_identity(current,root_identity), 'Refusing changed launcher identity')
                matches[(child.pid,root_identity['start_ticks'])] = current
            except (FileNotFoundError,ProcessLookupError): pass
            except Exception as error: identity_failure(failures,root_identity,error)
    targets = sorted({v['group'] for v in matches.values()}-already_sent)
    sent = []
    for group in targets:
        try:
            require(group > 1 and group != os.getpgrp() and
                    all(v['session'] == group for v in matches.values() if v['group'] == group),
                    'Refusing unsafe owned group/session')
            try: os.killpg(group,number)
            except ProcessLookupError: pass
            sent.append(group)
        except Exception as error: identity_failure(failures,{'pid':group},error)
    return sent


def absent_groups(groups):
    values = {}
    for group in groups:
        try: os.killpg(group,0); values[str(group)] = False
        except ProcessLookupError: values[str(group)] = True
        except PermissionError: values[str(group)] = False
    return values


def escalation(started, stop_at):
    # Early cancellation gets the same12s TERM grace, never a new540s clock.
    term = min(started+TERM_AT,stop_at if stop_at is not None else started+TERM_AT)
    return term,min(started+KILL_AT,term+12)


def retain_inner_receipt(driver,report,plan_pin,human_pin,deadline):
    # This receipt is owned by the driver, independent of public OUTPUT creation.
    result_pin,raw=driver.pin_read(BASE/'diagnostic-assessment.json',maximum=2*1024**2,deadline=deadline,keep=True)
    inner=driver.decode(raw)
    require(inner.get('mode')==driver.MODE and inner.get('plan_pin')==plan_pin and inner.get('human_pin')==human_pin,
        'Inner receipt plan/human/mode binding differs')
    errors=inner.get('errors',[])
    require(type(errors) is list and len(errors)<=64 and all(type(x) is dict and
        type(x.get('type')) is str and len(x['type'])<=256 and type(x.get('message')) is str and len(x['message'])<=8192
        for x in errors),'Bounded inner error evidence malformed')
    report['inner_result_pin']=result_pin
    report['inner_complete']=(inner.get('diagnostic_complete') is True and inner.get('cleanup_complete') is True and
        inner.get('status')=='complete')
    report['inner_outcome']={k:inner.get(k) for k in ('status','failure_phase','workload_dispatch_entered',
        'native_launched','workload_cleanup_applicable','cleanup_complete','cleanup_scope')}
    report['inner_outcome']['errors']=errors
    # Outer /proc/reap/group/capture evidence remains separately authoritative.


def run(started):
    deadline = started+MAXIMUM
    driver = load_driver()
    plan_pin,raw = driver.pin_read(driver.PLAN,maximum=256*1024,deadline=deadline,keep=True)
    plan = driver.validate_plan(driver.decode(raw))
    require(plan.get('status') == 'frozen_pending_fresh_readiness', 'Draft packet is unarmed pending root review')
    outer_pin = driver.pin_read(Path(__file__).resolve(),plan['sources']['outer_owner'],deadline=deadline)[0]
    human_pin,raw = driver.pin_read(driver.HUMAN,maximum=16384,deadline=deadline,keep=True)
    clocks = driver.budget(driver.decode(raw),plan_pin['sha256'],datetime.now(timezone.utc),time.monotonic())
    require(clocks['operator_deadline']-time.monotonic() >= MAXIMUM+30, 'Original1200s has less than570s launch/cleanup room')
    deadline = min(deadline,clocks['operator_deadline'])
    require(not driver.OUTPUT.exists(), 'No retry/output reuse')
    dispatch = BASE/'dispatch-01.json'
    require(not dispatch.exists(), 'Fresh dispatch required')
    # Exclusive create reserves this single dispatch before any child exists.
    with dispatch.open('x') as stream: stream.write('{}\n')
    report = {'schema':1,'mode':driver.MODE,'started_monotonic':started,'deadline_monotonic':deadline,
        'operator_clock':clocks,'plan_pin':plan_pin,'human_pin':human_pin,'outer_pin':outer_pin,
        'command':[plan['assets']['python']['path'],'-I','-B',str(LAUNCHER),'--run'],
        'command_maximum_seconds':MAXIMUM,'term_seconds':TERM_AT,'kill_seconds':KILL_AT,
        'automatic_retries':False,'external_signals':[],'errors':[],'passed':False,'native_model_execution_authorized_by_wrapper':False}
    child = root_identity = None; owned = {}; groups = set(); selector = selectors.DefaultSelector()
    captures = {}; stop_at = None; term_groups = set(); kill_groups = set(); handlers = {}
    def checkpoint():
        report['known_processes'] = list(owned.values()); driver.save(dispatch,report)
    def stop(signum,frame):
        nonlocal stop_at
        report['interruption_signal'] = signum
        if stop_at is None: stop_at = time.monotonic()
    def drain(wait):
        nonlocal stop_at
        for key,_ in selector.select(max(0,wait)):
            data = os.read(key.fd,8192)
            if not data:
                selector.unregister(key.fileobj); key.fileobj.close(); continue
            row = captures[key.data]; row['received'] += len(data)
            left = STREAM_LIMIT-row['written']; payload = data[:max(0,left)]
            if payload:
                written = row['stream'].write(payload)
                require(written == len(payload), 'Short outer capture write')
                row['written'] += written; row['digest'].update(payload)
            if len(payload) != len(data):
                row['overflow'] = True
                if stop_at is None: stop_at = time.monotonic()
    def signals(now):
        term,kill = escalation(started,stop_at)
        if now >= term:
            values = signal_owned(child,root_identity,owned,signal.SIGTERM,term_groups,report['errors']); term_groups.update(values)
            if values:
                report['external_signals'].append({'signal':'TERM','elapsed_seconds':now-started,'groups':values}); checkpoint()
        if now >= kill:
            values = signal_owned(child,root_identity,owned,signal.SIGKILL,kill_groups,report['errors']); kill_groups.update(values)
            if values:
                report['external_signals'].append({'signal':'KILL','elapsed_seconds':now-started,'groups':values}); checkpoint()
    try:
        handlers = {s:signal.signal(s,stop) for s in (signal.SIGINT,signal.SIGTERM)}
        for name in ('stdout','stderr'):
            path = BASE/('adapter.'+name+'.log')
            captures[name] = {'stream':path.open('xb'),'path':str(path),'received':0,'written':0,
                              'digest':hashlib.sha256(),'overflow':False}
        # Recheck exact readiness immediately before dispatch; never renew it.
        require(driver.pin_read(driver.HUMAN,human_pin,maximum=16384,deadline=deadline)[0] == human_pin,
                'Human record changed before dispatch')
        require(driver.pin_read(driver.PLAN,plan_pin,maximum=256*1024,deadline=deadline)[0] == plan_pin,
                'Plan changed before dispatch')
        driver.pin_read(LAUNCHER,plan['sources']['launcher'],maximum=256*1024,deadline=deadline)
        driver.pin_read(Path(plan['assets']['python']['path']),plan['assets']['python'],deadline=deadline)
        require(clocks['operator_deadline']-time.monotonic() >= MAXIMUM+30 and time.monotonic() < deadline,
                'Original window exhausted before dispatch')
        checkpoint()
        require(stop_at is None, 'Cancelled before dispatch; no launcher started')
        report['idle_inhibition_before_dispatch']=verify_idle_inhibition(driver,plan,deadline)
        require(stop_at is None and time.monotonic()<deadline and
                clocks['operator_deadline']-time.monotonic()>=MAXIMUM+30,
                'Cancelled or original window exhausted during idle-inhibition verification')
        checkpoint()
        child = subprocess.Popen(report['command'],cwd=ROOT,stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,bufsize=0)
        report['launcher_pid'] = child.pid; groups.add(child.pid)
        root_identity = process_record(child.pid)
        require(root_identity['group'] == root_identity['session'] == child.pid, 'Launcher owner session differs')
        owned[(child.pid,root_identity['start_ticks'])] = root_identity
        for name in ('stdout','stderr'): selector.register(getattr(child,name),selectors.EVENT_READ,name)
        checkpoint()
        while child.poll() is None and time.monotonic() < deadline:
            remember_owned(child,root_identity,owned,groups,deadline)
            signals(time.monotonic()); drain(min(.05,max(0,deadline-time.monotonic())))
        if child.poll() is None:
            raise TimeoutError('Original whole-command deadline exhausted')
    except BaseException as error:
        report['errors'].append({'phase':'dispatch','type':type(error).__name__,'message':str(error)[:2048]})
        if stop_at is None: stop_at = time.monotonic()
    finally:
        for number in handlers: signal.signal(number,signal.SIG_IGN)
        # Keep observing while the exact parent still lives, including failure
        # during initial /proc/pipe registration and separate-session creation.
        if child is not None:
            if stop_at is None and child.poll() is None: stop_at = time.monotonic()
            while time.monotonic() < deadline:
                try:
                    if child.poll() is None:
                        if root_identity is None:
                            root_identity = process_record(child.pid)
                            require(root_identity['group'] == root_identity['session'] == child.pid,'Launcher session changed')
                            owned[(child.pid,root_identity['start_ticks'])] = root_identity
                        remember_owned(child,root_identity,owned,groups,deadline)
                    remaining = live_owned(owned,report['errors'])
                    if child.poll() is not None and not remaining and not selector.get_map(): break
                    if stop_at is None and (child.poll() is not None and remaining): stop_at = time.monotonic()
                    signals(time.monotonic()); drain(min(.05,max(0,deadline-time.monotonic())))
                except BaseException as error:
                    if len(report['errors']) < 64: report['errors'].append({'phase':'owned_cleanup','message':str(error)[:2048]})
                    if stop_at is None: stop_at = time.monotonic()
                    # Observation/capture failure must never skip signalling.
                    try: signals(time.monotonic())
                    except Exception as error:
                        if len(report['errors']) < 64: report['errors'].append({'phase':'owned_signal','message':str(error)[:2048]})
                    time.sleep(max(0,min(.02,deadline-time.monotonic())))
            try: child.wait(timeout=max(0,deadline-time.monotonic()))
            except Exception as error: report['errors'].append({'phase':'launcher_reap','message':str(error)[:2048]})
        try:
            report['remaining_known_processes'] = list(live_owned(owned,report['errors']).values())
            report['owned_groups_absent'] = absent_groups(groups)
            report['launcher_reaped'] = child is None or child.poll() is not None
        except Exception as error: report['errors'].append({'phase':'absence_proof','message':str(error)[:2048]})
        report['complete_capture'] = not selector.get_map()
        selector.close()
        report['captures'] = {}
        for name,row in captures.items():
            try:
                row['stream'].close()
                report['captures'][name] = {k:row[k] for k in ('path','received','written','overflow')}
                report['captures'][name]['sha256'] = row['digest'].hexdigest()
            except Exception as error: report['errors'].append({'phase':'outer_capture_close','message':str(error)[:2048]})
        if child is not None:
            for name in ('stdout','stderr'):
                pipe = getattr(child,name,None)
                if pipe is not None and not pipe.closed: pipe.close()
        try:
            retain_inner_receipt(driver,report,plan_pin,human_pin,deadline)
        except Exception as error: report['errors'].append({'phase':'inner_receipt','message':str(error)[:2048]})
        report['exit_code'] = child.poll() if child is not None else None
        report['finished_monotonic'] = time.monotonic()
        report['within_external_command_budget'] = report['finished_monotonic'] <= deadline
        report['passed'] = bool(child is not None and report['exit_code'] == 0 and report.get('inner_complete') is True and
            report.get('launcher_reaped') is True and not report.get('remaining_known_processes') and
            all(report.get('owned_groups_absent',{}).values()) and report['complete_capture'] and
            set(report['captures']) == {'stdout','stderr'} and
            all(not r['overflow'] and r['received'] == r['written'] for r in report['captures'].values()) and
            report['within_external_command_budget'] and not report['external_signals'] and not report['errors'])
        checkpoint()
        for number,previous in handlers.items(): signal.signal(number,previous)
    return 0 if report['passed'] else 1


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--run',action='store_true')
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({'status':'unarmed_dry_owner','host_queried':False,'native_started':False,
                          'term_seconds':TERM_AT,'kill_seconds':KILL_AT,'maximum_seconds':MAXIMUM}))
        return 0
    return run(started)


if __name__ == '__main__': raise SystemExit(main())
