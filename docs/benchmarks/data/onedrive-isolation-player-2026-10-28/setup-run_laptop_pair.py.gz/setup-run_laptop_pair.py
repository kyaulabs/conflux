"""Current player check with the approved three-sample guard and unchanged runtime; dry by default."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import time
from types import SimpleNamespace

BASE=Path(__file__).resolve().parent
ARMS=('candidate',)
MODE='m2-onedrive-isolation-player-20261028-01'


def save(path,value):
 temporary=path.with_suffix(path.suffix+'.tmp')
 temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)


def pin(path):
 path=Path(path);assert path.is_file() and not path.is_symlink(),str(path)
 with path.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(path),bytes=path.stat().st_size,sha256=sha)


def verify(plan):
 assert plan['schema']==1 and plan['mode']==MODE and plan['seconds_per_arm']==120
 assert plan['operator_seconds']==1200 and plan['forced_redraw_interval_ms']==16 and plan['no_retries']
 for row in plan['pins'].values():assert pin(row['path'])==row,row['path']
 for row in plan['source_files']:
  p=Path(plan['source_root'])/row['file'];assert p.stat().st_size==row['bytes'] and pin(p)['sha256']==row['sha256'],str(p)
 for row in plan['cache_seed_files']:
  p=Path(plan['cache_seed'])/row['file'];assert p.stat().st_size==row['bytes'] and pin(p)['sha256']==row['sha256'],str(p)
 assert len([p for p in Path(plan['cache_seed']).rglob('*') if p.is_file()])==len(plan['cache_seed_files'])
 proof=json.loads(Path(plan['pins']['exact_outputs']['path']).read_text())
 assert proof['correctness_complete_both_hosts'] and proof['timing_qualification'] is False
 for host in ('laptop','apollo'):
  for arm in ('baseline',):assert proof['hosts'][host]['arms'][arm]['requests']==proof['hosts'][host]['arms'][arm]['exact_outputs']==16
 numeric=json.loads(Path(plan['pins']['numeric_laptop_plan']['path']).read_text())
 human=json.loads(Path(plan['pins']['numeric_laptop_readiness']['path']).read_text())
 assert human['plan_sha256']==plan['pins']['numeric_laptop_plan']['sha256']
 for name in ('baseline','model'):assert plan['pins'][name]==numeric['pins'][name]
 assert plan['pins']['candidate']==numeric['pins']['baseline']
 clearance=json.loads(Path(plan['pins']['source_ci']['path']).read_text())
 assert clearance['source']=='dfff55ea78b6fcbe633a178e996371238803013d' and clearance['all_nine_CI_jobs_passed'] and clearance['merge_tree_matches_source']
 raw_result=json.loads(Path(plan['pins']['numeric_laptop_result']['path']).read_text())
 assert hashlib.sha256(json.dumps(raw_result,sort_keys=True).encode()).hexdigest()==proof['hosts']['laptop']['source_result_sha256']


def clock(human,plan_sha,now_utc,now_mono):
 age=(now_utc-datetime.fromisoformat(human['recorded_at_utc'])).total_seconds()
 remaining=human['operator_deadline_monotonic']-now_mono
 assert human['mode']==MODE and human['plan_sha256']==plan_sha and 0<=age<=90 and 1000<=remaining<=1200-age+2
 assert human['operator_seconds']==1200 and all(human.get(k) is True for k in
  ('AC_power','lid_open','visible_window','screen_awake','Codex_minimized','other_work_paused','no_suspend'))
 assert human['human_reply'] and human['question_item_id']
 return human['operator_deadline_monotonic']


def load(name,row):
 assert pin(row['path'])==row
 spec=importlib.util.spec_from_file_location(name,row['path']);module=importlib.util.module_from_spec(spec)
 sys.modules[name]=module;spec.loader.exec_module(module);return module


def validate_caps(values,ceilings):
 assert values.keys()==ceilings.keys()
 for path,value in values.items():
  assert type(value) is int and value>0
  assert value<=ceilings[path] if path.endswith('_power_limit_uw') else value==ceilings[path],path


def prepare_host(plan,owner,guard,deadline,log):
 """Same guard, at most70C for60 sampled seconds; naturally recovered Balanced only."""
 since=None;before=None;paths=owner.sensor_paths()
 while time.monotonic()<deadline:
  row=owner.observation(paths);row['power']=owner.power_state()
  row['caps']={p:int(Path(p).read_text()) for p in plan['cap_ceilings']};validate_caps(row['caps'],plan['cap_ceilings'])
  assert not row['read_errors'] and row['power']['ac_online'] and row['power']['lid_open']
  assert owner.guard_identity(Path(plan['pins']['guard_script']['path']),Path(plan['pins']['guard_unit']['path']))==guard
  now=time.monotonic();profile=row['profile_epp_read_only']
  good=(max(row['temperatures_millidegrees_C'].values())<=70000 and
        profile['/sys/firmware/acpi/platform_profile']=='balanced' and
        profile['/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference']=='balance_performance' and
        (before is None or now-before<=5))
  since=(now if since is None else since) if good else None
  row['settled_span_seconds']=0 if since is None else now-since
  log.write(json.dumps(row)+'\n');log.flush()
  if good and now-since>=60:return
  before=now;time.sleep(min(2,max(0,deadline-time.monotonic())))
 raise TimeoutError('Bounded natural Balanced/70C settling interval not reached')


def assess(result):
 native=result.get('native',{});obs=result.get('observations',{});hops=obs.get('service_hops',{})
 count=hops.get('count',0);p99=hops.get('nearest_rank_p99_ms')
 complete=(result.get('requested_seconds')==120 and native.get('measurement_intervals_closed') is True and
  120000<=native.get('measured_wall_ms',0)<=122000 and native.get('shutdown_completed') is True and
  native.get('cancelled') is False and native.get('mode')=='live-stems-controls' and
  native.get('forced_redraw_interval_ms')==16 and native.get('ui_mode')=='visible' and
  native.get('window_policy')=='visible' and native.get('manual_controls_complete') is True and len(native.get('manual_controls',[]))==16)
 record=native.get('recording',{})
 recording_ok=(record.get('status')=='Complete' and record.get('error','')=='' and
  type(record.get('acceptedFrames')) is int and record['acceptedFrames']>0 and
  record['acceptedFrames']==record.get('writtenFrames') and record.get('overflowFrames')==0)
 functional=(complete and result.get('native_exit')==0 and native.get('passed') is True and native.get('error','')=='' and
  native.get('steady_starved_frames')==0 and recording_ok and
  all(native.get(k)==0 for k in ('execution_deadline_misses','invalid_buffers','source_read_failures','rejected_commands')))
 target=(obs.get('service_metrics_complete') is True and hops.get('complete') is True and count>0 and
         type(p99) in (int,float) and p99<4095)
 cleanup=result.get('cleanup',{})
 clean=(result.get('cleanup_proven') is True and cleanup.get('leader_reaped') is True and
        cleanup.get('cooperative_native_shutdown') is True and cleanup.get('ownership_complete') is True and
        not cleanup.get('remaining_known_processes') and cleanup.get('remaining_pipewire_count')==0 and
        not cleanup.get('remaining_live_jobs') and not cleanup.get('ownership_failures') and
        cleanup.get('engine_processes_observed') is True and result.get('pins_unchanged') is True and
        result.get('within_wall_budget') is True)
 return dict(measurement_complete=complete,native_functional_passed=functional,service_target_met=target,
  service_hops=hops,wrapper_passed=result.get('passed'),cleanup_complete=clean,qualified=False,
  hard_cancellation_exercised=False,steady_starved_frames=native.get('steady_starved_frames'),
  control_starved_frames=native.get('control_starved_frames'),execution_deadline_misses=native.get('execution_deadline_misses'),
  invalid_buffers=native.get('invalid_buffers'),source_read_failures=native.get('source_read_failures'),recording=native.get('recording'))


def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
 plan_path=BASE/'laptop-plan.json';plan=json.loads(plan_path.read_text())
 if not args.run:
  verify(plan);print(json.dumps(dict(verified=True,hardware_started=False)));return 0
 assert plan['state']=='frozen_pending_fresh_readiness','Draft player packet is unarmed'
 human=json.loads((BASE/'readiness.json').read_text())
 deadline=clock(human,pin(plan_path)['sha256'],datetime.now(timezone.utc),time.monotonic())
 root=BASE/'laptop-results-01';root.mkdir(mode=0o700)
 report=dict(schema=1,mode=MODE,original_readiness_utc=human['recorded_at_utc'],deadline_monotonic=deadline,
  completed=False,cleanup_complete=False,qualified=False,no_retries=True,arms={},errors=[],workload_attempted_arms=[])
 def checkpoint():save(root/'pair-result.json',report)
 def alarm(number,frame):raise InterruptedError('Original owned deadline reached')
 signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,max(.1,deadline-time.monotonic()-45))
 try:
  verify(plan)
  owner=load('staging_host_readings',plan['pins']['host_readings'])
  guard=owner.guard_identity(Path(plan['pins']['guard_script']['path']),Path(plan['pins']['guard_unit']['path']))
  report['guard_before']=guard;checkpoint()
  for arm in ARMS:
   assert deadline-time.monotonic()>=360,'No native setup/measurement/cleanup room on original clock'
   case=root/arm;case.mkdir(mode=0o700);started=time.monotonic();arm_deadline=min(deadline-45,started+540)
   with (case/'settling.jsonl').open('x') as log:prepare_host(plan,owner,guard,min(started+240,arm_deadline-240),log)
   verify(plan)
   assert arm_deadline-time.monotonic()>=240,'No minimum native work/cleanup room'
   cache=case/'driver-cache';shutil.copytree(plan['cache_seed'],cache)
   os.environ.update(MESA_SHADER_CACHE_DIR=str(cache/'mesa_shader_cache'),MESA_SHADER_CACHE_MAX_SIZE='128M')
   wrapper=load('staging_actual_player_'+arm,plan['pins']['wrapper'])
   assert wrapper.FLASH_RUNTIME_SHA256==plan['original_promoted_runtime_sha256']
   # Explicit private runtime binding after the full-output prerequisite above.
   # All processing, collection, visibility, source and health gates stay in the public owner.
   wrapper.FLASH_RUNTIME_SHA256=plan['pins'][arm]['sha256']
   original_observation=wrapper.observation
   def monitored(paths):
    row=original_observation(paths);row['configured_power_caps']={p:int(Path(p).read_text()) for p in plan['cap_ceilings']}
    validate_caps(row['configured_power_caps'],plan['cap_ceilings']);return row
   wrapper.observation=monitored
   readiness=dict(human,schema=1,decision='ready',ready_for_run='output-01',ui_mode='visible')
   readiness_path=case/'readiness.json';save(readiness_path,readiness)
   parameters={k:Path(plan['pins'][k]['path']) for k in ('binary','track_a','track_b','python','exporter','worker','service','model','guard_script','guard_unit')}
   parameters.update(runtime=Path(plan['pins'][arm]['path']),seconds=120,live_stems=True,live_stems_hour=False,background=False,
    active_controls=True,normal_redraw=False,output=case/'output-01',readiness_decision=readiness_path)
   signal.setitimer(signal.ITIMER_REAL,max(.1,arm_deadline-time.monotonic()))
   report['workload_attempted_arms'].append(arm);checkpoint()
   code=wrapper.run_live(SimpleNamespace(**parameters))
   signal.setitimer(signal.ITIMER_REAL,max(.1,deadline-time.monotonic()-45))
   result=json.loads((case/'output-01/result.json').read_text());assessment=assess(result)
   assessment.update(wrapper_exit=code,seconds=time.monotonic()-started)
   report['arms'][arm]=assessment;save(case/'assessment.json',assessment);checkpoint()
   assert assessment['cleanup_complete'],'Owned native/service cleanup not proven'
   assert assessment['measurement_complete'],'Incomplete first arm retained; no next arm'
  verify(plan)
  report['guard_after']=owner.guard_identity(Path(plan['pins']['guard_script']['path']),Path(plan['pins']['guard_unit']['path']))
  assert report['guard_after']==guard
  report['completed']=True
 except BaseException as error:report['errors'].append(dict(type=type(error).__name__,error=str(error)))
 finally:
  signal.setitimer(signal.ITIMER_REAL,0)
  report['finished_monotonic']=time.monotonic()
  report['within_original_window']=report['finished_monotonic']<=deadline
  for arm in report['workload_attempted_arms']:
   if arm not in report['arms']:
    p=root/arm/'output-01/result.json'
    if p.exists():
     try:report['arms'][arm]=assess(json.loads(p.read_text()))
     except Exception as error:report['errors'].append(dict(phase='partial-result-inspection',error=str(error)))
  report['cleanup_complete']=(len(report['arms'])==len(report['workload_attempted_arms']) and
    all(a['cleanup_complete'] for a in report['arms'].values()))
  report['completed']=report['completed'] and report['cleanup_complete'] and report['within_original_window'] and not report['errors']
  checkpoint()
 print(json.dumps({k:report[k] for k in ('completed','cleanup_complete','errors')}))
 return 0 if report['completed'] else 1


if __name__=='__main__':raise SystemExit(main())
