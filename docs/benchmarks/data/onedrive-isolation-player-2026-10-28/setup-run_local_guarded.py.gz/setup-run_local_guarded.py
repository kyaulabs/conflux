"""Run the existing uninstrumented owner inside an approved, reversible sync pause."""
from datetime import datetime, timezone
from pathlib import Path
import importlib.util
import hashlib
import json
import sys
import time

BASE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    human = json.loads((BASE / 'readiness.json').read_text()) if '--run' in sys.argv else None
    plan = json.loads((BASE / 'laptop-plan.json').read_text())
    row = plan['pins']['driver']
    assert Path(row['path']) == BASE / 'run_laptop_pair.py'
    raw = Path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    runner = load('normal_player_owner', BASE / 'run_laptop_pair.py')
    if '--run' not in sys.argv:
        return runner.main()
    runner.clock(human, runner.pin(BASE / 'laptop-plan.json')['sha256'],
        datetime.now(timezone.utc), time.monotonic())
    runner.verify(plan)
    pause = runner.load('approved_sync_pause', plan['pins']['sync_pause_helper'])
    try:
        pause.pause(human.get('onedrive_pause_approved') is True, human['question_item_id'])
        code = runner.main()
        pause.verify_held()
        return code
    finally:
        if pause.TOKEN.exists():
            pause.restore()


if __name__ == '__main__':
    raise SystemExit(main())
