"""Independently recompute complete-hop and native interval totals from raw captures."""
from pathlib import Path
from collections import Counter
import hashlib,json,math
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent

def read(p):return json.loads(p.read_text())
def file_pin(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
result=dict(schema=1,source='dfff55ea78b6fcbe633a178e996371238803013d',strict_target_ms=4095,hosts={},hard_cancellation_exercised=False,no_causal_AB_claim=True,release_or_milestone_gate_closed=False)
for host,path,wrapper in [
 ('laptop',ROOT/'laptop-results-01/candidate/output-01',ROOT/'laptop-results-01/candidate/output-01/result.json'),
 ('apollo',BASE/'apollo/cases/candidate/private-player-01/recordings/actual-player',BASE/'apollo/cases/candidate/private-player-01/recordings/actual-player/assessment.json')]:
 n=read(path/'native-result.json');w=read(wrapper);obs=w['observations']
 rows=[json.loads(s) for s in (path/'observations.jsonl').read_text().splitlines()]
 records=[s for s in rows if s['type']=='record'];chunks=[r for r in records if r['kind']==5]
 assert len(records)==n['observation_counters']['retained']==n['observation_counters']['attempted']
 assert n['observation_counters']['dropped']==0 and n['observation_counters']['invalid_clock_reads']==0
 assert [r['ordinal'] for r in records]==list(range(1,len(records)+1))
 assert all(r['hop_service_present'] and math.isfinite(r['hop_service_ms']) and r['hop_service_ms']>=0 for r in chunks)
 values=sorted(r['hop_service_ms'] for r in chunks)
 hops=dict(count=len(values),maximum_ms=values[-1],nearest_rank_p99_ms=values[math.ceil(.99*len(values))-1],strict_target_ms=4095,at_or_above_target=sum(v>=4095 for v in values),complete=True)
 assert hops==obs['service_hops']
 intervals=n['intervals'];assert n['measurement_intervals_closed'] and all(not r['aborted'] for r in intervals)
 steady=sum(r['starved_frames'] for r in intervals if r['kind']=='steady')
 controls=sum(r['starved_frames'] for r in intervals if r['kind']!='steady')
 assert steady==n['steady_starved_frames'] and controls==n['control_starved_frames']
 assert sum(r['starved_b'] for r in intervals)==0
 assert len(n['manual_controls'])==16 and all(r['acknowledged'] for r in n['manual_controls'])
 seek=next(c for c in n['controls'] if c['kind']=='incomplete_generation_seek')
 accepted=[r for r in records if r['kind']==4 and r['generation']==seek['previous_generation'] and r['observed_ns']<=seek['issued_ns']]
 complete=[r for r in records if r['kind']==8 and r['generation']==seek['previous_generation'] and r['observed_ns']<=seek['issued_ns']]
 assert accepted and not complete and seek['incomplete_when_last_drained'] and n['last_recovery_complete']
 assert all(r['recovered_cursor_observed_ns']>=r['issued_ns'] for r in n['controls'])
 rec=n['recording'];assert rec['status']=='Complete' and rec['acceptedFrames']==rec['writtenFrames']==n['recorded_audio']['frames'] and rec['overflowFrames']==0 and not rec['error']
 assert n['execution_deadline_misses']==n['invalid_buffers']==n['rejected_commands']==n['source_read_failures']==0
 tail=n['diagnostic_tail'];assert tail['starved_a']==tail['starved_b']==0 and tail['WAV_finalized_before_idle_close']
 worst=max(chunks,key=lambda r:r['hop_service_ms'])
 row=dict(measured_wall_ms=n['measured_wall_ms'],native_passed=n['passed'],native_error=n['error'],service_hops=hops,steady_starved_frames=steady,steady_starved_seconds=steady/48000,control_starved_frames=controls,control_starved_seconds=controls/48000,peer_starved_frames=0,tail_starved_frames=0,all_16_manual_controls_acknowledged=True,replays=n['replay_count'],incomplete_generation_seek_proved=True,stale_packet_discards=sum(r['kind']==7 for r in records),final_recovery_complete=True,seek_replay_recovery_poll_upper_ms=[(c['recovered_cursor_observed_ns']-c['issued_ns'])/1e6 for c in n['controls']],hard_cancellation_exercised=False,callback_execution_deadline_misses=0,driver_discontinuities=sum(r['driver_position_discontinuities'] for r in n['timing']),driver_recovery_flags=sum(r['driver_recovery_flags'] for r in n['timing']),invalid_buffers=0,rejected_commands=0,source_read_failures=0,scene_errors=n['scene_errors'],recording=dict(accepted_frames=rec['acceptedFrames'],written_frames=rec['writtenFrames'],overflow_frames=0,format=n['recorded_audio']),first_cursor_poll_upper_seconds=(n['first_advance_observed_ns']-n['load_issued_ns'])/1e9,maximum_GUI_heartbeat_gap_ms=n['maximum_gui_heartbeat_gap_ns']/1e6,maximum_frame_presentation_gap_ms=n['maximum_frame_presentation_gap_ns']/1e6,observation_loss=0,raw_observations=file_pin(path/'observations.jsonl'),native_result=file_pin(path/'native-result.json'),worst_hop=worst)
 if host=='laptop':
  hs=[json.loads(s) for s in (path/'host-observations.jsonl').read_text().splitlines()]
  profiles=Counter(s['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'] for s in hs)
  cap_key='/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_power_limit_uw'
  caps=Counter(s['configured_power_caps'][cap_key] for s in hs)
  assert set(caps)<={7500000,15000000} and all(s['power']['ac_online'] and s['power']['lid_open'] for s in hs)
  row['thermal']=dict(summary=w['thermal_summary'],profile_samples=dict(profiles),MMIO_long_term_limit_samples_uw=dict(caps),maximum_sample_gap_seconds=max((b['monotonic_ns']-a['monotonic_ns'])/1e9 for a,b in zip(hs,hs[1:])),guard_identity_unchanged=w['guard_before']==w['guard_after'])
  assert row['thermal']['guard_identity_unchanged'] and w['cleanup_proven']
 result['hosts'][host]=row
(BASE/'results-summary-01.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({h:{k:r[k] for k in ('measured_wall_ms','native_passed','service_hops','steady_starved_seconds','control_starved_seconds','replays','stale_packet_discards','first_cursor_poll_upper_seconds','maximum_GUI_heartbeat_gap_ms')} for h,r in result['hosts'].items()},indent=2))
print('Laptop thermal:',json.dumps(result['hosts']['laptop']['thermal']))
