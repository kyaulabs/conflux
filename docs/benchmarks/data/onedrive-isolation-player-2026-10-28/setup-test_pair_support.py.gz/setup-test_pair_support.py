"""Offline regressions for the private pair's clock, caps and separate result gates."""
import copy
from datetime import datetime,timedelta,timezone
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('staging_pair_under_test',BASE/'run_laptop_pair.py')
pair=importlib.util.module_from_spec(spec);spec.loader.exec_module(pair)


class PairSupportTests(unittest.TestCase):
 def human(self):
  now=datetime.now(timezone.utc)
  record=dict(mode=pair.MODE,plan_sha256='fixed',recorded_at_utc=now.isoformat(),operator_deadline_monotonic=3200,
   operator_seconds=1200,human_reply='offline fixture',question_item_id='offline fixture')
  for name in ('AC_power','lid_open','visible_window','screen_awake','Codex_minimized','other_work_paused','no_suspend'):record[name]=True
  return record,now

 def original(self):
  return json.loads((BASE.parent/'m2-synchronized-redraw-comparison-01/cases/baseline/output-01/result.json').read_text())

 def positive_fixture(self):
  value=self.original();n=value['native'];value['native_exit']=0
  n.update(passed=True,error='',steady_starved_frames=0)
  return value

 def test_original_deadline_not_renewed(self):
  human,now=self.human()
  self.assertEqual(pair.clock(human,'fixed',now,2000),3200)
  self.assertEqual(pair.clock(human,'fixed',now+timedelta(seconds=20),2020),3200)

 def test_expired_changed_plan_and_renewed_window_rejected(self):
  human,now=self.human()
  for altered,key,utc,mono in ((human,'wrong',now,2000),(human,'fixed',now+timedelta(seconds=91),2091),
   (dict(human,operator_deadline_monotonic=4400),'fixed',now,2000)):
   with self.assertRaises(AssertionError):pair.clock(altered,key,utc,mono)

 def test_missing_physical_conditions_rejected(self):
  human,now=self.human()
  for name in ('AC_power','lid_open','visible_window','screen_awake','Codex_minimized','other_work_paused','no_suspend'):
   with self.subTest(name=name),self.assertRaises(AssertionError):pair.clock(dict(human,**{name:False}),'fixed',now,2000)

 def test_real_failed_baseline_remains_a_completed_failure(self):
  value=pair.assess(self.original())
  self.assertTrue(value['measurement_complete']);self.assertTrue(value['cleanup_complete'])
  self.assertFalse(value['native_functional_passed']);self.assertFalse(value['service_target_met'])
  self.assertGreater(value['steady_starved_frames'],0)

 def test_native_function_and_latency_are_independent(self):
  value=pair.assess(self.positive_fixture())
  self.assertTrue(value['native_functional_passed']);self.assertFalse(value['service_target_met'])
  self.assertFalse(value['qualified'])

 def test_strict_boundary_and_incomplete_metrics_rejected(self):
  for late,complete in ((4095,True),(4094.9,False)):
   fixture=self.positive_fixture();obs=fixture['observations'];obs['service_hops']['nearest_rank_p99_ms']=late;obs['service_metrics_complete']=complete
   self.assertFalse(pair.assess(fixture)['service_target_met'])

 def test_faster_redraw_cancelled_or_missing_actions_is_incomplete(self):
  for changes in ({'forced_redraw_interval_ms':50},{'mode':'live-stems-controls-normal-redraw'},{'cancelled':True},{'manual_controls':[]}):
   fixture=self.positive_fixture();fixture['native'].update(changes)
   self.assertFalse(pair.assess(fixture)['measurement_complete'])

 def test_faults_and_recording_overflow_fail_function(self):
  for name in ('execution_deadline_misses','invalid_buffers','source_read_failures','rejected_commands'):
   fixture=self.positive_fixture();fixture['native'][name]=1
   self.assertFalse(pair.assess(fixture)['native_functional_passed'])
  fixture=self.positive_fixture();fixture['native']['recording']['overflowFrames']=1
  self.assertFalse(pair.assess(fixture)['native_functional_passed'])

 def test_unproven_cleanup_never_passes(self):
  fixture=self.positive_fixture();fixture['cleanup_proven']=False
  self.assertFalse(pair.assess(fixture)['cleanup_complete'])
  fixture=self.positive_fixture();fixture['cleanup']['remaining_live_jobs']=['unreaped']
  self.assertFalse(pair.assess(fixture)['cleanup_complete'])

 def test_guard_reductions_allowed_increases_rejected(self):
  ceiling={'p_power_limit_uw':15000000,'enabled':1}
  pair.validate_caps({'p_power_limit_uw':7500000,'enabled':1},ceiling)
  for fields in ({'p_power_limit_uw':25000000,'enabled':1},{'p_power_limit_uw':15000000,'enabled':0}):
   with self.assertRaises(AssertionError):pair.validate_caps(fields,ceiling)

 def test_draft_or_missing_readiness_never_imports_owner(self):
  for state in ('draft_unarmed_pending_remaining_offline_checks','frozen_pending_fresh_readiness'):
   with tempfile.TemporaryDirectory(dir=BASE) as temporary:
    root=Path(temporary);(root/'laptop-plan.json').write_text(json.dumps(dict(state=state)))
    with mock.patch.object(pair,'BASE',root),mock.patch.object(sys,'argv',['fixture','--run']),mock.patch.object(pair,'load') as imported:
     with self.assertRaises((AssertionError,FileNotFoundError)):pair.main()
     imported.assert_not_called();self.assertFalse((root/'laptop-results-01').exists())


if __name__=='__main__':unittest.main(verbosity=2)
