"""Temporarily pause one verified user service only after explicit approval."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess

BASE = Path(__file__).resolve().parent
UNIT = 'onedrive.service'
TOKEN = BASE / 'onedrive-pause-state.json'
PROPOSAL = BASE / 'onedrive-proposal.json'
PROC = Path('/proc')


def save(value):
    temporary = TOKEN.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(TOKEN)


def show():
    raw = subprocess.check_output(['systemctl', '--user', 'show', UNIT,
        '-p', 'LoadState', '-p', 'ActiveState', '-p', 'SubState', '-p', 'MainPID',
        '-p', 'InvocationID', '-p', 'FragmentPath', '-p', 'DropInPaths',
        '-p', 'ControlGroup', '-p', 'InactiveEnterTimestampMonotonic'], text=True, timeout=5)
    return dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)


def validate(state, proposal):
    assert proposal['unit'] == UNIT and proposal['user_uid'] == os.getuid()
    assert state['LoadState'] == 'loaded' and not state['DropInPaths']
    assert state['FragmentPath'] == proposal['unit_file']['path']
    for name in ('unit_file', 'executable'):
        row = proposal[name]
        path = Path(row['path'])
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size == row['bytes']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
    if state['ActiveState'] == 'active':
        pid = int(state['MainPID'])
        directory = PROC / str(pid)
        assert pid > 0 and directory.stat().st_uid == os.getuid()
        assert (directory / 'exe').resolve(strict=True) == Path(proposal['executable']['path']).resolve(strict=True)
        assert ('0::' + state['ControlGroup']) in (directory / 'cgroup').read_text().splitlines()


def change(action):
    assert action in ('stop', 'start')
    subprocess.run(['systemctl', '--user', action, UNIT], check=True,
        timeout=100 if action == 'stop' else 15)


def pause(approved, question_item_id):
    assert not TOKEN.exists(), 'A previous pause token must be inspected before reuse.'
    proposal = json.loads(PROPOSAL.read_text())
    before = show()
    validate(before, proposal)
    assert before['ActiveState'] in ('active', 'inactive')
    if before['ActiveState'] == 'active' and not approved:
        raise PermissionError('Explicit approval is required to pause OneDrive.')
    record = dict(schema=1, unit=UNIT, proposal_sha256=hashlib.sha256(PROPOSAL.read_bytes()).hexdigest(),
        approval=bool(approved), question_item_id=question_item_id, before=before,
        originally_active=before['ActiveState'] == 'active', pause_requested=False,
        paused=False, restore_complete=False)
    with TOKEN.open('x') as output:
        output.write(json.dumps(record, indent=2) + '\n')
    if record['originally_active']:
        record['pause_requested'] = True
        save(record)
        change('stop')
    after = show()
    validate(after, proposal)
    assert after['ActiveState'] == 'inactive' and after['MainPID'] == '0'
    record.update(paused=True, paused_state=after)
    save(record)
    return record


def verify_held():
    record = json.loads(TOKEN.read_text())
    assert record['paused']
    current = show()
    validate(current, json.loads(PROPOSAL.read_text()))
    held = (current['ActiveState'] == 'inactive' and current['MainPID'] == '0' and
        current['InactiveEnterTimestampMonotonic'] == record['paused_state']['InactiveEnterTimestampMonotonic'])
    record.update(pause_held_through_native_cleanup=held, after_native_cleanup=current)
    save(record)
    assert held, 'OneDrive state changed during the test; retain an invalid isolation result.'


def restore():
    if not TOKEN.exists():
        return dict(no_pause_token=True, service_changed=False)
    record = json.loads(TOKEN.read_text())
    if record['restore_complete']:
        return dict(already_restored=True, service_changed=False)
    assert record['unit'] == UNIT
    assert record['proposal_sha256'] == hashlib.sha256(PROPOSAL.read_bytes()).hexdigest()
    if not record['originally_active']:
        record.update(restore_complete=True, restoration='originally_inactive_left_unchanged')
        save(record)
        return record
    assert record['approval'] and record['pause_requested']
    current = show()
    proposal = json.loads(PROPOSAL.read_text())
    validate(current, proposal)
    if current['ActiveState'] == 'active':
        record.update(restore_complete=True, restoration='already_active', restored_state=current)
    elif current['ActiveState'] == 'inactive':
        paused = record.get('paused_state')
        if paused and current['InactiveEnterTimestampMonotonic'] != paused['InactiveEnterTimestampMonotonic']:
            record.update(restore_complete=True, restoration='foreign_transition_left_unchanged', restored_state=current)
        else:
            change('start')
            after = show()
            validate(after, proposal)
            assert after['ActiveState'] == 'active' and int(after['MainPID']) > 0
            record.update(restore_complete=True, restoration='original_active_service_restored', restored_state=after)
    else:
        raise RuntimeError('OneDrive has an unexpected state; automatic restoration was withheld.')
    save(record)
    return record


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--restore', action='store_true', required=True)
    parser.parse_args()
    result = restore()
    print(json.dumps({key: result[key] for key in
        ('no_pause_token', 'already_restored', 'restore_complete', 'restoration', 'service_changed') if key in result}))
