"""Read-only CPU counters reused from the tested thread observer; no workload entry."""
from pathlib import Path
import os,time,subprocess,json
BINARY=Path("/unarmed-conflux-cpu-probe")

def require(ok,message):
    if not ok: raise ValueError(message)

def parse_process_stat(raw, expected_pid):
    if len(raw) > 16384:
        raise ValueError('Process stat exceeds bound')
    left, right = raw.find('('), raw.rfind(')')
    if left < 1 or right <= left or int(raw[:left].strip()) != expected_pid:
        raise ValueError('Process stat identity/format differs')
    fields = raw[right + 1:].split()
    if len(fields) < 20:
        raise ValueError('Process stat fields missing')
    values = [int(fields[i]) for i in (1, 11, 12, 17, 19)]
    if min(values) < 0 or values[3] < 1 or values[4] < 1:
        raise ValueError('Invalid process counters')
    return {'pid': expected_pid, 'comm': raw[left + 1:right], 'ppid': values[0],
            'cpu_ticks': values[1] + values[2], 'threads': values[3], 'start_ticks': values[4]}

def process_cpu_delta(previous, current, interval_ns, ticks_per_second):
    if (previous is None or previous['pid'] != current['pid'] or
            previous['start_ticks'] != current['start_ticks'] or interval_ns <= 0 or
            ticks_per_second <= 0 or current['cpu_ticks'] < previous['cpu_ticks']):
        return None
    return (current['cpu_ticks'] - previous['cpu_ticks']) * 1e9 / ticks_per_second / interval_ns

def capture_native_thread_cpu(process, previous, proc_root=Path('/proc'), expected_exe=BINARY):
    result = {'pid': process['pid'], 'process_start_ticks': process['start_ticks'],
        'matched_expected_exe': False, 'complete': False, 'threads': [], 'errors': [],
        'scope': 'Read-only task stat CPU counters for the exact native executable and PID lifetime. Thread-row pid is the Linux TID. Thread counts and interval rates are sampled; creation/exit and unreadable threads can omit CPU. No stack or function attribution.'}
    directory = proc_root / str(process['pid'])
    try:
        if (directory / 'exe').resolve(strict=True) != expected_exe.resolve(strict=True):
            return result
        require(directory.stat().st_uid == os.getuid(), 'Native task user differs')
        result['matched_expected_exe'] = True
        with (directory / 'stat').open('r') as stream:
            before = parse_process_stat(stream.read(16385), process['pid'])
        require(before['start_ticks'] == process['start_ticks'], 'Native process lifetime changed')
        tasks = sorted((p for p in (directory / 'task').iterdir() if p.name.isdecimal()), key=lambda p: int(p.name))
        require(len(tasks) <= 128, 'Native thread observation exceeds128 TID bound')
        compatible = (previous is not None and previous['pid'] == process['pid'] and
                      previous['process_start_ticks'] == process['start_ticks'])
        old = {r['pid']: r for r in previous['threads']} if compatible else {}
        for task in tasks:
            try:
                with (task / 'stat').open('r') as stream:
                    row = parse_process_stat(stream.read(16385), int(task.name))
                row['observed_monotonic_ns'] = time.monotonic_ns()
                prior = old.get(row['pid'])
                interval = row['observed_monotonic_ns'] - prior['observed_monotonic_ns'] if prior else 0
                row['cpu_cores_since_previous_observation'] = process_cpu_delta(prior, row, interval, os.sysconf('SC_CLK_TCK'))
                result['threads'].append(row)
            except (OSError, ValueError, IndexError) as error:
                result['errors'].append({'tid': int(task.name), 'type': type(error).__name__, 'message': str(error)[:256]})
        with (directory / 'stat').open('r') as stream:
            after = parse_process_stat(stream.read(16385), process['pid'])
        require(after['start_ticks'] == before['start_ticks'] and
                (directory / 'exe').resolve(strict=True) == expected_exe.resolve(strict=True),
                'Native process lifetime/executable changed during task capture')
        result['complete'] = not result['errors']
    except (OSError, ValueError, IndexError) as error:
        result['threads'] = []
        result['errors'].append({'type': type(error).__name__, 'message': str(error)[:256]})
    return result

def capture_process_cpu(previous, proc_root=Path('/proc')):
    # Read-only process totals across threads; never read arguments or sum child CPU.
    # First-seen/reused PIDs retain raw counters without an invented interval rate.
    began = time.monotonic_ns(); cpu_began = time.thread_time_ns()
    rows = []; errors = []; error_count = 0
    ticks = os.sysconf('SC_CLK_TCK')
    paths = sorted((p for p in proc_root.iterdir() if p.name.isdecimal()), key=lambda p: int(p.name))
    if len(paths) > 4096:
        raise ValueError('Process observation exceeds4096 PID bound')
    old = {} if previous is None else {r['pid']: r for r in previous['processes']}
    for path in paths:
        try:
            with (path / 'stat').open('r') as stream:
                raw = stream.read(16385)
            row = parse_process_stat(raw, int(path.name))
            row['observed_monotonic_ns'] = time.monotonic_ns()
            before = old.get(row['pid'])
            interval = row['observed_monotonic_ns'] - before['observed_monotonic_ns'] if before else 0
            row['cpu_cores_since_previous_observation'] = process_cpu_delta(before, row, interval, ticks)
            rows.append(row)
        except (OSError, ValueError, IndexError) as error:
            error_count += 1
            if len(errors) < 8:
                errors.append({'pid': int(path.name), 'type': type(error).__name__, 'message': str(error)[:256]})
    prior_native = {r['pid']: r for r in previous.get('native_thread_cpu', [])} if previous else {}
    native_threads = [capture_native_thread_cpu(r, prior_native.get(r['pid']), proc_root, expected_exe=BINARY)
                      for r in rows if r['comm'] == BINARY.name[:15]]
    return {'schema': 1, 'native_thread_cpu': native_threads, 'began_monotonic_ns': began, 'finished_monotonic_ns': time.monotonic_ns(),
            'scan_thread_cpu_ns': time.thread_time_ns() - cpu_began, 'ticks_per_second': ticks,
            'read_error_count': error_count, 'read_error_examples': errors, 'processes': rows,
            'scope': 'Read-only proc process CPU totals across threads at existing host-poll cadence. Snapshot thread counts are not continuous maxima. Rates require the same PID lifetime at both observations. First-seen processes have raw totals only; missing/exited/unreadable processes can make attribution incomplete. Observer cost is recorded; no causal or timing qualification follows.'}


def owned_snapshot(snapshot, root_pid):
    """Persist only the observer process and its sampled descendants."""
    rows = snapshot['processes']
    owned = {root_pid} if any(r['pid'] == root_pid for r in rows) else set()
    while True:
        expanded = owned | {r['pid'] for r in rows if r['ppid'] in owned}
        if expanded == owned:
            break
        owned = expanded
    return dict(snapshot, processes=[r for r in rows if r['pid'] in owned],
        native_thread_cpu=[r for r in snapshot['native_thread_cpu'] if r['pid'] in owned],
        root_pid=root_pid, unrelated_processes_omitted=len(rows)-len(owned),
        scope='Read-only sampled CPU counters for the observer and descendants; '
              'no arguments, stacks or unrelated process rows retained. '
              'Short-lived/exited tasks can be missed. Observer CPU overhead is retained; '
              'instrumented results do not qualify latency.')


def wait_with_cpu_samples(child, command, output, deadline):
    """Observe an existing child within its original absolute deadline."""
    previous = None
    with output.open('x') as log:
        while child.poll() is None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise subprocess.TimeoutExpired(command, 210)
            try:
                child.wait(timeout=min(2, remaining))
            except subprocess.TimeoutExpired:
                if time.monotonic() >= deadline:
                    raise
                previous = capture_process_cpu(previous)
                log.write(json.dumps(owned_snapshot(previous, os.getpid())) + '\n')
                log.flush()
