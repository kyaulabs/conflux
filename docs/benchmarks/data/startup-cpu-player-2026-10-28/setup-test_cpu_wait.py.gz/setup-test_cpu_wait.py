from pathlib import Path
import json,subprocess,tempfile,unittest
from unittest.mock import Mock,patch
from test_process_cpu import driver

class Child:
    def __init__(self, clock, overshoot=False):self.clock=clock;self.done=False;self.waits=[];self.overshoot=overshoot
    def poll(self):return 0 if self.done else None
    def wait(self, timeout):
        self.waits.append(timeout)
        if len(self.waits)==1:
            self.clock[0]+=timeout+(1 if self.overshoot else 0)
            raise subprocess.TimeoutExpired(['owned-child'],timeout)
        self.clock[0]+=.1;self.done=True;return 0

class CpuWaitTests(unittest.TestCase):
    def test_success_observes_existing_child_without_renewing_deadline(self):
        clock=[100.];child=Child(clock)
        with tempfile.TemporaryDirectory() as temp,patch.object(driver.time,'monotonic',side_effect=lambda:clock[0]),patch.object(driver,'capture_process_cpu',return_value={'fixture':True}) as capture,patch.object(driver,'owned_snapshot',return_value={'owned':True}):
            output=Path(temp)/'cpu.jsonl';driver.wait_with_cpu_samples(child,['owned-child'],output,105.)
            self.assertEqual(child.waits,[2,2]);capture.assert_called_once_with(None)
            self.assertEqual(json.loads(output.read_text()),{'owned':True})
    def test_already_expired_deadline_cannot_wait_or_sample(self):
        clock=[106.];child=Child(clock)
        with tempfile.TemporaryDirectory() as temp,patch.object(driver.time,'monotonic',side_effect=lambda:clock[0]),patch.object(driver,'capture_process_cpu') as capture,self.assertRaises(subprocess.TimeoutExpired):
            driver.wait_with_cpu_samples(child,['owned-child'],Path(temp)/'cpu.jsonl',105.)
        self.assertEqual(child.waits,[]);capture.assert_not_called()
    def test_slice_that_exhausts_original_deadline_is_not_renewed(self):
        clock=[104.];child=Child(clock,True)
        with tempfile.TemporaryDirectory() as temp,patch.object(driver.time,'monotonic',side_effect=lambda:clock[0]),patch.object(driver,'capture_process_cpu') as capture,self.assertRaises(subprocess.TimeoutExpired):
            driver.wait_with_cpu_samples(child,['owned-child'],Path(temp)/'cpu.jsonl',105.)
        self.assertEqual(child.waits,[1]);capture.assert_not_called()

if __name__=='__main__':unittest.main()
