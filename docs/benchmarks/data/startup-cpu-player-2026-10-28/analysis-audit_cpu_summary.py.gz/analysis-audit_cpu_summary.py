"""Reproduce sampled CPU totals and relate the complete hop population to power samples."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
LOCAL = BASE.parent / 'laptop-results-01/candidate/output-01'
REMOTE = BASE / 'apollo/cases/candidate/private-player-01/recordings/actual-player'


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def aggregate(groups, hz):
    result = []
    for identity, samples in groups.items():
        first, last = samples[0], samples[-1]
        assert all(a['observed_monotonic_ns'] <= b['observed_monotonic_ns'] and
                   a['cpu_ticks'] <= b['cpu_ticks'] for a, b in zip(samples, samples[1:]))
        rates = [r['cpu_cores_since_previous_observation'] for r in samples
                 if r['cpu_cores_since_previous_observation'] is not None]
        result.append(dict(identity=list(identity), comm=last['comm'], observations=len(samples),
            observed_CPU_seconds=(last['cpu_ticks'] - first['cpu_ticks']) / hz,
            observed_span_seconds=(last['observed_monotonic_ns'] - first['observed_monotonic_ns']) / 1e9,
            maximum_sampled_rate_cores=max(rates, default=0),
            maximum_sampled_threads=max(r['threads'] for r in samples)))
    return sorted(result, key=lambda r: -r['observed_CPU_seconds'])


expected = json.loads((BASE / 'cpu-summary-01.json').read_text())
verified = {}
inputs = []
for host, path in [('laptop', LOCAL / 'host-observations.jsonl'),
                   ('apollo', REMOTE / 'cpu-observations.jsonl')]:
    scans = rows(path)
    if host == 'laptop':
        scans = [r['owned_process_cpu'] for r in scans]
    hz_values = {s['ticks_per_second'] for s in scans}
    assert len(hz_values) == 1
    hz = hz_values.pop()
    processes, tasks = defaultdict(list), defaultdict(list)
    batches = []
    for scan in scans:
        for row in scan['processes']:
            processes[row['pid'], row['start_ticks']].append(row)
        for batch in scan['native_thread_cpu']:
            batches.append(batch)
            assert batch['matched_expected_exe'] and batch['complete'] and not batch['errors']
            for row in batch['threads']:
                tasks[batch['pid'], batch['process_start_ticks'], row['pid'], row['start_ticks']].append(row)
    cost = sum(s['scan_thread_cpu_ns'] / 1e6 for s in scans)
    actual = dict(samples=len(scans), retained_scan_CPU_ms=cost,
        mean_scan_CPU_ms=cost / len(scans), max_scan_CPU_ms=max(s['scan_thread_cpu_ns'] for s in scans) / 1e6,
        processes=aggregate(processes, hz), native_tasks=aggregate(tasks, hz),
        native_batches=len(batches), matched_complete_native_batches=len(batches), native_capture_error_count=0)
    assert actual == expected['hosts'][host], host
    verified[host] = dict(samples=len(scans), all_reported_CPU_totals_reproduced=True,
        scan_thread_CPU_ms=cost, native_thread_batches_complete=len(batches),
        process_stat_read_errors=sum(s['read_error_count'] for s in scans),
        process_stat_error_types=sorted({r['type'] for s in scans for r in s['read_error_examples']}))
    inputs.append(pin(path))

host_rows = rows(LOCAL / 'host-observations.jsonl')
cap = '/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_power_limit_uw'
first_low = next(r for r in host_rows if r['configured_power_caps'][cap] == 7500000)
hops = [r for r in rows(LOCAL / 'observations.jsonl') if r['type'] == 'record' and r['kind'] == 5]
before = sum(r['observed_ns'] < first_low['monotonic_ns'] for r in hops)
timing = dict(first_observed_7_5W_utc=first_low['at_utc'], first_observed_7_5W_ns=first_low['monotonic_ns'],
    complete_hops_before_first_observed_reduction=before,
    complete_hops_at_or_after_first_observed_reduction=len(hops)-before,
    last_complete_hop_ns=max(r['observed_ns'] for r in hops),
    last_hop_seconds_before_first_observed_reduction=(first_low['monotonic_ns']-max(r['observed_ns'] for r in hops))/1e9,
    scope='Point samples bound the observed transition; no completed hops are discarded and no sustained reduced-power qualification is claimed.')

passive_path = BASE / 'passive-cpu-temperature-01.jsonl'
passive = rows(passive_path)
hottest = max(passive, key=lambda r: r['max_millidegrees'])
hot = [r for r in passive if r['max_millidegrees'] >= 88000]
summary = dict(samples=len(passive), began_utc=passive[0]['utc'], ended_utc=passive[-1]['utc'],
    maximum_observed_millidegrees_C=hottest['max_millidegrees'],
    process_stat_read_errors=sum(r['read_error_count'] for r in passive),
    samples_at_or_above_88C=[dict(utc=r['utc'], temperature_millidegrees_C=r['max_millidegrees'],
        processes=r['top']) for r in hot],
    scope='Passive existing-system process counters after CONFLUX cleanup. Correlation with temperature is not proof of causation or attribution of earlier spikes.')
audit = dict(schema=1, sampled_CPU_summary_verified=verified, laptop_power_timing=timing,
    passive_observation=summary, input_pins=inputs+[pin(LOCAL/'observations.jsonl'), pin(passive_path)],
    qualified=False, all_service_hops_retained=True)
(BASE / 'cpu-audit-01.json').write_text(json.dumps(audit, indent=2, allow_nan=False)+'\n')
print(json.dumps(dict(CPU_totals_reproduced=verified, power_timing=timing,
    passive_samples=len(passive), passive_maximum_C=hottest['max_millidegrees']/1000)))
