import unittest
from test_process_cpu import driver

class OwnedCpuTests(unittest.TestCase):
    def test_descendant_filter_keeps_recursive_children_and_excludes_unrelated_rows(self):
        rows=[dict(pid=10,ppid=1),dict(pid=11,ppid=10),dict(pid=12,ppid=11),dict(pid=99,ppid=1)]
        snapshot=dict(processes=rows,native_thread_cpu=[dict(pid=11),dict(pid=99)])
        result=driver.owned_snapshot(snapshot,10)
        self.assertEqual([r['pid'] for r in result['processes']],[10,11,12])
        self.assertEqual(result['native_thread_cpu'],[dict(pid=11)])
        self.assertEqual(result['unrelated_processes_omitted'],1)
        self.assertEqual(len(snapshot['processes']),4)
    def test_missing_observer_does_not_publish_unrelated_processes(self):
        result=driver.owned_snapshot(dict(processes=[dict(pid=99,ppid=1)],native_thread_cpu=[dict(pid=99)]),10)
        self.assertEqual(result['processes'],[])
        self.assertEqual(result['native_thread_cpu'],[])

if __name__=='__main__':unittest.main()
