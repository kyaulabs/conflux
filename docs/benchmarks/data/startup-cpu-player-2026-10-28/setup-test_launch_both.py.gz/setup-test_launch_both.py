"""Offline checks for fresh conditions, concurrent dispatch and the original remote clock."""
from datetime import datetime,timedelta,timezone
from io import StringIO
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import threading
import unittest
from unittest.mock import patch

BASE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('staging_launch_test',BASE/'launch_both.py')
launch=importlib.util.module_from_spec(s);s.loader.exec_module(launch)

class LaunchTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(dir=BASE);self.addCleanup(self.temp.cleanup);self.base=Path(self.temp.name)
  (self.base/'laptop-plan.json').write_text('{}')
  binding=self.base/'remote-binding.json';binding.write_text('{}')
  packet=dict(schema=1,offline_checks_passed=True,hardware_started=False,source_head='dfff55ea78b6fcbe633a178e996371238803013d',
   host_tests_concurrent=True,no_retries=True,local_files=[],remote_binding=launch.pin(binding))
  (self.base/'packet-pins.json').write_text(json.dumps(packet));self.packet=packet
  self.reply=dict(physical_conditions_confirmed=True,question_item_id='offline-fixture',human_question='Offline fixture',human_reply='Offline fixture')
  self.reply.update({k:True for k in ('AC_power','lid_open','visible_window','screen_awake','Codex_minimized','other_work_paused','no_suspend')})
  self.commands=[];self.remote_failure=False
 def checked(self,command,**kwargs):
  return '0\n' if '--value' in command else 'LoadState=not-found\nMainPID=0\n'
 def mock_run(self,command,**kwargs):
  self.commands.append(command);self.barrier.wait(timeout=2)
  if command[0]=='ssh':
   self.assertIn('HostName=10.4.20.101',command);self.assertIn('HostKeyAlias=[apollo.kyaulabs]:4222',command)
   self.assertIn('StrictHostKeyChecking=yes',command);compile(kwargs['input'],'remote-entry','exec')
   return subprocess.CompletedProcess(command,255 if self.remote_failure else 0)
  self.assertIn('/usr/bin/kde-inhibit',command);self.assertIn('--power',command);self.assertIn('--screenSaver',command)
  self.assertIn('--property=Restart=no',command)
  return subprocess.CompletedProcess(command,0)
 def invoke(self,live):
  with patch.object(launch,'BASE',self.base),patch('sys.argv',['entry']+(['--launch'] if live else [])), \
   patch('sys.stdin',StringIO(json.dumps(self.reply))),patch.object(launch.subprocess,'check_output',side_effect=self.checked), \
   patch.object(launch.subprocess,'run',side_effect=self.mock_run),patch('builtins.print'):
   return launch.main()
 def test_dry_mode_never_queries_or_dispatches_hosts(self):
  self.assertEqual(self.invoke(False),0);self.assertEqual(self.commands,[])
  self.assertFalse((self.base/'readiness.json').exists())
 def test_missing_physical_condition_prevents_readiness_and_dispatch(self):
  self.reply['AC_power']=False
  with self.assertRaises(AssertionError):self.invoke(True)
  self.assertEqual(self.commands,[]);self.assertFalse((self.base/'readiness.json').exists())
 def test_both_dispatches_happen_concurrently_and_once(self):
  self.barrier=threading.Barrier(2);self.assertEqual(self.invoke(True),0);self.assertEqual(len(self.commands),2)
  result=json.loads((self.base/'both-dispatch.json').read_text());self.assertTrue(result['hosts_submitted_concurrently']);self.assertFalse(result['retries'])
  with self.assertRaises(AssertionError):self.invoke(True)
  self.assertEqual(len(self.commands),2)
 def test_transport_failure_is_retained_without_retry(self):
  self.barrier=threading.Barrier(2);self.remote_failure=True;self.assertEqual(self.invoke(True),1)
  self.assertEqual(len(self.commands),2);self.assertEqual(json.loads((self.base/'both-dispatch.json').read_text())['apollo']['exit'],255)
 def test_expired_remote_clock_cannot_create_readiness_or_query_units(self):
  human=dict(original_readiness_utc=(datetime.now(timezone.utc)-timedelta(seconds=121)).isoformat())
  with patch.object(launch,'REMOTE',str(self.base)):
   script=launch.remote_script(self.packet,human)
  with patch.object(launch.subprocess,'check_output') as query,self.assertRaises(AssertionError):exec(compile(script,'remote-expired','exec'),{})
  query.assert_not_called();self.assertFalse((self.base/'pair-readiness-01.json').exists())

if __name__=='__main__':unittest.main(verbosity=2)
