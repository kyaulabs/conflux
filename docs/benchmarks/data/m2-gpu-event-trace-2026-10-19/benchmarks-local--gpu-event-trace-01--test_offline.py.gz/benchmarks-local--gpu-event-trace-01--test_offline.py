#!/usr/bin/env python3
"""Offline source-drift and compiled formatting/parser regression checks."""
from pathlib import Path
import hashlib
import os
import subprocess
import unittest

from apply_overlay import ANCHOR, SOURCE_SHA256, apply, replace_once
from parse_trace import parse_trace

HERE = Path(__file__).resolve().parent


class TraceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (HERE / "promoted-ggml-vulkan.cpp").read_bytes()
        cls.snippet = (HERE / "event_trace.inc").read_text()

    def run_harness(self, mode="ties", flag="1"):
        environment = dict(os.environ)
        environment.pop("GGML_VK_PERF_TRACE_TOP", None)
        if flag is not None:
            environment["GGML_VK_PERF_TRACE_TOP"] = flag
        run = subprocess.run([str(HERE / "trace_harness"), mode], env=environment,
                             capture_output=True, text=True, timeout=5, check=True)
        self.assertEqual(run.stdout, "")
        return run.stderr

    def test_pin_and_single_insertion(self):
        self.assertEqual(hashlib.sha256(self.source).hexdigest(), SOURCE_SHA256)
        changed = apply(self.source, self.snippet)
        self.assertEqual(changed.count(self.snippet.encode()), 1)
        self.assertEqual(changed.replace(self.snippet.encode(), b"", 1), self.source)
        # Existing query, aggregate, wait, submission and GPU text is byte-identical.
        with self.assertRaisesRegex(ValueError, "SHA256"):
            apply(changed, self.snippet)

    def test_source_drift_rejected(self):
        with self.assertRaisesRegex(ValueError, "SHA256"):
            apply(self.source + b"\n", self.snippet)
        for drift in ["", ANCHOR + ANCHOR]:
            with self.assertRaisesRegex(ValueError, "exactly one"):
                replace_once(drift, ANCHOR, "replacement")

    def test_deterministic_top32_ties_count_sum_max(self):
        text = self.run_harness()
        self.assertEqual(text, self.run_harness())
        trace = parse_trace(text)
        expected = [(i, 500000 if i in (32, 33) else (i % 41 + 1) * 100)
                    for i in range(1, 1558)]
        ordered = sorted(expected, key=lambda event: (-event[1], event[0]))[:32]
        self.assertEqual(trace["events"], 1557)
        self.assertEqual(trace["total_ns"], sum(event[1] for event in expected))
        self.assertEqual(trace["max_ns"], 500000)
        self.assertEqual([(r["query"], r["duration_ns"]) for r in trace["rows"]], ordered)
        self.assertEqual([r["node"] for r in trace["rows"]], [e[0] for e in ordered])
        self.assertEqual(ordered[:2], [(32, 500000), (33, 500000)])

    def test_exact_flag_profiler_and_concurrent_guards(self):
        for value in [None, "", "0", "true", "11"]:
            self.assertEqual(self.run_harness(flag=value), "")
        for mode in ["concurrent", "no-profiler"]:
            self.assertEqual(self.run_harness(mode), "")

    def test_repeated_tensor_pointer_preserves_graph_index(self):
        trace = parse_trace(self.run_harness("duplicates"))
        self.assertEqual([(row["query"], row["node"]) for row in trace["rows"][:2]],
                         [(32, 32), (33, 33)])

    def test_zero_and_fewer_than32(self):
        self.assertEqual(parse_trace(self.run_harness("zero"))["selected"], 0)
        small = parse_trace(self.run_harness("small"))
        self.assertEqual(small["selected"], 3)
        self.assertEqual([r["query"] for r in small["rows"]], [3, 2, 1])

    def test_float_period_matches_existing_conversion(self):
        base = parse_trace(self.run_harness())
        scaled = parse_trace(self.run_harness("period"))
        self.assertEqual(scaled["total_ns"], base["total_ns"] * 5 // 4)
        self.assertEqual(scaled["max_ns"], 625000)

    def test_output_bound_and_sanitization(self):
        text = self.run_harness("bound")
        self.assertLess(len(text.encode()), 16384)
        trace = parse_trace(text)
        self.assertEqual(len(trace["rows"]), 32)
        self.assertEqual(len(trace["rows"][0]["name"]), 48)
        self.assertEqual(len(trace["rows"][0]["op"]), 160)
        sanitized = parse_trace(self.run_harness("sanitize"))
        self.assertTrue(sanitized["rows"][0]["name"].startswith("___"))
        self.assertEqual(sanitized["rows"][0]["op"], "FUSED ADD___")
        (HERE / "offline-bound-example.stderr").write_text(text)

    def test_overflow_explicit_and_rejected(self):
        text = self.run_harness("overflow")
        self.assertIn("overflow=1", text)
        with self.assertRaises(ValueError):
            parse_trace(text)

    def test_parser_rejects_malformed_data(self):
        text = self.run_harness("small")
        invalid = ["", text + text, text[:-4], text.replace("selected=3", "selected=32"),
                   text.replace("total_ns=900", "total_ns=1"),
                   text.replace("max_ns=400", "max_ns=401"),
                   text.replace("query=3", "query=0"),
                   text.replace("node=3", "node=4"),
                   text.replace("rank=1", "rank=2"),
                   text.replace("name=\"tensor_3\"", "name=\"bad\\name\""),
                   text.replace("overflow=0", "overflow=1"),
                   text.replace("dst=1,2,3,4", "dst=-1,2,3,4"),
                   text.replace("duration_ns=400", "duration_ns=18446744073709551616"),
                   "x" * 65537 + text]
        lines = text.splitlines()
        invalid += ["\n".join([lines[0], lines[2].replace("rank=2", "rank=1"),
                              lines[1].replace("rank=1", "rank=2"), lines[3]]) + "\n",
                    text.replace("query=2", "query=3"),
                    text.replace("node=3", "node=0").replace("node=2", "node=0").replace("node=1", "node=0"),
                    text.replace("node=3", "node=0"),
                    text.replace("node=2", "node=3")]
        for malformed in invalid:
            with self.subTest(malformed=malformed[:100]):
                with self.assertRaises(ValueError):
                    parse_trace(malformed)

    def test_parser_omitted_total_and_tie_bounds(self):
        def synthetic(total, last_duration=1, first_query=1, events=33):
            header = (f"conflux_vk_trace_v1 events={events} graph_nodes={events} total_ns={total} "
                      f"max_ns={last_duration} selected=32 limit=32 overflow=0\n")
            return header + "".join(
                f'conflux_vk_trace_v1 rank={rank} query={query} node={query-1} '
                f'duration_ns={last_duration} dst=1,2,3,4 name="n" op="ADD"\n'
                for rank, query in enumerate(range(first_query, first_query + 32), 1))
        self.assertEqual(parse_trace(synthetic(33))["total_ns"], 33)
        self.assertEqual(parse_trace(synthetic(0, 0))["total_ns"], 0)
        self.assertEqual(parse_trace(synthetic(32, first_query=2))["total_ns"], 32)
        for text in [synthetic((1 << 64) - 1), synthetic(34), synthetic(1, 0),
                     synthetic(33, first_query=2), synthetic(0, 0, first_query=2)]:
            with self.subTest(header=text.splitlines()[0]):
                with self.assertRaises(ValueError):
                    parse_trace(text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
