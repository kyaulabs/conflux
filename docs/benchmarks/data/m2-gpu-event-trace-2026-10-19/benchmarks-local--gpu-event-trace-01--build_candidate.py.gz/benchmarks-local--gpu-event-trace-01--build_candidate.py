#!/usr/bin/env python3
"""CPU-only compile/relink from the promoted CMake commands and static objects."""
from pathlib import Path
import difflib
import hashlib
import json
import shlex
import shutil
import subprocess
import time

from apply_overlay import apply

HERE = Path(__file__).resolve().parent
BUILD = HERE / "build"
RECIPE = json.loads((HERE / "build-recipe.json").read_text())
PROMOTED = Path(RECIPE["promoted_build"])
PINS = json.loads((HERE / "source-pins.json").read_text())["inputs"]


def pin(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def require_pins():
    for expected in PINS:
        if pin(expected["path"]) != expected:
            raise ValueError("pinned build input changed: " + expected["path"])


def run(command, label, receipt, timeout=240):
    started = time.monotonic()
    completed = subprocess.run(command, cwd=HERE, capture_output=True, text=True, timeout=timeout)
    (HERE / (label + ".stdout")).write_text(completed.stdout)
    (HERE / (label + ".stderr")).write_text(completed.stderr)
    receipt["commands"].append(dict(label=label, argv=command, returncode=completed.returncode,
                                    elapsed_seconds=time.monotonic() - started))
    if completed.returncode:
        raise ValueError(label + " failed; see " + label + ".stderr")
    return completed.stdout


def build():
    receipt = dict(schema=1, status="preparing", source_head=RECIPE["source_head"],
                   execution_scope="CPU compiler, archiver and linker only; no native/model/Vulkan/shader startup",
                   maximum_parallel_compiles=2, actual_parallel_compiles=1,
                   commands=[], physical_launch=False, quality_equivalence="unverified")
    try:
        require_pins()
        BUILD.mkdir(exist_ok=True)
        original = (HERE / "promoted-ggml-vulkan.cpp").read_bytes()
        snippet = (HERE / "event_trace.inc").read_text()
        changed = apply(original, snippet)
        source = BUILD / "ggml-vulkan.cpp"
        source.write_bytes(changed)
        (HERE / "overlay.diff").write_text("".join(difflib.unified_diff(
            original.decode().splitlines(keepends=True), changed.decode().splitlines(keepends=True),
            fromfile="promoted/ggml-vulkan.cpp", tofile="trace/ggml-vulkan.cpp")))
        receipt["overlay"] = dict(base_sha256=hashlib.sha256(original).hexdigest(),
            snippet_sha256=hashlib.sha256(snippet.encode()).hexdigest(), candidate_source=pin(source))
        compile_args = shlex.split(RECIPE["promoted_compile_command"]["command"])
        if compile_args.count("-o") != 1 or compile_args.count("-c") != 1:
            raise ValueError("unexpected promoted compile command")
        if compile_args[compile_args.index("-c") + 1] != RECIPE["promoted_compile_command"]["file"]:
            raise ValueError("unexpected promoted source argument")
        obj = BUILD / "ggml-vulkan.cpp.o"
        dependencies = BUILD / "ggml-vulkan.cpp.d"
        compile_args[compile_args.index("-o") + 1] = str(obj)
        compile_args[compile_args.index("-c") + 1] = str(source)
        compile_args += ["-MMD", "-MF", str(dependencies)]
        run(compile_args, "compile", receipt)

        archive_original = PROMOTED / "audiocpp/ggml/src/ggml-vulkan/libggml-vulkan.a"
        members_before = run(["/bin/ar", "t", str(archive_original)], "members-before", receipt).splitlines()
        member = RECIPE["replacement_archive_member"]
        if members_before.count(member) != 1 or obj.name != member:
            raise ValueError("expected exactly one promoted backend archive member")
        archive = BUILD / "libggml-vulkan.a"
        shutil.copy2(archive_original, archive)
        run(["/bin/ar", "r", str(archive), str(obj)], "archive", receipt)
        run(["/bin/ranlib", str(archive)], "archive-index", receipt)
        members_after = run(["/bin/ar", "t", str(archive)], "members-after", receipt).splitlines()
        if members_before != members_after:
            raise ValueError("candidate archive member names/order changed")

        libraries = []
        for item in shlex.split(RECIPE["promoted_link_libraries"]):
            if item == "audiocpp/ggml/src/ggml-vulkan/libggml-vulkan.a":
                libraries.append(str(archive))
            elif item.startswith("-") or Path(item).is_absolute():
                libraries.append(item)
            else:
                libraries.append(str(PROMOTED / item))
        native = BUILD / "conflux-stem-runtime"
        native_object = PROMOTED / "CMakeFiles/conflux-stem-runtime.dir/htdemucs_segment.cpp.o"
        link_args = [compile_args[0], "-O3", "-DNDEBUG", str(native_object), "-o", str(native),
                     "-Wl,--dependency-file=" + str(BUILD / "link.d")] + libraries
        run(link_args, "link", receipt)

        # CPU-only exact-member comparison: all retained shader bytes stay identical.
        # ar output is binary: compare without decoding or executing it.
        member_bytes = subprocess.run(["/bin/ar", "p", str(archive), member],
                                      capture_output=True, timeout=30, check=True).stdout
        if hashlib.sha256(member_bytes).hexdigest() != hashlib.sha256(obj.read_bytes()).hexdigest():
            raise ValueError("backend archive member differs from compiled object")
        retained = [name for name in members_before if name != member]
        retained_hashes = []
        for input_archive in [archive_original, archive]:
            payload = subprocess.run(["/bin/ar", "p", str(input_archive)] + retained,
                                     capture_output=True, timeout=30, check=True).stdout
            retained_hashes.append(hashlib.sha256(payload).hexdigest())
        if retained_hashes[0] != retained_hashes[1]:
            raise ValueError("retained shader archive bytes changed")
        receipt["retained_shader_payload_sha256"] = retained_hashes[0]
        require_pins()
        dependency_text = dependencies.read_text().replace("\\\n", " ")
        header_paths = shlex.split(dependency_text.split(":", 1)[1])
        receipt["compile_dependencies"] = [pin(path) for path in dict.fromkeys(header_paths)]
        receipt["candidate"] = pin(native)
        receipt["candidate_object"] = pin(obj)
        receipt["candidate_archive"] = pin(archive)
        receipt["promoted_runtime_unchanged"] = pin(PROMOTED / "conflux-stem-runtime")
        receipt["archive_members"] = len(members_after)
        receipt["status"] = "compiled-and-linked-no-runtime-execution"
    except Exception as error:
        receipt["status"] = "failed"
        receipt["error"] = str(error)
        raise
    finally:
        (HERE / "build-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in ["status", "candidate", "promoted_runtime_unchanged"]}, indent=2))


if __name__ == "__main__":
    build()
