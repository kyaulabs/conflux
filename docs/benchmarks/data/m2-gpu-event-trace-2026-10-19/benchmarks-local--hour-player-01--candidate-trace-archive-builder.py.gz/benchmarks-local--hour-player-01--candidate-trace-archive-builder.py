#!/usr/bin/env python3
"""Archive closed candidate PCM/trace text evidence without executing its code or using Git."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import stat
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HOUR = ROOT / "benchmarks-local/hour-player-01"
PROFILE = ROOT / "benchmarks-local/gpu-event-trace-01"
DEST = ROOT / "docs/benchmarks/data/m2-gpu-event-trace-2026-10-19"
STAGE = HOUR / "candidate-trace-archive-stage"
RAW = HOUR / "candidate-trace-archive-raw"
INVENTORY = HOUR / "candidate-trace-archive-inputs.json"
SUMMARY = HOUR / "candidate-trace-archive-summary.json"
SCAN_LOG = HOUR / "candidate-trace-archive-gitleaks.log"
SCAN_REPORT = HOUR / "candidate-trace-archive-gitleaks-findings.json"
HEAD = "78b59e727b0a3708e90f02f5a03d4f8d6ed3fcbd"
LIMIT = 16 * 1024 * 1024
ALLOWED = {".json", ".jsonl", ".py", ".patch", ".diff", ".stderr", ".stdout", ".txt", ".log",
           ".cpp", ".hpp", ".h", ".inc", ".cmake", ".d"}


def pin(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def read(path):
    assert path.is_relative_to(ROOT)
    for item in (path, *path.relative_to(ROOT).parents):
        actual = item if item.is_absolute() else ROOT / item
        assert not actual.is_symlink(), str(actual)
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size <= LIMIT
    data = path.read_bytes()
    after = path.lstat()
    signature = lambda info: (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
    assert signature(before) == signature(after) and len(data) == before.st_size
    assert b"\0" not in data
    data.decode("utf-8")
    return data


def dump(path, value):
    data = (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(data)
    return data


def profile_paths():
    included, excluded = set(), []
    for folder, dirs, names in os.walk(PROFILE, followlinks=False):
        parent = Path(folder)
        kept = []
        for name in sorted(dirs):
            path = parent / name
            if name == "__pycache__" or path.is_symlink():
                excluded.append({"path": str(path.relative_to(ROOT)), "reason": "pycache_or_symlink_directory"})
            else:
                kept.append(name)
        dirs[:] = kept
        for name in sorted(names):
            path = parent / name
            if path.is_symlink():
                excluded.append({"path": str(path.relative_to(ROOT)), "reason": "symlink"})
            elif path.suffix in ALLOWED or name in {"stdout", "stderr"}:
                assert stat.S_ISREG(path.lstat().st_mode)
                included.add(path)
            else:
                excluded.append({"path": str(path.relative_to(ROOT)), "reason": "outside_named_text_suffixes"})
    return included, excluded


assert not any(os.path.lexists(path) for path in (DEST, STAGE, RAW, INVENTORY, SUMMARY, SCAN_LOG, SCAN_REPORT))
paths, excluded = profile_paths()
profile_inputs = set(paths)
paths.add(Path(__file__).resolve())
paths.add(ROOT / "benchmarks-local/m2-graph-phase-2026-10-18/flash-promoted-repro-01/result.json")
paths.update(path for path in HOUR.glob("candidate-codex-01*") if path.is_file())
paths.update(HOUR / name for name in (
    "gpu-event-trace-independent-cpu-check.json", "gpu-event-trace-independent-driver-checks.json",
    "gpu-event-trace-independent-review.json", "gpu-event-trace-terminal-plan-audit.json",
    "ui-exposure-followup-review.json", "profile05-merge-signature.json",
    "profile05-pr33-complete.json", "profile05-feature-ci.json", "profile05-pr-ci.json",
    "profile05-develop-ci.json", "profile05-feature-coverage-audit.json",
    "profile05-pr-merged.json", "profile05-postmerge-source-audit.json",
    "profile05-preapproval.json", "profile05-review.json", "profile05-root-verification.json"))
assert all(path.suffix in ALLOWED or path.name in {"stdout", "stderr"} for path in paths)


# Freeze the complete source list and every source byte hash before creating raw/stage files.
frozen = {str(path.relative_to(ROOT)): read(path) for path in sorted(paths)}
inputs = {name: pin(data) for name, data in frozen.items()}
assert sum(item["bytes"] for item in inputs.values()) <= LIMIT
inventory = {
    "schema": "conflux.candidate-trace-archive-inputs.v1", "source_head": HEAD,
    "profile_scope": str(PROFILE.relative_to(ROOT)), "source_input_count": len(inputs),
    "source_input_bytes": sum(item["bytes"] for item in inputs.values()),
    "maximum_raw_bytes": LIMIT, "inputs": inputs, "excluded_profile_paths": excluded,
    "scope": "All named UTF-8 candidate source/scripts/tests/generated backend/metadata/raw logs/history, plus explicit small reference, audits and PR33 receipts and this builder. Generated inventory/summary and scanner receipts are separately identified archive controls. No root CURRENT state, raw PCM, audio, model, executable, cache or CI artifact directory."
}
inventory_data = dump(INVENTORY, inventory)

def load(path):
    return json.loads(frozen[str(path.relative_to(ROOT))])


result = load(PROFILE / "candidate-pcm-trace-codex-01/result.json")
requests = result["requests"]
operation = load(HOUR / "candidate-codex-01-operation-audit.json")
host = load(HOUR / "candidate-codex-01-host-audit.json")
signature = load(HOUR / "profile05-merge-signature.json")
complete = load(HOUR / "profile05-pr33-complete.json")
plan = load(PROFILE / "codex-launch-plan-01.json")
human = load(PROFILE / "human-readiness-codex-01.json")
build = load(PROFILE / "build-receipt.json")
proof_path = ROOT / "benchmarks-local/m2-graph-phase-2026-10-18/flash-promoted-repro-01/result.json"
proof = load(proof_path)
assert signature["sha"] == complete["merge_commit"] == result["repository_head"] == result["head_after"] == plan["repository_head"] == HEAD
assert signature["commit"]["verification"]["verified"] is True and signature["commit"]["verification"]["reason"] == "valid"
assert build["source_head"] == "7c130e1a9cef91639a219db30f78857f8c515772"
assert result["status"] == "passed" and len(requests) == result["planned_requests"] == 16
assert result["exact_pcm_match"] and all(row["completed"] and row["exact_pcm_match"] and row["trace_valid"] for row in requests)
assert len({row["case_id"] for row in requests}) == len({row["input_sha256"] for row in requests}) == len({row["output_sha256"] for row in requests}) == 16
assert not result["errors"] and not result["watchdog_errors"] and result["cleanup_complete"]
assert result["pins_before"] == result["full_hashes_before_readiness"] == result["pins_after"] and result["pins_unchanged"]
assert len(result["pins_before"]) == 68 and all(host["checks"].values())
assert inputs[str(proof_path.relative_to(ROOT))]["sha256"] == "44554b8e1caca9e92a49be7b9cc0e05ba7248f0091b4cdfc005e87e2c87ffe70"
references = {row["id"]: row for row in proof["runtimes"][0]["requests"]}
assert set(references) == {row["case_id"] for row in requests}
for row in requests:
    reference = references[row["case_id"]]
    assert row["input_sha256"] == reference["input_sha256"]
    assert row["output_sha256"] == row["expected_output_sha256"] == reference["output_sha256"]
assert human == result["human_readiness_before_setup"]["record"] == result["human_readiness_before_native"]["record"]
assert human["Codex_minimized"] is True and human["Codex_closed"] is False
assert human["plan_sha256"] == inputs[str((PROFILE / "codex-launch-plan-01.json").relative_to(ROOT))]["sha256"]
assert result["pins_before"]["runtime"]["sha256"] == build["candidate"]["sha256"] == "75ce548efb92f85f3a10522bf5983d78e77ac80b825cfa642aa6a84cde827cac"
assert result["pins_before"]["baseline_runtime"]["sha256"] == proof["runtime_sha256"] == "6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53"
assert operation["trace_validation"]["events_total"] == 24912 and operation["trace_validation"]["top_rows_saved_total"] == 512
assert all(row["profile"]["trace"]["events"] == 1557 and row["profile"]["trace"]["selected"] == 32 for row in requests)
assert max(row["profile"]["trace"]["max_ns"] for row in requests) == 48099636
summary = {
    "schema": "conflux.m2-gpu-event-trace-summary.v1", "source_head": HEAD,
    "build_source_head": build["source_head"],
    "status": "sixteen_case_candidate_exact_PCM_and_bounded_GPU_interval_trace_validation_passed",
    "m2_open": True, "sustained_actual_player_qualified": False,
    "source_signature": {"kind": "retained_GitHub_commit_API_receipt", "verified": True, "reason": "valid",
                         "receipt": "benchmarks-local/hour-player-01/profile05-merge-signature.json",
                         "receipt_sha256": inputs["benchmarks-local/hour-player-01/profile05-merge-signature.json"]["sha256"]},
    "launch": {"name": "candidate-pcm-trace-codex-01", "origin": plan["launch_origin"],
               "Codex_minimized": True, "Codex_closed": False,
               "human_question": human["human_question"], "human_reply": human["human_reply"],
               "confirmation": "Direct human reply to Codex readiness question; not terminal READY or a closed-Codex claim.",
               "authoritative_plan": str((PROFILE / "codex-launch-plan-01.json").relative_to(ROOT)),
               "human_readiness": str((PROFILE / "human-readiness-codex-01.json").relative_to(ROOT)),
               "old_external_terminal_plan_used": False,
               "historical_plan_note": "Earlier unarmed preparation receipts and external-terminal plans are retained as history; they do not describe the actual launcher or completed minimized-Codex run."},
    "PCM": {"unique_completed_cases": 16, "unique_input_hashes": 16, "unique_output_hashes": 16,
            "all_exact_own_Flash_reference_matches": True,
            "immutable_reference_sha256": inputs[str(proof_path.relative_to(ROOT))]["sha256"],
            "baseline_runtime_sha256": result["pins_before"]["baseline_runtime"]["sha256"],
            "candidate_runtime_sha256": result["pins_before"]["runtime"]["sha256"],
            "candidate_distinct_from_baseline": True,
            "model_sha256": result["pins_before"]["model"]["sha256"],
            "shape_per_output": [4, 343980, 2], "dtype": "<f4", "bytes_per_output": 11007360,
            "scope": "Exact recorded full/seek float output hashes, not a new musical judgment or raw PCM archive."},
    "timings_descriptive_only": {"request_wall_ms": operation["timings_descriptive_only"]["request_and_nested_phase_distributions"]["request_wall_ms"],
                                "graph_compute_ms": operation["timings_descriptive_only"]["request_and_nested_phase_distributions"]["graph_compute_ms"],
                                "startup_wall_ms": result["startup_wall_ms"],
                                "native_profile_elapsed_seconds": result["profile_elapsed_seconds"],
                                "total_elapsed_including_admission_seconds": result["elapsed_seconds"],
                                "limit": "Fixed sixteen-case diagnostic sequence. Native phases are nested; request walls are not actual-player service-hop p99 or production latency."},
    "trace": {"graphs": 16, "events_per_graph": 1557, "events_total": 24912, "graph_nodes": 2871,
              "saved_top_rows_per_graph": 32, "saved_top_rows_total": 512,
              "exact_interval_total_ns": operation["trace_validation"]["exact_summed_interval_ns"],
              "maximum_interval_ns": 48099636, "maximum_interval_ms": 48.099636,
              "maximum_node": 2026, "maximum_operation": "MUL_MAT f16 m=172032 n=96 k=432",
              "all_graph_maxima_same_node": True,
              "aggregate_and_strict_trace_checks_match": True,
              "category_summary": operation["operation_families"],
              "limit": "Individual node/fusion timestamp intervals include synchronization and internal work; they are not exclusive individual GPU dispatch or shader durations."},
    "pins": {"count": 68, "initial_before_readiness_after_identical": True,
             "post_wait_metadata_binds_frozen_hashes": True, "independent_current_full_rehash_matches": True,
             "candidate_build_receipt_sha256": result["pins_before"]["build_receipt"]["sha256"],
             "driver_sha256": result["pins_before"]["driver"]["sha256"]},
    "host_and_cleanup": {"fresh_admission_package_C": 43, "after_profile_package_C": 96,
                         "thermal_limit": "Two discrete CPU/package observations; no exposure duration, true peak, GPU temperature or causality inferred.",
                         "exact_result_UTC_window": host["exact_result_UTC_window"],
                         "kernel_conclusion": host["kernel_conclusion"],
                         "native_and_readiness_original_identities_independently_absent": True,
                         "fixed_spool_independently_absent": True, "cleanup_complete": True,
                         "native_returncode": result["cleanup"]["native_returncode"],
                         "returncode_limit": "-9 follows sixteen completed requests and owned-child cleanup; it is not an in-flight cancellation test."},
    "unchanged_acceptance": {"strict_service_p99_target_ms": 4095, "p99_qualified": False,
                             "audio_UI_qualified": False, "cancellation_qualified": False,
                             "actual_hour_qualified": False, "musical_quality_rejudged": False},
    "claim_limits": ["No p99/tail, sustained playback, cancellation, audio/UI or actual-hour qualification.",
                     "No causal fix claim about Codex, minimization, hashing, temperature, Qt exposure or the earlier GPU hang.",
                     "No raw PCM/audio/model/executable/object/static archive is included; text inventories retain hashes and paths only.",
                     "UI exposure review is secondary read-only follow-up; no guard or implementation change is implied."],
    "next_step": operation["best_next_step"],
    "independent_audits": ["benchmarks-local/hour-player-01/" + name for name in (
        "candidate-codex-01-operation-audit.json", "candidate-codex-01-host-audit.json",
        "gpu-event-trace-independent-review.json", "gpu-event-trace-terminal-plan-audit.json",
        "ui-exposure-followup-review.json")]
}
summary_data = dump(SUMMARY, summary)

STAGE.mkdir(mode=0o700)
RAW.mkdir(mode=0o700)
files, uncompressed, origins = {}, {}, {}


def add(origin_path, data):
    origin_name = str(origin_path.relative_to(ROOT))
    name = origin_name.replace("/", "--")
    packed_name = name + ".gz"
    assert packed_name not in files
    (RAW / name).write_bytes(data)
    packed = gzip.compress(data, mtime=0)
    assert packed[4:8] == b"\0\0\0\0"
    (STAGE / packed_name).write_bytes(packed)
    files[packed_name] = pin(packed)
    uncompressed[packed_name] = pin(data)
    origins[packed_name] = {"path": origin_name, **pin(data)}


for name, data in frozen.items():
    add(ROOT / name, data)
add(INVENTORY, inventory_data)
add(SUMMARY, summary_data)
raw_scanned_bytes = sum(item["bytes"] for item in uncompressed.values())
raw_scanned_files = len(files)
assert raw_scanned_bytes <= LIMIT
with SCAN_LOG.open("xb") as stream:
    scan = subprocess.run(["gitleaks", "dir", str(RAW), "--redact", "--no-color", "--report-format", "json",
                           "--report-path", str(SCAN_REPORT)], stdin=subprocess.DEVNULL,
                          stdout=stream, stderr=subprocess.STDOUT, timeout=60)
assert scan.returncode == 0 and json.loads(read(SCAN_REPORT)) == []
for path in (SCAN_LOG, SCAN_REPORT):
    add(path, read(path))

# Verify all archive layers against their current origins and the original frozen source list.
assert profile_paths() == (profile_inputs, excluded)
for name, expected in inputs.items():
    assert pin(read(ROOT / name)) == expected
for name, expected in files.items():
    packed = (STAGE / name).read_bytes()
    data = gzip.decompress(packed)
    origin = origins[name]
    assert pin(packed) == expected and pin(data) == uncompressed[name]
    assert pin(data) == {key: origin[key] for key in ("bytes", "sha256")}
    assert data == read(ROOT / origin["path"]) and packed == gzip.compress(data, mtime=0)
verification = {
    "schema": "conflux.m2-gpu-event-trace.v1", "source_head": HEAD,
    "source_signature": summary["source_signature"], "status": summary["status"],
    "m2_open": True, "sustained_actual_player_qualified": False, "summary": summary,
    "files": files, "uncompressed": uncompressed, "origins": origins,
    "source_inputs": inputs, "source_input_count": len(inputs),
    "raw_source_input_bytes": inventory["source_input_bytes"],
    "raw_scanned_input_bytes": raw_scanned_bytes, "raw_scanned_file_count": raw_scanned_files,
    "maximum_raw_bytes": LIMIT, "raw_secret_scan_exit": scan.returncode,
    "raw_secret_scan_findings": 0, "source_inventory_unchanged_after_packaging": True,
    "generated_controls": [str(INVENTORY.relative_to(ROOT)), str(SUMMARY.relative_to(ROOT))],
    "scanner_outputs_added_after_scan": [str(SCAN_LOG.relative_to(ROOT)), str(SCAN_REPORT.relative_to(ROOT))],
    "scope": "Closed UTF-8 metadata/source/raw-log/history only; deterministic gzip mtime zero with compressed/raw/origin digests. All named candidate B inputs frozen and rechecked; no root CURRENT, raw PCM/audio/model/executable/cache/CI artifact directory. Raw Gitleaks scan precedes packaging its empty finding and log receipts; verification itself and scanner output are not in that scan. Source signature is the retained valid GitHub receipt, not a new local Git invocation."
}
dump(STAGE / "verification.json", verification)
STAGE.rename(DEST)
print(json.dumps({"destination": str(DEST), "files": len(files) + 1, "source_inputs": len(inputs),
                  "raw_scanned_bytes": raw_scanned_bytes, "compressed_bytes": sum(item["bytes"] for item in files.values()),
                  "verification": pin((DEST / "verification.json").read_bytes()),
                  "source_head": HEAD, "raw_secret_scan_exit": scan.returncode,
                  "sustained_actual_player_qualified": False}, indent=2))
