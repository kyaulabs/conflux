#!/usr/bin/env python3
"""Apply one post-query diagnostic insertion to the exact promoted source."""
from pathlib import Path
import hashlib
import sys

SOURCE_SHA256 = "e36ece6d9bd1219085c77e58e6f624da19c349fc1dd214469367d8824501f996"
ANCHOR = """                ctx->perf_logger->log_timing(node, name, uint64_t((timestamps[i] - timestamps[i-1]) * ctx->device->properties.limits.timestampPeriod));
            }
        } else {
            // Log each group of nodes
"""


def replace_once(source, anchor, replacement):
    count = source.count(anchor)
    if count != 1:
        raise ValueError(f"expected exactly one post-query anchor; got {count}")
    return source.replace(anchor, replacement, 1)


def apply(source, snippet):
    if hashlib.sha256(source).hexdigest() != SOURCE_SHA256:
        raise ValueError("promoted source SHA256 mismatch")
    original = source.decode("utf-8")
    prefix, suffix = ANCHOR.split("        } else {", 1)
    replacement = prefix + snippet + "        } else {" + suffix
    changed = replace_once(original, ANCHOR, replacement)
    if changed.replace(replacement, ANCHOR, 1) != original:
        raise ValueError("overlay reverse check failed")
    return changed.encode("utf-8")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: apply_overlay.py PROMOTED_CPP OUTPUT_CPP")
    snippet = Path(__file__).with_name("event_trace.inc").read_text()
    output = apply(Path(sys.argv[1]).read_bytes(), snippet)
    Path(sys.argv[2]).write_bytes(output)
    print(hashlib.sha256(output).hexdigest())
