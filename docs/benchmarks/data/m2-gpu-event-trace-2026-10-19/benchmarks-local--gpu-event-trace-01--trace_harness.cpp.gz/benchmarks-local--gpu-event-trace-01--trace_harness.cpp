// CPU-only test scaffold for the exact inserted post-query text. No Vulkan APIs.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

struct Tensor { int64_t ne[4]; char name[512]; std::string op; };
struct Logger {
    std::string get_node_fusion_name(const Tensor * n, const char * fusion, uint64_t * flops) {
        *flops = 0;
        return (fusion == nullptr ? "" : std::string(fusion) + " ") + n->op;
    }
};
struct Device { struct { struct { float timestampPeriod = 1.0f; } limits; } properties; };
struct Context {
    int query_idx;
    std::vector<Tensor *> query_nodes;
    std::vector<const char *> query_fusion_names;
    Device * device;
    Logger * perf_logger;
};
struct Graph { int n_nodes; Tensor ** nodes; };

static void emit(Context * ctx, Graph * cgraph, const std::vector<uint64_t> & timestamps,
                 bool profiler_enabled, bool concurrent) {
    if (profiler_enabled && !concurrent) {
#include "event_trace.inc"
    }
}

int main(int argc, char ** argv) {
    const std::string mode = argc > 1 ? argv[1] : "ties";
    const int count = mode == "zero" ? 0 : (mode == "small" ? 3 : 1557);
    std::vector<Tensor> tensors(size_t(count) + 1);
    std::vector<Tensor *> nodes;
    std::vector<uint64_t> timestamps { 0 };
    std::vector<uint64_t> durations;
    for (int i = 0; i <= count; ++i) {
        auto & node = tensors[size_t(i)];
        for (int j = 0; j < 4; ++j) {
            node.ne[j] = mode == "bound" ? std::numeric_limits<int64_t>::max() : j + 1;
        }
        const std::string name = mode == "bound" ? std::string(500, 'N') : "tensor_" + std::to_string(i);
        std::copy(name.begin(), name.end(), node.name);
        node.name[name.size()] = '\0';
        node.op = mode == "bound" ? std::string(500, 'X') : "MUL_MAT f32 m=4 n=3 k=8";
        if (mode == "sanitize") { node.name[0] = '\n'; node.name[1] = '"'; node.name[2] = '\\'; node.op = "ADD\n\"\\"; }
        nodes.push_back(&node);
        if (i > 0) {
            const uint64_t duration = i == 32 || i == 33 ? 500000 : uint64_t(i % 41 + 1) * 100;
            durations.push_back(duration);
            timestamps.push_back(timestamps.back() + duration);
        }
    }
    Device device;
    Logger logger;
    if (mode == "duplicates") { nodes[32] = nodes[1]; nodes[33] = nodes[1]; }
    Context context {count + 1, nodes, std::vector<const char *>(nodes.size(), "FUSED"), &device, &logger};
    Graph graph {int(nodes.size()), nodes.data()};
    if (mode == "period") { device.properties.limits.timestampPeriod = 1.25f; }
    if (mode == "overflow") {
        timestamps.assign(nodes.size(), 0);
        for (size_t i = 1; i < timestamps.size(); ++i) {
            timestamps[i] = timestamps[i - 1] + (uint64_t(1) << 62);
        }
    }
    emit(&context, &graph, timestamps, mode != "no-profiler", mode == "concurrent");
    return 0;
}
