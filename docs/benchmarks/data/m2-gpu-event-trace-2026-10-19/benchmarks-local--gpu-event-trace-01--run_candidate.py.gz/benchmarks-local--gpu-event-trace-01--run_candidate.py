#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Dry by default: sixteen candidate full/seek exact-PCM GPU interval profiles, no UI/audio load.

Only --run imports the worker/NumPy, queries admission or creates processes.
Profiling adds timestamps, barriers and query/printing work. Its operation GPU
intervals are not exclusive kernel time, and this is neither a latency gate nor
an overhead comparison. Ordinary benchmark diagnostic-flag guards stay intact.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True
SELF = Path(__file__).resolve()
BASE = SELF.parent
ROOT = SELF.parents[2]
OLD = ROOT / "benchmarks-local/m2-graph-phase-2026-10-18"
BASELINE_RUNTIME = OLD / "flash-promoted-native-build/conflux-stem-runtime"
BASELINE_SHA = "6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53"
RUNTIME = BASE / "build/conflux-stem-runtime"
BUILD_RECEIPT = BASE / "build-receipt.json"
TRACE_PARSER = BASE / "parse_trace.py"
HELPERS = {
    "comparison": (OLD / "compare_runtime.py", "5022aeed8eaf932adead05404f80b94c7d992f4b6f68dc81d05edb6126077e5b"),
    "launch": (OLD / "compare_launch.py", "338a42325617a19f72771239b00de17f4d12b822949e06966d598af95f5be7a8"),
    "retained": (OLD / "observed_launch.py", "511bb712d2f7af01abb1ab25ca92b001c6f82af4ee6f42547a5b43fa32b237d6"),
}
PROOF = OLD / "flash-promoted-repro-01/result.json"
PROOF_SHA = "44554b8e1caca9e92a49be7b9cc0e05ba7248f0091b4cdfc005e87e2c87ffe70"
CASE_IDS = tuple(f"{track}:{start}" for track in
                 ("club_xl", "when_the_light_breaks", "under_my_skin", "stfu")
                 for start in (0, 257985, 515970, 773955))
ORDER = CASE_IDS
LOGGER_ENV = {"GGML_VK_PERF_LOGGER": "1", "GGML_VK_PERF_LOGGER_FREQUENCY": "1",
              "GGML_VK_PERF_TRACE_TOP": "1"}
LOGGER_KEYS = tuple(LOGGER_ENV) + ("GGML_VK_PERF_LOGGER_CONCURRENT",)
REQUEST_SECONDS, PROFILE_SECONDS = 30, 60
READINESS_SECONDS, TOTAL_SECONDS = 195, 300
CLEANUP_RESERVE_SECONDS = 45
STDERR_LIMIT = 8 * 1024 * 1024
REQUEST_STDERR_LIMIT = 64 * 1024
VALIDATION_ORDER = ("initial full hashes", "CPU input preparation", "full hashes before stable readiness",
                    "stable readiness", "strict metadata, HEAD and same human proof",
                    "one unchanged fresh admission", "sixteen unique full/seek native requests", "cleanup and final full hashes")
SCOPE = ("Sixteen unique full/seek windows through one separately pinned trace candidate "
         "Vulkan/two-thread/blocking/passive child, each compared exactly to immutable promoted "
         "own-Flash PCM. Baseline runtime and candidate identity remain distinct. "
         "No UI, audio output, policy/service mutation, timing qualification or "
         "overhead claim. Profiler barriers/timestamps/query/formatting perturb "
         "execution; GPU intervals include synchronization/internal work.")


def require(value, message):
    if not value:
        raise RuntimeError(message)


def load(name, path):
    spec = importlib.util.spec_from_file_location("conflux_ops_" + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def bounded_head(deadline):
    # Provenance checks share their stage deadline, including Git.
    remaining = deadline - time.monotonic()
    require(remaining > 0, "Provenance deadline exhausted before HEAD verification")
    return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT,
        text=True, timeout=min(5, remaining)).strip()


def verify_pinned_metadata(comparison, pins, deadline):
    # Bulk reads occur before the stable observation. This later check binds
    # ordinary file identity/metadata to those exact fullhash snapshots.
    verified = {}
    for name, pinned in pins.items():
        comparison.check_deadline(deadline)
        current = os.stat(pinned["path"], follow_symlinks=False)
        expected = (pinned["device"], pinned["inode"], pinned["bytes"], pinned["mtime_ns"], pinned["ctime_ns"])
        actual = comparison.signature(current)
        require(stat.S_ISREG(current.st_mode) and actual == expected,
                "Pinned metadata changed after stable readiness: " + name)
        verified[name] = {"path": pinned["path"], "signature": list(actual)}
    comparison.check_deadline(deadline)
    return verified


def save_stderr(native, output):
    native.stderr.flush()
    path = native.root / "runtime.stderr"
    total = path.stat().st_size
    with path.open("rb") as stream:
        contents = stream.read(STDERR_LIMIT)
    target = output / "native.stderr"
    target.write_bytes(contents)
    return {"path": str(target), "bytes": len(contents), "original_bytes": total,
            "truncated": total > len(contents), "limit_bytes": STDERR_LIMIT,
            "sha256": hashlib.sha256(contents).hexdigest()}


def cleanup_request(native, row):
    # A failed request may still be writing. The outer reap proof owns its files.
    if row.get("completed") is True:
        for name in ("input.f32", "output.f32"):
            (native.root / name).unlink(missing_ok=True)


def cleanup_native(native, initialized, output):
    """Close this NativeRuntime's known fields, including a failed constructor."""
    process, root = getattr(native, "process", None), getattr(native, "root", None)
    errors, stderr_record = [], None
    cleanup = {"native_started": process is not None, "native_constructed": initialized}
    if process is not None:
        cleanup["native_pid"] = process.pid
        try:
            if process.poll() is None:
                process.kill()
            process.wait(timeout=3)
        except Exception as error:
            errors.append({"phase": "native_reap", "message": str(error)})
    reaped = process is None or process.poll() is not None
    # Keep the complete bounded log before normal close removes its directory.
    if reaped and root is not None and (root / "runtime.stderr").is_file():
        try:
            stderr_record = save_stderr(native, output)
        except Exception as error:
            errors.append({"phase": "native_log_cleanup", "message": str(error)})
    normal_closed = False
    if initialized and reaped:
        try:
            native.close()
            normal_closed = True
        except Exception as error:
            errors.append({"phase": "native_close", "message": str(error)})
    resource_errors = []
    if not normal_closed:
        # __init__ may have spawned before selector allocation/register failed.
        # Each exact resource is independent: one close error cannot skip others.
        for name, resource in (("selector", getattr(native, "selector", None)),
                               ("stdin", getattr(process, "stdin", None)),
                               ("stdout", getattr(process, "stdout", None)),
                               ("stderr", getattr(native, "stderr", None))):
            if resource is not None:
                try:
                    resource.close()
                except Exception as error:
                    resource_errors.append({"phase": "native_partial_" + name, "message": str(error)})
        directory = getattr(native, "directory", None)
        if directory is not None and (process is None or process.poll() is not None):
            try:
                directory.cleanup()
            except Exception as error:
                resource_errors.append({"phase": "native_partial_directory", "message": str(error)})
    cleanup.update(native_reaped=process is None or process.poll() is not None,
                   native_returncode=process.returncode if process is not None else None,
                   normal_close_returned=normal_closed, native_resources_closed=not resource_errors,
                   temporary_directory_removed=root is None or not root.exists())
    return cleanup, stderr_record, errors + resource_errors



def validate_reference(proof, model_sha):
    """The immutable PCM producer is always promoted baseline, never candidate."""
    require(proof.get("status") == "reproduction_complete" and proof.get("cleanup_complete") is True
            and proof.get("private_spool_removed") is True and proof.get("pins_unchanged") is True
            and proof.get("all_outputs_match_closed_B") is True and proof.get("input_sha_match") is True
            and proof.get("phase_fields_valid") is True and proof.get("completed_requests") == 16
            and proof.get("runtime_sha256") == BASELINE_SHA and proof.get("model_sha256") == model_sha
            and len(proof.get("runtimes", [])) == 1 and proof["runtimes"][0]["label"] == "diagnostic"
            and proof["runtimes"][0]["executable"] == str(BASELINE_RUNTIME), "Immutable baseline own-Flash proof differs")
    for key, digest in (("runtime", BASELINE_SHA), ("model", model_sha)):
        require(proof["pins_before"][key]["sha256"] == proof["pins_after"][key]["sha256"] == digest,
                "Baseline reference artifact pin differs: " + key)
    rows = proof["runtimes"][0]["requests"]
    require(len(rows) == len(CASE_IDS) and {row["id"] for row in rows} == set(CASE_IDS)
            and all(row.get("completed") is True and row.get("output_matches_closed_B") is True
                    and row.get("input_sha_match") is True and row.get("phase_fields_valid") is True
                    and re.fullmatch(r"[0-9a-f]{64}", row.get("output_sha256", "")) for row in rows),
            "Retained baseline full/seek case proof incomplete or duplicated")
    return {row["id"]: row for row in rows}


def verify_output_digest(actual, proven, case_id):
    require(actual == proven["output_sha256"], "Exact PCM mismatch: " + case_id)


def parse_request_profile(contents, trace_parser):
    require(len(contents) <= REQUEST_STDERR_LIMIT, "Request stderr exceeded 64KiB")
    text = contents.decode("utf-8")
    require(text.count("Vulkan Timings:\n") == 1, "Expected exactly one operation table per request")
    table = text.split("Vulkan Timings:\n", 1)[1]
    match = re.search(r"^Total time: ([0-9.eE+-]+) us\.$", table, re.MULTILINE)
    require(match is not None and len(re.findall(r"^Total time:", text, re.MULTILINE)) == 1,
            "Expected exactly one complete aggregate total per request")
    rows = []
    for line in table[:match.start()].splitlines():
        row = re.fullmatch(r"(.+): ([0-9]+) x ([0-9.eE+-]+) us = ([0-9.eE+-]+) us(?: \([0-9.eE+-]+ GFLOPS/s\))?", line)
        require(row is not None, "Malformed aggregate operation row")
        name, count, mean, total = row.groups()
        count, mean, total = int(count), float(mean), float(total)
        require(count > 0 and all(math.isfinite(value) and value >= 0 for value in (mean, total)),
                "Invalid aggregate operation count or interval")
        rows.append({"name": name, "count": count, "mean_us": mean, "sum_us": total})
    require(rows and len({row["name"] for row in rows}) == len(rows), "Missing or duplicate aggregate operations")
    printed_total = float(match[1])
    require(math.isfinite(printed_total) and printed_total > 0, "Invalid aggregate total")
    trace = trace_parser.parse_trace(text)
    require(trace["events"] == sum(row["count"] for row in rows), "Trace/aggregate interval count differs")
    # Existing std::cerr default precision is six significant decimal digits.
    # Half-unit rounding is <=5ppm of a positive printed value. The 1ns floor
    # also covers integer-nanosecond values printed as zero. Means are floored
    # to integer ns by the original logger and are not used for sum matching.
    error_us = lambda value: max(0.001, abs(value) * 0.000005)
    trace_total_us = trace["total_ns"] / 1000
    row_sum = sum(row["sum_us"] for row in rows)
    total_tolerance = error_us(printed_total)
    row_tolerance = sum(error_us(row["sum_us"]) for row in rows)
    require(abs(trace_total_us - printed_total) <= total_tolerance
            and abs(trace_total_us - row_sum) <= row_tolerance,
            "Trace/aggregate interval sum differs beyond six-significant-digit rounding")
    return {"aggregate": {"event_count": trace["events"], "printed_total_us": printed_total,
                          "summed_printed_rows_us": row_sum, "rows": rows,
                          "printed_total_tolerance_us": total_tolerance,
                          "summed_rows_tolerance_us": row_tolerance,
                          "rounding": "six significant digits, <=5ppm/value with 1ns floor"},
            "trace": trace}


def process_identity(pid, command):
    proc = Path("/proc") / str(pid)
    fields = (proc / "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": pid, "start_ticks": int(fields[19]), "group": int(fields[2]),
            "session": int(fields[3]), "command": list(command)}


def original_identity_absent(identity):
    try:
        current = process_identity(identity["pid"], identity["command"])
    except FileNotFoundError:
        return True
    return any(current[key] != identity[key] for key in ("start_ticks", "group", "session"))


def completed_case_set(rows):
    return (len(rows) == len(CASE_IDS) and {row["case_id"] for row in rows} == set(CASE_IDS)
            and all(row.get("completed") is True and row.get("exact_pcm_match") is True
                    and row.get("trace_valid") is True for row in rows))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("name", help="Fresh plain run/readiness label")
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--readiness-decision", type=Path, default=BASE / "human-readiness.json")
    parser.add_argument("--source-pins", type=Path, default=BASE / "comparison-source-pins.json")
    args = parser.parse_args()
    require(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,95}", args.name), "Use a fresh plain run label")
    output = BASE / args.name
    if not args.run:
        print(json.dumps({"schema": 1, "status": "dry_run", "native_started": False,
              "host_queried": False, "output": str(output), "cases": list(ORDER), "validation_order": VALIDATION_ORDER,
              "child_environment": LOGGER_ENV, "child_unset": ["GGML_VK_PERF_LOGGER_CONCURRENT"],
              "readiness_decision": str(args.readiness_decision), "source_pins": str(args.source_pins),
              "expected_pins": str(BASE / "expected-pins.json"), "comparison_proof": str(PROOF),
              "request_timeout_seconds": REQUEST_SECONDS, "profile_budget_seconds": PROFILE_SECONDS,
              "readiness_maximum_seconds": READINESS_SECONDS, "cleanup_reserve_seconds": CLEANUP_RESERVE_SECONDS, "maximum_total_seconds": TOTAL_SECONDS,
              "stderr_limit_bytes": STDERR_LIMIT, "per_request_stderr_limit_bytes": REQUEST_STDERR_LIMIT,
              "candidate_runtime": str(RUNTIME), "baseline_runtime": str(BASELINE_RUNTIME),
              "baseline_runtime_sha256": BASELINE_SHA, "build_receipt": str(BUILD_RECEIPT),
              "arming": "unarmed until PR33 merge and explicit expected HEAD/candidate receipt pins", "scope": SCOPE}, indent=2))
        return 0

    require(args.source_pins.is_absolute() and args.readiness_decision.is_absolute(), "Use absolute input paths")
    require(not output.exists(), "Output exists; use a fresh label")
    output.mkdir(mode=0o700)
    admission = output / "admission"
    admission.mkdir()
    started, native, readiness_child = time.monotonic(), None, None
    native_initialized = False
    deadline = started + TOTAL_SECONDS
    pre_native_deadline = min(started + READINESS_SECONDS, deadline - PROFILE_SECONDS - CLEANUP_RESERVE_SECONDS)
    report = {"schema": 1, "status": "checking", "native_started": False,
              "scope": SCOPE, "validation_order": VALIDATION_ORDER, "requests": [], "errors": [], "pins_before": {}, "pins_after": {},
              "AC_lid": [], "cleanup": {}, "child_environment": LOGGER_ENV,
              "child_unset": ["GGML_VK_PERF_LOGGER_CONCURRENT"], "planned_requests": len(ORDER),
              "request_timeout_seconds": REQUEST_SECONDS, "profile_budget_seconds": PROFILE_SECONDS,
              "maximum_total_seconds": TOTAL_SECONDS, "readiness_maximum_seconds": READINESS_SECONDS,
              "cleanup_reserve_seconds": CLEANUP_RESERVE_SECONDS,
              "per_request_stderr_limit_bytes": REQUEST_STDERR_LIMIT, "UI_load": False, "audio_load": False,
              "profile_mutation": False, "service_mutation": False, "pins_unchanged": False}
    comparison = launch = retained = admission_helper = None
    specs, handlers, watchdog_errors = {}, {}, []
    watchdog_stop, watchdog = threading.Event(), None
    constructing_child = False
    active_request_offset = [None]
    request_log_lock = threading.Lock()

    def checkpoint():
        report["elapsed_seconds"] = time.monotonic() - started
        if comparison is not None:
            comparison.atomic_json(output / "result.json", report)
        else:
            temp = output / "result.json.tmp"
            temp.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
            temp.replace(output / "result.json")

    def interrupted(signum, _frame):
        report["interruption_signal"] = signum
        if not constructing_child:
            raise KeyboardInterrupt

    def ac_lid(phase):
        row = {"phase": phase, **admission_helper.ac_lid()}
        report["AC_lid"].append(row)
        checkpoint()
        require(row["ready"], "AC/lid observation failed or changed: " + phase)

    try:
        handlers = {sig: signal.signal(sig, interrupted) for sig in (signal.SIGINT, signal.SIGTERM)}
        checkpoint()
        # No worker import until all directly imported helpers have frozen hashes.
        for name, (path, digest) in HELPERS.items():
            require(path.is_file() and path.stat().st_size <= 128 * 1024
                    and hashlib.sha256(path.read_bytes()).hexdigest() == digest,
                    "Frozen helper differs: " + name)
        comparison = load("comparison", HELPERS["comparison"][0])
        comparison.DIAGNOSTIC = RUNTIME
        launch = load("launch", HELPERS["launch"][0])
        retained = load("retained", HELPERS["retained"][0])
        config = BASE / "expected-pins.json"
        _, config_bytes = comparison.inspect_file(config, 64 * 1024, deadline, keep=True)
        expected = comparison.decode_json(config_bytes)
        require(expected.get("status") == "ready"
                and re.fullmatch(r"[0-9a-f]{40}", expected.get("repository_head", ""))
                and comparison.HEX.fullmatch(expected.get("pins", {}).get("runtime", ""))
                and expected["pins"]["runtime"] != BASELINE_SHA
                and expected["pins"].get("baseline_runtime") == BASELINE_SHA
                and comparison.HEX.fullmatch(expected.get("build_receipt_sha256", ""))
                and comparison.HEX.fullmatch(expected.get("trace_parser_sha256", ""))
                and re.fullmatch(r"[0-9a-f]{40}", expected.get("build_source_head", ""))
                and expected["pins"].get("model") == comparison.MODEL_SHA,
                "Expected HEAD/candidate/baseline/model/build/parser pins are not armed")
        require(retained.head() == expected["repository_head"], "Exact expected HEAD differs")
        report.update(started_at_utc=comparison.utc(), expected_producer=expected,
                      repository_head=expected["repository_head"])
        initial_human = launch.human_readiness(args.readiness_decision, args.name)
        require((initial_human["record"].get("Codex_minimized") is True or
                 initial_human["record"].get("Codex_closed") is True) and
                initial_human["record"].get("other_work_paused") is True,
                "Fresh readiness must cover minimized or closed Codex and paused other work")
        report["human_readiness_before_setup"] = initial_human
        _, sources = comparison.source_specs(args.source_pins, deadline)
        specs = {"runtime": (comparison.DIAGNOSTIC, expected["pins"]["runtime"], 256 * 1024 * 1024),
                 "model": (comparison.MODEL, comparison.MODEL_SHA, 2 * 1024 * 1024 * 1024),
                 "proof": (PROOF, PROOF_SHA, 2 * 1024 * 1024)}
        _, receipt_bytes = comparison.inspect_file(BUILD_RECEIPT, 2 * 1024 * 1024, deadline,
            expected=expected["build_receipt_sha256"], keep=True)
        receipt = comparison.decode_json(receipt_bytes)
        require(receipt.get("status") == "compiled-and-linked-no-runtime-execution"
                and receipt.get("source_head") == expected["build_source_head"]
                and receipt.get("candidate", {}).get("path") == str(RUNTIME)
                and receipt["candidate"].get("sha256") == expected["pins"]["runtime"]
                and receipt.get("promoted_runtime_unchanged", {}).get("path") == str(BASELINE_RUNTIME)
                and receipt["promoted_runtime_unchanged"].get("sha256") == BASELINE_SHA,
                "Candidate build receipt/baseline identity differs")
        specs["baseline_runtime"] = (BASELINE_RUNTIME, BASELINE_SHA, 256 * 1024 * 1024)
        specs["build_receipt"] = (BUILD_RECEIPT, expected["build_receipt_sha256"], 2 * 1024 * 1024)
        specs["trace_parser"] = (TRACE_PARSER, expected["trace_parser_sha256"], 128 * 1024)
        for key in ("candidate_object", "candidate_archive"):
            item = receipt[key]
            specs["candidate_build:" + key] = (Path(item["path"]), item["sha256"], 256 * 1024 * 1024)
        candidate_source = receipt["overlay"]["candidate_source"]
        specs["candidate_build:source"] = (Path(candidate_source["path"]), candidate_source["sha256"], 32 * 1024 * 1024)
        for index, item in enumerate(receipt["compile_dependencies"]):
            specs["candidate_dependency:" + str(index)] = (Path(item["path"]), item["sha256"], 32 * 1024 * 1024)
        report["candidate_build_receipt"] = {"pin": comparison.inspect_file(BUILD_RECEIPT, 2 * 1024 * 1024, deadline)[0],
                                             "candidate": receipt["candidate"], "build_source_head": receipt["source_head"]}
        for path, digest in sources.items():
            specs["source:" + path] = (Path(path), digest, 32 * 1024 * 1024)
        for name, (path, digest) in HELPERS.items():
            specs["helper:" + name] = (path, digest, 128 * 1024)
        for name in ("admission_source", "readiness_source", "native_replay_source"):
            path, digest = retained.HELPERS[name]
            specs["helper:" + name] = (path, digest, 128 * 1024)
        for name, path in (("driver", SELF), ("config", config), ("source_pins", args.source_pins),
                           ("human_readiness", args.readiness_decision)):
            pin, _ = comparison.inspect_file(path, 128 * 1024, deadline)
            specs[name] = (path, pin["sha256"], 128 * 1024)
        for label, digest in comparison.TRACKS:
            specs["asset:" + label] = (comparison.ASSETS / f"{label}-30s-23p4s.wav", digest, comparison.ASSET_BYTES)
        report["pins_before"] = comparison.capture_pins(specs, deadline)
        _, proof_bytes = comparison.inspect_file(PROOF, 2 * 1024 * 1024, deadline, expected=PROOF_SHA, keep=True)
        proof = comparison.decode_json(proof_bytes)
        expected_cases = validate_reference(proof, expected["pins"]["model"])
        report["comparison_proof"] = {"pin": comparison.inspect_file(PROOF, 2 * 1024 * 1024, deadline)[0],
                                      "status": proof["status"], "own_Flash_PCM": True, "threads": 2,
                                      "baseline_runtime_sha256": BASELINE_SHA,
                                      "candidate_runtime_sha256": expected["pins"]["runtime"]}
        trace_parser = load("trace_parser", TRACE_PARSER)
        # Presence-tested Vulkan flags must be absent, even when their value is 0.
        forbidden = set(comparison.DEBUG_FLAGS) | set(LOGGER_KEYS) | {
            "GGML_VK_SYNC_LOGGER", "GGML_VK_MEMORY_LOGGER", "GGML_VK_PIPELINE_STATS"}
        require(not forbidden.intersection(os.environ)
                and not any(key.startswith(("GGML_VK_", "GGML_VULKAN_")) for key in os.environ),
                "Inherited GPU diagnostic/backend flags must be unset")
        report["inherited_compute_environment"] = {key: value for key, value in os.environ.items()
            if key.startswith(("MESA_", "INTEL_", "GGML_", "OMP_", "GOMP_"))}
        np, NativeRuntime, prepared = comparison.prepare_cases(comparison.load_track_plan(deadline), deadline)
        cases = {case["id"]: case for case in prepared if case["id"] in CASE_IDS}
        del prepared
        require(len(cases) == len(CASE_IDS) and set(cases) == set(CASE_IDS), "Prepared full/seek case selection incomplete")
        for case_id, case in cases.items():
            proven = expected_cases[case_id]
            require(all(case[key] == proven[key] for key in
                        ("input_sha256", "shape", "dtype", "valid_frames", "normalization")),
                    "Normalized input differs from immutable proof: " + case_id)
        report.update(numpy_version=np.__version__, python_version=sys.version,
                      cases=[{k: v for k, v in cases[key].items() if k != "samples"} for key in CASE_IDS])
        # Keep every complete byte hash, but let stable readiness follow all
        # bulk reads. After the wait, strict metadata consistency guards them.
        report["full_hashes_before_readiness"] = comparison.capture_pins(specs, pre_native_deadline)
        report["full_hashes_before_readiness_scope"] = "Full byte hashes after CPU preparation and before stable readiness; post-wait check is metadata consistency, not a simultaneous byte rehash"
        require(report["full_hashes_before_readiness"] == report["pins_before"]
                and bounded_head(pre_native_deadline) == expected["repository_head"], "HEAD/source/artifact/config changed during setup")
        admission_helper = load("admission", retained.HELPERS["admission_source"][0])
        admission_helper.readiness_module()
        ac_lid("before_normal_readiness")
        command = [sys.executable, "-B", "-c",
                   "import runpy,sys;from pathlib import Path;sys.exit(runpy.run_path(sys.argv[1])['run']('admission',Path(sys.argv[2])))",
                   str(retained.HELPERS["readiness_source"][0]), str(admission)]
        report.update(status="normal_readiness", readiness_command=command)
        checkpoint()
        with (admission / "stdout").open("x") as out, (admission / "stderr").open("x") as err:
            constructing_child = True
            try:
                readiness_child = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err, start_new_session=True)
                report["readiness_identity"] = process_identity(readiness_child.pid, command)
                checkpoint()
            finally:
                constructing_child = False
            if "interruption_signal" in report:
                raise KeyboardInterrupt
            until, next_ac = pre_native_deadline, 0
            while readiness_child.poll() is None:
                require(time.monotonic() < until, "Normal readiness exhausted bounded wait")
                if time.monotonic() >= next_ac:
                    ac_lid("normal_readiness")
                    next_ac = time.monotonic() + 45
                time.sleep(.25)
            report["readiness_returncode"] = readiness_child.wait()
        require(report["readiness_returncode"] == 0, "Normal readiness did not match")
        report["metadata_before_native"] = verify_pinned_metadata(comparison, report["full_hashes_before_readiness"], pre_native_deadline)
        require(bounded_head(pre_native_deadline) == expected["repository_head"], "HEAD changed during stable readiness")
        report["human_readiness_before_native"] = launch.human_readiness(args.readiness_decision, args.name)
        require(report["human_readiness_before_native"]["pin"] == initial_human["pin"], "Human readiness record changed")
        comparison.check_deadline(pre_native_deadline)
        report["admission"] = admission_helper.fresh_admission(admission)
        comparison.check_deadline(pre_native_deadline)
        profile_started = time.monotonic()
        profile_deadline = min(deadline - CLEANUP_RESERVE_SECONDS, profile_started + PROFILE_SECONDS)
        report.update(status="profiling", profile_started_monotonic=profile_started, profile_started_at_utc=comparison.utc(),
                      native_construction_attempted=True)
        checkpoint()
        # Constructor copies the environment into the child. Defer a parent
        # interruption until assignment/restore; never pass a blocked signal mask
        # to either child. No other process is launched while these flags are set.
        constructing_child = True
        try:
            saved_env = {key: os.environ.get(key) for key in LOGGER_KEYS}
            try:
                os.environ.update(LOGGER_ENV)
                os.environ.pop("GGML_VK_PERF_LOGGER_CONCURRENT", None)
                # Retain the owner BEFORE __init__: selector allocation/register
                # can raise after Popen, so a normal constructor assignment leaks.
                native = NativeRuntime.__new__(NativeRuntime)
                try:
                    NativeRuntime.__init__(native, comparison.DIAGNOSTIC, comparison.MODEL, "vulkan", 2,
                        min(REQUEST_SECONDS, comparison.check_deadline(profile_deadline)), passive_openmp=True,
                        spool_directory=output / "native-spool")
                    native_initialized = True
                finally:
                    report["native_started"] = getattr(native, "process", None) is not None
                    report["native_construction_completed"] = native_initialized
            finally:
                for key, value in saved_env.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value
        finally:
            constructing_child = False
        if "interruption_signal" in report:
            raise KeyboardInterrupt
        report.update(pid=native.process.pid, temporary_directory=str(native.root))
        report["native_identity"] = process_identity(native.process.pid,
            [str(RUNTIME), "--model", str(comparison.MODEL), "--backend", "vulkan", "--threads", "2"])

        def monitor_native():
            while not watchdog_stop.wait(.05):
                try:
                    require(time.monotonic() < profile_deadline, "Native profile budget exhausted")
                    with request_log_lock:
                        total = (native.root / "runtime.stderr").stat().st_size
                        request_offset = active_request_offset[0]
                    require(total <= STDERR_LIMIT, "Native stderr exceeded 8MiB; diagnostic aborted")
                    if request_offset is not None:
                        require(0 <= total - request_offset <= REQUEST_STDERR_LIMIT,
                                "Request stderr exceeded 64KiB; diagnostic aborted")
                except Exception as error:
                    watchdog_errors.append({"type": type(error).__name__, "message": str(error)})
                    native.abort()
                    return
        watchdog = threading.Thread(target=monitor_native, name="conflux-ops-log-bound", daemon=True)
        watchdog.start()
        began_ready = time.monotonic()
        ready = native.start()
        report.update(ready=ready, startup_wall_ms=(time.monotonic() - began_ready) * 1000)
        require(ready.get("backend") == "vulkan" and ready.get("threads") == 2
                and ready.get("revision") == comparison.REVISION and ready.get("model") == str(comparison.MODEL)
                and ready.get("pid") == native.process.pid and ready.get("weight_storage") == "native"
                and ready.get("fence_wait_mode") == "blocking"
                and ready.get("process_environment") == {"OMP_WAIT_POLICY": "PASSIVE", "GOMP_SPINCOUNT": "0"},
                "Native readiness differs from pinned configuration")
        comparison.validate_number(ready, "load_ms")
        checkpoint()
        for request_id, case_id in enumerate(ORDER, 1):
            ac_lid("before_request_" + str(request_id))
            require(not watchdog_errors, "Native watchdog failed")
            case, proven = cases[case_id], expected_cases[case_id]
            native.timeout = min(REQUEST_SECONDS, comparison.check_deadline(profile_deadline))
            offset = (native.root / "runtime.stderr").stat().st_size
            row = {"request_id": request_id, "case_id": case_id, "repetition": 1,
                   "started_monotonic": time.monotonic(), "started_at_utc": comparison.utc(), "stderr_begin": offset, "completed": False}
            report["requests"].append(row)
            with request_log_lock:
                active_request_offset[0] = offset
            checkpoint()
            produced = None
            try:
                produced, metrics = native.infer(case["samples"], request_id)
                row.update(finished_monotonic=time.monotonic(), native_metrics=metrics)
                row["request_wall_ms"] = (row["finished_monotonic"] - row["started_monotonic"]) * 1000
                require(not watchdog_errors, "Native watchdog failed during request")
                for name in comparison.COMMON_TIMINGS + comparison.PHASE_TIMINGS:
                    comparison.validate_number(metrics, name)
                for name in comparison.SWITCH_COUNTS:
                    comparison.validate_number(metrics, name, integral=True)
                require(produced.shape == (4, comparison.WINDOW, 2) and produced.dtype.str == "<f4"
                        and produced.flags.c_contiguous and np.isfinite(produced).all(), "Native PCM contract differs")
                actual_input, _ = comparison.inspect_file(native.root / "input.f32", comparison.WINDOW * 8,
                    profile_deadline, expected=proven["input_sha256"])
                row.update(input_sha256=actual_input["sha256"], output_sha256=hashlib.sha256(memoryview(produced)).hexdigest(),
                           output_shape=list(produced.shape), output_dtype=produced.dtype.str,
                           output_bytes=produced.nbytes, expected_output_sha256=proven["output_sha256"])
                verify_output_digest(row["output_sha256"], proven, case_id)
                row["stderr_end"] = end = (native.root / "runtime.stderr").stat().st_size
                require(offset <= end <= STDERR_LIMIT and end - offset <= REQUEST_STDERR_LIMIT,
                        "Native/request stderr size bound exceeded")
                with (native.root / "runtime.stderr").open("rb") as stream:
                    stream.seek(offset)
                    table = stream.read(end - offset)
                row["profile"] = parse_request_profile(table, trace_parser)
                row["profiled_gpu_interval_total_us"] = row["profile"]["aggregate"]["printed_total_us"]
                row.update(completed=True, exact_pcm_match=True, trace_valid=True, finished_at_utc=comparison.utc())
            finally:
                with request_log_lock:
                    active_request_offset[0] = None
                produced = None
                cleanup_request(native, row)
                checkpoint()
            ac_lid("after_request_" + str(request_id))
        report["host_after"] = admission_helper.readiness_module().capture(
            Path(json.loads((admission / "admission-normal-ready.json").read_text())["package_zone"]),
            min(deadline - 30, time.monotonic() + 12))
        require(not report["host_after"]["errors"] and
                admission_helper.readiness_module().identity(report["host_after"]) == report["admission"]["same_guard_service_identity"],
                "Existing thermal guard identity changed during profiling")
        report.update(status="passed", exact_pcm_match=True,
                      profile_elapsed_seconds=time.monotonic() - profile_started)
    except KeyboardInterrupt:
        report["status"] = "interrupted"
    except Exception as error:
        report["status"] = "failed"
        report["errors"].append({"type": type(error).__name__, "message": str(error)[:8192]})
    finally:
        for sig in handlers:
            signal.signal(sig, signal.SIG_IGN)
        if readiness_child is not None:
            try:
                if readiness_child.poll() is None:
                    os.killpg(readiness_child.pid, signal.SIGINT)
                    try:
                        readiness_child.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        os.killpg(readiness_child.pid, signal.SIGKILL)
                readiness_child.wait(timeout=3)
                report["cleanup"]["readiness_reaped"] = True
                report["cleanup"]["readiness_original_identity_absent"] = (
                    "readiness_identity" in report and original_identity_absent(report["readiness_identity"]))
            except Exception as error:
                report["cleanup"]["readiness_reaped"] = False
                report["errors"].append({"phase": "readiness_cleanup", "message": str(error)})
        watchdog_stop.set()
        if watchdog is not None:
            watchdog.join(timeout=2)
        report["watchdog_errors"] = watchdog_errors
        if native is not None:
            native_cleanup, stderr_record, cleanup_errors = cleanup_native(native, native_initialized, output)
            report["cleanup"].update(native_cleanup)
            report["errors"].extend(cleanup_errors)
            if stderr_record is not None:
                report["native_stderr"] = stderr_record
        if admission_helper is not None and (admission / "admission-normal-ready.json").is_file() and "host_after" not in report:
            try:
                zone = Path(json.loads((admission / "admission-normal-ready.json").read_text())["package_zone"])
                report["host_after"] = admission_helper.readiness_module().capture(zone, min(deadline - 10, time.monotonic() + 12))
            except Exception as error:
                report["errors"].append({"phase": "host_after", "message": str(error)})
        report["cleanup"]["watchdog_joined"] = watchdog is None or not watchdog.is_alive()
        if specs:
            try:
                report["pins_after"] = comparison.capture_pins(specs, min(deadline, time.monotonic() + 60), verify=False)
                report["pins_unchanged"] = report["pins_after"] == report["pins_before"]
                report["head_after"] = bounded_head(deadline)
                require(report["head_after"] == report["repository_head"], "HEAD changed during diagnostic")
            except Exception as error:
                report["errors"].append({"phase": "after_pins", "message": str(error)})
        complete = (native is not None and report["cleanup"].get("native_reaped")
                    and report["cleanup"].get("native_resources_closed")
                    and report["cleanup"].get("temporary_directory_removed")
                    and report["cleanup"].get("watchdog_joined")
                    and report["cleanup"].get("readiness_reaped")
                    and report["cleanup"].get("readiness_original_identity_absent")
                    and completed_case_set(report["requests"]))
        if report["status"] == "passed" and (not complete or not report["pins_unchanged"]
                or report["errors"] or watchdog_errors or report.get("native_stderr", {}).get("truncated", True)):
            report["status"] = "failed"
        report["cleanup_complete"] = bool(native is not None and report["cleanup"].get("native_reaped")
            and report["cleanup"].get("native_resources_closed")
            and report["cleanup"].get("temporary_directory_removed") and report["cleanup"].get("watchdog_joined")
            and report["cleanup"].get("readiness_reaped")
            and report["cleanup"].get("readiness_original_identity_absent"))
        report["finished_at_utc"] = comparison.utc() if comparison is not None else None
        checkpoint()
        for sig, handler in handlers.items():
            signal.signal(sig, handler)
    print(json.dumps({"status": report["status"], "result": str(output / "result.json"),
                      "completed_requests": sum(row["completed"] for row in report["requests"])}))
    return 0 if report["status"] == "passed" else 130 if report["status"] == "interrupted" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, ValueError) as error:
        print("operation profiler admission failed: " + str(error), file=sys.stderr)
        raise SystemExit(1)
