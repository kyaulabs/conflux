#!/usr/bin/env python3
"""Strict offline parser for one bounded graph's optional interval report."""
import json
import re
import sys
from pathlib import Path

PREFIX = "conflux_vk_trace_v1 "
HEADER = re.compile(r"conflux_vk_trace_v1 events=(\d+) graph_nodes=(\d+) total_ns=(\d+) max_ns=(\d+) selected=(\d+) limit=32 overflow=0")
ROW = re.compile(r'conflux_vk_trace_v1 rank=(\d+) query=(\d+) node=(\d+) duration_ns=(\d+) dst=(-?\d+),(-?\d+),(-?\d+),(-?\d+) name="([^"\\\r\n]{0,48})" op="([^"\\\r\n]{1,160})"')
MAX_U64 = (1 << 64) - 1


def parse_trace(text):
    if len(text.encode("utf-8")) > 65536:
        raise ValueError("stderr exceeds single-request 64KiB budget")
    lines = [line for line in text.splitlines() if line.startswith("conflux_vk_trace_")]
    if not lines or len(("\n".join(lines) + "\n").encode("utf-8")) > 16384:
        raise ValueError("missing or oversized trace")
    match = HEADER.fullmatch(lines[0])
    if not match:
        raise ValueError("malformed trace header")
    events, nodes, total, maximum, selected = map(int, match.groups())
    if not (0 <= events <= nodes <= (1 << 31) - 1 and selected == min(events, 32)
            and len(lines) == selected + 1 and 0 <= maximum <= total <= MAX_U64):
        raise ValueError("inconsistent header counts or totals")
    rows = []
    for line in lines[1:]:
        match = ROW.fullmatch(line)
        if not match or any(ord(c) < 32 or ord(c) > 126 for c in line):
            raise ValueError("malformed interval row")
        rank, query, node, duration, *shape = map(int, match.groups()[:8])
        if not (rank == len(rows) + 1 and 1 <= query <= events and 0 <= node < nodes
                and 0 <= duration <= maximum and all(0 <= n <= (1 << 63) - 1 for n in shape)):
            raise ValueError("interval index, duration or shape out of range")
        rows.append(dict(rank=rank, query=query, node=node, duration_ns=duration,
                         dst=shape, name=match[9], op=match[10]))
    if len({row["query"] for row in rows}) != selected:
        raise ValueError("duplicate query")
    if rows != sorted(rows, key=lambda row: (-row["duration_ns"], row["query"])):
        raise ValueError("top intervals not deterministically ordered")
    query_order = sorted(rows, key=lambda row: row["query"])
    previous_query, previous_node = 0, -1
    for row in query_order:
        if row["node"] - previous_node < row["query"] - previous_query:
            raise ValueError("node order cannot accommodate query order")
        previous_query, previous_node = row["query"], row["node"]
    if nodes - previous_node - 1 < events - previous_query:
        raise ValueError("remaining graph nodes cannot accommodate remaining queries")
    selected_sum = sum(row["duration_ns"] for row in rows)
    omitted_upper = 0
    if rows:
        last = rows[-1]
        # A tied omitted query with a smaller ID would rank ahead of the last row.
        omitted_earlier = last["query"] - 1 - sum(row["query"] < last["query"] for row in rows)
        omitted_upper = (events - selected) * last["duration_ns"] - omitted_earlier
    if (selected_sum > total or total > events * maximum
            or total > selected_sum + omitted_upper
            or (rows and rows[0]["duration_ns"] != maximum)
            or (not rows and (total != 0 or maximum != 0))
            or (events <= 32 and selected_sum != total)):
        raise ValueError("inconsistent interval sums or maximum")
    return dict(events=events, graph_nodes=nodes, total_ns=total, max_ns=maximum,
                selected=selected, limit=32, rows=rows)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: parse_trace.py STDERR_FILE")
    print(json.dumps(parse_trace(Path(sys.argv[1]).read_text()), indent=2))
