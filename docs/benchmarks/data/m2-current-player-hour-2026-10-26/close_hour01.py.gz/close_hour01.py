"""Verify the current-player hour-01 scope after its owner has ended."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

P = Path('/home/kyau/projects/kyaulabs/conflux/build/m2-hour-history-01/hour-01')


def read(name):
    return json.loads((P / name).read_text())


def show(unit):
    raw = subprocess.check_output(['systemctl', '--user', 'show', unit,
        '--property=LoadState,ActiveState,SubState,MainPID,ControlGroup,InvocationID'], text=True, timeout=5)
    return dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)


def main():
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    d, outer, assessor, result, plan = (read(n) for n in (
        'root-unit-dispatch-01.json', 'dispatch-01.json', 'diagnostic-assessment.json',
        'output-01/result.json', 'plan.json'))
    assert outer.get('finished_monotonic') and outer['launcher_reaped'] and outer['complete_capture']
    assert not outer['errors'] and not outer['remaining_known_processes']
    assert assessor['cleanup_complete'] and result['cleanup_proven']
    assert result['pins_unchanged'] and assessor['post_run_frozen_inputs_unchanged']
    rows = outer['known_processes'] + result['cleanup']['known_processes'] + [d['owner_identity']]
    identities = {(row['pid'], row['start_ticks']) for row in rows}
    groups = {row['group'] for row in rows}
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            raw = (entry / 'stat').read_text()
            fields = raw[raw.rfind(')') + 2:].split()
        except (FileNotFoundError, ProcessLookupError):
            continue
        assert (int(entry.name), int(fields[19])) not in identities
        assert int(fields[2]) not in groups
    cgroup = d['original_owned_cgroup']
    assert cgroup and cgroup.endswith('/' + d['unit'])
    directory = Path('/sys/fs/cgroup') / cgroup.lstrip('/')
    assert not directory.exists() or all(not f.read_text().split() for f in directory.rglob('cgroup.procs'))
    unit_before = show(d['unit'])
    assert unit_before['MainPID'] == '0'
    if unit_before['LoadState'] != 'not-found':
        assert unit_before['InvocationID'] == d['unit_after_launch']['InvocationID']
        assert unit_before['SubState'] in ('exited', 'dead', 'failed')
    command = ['busctl', '--user', '--timeout=2s', '--json=short', 'call',
        'org.kde.Solid.PowerManagement.PolicyAgent', '/org/kde/Solid/PowerManagement/PolicyAgent',
        'org.kde.Solid.PowerManagement.PolicyAgent', 'ListInhibitions']
    inhibition = json.loads(subprocess.check_output(command, text=True, timeout=4))
    assert inhibition['type'] == 'aas'
    assert not any(row[1] == str(P / 'run_player_owned.py') for row in inhibition['data'][0])
    if unit_before['LoadState'] != 'not-found':
        subprocess.run(['systemctl', '--user', 'stop', d['unit']], capture_output=True, check=True, timeout=5)
    assert not directory.exists() or all(not f.read_text().split() for f in directory.rglob('cgroup.procs'))
    guard = show('thermal-guard.service')
    assert guard['ActiveState'] == 'active'
    assert all(guard[key] == d['guard_before'][key] for key in ('MainPID', 'InvocationID'))
    assert result['guard_before'] == result['guard_after']
    for key in ('script', 'unit'):
        row = result['guard_before'][key]
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']
    ceiling = plan['power_limits']
    def within_ceiling(values):
        return all(0 < values[path] <= bound if path.endswith('power_limit_uw') else values[path] == bound
                   for path, bound in ceiling.items())
    assert all(within_ceiling(row['values']) for row in assessor['configured_power_cap_snapshots'])
    assert within_ceiling({path: int(Path(path).read_text()) for path in ceiling})
    now = time.monotonic()
    complete = assessor.get('diagnostic_complete') is True
    receipt = dict(schema=1, status='diagnostic_complete' if complete else 'incomplete_run_closed',
        qualified=False, cleanup_complete=True, original_readiness_utc=d['original_readiness_utc'],
        original_readiness_monotonic=d['original_readiness_monotonic'],
        operator_deadline_monotonic=d['operator_deadline_monotonic'],
        automated_owner_finished_monotonic=outer['finished_monotonic'],
        automated_owner_elapsed_seconds=outer['finished_monotonic'] - d['original_readiness_monotonic'],
        automated_owner_within_original_4380_seconds=outer['finished_monotonic'] <= d['operator_deadline_monotonic'],
        root_verification_monotonic=now, root_verification_elapsed_seconds=now - d['original_readiness_monotonic'],
        root_verification_within_original_4380_seconds=now <= d['operator_deadline_monotonic'],
        known_unique_lifetimes=len(identities), remaining_known_processes=[], owned_groups_absent=True,
        original_owned_cgroup=cgroup, original_cgroup_absent_or_empty=True,
        own_idle_inhibitions_remaining=0, unit_before_stop=unit_before, unit_after_stop=show(d['unit']),
        guard_identity_and_files_unchanged=True, frozen_caps_respected=True, frozen_inputs_unchanged=True,
        original_errors=assessor['errors'], original_ordinary_assessment=assessor.get('ordinary_assessment'),
        requested3600s_complete=complete,
        p99_for_requested_3600s=assessor.get('ordinary_assessment', {}).get('nearest_rank_p99_ms') if complete else None,
        cleanup_helper=dict(path=str(Path(__file__).resolve()),
            sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),
        further_laptop_tests_authorized=False)
    with (P / 'root-finished-01.json').open('x') as stream:
        stream.write(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: receipt[key] for key in ('status', 'cleanup_complete', 'known_unique_lifetimes',
        'root_verification_elapsed_seconds', 'root_verification_within_original_4380_seconds',
        'original_ordinary_assessment')}))


if __name__ == '__main__':
    main()
