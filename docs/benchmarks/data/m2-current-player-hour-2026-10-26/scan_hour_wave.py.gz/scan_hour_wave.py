"""Streaming independent F32 WAV check; never opens an audio device."""
from array import array
import hashlib
import math
import os
from pathlib import Path
import struct
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def scan_wave(path, native):
    path = Path(path)
    require(path.resolve(strict=True) == path, 'WAV path must be a regular owned output')
    with path.open('rb') as stream:
        before = os.fstat(stream.fileno())
        header = stream.read(12)
        require(len(header) == 12 and header[:4] == b'RIFF' and header[8:] == b'WAVE', 'Invalid RIFF/WAVE header')
        require(int.from_bytes(header[4:8], 'little') + 8 == before.st_size, 'Incomplete RIFF size')
        offset, data, fmt = 12, None, None
        while offset < before.st_size:
            stream.seek(offset)
            chunk = stream.read(8)
            require(len(chunk) == 8, 'Truncated chunk header')
            kind, size = chunk[:4], int.from_bytes(chunk[4:], 'little')
            start, end = offset + 8, offset + 8 + size
            require(end <= before.st_size, 'Truncated WAV chunk')
            if kind == b'fmt ':
                require(fmt is None and size >= 16, 'Invalid or duplicate format chunk')
                fmt = struct.unpack('<HHIIHH', stream.read(16))
            if kind == b'data':
                require(data is None, 'Duplicate data chunk')
                data = (start, size)
            offset = end + (size & 1)
        require(offset == before.st_size and fmt == (3, 2, 48000, 384000, 8, 32), 'Need bounded stereo F32/48k WAV')
        require(data is not None and data[1] > 0 and data[1] % 8 == 0, 'Invalid stereo data size')
        stream.seek(data[0])
        remaining, count, nonzero, peaks = data[1], 0, 0, [0., 0.]
        while remaining:
            size = min(1024 * 1024, remaining)
            raw = stream.read(size)
            require(len(raw) == size, 'Incomplete PCM data')
            samples = array('f')
            samples.frombytes(raw)
            if sys.byteorder != 'little':
                samples.byteswap()
            require(all(math.isfinite(value) for value in samples), 'Nonfinite PCM sample')
            nonzero += sum(value != 0 for value in samples)
            for channel in (0, 1):
                peaks[channel] = max(peaks[channel], max(map(abs, samples[channel::2]), default=0))
            count += len(samples)
            remaining -= size
        stream.seek(0)
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        after, current = os.fstat(stream.fileno()), path.stat()
        identity = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
        require(identity(before) == identity(after) == identity(current), 'WAV changed during analysis')
    frames = count // 2
    expected, writer = native['recorded_audio'], native['recording']
    require(frames == expected['frames'] == writer['acceptedFrames'] == writer['writtenFrames'], 'Recording frame counts differ')
    require(nonzero == expected['nonzero_samples'] and peaks == [expected['peak_left'], expected['peak_right']], 'Recording counts or peaks differ')
    require(writer['overflowFrames'] == 0 and writer['status'] == 'Complete' and writer['error'] == '', 'Recording overflow or incomplete writer')
    return dict(path=str(path), bytes=before.st_size, sha256=digest, frames=frames, samples=count,
        sample_rate=48000, channels=2, all_samples_finite=True, nonzero_samples=nonzero, peaks=peaks,
        matches_native_counts_and_peaks=True, recording_overflow_frames=0)
