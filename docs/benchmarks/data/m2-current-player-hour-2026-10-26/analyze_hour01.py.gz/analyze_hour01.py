"""Summarize closed hour evidence without audio devices or whole-WAV buffering."""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import statistics

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
RUN = BASE / 'hour-01'
PHASES = ('source_read_ms', 'request_ms', 'overlap_ms', 'native_elapsed_ms',
    'native_inference_wall_ms', 'native_inference_cpu_ms', 'native_frontend_ms',
    'native_graph_ms', 'native_graph_upload_ms', 'native_graph_compute_ms',
    'native_graph_readback_ms', 'native_postprocess_ms', 'native_graph_rebuild_ms')


def read(path):
    return json.loads(path.read_text())


def scanner():
    path = BASE / 'scan_hour_wave.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == 'c030a6dc4af178e67edb9eafe11c86d2a5af945a45a308a1f858d1aae50050fd'
    spec = importlib.util.spec_from_file_location('hour_streaming_wave', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.scan_wave


def summarize(run, requested):
    closed = read(run / 'root-finished-01.json')
    assert closed['cleanup_complete']
    budget_key = 'root_verification_within_original_4380_seconds' if requested == 3600 else 'root_verification_within_original_600_seconds'
    assert closed[budget_key]
    result, assessment = (read(run / name) for name in ('output-01/result.json', 'diagnostic-assessment.json'))
    native, observed = result['native'], result['observations']
    rows = observed['chunk_phases']['hops']
    values = [row['hop_service_ms'] for row in rows]
    assert all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in values)
    all_phases = all(type(row.get(key)) in (int, float) and math.isfinite(row[key]) and row[key] >= 0 for row in rows for key in PHASES)
    p99 = sorted(values)[math.ceil(.99 * len(values)) - 1] if values else None
    ordinary = assessment.get('ordinary_assessment', {})
    population_complete = (observed.get('service_metrics_complete') is True
        and observed['service_hops'].get('complete') is True
        and len(rows) == observed['kind_counts'].get('ChunkValidated')
        and observed['service_telemetry_loss'][-1].get('kind') == 'ServiceClosed'
        and all(row.get('dropped') == 0 for row in observed['service_telemetry_loss']))
    if population_complete and ordinary.get('nearest_rank_p99_ms') is not None:
        assert p99 == ordinary['nearest_rank_p99_ms'] and len(values) == ordinary['hop_count']
    complete = assessment.get('diagnostic_complete') is True
    wave = scanner()(run / 'output-01/master.wav', native)
    controls = [{'kind': row['kind'], 'previous_generation': row.get('previous_generation'),
        'recovered': row.get('recovered_cursor_observed_ns', 0) >= row['issued_ns'],
        'recovery_poll_upper_seconds': (row['recovered_cursor_observed_ns'] - row['issued_ns']) / 1e9
            if row.get('recovered_cursor_observed_ns') else None} for row in native['controls']]
    return {'schema': 1, 'status': 'closed_hour_evidence' if requested == 3600 else 'reference_short_evidence',
        'qualified': False, 'M2_complete': False, 'requested_seconds': requested,
        'measured_seconds': native['measured_wall_ms'] / 1000, 'workload_complete': complete,
        'public_fixed_mix_qualified': result.get('qualified') is True,
        'ordinary_assessment': ordinary, 'errors': assessment.get('errors'),
        'runtime': native['setup']['runtime_sha256'], 'source_root': native.get('source_root'),
        'service_hops': len(values), 'service_population_complete': population_complete,
        'all13_service_phase_fields_finite': all_phases,
        'service_median_ms': statistics.median(values) if values else None,
        'observed_nearest_rank_p99_ms': p99, 'observed_maximum_service_ms': max(values) if values else None,
        'p99_for_requested_workload_ms': p99 if complete and population_complete and all_phases else None,
        'at_or_above_target': sum(value >= 4095 for value in values), 'strict_target_ms': 4095,
        'service_phase_maxima_ms': {key: max(row[key] for row in rows) for key in PHASES} if rows and all_phases else None,
        'service_telemetry_loss': observed['service_telemetry_loss'],
        'native_observation_counters': native['observation_counters'],
        'service_kind_counts': observed['kind_counts'],
        'steady_starved_seconds': native['steady_starved_frames'] / 48000,
        'controlled_seek_replay_starved_seconds': native['control_starved_frames'] / 48000,
        'controls': controls, 'peer_rewind_count': len(native.get('peer_controls', [])),
        'manual_control_acknowledgements': sum(row.get('acknowledged') is True for row in native.get('manual_controls', [])),
        'incomplete_generation_seek_submitted': native['incomplete_generation_seek_submitted'],
        'cancellation_scope': 'Generation invalidation and recovery; no hard GPU preemption or physical output-latency claim.',
        'callback_execution_deadline_misses': native['execution_deadline_misses'],
        'invalid_buffers': native['invalid_buffers'], 'rejected_commands': native['rejected_commands'],
        'source_read_failures': native['source_read_failures'], 'driver_timing': native['timing'],
        'UI': native['ui_coverage'], 'scene_errors': native['scene_errors'],
        'maximum_frame_presentation_gap_ns': native['maximum_frame_presentation_gap_ns'],
        'maximum_gui_heartbeat_gap_ns': native['maximum_gui_heartbeat_gap_ns'],
        'window_failure': native.get('window_failure'),
        'post_failure_observation_exercised': 'window_failure_followup' in native,
        'WAV': wave, 'thermal_summary': result['thermal_summary'], 'cleanup': closed,
        'scope': 'Pinned two-deck fixed mix, A live Best stems/B finite peer, visible UI and master WAV. No hardware cue, active EQ/effects, four-deck, musical-analysis, physical-latency or whole-M2 qualification.'}


def main():
    value = summarize(RUN, 3600)
    with (RUN / 'root-audio-results-01.json').open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key: value[key] for key in ('status', 'workload_complete', 'measured_seconds',
        'service_hops', 'p99_for_requested_workload_ms', 'observed_nearest_rank_p99_ms',
        'at_or_above_target', 'steady_starved_seconds', 'controlled_seek_replay_starved_seconds',
        'peer_rewind_count', 'WAV', 'thermal_summary')}))


if __name__ == '__main__':
    main()
