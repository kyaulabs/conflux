"""Read interrupted hour evidence; never manufacture a final native result."""
from array import array
from collections import Counter
from pathlib import Path
import hashlib
import json
import math
import os
import statistics
import struct
import sys

P = Path(__file__).resolve().parent / 'hour-01'
PHASES = ('source_read_ms', 'request_ms', 'overlap_ms', 'native_elapsed_ms',
    'native_inference_wall_ms', 'native_inference_cpu_ms', 'native_frontend_ms',
    'native_graph_ms', 'native_graph_upload_ms', 'native_graph_compute_ms',
    'native_graph_readback_ms', 'native_postprocess_ms', 'native_graph_rebuild_ms')
KINDS = ('ServiceReady', 'RuntimeReady', 'RequestObserved', 'CommandQueued',
    'CommandAccepted', 'ChunkValidated', 'PacketAccepted', 'PacketDiscarded',
    'RawComplete', 'ConverterComplete', 'ServiceClosed')


def read(name):
    return json.loads((P / name).read_text())


def stats(values):
    return {'count': len(values), 'median_ms': statistics.median(values) if values else None,
        'nearest_rank_p99_ms': sorted(values)[math.ceil(.99 * len(values)) - 1] if values else None,
        'maximum_ms': max(values) if values else None}


def scan_unfinalized_wave(path):
    """Inspect retained bytes while keeping the invalid header a failed result."""
    with path.open('rb') as stream:
        before = os.fstat(stream.fileno())
        header = stream.read(12)
        assert header[:4] == b'RIFF' and header[8:] == b'WAVE'
        declared_riff_bytes = int.from_bytes(header[4:8], 'little') + 8
        fmt, offset = None, 12
        while offset + 8 <= before.st_size:
            stream.seek(offset)
            chunk = stream.read(8)
            name, size = chunk[:4], int.from_bytes(chunk[4:], 'little')
            assert offset + 8 + size <= before.st_size
            if name == b'fmt ':
                assert fmt is None and size >= 16
                fmt = struct.unpack('<HHIIHH', stream.read(16))
            if name == b'data':
                data_offset, declared_data_bytes = offset + 8, size
                break
            offset += 8 + size + (size & 1)
        else:
            raise ValueError('No data chunk')
        assert fmt == (3, 2, 48000, 384000, 8, 32)
        retained_data_bytes = before.st_size - data_offset
        assert retained_data_bytes > 0 and retained_data_bytes % 8 == 0
        assert declared_riff_bytes != before.st_size and declared_data_bytes == 0
        stream.seek(data_offset)
        remaining, count, nonzero, peaks = retained_data_bytes, 0, 0, [0., 0.]
        while remaining:
            raw = stream.read(min(1024 * 1024, remaining))
            assert raw and len(raw) % 8 == 0
            samples = array('f'); samples.frombytes(raw)
            if sys.byteorder != 'little':
                samples.byteswap()
            assert all(math.isfinite(value) for value in samples)
            nonzero += sum(value != 0 for value in samples)
            for channel in (0, 1):
                peaks[channel] = max(peaks[channel], max(map(abs, samples[channel::2]), default=0))
            count += len(samples); remaining -= len(raw)
        stream.seek(0)
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        assert identity(before) == identity(os.fstat(stream.fileno())) == identity(path.stat())
    return {'path': str(path), 'bytes': before.st_size, 'sha256': digest,
        'declared_riff_bytes': declared_riff_bytes, 'declared_data_bytes': declared_data_bytes,
        'retained_data_bytes': retained_data_bytes, 'data_offset': data_offset,
        'retained_frames': count // 2, 'retained_samples': count, 'all_retained_samples_finite': True,
        'nonzero_retained_samples': nonzero, 'peaks': peaks,
        'finalized': False, 'valid_complete_recording': False,
        'matches_final_native_counts_and_peaks': None, 'modified_or_repaired': False}


def main():
    result, assessment, closed = (read(n) for n in ('output-01/result.json',
        'diagnostic-assessment.json', 'root-finished-01.json'))
    assert closed['cleanup_complete'] and not assessment['diagnostic_complete']
    assert result['native_exit'] == -15 and 'native' not in result
    counts, telemetry = Counter(), []
    hops, queued, accepted, first_validated = [], {}, {}, {}
    previous, rows = None, 0
    with (P / 'output-01/observations.jsonl').open('rb') as stream:
        context = json.loads(stream.readline(4097))
        assert context['type'] == 'setup'
        setup = context['context']
        assert setup['runtime_sha256'] == result['pins_before']['runtime']['sha256']
        assert setup['model_sha256'] == result['pins_before']['model']['sha256']
        while line := stream.readline(4097):
            assert len(line) <= 4096 and line.endswith(b'\n')
            row = json.loads(line); assert row['type'] == 'record'
            assert type(row['ordinal']) is int and (previous is None or row['ordinal'] == previous + 1)
            previous = row['ordinal']; rows += 1
            assert type(row['kind']) is int and 0 <= row['kind'] < len(KINDS)
            kind = KINDS[row['kind']]; counts[kind] += 1
            if row['telemetry_dropped_present']:
                telemetry.append({'kind': kind, 'generation': row['generation'], 'dropped': row['telemetry_dropped']})
            if kind == 'CommandQueued':
                assert row['command_id'] not in queued
                queued[row['command_id']] = row
            if kind == 'CommandAccepted':
                command = queued[row['command_id']]
                assert all(command[k] == row[k] for k in ('epoch', 'input_first', 'output_first'))
                assert row['observed_ns'] >= command['observed_ns']
                accepted[row['generation']] = command
            if kind == 'ChunkValidated':
                assert row['generation'] in accepted and row['hop_service_present'] is True
                for key in ('hop_service_ms', *PHASES):
                    assert type(row[key]) in (int, float) and math.isfinite(row[key]) and row[key] >= 0
                first_validated.setdefault(row['generation'], row['validated_ns'])
                assert row['validated_ns'] >= row['observed_ns'] > 0
                hops.append({key: row[key] for key in ('epoch', 'generation', 'request_id', 'lease_sequence',
                    'input_first', 'input_frames', 'hop_service_ms', *PHASES)})
    values = [row['hop_service_ms'] for row in hops]
    assert len(values) == counts['ChunkValidated'] and counts['ServiceClosed'] == 0
    command_to_validated = [(first_validated[g] - row['observed_ns']) / 1e6
        for g, row in accepted.items() if g in first_validated]
    assert all(value >= 0 for value in command_to_validated)
    package = '/sys/class/hwmon/hwmon6/temp1_input'
    temperatures, profiles, host_errors, long_caps = [], Counter(), 0, Counter()
    with (P / 'output-01/host-observations.jsonl').open('rb') as stream:
        while line := stream.readline(1024 * 1024):
            assert line.endswith(b'\n')
            row = json.loads(line)
            temperatures.append((row['monotonic_ns'], row['temperatures_millidegrees_C'][package]))
            profiles[row['profile_epp_read_only']['/sys/firmware/acpi/platform_profile']] += 1
            host_errors += bool(row['read_errors'])
            long_caps[row['configured_power_caps_read_only']['/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_power_limit_uw']] += 1
    wave = scan_unfinalized_wave(P / 'output-01/master.wav')
    report = {'schema': 1, 'status': 'interrupted_hour_partial_evidence', 'qualified': False,
        'M2_complete': False, 'requested_seconds': 3600, 'workload_complete': False,
        'last_progress_elapsed_seconds': result['last_progress']['elapsed_ms'] / 1000,
        'native_final_result_available': False, 'native_exit': result['native_exit'],
        'original_outer_errors': read('dispatch-01.json')['errors'], 'original_assessment_errors': assessment['errors'],
        'observed_service_hops': len(values), 'observed_service_stats': stats(values),
        'p99_for_requested_3600s_ms': None, 'service_population_complete': False,
        'at_or_above_target': sum(value >= 4095 for value in values), 'strict_target_ms': 4095,
        'all13_phase_fields_finite_for_retained_hops': True,
        'phase_maxima_ms': {key: max(row[key] for row in hops) for key in PHASES},
        'retained_hops': hops, 'retained_record_count': rows, 'retained_ordinals_contiguous': True,
        'service_kind_counts': counts, 'observed_service_telemetry_reports': telemetry,
        'final_producer_finished_and_drop_counters_available': False,
        'queued_command_to_first_validated_chunk_ms': {**stats(command_to_validated),
            'scope': 'Retained C++ queue and lease validation stamps only; not cursor recovery or audible output latency'},
        'cancellation_cursor_recovery_results': None, 'steady_and_controlled_starvation_results': None,
        'callback_deadline_driver_and_UI_health_summary': None,
        'last_progress': result['last_progress'], 'last_progress_recording_overflow_frames': result['last_progress']['recording']['overflowFrames'],
        'thermal': {'package_sensor': package, 'sample_count': len(temperatures),
            'maximum_package_C': max(v for _, v in temperatures) / 1000,
            'samples_at_or_above85C': sum(v >= 85000 for _, v in temperatures),
            'samples_at_or_above95C': sum(v >= 95000 for _, v in temperatures),
            'nominal_sample_interval_seconds': 2, 'profiles': profiles,
            'mmio_long_limit_uw_observations': long_caps, 'host_read_error_samples': host_errors},
        'WAV': wave, 'cleanup': closed,
        'scope': 'Retained partial trace and unfinalized WAV from a terminated 52-minute attempt; no hour, cancellation, audio-health or M2 pass. Original files remain unchanged.'}
    with (P / 'root-interrupted-audio-results-01.json').open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key: report[key] for key in ('status', 'last_progress_elapsed_seconds',
        'observed_service_hops', 'observed_service_stats', 'at_or_above_target', 'service_kind_counts', 'thermal', 'WAV')}))


if __name__ == '__main__':
    main()
