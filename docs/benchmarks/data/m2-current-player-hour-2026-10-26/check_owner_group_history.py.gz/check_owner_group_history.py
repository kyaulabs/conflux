"""Exercise the actual private owner with simulated process lifetimes; no host launches."""
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

target = Path(sys.argv.pop(1)).resolve()
spec = importlib.util.spec_from_file_location('hour_group_history_owner', target)
owner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owner)


def record(pid, start=1, parent=5000):
    return {'pid': pid, 'start_ticks': start, 'group': pid, 'session': pid,
        'ppid': parent, 'command': ['/offline/helper']}


class GroupHistoryTests(unittest.TestCase):
    def setUp(self):
        self.root = record(5000, parent=1)
        self.table = {5000: self.root}
        self.children = []
        self.owned, self.groups = {}, set()
        def read(pid):
            if pid not in self.table:
                raise FileNotFoundError(pid)
            return dict(self.table[pid])
        self.patches = [patch.object(owner, 'process_record', side_effect=read),
            patch.object(owner, 'children_of', side_effect=lambda pid: list(self.children) if pid == 5000 else []),
            patch.object(owner, 'time', SimpleNamespace(monotonic=lambda: 1.0))]
        for patcher in self.patches:
            patcher.start(); self.addCleanup(patcher.stop)

    def walk(self, deadline=2):
        owner.remember_owned(SimpleNamespace(pid=5000), self.root, self.owned, self.groups, deadline)

    def test_ninety_exited_session_groups_do_not_consume_live_slots(self):
        for pid in range(6000, 6090):
            self.table = {5000: self.root, pid: record(pid)}
            self.children = [pid]
            self.walk()
        self.assertEqual(len(self.owned), 91)
        self.assertEqual(len(self.groups), 91)
        self.assertEqual(len(owner.live_owned(self.owned, [])), 2)
        self.assertEqual(owner.LIVE_LIMIT, 64)

    def test_sixty_five_live_processes_still_fail(self):
        self.children = list(range(6000, 6064))
        self.table.update({pid: record(pid) for pid in self.children})
        with self.assertRaisesRegex(ValueError, 'exceeds64'):
            self.walk()

    def test_history_identity_limit_still_fails(self):
        with patch.object(owner, 'HISTORY_LIMIT', 3):
            for pid in (6000, 6001):
                self.table = {5000: self.root, pid: record(pid)}; self.children = [pid]; self.walk()
            self.table = {5000: self.root, 6002: record(6002)}; self.children = [6002]
            with self.assertRaisesRegex(ValueError, 'history exceeds 3 identities'):
                self.walk()

    def test_history_byte_limit_still_fails(self):
        with patch.object(owner, 'HISTORY_BYTES', 1), self.assertRaisesRegex(ValueError, 'history exceeds 1 bytes'):
            self.walk()
        self.assertFalse(self.owned)

    def test_known_lifetime_cannot_change_group_or_session(self):
        self.table[6000] = record(6000); self.children = [6000]; self.walk()
        self.table[6000] = {**record(6000), 'group': 7000, 'session': 7000}
        with self.assertRaisesRegex(ValueError, 'group/session changed'):
            self.walk()
        self.assertNotIn(7000, self.groups)

    def test_unproven_parent_cannot_supply_a_new_group(self):
        self.table[6000] = record(6000, parent=7000); self.children = [6000]
        with self.assertRaisesRegex(ValueError, 'parent changed'):
            self.walk()
        self.assertNotIn(6000, self.groups)

    def test_pid_reuse_preserves_both_lifetimes_and_counts_only_the_live_one(self):
        self.table[6000] = record(6000); self.children = [6000]; self.walk()
        self.table[6000] = record(6000, start=2); self.walk()
        self.assertIn((6000, 1), self.owned); self.assertIn((6000, 2), self.owned)
        live = owner.live_owned(self.owned, [])
        self.assertEqual(set(live), {(5000, 1), (6000, 2)})

    def test_expired_original_observation_deadline_still_fails(self):
        with self.assertRaisesRegex(ValueError, 'deadline exhausted'):
            self.walk(deadline=1)
        self.assertFalse(self.owned)


if __name__ == '__main__':
    unittest.main()
