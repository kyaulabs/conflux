#include "audio/PreparedTempoSource.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>
using namespace conflux::audio;
struct Input {
    std::uint64_t frames;std::size_t leaves,piece;
    PreparedTempoSource::StreamInput descriptor() {
        return {frames,leaves,this,[](void* context,std::uint64_t,std::uint64_t first,std::span<float> out) noexcept {
            auto& s=*static_cast<Input*>(context);if(first>s.frames)return AudioReadResult{0,true};
            const auto count=std::min<std::uint64_t>({out.size()/(s.leaves*2),s.frames-first,s.piece});
            for(std::size_t f=0;f<count;++f)for(std::size_t leaf=0;leaf<s.leaves;++leaf)for(std::size_t c=0;c<2;++c)
                out[(f*s.leaves+leaf)*2+c]=float(.07*(leaf+1)*std::sin((first+f+17*leaf+31*c)*.019)+.004*c);
            return AudioReadResult{std::size_t(count),false};
        },[](const void*)noexcept{return 0;}};
    }
};
int main(int argc,char**argv) {
 try {
    if(argc!=2||!std::filesystem::create_directory(argv[1]))throw std::runtime_error("Fresh output directory required");
    std::size_t cases=0;
    for(std::size_t frames:{31U,12011U})for(std::size_t leaves:{1U,4U})for(std::size_t piece:{37U,1024U})
      for(bool key:{false,true})for(double percent:{-6.,0.,6.}) {
        Input input{frames,leaves,piece};PreparedTempoSource source(input.descriptor());
        if(!source.request(0,percent,key))throw std::runtime_error("Request failed");
        auto name=std::to_string(frames)+"-"+std::to_string(leaves)+"-"+std::to_string(piece)+"-"+std::to_string(key)+"-"+std::to_string(int(percent))+".f32";
        std::ofstream file(std::filesystem::path(argv[1])/name,std::ios::binary);std::uint64_t count=0;
        const auto until=std::chrono::steady_clock::now()+std::chrono::seconds(5);
        for(;;) {
            auto view=source.peek();
            if(!view) {if(std::chrono::steady_clock::now()>=until)throw std::runtime_error("No DSP completion");std::this_thread::sleep_for(std::chrono::milliseconds(1));continue;}
            if(view.errorCode)throw std::runtime_error("DSP error");
            if(view.terminal) {if(!source.consume(0)||!source.status().finished)throw std::runtime_error("EOF not consumed");break;}
            const auto take=std::min<std::size_t>(17,view.frames);std::vector<float> packed(take*leaves*2);
            for(std::size_t f=0;f<take;++f)for(std::size_t leaf=0;leaf<leaves;++leaf)for(std::size_t c=0;c<2;++c)
                packed[(f*leaves+leaf)*2+c]=view.leaves[leaf][f*2+c];
            file.write(reinterpret_cast<const char*>(packed.data()),std::streamsize(packed.size()*sizeof(float)));count+=take;
            if(!source.consume(take))throw std::runtime_error("Consume failed");
        }
        if(!file||!count||source.nominalPosition()!=double(frames))throw std::runtime_error("Invalid result geometry");
        source.stop();++cases;
    }
    std::cout<<cases<<" complete PCM cases\n";
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}
}
