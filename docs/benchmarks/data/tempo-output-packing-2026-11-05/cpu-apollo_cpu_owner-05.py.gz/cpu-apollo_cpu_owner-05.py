INSIDE="\nfrom pathlib import Path\nimport subprocess,json,time\np=Path('/work');began=time.monotonic();codes={}\ncommands=[('native-configure',['cmake','-S','/native-src','-B','/work/native-build','-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DFROZEN_SOURCE_DIRECTORY=/frozen','-DCANDIDATE_TEMPO_SOURCE=/frozen/src/audio/PreparedTempoSource.cpp','-DPRODUCT_BUILD=/normal','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],45),('native-build',['cmake','--build','/work/native-build','-j2'],300),('controller-strict',['python3','-B','/frozen/tools/experiments/private_routing_check.py','/normal/conflux-preparation-controller-check','/work/controller-strict','--continuation-case','resident-tempo-takeover'],100)]\nfor name,command,limit in commands:\n with(p/(name+'.stdout.log')).open('x')as out,(p/(name+'.stderr.log')).open('x')as err:z=subprocess.run(command,stdout=out,stderr=err,timeout=limit)\n codes[name]=z.returncode\n if z.returncode:break\nreport=dict(completed=True,codes=codes,seconds=time.monotonic()-began,GPU_used=False,audio_hardware_used=False,comparison_players_unarmed=True);(p/'inside-result.json').write_text(json.dumps(report,indent=2)+'\\n');print(json.dumps(report));raise SystemExit(0 if codes.get('controller-strict')==0 else 1)\n"

from pathlib import Path
import subprocess,json,time,os
p=Path(__file__).resolve().parent;D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock'];name='conflux-tempo-pack-cpu-20261105-05';cid=None;attempted=False;report=dict(completed=False,GPU_used=False,audio_hardware_used=False)
import signal
def requested_stop(*_):raise InterruptedError('Owned CPU check stopped')
signal.signal(signal.SIGTERM,requested_stop)
try:
 assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}'],text=True,timeout=5))=='/srv/conflux-tests/docker-data'
 assert subprocess.check_output(D+['ps','-aq'],text=True,timeout=5).strip()==''
 cmd=D+['create','--name',name,'--label','org.kyaulabs.conflux.run='+name,'-i','--init','--runtime=runc','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--pids-limit=1024','--memory=6g','--cpus=2','--env','PYTHONDONTWRITEBYTECODE=1','--env','QT_QPA_PLATFORM=offscreen','--env','QT_QUICK_BACKEND=software','--env','QT_QUICK_CONTROLS_STYLE=Basic','--env','OPENBLAS_NUM_THREADS=1','--env','OMP_NUM_THREADS=1','--env','TMPDIR=/tmp','--env','XDG_CACHE_HOME=/work/cache','--env','XDG_DATA_HOME=/work/data','--env','XDG_STATE_HOME=/work/state','--env','XDG_CONFIG_HOME=/work/config','--mount','type=bind,src='+'/srv/conflux-tests/work/tempo-output-packing-20261105-02/source'+',dst=/source,readonly','--mount','type=bind,src='+str(p)+',dst=/work','--mount','type=bind,src=/srv/conflux-tests/work/tempo-output-packing-20261105-02/source,dst=/frozen,readonly','--mount','type=bind,src=/srv/conflux-tests/work/tempo-output-packing-20261105-02/build,dst=/normal,readonly','--mount','type=bind,src='+str(p/'native-source')+',dst=/native-src,readonly','--mount','type=bind,src=/srv/conflux-tests/work/tempo-output-packing-20261105-02/build,dst=/work/build','--mount','type=bind,src='+str(p/'tmp')+',dst=/tmp']
 attempted=True;cid=subprocess.check_output(cmd+['sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919','python3','-B','-'],text=True,timeout=15).strip();assert len(cid)==64;report['container_id']=cid
 with(p/'container.stdout.log').open('x')as out,(p/'container.stderr.log').open('x')as err:run=subprocess.run(D+['start','--attach','--interactive',cid],input=INSIDE,text=True,stdout=out,stderr=err,timeout=570)
 report.update(completed=True,runner_exit=run.returncode)
 if(p/'inside-result.json').exists():report['inside']=json.loads((p/'inside-result.json').read_text())
except BaseException as e:report['error']=type(e).__name__+': '+str(e)
finally:
 if cid is None and attempted:
  q=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
  if q.returncode==0:
   v=json.loads(q.stdout)[0]
   if v['Config']['Labels'].get('org.kyaulabs.conflux.run')==name:cid=v['Id']
 if cid:
  q=json.loads(subprocess.check_output(D+['inspect',cid],text=True,timeout=5))[0];assert q['Config']['Labels'].get('org.kyaulabs.conflux.run')==name;subprocess.run(D+['rm','--force',cid],check=True,capture_output=True,timeout=15);q=subprocess.run(D+['inspect',cid],capture_output=True,text=True,timeout=5);report['container_absent']=q.returncode!=0 and'no such'in(q.stdout+q.stderr).lower()
 (p/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report));raise SystemExit(0 if report.get('inside',{}).get('codes',{}).get('controller-strict')==0 and report.get('container_absent') else 1)
