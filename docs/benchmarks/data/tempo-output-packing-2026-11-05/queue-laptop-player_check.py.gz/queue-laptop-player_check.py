#!/usr/bin/python
"""Private descriptor-limited player case, called only by the isolated audio owner."""
from pathlib import Path
import importlib.util
import json
import os
import signal
import stat
import subprocess
import sys
import time

if len(sys.argv)!=4 or sys.argv[3]!='--functional-only' or os.environ.get('CONFLUX_PRIVATE_ROUTING_CHECK')!='1':
    raise SystemExit('Explicit private functional routing only')
config=json.loads(Path(os.environ['CONFLUX_QUEUE_PROBE_CONFIG']).read_text())
arm='candidate'
normal=False;mode='private-live-stems-controls'
runtime=Path(sys.argv[1]);assert runtime.is_absolute() and runtime.stat().st_uid==os.getuid() and stat.S_IMODE(runtime.stat().st_mode)==0o700
output=Path(sys.argv[2])/'actual-player';output.mkdir(mode=0o700);(output/'cache').mkdir(mode=0o700)
source=Path(config['source']);peer=Path(config['peer'])
report=dict(schema=1,arm=arm,passed=False,measurement_complete=False,qualified=False,host_audio=False,
    scope='Two-minute fixed106BPM MasterTempo private actual-model queue diagnostic; no physical audio, laptop latency or milestone qualification',
    hard_cancellation_exercised=False)
child=sink=None
try:
    with (output/'sink.stdout.log').open('x') as out,(output/'sink.stderr.log').open('x') as err:
        sink=subprocess.Popen([config['sink']],stdin=subprocess.PIPE,stdout=out,stderr=err,text=True)
    until=time.monotonic()+8
    while time.monotonic()<until:
        assert sink.poll() is None,'Private sink exited'
        graph=json.loads(subprocess.check_output(['pw-dump','-r',os.environ['PIPEWIRE_REMOTE'],'-N'],text=True,timeout=3))
        nodes=[p for p in graph if p.get('type','').endswith(':Node') and p.get('info',{}).get('props',{}).get('node.name')=='conflux-short-live-test-sink']
        if len(nodes)==1:break
        time.sleep(.05)
    else:raise TimeoutError('Owned sink did not appear')
    (output/'sink-graph.json').write_text(json.dumps(graph,indent=2)+'\n')
    client_id=nodes[0]['info']['props']['client.id']
    clients=[p for p in graph if p.get('type','').endswith(':Client') and str(p['id'])==str(client_id)]
    assert len(clients)==1 and str(clients[0]['info']['props']['application.process.id'])==str(sink.pid),'Sink client ownership differs'
    environment=dict(os.environ,QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software',QT_QUICK_CONTROLS_STYLE='Basic',XDG_CACHE_HOME=str(output/'cache'))
    environment.pop('CONFLUX_ALLOW_HOST_SOAK',None)
    command=[config['binary'],'--'+mode,str(source),str(peer),str(output),'120',str(output/'stop'),
        config['python'],config['exporter'],config['worker'],config['service'],
        config['runtime'],config['model']]
    report['command']=command;began=time.monotonic()
    with (output/'player.stdout.log').open('x') as out,(output/'player.stderr.log').open('x') as err:
        child=subprocess.Popen(command,env=environment,stdout=out,stderr=err,start_new_session=True)
        try:
            until=time.monotonic()+210
            while child.poll()is None:
                if Path(config['cancel']).exists():(output/'stop').touch(exist_ok=True)
                if time.monotonic()>=until:raise subprocess.TimeoutExpired(command,210)
                time.sleep(.2)
        except subprocess.TimeoutExpired:
            (output/'stop').touch()
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=3)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=3)
            raise TimeoutError('Native player exceeded the fixed210s diagnostic bound')
    report.update(native_exit=child.returncode,elapsed_seconds=time.monotonic()-began)
    path=output/'native-result.json';assert path.stat().st_size<=1024*1024
    native=json.loads(path.read_text())
    keys=['mode','forced_redraw_interval_ms','functional_only','host_audio','qualified','passed','error','measurement_completion_error',
        'setup','measured_wall_ms','frames_presented','maximum_gui_heartbeat_gap_ns','maximum_frame_presentation_gap_ns',
        'steady_starved_frames','control_starved_frames','eof_count','replay_count','last_recovery_complete','execution_deadline_misses',
        'invalid_buffers','source_read_failures','shutdown_completed','diagnostic_tail','configuration','observation_counters',
        'manual_controls_complete','manual_controls','controls','recording','tempo_diagnostic','tempo_setup','tempo_startup']
    report['native_summary']={k:native[k] for k in keys if k in native}
    report['measurement_complete']=(native.get('measurement_intervals_closed') is True and 120000<=native.get('measured_wall_ms',0)<=122000
        and native.get('mode')==mode and native.get('forced_redraw_interval_ms')==(50 if normal else 16)
        and native.get('functional_only') is True and native.get('host_audio') is False and native.get('qualified') is False
        and native.get('shutdown_completed') is True and native.get('cancelled') is False)
    spec=importlib.util.spec_from_file_location('matched_private_observations',config['parser'])
    parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
    observations=parser.summarize_live_observations(output/'observations.jsonl',native)
    report['observations']=observations
    report['runtime_sha256_expected']=os.environ['CONFLUX_EXPECTED_RUNTIME_SHA256']
    assert native['setup']['runtime_sha256']==report['runtime_sha256_expected']
    assert native['setup']['model_sha256']=='f8c54ba35df95aafea7881eac214b58ec18a73cbcb6ff5a90f4b762631a286b6'
    (output/'observation-summary.json').write_text(json.dumps(observations,indent=2)+'\n')
    hops=observations['service_hops']
    report['service_target_met']=(observations['service_metrics_complete'] is True and hops['complete'] is True and hops['count']>0
        and hops['nearest_rank_p99_ms']<4095)
    report['strict_target_ms']=4095
    recipe=native['tempo_diagnostic']
    assert recipe['reference_bpm']==100 and recipe['target_bpm']==106 and recipe['key_lock']is True and recipe['percent']==6
    report['requested_tempo_recipe']=recipe
    trace=json.loads((output/'tempo-short-reads.json').read_text())
    assert trace['capacity']==64 and trace['all_retained_slots_published'] and trace['private_diagnostic'] and trace['qualified']is False
    assert len(trace['events'])==min(trace['attempted'],64) and trace['overflow']==max(0,trace['attempted']-64)
    assert all(e['wanted']>e['provided']>=0 and 0<=e['pieces']<=8 and e['break_reason']in[1,2]for e in trace['events'])
    report['tempo_short_reads']=trace
    phases=observations['chunk_phases']['fields']
    assert set(phases)==set(parser.LIVE_PHASE_NAMES) and all(row['present_for_all_chunks'] and row['count']==hops['count'] for row in phases.values()),'Missing native phase evidence'
    report['manual_controls_complete']=native.get('manual_controls_complete')is True
    report['diagnostic_complete']=report['measurement_complete'] and report['manual_controls_complete'] and len(native.get('manual_controls',[]))==16
    recording=native['recording']
    assert recording.get('status')=='Complete' and recording.get('error','')=='' and recording['acceptedFrames']==recording['writtenFrames']>0 and recording['overflowFrames']==0,'Recording incomplete or lost frames'
    report['native_functional_passed']=(report['diagnostic_complete'] and child.returncode==0 and native.get('passed') is True and native.get('steady_starved_frames')==0)
    report['passed']=(report['diagnostic_complete'] and child.returncode==0 and native.get('passed') is True
        and native.get('last_recovery_complete') is True and report['service_target_met'] is True)
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
    if child is not None and child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
    if sink is not None:
        if sink.poll() is None:
            sink.stdin.write('stop\n');sink.stdin.flush();sink.stdin.close()
            try:sink.wait(timeout=5)
            except subprocess.TimeoutExpired:sink.kill();sink.wait(timeout=5)
        report['sink_reaped']=sink.poll() is not None
    report['collection_complete']=bool(report.get('diagnostic_complete')and report.get('sink_reaped')and child is not None and child.poll()is not None)
    (output/'assessment.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,allow_nan=False),flush=True)
raise SystemExit(0 if report['passed'] else 1)
