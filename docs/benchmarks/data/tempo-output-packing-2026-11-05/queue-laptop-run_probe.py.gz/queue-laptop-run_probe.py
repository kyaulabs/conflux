"""Dry by default; one bounded private actual-model diagnostic after fresh conditions."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,importlib.util,json,os,signal,subprocess,time,shutil
BASE=Path(__file__).resolve().parent
DOCKER=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
def read(p):return json.loads(Path(p).read_text())
def save(p,v):
 with Path(p).open('x')as f:f.write(json.dumps(v,indent=2,allow_nan=False)+'\n')
def pin(path):
 p=Path(path);assert p.is_absolute()and p.is_file()and not p.is_symlink(),str(p)
 with p.open('rb')as f:d=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=d)
def verify(c):
 assert c['source_head']=='8b9669e92e764822b272984502b25624609d419d'and c['seconds']==120 and c['operator_seconds']==720 and c['qualified']is False
 for r in c['pins']:assert pin(r['path'])==r,r['path']
 ci=read(c['source_ci']);assert ci['source']==c['source_head']and ci['all_six_CI_jobs_passed']and ci['direct_push_source_verified']
 assert not any((BASE/n).exists()for n in ['reservation.json','case','result.json'])
 seed=Path(c['cache_seed']);assert not seed.is_symlink()and not any(x.is_symlink()for x in seed.rglob('*'))
 assert len([x for x in seed.rglob('*')if x.is_file()])==c['cache_seed_file_count']
def human(h,c,now=None):
 now=now or datetime.now(timezone.utc);age=(now-datetime.fromisoformat(h['original_readiness_utc'])).total_seconds()
 assert 0<=age<=120 and h['operator_seconds']==720 and h['config_sha256']==pin(BASE/'config.json')['sha256']
 assert h['question_item_id']and h['human_reply']and all(h.get(k)is True for k in ['AC_power','lid_open','other_work_paused','Codex_minimized','no_suspend','CONFLUX_closed'])
 return age
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--run',action='store_true');args=ap.parse_args();c=read(BASE/'config.json')
 if not args.run:verify(c);print(json.dumps(dict(verified=True,hardware_started=False)));return
 h=read(BASE/'readiness.json');age=human(h,c);deadline=time.monotonic()+720-age;verify(c)
 save(BASE/'reservation.json',dict(original_readiness_utc=h['original_readiness_utc'],deadline_monotonic=deadline,retries=False))
 case=BASE/'case';case.mkdir(mode=0o700);shutil.copytree(c['cache_seed'],case/'driver-cache');report=dict(qualified=False,collection_complete=False,cleanup_complete=False,errors=[],source_head=c['source_head']);child=None;cid=None;host=None;guard=None;creation_attempted=False
 def stop(*_):raise InterruptedError('Bounded diagnostic stopped')
 signal.signal(signal.SIGTERM,stop)
 def observe():
  row=host.observation(paths);power=host.power_state();assert not row['read_errors']and power['ac_online']and power['lid_open'];assert host.guard_identity(Path(c['guard_script']),Path(c['guard_unit']))==guard
  return max(row['temperatures_millidegrees_C'].values())
 try:
  if c['host']=='laptop':
   spec=importlib.util.spec_from_file_location('known_readonly_host',c['host_readings']);host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host);guard=host.guard_identity(Path(c['guard_script']),Path(c['guard_unit']));paths=host.sensor_paths();since=None;until=min(time.monotonic()+180,deadline-360)
   with(case/'settling.jsonl').open('x')as log:
    while time.monotonic()<until:
     temp=observe();now=time.monotonic();since=now if temp<=70000 and since is None else since if temp<=70000 else None;log.write(json.dumps(dict(monotonic=now,max_mC=temp,stable_seconds=0 if since is None else now-since))+'\n');log.flush()
     if since is not None and now-since>=60:break
     time.sleep(2)
    else:raise TimeoutError('Existing70C/60s sampled settling not reached in180s; no workload starts')
   env=dict(os.environ,CONFLUX_QUEUE_PROBE_CONFIG=str(BASE/'client-config.json'));command=[c['python'],'-B',str(BASE/'inside.py')]
  else:
   assert json.loads(subprocess.check_output(DOCKER+['info','--format','{{json .DockerRootDir}}'],text=True,timeout=5))=='/srv/conflux-tests/docker-data'
   assert subprocess.check_output(DOCKER+['ps','-aq'],text=True,timeout=5).strip()==''
   assert subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True,timeout=5).strip()==''
   command=DOCKER+['create','--name',c['container_name'],'--label','org.kyaulabs.conflux.run='+c['container_name'],'--init','--runtime=runc','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--pids-limit=1024','--memory=8g','--device','nvidia.com/gpu=GPU-c58fa4ef-cda8-be9f-eb37-caeb7cf7d42b','--env','CONFLUX_QUEUE_PROBE_CONFIG=/operations/client-config.json','--env','PYTHONDONTWRITEBYTECODE=1']
   (case/'tmp').mkdir(mode=0o700)
   for row in c['mounts']+[[str(case),'/results',False],[str(case/'tmp'),'/tmp',False]]:command+=['--mount','type=bind,src='+row[0]+',dst='+row[1]+(',readonly'if row[2]else'')]
   creation_attempted=True
   cid=subprocess.check_output(command+[c['image'],'python3','-B','/operations/inside.py'],text=True,timeout=15).strip();assert len(cid)==64;report['container_id']=cid;command=DOCKER+['start','--attach',cid];env=os.environ.copy()
  for row in c['pins']:assert pin(row['path'])==row,row['path']
  began=time.monotonic();consecutive=0;abort=False
  with(case/'runner.stdout.log').open('x')as out,(case/'runner.stderr.log').open('x')as err,(case/'host-samples.jsonl').open('x')as log:
   child=subprocess.Popen(command,env=env,stdout=out,stderr=err)
   while child.poll()is None:
    now=time.monotonic()
    if now>=min(began+320,deadline-90):abort=True
    if host:
     temp=observe();consecutive=consecutive+1 if temp>=85000 else 0;log.write(json.dumps(dict(monotonic=now,max_mC=temp))+'\n');log.flush();abort=abort or temp>=95000 or consecutive>=3
    if abort:
     (case/'stop-request').touch(exist_ok=True)
     try:child.wait(timeout=20)
     except subprocess.TimeoutExpired:raise TimeoutError('Diagnostic abort required bounded unit/container fallback')
     raise InterruptedError('Diagnostic stopped by original deadline or retained thermal limits')
    time.sleep(2)
   report['runner_exit']=child.returncode
  r=read(case/'private-player/result.json');a=read(case/'private-player/recordings/actual-player/assessment.json');report.update(collection_complete=a.get('collection_complete')is True,native_passed=a.get('native_functional_passed'),service_target_met=a.get('service_target_met'),trace=a.get('tempo_short_reads'),native_error=a.get('native_summary',{}).get('error'),assessment_error=a.get('error'),private_daemon_reaped=r.get('daemon_reaped'),sink_reaped=a.get('sink_reaped'),graph_clean=r.get('cleanup',{}))
  report['cleanup_complete']=r.get('daemon_reaped')is True and a.get('sink_reaped')is True and r.get('cleanup',{}).get('only_dummy_driver_remains')is True
 except BaseException as err:report['errors'].append(type(err).__name__+': '+str(err))
 finally:
  if child is not None and child.poll()is None and host:
   (case/'stop-request').touch(exist_ok=True)
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:pass
  if cid is None and creation_attempted:
   found=subprocess.run(DOCKER+['inspect',c['container_name']],text=True,capture_output=True,timeout=5)
   if found.returncode==0:
    value=json.loads(found.stdout)[0]
    if value['Config']['Labels'].get('org.kyaulabs.conflux.run')==c['container_name']:cid=value['Id']
  if cid:
   q=subprocess.run(DOCKER+['inspect',cid],text=True,capture_output=True,timeout=5)
   if q.returncode==0:
    value=json.loads(q.stdout)[0];assert value['Config']['Labels']['org.kyaulabs.conflux.run']==c['container_name'];subprocess.run(DOCKER+['rm','--force',cid],check=True,capture_output=True,timeout=15)
   q=subprocess.run(DOCKER+['inspect',cid],text=True,capture_output=True,timeout=5);report['container_absent']=q.returncode!=0 and'no such'in(q.stdout+q.stderr).lower()
  if child is not None and child.poll()is None:
   child.terminate()
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
  report['within_original_deadline']=time.monotonic()<=deadline;save(BASE/'result.json',report)
 print(json.dumps(report))
 raise SystemExit(0 if report['collection_complete']and report['cleanup_complete']and not report['errors']else 1)
if __name__=='__main__':main()
