INSIDE="\nfrom pathlib import Path\nimport subprocess,json,time,os\np=Path('/work');started=time.monotonic();codes={}\nselected='^audio-(prepared-tempo|stream-tempo|live-tempo|loop-tempo|loops|tempo-transport|live-recovery)$'\ncommands=[('remaining-normal-tests',['ctest','--test-dir','/work/build','-R','^manual-(ui|playback-modes)$','--output-on-failure','-j1'],300),('asan-configure',['cmake','-S','/source','-B','/work/asan','-G','Ninja','-DCONFLUX_BUILD_UI=OFF','-DBUILD_TESTING=ON','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -fno-pie','-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined -no-pie'],60),('asan-build',['cmake','--build','/work/asan','--target','conflux-audio-prepared-tempo-test','conflux-audio-stream-tempo-test','conflux-audio-live-tempo-test','conflux-audio-loop-tempo-test','conflux-audio-loops-test','conflux-audio-tempo-transport-test','conflux-audio-live-recovery-test','-j2'],360),('asan-test',['ctest','--test-dir','/work/asan','-R',selected,'--output-on-failure','-j1'],120)]\nfor name,command,limit in commands:\n env=dict(os.environ)\n if name=='asan-test':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')\n with(p/(name+'.stdout.log')).open('x')as out,(p/(name+'.stderr.log')).open('x')as err:run=subprocess.run(command,env=env,stdout=out,stderr=err,timeout=limit)\n codes[name]=run.returncode\n if run.returncode:break\nreport=dict(completed=True,codes=codes,seconds=time.monotonic()-started,GPU_used=False,audio_hardware_used=False);(p/'inside-result.json').write_text(json.dumps(report,indent=2)+'\\n');print(json.dumps(report));raise SystemExit(0 if codes.get('asan-test')==0 else 1)\n"

from pathlib import Path
import subprocess,json,time,os
p=Path(__file__).resolve().parent;D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock'];name='conflux-tempo-pack-cpu-20261105-04';cid=None;attempted=False;report=dict(completed=False,GPU_used=False,audio_hardware_used=False)
import signal
def requested_stop(*_):raise InterruptedError('Owned CPU check stopped')
signal.signal(signal.SIGTERM,requested_stop)
try:
 assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}'],text=True,timeout=5))=='/srv/conflux-tests/docker-data'
 assert subprocess.check_output(D+['ps','-aq'],text=True,timeout=5).strip()==''
 cmd=D+['create','--name',name,'--label','org.kyaulabs.conflux.run='+name,'-i','--init','--runtime=runc','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--pids-limit=1024','--memory=6g','--cpus=2','--env','PYTHONDONTWRITEBYTECODE=1','--env','QT_QPA_PLATFORM=offscreen','--env','QT_QUICK_BACKEND=software','--env','QT_QUICK_CONTROLS_STYLE=Basic','--env','OPENBLAS_NUM_THREADS=1','--env','OMP_NUM_THREADS=1','--env','TMPDIR=/tmp','--env','XDG_CACHE_HOME=/work/cache','--env','XDG_DATA_HOME=/work/data','--env','XDG_STATE_HOME=/work/state','--env','XDG_CONFIG_HOME=/work/config','--mount','type=bind,src='+'/srv/conflux-tests/work/tempo-output-packing-20261105-02/source'+',dst=/source,readonly','--mount','type=bind,src='+str(p)+',dst=/work','--mount','type=bind,src=/srv/conflux-tests/work/tempo-output-packing-20261105-02/build,dst=/work/build','--mount','type=bind,src='+str(p/'tmp')+',dst=/tmp']
 attempted=True;cid=subprocess.check_output(cmd+['sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919','python3','-B','-'],text=True,timeout=15).strip();assert len(cid)==64;report['container_id']=cid
 with(p/'container.stdout.log').open('x')as out,(p/'container.stderr.log').open('x')as err:run=subprocess.run(D+['start','--attach','--interactive',cid],input=INSIDE,text=True,stdout=out,stderr=err,timeout=880)
 report.update(completed=True,runner_exit=run.returncode)
 if(p/'inside-result.json').exists():report['inside']=json.loads((p/'inside-result.json').read_text())
except BaseException as e:report['error']=type(e).__name__+': '+str(e)
finally:
 if cid is None and attempted:
  q=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
  if q.returncode==0:
   v=json.loads(q.stdout)[0]
   if v['Config']['Labels'].get('org.kyaulabs.conflux.run')==name:cid=v['Id']
 if cid:
  q=json.loads(subprocess.check_output(D+['inspect',cid],text=True,timeout=5))[0];assert q['Config']['Labels'].get('org.kyaulabs.conflux.run')==name;subprocess.run(D+['rm','--force',cid],check=True,capture_output=True,timeout=15);q=subprocess.run(D+['inspect',cid],capture_output=True,text=True,timeout=5);report['container_absent']=q.returncode!=0 and'no such'in(q.stdout+q.stderr).lower()
 (p/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report));raise SystemExit(0 if report.get('inside',{}).get('codes',{}).get('asan-test')==0 and report.get('container_absent') else 1)
