from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from test_process_cpu import driver, stat_line


class ThreadCpuTests(unittest.TestCase):
    def fixture(self, root):
        proc = root / 'proc'; directory = proc / '15'
        directory.mkdir(parents=True)
        binary = root / 'native'; binary.write_bytes(b'fixture')
        (directory / 'exe').symlink_to(binary)
        (directory / 'stat').write_text(stat_line(15, user=1000, system=0, start=90))
        for tid, ticks, start in ((15, 100, 90), (16, 200, 91)):
            task = directory / 'task' / str(tid); task.mkdir(parents=True)
            (task / 'stat').write_text(stat_line(tid, user=ticks, system=0, start=start))
        return proc, binary, {'pid': 15, 'start_ticks': 90}

    def test_separates_main_and_worker_task_cpu_from_process_total(self):
        with tempfile.TemporaryDirectory() as path:
            proc, binary, process = self.fixture(Path(path))
            with patch.object(driver.time, 'monotonic_ns', return_value=1_000_000_000):
                first = driver.capture_native_thread_cpu(process, None, proc, binary)
            self.assertTrue(first['complete'])
            self.assertEqual([r['cpu_ticks'] for r in first['threads']], [100, 200])
            for tid, ticks in ((15, 110), (16, 300)):
                (proc / '15/task' / str(tid) / 'stat').write_text(stat_line(tid, user=ticks, system=0, start=90 if tid == 15 else 91))
            with (patch.object(driver.time, 'monotonic_ns', return_value=3_000_000_000),
                  patch.object(driver.os, 'sysconf', return_value=100)):
                second = driver.capture_native_thread_cpu(process, first, proc, binary)
            self.assertEqual([r['cpu_cores_since_previous_observation'] for r in second['threads']], [.05, .5])

    def test_reused_tid_and_incompatible_parent_lifetime_do_not_inherit_cpu(self):
        with tempfile.TemporaryDirectory() as path:
            proc, binary, process = self.fixture(Path(path))
            first = driver.capture_native_thread_cpu(process, None, proc, binary)
            (proc / '15/task/16/stat').write_text(stat_line(16, user=1, system=0, start=92))
            second = driver.capture_native_thread_cpu(process, first, proc, binary)
            self.assertIsNone(second['threads'][1]['cpu_cores_since_previous_observation'])
            first['process_start_ticks'] = 1
            third = driver.capture_native_thread_cpu(process, first, proc, binary)
            self.assertTrue(all(r['cpu_cores_since_previous_observation'] is None for r in third['threads']))

    def test_wrong_executable_is_not_profiled(self):
        with tempfile.TemporaryDirectory() as path:
            proc, binary, process = self.fixture(Path(path))
            other = Path(path) / 'other'; other.write_bytes(b'other')
            result = driver.capture_native_thread_cpu(process, None, proc, other)
            self.assertFalse(result['matched_expected_exe'])
            self.assertEqual(result['threads'], [])

    def test_parent_lifetime_change_discards_the_entire_batch(self):
        with tempfile.TemporaryDirectory() as path:
            proc, binary, process = self.fixture(Path(path))
            original = driver.parse_process_stat; calls = 0
            def changing(raw, pid):
                nonlocal calls
                calls += 1; value = original(raw, pid)
                if calls == 4: value['start_ticks'] += 1
                return value
            with patch.object(driver, 'parse_process_stat', side_effect=changing):
                result = driver.capture_native_thread_cpu(process, None, proc, binary)
            self.assertFalse(result['complete'])
            self.assertEqual(result['threads'], [])
            self.assertIn('lifetime', result['errors'][0]['message'])

    def test_exited_thread_preserves_other_rows_and_marks_capture_incomplete(self):
        with tempfile.TemporaryDirectory() as path:
            proc, binary, process = self.fixture(Path(path))
            (proc / '15/task/17').mkdir()
            result = driver.capture_native_thread_cpu(process, None, proc, binary)
            self.assertFalse(result['complete'])
            self.assertEqual(len(result['threads']), 2)
            self.assertEqual(result['errors'][0]['tid'], 17)

    def test_thread_bound_is_enforced_before_task_stat_reads(self):
        with tempfile.TemporaryDirectory() as path:
            proc, binary, process = self.fixture(Path(path))
            for tid in range(129): (proc / '15/task' / str(tid)).mkdir(exist_ok=True)
            result = driver.capture_native_thread_cpu(process, None, proc, binary)
            self.assertFalse(result['complete'])
            self.assertEqual(result['threads'], [])
            self.assertIn('128 TID', result['errors'][0]['message'])


if __name__ == '__main__':
    unittest.main()
