"""Analyze retained partial output only; no player, audio device or model starts."""
from pathlib import Path
import hashlib
import json
import math
import statistics

ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
RUN=Path(__file__).resolve().parent/'player-01'
HELPER=ROOT/'build/m2-meter-stability-01/analyze_ui_comparison.py'
source=HELPER.read_text();marker="assert read(BASE/'root-finished-01.json')"
assert source.count(marker)==1
namespace={'__file__':str(HELPER)}
exec(compile(source.split(marker,1)[0],str(HELPER),'exec'),namespace)
result=json.loads((RUN/'output-01/result.json').read_text())
native=result['native'];observed=result['observations'];hops=observed['chunk_phases']['hops']
values=[row['hop_service_ms'] for row in hops]
assert len(hops)==11 and max(values)==10041.248880967032 and sum(v>=4095 for v in values)==6
phases=('source_read_ms','request_ms','overlap_ms','native_elapsed_ms','native_inference_wall_ms',
    'native_inference_cpu_ms','native_frontend_ms','native_graph_ms','native_graph_upload_ms',
    'native_graph_compute_ms','native_graph_readback_ms','native_postprocess_ms','native_graph_rebuild_ms')
assert all(type(row.get(key)) in (int,float) and math.isfinite(row[key]) and row[key]>=0
    for row in hops for key in phases)
wave=namespace['scan_wave'](RUN/'output-01/master.wav',native)
host=[json.loads(line) for line in (RUN/'output-01/host-observations.jsonl').read_bytes().splitlines()]
threads=namespace['summarize_threads'](host)
controls=[{'kind':row['kind'],'previous_generation':row['previous_generation'],
    'recovery_poll_upper_seconds':(row['recovered_cursor_observed_ns']-row['issued_ns'])/1e9,'recovered':True}
    for row in native['controls']]
closed=json.loads((RUN/'root-finished-01.json').read_text())
assert closed['cleanup_complete'] and closed['root_verification_within_original_600_seconds']
analysis={'schema':1,'status':'incomplete_normal_runtime_run_retained','qualified':False,
    'requested_seconds':120,'measured_seconds':native['measured_wall_ms']/1000,'requested_workload_p99_ms':None,
    'runtime':native['setup']['runtime_sha256'],'normal_runtime_used':True,
    'coarse_GPU_interval_instrumentation_enabled':False,'getter_counters_enabled':False,
    'partial_observed_hops':len(hops),'partial_observed_median_ms':statistics.median(values),
    'partial_observed_maximum_ms':max(values),'partial_at_or_above4095_ms':sum(v>=4095 for v in values),
    'strict_service_target_ms':4095,'all13_phase_fields_finite_for_observed_hops':True,
    'service_telemetry_loss':observed['service_telemetry_loss'],'native_observation_counters':native['observation_counters'],
    'service_kind_counts':observed['kind_counts'],'full120s_and_closed_control_population_incomplete':True,
    'original_ordinary_assessment':closed['original_ordinary_assessment'],
    'steady_starved_seconds_so_far':native['steady_starved_frames']/48000,
    'control_starved_seconds_so_far':native['control_starved_frames']/48000,
    'controls_acknowledged':sum(row.get('acknowledged') is True for row in native['manual_controls']),
    'scheduled_controls':16,'manual_controls_complete':native['manual_controls_complete'],
    'completed_control_recoveries':controls,
    'cancellation_scope':'Only exercised generation invalidation/recovery; no hard GPU preemption or full-control qualification.',
    'callback_execution_deadline_misses':native['execution_deadline_misses'],'invalid_buffers':native['invalid_buffers'],
    'rejected_commands':native['rejected_commands'],'source_read_failures':native['source_read_failures'],
    'driver_timing':native['timing'],'UI':native['ui_coverage'],'window_failure':native['window_failure'],
    'WAV':wave,'thermal_summary':result['thermal_summary'],'cleanup':closed,
    'analysis_source':{'path':str(HELPER),'sha256':hashlib.sha256(HELPER.read_bytes()).hexdigest()},
    'scope':'Partial exposure-stop run. Observed latency overruns/starvation remain independent evidence. No requested120s p99, normal-runtime, sustained, musical or M2 qualification. Physical window observation pending.'}
for name,value in [('root-partial-audio-results-01.json',analysis),('root-thread-cpu-analysis-01.json',threads)]:
    with (RUN/name).open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps({key:analysis[key] for key in ('status','measured_seconds','partial_observed_hops',
    'partial_observed_maximum_ms','partial_at_or_above4095_ms','steady_starved_seconds_so_far',
    'control_starved_seconds_so_far','controls_acknowledged','completed_control_recoveries','WAV','thermal_summary')}))
