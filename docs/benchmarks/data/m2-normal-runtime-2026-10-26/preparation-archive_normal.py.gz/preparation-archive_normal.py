"""Archive the failed normal-runtime diagnostic as text evidence only."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

BASE=Path(__file__).resolve().parent
RUN=BASE/'player-01'
ROOT=BASE.parent.parent
DEST=ROOT/'build/m2-profile-reporting-worktree/docs/benchmarks/data/m2-normal-runtime-2026-10-26'
RAW=BASE/'archive-raw-01'


def sha(raw):return hashlib.sha256(raw).hexdigest()


def main():
    assert not DEST.exists() and not RAW.exists()
    audio=json.loads((RUN/'root-partial-audio-results-01.json').read_text())
    closed=json.loads((RUN/'root-finished-01.json').read_text())
    human=json.loads((RUN/'root-user-window-observation-01.json').read_text())
    assert audio['requested_workload_p99_ms'] is None and audio['partial_at_or_above4095_ms']==6
    assert closed['cleanup_complete'] and closed['root_verification_within_original_600_seconds']
    assert human['human_reply']=='It stayed visible and untouched'
    sources=[(p,'player-'+p.name) for p in RUN.iterdir() if p.is_file() and
        (p.suffix in ('.json','.py') or p.name in ('offline-checks-suffix-01.log','file-preflight-01.log','launch-command-01.txt'))]
    sources += [(RUN/'output-01'/name,'output-'+name) for name in ('result.json','native-result.json','progress.json',
        'observations.jsonl','host-observations.jsonl','owned-pipewire-cleanup.json','native.stdout.log','native.stderr.log')]
    sources += [(p,'preparation-'+p.name) for p in BASE.iterdir() if p.is_file() and
        (p.suffix in ('.json','.py') or p.name.startswith('window-history-') and p.suffix=='.log')]
    sources += [(BASE/'qt-upstream-source-01/source-proof-01.json','Qt-official-source-proof.json'),
        (ROOT/'build/m2-meter-stability-01/analyze_ui_comparison.py','shared-audio-thread-analysis.py')]
    assert len(sources)==len({name for _,name in sources})
    RAW.mkdir(mode=0o700);rows=[]
    for path,name in sorted(sources,key=lambda pair:pair[1]):
        assert path.resolve(strict=True)==path and path.is_file() and path.stat().st_size<32*1024**2
        raw=path.read_bytes();raw.decode('utf-8')
        if path.suffix=='.json':json.loads(raw)
        if path.suffix=='.jsonl':
            assert raw.endswith(b'\n')
            for line in raw.splitlines():json.loads(line)
        (RAW/name).write_bytes(raw)
        rows.append({'original_path':str(path),'raw_file':name,'raw_bytes':len(raw),'raw_sha256':sha(raw)})
    scanner=shutil.which('gitleaks');assert scanner
    command=[scanner,'dir','--no-banner','--redact','--max-target-megabytes','32',str(RAW)]
    with (BASE/'archive-gitleaks-01.log').open('xb') as stream:
        done=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
    log=(BASE/'archive-gitleaks-01.log').read_bytes();total=sum(row['raw_bytes'] for row in rows)
    count=re.search(rb'scanned ~(\d+) bytes',log)
    assert done.returncode==0 and count and int(count[1])==total
    DEST.mkdir()
    for row in rows:
        raw=(RAW/row['raw_file']).read_bytes();compressed=gzip.compress(raw,compresslevel=9,mtime=0)
        assert gzip.decompress(compressed)==raw
        name=row['raw_file']+'.gz';(DEST/name).write_bytes(compressed)
        row.update(archive_file=name,archive_bytes=len(compressed),archive_sha256=sha(compressed))
    manifest={'schema':1,'qualified':False,'normal_runtime_used':True,'requested120s_complete':False,
        'requested120s_p99_ms':None,'partial_hops':11,'partial_maximum_ms':10041.248880967032,'partial_late_hops':6,
        'strict_service_target_ms':4095,'guard_and15W_ceiling_preserved':True,'user_reports_window_unchanged':True,
        'original_failure_retained':True,'root_cleanup_within_original600s':True,'Qt_timeout_explanation':'Hypothesis supported by source and event timing, not captured runtime proof',
        'failure_followup_regression':'QtCore-only behavior failed before implementation and passed afterward; real-player followup remains untested',
        'milestone_or_release_gate_changed':False,'files':rows,'total_raw_bytes':total,
        'total_archive_bytes':sum(row['archive_bytes'] for row in rows),'gzip_roundtrip_and_original_hashes_verified':True,
        'no_audio_models_executables_PCM_or_full_third_party_source_published':True,
        'raw_secret_scan':{'command':command,'exit':0,'scanned_bytes':total,'log_sha256':sha(log)}}
    with (DEST/'verification.json').open('x') as stream:json.dump(manifest,stream,indent=2,allow_nan=False);stream.write('\n')
    for row in rows:
        data=(DEST/row['archive_file']).read_bytes()
        assert sha(data)==row['archive_sha256'] and sha(gzip.decompress(data))==row['raw_sha256']
        (RAW/row['raw_file']).unlink()
    RAW.rmdir()
    print(json.dumps({'files':len(rows),'raw_bytes':total,'gzip_bytes':manifest['total_archive_bytes'],
        'all_raw_bytes_secret_scanned':True,'all_round_trips_verified':True}))


if __name__=='__main__':main()
