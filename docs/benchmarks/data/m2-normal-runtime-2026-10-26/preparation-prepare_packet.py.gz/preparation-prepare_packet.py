"""Prepare an unarmed normal-runtime comparison; never execute native code."""
import copy
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
OLD = ROOT/'build/m2-uninstrumented-repeat-01/player-02'
NEW = BASE/'player-01'
MODE = 'm2-fixed-meter-normal-runtime-120-01'
NORMAL_BUILD = ROOT/'benchmarks-local/m2-graph-phase-2026-10-18/flash-promoted-native-build'
PROOF = ROOT/'benchmarks-local/m2-graph-phase-2026-10-18/flash-promoted-repro-01/result.json'


def pin(path):
    raw = path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def replace_once(text, before, after):
    assert text.count(before) == 1, before[:120]
    return text.replace(before, after, 1)


prior_cleanup = json.loads((OLD/'root-finished-01.json').read_text())
assert prior_cleanup['cleanup_complete'] and prior_cleanup['requested120s_complete']
assert prior_cleanup['root_verification_within_original_600_seconds']
prior = json.loads((OLD/'plan.json').read_text())
reference = json.loads(PROOF.read_text())
proof_pin = pin(PROOF)
assert proof_pin['sha256'] == '44554b8e1caca9e92a49be7b9cc0e05ba7248f0091b4cdfc005e87e2c87ffe70'
runtime_pin = pin(NORMAL_BUILD/'conflux-stem-runtime')
assert runtime_pin['sha256'] == '6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53'
NEW.mkdir()
for name in ('test_host_player.py','test_process_cpu.py','test_thread_cpu.py','test_ui_provenance.py'):
    shutil.copyfile(OLD/name,NEW/name)

driver = (OLD/'run_host_player.py').read_text()
driver = replace_once(driver, "MODE = 'm2-fixed-meter-uninstrumented-120-02'", f'MODE = {MODE!r}')
driver = replace_once(driver, f"RUNTIME = Path({prior['assets']['runtime']['path']!r})", f"RUNTIME = Path({runtime_pin['path']!r})")
driver = replace_once(driver, f"RUNTIME_SHA = {prior['assets']['runtime']['sha256']!r}", f"RUNTIME_SHA = {runtime_pin['sha256']!r}")
driver = replace_once(driver, 'PCM_PREREQUISITE = '+repr(prior['helpers']['exact_pcm_prerequisite']), 'PCM_PREREQUISITE = '+repr(proof_pin))
start = driver.index("    proof=decode(pin_read(plan['helpers']['exact_pcm_prerequisite']")
end = driver.index('\n\ndef verify_historical_build_file',start)
driver = driver[:start]+'''    proof=decode(pin_read(plan['helpers']['exact_pcm_prerequisite']['path'],PCM_PREREQUISITE,maximum=128*1024,deadline=deadline,keep=True)[1])
    validate_normal_pcm_proof(plan,proof)
    built=decode(pin_read(plan['helpers']['normal_runtime_build_receipt']['path'],
        plan['helpers']['normal_runtime_build_receipt'],maximum=256*1024,deadline=deadline,keep=True)[1])
    require(built.get('status')=='built_metadata_verified_native_execution_pending' and
        built.get('runtime')==plan['assets']['runtime'] and built.get('before_after_inputs_unchanged') is True and
        built.get('build_receipt',{}).get('exit_code')==0 and
        built['build_receipt']['file']==plan['helpers']['normal_runtime_build_execution'],
        'Normal runtime build receipt differs')
    for key,name in [('runtime_source','conflux-flash-f32/ggml-vulkan.cpp'),
                     ('normal_pipeline_source','conflux-flash-f32/pipeline.cpp')]:
        require(built['inspection']['generated_inputs'][name]==plan['sources'][key],
            'Normal runtime generated source binding differs')


def validate_normal_pcm_proof(plan,proof):
    require(proof.get('schema')==1 and proof.get('status')=='reproduction_complete' and
        proof.get('runtime_sha256')==NORMAL==RUNTIME_SHA and proof.get('model_sha256')==MODEL and
        proof.get('errors')==[] and proof.get('completed_requests')==16 and
        proof.get('total_completed_requests')==16 and proof.get('completed_cases_per_runtime')=={'diagnostic':16} and
        all(proof.get(k) is True for k in ('native_started','cleanup_complete','private_spool_removed',
            'pins_unchanged','all_outputs_match_closed_B','input_sha_match','phase_fields_valid')),
        'Normal exact16 completion/runtime/cleanup prerequisite differs')
    before=proof['pins_before']
    require(before==proof.get('pins_after') and proof.get('build_receipt_sha256')==
        plan['helpers']['normal_runtime_build_receipt']['sha256'], 'Normal proof input/build identity differs')
    for key,expected in [('runtime',plan['assets']['runtime']),('model',plan['assets']['model']),
                         ('build_receipt',plan['helpers']['normal_runtime_build_receipt'])]:
        require({k:before[key].get(k) for k in ('path','bytes','sha256')}==expected,
            'Normal proof frozen runtime/model/build pin differs')
    runtimes=proof.get('runtimes')
    require(type(runtimes) is list and len(runtimes)==1 and
        runtimes[0].get('executable')==str(RUNTIME), 'Normal proof executable differs')
    runtime=runtimes[0];ready=runtime.get('ready',{})
    require(ready.get('backend')=='vulkan' and ready.get('threads')==2 and
        ready.get('weight_storage')=='native' and ready.get('fence_wait_mode')=='blocking' and
        ready.get('segment_frames')==343980 and ready.get('sample_rate')==44100 and ready.get('channels')==2 and
        ready.get('stems')==['drums','bass','other','vocals'] and ready.get('model')==plan['assets']['model']['path'] and
        ready.get('process_environment')=={'OMP_WAIT_POLICY':'PASSIVE','GOMP_SPINCOUNT':'0'} and
        all(runtime.get('cleanup',{}).get(k) is True for k in
            ('complete','close_returned','reaped','temporary_directory_removed')),
        'Normal proof Best runtime configuration or child cleanup differs')
    expected=[(track,start) for track in ('club_xl','when_the_light_breaks','under_my_skin','stfu')
        for start in (0,257985,515970,773955)]
    requests=runtime.get('requests')
    require(type(requests) is list and len(requests)==16, 'Normal proof must contain all sixteen windows')
    for index,(row,(track,start)) in enumerate(zip(requests,expected),1):
        require(row.get('id')==f'{track}:{start}' and row.get('track')==track and row.get('start_frame')==start and
            row.get('valid_frames')==(257985 if start==773955 else 343980) and
            row.get('shape')==[343980,2] and row.get('dtype')=='<f4' and row.get('request_id')==index and
            row.get('output_shape')==[4,343980,2] and row.get('output_dtype')=='<f4' and row.get('output_bytes')==11007360 and
            all(row.get(k) is True for k in ('completed','input_sha_match','output_matches_closed_B','finite','phase_fields_valid')) and
            all(type(row.get(k)) is str and re.fullmatch('[0-9a-f]{64}',row[k]) for k in ('input_sha256','output_sha256')),
            'Normal proof exact window/input/output identity differs')
        metrics=row.get('native_metrics',{})
        require(metrics.get('event')=='result' and metrics.get('id')==index and metrics.get('frames')==343980 and
            metrics.get('stems')==4 and all(type(metrics.get(k.removeprefix('native_'))) in (int,float) and
                math.isfinite(metrics[k.removeprefix('native_')]) and metrics[k.removeprefix('native_')]>=0
                for k in PHASES[3:]), 'Normal proof native phases missing or nonfinite')
''' + driver[end:]
(NEW/'run_host_player.py').write_text(driver)
owner = (OLD/'run_player_owned.py').read_text()
owner = replace_once(owner, "LAUNCHER_SHA = "+repr(prior['sources']['launcher']['sha256']),
    "LAUNCHER_SHA = "+repr(pin(NEW/'run_host_player.py')['sha256']))
(NEW/'run_player_owned.py').write_text(owner)
(NEW/'run_player_owned.py').chmod(0o700)
(NEW/'launch-command-01.txt').write_text(f'/usr/bin/kde-inhibit --power --screenSaver {NEW}/run_player_owned.py --run\n')

tests = '''"""Normal-runtime evidence validation only; no process or model execution."""
import copy
import json
from pathlib import Path
import unittest
from test_host_player import driver


class NormalProofTests(unittest.TestCase):
    def fixture(self):
        plan=json.loads(driver.PLAN.read_text())
        proof=json.loads(Path(driver.PCM_PREREQUISITE['path']).read_text())
        return plan,proof

    def test_complete_normal16_reference_is_accepted(self):
        plan,proof=self.fixture();driver.validate_normal_pcm_proof(plan,proof)

    def test_diagnostic_runtime_cannot_be_mislabelled_normal(self):
        plan,original=self.fixture()
        for mutate in (lambda p:p.update(runtime_sha256='c63b1299877d0f7f6df9d8ca688f0bd88be1406a5da1be71233bc01231b4a6c6'),
                       lambda p:p['runtimes'][0].update(executable='/offline/instrumented-runtime')):
            proof=copy.deepcopy(original);mutate(proof)
            with self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_missing_or_duplicate_window_is_rejected(self):
        plan,original=self.fixture()
        for mutate in (lambda rows:rows.pop(),lambda rows:rows.__setitem__(1,copy.deepcopy(rows[0]))):
            proof=copy.deepcopy(original);mutate(proof['runtimes'][0]['requests'])
            with self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_unverified_pcm_or_wrong_output_shape_is_rejected(self):
        plan,original=self.fixture()
        for key,value in [('finite',False),('input_sha_match',False),('output_matches_closed_B',False),
                          ('output_shape',[2,343980,2]),('output_bytes',1),('valid_frames',1)]:
            proof=copy.deepcopy(original);proof['runtimes'][0]['requests'][0][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_missing_or_nonfinite_native_timing_is_rejected(self):
        plan,original=self.fixture()
        for value in (None,float('nan'),float('inf'),-1,True):
            proof=copy.deepcopy(original);proof['runtimes'][0]['requests'][0]['native_metrics']['graph_compute_ms']=value
            with self.subTest(value=value),self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_failed_cleanup_or_changed_input_pins_is_rejected(self):
        plan,original=self.fixture()
        for mutate in (lambda p:p.update(cleanup_complete=False),lambda p:p.update(private_spool_removed=False),
                       lambda p:p['runtimes'][0]['cleanup'].update(reaped=False),
                       lambda p:p['pins_after']['model'].update(sha256='a'*64)):
            proof=copy.deepcopy(original);mutate(proof)
            with self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_precision_thread_or_backend_changes_are_rejected(self):
        plan,original=self.fixture()
        for key,value in [('backend','cpu'),('threads',1),('weight_storage','f16'),('fence_wait_mode','spin')]:
            proof=copy.deepcopy(original);proof['runtimes'][0]['ready'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_wrong_normal_runtime_build_receipt_is_rejected(self):
        plan,proof=self.fixture();plan['helpers']['normal_runtime_build_receipt']['sha256']='a'*64
        with self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)


if __name__=='__main__':unittest.main()
'''
(NEW/'test_normal_proof.py').write_text(tests)
plan = copy.deepcopy(prior)
plan.update(mode=MODE,quality='Best; promoted normal runtime; sixteen exact accepted-reference PCM matches',
    workload_scope='One two-minute visible fixed-meter player check with the normal stem runtime. Same audio, UI, controls, quality, thermal/cap rules and strict latency target. No coarse GPU interval instrumentation or getter counters. No sustained/milestone qualification.')
plan['assets']['runtime']=runtime_pin
plan['helpers']['exact_pcm_prerequisite']=proof_pin
plan['helpers']['normal_runtime_build_receipt']=pin(Path(reference['pins_before']['build_receipt']['path']))
built=json.loads(Path(plan['helpers']['normal_runtime_build_receipt']['path']).read_text())
plan['helpers']['normal_runtime_build_execution']=pin(Path(built['build_receipt']['file']['path']))
for key,name in [('launcher','run_host_player.py'),('outer_owner','run_player_owned.py'),
                 ('operator_launch','launch-command-01.txt'),('normal_proof_tests','test_normal_proof.py')]:
    plan['sources'][key]=pin(NEW/name)
for key,name in [('runtime_source','ggml-vulkan.cpp'),('normal_pipeline_source','pipeline.cpp')]:
    plan['sources'][key]=pin(NORMAL_BUILD/'conflux-flash-f32'/name)
save(NEW/'plan.json',plan)
save(NEW/'root-preparation-01.json',{'schema':1,'status':'prepared_unarmed_pending_verification',
    'prior_cleanup':pin(OLD/'root-finished-01.json'),'prior_audio_analysis':pin(OLD/'root-audio-results-01.json'),
    'previous_packet':str(OLD),'new_packet':str(NEW),'old_runtime':prior['assets']['runtime'],'normal_runtime':runtime_pin,
    'retained_normal16_proof':proof_pin,'changed_factor':'stem runtime: coarse GPU interval instrumentation removed',
    'same_native_player_UI_audio_controls_quality_guard_caps_and_latency_rules':True,
    'no_build_or_product_changes':True,'no_native_model_audio_or_host_policy_started':True,
    'readiness_absent':not (NEW/'readiness.json').exists(),'preparer':pin(Path(__file__).resolve())})
print(json.dumps({'status':'prepared_unarmed','packet':str(NEW),'plan':pin(NEW/'plan.json'),'native_started':False}))
