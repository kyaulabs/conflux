"""Offline UI source/build isolation; no player, model, audio or host work starts."""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch
from test_host_player import driver


class UiProvenanceTests(unittest.TestCase):
    def fixture(self):
        plan=json.loads(driver.PLAN.read_text())
        receipt=json.loads(Path(plan['helpers']['ui_build']['path']).read_text())
        commands=Path(plan['helpers']['compile_commands']['path']).read_bytes()
        def pin(path,*args,**kwargs):
            return {},commands if str(path)==plan['helpers']['compile_commands']['path'] else None
        return plan,receipt,pin

    def test_known_original_and_fixed_UI_pass_build_binding(self):
        plan,receipt,pin=self.fixture()
        with patch.object(driver,'pin_read',side_effect=pin):driver.verify_ui_build(plan,receipt,float('inf'))

    def test_historical_meter_uses_only_the_explicit_original_snapshot(self):
        plan,_,_=self.fixture()
        row={'path':str(driver.W/'qml/StereoMeter.qml'),'bytes':1,
             'sha256':'4682b5f604cf932e248584668e1f2bb3502dc484253b98048784c3a16b9fc9d8'}
        with patch.object(driver,'pin_read',return_value=({},None)) as pin:
            driver.verify_historical_build_file(row,plan,float('inf'))
        self.assertEqual(pin.call_args.args[0],driver.HISTORICAL_UI_ROOT/'qml/StereoMeter.qml')
        row['sha256']='cb37a92886292c76e54c24bea7e1cf4002ca334d006955a8a246a044cafe897d'
        with patch.object(driver,'pin_read') as pin,self.assertRaisesRegex(ValueError,'original build content'):
            driver.verify_historical_build_file(row,plan,float('inf'))
        pin.assert_not_called()

    def test_other_source_paths_are_never_substituted(self):
        plan,_,_=self.fixture();row={'path':str(driver.W/'src/ui/DeckController.cpp'),'bytes':1,'sha256':'a'*64}
        with patch.object(driver,'pin_read',return_value=({},None)) as pin:
            driver.verify_historical_build_file(row,plan,float('inf'))
        self.assertEqual(pin.call_args.args[0],Path(row['path']))

    def test_extra_UI_change_or_wrong_meter_revision_is_rejected(self):
        original_plan,original,read=self.fixture()
        for name in ['qml/DeckSurface.qml','qml/StereoMeter.qml']:
            receipt=copy.deepcopy(original)
            next(row for row in receipt['arms']['candidate']['ui_and_wrapper_files'] if row['path'].endswith('/'+name))['sha256']='a'*64
            with self.subTest(name=name),patch.object(driver,'pin_read',side_effect=read),self.assertRaisesRegex(ValueError,'sole UI content'):
                driver.verify_ui_build(original_plan,receipt,float('inf'))

    def test_changed_compile_flags_are_rejected(self):
        plan,receipt,read=self.fixture()
        receipt['arms']['candidate']['compile_argv'].append('-DQT_QML_DEBUG')
        with patch.object(driver,'pin_read',side_effect=read),self.assertRaisesRegex(ValueError,'Only UI macro'):
            driver.verify_ui_build(plan,receipt,float('inf'))

    def test_snapshot_file_cannot_escape_the_frozen_UI_root(self):
        plan,receipt,read=self.fixture();receipt['arms']['candidate']['ui_and_wrapper_files'][0]['path']='/outside/track.qml'
        with patch.object(driver,'pin_read',side_effect=read),self.assertRaisesRegex(ValueError,'escaped'):
            driver.verify_ui_build(plan,receipt,float('inf'))

    def test_actual_binary_UI_root_and_arm_cannot_be_mislabelled(self):
        original_plan,receipt,read=self.fixture()
        for key,value in [('ui_arm','other'),('runtime_ui_source_root','/outside'),('assets',{'binary':{'path':'/outside'}})]:
            plan=copy.deepcopy(original_plan);plan[key]=value
            with self.subTest(key=key),patch.object(driver,'pin_read',side_effect=read),self.assertRaises(ValueError):
                driver.verify_ui_build(plan,receipt,float('inf'))


if __name__=='__main__':unittest.main()
