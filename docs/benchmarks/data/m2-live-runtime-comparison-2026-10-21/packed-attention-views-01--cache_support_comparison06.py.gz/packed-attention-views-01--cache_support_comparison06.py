#!/usr/bin/env python3
"""Fixed PCM then player diagnostic: independent bounded copies of the same private seed."""
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import time

PARENT = Path(__file__).resolve().parent
SEED_PARENT = Path(__file__).resolve().parents[3] / "benchmarks-local/background-player-01/request-trace-candidate/cache-pair"
SEED_CACHE = SEED_PARENT / "driver-cache-01"
PHASE_CACHES = {
    "06-A1-baseline": PARENT / "driver-cache-comparison-06-A1-baseline",
    "06-B1-packed": PARENT / "driver-cache-comparison-06-B1-packed",
    "06-B2-packed": PARENT / "driver-cache-comparison-06-B2-packed",
    "06-A2-baseline": PARENT / "driver-cache-comparison-06-A2-baseline",
}
LOCK = PARENT / "comparison-06.lock"
MAX_BYTES, MAX_FILES, MAX_DIRS, MAX_DEPTH = 128 * 1024**2, 4096, 256, 8
_DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | os.O_NOFOLLOW
_FILE_FLAGS = os.O_RDONLY | os.O_NONBLOCK | os.O_CLOEXEC | os.O_NOFOLLOW


def _deadline(deadline):
    if type(deadline) not in (int, float) or not math.isfinite(deadline):
        raise ValueError("A finite original cache deadline is required")
    if time.monotonic() >= deadline:
        raise TimeoutError("Original cache inventory deadline exhausted")

def _identity(info):
    return {"device": info.st_dev, "inode": info.st_ino,
            "uid": info.st_uid, "mode": stat.S_IMODE(info.st_mode)}

def _metadata(info):
    return {**_identity(info), "bytes": info.st_size, "links": info.st_nlink,
            "mtime_ns": info.st_mtime_ns, "ctime_ns": info.st_ctime_ns}

def _directory(info, private=False):
    mode = stat.S_IMODE(info.st_mode)
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid()
            or mode & 0o7022 or (private and mode != 0o700)):
        raise ValueError("Cache directory is not an owned safe directory")

class _CacheLock:
    def __init__(self, descriptor, metadata):
        self.descriptor, self.metadata = descriptor, metadata
    def close(self):
        if self.descriptor is not None:
            descriptor, self.descriptor = self.descriptor, None
            try:
                fcntl.flock(descriptor, fcntl.LOCK_UN)
            finally:
                os.close(descriptor)
    def __enter__(self):
        return self
    def __exit__(self, *_):
        self.close()

def _digest(manifest):
    fields = ("cache_path", "parent", "cache_identity", "files", "directories",
              "file_count", "directory_count", "total_bytes")
    raw = json.dumps({key: manifest[key] for key in fields}, sort_keys=True,
                     separators=(",", ":"), ensure_ascii=True).encode()
    return hashlib.sha256(raw).hexdigest()


def capture_cache_parent(path=None):
    path = PARENT if path is None else path
    if path not in (PARENT, SEED_PARENT):
        raise ValueError("Only fixed private logger/seed parents are allowed")
    info = path.stat(follow_symlinks=False)
    _directory(info, private=True)
    return {"path": str(path), **_identity(info)}


def _parent(expected, path):
    if expected != capture_cache_parent(path):
        raise ValueError("Private cache parent identity changed")


def _root(expected, cache):
    if cache not in (SEED_CACHE, *PHASE_CACHES.values()):
        raise ValueError("Only fixed seed/phase cache paths are allowed")
    info = cache.stat(follow_symlinks=False)
    _directory(info, private=True)
    if expected != _identity(info):
        raise ValueError("Private cache root identity changed")
    return info


def acquire_cache_lock(parent, deadline):
    _deadline(deadline); _parent(parent, PARENT)
    flags = os.O_RDWR | os.O_NONBLOCK | os.O_CLOEXEC | os.O_NOFOLLOW
    try:
        descriptor = os.open(LOCK, flags | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        descriptor = os.open(LOCK, flags)
    try:
        info = os.fstat(descriptor)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) != 0o600 or info.st_size or info.st_nlink != 1
                or _metadata(info) != _metadata(LOCK.stat(follow_symlinks=False))):
            raise ValueError("Logger cache lock is unsafe or changed")
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        _deadline(deadline); _parent(parent, PARENT)
        return _CacheLock(descriptor, {"path": str(LOCK), **_metadata(info)})
    except BaseException:
        os.close(descriptor)
        raise


def payload_digest(manifest):
    # Copies necessarily have new inodes/ctime. Compare all paths and bytes,
    # while the full inventories independently retain their safe metadata.
    raw = {"files": [{key: row[key] for key in ("path", "sha256")} | {"bytes": row["metadata"]["bytes"]}
                    for row in manifest["files"]],
           "directories": [row["path"] for row in manifest["directories"]],
           "total_bytes": manifest["total_bytes"]}
    return hashlib.sha256(json.dumps(raw, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _parent_fd(root, path):
    parts = path.split("/")
    if any(not part or part in (".", "..") for part in parts) or len(parts) > MAX_DEPTH:
        raise ValueError("Unsafe cache copy path")
    descriptor = os.dup(root)
    try:
        for part in parts[:-1]:
            next_fd = os.open(part, _DIR_FLAGS, dir_fd=descriptor)
            os.close(descriptor); descriptor = next_fd
        return descriptor, parts[-1]
    except BaseException:
        os.close(descriptor)
        raise


def prepare_phase(arm, seed_manifest, deadline):
    _deadline(deadline)
    if arm not in PHASE_CACHES or seed_manifest.get("cache_path") != str(SEED_CACHE):
        raise ValueError("Only the fixed source seed and PCM/player copies are allowed")
    parent = capture_cache_parent()
    # Seed lock is opened read-only and never created, modified or unlinked.
    seed_lock = os.open(SEED_PARENT / "driver-cache-01.lock", _FILE_FLAGS)
    seed_fd = target_fd = None
    try:
        info = os.fstat(seed_lock)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1
                or info.st_size or stat.S_IMODE(info.st_mode) != 0o600
                or _metadata(info) != _metadata((SEED_PARENT / "driver-cache-01.lock").stat(follow_symlinks=False))):
            raise ValueError("Existing seed ownership lock is unsafe")
        fcntl.flock(seed_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        seed = inventory(SEED_CACHE, seed_manifest["parent"], deadline, seed_manifest["cache_identity"])
        if (seed["manifest_sha256"] != seed_manifest.get("manifest_sha256") or
                not seed["file_count"] or not seed["total_bytes"]):
            raise ValueError("The exact nonempty retained seed changed")
        cache = PHASE_CACHES[arm]
        cache.mkdir(mode=0o700)  # Never adopt an existing cache, even empty.
        identity = _identity(cache.stat(follow_symlinks=False))
        _root(identity, cache)
        seed_fd = os.open(SEED_CACHE, _DIR_FLAGS)
        target_fd = os.open(cache, _DIR_FLAGS)
        if _identity(os.fstat(seed_fd)) != seed["cache_identity"] or _identity(os.fstat(target_fd)) != identity:
            raise ValueError("Cache root changed while opening for copy")
        for row in sorted(seed["directories"], key=lambda row: (row["path"].count("/"), row["path"])):
            _deadline(deadline)
            if row["path"] == ".":
                continue
            parent_fd, name = _parent_fd(target_fd, row["path"])
            try:
                os.mkdir(name, 0o700, dir_fd=parent_fd)
            finally:
                os.close(parent_fd)
        for row in seed["files"]:
            _deadline(deadline)
            source_parent = target_parent = source = target = None
            try:
                source_parent, name = _parent_fd(seed_fd, row["path"])
                target_parent, target_name = _parent_fd(target_fd, row["path"])
                source = os.open(name, _FILE_FLAGS, dir_fd=source_parent)
                if _metadata(os.fstat(source)) != row["metadata"]:
                    raise ValueError("Seed file identity changed before copying")
                target = os.open(target_name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                                 0o600, dir_fd=target_parent)
                digest, count = hashlib.sha256(), 0
                while count < row["metadata"]["bytes"]:
                    _deadline(deadline)
                    data = os.read(source, min(1024**2, row["metadata"]["bytes"] - count))
                    if not data:
                        raise ValueError("Seed file truncated while copying")
                    digest.update(data); count += len(data)
                    view = memoryview(data)
                    while view:
                        _deadline(deadline)
                        written = os.write(target, view)
                        if written <= 0:
                            raise OSError("Private cache copy write failed")
                        view = view[written:]
                if digest.hexdigest() != row["sha256"] or _metadata(os.fstat(source)) != row["metadata"]:
                    raise ValueError("Seed content changed while copying")
            finally:
                if source is not None: os.close(source)
                if target is not None: os.close(target)
                if source_parent is not None: os.close(source_parent)
                if target_parent is not None: os.close(target_parent)
        after = inventory(SEED_CACHE, seed_manifest["parent"], deadline, seed_manifest["cache_identity"])
        copied = inventory(cache, parent, deadline, identity)
        if seed["manifest_sha256"] != after["manifest_sha256"] or payload_digest(copied) != payload_digest(seed):
            raise ValueError("Read-only seed or copied payload parity differs")
        if _metadata(os.fstat(seed_lock)) != _metadata((SEED_PARENT / "driver-cache-01.lock").stat(follow_symlinks=False)):
            raise ValueError("Seed lock identity changed during copying")
        _deadline(deadline)
        return {"arm": arm, "cache_path": str(cache), "cache_identity": identity, "parent": parent,
                "seed_before": seed, "seed_after": after, "pre": copied,
                "payload_sha256": payload_digest(copied), "seed_unchanged": True,
                "cache_hits_proven": False}
    finally:
        if seed_fd is not None: os.close(seed_fd)
        if target_fd is not None: os.close(target_fd)
        os.close(seed_lock)


def cache_environment(inherited, arm):
    if arm not in PHASE_CACHES:
        raise ValueError("Unknown logger arm")
    environment = dict(inherited)
    if any(name == "MESA_GLSL_CACHE_DISABLE" or name.startswith(("MESA_SHADER_CACHE_", "MESA_DISK_CACHE_"))
           for name in environment):
        raise ValueError("Inherited Mesa cache controls are forbidden")
    environment.update(MESA_SHADER_CACHE_DIR=str(PHASE_CACHES[arm]), MESA_SHADER_CACHE_MAX_SIZE="128M")
    return environment


def inventory(cache, parent, deadline, identity):
    """Caller must reap all native cache writers before post-run inventory."""
    _deadline(deadline); _parent(parent, cache.parent); _root(identity, cache)
    began = time.monotonic()
    descriptor = os.open(cache, _DIR_FLAGS)
    try:
        if _identity(os.fstat(descriptor)) != identity:
            raise ValueError("Cache root changed while opening")
        def scan(hash_files):
            files, directories = [], []
            total, entries_seen = 0, 0
            def walk(directory, relative):
                nonlocal total, entries_seen
                _deadline(deadline)
                before = os.fstat(directory); _directory(before)
                directories.append({"path": relative or ".", "metadata": _metadata(before)})
                if len(directories) > MAX_DIRS:
                    raise ValueError("Cache directory count exceeds bound")
                names = []
                with os.scandir(directory) as iterator:
                    for entry in iterator:
                        _deadline(deadline)
                        entries_seen += 1
                        if entries_seen > MAX_FILES + MAX_DIRS - 1:
                            raise ValueError("Cache entry count exceeds bound")
                        names.append(entry.name)
                for name in sorted(names):
                    _deadline(deadline)
                    path = name if not relative else relative + "/" + name
                    if len(path.split("/")) > MAX_DEPTH:
                        raise ValueError("Cache depth exceeds bound")
                    info = os.stat(name, dir_fd=directory, follow_symlinks=False)
                    if stat.S_ISDIR(info.st_mode):
                        child = os.open(name, _DIR_FLAGS, dir_fd=directory)
                        try:
                            if _metadata(os.fstat(child)) != _metadata(info):
                                raise ValueError("Cache directory changed while opening")
                            walk(child, path)
                        finally:
                            os.close(child)
                    else:
                        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                                or info.st_nlink != 1 or stat.S_IMODE(info.st_mode) & 0o7022):
                            raise ValueError("Cache leaf is not an owned safe single-link regular file")
                        total += info.st_size
                        if len(files) >= MAX_FILES or total > MAX_BYTES:
                            raise ValueError("Cache content or file count exceeds bound")
                        row = {"path": path, "metadata": _metadata(info)}
                        if hash_files:
                            file = os.open(name, _FILE_FLAGS, dir_fd=directory)
                            try:
                                if _metadata(os.fstat(file)) != _metadata(info):
                                    raise ValueError("Cache file changed while opening")
                                digest, count = hashlib.sha256(), 0
                                while True:
                                    _deadline(deadline)
                                    data = os.read(file, min(1024**2, info.st_size - count + 1))
                                    if not data:
                                        break
                                    count += len(data)
                                    if count > info.st_size:
                                        raise ValueError("Cache file grew while hashing")
                                    digest.update(data)
                                _deadline(deadline)
                                if (count != info.st_size or _metadata(os.fstat(file)) != _metadata(info)
                                        or _metadata(os.stat(name, dir_fd=directory, follow_symlinks=False)) != _metadata(info)):
                                    raise ValueError("Cache file changed while hashing")
                                row["sha256"] = digest.hexdigest()
                            finally:
                                os.close(file)
                        files.append(row)
                if _metadata(os.fstat(directory)) != _metadata(before):
                    raise ValueError("Cache directory changed during inventory")
            walk(descriptor, "")
            return sorted(files, key=lambda row: row["path"]), sorted(directories, key=lambda row: row["path"]), total
        files, directories, total = scan(True)
        verified_files, verified_directories, verified_total = scan(False)
        if ([{key: value for key, value in row.items() if key != "sha256"} for row in files] != verified_files
                or directories != verified_directories or total != verified_total):
            raise ValueError("Cache tree changed across inventory")
        _root(identity, cache); _parent(parent, cache.parent); _deadline(deadline)
        manifest = {"schema": 1, "complete": True, "cache_path": str(cache),
                    "parent": parent, "cache_identity": identity, "files": files,
                    "directories": directories, "file_count": len(files),
                    "directory_count": len(directories), "total_bytes": total,
                    "capture_started_monotonic": began, "capture_finished_monotonic": time.monotonic()}
        manifest["manifest_sha256"] = _digest(manifest)
        _deadline(deadline)
        return manifest
    finally:
        os.close(descriptor)
