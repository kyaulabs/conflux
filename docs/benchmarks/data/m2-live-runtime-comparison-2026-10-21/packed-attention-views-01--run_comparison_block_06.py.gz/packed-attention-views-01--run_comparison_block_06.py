#!/usr/bin/env python3
"""Dry by default. One fixed ABBA block; root owns every inter-block admission."""
import argparse
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
import time
from types import SimpleNamespace

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
J = ROOT.parent / "drm-clients-01"
PLAN = ROOT / "comparison-plan-06.json"
HUMAN = ROOT / "human-readiness-comparison-06.json"
MODE = "runtime-only-ABBA-player120-06"
SOURCE_HEAD = "3d56de316fe4c2bf1b9dd67e15eff3e54b0d386c"
PLAYER_BINARY = ROOT.parents[2] / "build/live-drain/conflux-manual-playback-soak"
BASE_FILE = ROOT / "run_drm_player_retry02.py"
BASE_SHA = "05e35bfb723136d430e090c1515163c60bcce7a05f570fcbc6842b4c41e048fb"
J_FILE = J / "run_drm_player.py"
J_SHA = "722784d8a1f5448791f43e46a94d3fa4e2dc2128c4faa2878c40dd372c532cfd"
CACHE = ROOT / "cache_support_comparison06.py"
CACHE_SHA = "62c013b8cd10b5c493687262e948a893f4ea0f727a7ecfb17ec11e68a1c38788"
ARMS = {
    "A_baseline": (J / "conflux-stem-runtime", "ca781657d698119b298c402cb716329b10ce113f10c31633be4b8fade8fa0e71", J / "pcm-equivalence-drm-clients-01/result.json"),
    "B_packed": (ROOT / "conflux-stem-runtime", "82e5bcf77e70353a82bec88c892eb420d6d565382cbf7fadfaf00cbad0d61a6c", ROOT / "pcm-equivalence-packed-attention-02/result.json"),
}
QUALITY_SHA = {"A_baseline":"d8aa041f489727a4e0e9c3ba4657213aff6da8a912ff12d6bb611ba3d087a2e1",
               "B_packed":"bd2e4f37f5b176ac9b2607628b3e614ff57471dffcc9c2dcd40d46f65c2c0037"}
BLOCKS = (("06-A1-baseline", "A_baseline"), ("06-B1-packed", "B_packed"),
          ("06-B2-packed", "B_packed"), ("06-A2-baseline", "A_baseline"))
HEALTH = ("guard_unchanged", "owned_processes_absent", "owned_groups_absent", "no_owned_pipewire", "immutable_seed_unchanged", "source_pins_unchanged")
HISTORICAL_ARCHIVE = ROOT / "product-source-before-drain-5373466"
HISTORICAL_MANIFEST = {"path": str(HISTORICAL_ARCHIVE / "manifest.json"), "bytes": 1770,
    "sha256": "6f84117c1b9627a98713f13243d199676abc10a8428f8361f0dea27b729d7fb3"}
# Finite provenance exceptions for the unchanged native quality proofs only.
HISTORICAL_PRODUCT_SOURCES = {
    "src/library/LiveStemObservations.hpp": (4581, "6d61b874f0a7e44801307112186e89c77d3c1c96914ed77796c38fdb77c32e43"),
    "src/library/LiveStemBridge.cpp": (63037, "63ce599a780d0dd91fe5b36a7850e48fa8faf205496019a5547bacc87476a7e3"),
    "tools/experiments/manual_playback_soak.cpp": (61559, "851c2d8378dbfd8464ce0280813b79b65d5683813836e3969f9392672c10a81d"),
}


def require(value, message):
    if not value:
        raise RuntimeError(message)


def import_pinned(path, digest, name):
    require(path.resolve(strict=True) == path, "Module path must be canonical")
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= 256 * 1024, "Unsafe imported module")
        data = b""
        while len(data) < before.st_size:
            part = os.read(fd, min(65536, before.st_size-len(data)))
            require(bool(part), "Module truncated")
            data += part
        sig = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        require(sig(before) == sig(os.fstat(fd)) == sig(path.lstat()) and hashlib.sha256(data).hexdigest() == digest,
                "Imported module identity/content differs")
    finally:
        os.close(fd)
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    # Execute the already verified bytes; do not reopen a raceable module path.
    exec(compile(data, str(path), "exec"), module.__dict__)
    return module


def same_pin(a, b):
    return type(a) is dict and type(b) is dict and all(a.get(k) == b.get(k) for k in ("path", "bytes", "sha256"))


def pin_shape(row):
    return (type(row) is dict and type(row.get("path")) is str and Path(row["path"]).is_absolute()
            and type(row.get("bytes")) is int and row["bytes"] > 0
            and type(row.get("sha256")) is str and re.fullmatch(r"[0-9a-f]{64}", row["sha256"]) is not None)


def checked_json(base, path, expected=None, maximum=2*1024**2):
    value, pinned = base.bounded_json(path, maximum)
    if expected is not None:
        require(pin_shape(expected) and same_pin(pinned, expected), "Fixed JSON proof pin differs")
    return value, pinned


def load_plan(base, path):
    require(path == PLAN, "Only comparison06 plan is permitted")
    plan, pinned = checked_json(base, path)
    require(plan.get("schema") == 1 and plan.get("status") == "frozen_pending_comparison06_readiness"
            and plan.get("mode") == MODE and plan.get("consent") is None and plan.get("physical_launch") is False
            and plan.get("qualified") is False and plan.get("seconds") == 120
            and plan.get("operator_seconds") == 2100 and plan.get("phase_seconds") == 480
            and plan.get("strict_service_target_ms") == 4095 and plan.get("window_policy") == "hidden"
            and plan.get("source_root") == str(base.SOURCE_ROOT)
            and re.fullmatch(r"[0-9a-f]{40}", SOURCE_HEAD) is not None and plan.get("source_head") == SOURCE_HEAD
            and plan.get("block_order") == [x[0] for x in BLOCKS]
            and plan.get("review", {}).get("status") == "passed", "Comparison06 is unarmed or has different fixed scope")
    require(set(plan.get("variants", {})) == set(ARMS), "Exactly the two frozen arms are required")
    require(set(plan.get("assets", {})) == set(base.ASSET_PATHS)
            and all(plan["assets"][k].get("path") == str(PLAYER_BINARY if k == "binary" else v)
                    for k,v in base.ASSET_PATHS.items() if k != "runtime")
            and plan.get("native_schema") == 2 and plan.get("native_mode") == base.NATIVE_MODE
            and plan.get("native_trace_limits") == base.NATIVE_TRACE_LIMITS,
            "Fixed workload or full-client observer differs")
    for arm, (runtime, digest, quality) in ARMS.items():
        row = plan["variants"][arm]
        require(pin_shape(row.get("runtime")) and row["runtime"]["path"] == str(runtime)
                and row["runtime"]["sha256"] == digest and pin_shape(row.get("quality_result"))
                and row["quality_result"]["path"] == str(quality)
                and row["quality_result"]["sha256"] == QUALITY_SHA[arm]
                and row.get("build_result", {}).get("path") == str(runtime.parent/"adapter-build-result.json")
                and type(row.get("source_pins")) is dict, "Arm/runtime/quality/build mapping differs")
    require(plan.get("assets", {}).get("model", {}).get("sha256") == base.FLASH_MODEL_SHA256
            and plan.get("cache_helper", {}).get("path") == str(CACHE)
            and plan["cache_helper"].get("sha256") == CACHE_SHA, "Model/cache helper differs")
    required = {"comparison_adapter": Path(__file__).resolve(), "comparison_base": BASE_FILE,
                "comparison_baseline_validator": J_FILE, "comparison_cache": CACHE,
                "comparison_tests": ROOT/"comparison_06_check.py",
                "comparison_cache_binding_tests": ROOT/"comparison_cache_binding_06_check.py",
                "comparison_shared_context": ROOT/"context_capture.py",
                "comparison_dispatch": ROOT/"dispatch_comparison06.py",
                "comparison_root_admission": ROOT/"root_admission_comparison06.py"}
    require(all(plan.get("source_pins", {}).get(k, {}).get("path") == str(v) for k, v in required.items()),
            "Adapter/base/cache/test closure incomplete")
    require(plan["source_pins"]["comparison_base"].get("sha256") == BASE_SHA
            and plan["source_pins"]["comparison_baseline_validator"].get("sha256") == J_SHA,
            "Imported base identity differs")
    require(plan["source_pins"]["comparison_shared_context"].get("sha256") ==
            "f48908d3966f8c35a8701543e7a1c381bc071690316e014e0bedd82794ece724",
            "Shared executed A context helper differs")
    require(same_pin(plan["source_pins"].get("historical_product_archive_manifest"), HISTORICAL_MANIFEST),
            "Fixed historical product archive manifest missing")
    for relative, (size, digest) in HISTORICAL_PRODUCT_SOURCES.items():
        expected_archive = {"path": str(HISTORICAL_ARCHIVE / relative), "bytes": size, "sha256": digest}
        key = "base:" + relative
        current = plan["source_pins"].get(key)
        require(same_pin(plan["source_pins"].get("historical_product_archive:" + relative), expected_archive)
                and pin_shape(current) and current["path"] == str(base.SOURCE_ROOT / relative)
                and all(same_pin(variant["source_pins"].get(key), current) for variant in plan["variants"].values()),
                "Current common/variant source or fixed historical archive binding differs")
    rows = [*plan["assets"].values(), *plan["source_pins"].values(), plan["review"], plan["cache_helper"],
            plan["gpu_helper"], plan["package_helper"], plan["seed_proof"]]
    for variant in plan["variants"].values():
        rows += [variant["runtime"], variant["quality_result"], variant["build_result"], *variant["source_pins"].values()]
    require(all(pin_shape(x) for x in rows), "Comparison file pin incomplete")
    return plan, pinned


def selected_plan(plan, block):
    arm = BLOCKS[block-1][1]
    variant = plan["variants"][arm]
    selected = {**plan, "assets": {**plan["assets"], "runtime": variant["runtime"]},
                "source_pins": {**plan["source_pins"], **variant["source_pins"]}, "build_result": variant["build_result"]}
    return selected, variant


def historical_product_closure(base, recorded):
    # Verify archived contents, never rewrite or reinterpret the recorded inode/stat identity.
    manifest, manifest_pin = checked_json(base, Path(HISTORICAL_MANIFEST["path"]), HISTORICAL_MANIFEST, 16384)
    require(manifest.get("source_head") == "537346694cb2056738f156c506ecc2254d407f93"
            and type(manifest.get("files")) is list, "Historical source archive manifest differs")
    closure = {"historical:" + key: row for key, row in recorded.items()}
    bindings = []
    for relative, (size, digest) in HISTORICAL_PRODUCT_SOURCES.items():
        key = "source:base:" + relative
        old = {"path": str(ROOT.parents[2] / relative), "bytes": size, "sha256": digest}
        archive = {"path": str(HISTORICAL_ARCHIVE / relative), "bytes": size, "sha256": digest}
        expected = {"original_path": old["path"], "archived_path": archive["path"], "bytes": size, "sha256": digest}
        require(same_pin(recorded.get(key), old)
                and sum(row == expected for row in manifest["files"]) == 1,
                "Historical product source does not match its exact archived binding")
        closure["historical:" + key] = archive
        bindings.append({"historical_key": key, "recorded_pin": recorded[key], "archive_pin": archive})
    closure["historical:product_source_archive_manifest"] = manifest_pin
    return closure, {"manifest_pin": manifest_pin, "bindings": bindings,
        "scope": "Exactly three historical source contents checked in fixed archive; recorded identity is retained evidence, not current archive inode continuity or fresh readiness"}


def historical_quality(base, plan, variant, deadline):
    value, pinned = checked_json(base, Path(variant["quality_result"]["path"]), variant["quality_result"])
    require(value.get("status") == "passed" and value.get("qualified") is False
            and value.get("timing_qualification") is False and value.get("candidate_runtime") == variant["runtime"]
            and value.get("model") == plan["assets"]["model"] and value.get("pins_unchanged") is True
            and value.get("pins_before") == value.get("pins_after") and bool(value.get("pins_before"))
            and value.get("guard_before") == value.get("guard_after") and bool(value.get("guard_before"))
            and value.get("cleanup_complete") is True and value.get("within_wall_budget") is True
            and value.get("errors") == [] and value.get("watchdog_errors") == []
            and value.get("native_shutdown", {}).get("graceful_complete") is True
            and value["native_shutdown"].get("exit_code") == 0
            and value.get("native_trace", {}).get("passed") is True
            and value["native_trace"].get("completed_requests") == 16,
            "Historical output quality proof is incomplete or selected for another arm")
    original = base.load_frozen_module("comparison06_pcm_reference", base.ORIGINAL_PCM, base.ORIGINAL_PCM_SHA256)
    reference, reference_pin = checked_json(base, base.REFERENCE)
    require(reference_pin["sha256"] == base.REFERENCE_SHA256, "Original reference changed")
    expected = original.validate_reference(reference, base.FLASH_MODEL_SHA256)
    cases, requests = value.get("cases"), value.get("requests")
    require(type(cases) is list and type(requests) is list and len(cases) == len(requests) == 16
            and [x.get("id") for x in cases] == list(base.PCM_CASE_IDS)
            and [x.get("case_id") for x in requests] == list(base.PCM_CASE_IDS), "Historical sixteen-case order differs")
    for n, (case, row) in enumerate(zip(cases, requests), 1):
        target = expected[row["case_id"]]
        require(all(case.get(k) == target.get(k) for k in ("id", "track", "start_frame", "valid_frames", "shape", "dtype", "input_sha256", "normalization"))
                and type(row.get("request_id")) is int and row["request_id"] == n
                and row.get("completed") is True and row.get("exact_pcm_match") is True
                and row.get("input_sha256") == target["input_sha256"] and row.get("output_sha256") == target["output_sha256"]
                and row.get("output_shape") == [4,343980,2] and row.get("output_dtype") == "<f4"
                and row.get("output_bytes") == 4*343980*2*4, "Historical input/output/normalization differs")
    # Rehash the actual historical dependency closure, including its original guard,
    # plan and consumed human record. These identities are evidence, not readiness.
    require(all(pin_shape(x) for x in value["pins_before"].values()), "Historical dependency pin incomplete")
    historical, archive = historical_product_closure(base, value["pins_before"])
    closure = {**plan, "source_pins": {**plan["source_pins"], **historical}}
    base.verify_plan_files(closure, deadline)
    return {"passed": True, "scope": "historical exact16 PCM quality only; not fresh interstage/readiness",
            "pcm_result_pin": pinned, "historical_source_head": value["source_head"],
            "historical_product_source_archive": archive}


def readiness(base, path, plan_pin):
    require(path == HUMAN, "One new comparison06 human record is required")
    value, pinned = checked_json(base, path, maximum=16384)
    issued = datetime.fromisoformat(value.get("recorded_at_utc", ""))
    sampled = time.monotonic()
    age = (datetime.now(timezone.utc)-issued).total_seconds() if issued.tzinfo else -1
    require(value.get("schema") == 1 and value.get("decision") == "ready"
            and value.get("ready_for_diagnostic") == MODE and value.get("diagnostic_mode") == MODE
            and value.get("stages") == [x[0] for x in BLOCKS] and value.get("ui_mode") == "background"
            and value.get("window_policy") == "hidden" and type(value.get("maximum_operator_seconds")) is int
            and value["maximum_operator_seconds"] == 2100 and value.get("plan_sha256") == plan_pin["sha256"]
            and 0 <= age < 2100 and all(value.get(k) is True for k in
                ("AC_power", "lid_open", "Codex_minimized", "other_work_paused", "controls_untouched", "no_suspend"))
            and all(type(value.get(k)) is str and 0<len(value[k])<=8192 for k in
                ("question_item_id", "human_question", "human_reply")), "New comparison06 readiness is absent or consumed")
    return {"record": value, "pin": pinned, "age_seconds": age, "sampled_monotonic": sampled,
            "maximum_age_seconds": 2100}


def healthy_result(result, exit_code):
    require(type(exit_code) is int and exit_code in (0,1), "Non-diagnostic exit")
    target = result.get("service_target_met")
    require(type(target) is bool and result.get("functional_passed") is True
            and result.get("passed") is target and exit_code == (0 if target else 1)
            and result.get("qualified") is False and result.get("timing_qualification") is False
            and result.get("stop_reason") is None and not any(v for k,v in result.items() if k == "error" or k.endswith("_error"))
            and type(result.get("native_exit")) is int and result["native_exit"] == 0 and result.get("pins_unchanged") is True
            and bool(result.get("pins_before")) and result["pins_before"] == result.get("pins_after")
            and bool(result.get("guard_before")) and result["guard_before"] == result.get("guard_after")
            and result.get("cleanup_proven") is True and result.get("owned_cache_removed") is True
            and result.get("cache_preserved") is False and result.get("cache_inventory_complete") is True
            and result.get("hidden_policy_validated") is True and result.get("within_wall_budget") is True
            and result.get("native_trace", {}).get("passed") is True and result.get("request_trace", {}).get("passed") is True
            and result.get("package_coverage", {}).get("complete") is True
            and result.get("shader_cache", {}).get("lock_released") is True
            and result["shader_cache"].get("seed_unchanged") is True,
            "Not a complete healthy result or narrow latency-only failure")
    c = result.get("cleanup", {})
    require(all(c.get(k) is True for k in ("ownership_complete", "leader_reaped", "cooperative_native_shutdown", "engine_processes_observed"))
            and c.get("remaining_known_processes") == [] and c.get("remaining_live_jobs") == []
            and type(c.get("remaining_pipewire_count")) is int and c["remaining_pipewire_count"] == 0 and bool(c.get("owned_group_absent"))
            and all(x is True for x in c["owned_group_absent"].values())
            and c.get("ownership_failure_count") == 0 and c.get("ownership_failure_overflow") is False,
            "Known cleanup is incomplete")
    require(all(result.get("power_"+x, {}).get("ac_online") is True and result["power_"+x].get("lid_open") is True for x in ("before", "after"))
            and set(result.get("capture", {})) == {"stdout", "stderr"}
            and all(x.get("complete") is True for x in result["capture"].values()), "Power or native capture incomplete")
    hops = result.get("observations", {}).get("service_hops", {})
    p99 = hops.get("nearest_rank_p99_ms")
    require(hops.get("complete") is True and hops.get("strict_target_ms") == 4095
            and type(hops.get("count")) is int and 0<hops["count"]<=64
            and type(p99) in (int,float) and math.isfinite(p99) and p99 >= 0
            and hops.get("maximum_ms") == p99 and type(hops.get("at_or_above_target")) is int
            and 0<=hops["at_or_above_target"]<=hops["count"]
            and target == (p99 < 4095) == (hops["at_or_above_target"] == 0), "Target was altered or relabeled")
    n = result.get("native", {})
    recording = n.get("recording", {})
    require(n.get("passed") is True and n.get("error") == "" and n.get("shutdown_completed") is True
            and all(type(n.get(k)) is int and n[k] == 0 for k in
                ("steady_starved_frames", "execution_deadline_misses", "invalid_buffers", "rejected_commands", "source_read_failures"))
            and recording.get("status") == "Complete" and recording.get("error") == ""
            and recording.get("overflowFrames") == 0 and recording.get("active") is False
            and type(recording.get("writtenFrames")) is int and recording["writtenFrames"] > 0
            and recording.get("acceptedFrames") == recording["writtenFrames"], "Audio/native functional result incomplete")
    return "complete_target_pass" if target else "complete_latency_only_failure"


def current_admission(base, plan, plan_pin, human, block, phase_started, now, boot):
    path = ROOT/f"comparison-admission-06-block-{block}.json"
    audit, audit_pin = checked_json(base, path, maximum=128*1024)
    created = datetime.fromisoformat(audit.get("created_at_utc", ""))
    anchor = audit.get("original_anchor", {})
    sampled, age, deadline = (anchor.get(k) for k in ("sampled_monotonic", "age_seconds", "deadline_monotonic"))
    require(all(type(x) in (int,float) and math.isfinite(x) for x in (sampled,age,deadline))
            and 0<=age<2100 and 0<=sampled<=now and abs(deadline-(sampled+2100-age))<=1e-6
            and audit.get("boot_id") == boot and created.tzinfo is not None
            and 0 <= (datetime.now(timezone.utc)-created).total_seconds() <= 60
            and audit.get("schema") == 1 and audit.get("status") == "passed"
            and type(audit.get("block")) is int and audit["block"] == block
            and audit.get("plan_sha256") == plan_pin["sha256"] and audit.get("human_sha256") == human["pin"]["sha256"]
            and audit.get("source_head") == plan["source_head"] and all(audit.get(k) is True for k in HEALTH),
            "Fresh independent root admission/original anchor absent")
    require(type(audit.get("guard_identity")) is dict and bool(audit["guard_identity"])
            and audit.get("audit_kind") == "independent_root_current_host_seed_audit",
            "Independent root guard/host audit identity missing")
    first = audit if block == 1 else checked_json(base, ROOT/"comparison-admission-06-block-1.json")[0]
    require(first.get("original_anchor") == anchor and first.get("human_sha256") == audit["human_sha256"]
            and first.get("plan_sha256") == audit["plan_sha256"] and first.get("boot_id") == boot,
            "Original same-boot comparison anchor was renewed")
    # Clamp both to the saved original anchor and the newly observed UTC age.
    original_deadline = min(deadline, human["sampled_monotonic"]+2100-human["age_seconds"])
    prior = audit.get("prior_blocks")
    require(type(prior) is list and [x.get("block") for x in prior] == list(range(1,block)), "ABBA order/prior roots missing")
    for number, row in enumerate(prior,1):
        require(pin_shape(row.get("summary_pin")) and pin_shape(row.get("result_pin")), "Prior result/audit pin incomplete")
        output = ROOT/("comparison-"+BLOCKS[number-1][0])
        summary, _ = checked_json(base, output/"comparison-summary.json", row.get("summary_pin"), 128*1024)
        result, result_pin = checked_json(base, output/"result.json", row.get("result_pin"))
        require(summary.get("block") == number and summary.get("plan_sha256") == plan_pin["sha256"]
                and summary.get("strict_source_closure_after") is True
                and summary.get("human_sha256") == human["pin"]["sha256"] and same_pin(summary.get("result_pin"),result_pin)
                and summary.get("original_anchor") == anchor
                and result.get("comparison", {}).get("block") == number
                and result["comparison"].get("arm") == BLOCKS[number-1][1]
                and result["comparison"].get("original_anchor") == anchor
                and result.get("plan_pin",{}).get("sha256") == plan_pin["sha256"]
                and result.get("diagnostic_mode") == MODE
                and result.get("human_before_launch",{}).get("pin",{}).get("sha256") == human["pin"]["sha256"]
                and result.get("native",{}).get("setup",{}).get("runtime_sha256") == ARMS[BLOCKS[number-1][1]][1]
                and result.get("pins_before",{}).get("runtime",{}).get("sha256") == ARMS[BLOCKS[number-1][1]][1]
                and result["pins_before"]["runtime"].get("path") == str(ARMS[BLOCKS[number-1][1]][0])
                and result["native"]["setup"].get("model_sha256") == base.FLASH_MODEL_SHA256
                and result.get("repository_head") == plan["source_head"] == result.get("head_after"),
                "Prior block lost exact plan/human/order/clock binding")
        prior_deadline = result.get("operator_budget",{}).get("operator_deadline_monotonic")
        require(type(prior_deadline) in (int,float) and math.isfinite(prior_deadline) and 0<prior_deadline<=deadline,
                "Prior block lost finite original deadline")
        original_deadline = min(original_deadline,prior_deadline)
        healthy_result(result,summary.get("exit_code"))
    require(original_deadline-now >= 480, "Insufficient original time for an unchanged480s block")
    return audit, audit_pin, {"phase":"comparison_block", "phase_deadline_monotonic":min(phase_started+480,original_deadline),
        "operator_deadline_monotonic":original_deadline, "age_seconds":human["age_seconds"],
        "approval_sample_monotonic":sampled, "remaining_operator_seconds":original_deadline-now,
        "permitted_seconds":min(480,original_deadline-now), "external_INT_after_seconds":min(480,original_deadline-now)-30,
        "external_kill_grace_seconds":30, "original_anchor":anchor, "scope":"One original2100s comparison window; no renewal"}


@contextlib.contextmanager
def inherited_logs(stdout_path, stderr_path):
    descriptors = []
    saved = []
    try:
        for path in (stdout_path,stderr_path):
            descriptors.append(os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC|os.O_NOFOLLOW,0o600))
        sys.stdout.flush();sys.stderr.flush()
        saved = [os.dup(1),os.dup(2)]
        os.dup2(descriptors[0],1);os.dup2(descriptors[1],2)
        yield
    finally:
        sys.stdout.flush();sys.stderr.flush()
        if saved:
            os.dup2(saved[0],1);os.dup2(saved[1],2)
        for fd in [*saved,*descriptors]:os.close(fd)
        if len(descriptors) == 2:
            require(stdout_path.stat().st_size <= 8*1024**2 and stderr_path.stat().st_size <= 8*1024**2,
                    "Comparison inherited log exceeds retained8MiB bound")


def bind(base, block, quality, audit_path):
    # Explicit, fixed process-local bindings. Never invoke imported main/old PCM admission.
    base.PLAN,base.HUMAN,base.MODE = PLAN,HUMAN,MODE
    base.OUTPUT = ROOT/("comparison-"+BLOCKS[block-1][0])
    base.PCM_OUTPUT = Path(quality["pcm_result_pin"]["path"]).parent
    base.INTERSTAGE_AUDIT = audit_path
    base.CACHE_HELPER,base.CACHE_HELPER_SHA256 = CACHE,CACHE_SHA
    base.readiness = lambda path,pin: readiness(base,path,pin)


def bind_player_cache_environment(helper, block, preparation):
    # run_live names its one logical phase "player"; this process owns one literal block.
    block_id = BLOCKS[block-1][0]
    expected = ROOT / ("driver-cache-comparison-" + block_id)
    def check_preparation():
        require(helper.PHASE_CACHES.get(block_id) == expected
                and preparation.get("arm") == block_id
                and preparation.get("cache_path") == str(expected),
                "Selected block cache preparation/path differs")
    check_preparation()
    original = helper.cache_environment
    def environment(inherited, logical_arm):
        require(logical_arm == "player", "Only the logical player cache phase is permitted")
        check_preparation()
        value = original(inherited, block_id)
        require(value.get("MESA_SHADER_CACHE_DIR") == str(expected), "Selected cache environment path differs")
        return value
    helper.cache_environment = environment


def run_block(base, plan, plan_pin, block, phase_started):
    output=ROOT/("comparison-"+BLOCKS[block-1][0])
    require(not any(p.exists() or p.is_symlink() for p in
        (output,ROOT/f"comparison-{BLOCKS[block-1][0]}.stdout.log",ROOT/f"comparison-{BLOCKS[block-1][0]}.stderr.log")),
        "Fresh fixed comparison output/logs required")
    selected,variant = selected_plan(plan,block)
    human = readiness(base,HUMAN,plan_pin)
    audit,audit_pin,budget = current_admission(base,plan,plan_pin,human,block,phase_started,time.monotonic(),base.boot_identity())
    cool_deadline = min(phase_started+180,budget["phase_deadline_monotonic"])
    validator = base if BLOCKS[block-1][1] == "B_packed" else import_pinned(J_FILE,J_SHA,"comparison06_baseline")
    validator.validate_build_result(selected)
    base.verify_plan_files(selected,cool_deadline)
    quality = historical_quality(base,selected,variant,cool_deadline)
    quality["root_audit_pin"] = audit_pin
    bind(base,block,quality,ROOT/f"comparison-admission-06-block-{block}.json")
    helper,helper_pin = base.load_cache_support()
    parent = helper.capture_cache_parent()
    lock = helper.acquire_cache_lock(parent,cool_deadline)
    try:
        seed,seed_pin = checked_json(base,Path(plan["seed_proof"]["path"]),plan["seed_proof"])
        require(seed.get("cleanup_proven") is True and seed.get("pins_unchanged") is True
                and seed.get("shader_cache",{}).get("inventory_complete") is True,"Immutable seed proof incomplete")
        manifest = seed["shader_cache"]["post"]
        require(manifest.get("manifest_sha256") == plan["seed_manifest_sha256"],"Immutable seed manifest differs")
        preparation = helper.prepare_phase(BLOCKS[block-1][0],manifest,cool_deadline)
        bind_player_cache_environment(helper,block,preparation)
        assets = {k:Path(v["path"]) for k,v in selected["assets"].items()}
        guard = base.guard_identity(assets["guard_script"],assets["guard_unit"])
        require(guard == audit.get("guard_identity"),"Current guard differs from independent root admission")
        rows = base.cool_start(cool_deadline)
        require(base.guard_identity(assets["guard_script"],assets["guard_unit"]) == guard,"Guard changed during cooldown")
        require(readiness(base,HUMAN,plan_pin)["pin"] == human["pin"]
                and time.monotonic()+150 < budget["phase_deadline_monotonic"],"Readiness changed or block time exhausted")
        require(not base.OUTPUT.exists(),"Fixed comparison output already exists")
        original_finalize = base.finalize_logger_result
        def finalize(result,args,deadline):
            original_finalize(result,args,deadline)
            result["comparison"] = {"block":block,"block_id":BLOCKS[block-1][0],"arm":BLOCKS[block-1][1],
                "original_anchor":audit["original_anchor"],"historical_quality_only":quality["pcm_result_pin"],
                "historical_product_source_archive":quality["historical_product_source_archive"],
                "fresh_root_admission":audit_pin,"adapter_source":plan["source_pins"]["comparison_adapter"],
                "scope":"Runtime-only diagnostic; target failures retained, no pooled p99 qualification"}
        base.finalize_logger_result = finalize
        args = SimpleNamespace(**assets,seconds=120,live_stems=True,live_stems_hour=False,background=True,
            output=base.OUTPUT,readiness_decision=HUMAN,plan=selected,plan_pin=plan_pin,human_pin=human["pin"],
            operator_budget=budget,phase_deadline=budget["phase_deadline_monotonic"],operator_deadline=budget["operator_deadline_monotonic"],
            cache_helper=helper,cache_helper_pin=helper_pin,cache_preparation=preparation,cache_lock=lock,
            preflight={"natural_cool_observations":rows,"guard":guard,"seed_proof_pin":seed_pin,
                "pcm_gate":quality,"current_root_admission":audit_pin,"quality_is_historical_not_fresh_PCM":True})
        require(base.shutil.disk_usage(ROOT).free >= base.live_required_free_bytes(120,False)+16*1024**2,
                "Existing storage reserve plus inherited log allowance required")
        with inherited_logs(ROOT/f"comparison-{BLOCKS[block-1][0]}.stdout.log",ROOT/f"comparison-{BLOCKS[block-1][0]}.stderr.log"):
            code = base.run_live(args)
        base.verify_plan_files(selected,budget["phase_deadline_monotonic"])
        require(time.monotonic() <= budget["phase_deadline_monotonic"],"Original phase ended before final file verification")
        result,result_pin = checked_json(base,base.OUTPUT/"result.json")
        verdict = healthy_result(result,code)
        summary = {"schema":1,"block":block,"arm":BLOCKS[block-1][1],"exit_code":code,"verdict":verdict,
            "plan_sha256":plan_pin["sha256"],"human_sha256":human["pin"]["sha256"],
            "original_anchor":audit["original_anchor"],"result_pin":result_pin,
            "target_passed":result["service_target_met"],"qualified":False,
            "strict_source_closure_after":True,
            "next_block_requires_independent_root_audit":block<4}
        require(not (base.OUTPUT/"comparison-summary.json").exists(),"Summary already exists")
        base.save(base.OUTPUT/"comparison-summary.json",summary)
        print(json.dumps(summary))
        return code
    finally:
        lock.close()


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run",action="store_true")
    p.add_argument("--block",type=int,choices=range(1,5))
    p.add_argument("--allow-host-audio",action="store_true")
    p.add_argument("--drm-busy-diagnostic",action="store_true")
    a=p.parse_args(argv)
    if not a.run:
        print(json.dumps({"dry":True,"mode":MODE,"physical_launch":False,"scope":"No imports, host checks or child"}));return 0
    require(a.block is not None and a.allow_host_audio and a.drm_busy_diagnostic,"Explicit fixed block/audio/diagnostic flags required")
    began=time.monotonic()
    base=import_pinned(BASE_FILE,BASE_SHA,"comparison06_player")
    plan,plan_pin=load_plan(base,PLAN)
    return run_block(base,plan,plan_pin,a.block,began)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({"passed":False,"qualified":False,"mode":MODE,"error":str(error),"scope":"No continuation without exact healthy result and independent root audit"}))
        raise SystemExit(1)
