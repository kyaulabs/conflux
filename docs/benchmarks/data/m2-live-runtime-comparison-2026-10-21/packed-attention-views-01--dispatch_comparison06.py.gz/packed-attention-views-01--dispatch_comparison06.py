#!/usr/bin/env python3
"""Dry by default; dispatch one fixed comparison06 audit or player command."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PLAN = ROOT / "comparison-plan-06.json"
HUMAN = ROOT / "human-readiness-comparison-06.json"
MODE = "runtime-only-ABBA-player120-06"
BLOCKS = ("06-A1-baseline", "06-B1-packed", "06-B2-packed", "06-A2-baseline")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path, maximum):
    require(path.resolve(strict=True) == path, "Noncanonical dispatch input")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid() and before.st_nlink == 1
                and 0 < before.st_size <= maximum, "Unsafe dispatch input")
        data = stream.read(maximum + 1)
        signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        require(len(data) == before.st_size and signature(before) == signature(os.fstat(stream.fileno()))
                == signature(path.lstat()), "Dispatch input changed")
    return data


def human_age(human, plan_sha, utc_now):
    require(human.get("schema") == 1 and human.get("plan_sha256") == plan_sha and human.get("decision") == "ready"
            and human.get("diagnostic_mode") == human.get("ready_for_diagnostic") == MODE
            and type(human.get("maximum_operator_seconds")) is int and human["maximum_operator_seconds"] == 2100
            and human.get("stages") == list(BLOCKS)
            and human.get("ui_mode") == "background" and human.get("window_policy") == "hidden"
            and all(human.get(k) is True for k in ("AC_power", "lid_open", "Codex_minimized",
                "other_work_paused", "controls_untouched", "no_suspend"))
            and all(type(human.get(k)) is str and 0 < len(human[k]) <= 8192 for k in
                ("question_item_id", "human_question", "human_reply")), "New comparison06 conditions are absent")
    issued = datetime.fromisoformat(human.get("recorded_at_utc", ""))
    require(issued.tzinfo is not None, "Readiness UTC is missing")
    age = (utc_now - issued).total_seconds()
    require(0 <= age < 2100, "Original readiness is expired or in the future")
    return age


def original_deadline(human, human_sha, plan_sha, now, utc_now, boot, first, prior_deadlines):
    age = human_age(human, plan_sha, utc_now)
    deadline = now + 2100 - age
    if first is None:
        require(age <= 120, "Initial comparison06 readiness is too old")
    else:
        require(first.get("status") == "passed" and first.get("block") == 1
                and first.get("plan_sha256") == plan_sha and first.get("human_sha256") == human_sha
                and first.get("boot_id") == boot, "Original admission identity differs")
        anchor = first.get("original_anchor", {})
        sampled, initial_age, original = (anchor.get(k) for k in
            ("sampled_monotonic", "age_seconds", "deadline_monotonic"))
        require(all(type(x) in (int, float) and math.isfinite(x) for x in (sampled, initial_age, original))
                and 0 <= sampled <= now and 0 <= initial_age <= 120
                and abs(original - (sampled + 2100 - initial_age)) <= 1e-6,
                "Original same-boot clock anchor changed")
        deadline = min(deadline, original)
    for prior in prior_deadlines:
        require(type(prior) in (int, float) and math.isfinite(prior) and 0 < prior <= deadline + 1,
                "Prior operator deadline differs")
        deadline = min(deadline, prior)
    return deadline


def allocation(mode, deadline, now):
    require(mode in ("audit", "player") and all(type(x) in (int, float) and math.isfinite(x)
            for x in (deadline, now)), "Invalid dispatch clock/mode")
    # Compute only after tool-review delay; leave one second before exec starts its timer.
    remaining = deadline - now - 1
    if mode == "audit":
        allowed = min(90, math.floor(remaining))
        require(allowed > 5, "Insufficient original audit time")
        return allowed, allowed - 5, 5
    require(remaining >= 480, "Insufficient original time for a complete480s player block")
    return 480, 450, 30


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", choices=("audit", "player"))
    parser.add_argument("--block", type=int, choices=range(1, 6))
    parser.add_argument("--plan-sha256")
    args = parser.parse_args(argv)
    if args.execute is None:
        print("Dry: no plan, human, host reads or commands.")
        return 0
    mode, block = args.execute, args.block
    require(block is not None and (mode == "audit" or block <= 4)
            and type(args.plan_sha256) is str and re.fullmatch(r"[0-9a-f]{64}", args.plan_sha256),
            "Explicit fixed block and reviewed plan SHA are required")
    plan_raw = read(PLAN, 2097152)
    require(hashlib.sha256(plan_raw).hexdigest() == args.plan_sha256, "Exact reviewed plan changed")
    plan = json.loads(plan_raw)
    require(plan.get("mode") == MODE and plan.get("operator_seconds") == 2100
            and plan.get("phase_seconds") == 480 and plan.get("block_order") == list(BLOCKS),
            "Fixed comparison06 scope differs")
    for key, name in (("comparison_dispatch", "dispatch_comparison06.py"),
                      ("comparison_root_admission", "root_admission_comparison06.py"),
                      ("comparison_adapter", "run_comparison_block_06.py")):
        expected = plan.get("source_pins", {}).get(key, {})
        path = ROOT / name
        require(expected.get("path") == str(path) and type(expected.get("bytes")) is int
                and 0 < expected["bytes"] <= 262144, "Dispatch command source binding differs")
        content = read(path, 262144)
        require(len(content) == expected["bytes"] and hashlib.sha256(content).hexdigest() == expected.get("sha256"),
                "Reviewed dispatch command source changed")
    raw = read(HUMAN, 16384)
    human, human_sha = json.loads(raw), hashlib.sha256(raw).hexdigest()
    # The full human contract is checked before even reading the boot identity.
    age = human_age(human, args.plan_sha256, datetime.now(timezone.utc))
    if mode == "audit" and block == 1:
        require(age <= 120, "Initial comparison06 readiness is too old")
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    first_path = ROOT / "comparison-admission-06-block-1.json"
    if mode == "audit" and block == 1:
        require(not first_path.exists() and not first_path.is_symlink(), "Initial admission already exists")
        first = None
    else:
        first = json.loads(read(first_path, 131072))
    prior = []
    for previous in range(1, block):
        result = json.loads(read(ROOT / ("comparison-" + BLOCKS[previous - 1]) / "result.json", 2097152))
        prior.append(result["operator_budget"]["operator_deadline_monotonic"])
    now = time.monotonic()
    deadline = original_deadline(human, human_sha, args.plan_sha256, now, datetime.now(timezone.utc), boot, first, prior)
    allowed, signal_after, grace = allocation(mode, deadline, time.monotonic())
    if mode == "audit":
        command = ["/usr/bin/python3.14", "-I", "-B", str(ROOT / "root_admission_comparison06.py"),
                   "--audit", "--block", str(block), "--plan-sha256", args.plan_sha256]
    else:
        command = ["/usr/bin/python3.14", "-I", "-B", str(ROOT / "run_comparison_block_06.py"),
                   "--run", "--block", str(block), "--allow-host-audio", "--drm-busy-diagnostic"]
    command = ["/usr/bin/timeout", "--signal=" + ("TERM" if mode == "audit" else "INT"),
               "--kill-after=" + str(grace) + "s", str(signal_after) + "s", *command]
    record = {"mode": mode, "block": block, "plan_sha256": args.plan_sha256, "human_sha256": human_sha,
              "boot_id": boot, "sampled_monotonic": time.monotonic(), "original_deadline_monotonic": deadline,
              "allowed_total_seconds": allowed, "argv": command, "new_window": False}
    data = (json.dumps(record, indent=2, allow_nan=False) + "\n").encode()
    require(len(data) <= 16384, "Dispatch record exceeds bound")
    path = ROOT / ("root-dispatch-comparison-06-" + mode + "-" + str(block) + ".json")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(data)
    print(json.dumps({"dispatch_record": str(path), "mode": mode, "block": block,
                      "allowed_total_seconds": allowed}), flush=True)
    os.execv(command[0], command)


if __name__ == "__main__":
    raise SystemExit(main())
