#!/usr/bin/env python3
"""Synthetic actual-run_live cache seam checks; no host queries or native child."""
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest import mock

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("comparison06_cache_revision", ROOT / "run_comparison_block_06.py")
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)


def pin(path):
    raw = path.read_bytes(); s = path.stat()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
            "identity": [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]}


class CacheBindingChecks(unittest.TestCase):
    def helper(self):
        return c.import_pinned(c.CACHE, c.CACHE_SHA, "comparison06_real_cache_fixture")

    def preparation(self, block):
        name = c.BLOCKS[block-1][0]
        return {"arm": name, "cache_path": str(ROOT / ("driver-cache-comparison-" + name))}

    def rehearsal(self, helper, suffix):
        """Call the retained run_live, stopping at its real Popen boundary."""
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            def file(name):
                path = root / name; path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(("synthetic:" + name).encode()); return path
            assets = {name: file(name) for name in ("binary", "track_a", "track_b", "python", "exporter", "runtime", "model", "guard_script", "guard_unit")}
            assets.update(worker=file("tools/stems/worker.py"), service=file("service_drm.py"))
            for name in ("qml/Main.qml", "qml/DeckSurface.qml", "qml/MixerSurface.qml", "qml/DeckButton.qml", "qml/SurfaceKnob.qml", "qml/StereoMeter.qml",
                         "brand/integration/qtquick/ConfluxTheme.qml", "brand/integration/qtquick/qmldir",
                         "brand/assets/logos/conflux-horizontal-dark.svg", "brand/assets/logos/conflux-horizontal-light.svg",
                         "brand/assets/fonts/Barlow-Regular.ttf", "brand/assets/fonts/BarlowCondensed-SemiBold.ttf", "brand/assets/fonts/JetBrainsMono-Regular.ttf"):
                file(name)
            plan_path, seed, quality, audit = (file(name) for name in ("plan.json", "seed.json", "quality/result.json", "audit.json"))
            observer = file("observer.py")
            mandatory = {key: file(key + ".py") for key in ("context_helper", "trace_validator", "trace_helper", "trace_parser", "original_service")}
            base = c.import_pinned(c.BASE_FILE, c.BASE_SHA, "comparison06_real_run_live_fixture")
            output = root / ("output-" + suffix)
            plan = {"assets": {"runtime": pin(assets["runtime"])}, "source_head": "synthetic-head", "seed_proof": pin(seed)}
            args = SimpleNamespace(**assets, seconds=120, live_stems=True, live_stems_hour=False, background=True,
                output=output, plan=plan, plan_pin=pin(plan_path), phase_deadline=time.monotonic()+250,
                operator_deadline=time.monotonic()+250, cache_helper=helper,
                preflight={"pcm_gate": {"pcm_result_pin": pin(quality), "root_audit_pin": pin(audit)}})
            ready = {"pin": {"fixture": "same human"}}
            gpu = SimpleNamespace(discover_gpu_fields=lambda: {"fixture": "gpu"}, read_gpu_snapshot=lambda _: {"fixture": "gpu sample"})
            package = SimpleNamespace(discover_package_constraints=lambda: {"fixture": "package"}, read_package_snapshot=lambda _: {"fixture": "package sample"})
            def command(argv, **kwargs):
                if argv[:3] == ["systemctl", "--user", "show"]:
                    return "ActiveState=active\nMainPID=123\nInvocationID=fixture\nExecMainStartTimestampMonotonic=1"
                if argv[:2] == ["git", "-C"]: return "synthetic-head"
                raise AssertionError("Unexpected host command: " + repr(argv))
            with contextlib.ExitStack() as stack:
                for key, value in {"SOURCE_ROOT": root, "RUNNER_ROOT": root, "OUTPUT": output, "PLAN": plan_path,
                    "PCM_OUTPUT": quality.parent, "INTERSTAGE_AUDIT": audit, "GPU_HELPER": observer, "PACKAGE_HELPER": observer,
                    "CACHE_HELPER": c.CACHE, "MANDATORY_SOURCES": mandatory, "FLASH_MODEL_SHA256": pin(assets["model"])["sha256"]}.items():
                    stack.enter_context(mock.patch.object(base, key, value))
                for key, value in {"phase_readiness": lambda _: ready, "verify_plan_files": lambda *_: None,
                    "read_command": command, "process_identity": lambda pid: {"command": [str(assets["guard_script"])]},
                    "load_gpu_observer": lambda _: gpu, "load_package_observer": lambda _: package,
                    "validate_gpu_snapshot": lambda *_: True, "validate_package_snapshot": lambda *_: True,
                    "power_state": lambda: {"ac_online": True, "lid_open": True}, "sensor_paths": lambda: {},
                    "frequency_observation": lambda *_: {"package_constraints": {"fixture": "package sample"}},
                    "finalize_passive_trace": lambda *_: None, "finalize_logger_result": lambda *_: None}.items():
                    stack.enter_context(mock.patch.object(base, key, value))
                stack.enter_context(mock.patch.object(base.shutil, "disk_usage", return_value=SimpleNamespace(free=10**15)))
                stack.enter_context(mock.patch.dict(os.environ, {"PRESERVED_FIXTURE": "yes"}, clear=True))
                stack.enter_context(mock.patch.object(base.os, "killpg", side_effect=AssertionError("No process/group probe")))
                child = stack.enter_context(mock.patch.object(base.subprocess, "Popen", side_effect=RuntimeError("synthetic Popen boundary reached; no child")))
                stack.enter_context(mock.patch("sys.stdout", io.StringIO()))
                self.assertEqual(base.run_live(args), 1)
                result = json.loads((output / "result.json").read_text())
                self.assertFalse(result["passed"])
                self.assertFalse(result["qualified"])
                self.assertTrue(result["cleanup_proven"])
                self.assertTrue(result["owned_cache_removed"])
                self.assertFalse((output / "cache").exists())
                self.assertNotIn("native", result)
                self.assertEqual(result["cleanup"]["proven_command_history"], [])
                return result, child.call_args, child.call_count

    def test_real_unbound_run_live_reproduces_original_failure_before_Popen(self):
        result, call, count = self.rehearsal(self.helper(), "unbound")
        self.assertEqual(result["error"], "Unknown logger arm")
        self.assertEqual(count, 0)
        self.assertIsNone(call)

    def test_all_four_bound_arms_reach_actual_Popen_with_fixed_environment_and_command(self):
        for block in range(1, 5):
            with self.subTest(block=block):
                helper = self.helper(); prepared = self.preparation(block)
                c.bind_player_cache_environment(helper, block, prepared)
                result, call, count = self.rehearsal(helper, str(block))
                self.assertEqual(count, 1)
                self.assertEqual(result["error"], "synthetic Popen boundary reached; no child")
                argv = call.args[0]; environment = call.kwargs["env"]
                self.assertEqual(argv[1], "--live-stems-hidden")
                self.assertEqual(argv[5], "120")
                self.assertEqual(len(argv), 13)
                self.assertEqual(environment["MESA_SHADER_CACHE_DIR"], prepared["cache_path"])
                self.assertEqual(environment["MESA_SHADER_CACHE_MAX_SIZE"], "128M")
                self.assertEqual(environment["PRESERVED_FIXTURE"], "yes")
                self.assertEqual(environment["QT_QUICK_BACKEND"], "software")
                self.assertEqual(environment["CONFLUX_ALLOW_HOST_SOAK"], "1")
                self.assertEqual(environment["XDG_CACHE_HOME"], argv[4] + "/cache")
                self.assertTrue(environment["CONFLUX_DRM_USAGE_TRACE"].endswith("/drm-traces/native-drm.jsonl"))
                self.assertEqual(call.kwargs["stdin"], subprocess.DEVNULL)
                self.assertEqual(call.kwargs["stdout"], subprocess.PIPE)
                self.assertEqual(call.kwargs["stderr"], subprocess.PIPE)
                self.assertIs(call.kwargs["start_new_session"], True)

    def test_incorrect_logical_arm_preparation_or_changed_mapping_fail_closed(self):
        for field, value in (("arm", c.BLOCKS[1][0]), ("cache_path", str(ROOT / "wrong-cache"))):
            with self.subTest(field=field):
                helper = self.helper(); prepared = self.preparation(1); prepared[field] = value
                with self.assertRaisesRegex(RuntimeError, "cache preparation"):
                    c.bind_player_cache_environment(helper, 1, prepared)
        helper = self.helper(); prepared = self.preparation(1)
        c.bind_player_cache_environment(helper, 1, prepared)
        for arm in ("pcm", c.BLOCKS[0][0], "03-B1-packed", None):
            with self.assertRaisesRegex(RuntimeError, "logical player"):
                helper.cache_environment({}, arm)
        prepared["cache_path"] = str(ROOT / "changed-cache")
        with self.assertRaisesRegex(RuntimeError, "cache preparation"):
            helper.cache_environment({}, "player")
        helper = self.helper(); prepared = self.preparation(1)
        c.bind_player_cache_environment(helper, 1, prepared)
        helper.PHASE_CACHES[prepared["arm"]] = ROOT / "changed-cache"
        with self.assertRaisesRegex(RuntimeError, "cache preparation"):
            helper.cache_environment({}, "player")

    def test_actual_helper_still_rejects_inherited_cache_overrides(self):
        helper = self.helper(); c.bind_player_cache_environment(helper, 1, self.preparation(1))
        for key in ("MESA_GLSL_CACHE_DISABLE", "MESA_SHADER_CACHE_DIR", "MESA_DISK_CACHE_SINGLE_FILE"):
            with self.assertRaisesRegex(ValueError, "Inherited Mesa"):
                helper.cache_environment({key: "override"}, "player")

    def test_actual_run_block_binds_selected_preparation_before_run_live_handoff(self):
        helper = self.helper(); block = 2; block_id = c.BLOCKS[block-1][0]
        prepared = self.preparation(block); lock = mock.Mock()
        guard = {"synthetic": True}; human = {"pin": {"synthetic": "human"}}
        now = time.monotonic()
        budget = {"phase_deadline_monotonic": now+480, "operator_deadline_monotonic": now+2100}
        selected = {"assets": {name: {"path": "/synthetic/"+name} for name in
            ("binary", "track_a", "track_b", "python", "exporter", "worker", "service", "runtime", "model", "guard_script", "guard_unit")}}
        plan = {"seed_proof": {"path": "/synthetic/seed.json"}, "seed_manifest_sha256": "synthetic"}
        seed = {"cleanup_proven": True, "pins_unchanged": True,
                "shader_cache": {"inventory_complete": True, "post": {"manifest_sha256": "synthetic"}}}
        def handoff(args):
            self.assertIs(args.cache_helper, helper)
            self.assertIs(args.cache_preparation, prepared)
            value = args.cache_helper.cache_environment({"PRESERVED_FIXTURE": "yes"}, "player")
            self.assertEqual(value["MESA_SHADER_CACHE_DIR"], str(helper.PHASE_CACHES[block_id]))
            self.assertEqual(value["PRESERVED_FIXTURE"], "yes")
            raise RuntimeError("synthetic run_live handoff reached")
        base = SimpleNamespace(boot_identity=lambda: "synthetic", validate_build_result=lambda _: None,
            verify_plan_files=lambda *_: None, load_cache_support=lambda: (helper, {"synthetic": "helper"}),
            guard_identity=lambda *_: guard, cool_start=lambda _: [], finalize_logger_result=lambda *_: None,
            live_required_free_bytes=lambda *_: 1, shutil=SimpleNamespace(disk_usage=lambda _: SimpleNamespace(free=10**15)),
            run_live=mock.Mock(side_effect=handoff))
        with contextlib.ExitStack() as stack:
            for name, value in {"selected_plan": lambda *_: (selected, {}), "readiness": lambda *_: human,
                "current_admission": lambda *_: ({"guard_identity": guard, "original_anchor": {}}, {"synthetic": "audit"}, budget),
                "historical_quality": lambda *_: {"pcm_result_pin": {"path": "/synthetic/quality/result.json"}},
                "checked_json": lambda *_: (seed, {"synthetic": "seed"}), "inherited_logs": lambda *_: contextlib.nullcontext()}.items():
                stack.enter_context(mock.patch.object(c, name, value))
            stack.enter_context(mock.patch.object(helper, "capture_cache_parent", return_value={"synthetic": "parent"}))
            stack.enter_context(mock.patch.object(helper, "acquire_cache_lock", return_value=lock))
            prepare = stack.enter_context(mock.patch.object(helper, "prepare_phase", return_value=prepared))
            stack.enter_context(mock.patch("subprocess.Popen", side_effect=AssertionError("No child")))
            with self.assertRaisesRegex(RuntimeError, "synthetic run_live handoff reached"):
                c.run_block(base, plan, {"synthetic": "plan"}, block, now)
        self.assertEqual(prepare.call_args.args[0], block_id)
        base.run_live.assert_called_once()
        lock.close.assert_called_once()

    def test_fresh_06_root_admission_keeps_original_budget_and_03_paths_unused(self):
        helper = self.helper()
        self.assertEqual(c.PLAN.name, "comparison-plan-06.json")
        self.assertEqual(c.HUMAN.name, "human-readiness-comparison-06.json")
        self.assertEqual(c.MODE, "runtime-only-ABBA-player120-06")
        self.assertEqual(helper.LOCK, ROOT / "comparison-06.lock")
        self.assertTrue(all(path.name.startswith("driver-cache-comparison-06-") for path in helper.PHASE_CACHES.values()))
        plan_pin, human_pin = {"sha256": "a"*64}, {"sha256": "b"*64}
        audit = {"schema": 1, "status": "passed", "block": 1,
                 "created_at_utc": datetime.now(timezone.utc).isoformat(), "boot_id": "synthetic",
                 "original_anchor": {"sampled_monotonic": 100., "age_seconds": 0., "deadline_monotonic": 2200.},
                 "plan_sha256": plan_pin["sha256"], "human_sha256": human_pin["sha256"], "source_head": c.SOURCE_HEAD,
                 "guard_identity": {"synthetic": True}, "audit_kind": "independent_root_current_host_seed_audit",
                 "prior_blocks": [], **{key: True for key in c.HEALTH}}
        with mock.patch.object(c, "checked_json", return_value=(audit, {"synthetic": True})) as checked:
            _, _, budget = c.current_admission(None, {"source_head": c.SOURCE_HEAD}, plan_pin,
                {"pin": human_pin, "sampled_monotonic": 100., "age_seconds": 0.}, 1, 150., 150., "synthetic")
        self.assertEqual(checked.call_args.args[1], ROOT / "comparison-admission-06-block-1.json")
        self.assertEqual(budget["operator_deadline_monotonic"], 2200.)
        self.assertEqual(budget["phase_deadline_monotonic"], 630.)


if __name__ == "__main__": unittest.main()
