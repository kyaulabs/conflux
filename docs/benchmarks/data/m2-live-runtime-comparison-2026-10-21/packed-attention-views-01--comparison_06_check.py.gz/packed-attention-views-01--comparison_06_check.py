#!/usr/bin/env python3
"""Offline comparison admission regressions; no model or host probes."""
import contextlib
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("comparison06_check_adapter",ROOT/"run_comparison_block_06.py")
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def file_pin(path):
    data=path.read_bytes()
    return {"path":str(path),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}


class ComparisonChecks(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.base=c.import_pinned(c.BASE_FILE,c.BASE_SHA,"comparison06_fixture_base")
        self.native=json.loads((ROOT/"short-live-packed-attention-02/result.json").read_text())
        self.plan=json.loads((ROOT/"packed-attention-plan-02.json").read_text())
        self.pin={"path":str(c.PLAN),"bytes":1,"sha256":"a"*64}
        self.human={"pin":{"path":str(c.HUMAN),"bytes":1,"sha256":"b"*64},"sampled_monotonic":100.,"age_seconds":0.}

    def test_dry_default_does_not_import_or_spawn(self):
        with mock.patch.object(c,"import_pinned",side_effect=AssertionError("no imports")),mock.patch("subprocess.Popen",side_effect=AssertionError("no child")),mock.patch("sys.stdout",io.StringIO()):
            self.assertEqual(c.main([]),0)

    def test_module_tampering_is_rejected_before_execution(self):
        path=self.root/"bad.py"
        path.write_text("raise AssertionError('module executed')\n")
        with self.assertRaisesRegex(RuntimeError,"identity/content"):
            c.import_pinned(path,"0"*64,"untrusted")

    def test_unarmed_plan_is_rejected_before_admission(self):
        with mock.patch.object(self.base,"bounded_json",return_value=({"status":"UNARMED"},self.pin)):
            with self.assertRaises(RuntimeError):c.load_plan(self.base,c.PLAN)

    def test_exact_ABBA_runtime_selection(self):
        variants={k:{"runtime":{"path":str(v[0]),"sha256":v[1]},"source_pins":{},"build_result":{}} for k,v in c.ARMS.items()}
        p={"variants":variants,"assets":{},"source_pins":{}}
        self.assertEqual([c.selected_plan(p,n)[0]["assets"]["runtime"]["sha256"] for n in range(1,5)],
                         [c.ARMS[k][1] for k in ("A_baseline","B_packed","B_packed","A_baseline")])

    def test_baseline_retains_and_binds_shared_executed_A_context(self):
        p=json.loads((ROOT/"comparison-plan-DRAFT-03.json").read_text())
        p["status"]="frozen_pending_comparison06_readiness"
        p["mode"]=c.MODE
        p["block_order"]=[x[0] for x in c.BLOCKS]
        p["cache_helper"]=file_pin(c.CACHE)
        for key,path in {"comparison_adapter":Path(c.__file__), "comparison_cache":c.CACHE,
                         "comparison_tests":ROOT/"comparison_06_check.py",
                         "comparison_cache_binding_tests":ROOT/"comparison_cache_binding_06_check.py",
                         "comparison_dispatch":ROOT/"dispatch_comparison06.py",
                         "comparison_root_admission":ROOT/"root_admission_comparison06.py"}.items():
            p["source_pins"][key]={"path":str(path),"bytes":1,"sha256":"d"*64}
        p["review"].update(status="passed",bytes=1,sha256="c"*64)
        p["source_pins"]["comparison_shared_context"]=file_pin(ROOT/"context_capture.py")
        p["source_head"]="1"*40
        p["assets"]["binary"]={"path":str(c.PLAYER_BINARY),"bytes":1,"sha256":"d"*64}
        p["source_pins"]["historical_product_archive_manifest"]=dict(c.HISTORICAL_MANIFEST)
        for relative,(size,digest) in c.HISTORICAL_PRODUCT_SOURCES.items():
            p["source_pins"]["historical_product_archive:"+relative]={"path":str(c.HISTORICAL_ARCHIVE/relative),"bytes":size,"sha256":digest}
            current=file_pin(self.base.SOURCE_ROOT/relative)
            p["source_pins"]["base:"+relative]=current
            for variant in p["variants"].values():variant["source_pins"]["base:"+relative]=dict(current)
        for row in p["source_pins"].values():
            if row["bytes"] is None:row.update(bytes=1,sha256="d"*64)
        selected,_=c.selected_plan(p,1)
        self.assertEqual(selected["source_pins"]["context_helper"]["path"],str(c.J/"context_capture.py"))
        self.assertEqual(selected["source_pins"]["comparison_shared_context"],file_pin(ROOT/"context_capture.py"))
        with mock.patch.object(c,"SOURCE_HEAD","1"*40),mock.patch.object(self.base,"bounded_json",return_value=(p,self.pin)):
            c.load_plan(self.base,c.PLAN)
        p["source_pins"]["comparison_shared_context"]["sha256"]="f"*64
        with mock.patch.object(c,"SOURCE_HEAD","1"*40),mock.patch.object(self.base,"bounded_json",return_value=(p,self.pin)):
            with self.assertRaisesRegex(RuntimeError,"Shared executed"):
                c.load_plan(self.base,c.PLAN)
        p["source_pins"]["comparison_shared_context"]=file_pin(ROOT/"context_capture.py")
        with mock.patch.object(c,"SOURCE_HEAD","DRAFT_PENDING_COMMITTED_DRAIN_HEAD"),mock.patch.object(self.base,"bounded_json",return_value=(p,self.pin)):
            with self.assertRaisesRegex(RuntimeError,"unarmed"):c.load_plan(self.base,c.PLAN)
        for mutate in (lambda v:v["assets"]["binary"].update(path=str(self.base.ASSET_PATHS["binary"])),
                       lambda v:v["variants"]["A_baseline"]["source_pins"]["base:src/library/LiveStemBridge.cpp"].update(sha256="0"*64)):
            bad=copy.deepcopy(p);mutate(bad)
            with mock.patch.object(c,"SOURCE_HEAD","1"*40),mock.patch.object(self.base,"bounded_json",return_value=(bad,self.pin)):
                with self.assertRaises(RuntimeError):c.load_plan(self.base,c.PLAN)

    def quality_fixture(self,arm):
        path=c.ARMS[arm][2]
        value=json.loads(path.read_text())
        plan={**self.plan,"assets":{**self.plan["assets"],"runtime":value["candidate_runtime"]}}
        variant={"runtime":value["candidate_runtime"],"quality_result":file_pin(path)}
        return path,value,plan,variant

    def test_both_actual_sixteen_output_proofs_and_full_dependency_closure(self):
        for arm in c.ARMS:
            with self.subTest(arm=arm):
                path,value,plan,variant=self.quality_fixture(arm)
                with mock.patch.object(self.base,"verify_plan_files") as verify,mock.patch("subprocess.Popen",side_effect=AssertionError("no model/host child")):
                    proof=c.historical_quality(self.base,plan,variant,time.monotonic()+30)
                self.assertTrue(proof["passed"])
                self.assertIn("historical",proof["scope"])
                closure=verify.call_args.args[0]["source_pins"]
                self.assertEqual(len([k for k in closure if k.startswith("historical:")]),len(value["pins_before"])+1)
                self.assertEqual(len(proof["historical_product_source_archive"]["bindings"]),3)
                for relative in c.HISTORICAL_PRODUCT_SOURCES:
                    key="source:base:"+relative
                    self.assertEqual(closure["historical:"+key]["path"],str(c.HISTORICAL_ARCHIVE/relative))
                self.assertEqual(json.loads(path.read_text()),value) # The saved proof is never rewritten.

    @contextlib.contextmanager
    def archive_fixture(self, *, duplicate=False):
        archive=self.root/"archive";archive.mkdir()
        rows=[]
        for relative,(size,digest) in c.HISTORICAL_PRODUCT_SOURCES.items():
            path=archive/relative;path.parent.mkdir(parents=True,exist_ok=True)
            path.write_bytes((c.HISTORICAL_ARCHIVE/relative).read_bytes())
            rows.append({"original_path":str(ROOT.parents[2]/relative),"archived_path":str(path),"bytes":size,"sha256":digest})
        manifest=archive/"manifest.json"
        manifest.write_text(json.dumps({"source_head":"537346694cb2056738f156c506ecc2254d407f93","files":rows+[rows[0]] if duplicate else rows}))
        with mock.patch.object(c,"HISTORICAL_ARCHIVE",archive),mock.patch.object(c,"HISTORICAL_MANIFEST",file_pin(manifest)):
            yield archive

    def verify_small_closure(self,closure):
        witness=self.root/"strict-proof";witness.write_bytes(b"strict positive fixture")
        pinned=file_pin(witness)
        plan={"assets":{},"source_pins":closure,"canonical_alias_bindings":{},
              **{k:pinned for k in ("cache_helper","gpu_helper","package_helper","seed_proof","build_result","review")}}
        with mock.patch.object(self.base,"ALIAS_PATHS",{}),mock.patch("subprocess.Popen",side_effect=AssertionError("No child")):
            self.base.verify_plan_files(plan,time.monotonic()+10)

    def test_actual_archived_bytes_use_the_real_strict_reader_and_mutation_fails(self):
        _,value,_,_=self.quality_fixture("B_packed")
        recorded={key:value["pins_before"][key] for key in ("source:base:"+x for x in c.HISTORICAL_PRODUCT_SOURCES)}
        before=copy.deepcopy(recorded)
        with self.archive_fixture() as archive:
            closure,proof=c.historical_product_closure(self.base,recorded)
            self.verify_small_closure(closure)
            self.assertEqual(recorded,before)
            self.assertTrue(all(x["recorded_pin"]==recorded[x["historical_key"]] for x in proof["bindings"]))
            path=archive/"src/library/LiveStemBridge.cpp"
            raw=path.read_bytes();path.write_bytes(b"X"+raw[1:])
            with self.assertRaisesRegex(RuntimeError,"content changed"):
                self.verify_small_closure(closure)

    def test_archived_binding_never_accepts_different_or_missing_recorded_source(self):
        _,value,_,_=self.quality_fixture("B_packed")
        key="source:base:src/library/LiveStemBridge.cpp"
        for mutation in (lambda v:v.pop(key),lambda v:v[key].update(path=str(self.root/"other.cpp")),
                         lambda v:v[key].update(bytes=v[key]["bytes"]+1),lambda v:v[key].update(sha256="0"*64)):
            bad=copy.deepcopy(value["pins_before"]);mutation(bad)
            with self.assertRaisesRegex(RuntimeError,"exact archived binding"):
                c.historical_product_closure(self.base,bad)
        with self.archive_fixture(duplicate=True):
            with self.assertRaisesRegex(RuntimeError,"exact archived binding"):
                c.historical_product_closure(self.base,value["pins_before"])

    def test_every_other_historical_source_keeps_its_original_strict_verification(self):
        _,value,_,_=self.quality_fixture("B_packed")
        recorded={key:value["pins_before"][key] for key in ("source:base:"+x for x in c.HISTORICAL_PRODUCT_SOURCES)}
        other=self.root/"unrelated.cpp";other.write_bytes(b"unrelated historical source")
        recorded["source:base:unrelated.cpp"]=file_pin(other)
        closure,proof=c.historical_product_closure(self.base,recorded)
        self.assertEqual(len(proof["bindings"]),3)
        self.assertEqual(closure["historical:source:base:unrelated.cpp"],recorded["source:base:unrelated.cpp"])
        self.verify_small_closure(closure)
        other.write_bytes(b"changed historical source")
        with self.assertRaises(RuntimeError):self.verify_small_closure(closure)

    def test_quality_wrong_arm_and_output_tampering_fail(self):
        path,value,plan,variant=self.quality_fixture("B_packed")
        original=c.checked_json
        for mutation in (lambda v:v["candidate_runtime"].update(sha256=c.ARMS["A_baseline"][1]),
                         lambda v:v["requests"][0].update(output_sha256="f"*64),
                         lambda v:v["cases"][0]["normalization"].update(std=0),
                         lambda v:v.update(cleanup_complete=False)):
            bad=copy.deepcopy(value);mutation(bad)
            def read(base,p,expected=None,maximum=2*1024**2):
                return (bad,file_pin(path)) if p==path else original(base,p,expected,maximum)
            with mock.patch.object(c,"checked_json",side_effect=read),mock.patch.object(self.base,"verify_plan_files"):
                with self.assertRaises(RuntimeError):c.historical_quality(self.base,plan,variant,time.monotonic()+30)

    def test_consumed_old_human_is_not_new_comparison_readiness(self):
        old=json.loads((ROOT/"human-readiness-packed-attention-02.json").read_text())
        with mock.patch.object(c,"checked_json",return_value=(old,self.pin)):
            with self.assertRaises(RuntimeError):c.readiness(self.base,c.HUMAN,self.pin)

    def test_new_mode_and_four_stages_are_required_even_with_fresh_UTC(self):
        value={"schema":1,"decision":"ready","recorded_at_utc":datetime.now(timezone.utc).isoformat(),
            "ready_for_diagnostic":c.MODE,"diagnostic_mode":c.MODE,"stages":[x[0] for x in c.BLOCKS],
            "ui_mode":"background","window_policy":"hidden","maximum_operator_seconds":2100,
            "plan_sha256":self.pin["sha256"],"question_item_id":"fixture","human_question":"fixture","human_reply":"ready",
            **{k:True for k in ("AC_power","lid_open","Codex_minimized","other_work_paused","controls_untouched","no_suspend")}}
        with mock.patch.object(c,"checked_json",return_value=(value,self.human["pin"])):
            self.assertEqual(c.readiness(self.base,c.HUMAN,self.pin)["maximum_age_seconds"],2100)
        for change in ({"diagnostic_mode":"packed-attention-views-pcm16-player120-02"},
                       {"maximum_operator_seconds":960},{"stages":["pcm16","player120"]}):
            with mock.patch.object(c,"checked_json",return_value=({**value,**change},self.human["pin"])):
                with self.assertRaises(RuntimeError):c.readiness(self.base,c.HUMAN,self.pin)

    def test_target_only_failure_keeps_nonzero_and_failed_verdict(self):
        self.assertEqual(c.healthy_result(self.native,1),"complete_latency_only_failure")
        passed=copy.deepcopy(self.native)
        passed.update(service_target_met=True,passed=True)
        passed["observations"]["service_hops"].update(nearest_rank_p99_ms=2000.,maximum_ms=2000.,at_or_above_target=0)
        self.assertEqual(c.healthy_result(passed,0),"complete_target_pass")
        with self.assertRaises(RuntimeError):c.healthy_result(self.native,0)

    def test_other_failure_never_continues_diagnostics(self):
        mutations=(lambda r:r.update(stop_reason="stop"),lambda r:r.update(functional_passed=False),
                   lambda r:r.update(error="failure"),lambda r:r["native_trace"].update(passed=False),
                   lambda r:r["cleanup"].update(remaining_pipewire_count=1),
                   lambda r:r["shader_cache"].update(seed_unchanged=False),
                   lambda r:r["native"]["recording"].update(overflowFrames=1),
                   lambda r:r["observations"]["service_hops"].update(strict_target_ms=7000),
                   lambda r:r["capture"]["stderr"].update(complete=False))
        for mutation in mutations:
            bad=copy.deepcopy(self.native);mutation(bad)
            with self.assertRaises(RuntimeError):c.healthy_result(bad,1)
        with self.assertRaises(RuntimeError):c.healthy_result(self.native,2)

    def admission(self,block=1):
        return {"schema":1,"status":"passed","block":block,"created_at_utc":datetime.now(timezone.utc).isoformat(),
            "plan_sha256":self.pin["sha256"],"human_sha256":self.human["pin"]["sha256"],"source_head":c.SOURCE_HEAD,
            "boot_id":"fixture-boot","original_anchor":{"sampled_monotonic":100.,"age_seconds":0.,"deadline_monotonic":2200.},
            "prior_blocks":[],"guard_identity":{"fixture":"unchanged"},
            "audit_kind":"independent_root_current_host_seed_audit",**{k:True for k in c.HEALTH}}

    def test_new_root_admission_and_original_clock_budget(self):
        audit=self.admission();plan={"source_head":c.SOURCE_HEAD}
        with mock.patch.object(c,"checked_json",return_value=(audit,self.pin)):
            _,_,budget=c.current_admission(self.base,plan,self.pin,self.human,1,150.,150.,"fixture-boot")
        self.assertEqual(budget["operator_deadline_monotonic"],2200.)
        self.assertEqual(budget["phase_deadline_monotonic"],630.)
        for bad in ({**audit,"boot_id":"new-boot"},{**audit,"owned_groups_absent":False},
                    {**audit,"block":2},{**audit,"human_sha256":"e"*64}):
            with mock.patch.object(c,"checked_json",return_value=(bad,self.pin)):
                with self.assertRaises(RuntimeError):c.current_admission(self.base,plan,self.pin,self.human,1,150.,150.,"fixture-boot")
        with mock.patch.object(c,"checked_json",return_value=(audit,self.pin)):
            with self.assertRaises(RuntimeError):c.current_admission(self.base,plan,self.pin,self.human,1,1800.,1800.,"fixture-boot")

    def test_prior_block_order_and_missing_pins_fail_closed(self):
        audit=self.admission(2)
        audit["prior_blocks"]=[{"block":1}]
        first=self.admission()
        def read(base,path,*args,**kwargs):
            return (first,self.pin) if path.name.endswith("block-1.json") else (audit,self.pin)
        with mock.patch.object(c,"checked_json",side_effect=read):
            with self.assertRaisesRegex(RuntimeError,"pin incomplete"):
                c.current_admission(self.base,{"source_head":c.SOURCE_HEAD},self.pin,self.human,2,150.,150.,"fixture-boot")

    def test_prior_monotonic_deadline_clamps_a_later_UTC_reconstruction(self):
        first=self.admission();audit=self.admission(2)
        result=copy.deepcopy(self.native)
        result.update(diagnostic_mode=c.MODE,plan_pin=self.pin,repository_head=c.SOURCE_HEAD,head_after=c.SOURCE_HEAD)
        result["human_before_launch"]["pin"]=self.human["pin"]
        result["native"]["setup"]["runtime_sha256"]=c.ARMS["A_baseline"][1]
        for key in ("pins_before","pins_after"):
            result[key]["runtime"].update(path=str(c.ARMS["A_baseline"][0]),sha256=c.ARMS["A_baseline"][1])
        result["comparison"]={"block":1,"arm":"A_baseline","original_anchor":audit["original_anchor"]}
        result["operator_budget"]["operator_deadline_monotonic"]=1900.
        rp={"path":str(ROOT/"comparison-06-A1-baseline/result.json"),"bytes":1,"sha256":"c"*64}
        sp={"path":str(ROOT/"comparison-06-A1-baseline/comparison-summary.json"),"bytes":1,"sha256":"d"*64}
        summary={"block":1,"plan_sha256":self.pin["sha256"],"human_sha256":self.human["pin"]["sha256"],
            "result_pin":rp,"original_anchor":audit["original_anchor"],"exit_code":1,"strict_source_closure_after":True}
        audit["prior_blocks"]=[{"block":1,"result_pin":rp,"summary_pin":sp}]
        def read(base,path,*args,**kwargs):
            if path.name=="comparison-summary.json":return summary,sp
            if path.name=="result.json":return result,rp
            return (first,self.pin) if path.name.endswith("block-1.json") else (audit,self.pin)
        later={**self.human,"sampled_monotonic":1000.,"age_seconds":0.}
        with mock.patch.object(c,"checked_json",side_effect=read):
            _,_,budget=c.current_admission(self.base,{"source_head":c.SOURCE_HEAD},self.pin,later,2,1000.,1000.,"fixture-boot")
            self.assertEqual(budget["operator_deadline_monotonic"],1900.)
            with self.assertRaisesRegex(RuntimeError,"Insufficient"):
                c.current_admission(self.base,{"source_head":c.SOURCE_HEAD},self.pin,later,2,1500.,1500.,"fixture-boot")
        audit["prior_blocks"]=[{"block":2}]
        with mock.patch.object(c,"checked_json",side_effect=read):
            with self.assertRaisesRegex(RuntimeError,"order"):
                c.current_admission(self.base,{"source_head":c.SOURCE_HEAD},self.pin,self.human,2,150.,150.,"fixture-boot")

    def test_four_new_cache_paths_keep_the_old_helper_unchanged(self):
        helper=c.import_pinned(c.CACHE,c.CACHE_SHA,"comparison06_fixture_cache")
        self.assertEqual(set(helper.PHASE_CACHES),{x[0] for x in c.BLOCKS})
        self.assertEqual(len(set(helper.PHASE_CACHES.values())),4)
        self.assertTrue(all(p.parent==ROOT and "comparison-06" in p.name for p in helper.PHASE_CACHES.values()))
        self.assertEqual(helper.LOCK,ROOT/"comparison-06.lock")
        self.assertEqual(helper.capture_cache_parent()["mode"],0o700)
        self.assertEqual(file_pin(ROOT/"cache_support.py")["sha256"],"ae6a4d488b3b18c181808bfeb1cc68000392028b9feacea69ab9b17edbc58331")

    def test_inherited_child_stdout_and_stderr_are_redirected(self):
        out,err=self.root/"stdout",self.root/"stderr"
        with c.inherited_logs(out,err):
            subprocess.run([sys.executable,"-I","-B","-c","import os;os.write(1,b'child-out');os.write(2,b'child-err')"],
                           stdin=subprocess.DEVNULL,check=True,timeout=5)
        self.assertEqual(out.read_bytes(),b"child-out")
        self.assertEqual(err.read_bytes(),b"child-err")
        with self.assertRaises(FileExistsError):
            with c.inherited_logs(out,err):pass

    def test_fixed_imported_run_live_bindings_do_not_relabel_quality(self):
        quality={"pcm_result_pin":{"path":str(c.ARMS["A_baseline"][2])}}
        c.bind(self.base,1,quality,ROOT/"comparison-admission-06-block-1.json")
        self.assertEqual(self.base.OUTPUT,ROOT/"comparison-06-A1-baseline")
        self.assertEqual(self.base.PCM_OUTPUT,c.ARMS["A_baseline"][2].parent)
        self.assertEqual(self.base.HUMAN,c.HUMAN)
        self.assertEqual(self.base.MODE,c.MODE)
        self.assertEqual(self.base.CACHE_HELPER,c.CACHE)


if __name__=="__main__":unittest.main()
