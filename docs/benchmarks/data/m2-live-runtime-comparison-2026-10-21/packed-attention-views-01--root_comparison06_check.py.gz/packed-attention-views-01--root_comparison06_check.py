#!/usr/bin/env python3
"""Temporary-file/mocked root admission and dispatch checks; no host workload."""
import contextlib
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest import mock

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


AUDIT = load("root06_audit_check", ROOT / "root_admission_comparison06.py")
DISPATCH = load("root06_dispatch_check", ROOT / "dispatch_comparison06.py")
OLD = load("root06_immutable_reader", ROOT / "run_comparison_block_03.py")
REAL_BASE = OLD.import_pinned(OLD.BASE_FILE, OLD.BASE_SHA, "root06_frozen_base")
sys.modules["root06_fixture"] = sys.modules[__name__]
READINESS = None
SEED_HELPER = None


class ReadySentinel(Exception):
    pass


class PowerSentinel(Exception):
    pass


class ExecSentinel(Exception):
    pass


def pin(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def write(path, value):
    path.write_text(json.dumps(value) + "\n")
    return pin(path)


def human(issued):
    return {"schema": 1, "decision": "ready", "plan_sha256": "a" * 64, "diagnostic_mode": DISPATCH.MODE,
            "ready_for_diagnostic": DISPATCH.MODE, "maximum_operator_seconds": 2100,
            "stages": list(DISPATCH.BLOCKS), "ui_mode": "background", "window_policy": "hidden",
            "recorded_at_utc": issued.isoformat(), "question_item_id": "fixture",
            "human_question": "fixture conditions", "human_reply": "ready",
            **{k: True for k in ("AC_power", "lid_open", "Codex_minimized", "other_work_paused",
                                "controls_untouched", "no_suspend")}}


class RootChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.child = mock.patch("subprocess.Popen", side_effect=AssertionError("No real children"))
        self.child.start()
        self.addCleanup(self.child.stop)

    def audit_fixture(self):
        self.plan_path = self.root / "comparison-plan-06.json"
        self.stub = self.root / "run_comparison_block_06.py"
        self.stub.write_text('''import sys
f=sys.modules['root06_fixture']
BASE_FILE=BASE_SHA=HUMAN=None
BLOCKS=(("06-A1-baseline","A_baseline"),("06-B1-packed","B_packed"),("06-B2-packed","B_packed"),("06-A2-baseline","A_baseline"))
HEALTH=()
def import_pinned(*args): return f.REAL_BASE
def load_plan(base,path): return base.bounded_json(path)
same_pin=f.OLD.same_pin
def readiness(*args):
 if f.READINESS is None: raise f.ReadySentinel('reached readiness after actual pin gate')
 return f.READINESS
def checked_json(base,path,expected=None,maximum=2097152):
 value,actual=base.bounded_json(path,maximum)
 if expected is not None and not same_pin(actual,expected): raise ValueError('retained pin differs')
 return value,actual
def selected_plan(plan,block): return plan,{}
def healthy_result(result,code):
 if result['guard_before']!=result['guard_after']: raise ValueError('guard changed within workload')
 return 'fixture health isolated from guard-schema comparison'
''')
        self.plan = {"source_pins": {"comparison_root_admission": pin(Path(AUDIT.__file__).resolve()),
                                     "comparison_adapter": pin(self.stub)}, "source_head": "fixture-head"}
        self.plan_pin = write(self.plan_path, self.plan)

    def audit_call(self, block):
        def commands(argv, **_kwargs):
            if argv == ["git", "-C", str(REAL_BASE.SOURCE_ROOT), "rev-parse", "HEAD"]:
                return "fixture-head"
            raise AssertionError("No actual host command")
        with contextlib.ExitStack() as stack:
            stack.enter_context(mock.patch.object(AUDIT, "ROOT", self.root))
            stack.enter_context(mock.patch.object(AUDIT, "PLAN", self.plan_path))
            stack.enter_context(mock.patch.object(AUDIT, "pid_absent", side_effect=AssertionError("No PID query")))
            stack.enter_context(mock.patch.object(REAL_BASE, "boot_identity", return_value="fixture-boot"))
            stack.enter_context(mock.patch.object(REAL_BASE, "read_command", side_effect=commands))
            stack.enter_context(mock.patch.object(REAL_BASE, "verify_plan_files"))
            stack.enter_context(mock.patch.object(AUDIT, "verify_native_captures", return_value={}))
            stack.enter_context(mock.patch.object(REAL_BASE, "guard_identity", return_value=getattr(self, "guard", {})))
            stack.enter_context(mock.patch.object(REAL_BASE, "power_state", side_effect=PowerSentinel("guard seam passed")))
            AUDIT.audit(block, self.plan_pin["sha256"])

    def test_actual_three_vs_four_field_reader_seam(self):
        path = self.root / "fixture.json"
        expected = write(path, {"fixture": 1})
        raw, simple = AUDIT.verified_bytes(path, expected, 4096)
        value, rich = REAL_BASE.bounded_json(path, 4096)
        self.assertEqual(json.loads(raw), value)
        self.assertNotEqual(simple, rich)
        self.assertTrue(OLD.same_pin(simple, rich))
        for field, bad in (("path", str(self.root / "other")), ("bytes", expected["bytes"] + 1), ("sha256", "0" * 64)):
            with self.assertRaises(ValueError):
                AUDIT.verified_bytes(path, {**expected, field: bad}, 4096)

    def test_first_actual_audit_prefix_reaches_readiness_without_host(self):
        global READINESS
        READINESS = None
        self.audit_fixture()
        with self.assertRaisesRegex(ReadySentinel, "actual pin gate"):
            self.audit_call(1)
        self.assertFalse((self.root / "comparison-admission-06-block-1.json").exists())

    def test_actual_audit_prefix_rejects_pinned_adapter_mutation(self):
        global READINESS
        READINESS = None
        self.audit_fixture()
        self.plan["source_pins"]["comparison_adapter"]["sha256"] = "f" * 64
        self.plan_pin = write(self.plan_path, self.plan)
        with self.assertRaisesRegex(ValueError, "pin differs"):
            self.audit_call(1)

    def second_fixture(self):
        global READINESS
        self.audit_fixture()
        for name in ("guard.sh", "guard.service"):
            (self.root / name).write_text("generated guard identity fixture\n")
        self.guard = {"service": {"ActiveState": "active", "MainPID": "123", "InvocationID": "fixture"},
                      "process": {"pid": 123, "start_ticks": 456, "command": ["generated-guard"]},
                      "script": pin(self.root / "guard.sh"), "unit": pin(self.root / "guard.service")}
        rich = copy.deepcopy(self.guard)
        for name in ("script", "unit"):
            rich[name].update(canonical_path=rich[name]["path"], identity=[1, 2, rich[name]["bytes"], 4, 5])
        self.plan["assets"] = {"guard_script": {"path": self.guard["script"]["path"]},
                               "guard_unit": {"path": self.guard["unit"]["path"]}}
        self.plan_pin = write(self.plan_path, self.plan)
        now = time.monotonic()
        self.anchor = {"sampled_monotonic": now - 100, "age_seconds": 0., "deadline_monotonic": now + 2000}
        READINESS = {"pin": {"sha256": "b" * 64}, "sampled_monotonic": now, "age_seconds": 100.}
        self.first = {"plan_sha256": self.plan_pin["sha256"], "human_sha256": "b" * 64, "boot_id": "fixture-boot",
                      "original_anchor": self.anchor, "guard_identity": self.guard,
                      "guard_file_metadata": AUDIT.guard_file_metadata(self.guard)}
        self.dispatch = {"mode": "audit", "block": 1, "new_window": False, "boot_id": "fixture-boot",
                         "plan_sha256": self.plan_pin["sha256"], "human_sha256": "b" * 64,
                         "sampled_monotonic": self.anchor["sampled_monotonic"],
                         "original_deadline_monotonic": self.anchor["deadline_monotonic"]}
        self.result = {"repository_head": "fixture-head", "head_after": "fixture-head",
                       "comparison": {"block": 1, "original_anchor": self.anchor},
                       "guard_before": rich, "guard_after": copy.deepcopy(rich),
                       "cleanup": {"known_processes": [], "owned_group_absent": {}}, "pins_after": {},
                       "native_trace": {"pin": {}}, "request_trace": {}, "observations": {"file": {}}, "capture": {}}
        self.output = self.root / "comparison-06-A1-baseline"
        self.output.mkdir()
        self.write_second()

    def write_second(self):
        write(self.root / "root-dispatch-comparison-06-audit-1.json", self.dispatch)
        write(self.root / "comparison-admission-06-block-1.json", self.first)
        result_pin = write(self.output / "result.json", self.result)
        write(self.output / "comparison-summary.json", {"block": 1, "plan_sha256": self.plan_pin["sha256"],
              "human_sha256": "b" * 64, "original_anchor": self.anchor, "strict_source_closure_after": True,
              "result_pin": result_pin, "exit_code": 0 if self.result.get("service_target_met", True) else 1})

    def test_second_actual_audit_accepts_rich_guard_pins(self):
        self.second_fixture()
        self.assertNotEqual(self.guard, self.result["guard_before"])
        with self.assertRaisesRegex(PowerSentinel, "guard seam passed"):
            self.audit_call(2)

    def test_initial_dispatch_anchor_is_exact_and_rejects_other_window(self):
        self.second_fixture()
        with mock.patch.object(AUDIT, "ROOT", self.root):
            anchor, _pin = AUDIT.initial_dispatch_anchor(OLD, REAL_BASE, self.plan_pin,
                                                       {"pin": {"sha256": "b" * 64}}, "fixture-boot")
            self.assertEqual(anchor, self.anchor)
            original = dict(self.dispatch)
            for change in ({"boot_id": "other-boot"}, {"human_sha256": "f" * 64},
                           {"original_deadline_monotonic": self.anchor["sampled_monotonic"] + 2200}):
                write(self.root / "root-dispatch-comparison-06-audit-1.json", {**original, **change})
                with self.assertRaises(ValueError):
                    AUDIT.initial_dispatch_anchor(OLD, REAL_BASE, self.plan_pin,
                                                  {"pin": {"sha256": "b" * 64}}, "fixture-boot")

    def test_second_actual_audit_rejects_guard_and_rich_metadata_changes(self):
        self.second_fixture()
        original = copy.deepcopy(self.result)
        for mutation in (lambda g: g["script"].update(sha256="f" * 64),
                         lambda g: g["unit"].update(bytes=g["unit"]["bytes"] + 1),
                         lambda g: g["process"].update(start_ticks=999),
                         lambda g: g["service"].update(InvocationID="changed")):
            self.result = copy.deepcopy(original)
            mutation(self.result["guard_before"])
            self.result["guard_after"] = copy.deepcopy(self.result["guard_before"])
            self.write_second()
            with self.assertRaisesRegex(ValueError, "Guard changed across prior workload"):
                self.audit_call(2)
        self.result = original
        self.first["guard_file_metadata"]["script"]["st_ino"] += 1
        self.write_second()
        with self.assertRaisesRegex(ValueError, "Guard changed since initial admission"):
            self.audit_call(2)

    def test_dispatch_default_does_not_read_or_exec(self):
        with mock.patch.object(DISPATCH, "read", side_effect=AssertionError("No input reads")), \
             mock.patch.object(Path, "read_text", side_effect=AssertionError("No boot read")), \
             mock.patch.object(DISPATCH.os, "execv", side_effect=AssertionError("No exec")), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(DISPATCH.main([]), 0)

    def test_dispatch_original_and_prior_clamps_do_not_renew_UTC(self):
        issued = datetime(2026, 10, 20, tzinfo=timezone.utc)
        h = human(issued)
        first = {"status": "passed", "block": 1, "plan_sha256": "a" * 64, "human_sha256": "b" * 64,
                 "boot_id": "fixture-boot", "original_anchor": {"sampled_monotonic": 900., "age_seconds": 0.,
                                                                "deadline_monotonic": 3000.}}
        self.assertEqual(DISPATCH.original_deadline(h, "b" * 64, "a" * 64, 1000., issued + timedelta(seconds=100),
                                                   "fixture-boot", None, []), 3000.)
        self.assertEqual(DISPATCH.original_deadline(h, "b" * 64, "a" * 64, 1100., issued + timedelta(seconds=50),
                                                   "fixture-boot", first, [2800., 2700.]), 2700.)
        for bad in ({**first, "boot_id": "new-boot"},
                    {**first, "original_anchor": {**first["original_anchor"], "deadline_monotonic": 3100.}}):
            with self.assertRaises(ValueError):
                DISPATCH.original_deadline(h, "b" * 64, "a" * 64, 1100., issued + timedelta(seconds=100),
                                           "fixture-boot", bad, [])

    def test_dispatch_freshness_and_old_mode_are_rejected(self):
        issued = datetime(2026, 10, 20, tzinfo=timezone.utc)
        for age in (-1, 121, 2100):
            with self.assertRaises(ValueError):
                DISPATCH.original_deadline(human(issued), "b" * 64, "a" * 64, 1000., issued + timedelta(seconds=age),
                                           "fixture-boot", None, [])
        h = human(issued)
        h["diagnostic_mode"] = "runtime-only-ABBA-player120-03"
        with self.assertRaises(ValueError):
            DISPATCH.human_age(h, "a" * 64, issued)

    def test_dispatch_whole_phase_and_kill_grace_boundaries(self):
        self.assertEqual(DISPATCH.allocation("audit", 107., 100.), (6, 1, 5))
        self.assertEqual(DISPATCH.allocation("audit", 191., 100.), (90, 85, 5))
        self.assertEqual(DISPATCH.allocation("player", 581., 100.), (480, 450, 30))
        for mode, deadline in (("audit", 106.), ("player", 580.999), ("audit", float("nan"))):
            with self.assertRaises(ValueError):
                DISPATCH.allocation(mode, deadline, 100.)

    def dispatch_fixture(self, mode, block):
        self.issued = datetime(2026, 10, 20, tzinfo=timezone.utc)
        sources = {}
        for key, name in (("comparison_dispatch", "dispatch_comparison06.py"),
                          ("comparison_root_admission", "root_admission_comparison06.py"),
                          ("comparison_adapter", "run_comparison_block_06.py")):
            path = self.root / name
            path.write_bytes((ROOT / name).read_bytes())
            sources[key] = pin(path)
        plan = {"mode": DISPATCH.MODE, "operator_seconds": 2100, "phase_seconds": 480,
                "block_order": list(DISPATCH.BLOCKS), "source_pins": sources}
        self.dispatch_plan_path = self.root / "comparison-plan-06.json"
        self.dispatch_plan_pin = write(self.dispatch_plan_path, plan)
        self.dispatch_human = human(self.issued)
        self.dispatch_human["plan_sha256"] = self.dispatch_plan_pin["sha256"]
        self.dispatch_human_path = self.root / "human-readiness-comparison-06.json"
        human_pin = write(self.dispatch_human_path, self.dispatch_human)
        if mode != "audit" or block != 1:
            write(self.root / "comparison-admission-06-block-1.json", {"status": "passed", "block": 1,
                  "plan_sha256": self.dispatch_plan_pin["sha256"], "human_sha256": human_pin["sha256"],
                  "boot_id": "fixture-boot", "original_anchor": {"sampled_monotonic": 900.,
                  "age_seconds": 0., "deadline_monotonic": 3000.}})
        for previous in range(1, block):
            output = self.root / ("comparison-" + DISPATCH.BLOCKS[previous - 1])
            output.mkdir()
            write(output / "result.json", {"operator_budget": {"operator_deadline_monotonic": 2800.}})
        self.dispatch_argv = ["--execute", mode, "--block", str(block), "--plan-sha256", self.dispatch_plan_pin["sha256"]]

    @contextlib.contextmanager
    def dispatch_boundary(self):
        with contextlib.ExitStack() as stack:
            stack.enter_context(mock.patch.object(DISPATCH, "ROOT", self.root))
            stack.enter_context(mock.patch.object(DISPATCH, "PLAN", self.dispatch_plan_path))
            stack.enter_context(mock.patch.object(DISPATCH, "HUMAN", self.dispatch_human_path))
            clock = stack.enter_context(mock.patch.object(DISPATCH, "datetime", wraps=datetime))
            clock.now.return_value = self.issued + timedelta(seconds=100)
            stack.enter_context(mock.patch.object(DISPATCH.time, "monotonic", return_value=1000.))
            boot = stack.enter_context(mock.patch.object(Path, "read_text", return_value="fixture-boot"))
            execute = stack.enter_context(mock.patch.object(DISPATCH.os, "execv", side_effect=ExecSentinel("no real exec")))
            stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
            yield execute, boot

    def test_actual_dispatch_first_audit_handoff_and_exclusive_record(self):
        self.dispatch_fixture("audit", 1)
        with self.dispatch_boundary() as (execute, boot):
            with self.assertRaises(ExecSentinel):
                DISPATCH.main(self.dispatch_argv)
            argv = execute.call_args.args[1]
            self.assertEqual(argv[:4], ["/usr/bin/timeout", "--signal=TERM", "--kill-after=5s", "85s"])
            self.assertEqual(argv[7:], [str(self.root / "root_admission_comparison06.py"), "--audit", "--block", "1",
                                      "--plan-sha256", self.dispatch_plan_pin["sha256"]])
            boot.assert_called_once()
            record_path = self.root / "root-dispatch-comparison-06-audit-1.json"
            before = pin(record_path)
            with self.assertRaises(FileExistsError):
                DISPATCH.main(self.dispatch_argv)
            self.assertEqual(pin(record_path), before)
            self.assertEqual(execute.call_count, 1)
        record = json.loads(record_path.read_bytes())
        self.assertEqual(record["original_deadline_monotonic"], 3000.)
        self.assertEqual(record["allowed_total_seconds"], 90)
        self.assertFalse(record["new_window"])

    def test_actual_dispatch_later_player_handoff_clamps_prior_deadline(self):
        self.dispatch_fixture("player", 2)
        with self.dispatch_boundary() as (execute, _boot):
            with self.assertRaises(ExecSentinel):
                DISPATCH.main(self.dispatch_argv)
            argv = execute.call_args.args[1]
            self.assertEqual(argv[:4], ["/usr/bin/timeout", "--signal=INT", "--kill-after=30s", "450s"])
            self.assertEqual(argv[7:], [str(self.root / "run_comparison_block_06.py"), "--run", "--block", "2",
                                      "--allow-host-audio", "--drm-busy-diagnostic"])
        record = json.loads((self.root / "root-dispatch-comparison-06-player-2.json").read_bytes())
        self.assertEqual(record["original_deadline_monotonic"], 2800.)
        self.assertEqual(record["allowed_total_seconds"], 480)

    def test_actual_dispatch_source_tampering_rejects_before_boot_or_exec(self):
        self.dispatch_fixture("audit", 1)
        with (self.root / "root_admission_comparison06.py").open("ab") as stream:
            stream.write(b"\n# changed fixture bytes\n")
        with self.dispatch_boundary() as (execute, boot):
            with self.assertRaisesRegex(ValueError, "command source changed"):
                DISPATCH.main(self.dispatch_argv)
            execute.assert_not_called()
            boot.assert_not_called()
        self.assertFalse((self.root / "root-dispatch-comparison-06-audit-1.json").exists())

    def capture_fixture(self, data=b""):
        output = self.root / "raw-captures"
        output.mkdir(mode=0o700)
        result = {"capture": {}}
        for stream in ("stdout", "stderr"):
            path = output / ("native." + stream + ".log")
            path.write_bytes(data)
            result["capture"][stream] = {"complete": True, "bytes_received": len(data),
                "sha256_received": hashlib.sha256(data).hexdigest(), "retained_file": pin(path)}
        return output, result

    def test_actual_saved_A1_empty_captures_are_valid_only_as_captures(self):
        # Explicit historical04 evidence is read only; never touch its files.
        old = ROOT / "comparison-04-A1-baseline"
        result = json.loads((old / "result.json").read_bytes())
        checks = AUDIT.verify_native_captures(old, result, time.monotonic() + 10)
        self.assertEqual(set(checks), {"stdout", "stderr"})
        self.assertTrue(all(row["pin"]["bytes"] == 0 for row in checks.values()))
        empty = self.root / "not-a-capture.py"
        empty.write_bytes(b"")
        with self.assertRaises(ValueError):
            AUDIT.verified_bytes(empty, pin(empty), 4096)

    def test_capture_counter_metadata_and_missing_rows_fail_closed(self):
        output, original = self.capture_fixture()
        for mutation in (lambda r: r["capture"].pop("stderr"),
                         lambda r: r["capture"]["stdout"].update(complete=False),
                         lambda r: r["capture"]["stdout"].update(bytes_received=True),
                         lambda r: r["capture"]["stdout"].update(bytes_received=1),
                         lambda r: r["capture"]["stdout"].update(sha256_received="f" * 64),
                         lambda r: r["capture"]["stdout"]["retained_file"].update(path=str(output / "other")),
                         lambda r: r["capture"]["stdout"]["retained_file"].update(bytes=-1),
                         lambda r: (r["capture"]["stdout"]["retained_file"].update(sha256="f" * 64),
                                    r["capture"]["stdout"].update(sha256_received="f" * 64))):
            bad = copy.deepcopy(original)
            mutation(bad)
            with self.assertRaises(ValueError):
                AUDIT.verify_native_captures(output, bad, time.monotonic() + 10)
        (output / "native.stdout.log").unlink()
        with self.assertRaises(FileNotFoundError):
            AUDIT.verify_native_captures(output, original, time.monotonic() + 10)

    def test_capture_nonregular_alias_link_and_owner_are_rejected(self):
        output, result = self.capture_fixture(b"abc")
        path = output / "native.stdout.log"
        backup = output / "backup"
        path.rename(backup)
        path.symlink_to(backup)
        with self.assertRaises((ValueError, OSError)):
            AUDIT.verify_native_captures(output, result, time.monotonic() + 10)
        path.unlink()
        os.link(backup, path)
        with self.assertRaises(ValueError):
            AUDIT.verify_native_captures(output, result, time.monotonic() + 10)
        path.unlink()
        os.mkfifo(path)
        with self.assertRaises(ValueError):
            AUDIT.verify_native_captures(output, result, time.monotonic() + 10)
        path.unlink()
        backup.rename(path)
        actual_uid = os.getuid()
        with mock.patch.object(AUDIT.os, "getuid", return_value=actual_uid + 1), self.assertRaises(ValueError):
            AUDIT.verify_native_captures(output, result, time.monotonic() + 10)

    def test_capture_bounds_content_change_and_deadline_are_rejected(self):
        output, result = self.capture_fixture(b"abc")
        path = output / "native.stdout.log"
        self.assertEqual(AUDIT.verify_native_captures(output, result, time.monotonic() + 10)["stdout"]["pin"]["bytes"], 3)
        path.write_bytes(b"ab")
        with self.assertRaisesRegex(ValueError, "file/extent"):
            AUDIT.verify_native_captures(output, result, time.monotonic() + 10)
        path.write_bytes(b"abc")
        read = os.read
        def mutate_after_read(fd, size):
            data = read(fd, size)
            if data == b"abc":
                path.write_bytes(b"changed after read")
            return data
        with mock.patch.object(AUDIT.os, "read", side_effect=mutate_after_read), self.assertRaises(ValueError):
            AUDIT.verify_native_captures(output, result, time.monotonic() + 10)
        data = b"x" * (2 * 1024**2 + 1)
        path.write_bytes(data)
        result["capture"]["stdout"] = {"complete": True, "bytes_received": len(data),
            "sha256_received": hashlib.sha256(data).hexdigest(), "retained_file": pin(path)}
        with self.assertRaisesRegex(ValueError, "metadata differs"):
            AUDIT.verify_native_captures(output, result, time.monotonic() + 10)
        with self.assertRaisesRegex(ValueError, "deadline"):
            AUDIT.verify_native_captures(output, result, time.monotonic() - 1)

    def full_second_fixture(self):
        global SEED_HELPER
        self.second_fixture()
        self.plan["assets"]["guard_script"] = self.guard["script"]
        self.plan["assets"]["guard_unit"] = self.guard["unit"]
        self.output.chmod(0o700)
        saved = json.loads((ROOT / "comparison-04-A1-baseline/result.json").read_bytes())
        # Retain the actual complete result schema and health fields, replacing
        # only file content/paths and clock/guard context with staged fixtures.
        self.result = copy.deepcopy(saved)
        self.result.update(repository_head="fixture-head", head_after="fixture-head")
        self.result["comparison"].update(block=1, original_anchor=self.anchor)
        rich_guard = copy.deepcopy(self.guard)
        for name in ("script", "unit"):
            info = Path(rich_guard[name]["path"]).stat()
            rich_guard[name].update(canonical_path=rich_guard[name]["path"],
                identity=[info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns])
        self.result["guard_before"] = rich_guard
        self.result["guard_after"] = copy.deepcopy(rich_guard)
        staging = self.root / "staged-positive-files"
        staging.mkdir(mode=0o700)
        def staged(label, old):
            path = staging / (label + ".json")
            path.write_bytes((json.dumps({"staged": label}) + "\n").encode())
            info = path.stat()
            return {**old, **pin(path), "canonical_path": str(path),
                    "identity": [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns]}
        self.result["pins_after"] = {key: staged("asset-" + str(i), value)
            for i, (key, value) in enumerate(saved["pins_after"].items())}
        self.result["pins_before"] = copy.deepcopy(self.result["pins_after"])
        self.result["native_trace"]["pin"] = staged("native-trace", saved["native_trace"]["pin"])
        self.result["request_trace"] = staged("request-trace", saved["request_trace"])
        self.result["observations"]["file"] = staged("observations", saved["observations"]["file"])
        self.result["capture"] = copy.deepcopy(saved["capture"])
        for stream in ("stdout", "stderr"):
            raw = (ROOT / "comparison-04-A1-baseline" / ("native." + stream + ".log")).read_bytes()
            self.assertEqual(raw, b"")
            path = self.output / ("native." + stream + ".log")
            path.write_bytes(raw)
            self.result["capture"][stream]["retained_file"] = pin(path)
        aliases = {}
        self.alias_paths = {}
        for name, section, key in (("python", "assets", "python"),
                                   ("libvulkan", "source_pins", "reused_link_input:8"),
                                   ("libgomp", "source_pins", "reused_link_input:12")):
            target = staging / (name + ".bin")
            target.write_bytes(("staged canonical " + name).encode())
            alias = staging / (name + ".alias")
            alias.symlink_to(target)
            target_pin = pin(target)
            self.plan[section][key] = target_pin
            info = alias.lstat()
            aliases[name] = {"alias_path": str(alias), "canonical_path": str(target),
                "bytes": target_pin["bytes"], "sha256": target_pin["sha256"],
                "alias_identity": [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns]}
            self.alias_paths[name] = (alias, target, section, key)
        self.plan["canonical_alias_bindings"] = aliases
        expected = {"parent": {"staged": True}, "cache_identity": {"staged": True},
                    "manifest_sha256": "f" * 64}
        for name in ("cache_helper", "gpu_helper", "package_helper", "build_result", "review", "seed_proof"):
            path = staging / (name + ".json")
            self.plan[name] = write(path, {"shader_cache": {"post": expected}} if name == "seed_proof" else {"staged": name})
        SEED_HELPER = SimpleNamespace(SEED_CACHE=self.root / "uncreated-seed",
                                    inventory=lambda *_args: copy.deepcopy(expected))
        source = self.stub.read_text().replace("def import_pinned(*args): return f.REAL_BASE",
            "def import_pinned(path,*args): return f.REAL_BASE if path is None else f.SEED_HELPER")
        source = source.replace("HEALTH=()", "HEALTH=f.OLD.HEALTH\nCACHE='mock-seed'\nCACHE_SHA='mock-seed'")
        source = source.replace("return 'fixture health isolated from guard-schema comparison'", "return f.OLD.healthy_result(result,code)")
        self.stub.write_text(source)
        self.plan["source_pins"]["comparison_adapter"] = pin(self.stub)
        self.plan_pin = write(self.plan_path, self.plan)
        self.first["plan_sha256"] = self.plan_pin["sha256"]
        self.dispatch["plan_sha256"] = self.plan_pin["sha256"]
        self.write_second()

    def full_second_call(self):
        def command(argv, **_kwargs):
            if argv[0] == "git":
                return "fixture-head"
            if argv == ["ps", "-e", "-o", "pid=,pgid="]:
                return ""
            if argv == ["pw-dump"]:
                return "[]"
            raise AssertionError("No other host commands")
        with contextlib.ExitStack() as stack:
            stack.enter_context(mock.patch.object(AUDIT, "ROOT", self.root))
            stack.enter_context(mock.patch.object(AUDIT, "PLAN", self.plan_path))
            stack.enter_context(mock.patch.object(AUDIT, "pid_absent", return_value=True))
            stack.enter_context(mock.patch.object(REAL_BASE, "ALIAS_PATHS", self.alias_paths))
            stack.enter_context(mock.patch.object(REAL_BASE, "boot_identity", return_value="fixture-boot"))
            stack.enter_context(mock.patch.object(REAL_BASE, "read_command", side_effect=command))
            stack.enter_context(mock.patch.object(REAL_BASE, "guard_identity", return_value=self.guard))
            stack.enter_context(mock.patch.object(REAL_BASE, "power_state", return_value={"ac_online": True, "lid_open": True}))
            stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
            # verify_plan_files, canonical alias checks, retained capture reader,
            # checked_json and final receipt writer are deliberately not mocked.
            AUDIT.audit(2, self.plan_pin["sha256"])

    def test_full_actual_second_audit_accepts_real_A1_zero_capture_schema(self):
        self.full_second_fixture()
        self.full_second_call()
        receipt = json.loads((self.root / "comparison-admission-06-block-2.json").read_bytes())
        self.assertEqual(receipt["status"], "passed")
        self.assertEqual(receipt["retained_player_file_checks"], 40)
        self.assertTrue(all(receipt[key] is True for key in OLD.HEALTH))
        self.assertTrue(all(row["pin"]["bytes"] == 0
            for row in receipt["native_capture_checks"][0]["captures"].values()))
        self.assertIn("3497609", receipt["exact_known_PIDs_absent"])

    def test_full_actual_second_audit_rejects_capture_counter_without_receipt(self):
        self.full_second_fixture()
        self.result["capture"]["stdout"]["bytes_received"] = 1
        self.write_second()
        with self.assertRaisesRegex(ValueError, "Native capture metadata differs"):
            self.full_second_call()
        self.assertFalse((self.root / "comparison-admission-06-block-2.json").exists())

    def test_full_actual_second_audit_still_rejects_empty_noncapture_source(self):
        self.full_second_fixture()
        row = self.result["pins_after"]["binary"]
        path = Path(row["path"])
        path.write_bytes(b"")
        row.update(pin(path))
        self.result["pins_before"] = copy.deepcopy(self.result["pins_after"])
        self.write_second()
        with self.assertRaisesRegex(RuntimeError, "Frozen plan file size/type differs"):
            self.full_second_call()
        self.assertFalse((self.root / "comparison-admission-06-block-2.json").exists())


if __name__ == "__main__":
    unittest.main()
