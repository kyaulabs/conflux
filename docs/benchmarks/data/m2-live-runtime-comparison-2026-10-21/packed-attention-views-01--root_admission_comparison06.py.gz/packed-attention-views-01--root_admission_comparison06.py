#!/usr/bin/env python3
"""Read-only host audit for the four fixed comparison blocks; dry by default."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PLAN = ROOT / "comparison-plan-06.json"
INITIAL_PIDS = (3405398, 3405430, 3405432, 3405436, 3497609, 3497641, 3497647, 3497649,
                3503229, 3503259, 3503267, 3503269)
INITIAL_GROUPS = (3405398, 3405430, 3405432, 3497609, 3497641, 3497647,
                  3503229, 3503259, 3503267)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def verified_bytes(path, expected, limit):
    require(path.resolve(strict=True) == path, "Noncanonical audit input")
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= limit, "Audit input extent/type")
        chunks, count = [], 0
        while count < before.st_size:
            data = os.read(fd, min(1048576, before.st_size - count))
            require(bool(data), "Truncated audit input")
            chunks.append(data)
            count += len(data)
        payload = b"".join(chunks)
        signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        require(signature(before) == signature(os.fstat(fd)) == signature(path.lstat()), "Audit input changed")
        actual = {"path": str(path), "bytes": count, "sha256": hashlib.sha256(payload).hexdigest()}
        require(all(actual[k] == expected[k] for k in expected), "Reviewed audit input pin differs")
        return payload, actual
    finally:
        os.close(fd)


def pid_absent(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    return False


def guard_file_metadata(guard):
    fields = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
    result = {}
    for key in ("script", "unit"):
        info = Path(guard[key]["path"]).lstat()
        result[key] = {name: getattr(info, name) for name in fields}
    return result


def same_guard(wrapper, current, prior):
    """Compare guard identity across simple and richer file-pin readers."""
    fields = {"service", "process", "script", "unit"}
    return (type(current) is dict and type(prior) is dict and set(current) == set(prior) == fields
            and current["service"] == prior["service"] and current["process"] == prior["process"]
            and all(wrapper.same_pin(current[name], prior[name]) for name in ("script", "unit")))


def initial_dispatch_anchor(wrapper, base, plan_pin, human, boot):
    dispatch, pinned = wrapper.checked_json(base, ROOT / "root-dispatch-comparison-06-audit-1.json", maximum=16384)
    sampled, deadline = dispatch.get("sampled_monotonic"), dispatch.get("original_deadline_monotonic")
    require(dispatch.get("mode") == "audit" and dispatch.get("block") == 1 and dispatch.get("new_window") is False
            and dispatch.get("plan_sha256") == plan_pin["sha256"] and dispatch.get("human_sha256") == human["pin"]["sha256"]
            and dispatch.get("boot_id") == boot
            and all(type(x) in (int, float) and math.isfinite(x) for x in (sampled, deadline)),
            "Initial dispatch identity/clock differs")
    age = sampled + 2100 - deadline
    require(0 <= sampled <= time.monotonic() and 0 <= age <= 120, "Initial dispatch was not timely")
    return {"sampled_monotonic": sampled, "age_seconds": age,
            "deadline_monotonic": deadline}, pinned


def verify_native_captures(output, result, deadline):
    """Only the two complete, explicitly owned native raw logs may be empty."""
    require(time.monotonic() < deadline and output.resolve(strict=True) == output, "Capture deadline/path differs")
    capture = result.get("capture")
    require(type(capture) is dict and set(capture) == {"stdout", "stderr"}, "Native capture set differs")
    signature = lambda s: [s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid, s.st_nlink,
                           s.st_size, s.st_mtime_ns, s.st_ctime_ns]
    parent_fd = os.open(output, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    checks = {}
    try:
        parent = os.fstat(parent_fd)
        require(stat.S_ISDIR(parent.st_mode) and parent.st_uid == os.getuid()
                and stat.S_IMODE(parent.st_mode) == 0o700
                and signature(parent) == signature(output.lstat()), "Unsafe native capture parent")
        for stream in ("stdout", "stderr"):
            row = capture[stream]
            pinned = row.get("retained_file", {}) if type(row) is dict else {}
            leaf = "native." + stream + ".log"
            path = output / leaf
            require(type(row) is dict and row.get("complete") is True
                    and type(pinned) is dict and set(pinned) == {"path", "bytes", "sha256"}
                    and pinned["path"] == str(path) and type(pinned["bytes"]) is int
                    and 0 <= pinned["bytes"] <= 2 * 1024**2
                    and type(row.get("bytes_received")) is int and row["bytes_received"] == pinned["bytes"]
                    and type(pinned["sha256"]) is str and re.fullmatch(r"[0-9a-f]{64}", pinned["sha256"])
                    and row.get("sha256_received") == pinned["sha256"], "Native capture metadata differs")
            require(time.monotonic() < deadline, "Native capture deadline exhausted")
            fd = os.open(leaf, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent_fd)
            try:
                before = os.fstat(fd)
                require(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid() and before.st_nlink == 1
                        and before.st_size == pinned["bytes"], "Unsafe native capture file/extent")
                digest, count = hashlib.sha256(), 0
                while count < before.st_size:
                    require(time.monotonic() < deadline, "Native capture deadline exhausted")
                    data = os.read(fd, min(65536, before.st_size - count))
                    require(bool(data), "Native capture truncated")
                    digest.update(data)
                    count += len(data)
                require(signature(before) == signature(os.fstat(fd))
                        == signature(os.stat(leaf, dir_fd=parent_fd, follow_symlinks=False))
                        and count == pinned["bytes"] and digest.hexdigest() == pinned["sha256"],
                        "Native capture content/identity changed")
                checks[stream] = {"pin": pinned, "observed_stable_identity": signature(before),
                                  "scope": "Present descriptor/path stability; original capture inode was not pinned"}
            finally:
                os.close(fd)
        require(signature(parent) == signature(os.fstat(parent_fd)) == signature(output.lstat())
                and time.monotonic() < deadline, "Native capture parent/deadline changed")
    finally:
        os.close(parent_fd)
    return checks


def audit(block, digest):
    began = time.monotonic()
    raw, plan_pin = verified_bytes(PLAN, {"sha256": digest}, 2 * 1024**2)
    plan = json.loads(raw)
    pins = plan["source_pins"]
    verified_bytes(Path(__file__).resolve(), pins["comparison_root_admission"], 65536)
    path = ROOT / "run_comparison_block_06.py"
    data, _ = verified_bytes(path, pins["comparison_adapter"], 262144)
    wrapper = importlib.util.module_from_spec(importlib.util.spec_from_file_location("root_comparison06", path))
    exec(compile(data, str(path), "exec"), wrapper.__dict__)
    base = wrapper.import_pinned(wrapper.BASE_FILE, wrapper.BASE_SHA, "root_comparison06_base")
    loaded, observed_pin = wrapper.load_plan(base, PLAN)
    require(loaded == plan and wrapper.same_pin(observed_pin, plan_pin), "Plan changed after reviewed-byte admission")
    human = wrapper.readiness(base, wrapper.HUMAN, plan_pin)
    boot = base.boot_identity()
    first_path = ROOT / "comparison-admission-06-block-1.json"
    anchor, dispatch_pin = initial_dispatch_anchor(wrapper, base, plan_pin, human, boot)
    if block == 1:
        require(human["age_seconds"] <= 120, "Initial physical readiness is too old")
        first = None
    else:
        first, _ = wrapper.checked_json(base, first_path)
        require(first.get("plan_sha256") == digest and first.get("human_sha256") == human["pin"]["sha256"]
                and first.get("boot_id") == boot and first.get("original_anchor") == anchor,
                "Original admission identity/dispatch anchor differs")
    require(all(type(anchor.get(k)) in (int, float) and math.isfinite(anchor[k]) for k in
                ("sampled_monotonic", "age_seconds", "deadline_monotonic")), "Invalid original anchor")
    require(0 <= anchor["age_seconds"] <= 120 and 0 <= anchor["sampled_monotonic"] <= time.monotonic()
            and abs(anchor["deadline_monotonic"] - (anchor["sampled_monotonic"] + 2100 - anchor["age_seconds"])) <= 1e-6,
            "Original clock anchor changed")
    deadline = min(anchor["deadline_monotonic"], human["sampled_monotonic"] + 2100 - human["age_seconds"], began + 90)
    require(time.monotonic() < deadline, "Original audit deadline exhausted")
    target = ROOT / (f"comparison-admission-06-block-{block}.json" if block <= 4 else "comparison-final-root-audit-06.json")
    require(not target.exists() and not target.is_symlink(), "Preserve previous root audit")
    pids, groups, prior, player_pin_count = set(INITIAL_PIDS), set(INITIAL_GROUPS), [], 0
    capture_checks = []
    for number in range(1, block):
        output = ROOT / ("comparison-" + wrapper.BLOCKS[number - 1][0])
        result, result_pin = wrapper.checked_json(base, output / "result.json")
        summary, summary_pin = wrapper.checked_json(base, output / "comparison-summary.json", maximum=131072)
        require(summary.get("block") == number and summary.get("plan_sha256") == digest
                and summary.get("human_sha256") == human["pin"]["sha256"]
                and summary.get("original_anchor") == anchor and summary.get("strict_source_closure_after") is True
                and wrapper.same_pin(summary.get("result_pin"), result_pin), "Prior summary lineage differs")
        wrapper.healthy_result(result, summary.get("exit_code"))
        require(result.get("repository_head") == plan["source_head"] == result.get("head_after")
                and result.get("comparison", {}).get("block") == number
                and result["comparison"].get("original_anchor") == anchor, "Prior runtime/source lineage differs")
        for row in result["cleanup"]["known_processes"]:
            require(type(row.get("pid")) is int and row["pid"] > 1, "Invalid known PID")
            pids.add(row["pid"])
        groups.update(int(g) for g in result["cleanup"]["owned_group_absent"])
        file_rows = [*result["pins_after"].values(), result["native_trace"]["pin"], result["request_trace"], result["observations"]["file"]]
        # Reuse the strict bounded reader for the retained player files too.
        check = {**plan, "source_pins": {**plan["source_pins"],
                 **{"retained:" + str(i): row for i, row in enumerate(file_rows)}}}
        base.verify_plan_files(check, deadline)
        captures = verify_native_captures(output, result, deadline)
        capture_checks.append({"block": number, "captures": captures})
        player_pin_count += len(file_rows) + len(captures)
        prior.append({"block": number, "result_pin": result_pin, "summary_pin": summary_pin})
    for number in (1, 2):
        selected, _ = wrapper.selected_plan(plan, number)
        base.verify_plan_files(selected, deadline)
    require(base.read_command(["git", "-C", str(base.SOURCE_ROOT), "rev-parse", "HEAD"]) == plan["source_head"], "Current source HEAD differs")
    guard = base.guard_identity(Path(plan["assets"]["guard_script"]["path"]), Path(plan["assets"]["guard_unit"]["path"]))
    rich = guard_file_metadata(guard)
    if first is not None:
        require(same_guard(wrapper, guard, first["guard_identity"]) and rich == first["guard_file_metadata"], "Guard changed since initial admission")
    for number in range(1, block):
        result, _ = wrapper.checked_json(base, ROOT / ("comparison-" + wrapper.BLOCKS[number - 1][0]) / "result.json")
        require(result["guard_before"] == result["guard_after"] and same_guard(wrapper, guard, result["guard_before"]),
                "Guard changed across prior workload")
    power = base.power_state()
    require(power.get("ac_online") is True and power.get("lid_open") is True, "Current AC/lid conditions differ")
    absent = {str(pid): pid_absent(pid) for pid in sorted(pids)}
    group_rows = base.read_command(["ps", "-e", "-o", "pid=,pgid="])
    require(len(group_rows.encode()) <= 1048576, "Process-group observation too large")
    present_groups = {int(line.split()[1]) for line in group_rows.splitlines() if line.strip()}
    group_absent = {str(group): group not in present_groups for group in sorted(groups)}
    require(all(absent.values()) and all(group_absent.values()), "Known process/group remains")
    raw_pw = base.read_command(["pw-dump"], timeout=5)
    require(len(raw_pw.encode()) <= 8 * 1024**2, "PipeWire observation too large")
    objects = json.loads(raw_pw)
    require(type(objects) is list, "Malformed PipeWire observation")
    owned = {str(pid): len(base.owned_objects(objects, pid)) for pid in sorted(pids)}
    require(not any(owned.values()), "Known owned PipeWire objects remain")
    helper = wrapper.import_pinned(wrapper.CACHE, wrapper.CACHE_SHA, "root_comparison06_cache")
    seed, _ = wrapper.checked_json(base, Path(plan["seed_proof"]["path"]), plan["seed_proof"])
    expected = seed["shader_cache"]["post"]
    actual = helper.inventory(helper.SEED_CACHE, expected["parent"], deadline, expected["cache_identity"])
    stable = lambda row: {k: v for k, v in row.items() if k not in ("capture_started_monotonic", "capture_finished_monotonic")}
    require(stable(actual) == stable(expected), "Immutable seed content/metadata differs")
    require(base.guard_identity(Path(guard["script"]["path"]), Path(guard["unit"]["path"])) == guard
            and guard_file_metadata(guard) == rich and time.monotonic() < deadline, "Guard/audit deadline changed")
    value = {"schema": 1, "status": "passed", "audit_kind": "independent_root_current_host_seed_audit",
             "block": block, "created_at_utc": datetime.now(timezone.utc).isoformat(), "plan_sha256": digest,
             "human_sha256": human["pin"]["sha256"], "source_head": plan["source_head"], "boot_id": boot,
             "original_anchor": anchor, "guard_identity": guard, "guard_file_metadata": rich,
             "initial_dispatch_pin": dispatch_pin,
             "prior_blocks": prior, "exact_known_PIDs_absent": absent, "known_groups_absent": group_absent,
             "known_owned_PipeWire_counts": owned, "power": power, "retained_player_file_checks": player_pin_count,
             "native_capture_checks": capture_checks,
             "seed_manifest_sha256": actual["manifest_sha256"], "elapsed_seconds": time.monotonic() - began,
             "physical_workload_started": False, **{key: True for key in wrapper.HEALTH}}
    data = (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()
    require(len(data) <= 131072, "Root audit output bound")
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(data)
    print(json.dumps({"status": "passed", "path": str(target), "block": block, "bytes": len(data),
                      "sha256": hashlib.sha256(data).hexdigest(), "elapsed_seconds": value["elapsed_seconds"]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit", action="store_true")
    parser.add_argument("--block", type=int, choices=range(1, 6))
    parser.add_argument("--plan-sha256")
    args = parser.parse_args()
    if not args.audit:
        print("Dry: no host queries, readiness, caches or subprocesses.")
    else:
        require(args.block is not None and type(args.plan_sha256) is str
                and re.fullmatch(r"[0-9a-f]{64}", args.plan_sha256), "Exact reviewed plan/block required")
        audit(args.block, args.plan_sha256)
