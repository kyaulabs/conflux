// SPDX-License-Identifier: AGPL-3.0-or-later
// Private experiment. Raw DRM accounting is not a GPU-idle/freshness test.
#pragma once
#include <algorithm>
#include <cerrno>
#include <charconv>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <map>
#include <limits>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <tuple>
#include <vector>
#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace conflux_drm {
constexpr std::size_t fd_bytes_max = 16384, lines_max = 128, line_max = 512;
constexpr std::size_t engines_max = 8, fd_entries_max = 128, char_candidates_max = 16;
constexpr std::size_t trace_bytes_max = 1048576, trace_rows_max = 64, row_bytes_max = 16384;
constexpr std::size_t physical_rows_max = 82, footer_reason_max = 512;
constexpr std::string_view native_mode = "passive_drm_owned_client_set_v1";
struct Error : std::runtime_error { using std::runtime_error::runtime_error; };

inline std::uint64_t number(std::string_view text) {
    std::uint64_t out{};
    const auto [end, error] = std::from_chars(text.data(), text.data() + text.size(), out);
    if (text.empty() || error != std::errc{} || end != text.data() + text.size())
        throw Error("invalid unsigned decimal");
    return out;
}
inline std::string_view trim(std::string_view value) {
    while (!value.empty() && (value.front() == ' ' || value.front() == '\t')) value.remove_prefix(1);
    while (!value.empty() && (value.back() == ' ' || value.back() == '\t')) value.remove_suffix(1);
    return value;
}
inline bool token(std::string_view value, std::size_t max = 64) {
    return !value.empty() && value.size() <= max && std::all_of(value.begin(), value.end(), [](unsigned char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
            || c == '_' || c == '-' || c == ':' || c == '.';
    });
}
inline std::string quote(std::string_view text) {
    constexpr char hex[] = "0123456789abcdef";
    std::string out = "\"";
    for (const unsigned char c : text) {
        if (c == '"' || c == '\\') { out += '\\'; out += static_cast<char>(c); }
        else if (c < 32 || c >= 127) { out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15]; }
        else out += static_cast<char>(c);
    }
    return out + '"';
}
inline std::string decimal(std::uint64_t value) { return quote(std::to_string(value)); }
inline std::uint64_t now_ns() {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count());
}

// Eight actual read attempts including EINTR and EOF; one extra byte detects overflow.
inline std::string read_bounded_fd(int fd, std::size_t maximum) {
    std::string result;
    for (int attempt = 0; attempt < 8; ++attempt) {
        char buffer[16385];
        const auto wanted = std::min(sizeof(buffer), maximum + 1 - result.size());
        const auto count = ::read(fd, buffer, wanted);
        if (count < 0) { if (errno == EINTR) continue; throw Error("bounded read failed"); }
        if (count == 0) return result;
        result.append(buffer, static_cast<std::size_t>(count));
        if (result.size() > maximum) throw Error("bounded read overflow");
    }
    throw Error("bounded read attempt limit");
}
inline std::string read_file(const std::string& path, std::size_t maximum) {
    int fd = ::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
    if (fd < 0) throw Error("could not open owned accounting file");
    try {
        const auto result = read_bounded_fd(fd, maximum);
        const int closing = fd; fd = -1;
        if (::close(closing) != 0) throw Error("accounting close failed");
        return result;
    } catch (...) { if (fd >= 0) ::close(fd); throw; }
}

struct Engine { std::uint64_t ns{}; std::uint64_t capacity = 1; };
struct Client {
    std::string driver, pdev;
    std::uint64_t client_id{}, rdev{};
    int fd = -1;
    std::map<std::string, Engine> engines;
};
inline bool same_owner(const Client& a, const Client& b) {
    return a.driver == b.driver && a.pdev == b.pdev && a.rdev == b.rdev && a.client_id == b.client_id;
}
inline bool same_shape(const Client& a, const Client& b) {
    if (a.engines.size() != b.engines.size()) return false;
    for (const auto& [name, e] : a.engines) {
        const auto other = b.engines.find(name);
        if (other == b.engines.end() || other->second.capacity != e.capacity) return false;
    }
    return true;
}
inline std::optional<Client> parse_fdinfo(std::string_view text) {
    if (text.size() > fd_bytes_max) throw Error("fdinfo byte limit");
    Client result;
    std::map<std::string, std::string> fields;
    std::size_t lines = 0;
    while (!text.empty()) {
        const auto end = text.find('\n');
        const auto line = text.substr(0, end);
        if (++lines > lines_max || line.size() > line_max) throw Error("fdinfo line limit");
        if (end == std::string_view::npos) text = {}; else text.remove_prefix(end + 1);
        const auto colon = line.find(':');
        if (colon == std::string_view::npos) continue;
        const auto key = line.substr(0, colon);
        if (!key.starts_with("drm-")) continue;
        if (!fields.emplace(std::string(key), std::string(trim(line.substr(colon + 1)))).second)
            throw Error("duplicate DRM field");
    }
    if (fields.empty()) return std::nullopt;
    if (!fields.contains("drm-driver") || !fields.contains("drm-pdev") || !fields.contains("drm-client-id"))
        throw Error("incomplete DRM owner identity");
    result.driver = fields.at("drm-driver"); result.pdev = fields.at("drm-pdev");
    if (!token(result.driver) || !token(result.pdev)) throw Error("invalid DRM owner token");
    result.client_id = number(fields.at("drm-client-id"));
    for (const auto& [key, value] : fields) {
        if (!key.starts_with("drm-engine-") || key.starts_with("drm-engine-capacity-")) continue;
        const auto name = key.substr(11);
        if (!token(name, 48) || result.engines.size() >= engines_max || !value.ends_with(" ns"))
            throw Error("unsupported engine counter");
        result.engines.emplace(name, Engine{number(std::string_view(value).substr(0, value.size() - 3)), 1});
    }
    for (const auto& [key, value] : fields) {
        if (!key.starts_with("drm-engine-capacity-")) continue;
        const auto name = key.substr(20);
        const auto found = result.engines.find(name);
        if (found == result.engines.end()) throw Error("capacity without counter");
        found->second.capacity = number(value);
        if (found->second.capacity == 0) throw Error("zero engine capacity");
    }
    if (result.engines.empty()) throw Error("no supported engine counters");
    return result;
}
inline Client select_one(std::vector<Client> candidates) {
    if (candidates.empty()) throw Error("no owned DRM client with counters");
    std::sort(candidates.begin(), candidates.end(), [](const Client& a, const Client& b) { return a.fd < b.fd; });
    const auto selected = candidates.front();
    for (const auto& candidate : candidates) {
        if (!same_owner(candidate, selected)) throw Error("unexpected additional DRM owner");
        if (!same_shape(candidate, selected)) throw Error("alias counter shape changed");
    }
    // Sequential alias reads can legitimately differ. Retain the lowest-FD raw
    // representative only, never sum counters or claim identical alias values.
    return selected;
}
inline std::uint64_t start_ticks(std::string_view stat) {
    const auto end = stat.rfind(')');
    if (end == std::string_view::npos || end + 2 >= stat.size()) throw Error("invalid process stat");
    auto tail = stat.substr(end + 2); // field3 begins after the final comm parenthesis.
    for (int field = 3; field <= 22; ++field) {
        const auto space = tail.find(' ');
        const auto value = tail.substr(0, space);
        if (field == 22) return number(value);
        if (space == std::string_view::npos) throw Error("short process stat");
        tail.remove_prefix(space + 1);
    }
    throw Error("missing process starttime");
}
struct Candidate {
    Client client;
    std::uint64_t begin_ns{}, end_ns{};
    bool fd_identity_stable = false;
};
using OwnerKey = std::tuple<std::string, std::string, std::uint64_t, std::uint64_t>;
inline OwnerKey owner_key(const Client& c) { return {c.driver, c.pdev, c.rdev, c.client_id}; }
struct Owner {
    Client representative;
    std::vector<int> alias_fds;
    std::uint64_t begin_ns{}, end_ns{};
};
inline std::vector<Owner> group_owners(const std::vector<Candidate>& candidates) {
    if (candidates.size() > char_candidates_max) throw Error("owned client set candidate limit");
    std::map<OwnerKey, std::vector<const Candidate*>> grouped;
    for (const auto& candidate : candidates) {
        if (!candidate.fd_identity_stable) throw Error("unstable owned client FD");
        if (candidate.client.driver != "i915" || candidate.client.pdev != "0000:00:02.0")
            throw Error("unexpected owned client device");
        grouped[owner_key(candidate.client)].push_back(&candidate);
    }
    std::vector<Owner> result;
    for (const auto& [key, aliases] : grouped) {
        (void)key;
        std::vector<Client> clients;
        std::vector<int> fds;
        for (const auto* alias : aliases) { clients.push_back(alias->client); fds.push_back(alias->client.fd); }
        auto selected = select_one(std::move(clients));
        std::sort(fds.begin(), fds.end());
        if (fds.front() < 0 || std::adjacent_find(fds.begin(), fds.end()) != fds.end())
            throw Error("duplicate or invalid owned alias FD");
        const auto found = std::find_if(aliases.begin(), aliases.end(), [&](const Candidate* c) { return c->client.fd == selected.fd; });
        result.push_back(Owner{std::move(selected), std::move(fds), (*found)->begin_ns, (*found)->end_ns});
    }
    return result;
}
inline bool same_owner_set(const std::vector<Owner>& a, const std::vector<Owner>& b) {
    if (a.empty() || a.size() != b.size()) return false;
    for (std::size_t i = 0; i < a.size(); ++i) {
        if (!same_owner(a[i].representative, b[i].representative)
            || a[i].representative.fd != b[i].representative.fd || a[i].alias_fds != b[i].alias_fds
            || !same_shape(a[i].representative, b[i].representative)) return false;
    }
    return true;
}
struct Snapshot {
    std::uint64_t begin_ns{}, end_ns{};
    std::vector<Owner> clients{};
    std::string reason;
    std::vector<Candidate> candidates{};
    bool fd_enumeration_complete = false, candidate_scan_complete = false;
    bool usable() const { return !clients.empty() && reason.empty() && fd_enumeration_complete && candidate_scan_complete; }
};
inline Snapshot discover(bool retain_inventory = false) {
    Snapshot out; out.begin_ns = now_ns();
    std::vector<Candidate> candidates;
    try {
        DIR* directory = ::opendir("/proc/self/fd");
        if (!directory) throw Error("owned FD directory unavailable");
        std::vector<int> fds;
        try {
            errno = 0;
            while (const auto* entry = ::readdir(directory)) {
                const std::string_view name(entry->d_name);
                if (name == "." || name == "..") continue;
                if (fds.size() >= fd_entries_max) throw Error("own FD entry limit");
                const auto fd = number(name);
                if (fd > 2147483647) throw Error("FD number overflow");
                fds.push_back(static_cast<int>(fd));
                errno = 0;
            }
            if (errno != 0) throw Error("owned FD enumeration failed");
            if (::closedir(directory) != 0) { directory = nullptr; throw Error("FD directory close failed"); }
            directory = nullptr;
            out.fd_enumeration_complete = true;
        } catch (...) { if (directory) ::closedir(directory); throw; }
        std::size_t character_count = 0;
        for (const int fd : fds) {
            const auto read_begin = now_ns();
            struct stat before{}, after{};
            // The enumeration descriptor itself has already closed.
            if (::fstat(fd, &before) != 0) { if (errno == EBADF) continue; throw Error("owned FD stat failed"); }
            if (!S_ISCHR(before.st_mode)) continue;
            if (++character_count > char_candidates_max) throw Error("character FD candidate limit");
            auto parsed = parse_fdinfo(read_file("/proc/self/fdinfo/" + std::to_string(fd), fd_bytes_max));
            const bool stable = ::fstat(fd, &after) == 0 && before.st_rdev == after.st_rdev && before.st_dev == after.st_dev
                && before.st_ino == after.st_ino && before.st_mode == after.st_mode;
            const auto read_end = now_ns();
            if (parsed) {
                parsed->fd = fd; parsed->rdev = static_cast<std::uint64_t>(before.st_rdev);
                candidates.push_back(Candidate{*parsed, read_begin, read_end, stable});
            }
            if (!stable) throw Error("owned FD changed during accounting read");
        }
        out.candidate_scan_complete = true;
    } catch (const std::exception& error) { out.reason = error.what(); }
    try {
        out.clients = group_owners(candidates);
        if (out.clients.empty() && out.reason.empty()) out.reason = "no owned DRM client with counters";
    } catch (const std::exception& error) { if (out.reason.empty()) out.reason = error.what(); }
    if (retain_inventory) out.candidates = std::move(candidates);
    out.end_ns = now_ns();
    return out;
}
inline std::string client_json(const Client& c, std::string_view alias_policy = "lowest_fd_representative_not_summed") {
    std::string out = "{\"driver\":" + quote(c.driver) + ",\"pdev\":" + quote(c.pdev)
        + ",\"rdev\":" + decimal(c.rdev) + ",\"client_id\":" + decimal(c.client_id)
        + ",\"fd\":" + decimal(static_cast<std::uint64_t>(c.fd))
        + ",\"alias_policy\":" + quote(alias_policy) + ",\"engines\":{";
    bool first = true;
    for (const auto& [name, e] : c.engines) {
        if (!first) out += ',';
        first = false;
        out += quote(name) + ":{\"ns\":" + decimal(e.ns) + ",\"capacity\":" + decimal(e.capacity) + '}';
    }
    return out + "}}";
}
inline std::string snapshot_json(const Snapshot& s) {
    if (s.reason.size() > footer_reason_max) throw Error("snapshot reason exceeds trace bound");
    std::string clients = "[";
    for (const auto& owner : s.clients) {
        if (clients.size() > 1) clients += ',';
        auto row = client_json(owner.representative, "fixed_lowest_fd_per_owner_not_summed");
        row.pop_back();
        row += ",\"alias_fds\":[";
        bool first = true;
        for (const int fd : owner.alias_fds) { if (!first) row += ','; first = false; row += decimal(static_cast<std::uint64_t>(fd)); }
        clients += row + "],\"read_begin_ns\":" + decimal(owner.begin_ns) + ",\"read_end_ns\":" + decimal(owner.end_ns) + '}';
    }
    return "{\"read_begin_ns\":" + decimal(s.begin_ns) + ",\"read_end_ns\":" + decimal(s.end_ns)
        + ",\"status\":" + quote(s.usable() ? "observed" : "inconclusive") + ",\"reason\":" + quote(s.reason)
        + ",\"fd_enumeration_complete\":" + (s.fd_enumeration_complete ? "true" : "false")
        + ",\"candidate_scan_complete\":" + (s.candidate_scan_complete ? "true" : "false")
        + ",\"clients\":" + clients + "]}";
}
struct History { std::uint64_t first{}, previous{}, high{}; bool ever_regressed = false; };
class Accounting {
    std::map<std::string, History> history_;
public:
    std::string observe(const Client& before, const Client& after) {
        if (!same_owner(before, after) || !same_shape(before, after)) throw Error("incompatible boundary clients");
        std::string out = "{";
        bool first = true;
        for (const auto& [name, a] : before.engines) {
            const auto b = after.engines.at(name).ns;
            const bool prior = history_.contains(name);
            auto& h = history_.try_emplace(name, History{a.ns, a.ns, a.ns, false}).first->second;
            const auto old_high = h.high;
            const bool regressed = a.ns < old_high || b < a.ns;
            h.ever_regressed = h.ever_regressed || regressed;
            const auto delta = [](bool valid, std::uint64_t last, std::uint64_t initial) {
                return valid ? decimal(last - initial) : std::string("null");
            };
            if (!first) out += ',';
            first = false;
            out += quote(name) + ":{\"within_call_delta_ns\":" + delta(!regressed, b, a.ns)
                + ",\"between_call_delta_ns\":" + delta(prior && a.ns >= old_high && h.previous >= old_high, a.ns, h.previous)
                + ",\"cumulative_delta_ns\":" + delta(!h.ever_regressed && b >= h.first, b, h.first)
                + ",\"high_water_ns\":" + decimal(std::max({h.high, a.ns, b}))
                + ",\"regressed_or_below_high_water\":" + (regressed ? "true" : "false") + '}';
            h.high = std::max({h.high, a.ns, b}); h.previous = b;
        }
        return out + '}';
    }
};

inline std::string owner_fields(const Client& c) {
    return "\"driver\":" + quote(c.driver) + ",\"pdev\":" + quote(c.pdev)
        + ",\"rdev\":" + decimal(c.rdev) + ",\"client_id\":" + decimal(c.client_id);
}
class ClientAccounting {
    std::map<OwnerKey, Accounting> histories_;
public:
    std::string observe(const std::vector<Owner>& before, const std::vector<Owner>& after) {
        if (!same_owner_set(before, after)) throw Error("incompatible owned client set boundaries");
        std::string out = "[";
        for (std::size_t i = 0; i < before.size(); ++i) {
            if (i) out += ',';
            const auto& c = before[i].representative;
            out += '{' + owner_fields(c) + ",\"engines\":"
                + histories_[owner_key(c)].observe(c, after[i].representative) + '}';
        }
        return out + ']';
    }
};
inline std::string request_json(std::string_view prefix, std::uint64_t id,
    std::string_view outcome, const Snapshot& before, const Snapshot& after,
    std::uint64_t call_begin, std::uint64_t call_end, std::string_view accounting) {
    return "{\"event\":\"inference\"," + std::string(prefix) + ",\"request_id\":" + decimal(id)
        + ",\"status\":" + quote(outcome) + ",\"call_begin_ns\":" + decimal(call_begin)
        + ",\"call_end_ns\":" + decimal(call_end) + ",\"before\":" + snapshot_json(before)
        + ",\"after\":" + snapshot_json(after) + ",\"accounting\":" + std::string(accounting) + '}';
}
inline std::string footer_json(std::string_view prefix, std::string_view status, std::string_view reason) {
    return "{\"event\":\"footer\"," + std::string(prefix) + ",\"status\":" + quote(status)
        + ",\"reason\":" + quote(reason.substr(0, footer_reason_max))
        + ",\"reason_bytes\":" + decimal(reason.size())
        + ",\"reason_truncated\":" + (reason.size() > footer_reason_max ? "true" : "false") + '}';
}
struct Reservation { std::size_t request_bytes{}, footer_bytes{}; };
inline Reservation reservation(std::string_view prefix, const Snapshot& setup) {
    if (!setup.usable()) throw Error("cannot reserve an incomplete client set");
    const auto maximum = std::numeric_limits<std::uint64_t>::max();
    auto bounded = setup;
    bounded.candidates.clear(); bounded.begin_ns = bounded.end_ns = maximum;
    std::string accounting = "[";
    for (auto& owner : bounded.clients) {
        owner.begin_ns = owner.end_ns = maximum;
        for (auto& [name, engine] : owner.representative.engines) { (void)name; engine.ns = maximum; }
        if (accounting.size() > 1) accounting += ',';
        accounting += '{' + owner_fields(owner.representative) + ",\"engines\":{";
        bool first = true;
        for (const auto& [name, engine] : owner.representative.engines) {
            (void)engine;
            if (!first) accounting += ',';
            first = false;
            accounting += quote(name) + ":{\"within_call_delta_ns\":" + decimal(maximum)
                + ",\"between_call_delta_ns\":" + decimal(maximum)
                + ",\"cumulative_delta_ns\":" + decimal(maximum) + ",\"high_water_ns\":" + decimal(maximum)
                + ",\"regressed_or_below_high_water\":false}";
        }
        accounting += "}}";
    }
    accounting += ']';
    const auto success = request_json(prefix, maximum, "request_error_after_call", bounded, bounded, maximum, maximum, accounting).size() + 1;
    auto error = bounded;
    error.reason = std::string(footer_reason_max, '\1');
    const auto after_error = request_json(prefix, maximum, "inconclusive", bounded, error, maximum, maximum, "null").size() + 1;
    const auto before_error = ("{\"event\":\"inference\"," + std::string(prefix) + ",\"request_id\":" + decimal(maximum)
        + ",\"status\":\"inconclusive_not_called\",\"before\":" + snapshot_json(error) + ",\"after\":null,\"accounting\":null}").size() + 1;
    // Maximum-width original reason length also covers a truncated failed footer.
    auto footer = footer_json(prefix, "failed", std::string(footer_reason_max, '\1'));
    const auto footer_size = footer.size() + 1 + 17; // 20 digits versus the three-digit512 reason length.
    const Reservation result{std::max({success, after_error + 4, before_error + 4}), footer_size};
    if (result.request_bytes > row_bytes_max || result.footer_bytes > row_bytes_max)
        throw Error("complete owned client set cannot fit trace row bound");
    return result;
}

class Sink {
    int fd_ = -1;
    std::size_t bytes_ = 0, requests_ = 0, rows_ = 0;
    bool broken_ = false;
public:
    explicit Sink(const std::filesystem::path& path) {
        if (!path.is_absolute()) throw Error("trace path must be absolute");
        const auto parent = path.parent_path();
        struct stat info{};
        if (::lstat(parent.c_str(), &info) != 0 || !S_ISDIR(info.st_mode)
            || info.st_uid != ::geteuid() || (info.st_mode & 0777) != 0700
            || std::filesystem::canonical(parent) != parent)
            throw Error("trace parent must be canonical owned0700 directory");
        fd_ = ::open(path.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
        if (fd_ < 0) throw Error("could not exclusively create trace");
    }
    Sink(const Sink&) = delete;
    Sink& operator=(const Sink&) = delete;
    ~Sink() { if (fd_ >= 0) ::close(fd_); }
    void admit_request(const Reservation& reserved) const {
        if (fd_ < 0 || broken_ || requests_ >= trace_rows_max || rows_ + 2 > physical_rows_max
            || reserved.request_bytes == 0 || reserved.footer_bytes == 0
            || reserved.request_bytes > row_bytes_max || reserved.footer_bytes > row_bytes_max
            || bytes_ + reserved.request_bytes + reserved.footer_bytes > trace_bytes_max)
            throw Error("trace request admission or reservation limit");
    }
    void row(std::string text, bool request = false) {
        text += '\n';
        if (fd_ < 0 || broken_) throw Error("trace unavailable/partial");
        if (text.size() > row_bytes_max || bytes_ + text.size() > trace_bytes_max || rows_ >= physical_rows_max
            || (request && requests_ >= trace_rows_max)) { broken_ = true; throw Error("trace cap exceeded"); }
        std::size_t offset = 0;
        for (int attempt = 0; offset < text.size() && attempt < 8; ++attempt) {
            const auto count = ::write(fd_, text.data() + offset, text.size() - offset);
            if (count < 0 && errno == EINTR) continue;
            if (count <= 0) { broken_ = true; throw Error("trace write failed"); }
            offset += static_cast<std::size_t>(count); bytes_ += static_cast<std::size_t>(count);
        }
        if (offset != text.size()) { broken_ = true; throw Error("trace write attempt limit"); }
        if (request) ++requests_;
        ++rows_;
    }
    void close_checked() {
        const int fd = fd_; fd_ = -1;
        const bool closed = fd >= 0 && ::close(fd) == 0;
        if (!closed || broken_) throw Error("trace close/partial failure");
    }
};

inline std::string inventory_summary_json(const Snapshot& s) {
    return "{\"candidate_count\":" + std::to_string(s.candidates.size())
        + ",\"fd_enumeration_complete\":" + (s.fd_enumeration_complete ? "true" : "false")
        + ",\"candidate_scan_complete\":" + (s.candidate_scan_complete ? "true" : "false") + '}';
}
inline void write_inventory(Sink& sink, const Snapshot& s, std::string_view prefix) {
    if (s.candidates.size() > char_candidates_max) throw Error("inventory candidate limit");
    for (std::size_t index = 0; index < s.candidates.size(); ++index) {
        const auto& candidate = s.candidates[index];
        if (candidate.client.fd < 0 || candidate.begin_ns < s.begin_ns
            || candidate.end_ns < candidate.begin_ns || candidate.end_ns > s.end_ns)
            throw Error("invalid inventory read bracket or FD");
        sink.row("{\"event\":\"discovery_candidate\"," + std::string(prefix)
            + ",\"ordinal\":" + std::to_string(index + 1)
            + ",\"inventory\":" + inventory_summary_json(s)
            + ",\"read_begin_ns\":" + decimal(candidate.begin_ns)
            + ",\"read_end_ns\":" + decimal(candidate.end_ns)
            + ",\"fd_identity_stable\":" + (candidate.fd_identity_stable ? "true" : "false")
            + ",\"client\":" + client_json(candidate.client, "raw_per_fd_not_selected_or_summed") + '}');
    }
}
inline std::string setup_json(std::string_view prefix, const Snapshot& s, const Reservation& reserved) {
    return "{\"event\":\"setup\"," + std::string(prefix) + ",\"backend\":\"vulkan\",\"threads\":2,\"fence_wait_mode\":\"blocking\",\"inventory\":" + inventory_summary_json(s)
        + ",\"limits\":{\"fd_bytes\":16384,\"fd_entries\":128,\"character_candidates\":16,\"engines\":8,\"requests\":64,\"physical_rows\":82,\"record_bytes\":16384,\"file_bytes\":1048576,\"footer_reason_bytes\":512}"
        + ",\"reservation\":" + (s.usable() ? "{\"request_row_max_bytes\":" + std::to_string(reserved.request_bytes)
            + ",\"footer_max_bytes\":" + std::to_string(reserved.footer_bytes) + '}' : "null")
        + ",\"snapshot\":" + snapshot_json(s) + '}';
}

class Trace {
    Sink sink_;
    std::string run_, prefix_;
    pid_t pid_;
    std::uint64_t start_;
    std::vector<Owner> owners_;
    ClientAccounting accounting_;
    Reservation reserved_;
    bool finished_ = false;
    Snapshot snapshot(bool retain_inventory = false) {
        auto result = discover(retain_inventory);
        try {
            if (::getpid() != pid_ || start_ticks(read_file("/proc/self/stat", 4096)) != start_)
                throw Error("native process lifetime changed");
            if (result.reason.empty() && !owners_.empty() && !same_owner_set(result.clients, owners_))
                throw Error("bound client set/alias/FD/engine shape changed");
        } catch (const std::exception& error) { result.reason = error.what(); }
        result.end_ns = now_ns();
        return result;
    }
public:
    Trace(const std::filesystem::path& path, std::string run)
        : sink_(path), run_(std::move(run)), pid_(::getpid()), start_(start_ticks(read_file("/proc/self/stat", 4096))) {
        if (!token(run_, 64) || run_.find_first_of(":.") != std::string::npos) throw Error("invalid trace run ID");
        prefix_ = "\"schema\":2,\"mode\":" + quote(native_mode) + ",\"run_id\":" + quote(run_) + ",\"native_pid\":" + decimal(static_cast<std::uint64_t>(pid_))
            + ",\"start_ticks\":" + decimal(start_) + ",\"freshness\":\"unknown\"";
    }
    static std::string required_env(const char* name) {
        const char* value = std::getenv(name);
        if (!value || !*value) throw Error(std::string("required private environment missing: ") + name);
        return value;
    }
    void setup(bool vulkan, int threads, bool blocking) {
        if (!vulkan || threads != 2 || !blocking) {
            sink_.row("{\"event\":\"setup\"," + prefix_ + ",\"status\":\"inconclusive\",\"reason\":\"requires Vulkan/explicit2/blocking\"}");
            throw Error("private diagnostic requires Vulkan, two threads and blocking wait");
        }
    }
    void ready() {
        const auto s = snapshot(true);
        write_inventory(sink_, s, prefix_);
        if (s.usable()) reserved_ = reservation(prefix_, s);
        sink_.row(setup_json(prefix_, s, reserved_));
        if (!s.usable()) throw Error("DRM discovery inconclusive: " + s.reason);
        owners_ = s.clients;
    }
    Snapshot before(std::uint64_t id) {
        sink_.admit_request(reserved_); // Reserve a complete known-shape row plus failed footer before separate_chunk.
        const auto s = snapshot();
        if (!s.usable()) {
            sink_.row("{\"event\":\"inference\"," + prefix_ + ",\"request_id\":" + decimal(id)
                + ",\"status\":\"inconclusive_not_called\",\"before\":" + snapshot_json(s) + ",\"after\":null,\"accounting\":null}", true);
            throw Error("pre-inference DRM observation inconclusive");
        }
        return s;
    }
    void after(std::uint64_t id, const Snapshot& before, std::uint64_t call_begin_ns,
        std::uint64_t call_end_ns, std::string_view outcome) {
        const auto after = snapshot();
        if (call_begin_ns < before.end_ns || call_end_ns < call_begin_ns || after.begin_ns < call_end_ns)
            throw Error("nonmonotonic native call boundaries");
        const auto deltas = before.usable() && after.usable() ? accounting_.observe(before.clients, after.clients) : "null";
        sink_.row(request_json(prefix_, id, after.usable() ? outcome : "inconclusive", before, after,
            call_begin_ns, call_end_ns, deltas), true);
        if (!after.usable()) throw Error("post-inference DRM observation inconclusive");
    }
    void finish(std::string_view status, std::string_view reason = {}) {
        if (finished_) return;
        sink_.row(footer_json(prefix_, status, reason));
        sink_.close_checked(); finished_ = true;
    }
};
} // namespace conflux_drm
