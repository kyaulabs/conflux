// SPDX-License-Identifier: AGPL-3.0-or-later
// CPU fixtures only. Never invoke discover(), Trace, /proc, DRM or a model.
#include "drm_client_usage.hpp"
#include <fstream>
#include <iostream>
#include <limits>
#include <functional>

namespace {
int read_fd = -1, read_mode = 0, read_calls = 0;
int write_mode = 0, write_calls = 0, last_write_fd = -1, close_fail_fd = -1;
int checks = 0;
void require(bool value, const char* message) { if (!value) throw std::runtime_error(message); ++checks; }
void fails(const std::function<void()>& work, const char* message) {
    bool caught = false;
    try { work(); } catch (const conflux_drm::Error&) { caught = true; }
    require(caught, message);
}
std::string base(std::uint64_t counter = 100) {
    return "pos:\t0\nflags:\t0100002\nmnt_id:\t5\nino:\t123\n"
        "drm-driver:\ti915\ndrm-pdev:\t0000:00:02.0\ndrm-client-id:\t7\n"
        "drm-engine-render:\t" + std::to_string(counter) + " ns\n";
}
conflux_drm::Client client(std::uint64_t ns, int fd = 5, std::uint64_t device = 226) {
    auto c = *conflux_drm::parse_fdinfo(base(ns)); c.fd = fd; c.rdev = device; return c;
}
std::string contents(const std::filesystem::path& path) {
    std::ifstream stream(path); return {std::istreambuf_iterator<char>(stream), std::istreambuf_iterator<char>()};
}
void file(const std::filesystem::path& path, const std::string& text) { std::ofstream(path, std::ios::binary) << text; }
conflux_drm::Snapshot inventory(const std::vector<conflux_drm::Client>& clients, bool complete = true) {
    conflux_drm::Snapshot result;
    result.begin_ns = 10; result.end_ns = 100;
    result.fd_enumeration_complete = true; result.candidate_scan_complete = complete;
    std::uint64_t begin = 11;
    for (const auto& c : clients) {
        result.candidates.push_back({c, begin, begin + 1, true}); begin += 2;
    }
    return result;
}
}
extern "C" ssize_t __real_read(int, void*, size_t);
extern "C" ssize_t __wrap_read(int fd, void* buffer, size_t count) {
    if (fd == read_fd) {
        ++read_calls;
        if (read_mode == 1 && read_calls == 1) { errno = EINTR; return -1; }
        if (read_mode == 2) { errno = EIO; return -1; }
        if (read_mode == 3) count = std::min<std::size_t>(count, 1);
        if (read_mode == 4) { errno = EINTR; return -1; }
    }
    return __real_read(fd, buffer, count);
}
extern "C" ssize_t __real_write(int, const void*, size_t);
extern "C" ssize_t __wrap_write(int fd, const void* buffer, size_t count) {
    last_write_fd = fd;
    if (write_mode) {
        ++write_calls;
        if (write_mode == 1 && write_calls == 1) { errno = EINTR; return -1; }
        if (write_mode == 2) count = std::min<std::size_t>(count, 1);
        if (write_mode == 3) { errno = EIO; return -1; }
    }
    return __real_write(fd, buffer, count);
}
extern "C" int __real_close(int);
extern "C" int __wrap_close(int fd) {
    const int result = __real_close(fd);
    if (fd == close_fail_fd) { close_fail_fd = -1; errno = EIO; return -1; }
    return result;
}

int main() {
    using namespace conflux_drm;
    std::filesystem::path temp;
    bool owned_temp = false;
    try {
        auto pattern = (std::filesystem::temp_directory_path() / "conflux-drm-fixture-XXXXXX").string();
        std::vector<char> name(pattern.begin(), pattern.end()); name.push_back('\0');
        if (!::mkdtemp(name.data())) throw Error("could not atomically create fixture directory");
        temp = name.data(); owned_temp = true;
        const auto c = client(std::numeric_limits<std::uint64_t>::max());
        require(c.engines.at("render").capacity == 1, "absent capacity defaults1");
        require(client_json(c).find("\"18446744073709551615\"") != std::string::npos, "uint64 stays exact JSON string");
        require(quote("a\n\"\\") == "\"a\\u000a\\\"\\\\\"", "JSON escaping");
        require(!parse_fdinfo("pos: 0\nflags: 0\n"), "nonDRM explicit absence");
        auto capacity = *parse_fdinfo(base() + "drm-engine-capacity-render: 2\n");
        require(capacity.engines.at("render").capacity == 2, "explicit capacity retained");
        for (const auto& bad : std::vector<std::string>{
            base() + "drm-client-id: 8\n", base() + "drm-engine-capacity-render: 0\n",
            base() + "drm-engine-capacity-copy: 1\n", base() + "drm-engine-copy: 1 ms\n",
            base() + "drm-engine-copy: 18446744073709551616 ns\n",
            "drm-driver: i915\n", base() + "drm-engine-copy: -1 ns\n",
            base() + "drm-engine-copy: 1.0 ns\n", base() + std::string(513, 'x') + "\n",
            std::string(16385, 'x')}) fails([&] { (void)parse_fdinfo(bad); }, "malformed/cap rejected");
        std::string lines = base(); for (int i = 0; i < 128; ++i) lines += "x\n";
        fails([&] { (void)parse_fdinfo(lines); }, "line count bounded");
        std::string engines = base(); for (int i = 0; i < 8; ++i) engines += "drm-engine-x" + std::to_string(i) + ": 0 ns\n";
        fails([&] { (void)parse_fdinfo(engines); }, "engine count bounded");
        require(select_one({client(110, 8), client(100, 5)}).engines.at("render").ns == 100, "aliases choose one never sum");
        fails([&] { (void)select_one({client(1, 5), client(1, 8, 227)}); }, "same client id different device is extra owner");
        auto other = client(1, 8); other.client_id = 8;
        fails([&] { (void)select_one({client(1), other}); }, "extra client rejected");
        fails([&] { (void)select_one({}); }, "missing client unknown");
        other = client(1, 8); other.engines.at("render").capacity = 2;
        fails([&] { (void)select_one({client(1), other}); }, "alias shape mismatch rejected");
        std::string stat = "123 (odd ) process) R";
        for (int field = 4; field <= 21; ++field) stat += " 0";
        stat += " 9007199254740993 0\n";
        require(start_ticks(stat) == 9007199254740993ULL, "stat starttime exact with parenthesized comm");
        fails([&] { (void)start_ticks("123 (x) R 0"); }, "short process stat rejected");

        const auto input = temp / "input"; file(input, std::string(16384, 'x'));
        require(read_file(input, 16384).size() == 16384, "exact byte bound includes EOF proof");
        file(input, std::string(16385, 'x'));
        fails([&] { (void)read_file(input, 16384); }, "one overflow byte rejected");
        file(input, "abcdefghi");
        for (const int mode : {1, 2, 3, 4}) {
            read_fd = ::open(input.c_str(), O_RDONLY | O_CLOEXEC); read_mode = mode; read_calls = 0;
            if (mode == 1) require(read_bounded_fd(read_fd, 32) == "abcdefghi", "EINTR retried");
            else fails([&] { (void)read_bounded_fd(read_fd, 32); }, "IO/short/EINTR attempt failure explicit");
            if (mode >= 3) require(read_calls == 8, "read attempt budget exact");
            const int closing = read_fd; read_fd = -1; ::close(closing);
        }
        read_mode = 0;
        fails([&] { (void)read_file(temp / "missing", 32); }, "missing read not zero");
        std::filesystem::create_symlink(input, temp / "link");
        fails([&] { (void)read_file(temp / "link", 32); }, "read refuses final symlink");

        Accounting a;
        auto row = a.observe(client(100), client(130));
        require(row.find("\"within_call_delta_ns\":\"30\"") != std::string::npos, "within accounting");
        require(row.find("\"between_call_delta_ns\":null") != std::string::npos, "no invented initial gap");
        row = a.observe(client(145), client(170));
        require(row.find("\"between_call_delta_ns\":\"15\"") != std::string::npos, "intervening accounting");
        require(row.find("\"cumulative_delta_ns\":\"70\"") != std::string::npos, "first last movement");
        row = a.observe(client(170), client(170));
        require(row.find("\"within_call_delta_ns\":\"0\"") != std::string::npos, "zero is raw accounted movement only");
        row = a.observe(client(160), client(165));
        require(row.find("\"within_call_delta_ns\":null") != std::string::npos
            && row.find("\"high_water_ns\":\"170\"") != std::string::npos, "regression retains highwater no clamp");
        row = a.observe(client(168), client(175));
        require(row.find("\"within_call_delta_ns\":null") != std::string::npos, "catchup pair stays unknown");
        row = a.observe(client(180), client(190));
        require(row.find("\"within_call_delta_ns\":\"10\"") != std::string::npos
            && row.find("\"between_call_delta_ns\":\"5\"") != std::string::npos
            && row.find("\"cumulative_delta_ns\":null") != std::string::npos, "clean pair rebaselines, cumulative regression remains explicit");
        other = client(200); other.engines.clear();
        fails([&] { (void)a.observe(client(190), other); }, "missing engine never zero");
        other = client(200); other.engines.at("render").capacity = 2;
        fails([&] { (void)a.observe(client(190), other); }, "capacity change incompatible");
        auto changed = inventory({client(200)});
        changed.clients = group_owners(changed.candidates); changed.reason = "bound client changed";
        require(snapshot_json(changed).find("\"status\":\"inconclusive\"") != std::string::npos
            && snapshot_json(changed).find("\"ns\":\"200\"") != std::string::npos, "invalid owner observation still retains raw data");

        const std::string prefix = "\"run_id\":\"cpu-fixture\",\"native_pid\":\"42\",\"start_ticks\":\"500\",\"freshness\":\"unknown\"";
        auto aliases = inventory({client(110, 8), client(100, 5)});
        { Sink sink(temp / "inventory-aliases"); write_inventory(sink, aliases, prefix); sink.close_checked(); }
        auto evidence = contents(temp / "inventory-aliases");
        require(std::count(evidence.begin(), evidence.end(), '\n') == 2, "all duplicate FDs retained as separate rows");
        require(evidence.find("\"fd\":\"8\"") < evidence.find("\"fd\":\"5\""), "inventory order follows read order");
        require(evidence.find("\"ordinal\":1") < evidence.find("\"ordinal\":2")
            && evidence.find("\"candidate_count\":2") != std::string::npos, "ordinals and total count retained");
        require(evidence.find("\"ns\":\"110\"") != std::string::npos && evidence.find("\"ns\":\"100\"") != std::string::npos,
            "alias sequential raw counters retained without summation");
        require(evidence.find("raw_per_fd_not_selected_or_summed") != std::string::npos
            && evidence.find("lowest_fd_representative") == std::string::npos, "raw FDs are not mislabeled selected representatives");
        require(select_one({aliases.candidates[0].client, aliases.candidates[1].client}).fd == 5,
            "inventory does not alter strict lowest-FD alias selection");
        auto distinct = inventory({client(1, 5), client(2, 8, 227)});
        { Sink sink(temp / "inventory-distinct"); write_inventory(sink, distinct, prefix); sink.close_checked(); }
        evidence = contents(temp / "inventory-distinct");
        require(evidence.find("\"rdev\":\"226\"") != std::string::npos
            && evidence.find("\"rdev\":\"227\"") != std::string::npos, "distinct node identities survive inconclusive selection");
        fails([&] { (void)select_one({distinct.candidates[0].client, distinct.candidates[1].client}); },
            "inventory does not waive distinct owner rejection");
        auto partial = inventory({client(1)}, false);
        partial.candidates.front().fd_identity_stable = false;
        { Sink sink(temp / "inventory-partial"); write_inventory(sink, partial, prefix); sink.close_checked(); }
        evidence = contents(temp / "inventory-partial");
        require(evidence.find("\"fd_enumeration_complete\":true") != std::string::npos
            && evidence.find("\"candidate_scan_complete\":false") != std::string::npos
            && evidence.find("\"fd_identity_stable\":false") != std::string::npos, "partial/error inventory never labels candidate scan complete");
        Snapshot unenumerated;
        require(inventory_summary_json(unenumerated) == "{\"candidate_count\":0,\"fd_enumeration_complete\":false,\"candidate_scan_complete\":false}",
            "incomplete FD enumeration distinct from complete empty inventory");
        std::vector<Client> maximum;
        for (std::size_t i = 0; i < char_candidates_max; ++i) {
            auto entry = client(std::numeric_limits<std::uint64_t>::max(), static_cast<int>(i + 3));
            entry.driver = std::string(64, 'd'); entry.pdev = std::string(64, 'p'); entry.engines.clear();
            for (std::size_t j = 0; j < engines_max; ++j)
                entry.engines.emplace(std::string(47, 'e') + static_cast<char>('a' + j),
                    Engine{std::numeric_limits<std::uint64_t>::max(), std::numeric_limits<std::uint64_t>::max()});
            maximum.push_back(std::move(entry));
        }
        auto full_inventory = inventory(maximum);
        { Sink sink(temp / "inventory-maximum"); write_inventory(sink, full_inventory, prefix); sink.close_checked(); }
        evidence = contents(temp / "inventory-maximum");
        require(std::count(evidence.begin(), evidence.end(), '\n') == 16 && evidence.size() < trace_bytes_max,
            "all sixteen maximal parsed candidates fit unchanged aggregate limit");
        for (std::size_t begin = 0, end; begin < evidence.size(); begin = end + 1) {
            end = evidence.find('\n', begin);
            require(end != std::string::npos && end + 1 - begin <= row_bytes_max, "each maximal candidate respects unchanged row cap");
        }
        full_inventory.candidates.push_back(full_inventory.candidates.front());
        { Sink sink(temp / "inventory-overflow"); fails([&] { write_inventory(sink, full_inventory, prefix); }, "seventeenth candidate rejects before writing"); sink.close_checked(); }
        require(contents(temp / "inventory-overflow").empty(), "overlimit inventory is not silently truncated");
        aliases.candidates.front().end_ns = aliases.end_ns + 1;
        { Sink sink(temp / "inventory-bracket"); fails([&] { write_inventory(sink, aliases, prefix); }, "invalid candidate bracket rejected"); sink.close_checked(); }
        { Sink sink(temp / "inventory-write-failure"); write_mode = 3;
            fails([&] { write_inventory(sink, distinct, prefix); }, "inventory write EIO remains failure");
            write_mode = 0; fails([&] { sink.close_checked(); }, "failed inventory write cannot complete"); }

        { Sink sink(temp / "trace"); sink.row("{\"request_id\":\"9007199254740993\",\"freshness\":\"unknown\"}", true); sink.row("{\"event\":\"footer\",\"status\":\"complete\"}"); sink.close_checked(); }
        require(contents(temp / "trace").find("9007199254740993") != std::string::npos, "exact request lineage retained");
        fails([&] { Sink sink(temp / "trace"); }, "exclusive sink refuses overwrite");
        fails([&] { Sink sink("relative"); }, "relative sink rejected");
        { Sink sink(temp / "requests"); for (int i = 0; i < 64; ++i) { sink.admit_request(Reservation{row_bytes_max, row_bytes_max}); sink.row("{}", true); } fails([&] { sink.admit_request(Reservation{row_bytes_max, row_bytes_max}); }, "request budget stops before work"); sink.close_checked(); }
        { Sink sink(temp / "large-row"); fails([&] { sink.row(std::string(row_bytes_max, 'x')); }, "row cap explicit"); fails([&] { sink.close_checked(); }, "capped sink cannot complete"); }
        { Sink sink(temp / "large-file"); for (int i = 0; i < 64; ++i) sink.row(std::string(row_bytes_max - 1, 'x')); fails([&] { sink.row("{}"); }, "aggregate cap explicit"); fails([&] { sink.close_checked(); }, "aggregate capped sink cannot complete"); }
        { Sink sink(temp / "eintr"); write_mode = 1; write_calls = 0; sink.row("{}"); write_mode = 0; sink.close_checked(); require(contents(temp / "eintr") == "{}\n", "EINTR write retained exactly"); }
        for (const int mode : {2, 3}) {
            Sink sink(temp / ("write-failure" + std::to_string(mode))); write_mode = mode; write_calls = 0;
            fails([&] { sink.row("{\"event\":\"not_complete\"}"); }, "partial write or EIO fails");
            write_mode = 0; fails([&] { sink.close_checked(); }, "partial sink cannot close complete");
        }
        { Sink sink(temp / "close-failure"); sink.row("{}"); close_fail_fd = last_write_fd; fails([&] { sink.close_checked(); }, "close EIO fails completion; process must fail"); }

        auto two = inventory({client(900, 8), client(1000, 5), client(0, 9)});
        two.candidates[2].client.client_id = 8;
        two.clients = group_owners(two.candidates);
        require(two.clients.size() == 2 && two.clients[0].alias_fds == std::vector<int>({5, 8})
            && two.clients[0].representative.fd == 5 && two.clients[1].representative.fd == 9,
            "two owners keep distinct fixed representatives and complete alias membership");
        require(two.clients[0].representative.engines.at("render").ns == 1000
            && two.clients[1].representative.engines.at("render").ns == 0, "zero client is retained, alias values not equated or summed");
        auto first_before = two.clients, first_after = two.clients;
        first_before[0].representative.engines.at("render").ns = 100;
        first_after[0].representative.engines.at("render").ns = 130;
        first_after[1].representative.engines.at("render").ns = 7;
        ClientAccounting by_owner;
        auto per_client = by_owner.observe(first_before, first_after);
        require(per_client.find("\"within_call_delta_ns\":\"30\"") != std::string::npos
            && per_client.find("\"within_call_delta_ns\":\"7\"") != std::string::npos,
            "same engine name has separate client deltas with setup busy time excluded");
        auto second_before = first_after, second_after = first_after;
        second_before[0].representative.engines.at("render").ns = 120;
        second_after[0].representative.engines.at("render").ns = 125;
        second_after[1].representative.engines.at("render").ns = 10;
        per_client = by_owner.observe(second_before, second_after);
        require(per_client.find("\"within_call_delta_ns\":null") != std::string::npos
            && per_client.find("\"within_call_delta_ns\":\"3\"") != std::string::npos,
            "one owner regression does not erase another owner delta");
        require(per_client.find("\"high_water_ns\":\"130\"") != std::string::npos
            && per_client.find("\"high_water_ns\":\"10\"") != std::string::npos, "high-water histories are independent");
        second_before = first_after; second_after = first_after;
        second_before[0].representative.engines.at("render").ns = 135;
        second_after[0].representative.engines.at("render").ns = 140;
        second_before[1].representative.engines.at("render").ns = 12;
        second_after[1].representative.engines.at("render").ns = 13;
        per_client = by_owner.observe(second_before, second_after);
        require(per_client.find("\"cumulative_delta_ns\":null") != std::string::npos
            && per_client.find("\"cumulative_delta_ns\":\"13\"") != std::string::npos,
            "regressed owner cumulative remains unknown while other owner stays cumulative");
        for (int mutation = 0; mutation < 7; ++mutation) {
            auto altered = two.clients;
            if (mutation == 0) altered.pop_back();
            if (mutation == 1) altered[0].alias_fds.push_back(20);
            if (mutation == 2) altered[0].alias_fds.erase(altered[0].alias_fds.begin());
            if (mutation == 3) altered[0].representative.fd = 8;
            if (mutation == 4) altered[0].representative.client_id += 10;
            if (mutation == 5) altered[0].representative.engines.at("render").capacity = 2;
            if (mutation == 6) altered[0].representative.rdev += 1;
            require(!same_owner_set(two.clients, altered), "full owner/alias/representative/capacity change is rejected");
            fails([&] { (void)by_owner.observe(two.clients, altered); }, "changed set never enters accounting");
        }
        auto inconsistent = two.candidates;
        inconsistent[0].client.engines.at("render").capacity = 2;
        fails([&] { (void)group_owners(inconsistent); }, "alias engine shapes must agree without equating counters");
        two.candidate_scan_complete = false;
        require(!two.usable() && snapshot_json(two).find("\"clients\":[") != std::string::npos,
            "partial scan retains observed owners but cannot be usable");
        two.candidate_scan_complete = true;
        const auto max = std::numeric_limits<std::uint64_t>::max();
        std::vector<Candidate> maximal_candidates;
        for (int index = 0; index < 16; ++index) {
            auto c = client(max, std::numeric_limits<int>::max() - 15 + index);
            c.client_id = max - static_cast<std::uint64_t>(index % 2);
            c.rdev = max; c.engines.clear();
            for (int engine = 0; engine < 8; ++engine)
                c.engines.emplace(std::string(47, 'e') + static_cast<char>('a' + engine), Engine{max, max});
            maximal_candidates.push_back({std::move(c), static_cast<std::uint64_t>(11 + index * 2),
                static_cast<std::uint64_t>(12 + index * 2), true});
        }
        Snapshot maximal;
        maximal.begin_ns = 10; maximal.end_ns = 100; maximal.fd_enumeration_complete = maximal.candidate_scan_complete = true;
        maximal.candidates = maximal_candidates; maximal.clients = group_owners(maximal_candidates);
        const std::string max_prefix = "\"schema\":2,\"mode\":" + quote(native_mode) + ",\"run_id\":" + quote(std::string(64, 'r'))
            + ",\"native_pid\":" + decimal(max) + ",\"start_ticks\":" + decimal(max) + ",\"freshness\":\"unknown\"";
        const auto reserved = reservation(max_prefix, maximal);
        require(reserved.request_bytes <= row_bytes_max && reserved.footer_bytes <= row_bytes_max,
            "two owners/eight maximal engines/sixteen aliases reserve within row bounds");
        auto invalid_before = maximal, invalid_after = maximal;
        invalid_after.reason = std::string(footer_reason_max, '\1');
        invalid_after.fd_enumeration_complete = invalid_after.candidate_scan_complete = false;
        require(request_json(max_prefix, max, "inconclusive", invalid_before, invalid_after, max, max, "null").size() + 1 <= reserved.request_bytes,
            "escaped worst reason and both longer false flags fit reservation");
        require(footer_json(max_prefix, "failed", std::string(footer_reason_max + 1, '\1')).size() + 1 <= reserved.footer_bytes,
            "bounded failed footer includes truncation and original reason length");
        std::size_t written = 0;
        { Sink sink(temp / "complete-client-set-size-proof");
            write_inventory(sink, maximal, max_prefix);
            sink.row(setup_json(max_prefix, maximal, reserved));
            ClientAccounting history;
            for (std::uint64_t id = 1; id <= 64; ++id) {
                sink.admit_request(reserved);
                auto before = maximal, after = maximal;
                before.candidates.clear(); after.candidates.clear();
                before.begin_ns = id * 1000; before.end_ns = before.begin_ns + 100;
                after.begin_ns = before.end_ns + 100; after.end_ns = after.begin_ns + 100;
                for (std::size_t index = 0; index < before.clients.size(); ++index) {
                    before.clients[index].begin_ns = before.begin_ns + 10 + index * 2;
                    before.clients[index].end_ns = before.clients[index].begin_ns + 1;
                    after.clients[index].begin_ns = after.begin_ns + 10 + index * 2;
                    after.clients[index].end_ns = after.clients[index].begin_ns + 1;
                    for (auto& [name, engine] : before.clients[index].representative.engines) {
                        engine.ns = id * 100; after.clients[index].representative.engines.at(name).ns = id * 100 + 50;
                    }
                }
                auto encoded = request_json(max_prefix, id, "returned", before, after, before.end_ns + 1,
                    after.begin_ns - 1, history.observe(before.clients, after.clients));
                require(encoded.size() + 1 <= reserved.request_bytes, "actual full-client row stays below conservative bound");
                encoded.append(reserved.request_bytes - 1 - encoded.size(), ' '); // Valid JSON trailing whitespace: exercise the whole reserved bound.
                sink.row(encoded, true);
            }
            fails([&] { sink.admit_request(reserved); }, "request65 is rejected before work");
            sink.row(footer_json(max_prefix, "complete", {})); sink.close_checked();
        }
        evidence = contents(temp / "complete-client-set-size-proof"); written = evidence.size();
        require(std::count(evidence.begin(), evidence.end(), '\n') == 82 && written <= trace_bytes_max,
            "actual64 padded maximum request rows plus16initial/setup/footer fit1MiB");
        std::cout << "client_set_size_proof request_max=" << reserved.request_bytes << " footer_max=" << reserved.footer_bytes
            << " physical_rows=82 bytes=" << written << "\n";
        { Sink sink(temp / "physical-row-cap"); for (std::size_t i = 0; i < physical_rows_max; ++i) sink.row("{}");
            fails([&] { sink.row("{}"); }, "physical row83 is rejected independently of request count");
            fails([&] { sink.close_checked(); }, "physical row exhaustion cannot complete"); }
        { Sink sink(temp / "reserve-exhaustion");
            for (int row = 0; row < 63; ++row) sink.row(std::string(row_bytes_max - 1, 'x'));
            fails([&] { sink.admit_request(Reservation{row_bytes_max, 1}); }, "next full row plus failed footer must fit before work");
            sink.close_checked(); }
        auto unsupported = maximal;
        unsupported.clients.clear();
        for (int index = 0; index < 16; ++index) {
            auto owner = maximal.clients.front(); owner.representative.client_id = static_cast<std::uint64_t>(index + 1);
            owner.alias_fds = {index + 3}; owner.representative.fd = index + 3; unsupported.clients.push_back(owner);
        }
        fails([&] { (void)reservation(max_prefix, unsupported); }, "unsupported full shape rejects whole set, never drops clients");
        std::filesystem::create_directory(temp / "public"); std::filesystem::permissions(temp / "public", std::filesystem::perms::all);
        fails([&] { Sink sink(temp / "public" / "trace"); }, "nonprivate parent rejected");
        std::filesystem::remove_all(temp); owned_temp = false;
        std::cout << checks << " CPU fixture assertions passed\n";
        return 0;
    } catch (const std::exception& error) {
        read_fd = -1; write_mode = 0; close_fail_fd = -1;
        if (owned_temp) std::filesystem::remove_all(temp);
        std::cerr << error.what() << '\n'; return 1;
    }
}
