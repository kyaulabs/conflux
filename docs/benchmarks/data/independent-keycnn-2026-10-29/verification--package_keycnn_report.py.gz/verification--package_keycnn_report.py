"""Package the closed Key-CNN screen as text evidence, excluding audio/runtimes."""
from pathlib import Path
import gzip
import hashlib
import json
from prepare_keycnn import BASE,TARGET,pin,save


def main():
    score=json.loads((TARGET/'corpus-scores-01.json').read_text())
    assert score['full_23_case_capture_per_host']and score['both_captures_closed_and_owned_resources_retired_before_scoring']
    stage=TARGET/'report-stage-01';stage.mkdir(mode=0o700)
    data=stage/'data';data.mkdir();decoded=stage/'decoded';decoded.mkdir()
    files=[];omitted=[]
    excluded={'numba-cache','__pycache__','report-stage-01','publication-01'}
    for path in sorted(TARGET.rglob('*')):
        if not path.is_file()or path.is_symlink():continue
        relative=path.relative_to(TARGET)
        if any(part in excluded for part in relative.parts):continue
        if path.name=='receive_assets.py':
            omitted.append(dict(**pin(path),reason='Embeds the retained asset manifest verbatim; the generating stage_keycnn_runtime.py is retained'))
            continue
        if path.suffix not in('.py','.json','.log','.stderr'):continue
        files.append((path,'keycnn--'+'--'.join(relative.parts)))
    for name in('prepare_keycnn.py','stage_keycnn_runtime.py','prepare_keycnn_checks.py','run_keycnn_checks.py',
        'observe_keycnn_checks.py','stage_keycnn_corpus.py','launch_keycnn_corpus.py','observe_keycnn_corpus.py','score_keycnn_corpus.py',
        'package_keycnn_report.py'):
        files.append((BASE/name,'verification--'+name))
    seen={};members=[];aliases=[];total=0
    for path,name in files:
        raw=path.read_bytes();raw.decode('utf-8');digest=hashlib.sha256(raw).hexdigest()
        assert len(raw)<=8*1024**2
        identity=(len(raw),digest)
        if identity in seen:
            aliases.append(dict(original_path=str(path),decoded_file=name,original_bytes=len(raw),
                original_sha256=digest,same_as=seen[identity]));continue
        seen[identity]=name+'.gz';total+=len(raw);assert total<=32*1024**2
        encoded=gzip.compress(raw,compresslevel=9,mtime=0)
        (data/(name+'.gz')).write_bytes(encoded);(decoded/name).write_bytes(raw)
        members.append(dict(file=name+'.gz',decoded_file=name,original_path=str(path),
            original_bytes=len(raw),original_sha256=digest,gzip_bytes=len(encoded),gzip_sha256=hashlib.sha256(encoded).hexdigest()))
    manifest=dict(schema=1,members=members,aliases=aliases,omitted=omitted,
        scope='Existing dense Winterreise recipe on the fixed new-artist sample; no music/model/runtime binaries',
        original_denominator=24,source_failure_retained='003956',candidate_promoted=False,qualified=False)
    save(data/'manifest.json',manifest)
    by_name={row['file']:row for row in members}
    for row in members:
        encoded=(data/row['file']).read_bytes();raw=gzip.decompress(encoded)
        assert len(encoded)==row['gzip_bytes']and hashlib.sha256(encoded).hexdigest()==row['gzip_sha256']
        assert len(raw)==row['original_bytes']and hashlib.sha256(raw).hexdigest()==row['original_sha256']
    for row in aliases:
        original=by_name[row['same_as']]
        assert row['original_bytes']==original['original_bytes']and row['original_sha256']==original['original_sha256']
    left=score['hosts']['laptop'];right=score['hosts']['apollo'];assert left['global_exact']==right['global_exact']
    assert left['global_exact']['matches']==11 and left['estimated_subset']['denominator']==23
    worst=max(row['maximum_mean_probability']for row in left['cases']if row['predicted_class']is not None and not row['match'])
    report=f'''# Key-CNN on the independent artist sample

The unchanged dense Winterreise recipe matched **11/24 global references**
(45.83%) on both hosts, or 11/23 decoded tracks (47.83%). The rejected MP3 remains
in the original denominator. On the same sample, the earlier whole-track
KeyFinder recipe matched 12/24. This screen provides no reason to promote the
Key-CNN candidate. The production key backend stays disabled, confidence stays
Unknown, and M2/M3 and release gates remain open.

| Recipe | Decoded sources per host | Exact global matches | Original denominator |
| --- | ---: | ---: | ---: |
| Whole-track KeyFinder | 23 | 12/23 | 12/24 |
| Dense Winterreise Key-CNN | 23 | 11/23 | 11/24 |

The [fixed selection](independent-key-2026-10-29.md) has 24 artists absent from
the prior screen, 22 selected key classes and 21 classes among the decoded
sources. Its metadata exposed reference labels, and the KeyFinder results were
known before this comparison was chosen. No Key-CNN settings were fitted to this
sample. The original source `003956` remained rejected and was neither converted
nor replaced. Every successful capture decoded the original source again and
matched its complete stereo 48 kHz float32 frame count and PCM SHA-256.

This is the existing `winterreise_n_fold16` model, SHA-256
`b425f2e8d5165415c8863b6666aa82d7573121ee675bd2fd8b59d7594f5f11e9`,
with legacy CQT, dense hop-8 contexts and boundary zero padding. One global
decision uses the arithmetic mean of every raw posterior row with float64
`math.fsum`; quiet rows remain included, all-zero feature populations are
Unknown, and ties choose the lowest class index. The publisher's global defaults
use hop 30 without boundary padding. That alternate context recipe was not part
of this capture. Neither this result nor the separate DeepSpec experiment
qualifies every Key-CNN model or explains these errors.

The weight set's [earlier numerical reference](keycnn-winterreise-reference-2026-10-28.md)
passed 99/99 generated layer/output comparisons against TensorFlow 1.15.2.
For this new host pairing, the existing Python 3.10.22/CQT environment was copied
into CONFLUX's private Apollo directory. All 8,585 regular files retained their
hashes; 1,054 internal symlinks were rebound within that copied tree. No package
version was changed or newly installed, and no duplicate runtime archive was
stored on the laptop. Model loading reads only the audited raw float tensors;
the HDF5 file is hashed without deserializing model classes.

Both copied-environment checks passed the frozen generated fixtures:
normalization was bit-exact, six CQT cases differed by at most
5.7731597281e-15, and three posterior batching checks differed from the retained
fixtures by at most 3.2782554626e-7. These checks use the original combined
posterior tolerance `atol=2e-6, rtol=2e-6`; they do not repeat the full 99-layer
reference or establish musical accuracy. The initial asset freeze rejected the
existing Python symlink as a regular file. Resolving its internal target and
checking the original binary hash fixed that setup check before inference.

Both full music captures completed all 23 usable sources, with no inference
failure or altered PCM. All 23 global decisions agreed across hosts. The largest
posterior difference was 2.0861625671e-6, with zero elements outside the frozen
combined absolute/relative bound. Emitted prediction files are not claimed
byte-identical. Both captures and owned resources closed before the scorer read
the reference mapping. No reference file was mounted into the classifier.

An incorrect global estimate had a maximum mean posterior of {worst:.3f}.
The recorded probability bins are descriptive; no confidence threshold was
fitted. These song-level labels supply no local key-change truth, confidence
calibration or proof of upstream training independence.

Twenty-three protocol and process-lifecycle regressions passed on each host
before music classification. The batches used one CPU and 3 GiB limits;
the retained execution durations were 1,206.336 seconds on the laptop and
1,231.565 seconds on Apollo. Those durations include preparation and are not
live-stem latency measurements. All source/runtime pins remained unchanged.
Both units have empty original cgroups, all owned containers are removed, and
no PCM spool remains. The tests made no player, sound-output, GPU, power-policy,
OneDrive or desktop-inhibitor changes. They consume no physical client-test
readiness and close no sustained audio/UI, cancellation or release gate.

The [evidence manifest](data/independent-keycnn-2026-10-29/manifest.json) binds
{len(members)} unique compressed text members and {len(aliases)} byte-identical
aliases, including complete per-case predictions, source/PCM and runtime pins,
generated checks, failed setup records, frozen code and owned cleanup. Audio,
weights, numeric arrays, installed runtimes, native binaries and JIT caches are
excluded. The receiver with an embedded manifest is represented by its hash,
the complete manifest and its generating script.
'''
    (stage/'report.md').write_text(report)
    save(stage/'verification-01.json',dict(unique_members=len(members),aliases=len(aliases),
        original_text_records=len(files),all_member_and_alias_hashes_verified=True,
        decoded_unique_bytes=total,gzip_bytes=sum(row['gzip_bytes']for row in members),
        audio_models_binaries_or_runtimes_included=False))
    print(json.dumps(dict(unique_members=len(members),aliases=len(aliases),decoded_bytes=total,
        gzip_bytes=sum(row['gzip_bytes']for row in members))))


if __name__=='__main__':main()
