BASE='/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/keycnn-01/laptop'

from pathlib import Path
import json,os
base=Path(BASE)
(base/'entry-binding.json').write_text(json.dumps(dict(pid=os.getpid(),invocation=os.environ['INVOCATION_ID'],cgroup=Path('/proc/self/cgroup').read_text().strip()),indent=2)+chr(10))
os.execv('/usr/bin/python3.14',['python3.14','-B',str(base/'run_corpus.py'),'--owned','--plan',str(base/'music-plan-01.json'),'--output',str(base/'output-01')])
