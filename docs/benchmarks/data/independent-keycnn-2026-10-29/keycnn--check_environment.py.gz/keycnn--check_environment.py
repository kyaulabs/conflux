"""Generated CQT and posterior compatibility only; no music or sound output."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import time
import warnings

DATA=Path('/home/kyau/projects/kyaulabs/conflux/build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/model-data-audit-01')
for variable in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[variable]='1'
sys.dont_write_bytecode=True


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--inputs',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    assert not args.output.exists();args.output.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    os.environ['NUMBA_CACHE_DIR']=str(args.output.parent/'numba-cache')
    os.environ.pop('LIBROSA_CACHE_DIR',None)
    resource.setrlimit(resource.RLIMIT_CPU,(100,100))
    resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
    first=time.monotonic();plan=json.loads((args.inputs/'plan.json').read_text())
    feature=DATA/'feature-compatibility-01'
    sources=json.loads((feature/'source-downloads-01.json').read_text())
    for package in sources['source_packages']:
        for row in package['files']:
            raw=Path(row['path']).read_bytes()
            assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
    import numba
    sys.modules['numba.decorators']=numba
    sys.path[:0]=[str(feature/'legacy-source/librosa'),str(feature/'legacy-source/resampy')]
    with warnings.catch_warnings(record=True)as recorded:
        warnings.simplefilter('always')
        import librosa
        import numpy as np
        import resampy
        import scipy
        versions=dict(python='.'.join(str(x)for x in sys.version_info[:3]),
            numpy=np.__version__,scipy=scipy.__version__,numba=numba.__version__,
            librosa=librosa.__version__,resampy=resampy.__version__)
        assert versions==dict(python='3.10.22',numpy='1.23.5',scipy='1.10.1',numba='0.57.1',librosa='0.6.2',resampy='0.2.2')
        module_path=DATA/'numeric-forward-03/keycnn_numeric.py'
        spec=importlib.util.spec_from_file_location('fixed_numeric_candidate',module_path)
        numeric=importlib.util.module_from_spec(spec);spec.loader.exec_module(numeric)
        assert numeric.MODEL_SHA=='b425f2e8d5165415c8863b6666aa82d7573121ee675bd2fd8b59d7594f5f11e9'
        arrays={}
        for row in plan['inputs']:
            path=args.inputs/row['file'];raw=path.read_bytes()
            assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
            arrays[row['name']]=np.frombuffer(raw,dtype='<f8'if row['name']=='features'else'<f4').reshape(row['shape'])
        normalized=numeric.normalize(arrays['features'])
        assert np.array_equal(normalized,arrays['normalized_input'])
        weights=numeric.weights();posterior=[]
        for batch in(1,2,4):
            value=numeric.predict(arrays['features'],weights,batch_size=batch)
            passed=bool(np.allclose(value,arrays['activation'],atol=plan['posterior_atol'],rtol=plan['posterior_rtol']))
            classes=value.argmax(axis=1).tolist();assert classes==arrays['activation'].argmax(axis=1).tolist()
            posterior.append(dict(batch=batch,passed=passed,top_one=classes,
                maximum_absolute_difference=float(np.max(np.abs(value-arrays['activation'])))))
        signal_file=args.inputs/'generated_signals.py'
        assert hashlib.sha256(signal_file.read_bytes()).hexdigest()==plan['generated_signal_definition']['sha256']
        spec=importlib.util.spec_from_file_location('frozen_generated_signals',signal_file)
        generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
        expected_file=args.inputs/'legacy-features-01.npz'
        assert hashlib.sha256(expected_file.read_bytes()).hexdigest()==plan['legacy_CQT']['sha256']
        cqts=[]
        with np.load(expected_file,allow_pickle=False)as expected:
            for name,signal in generator.fixtures().items():
                value=np.abs(librosa.cqt(signal,sr=22050,hop_length=4096,
                    fmin=librosa.note_to_hz('E1'),n_bins=168,bins_per_octave=24))
                assert value.shape==expected[name].shape and np.isfinite(value).all()
                passed=bool(np.allclose(value,expected[name],atol=plan['CQT_atol'],rtol=plan['CQT_rtol']))
                cqts.append(dict(name=name,passed=passed,shape=list(value.shape),
                    maximum_absolute_difference=float(np.max(np.abs(value-expected[name])))))
    counts=Counter((row.category.__name__,str(row.message),row.filename,row.lineno)for row in recorded)
    result=dict(schema=1,versions=versions,normalization_bit_exact=True,posteriors=posterior,CQT=cqts,
        warning_count=len(recorded),warnings=[dict(category=k[0],message=k[1],filename=k[2],line=k[3],count=v)for k,v in counts.items()],
        passed=all(row['passed']for row in posterior+cqts),elapsed_seconds=time.monotonic()-first,
        generated_only=True,music_sources_opened=False,GPU_or_audio_started=False,
        model_or_tolerance_changed=False,physical_readiness_consumed=False,qualified=False)
    encoded=(json.dumps(result,indent=2,allow_nan=False)+'\n').encode();assert len(encoded)<=262144
    with args.output.open('xb')as stream:stream.write(encoded)
    print(json.dumps({key:result[key]for key in('passed','elapsed_seconds','normalization_bit_exact')}))
    return 0 if result['passed']else 1


if __name__=='__main__':raise SystemExit(main())
