"""Fixed CPU-only music captures; reference labels are never opened here."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
import protocol
from aggregate import global_class
RECIPE=protocol.RECIPE


class ChildCleanupError(RuntimeError):pass


def strict_json(raw):
    def pairs(items):
        result={}
        for key,value in items:
            if key in result:raise ValueError('Duplicate JSON field')
            result[key]=value
        return result
    return json.loads(raw,object_pairs_hook=pairs,
        parse_constant=lambda value:(_ for _ in()).throw(ValueError('Nonfinite JSON value')))


def save(path,value):
    with path.open('x')as stream:stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def verify(row):
    path=Path(row['path'])
    assert path.is_file()and not path.is_symlink()and path.stat().st_size==row['bytes']
    with path.open('rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']


def verify_assets(plan):
    manifest=strict_json(Path(plan['asset_manifest']).read_bytes())
    root=Path(manifest['container_asset_root'])
    for row in manifest['files']:verify(dict(row,path=str(root/row['file'])))
    for row in manifest['links']:
        assert os.readlink(root/row['file'])==row['original_target'if plan['host']=='laptop'else'target']


def reap(children):
    failures=[]
    for child in children:
        if child is None or child.poll()is not None:continue
        try:os.killpg(child.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            try:child.wait(timeout=2)
            except subprocess.TimeoutExpired:failures.append(child.pid)
    if failures:raise ChildCleanupError('Owned pipeline reap not proven: '+str(failures))


def predict(plan,case,output):
    identifier=case['id'];assert re.fullmatch('[0-9]{6}',identifier)
    spool=output/('spool-'+identifier);spool.mkdir(mode=0o700)
    metadata_path=output/(identifier+'-source.json')
    prediction_path=output/(identifier+'-prediction.json')
    errors_path=output/(identifier+'-worker.stderr')
    producer=consumer=None;first=time.monotonic()
    try:
        with metadata_path.open('xb')as metadata,prediction_path.open('xb')as prediction,errors_path.open('xb')as errors:
            producer=subprocess.Popen([plan['preparer']['path'],identifier,str(spool),'--pcm'],
                stdout=subprocess.PIPE,stderr=metadata,start_new_session=True)
            consumer=subprocess.Popen([plan['python'],'-I','-B',plan['worker'],'--case',identifier,
                '--frames',str(case['prepared_frames'])],stdin=producer.stdout,
                stdout=prediction,stderr=errors,start_new_session=True)
            producer.stdout.close()
            while producer.poll()is None or consumer.poll()is None:
                if time.monotonic()-first>=160:raise TimeoutError('Original 160-second case bound exhausted')
                if (os.fstat(prediction.fileno()).st_size>524288 or os.fstat(metadata.fileno()).st_size>4096 or
                    os.fstat(errors.fileno()).st_size>4096):raise ValueError('Bounded capture exceeded')
                time.sleep(.05)
            if producer.wait()!=0 or consumer.wait()!=0:raise ValueError('Preparation or model worker failed')
        assert prediction_path.stat().st_size<=524288 and metadata_path.stat().st_size<=4096 and errors_path.stat().st_size<=4096
        assert not list(spool.iterdir()),'Anonymous source spool contains artifacts'
        source=strict_json(metadata_path.read_bytes());value=strict_json(prediction_path.read_bytes())
        assert type(source['schema'])is int and source['schema']==1
        protocol.validate_prediction(value,source,case)
        key,means=global_class(value['raw_predictions'])
        return dict(id=identifier,status='PredictionCaptured',complete=True,model_started=True,
            predicted_class=key,mean_probabilities=means,confidence='Unknown',source=source,
            prediction_file=prediction_path.name,prediction_sha256=hashlib.sha256(prediction_path.read_bytes()).hexdigest(),
            producer_reaped=producer.poll()is not None,consumer_reaped=consumer.poll()is not None,
            spool_empty=True,elapsed_seconds=time.monotonic()-first)
    finally:
        reap((producer,consumer))
        if spool.exists()and not list(spool.iterdir()):spool.rmdir()


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--owned',action='store_true')
    parser.add_argument('--plan',type=Path);parser.add_argument('--output',type=Path);args=parser.parse_args()
    if not args.owned:
        print(json.dumps(dict(unarmed=True,source_opened=False,model_started=False)));return 0
    plan=strict_json(args.plan.read_bytes())
    assert plan['status']=='frozen_CPU_correctness_only'and plan['physical_readiness_required']is False and plan['recipe']==RECIPE
    if plan['host']=='laptop':
        assert any(row.endswith('/'+plan['unit'])for row in Path('/proc/self/cgroup').read_text().splitlines())
    else:
        assert plan['host']=='apollo'and os.environ.get('CONFLUX_PRIVATE_KEYCNN')=='1'
        assert not any(Path(path).exists()for path in('/dev/nvidia0','/dev/dri','/dev/snd'))
    assert len(plan['cases'])==24 and len({row['id']for row in plan['cases']})==24
    assert all(re.fullmatch('[0-9]{6}',row['id'])for row in plan['cases'])
    first=time.monotonic();deadline=first+plan.get('inner_total_seconds',3900)
    for row in plan['input_pins']:verify(row)
    if'asset_manifest'in plan:verify_assets(plan)
    args.output.mkdir(mode=0o700,exist_ok=True)
    assert not any(args.output.glob('*-capture.json'))
    captures=[]
    for case in plan['cases']:
        if case['preparation_status']!='PreparedMetadataMeasured':
            row=dict(id=case['id'],status='SourcePreparationFailed',complete=False,model_started=False,error=case['error'])
        elif time.monotonic()+160>=deadline:
            row=dict(id=case['id'],status='NotRunBudget',complete=False,model_started=False)
        else:
            try:row=predict(plan,case,args.output)
            except ChildCleanupError:raise
            except Exception as error:
                row=dict(id=case['id'],status='InferenceFailed',complete=False,model_started=None,
                    error=dict(type=type(error).__name__,message=str(error)[:1200]))
        save(args.output/(case['id']+'-capture.json'),row);captures.append(row)
        print(json.dumps(dict(id=case['id'],status=row['status'])),flush=True)
    closed=args.output/'predictions-before-scoring.json';save(closed,captures)
    for row in plan['input_pins']:verify(row)
    if'asset_manifest'in plan:verify_assets(plan)
    artifacts=sorted(str(path.relative_to(args.output))for directory in args.output.glob('spool-*')
        if directory.is_dir()for path in directory.rglob('*')if path.is_file()or path.is_symlink())
    result=dict(schema=1,completed_captures=24,fixed_denominator=24,
        inferred=sum(row['complete']for row in captures),PCM_persisted=bool(artifacts),spool_artifacts=artifacts,
        all_inferable_sources_completed=not artifacts and all(row['complete']for case,row in zip(plan['cases'],captures,strict=True)
            if case['preparation_status']=='PreparedMetadataMeasured'),
        closed_capture_sha256=hashlib.sha256(closed.read_bytes()).hexdigest(),
        reference_labels_opened=False,confidence='Unknown',qualified=False,input_pins_unchanged=True,
        elapsed_seconds=time.monotonic()-first,GPU_or_audio_opened=False,hardware_or_latency_qualification=False)
    assert time.monotonic()<deadline,'Original inner CPU-capture deadline exhausted'
    save(args.output/'prediction-receipt.json',result);print(json.dumps(result),flush=True)
    return 0 if result['all_inferable_sources_completed']else 1


if __name__=='__main__':raise SystemExit(main())
