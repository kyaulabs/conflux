"""Freeze generated portability checks before either CPU environment runs them."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
from prepare_keycnn import TARGET,DATA,ROOT,pin,save


def main():
    folder=TARGET/'compatibility-01';folder.mkdir(mode=0o700)
    original=ROOT/'build/m2-winterreise-tf115-reference-01/input'
    specification=json.loads((original/'fixtures.json').read_text())
    inputs=[]
    selected=[dict(name='features',**specification['features'])]
    selected += [row for row in specification['expected']if row['name']in('normalized_input','activation')]
    assert len(selected)==3
    for row in selected:
        path=original/row['file'];expected=pin(path)
        assert expected['bytes']==row['bytes']and expected['sha256']==row['sha256']
        target=folder/row['file'];target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,target);inputs.append(dict(row,path=str(target)))
    feature=DATA/'feature-compatibility-01'
    expected=json.loads((feature/'legacy-features-01.json').read_text())
    raw=feature/'legacy-features-01.npz'
    assert pin(raw)['sha256']==expected['feature_sha256']
    shutil.copyfile(raw,folder/raw.name)
    source=(feature/'feature_worker.py').read_text();tree=ast.parse(source)
    function=next(node for node in tree.body if isinstance(node,ast.FunctionDef)and node.name=='fixtures')
    (folder/'generated_signals.py').write_text(ast.get_source_segment(source,function)+'\n')
    manifest=dict(schema=1,inputs=inputs,legacy_CQT=pin(folder/raw.name),
        generated_signal_definition=pin(folder/'generated_signals.py'),
        CQT_atol=1e-6,CQT_rtol=1e-6,posterior_atol=2e-6,posterior_rtol=2e-6,
        normalization_bit_exact=True,declared_before_new_host_results=True,
        old_numeric_reference_input=pin(original/'fixtures.json'),music_or_reference_labels_used=False)
    save(folder/'plan.json',manifest)
    print(json.dumps(dict(frozen=True,generated_signals=6,numeric_windows=4,music_started=False)))


if __name__=='__main__':main()
