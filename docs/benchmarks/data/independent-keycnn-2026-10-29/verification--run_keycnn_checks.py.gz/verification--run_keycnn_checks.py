"""Run generated compatibility checks concurrently, bounded to four minutes."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import time
from prepare_keycnn import TARGET,DATA,pin,save
from stage_keycnn_runtime import REMOTE,SSH

IMAGE='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
LOCAL_UNIT='conflux-keycnn-environment-laptop-20261029-01.service'
REMOTE_UNIT='conflux-keycnn-environment-apollo-20261029-01.service'


def main():
    assert json.loads((TARGET/'runtime-transfer-complete-01.json').read_text())['remote']['all_hashes_verified']
    assert not(TARGET/'compatibility-reservation-01.json').exists()
    inputs=TARGET/'compatibility-01';output=TARGET/'compatibility-laptop-01';output.mkdir(mode=0o700)
    files={}
    for path in sorted(inputs.rglob('*')):
        if path.is_file():files[str(path.relative_to(inputs))]=base64.b64encode(path.read_bytes()).decode()
    program=(TARGET/'check_environment.py').read_text()
    local_entry='OUTPUT='+repr(str(output))+'\nPYTHON='+repr(str(DATA/'feature-compatibility-01/venv/bin/python'))+'\nCHECK='+repr(str(TARGET/'check_environment.py'))+'\nINPUTS='+repr(str(inputs))+'\n'+r'''
from pathlib import Path
import json,os
output=Path(OUTPUT);group=Path('/proc/self/cgroup').read_text().strip()
(output/'entry-binding.json').write_text(json.dumps(dict(pid=os.getpid(),invocation=os.environ['INVOCATION_ID'],cgroup=group),indent=2)+chr(10))
os.execv(PYTHON,[PYTHON,'-I','-B',CHECK,'--inputs',INPUTS,'--output',str(output/'result.json')])
'''
    (TARGET/'check_local_entry.py').write_text(local_entry)
    for name in('unit.stdout.log','unit.stderr.log'):(output/name).touch(mode=0o600,exist_ok=False)
    setup='BASE='+repr(REMOTE)+'\nFILES='+repr(files)+'\nPROGRAM='+repr(program)+'\nASSETS='+repr(str(DATA))+'\nIMAGE='+repr(IMAGE)+'\n'+r'''
from pathlib import Path
import base64,hashlib,json
base=Path(BASE);assert json.loads((base/'asset-transfer-complete-01.json').read_text())['all_hashes_verified']
operations=base/'compatibility-01';assert not operations.exists();operations.mkdir(mode=0o700)
for name,encoded in FILES.items():
 path=operations/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(base64.b64decode(encoded,validate=True))
(operations/'check_environment.py').write_text(PROGRAM)
output=base/'compatibility-output-01';output.mkdir(mode=0o700)
for name in('unit.stdout.log','unit.stderr.log'):(output/name).touch(mode=0o600,exist_ok=False)
owner=r"""
from pathlib import Path
import json,os,signal,subprocess,time
base=Path(BASE);output=base/'compatibility-output-01'
(output/'entry-binding.json').write_text(json.dumps(dict(pid=os.getpid(),invocation=os.environ['INVOCATION_ID'],cgroup=Path('/proc/self/cgroup').read_text().strip()),indent=2)+chr(10))
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
name='conflux-keycnn-environment-20261029-01';label='keycnn-environment-20261029-01'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
def interrupted(number,frame):raise InterruptedError('Owned generated check stopped')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
python=ASSETS+'/feature-compatibility-01/venv/bin/python'
command=D+['run','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL',
 '--security-opt=no-new-privileges:true','--user=1000:1000','--memory=3g','--cpus=1','--pids-limit=128',
 '--label','org.kyaulabs.conflux.run='+label,'--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777',
 '--mount','type=bind,src='+str(base/'assets')+',dst='+ASSETS+',readonly',
 '--mount','type=bind,src='+str(base/'compatibility-01')+',dst=/operations,readonly',
 '--mount','type=bind,src='+str(output)+',dst=/output',IMAGE,
 python,'-I','-B','/operations/check_environment.py','--inputs','/operations','--output','/output/result.json']
result=None;error=None;first=time.monotonic()
try:result=subprocess.run(command,timeout=150)
except BaseException as exception:error=dict(type=type(exception).__name__,message=str(exception)[:1000])
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  container=json.loads(found.stdout)[0]
  assert container['Image']==IMAGE and container['Config']['Labels']['org.kyaulabs.conflux.run']==label
  subprocess.run(D+['rm','--force',container['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
 (output/'container-closed.json').write_text(json.dumps(dict(container_absent=True,exit=None if result is None else result.returncode,error=error,elapsed_seconds=time.monotonic()-first),indent=2)+chr(10))
raise SystemExit(0 if result is not None and result.returncode==0 and error is None else 1)
"""
text='BASE='+repr(BASE)+'\nASSETS='+repr(ASSETS)+'\nIMAGE='+repr(IMAGE)+'\n'+owner
(base/'check_environment_owner.py').write_text(text);compile(text,'keycnn-environment-owner','exec')
print(json.dumps(dict(staged=True,generated_checks_started=False)))
'''
    result=subprocess.run(SSH+['python3 -'],input=setup,capture_output=True,text=True,timeout=30)
    (TARGET/'compatibility-setup.stdout.log').write_text(result.stdout)
    (TARGET/'compatibility-setup.stderr.log').write_text(result.stderr);result.check_returncode()
    state=subprocess.check_output(['systemctl','--user','show',LOCAL_UNIT,'--property=LoadState,MainPID'],text=True,timeout=5)
    assert'LoadState=not-found'in state and'MainPID=0'in state
    began=time.monotonic()
    save(TARGET/'compatibility-reservation-01.json',dict(utc=datetime.now(timezone.utc).isoformat(),
        started_monotonic=began,deadline_monotonic=began+240,physical_readiness_consumed=False,
        music_sources_opened=False,model_settings_or_tolerance_changed=False))
    local=['systemd-run','--user','--unit='+LOCAL_UNIT,'--property=Type=exec','--property=RemainAfterExit=yes',
        '--property=Restart=no','--property=KillMode=control-group','--property=RuntimeMaxSec=180s',
        '--property=TimeoutStopSec=15s','--property=CPUQuota=100%','--property=MemoryMax=3G',
        '--property=TasksMax=128','--property=Nice=19','--property=UMask=0077',
        '--property=StandardOutput=append:'+str(output/'unit.stdout.log'),
        '--property=StandardError=append:'+str(output/'unit.stderr.log'),
        '/usr/bin/python3.14','-B',str(TARGET/'check_local_entry.py')]
    remote='BASE='+repr(REMOTE)+'\nUNIT='+repr(REMOTE_UNIT)+'\n'+r'''
from pathlib import Path
import json,subprocess
base=Path(BASE);output=base/'compatibility-output-01'
state=subprocess.check_output(['systemctl','show',UNIT,'--property=LoadState,MainPID'],text=True,timeout=5)
assert'LoadState=not-found'in state and'MainPID=0'in state
command=['sudo','-n','systemd-run','--unit='+UNIT,'--uid=1000','--gid=1000',
 '--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no','--property=KillMode=control-group',
 '--property=RuntimeMaxSec=180s','--property=TimeoutStopSec=20s','--property=MemoryMax=4G',
 '--property=TasksMax=256','--property=Nice=19','--property=UMask=0077',
 '--property=StandardOutput=append:'+str(output/'unit.stdout.log'),
 '--property=StandardError=append:'+str(output/'unit.stderr.log'),'/usr/bin/python3','-B',str(base/'check_environment_owner.py')]
r=subprocess.run(command,capture_output=True,text=True,timeout=15)
print(json.dumps(dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)));r.check_returncode()
'''
    def dispatch(host,command,data=None):
        r=subprocess.run(command,input=data,capture_output=True,text=True,timeout=30)
        row=dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
        save(TARGET/('compatibility-'+host+'-dispatch-01.json'),row);return row
    with ThreadPoolExecutor(max_workers=2)as pool:
        left=pool.submit(dispatch,'laptop',local);right=pool.submit(dispatch,'apollo',SSH+['python3 -'],remote)
        results=dict(laptop=left.result(),apollo=right.result())
    save(TARGET/'compatibility-dispatched-01.json',dict(hosts=results,concurrent=True))
    print(json.dumps(dict(hosts={host:row['exit']for host,row in results.items()},generated_only=True)))
    assert all(row['exit']==0 for row in results.values())


if __name__=='__main__':main()
