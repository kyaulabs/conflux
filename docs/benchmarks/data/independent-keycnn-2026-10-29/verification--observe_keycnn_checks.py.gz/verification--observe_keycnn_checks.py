"""Observe generated checks and retire their exact units and private container."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import inspect
import json
from pathlib import Path
import subprocess
import time
from prepare_keycnn import TARGET,save
from stage_keycnn_runtime import REMOTE,SSH


def observe(base,local,expired):
    unit='conflux-keycnn-environment-'+('laptop'if local else'apollo')+'-20261029-01.service'
    output=base/('compatibility-laptop-01'if local else'compatibility-output-01')
    prefix=['systemctl']+(['--user']if local else[])
    def state():
        raw=subprocess.check_output(prefix+['show',unit,
            '--property=LoadState,MainPID,InvocationID,ControlGroup,ActiveState,SubState,Result,ExecMainStatus'],text=True,timeout=5)
        return dict(line.split('=',1)for line in raw.splitlines()if'='in line)
    current=state();closed_path=output/'unit-closed.json'
    if closed_path.exists():
        closed=json.loads(closed_path.read_text())
        assert current['LoadState']=='not-found'and current['MainPID']=='0'
    elif current['MainPID']=='0'or expired:
        binding=json.loads((output/'entry-binding.json').read_text())
        assert current['InvocationID']==binding['invocation']and current['LoadState']=='loaded'
        command=prefix+['stop',unit]
        if not local:command=['sudo','-n']+command
        subprocess.run(command,check=True,capture_output=True,timeout=25)
        after=state()
        if after['LoadState']!='not-found':
            assert after['MainPID']=='0'
            command=prefix+['reset-failed',unit]
            if not local:command=['sudo','-n']+command
            subprocess.run(command,check=True,capture_output=True,timeout=5);after=state()
        assert after['LoadState']=='not-found'and after['MainPID']=='0'
        group=binding['cgroup'].split(':',2)[2];assert group.endswith('/'+unit)
        cgroup=Path('/sys/fs/cgroup'+group)
        assert not cgroup.exists()or not any(path.read_text().strip()for path in cgroup.rglob('cgroup.procs'))
        closed=dict(before_stop=current,after_stop=after,binding=binding,
            original_cgroup_absent_or_empty=True,expired=expired)
        if not local:
            D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
            name='conflux-keycnn-environment-20261029-01'
            found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
            if found.returncode==0:
                row=json.loads(found.stdout)[0]
                assert row['Image']=='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
                assert row['Config']['Labels']['org.kyaulabs.conflux.run']=='keycnn-environment-20261029-01'
                subprocess.run(D+['rm','--force',row['Id']],check=True,capture_output=True,timeout=10)
            assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
            closed['container_absent']=True
        closed_path.write_text(json.dumps(closed,indent=2)+chr(10))
    else:closed=None
    result=dict(unit=current,closed=closed)
    if closed:
        text={}
        for name in('entry-binding.json','unit-closed.json','result.json','unit.stdout.log','unit.stderr.log','container-closed.json'):
            path=output/name
            if path.exists():
                assert path.is_file()and not path.is_symlink()and path.stat().st_size<=262144
                text[name]=path.read_text()
        result['files']=text
    return result


def main():
    reservation=json.loads((TARGET/'compatibility-reservation-01.json').read_text())
    expired=time.monotonic()>=reservation['deadline_monotonic']-35
    def local():return observe(TARGET,True,expired)
    def apollo():
        code='from pathlib import Path\nimport json,subprocess\n'+inspect.getsource(observe)
        code+='\nprint(json.dumps(observe(Path('+repr(REMOTE)+'),False,'+repr(expired)+')))\n'
        r=subprocess.run(SSH+['python3 -'],input=code,capture_output=True,text=True,timeout=50)
        (TARGET/'compatibility-observe.stderr.log').write_text(r.stderr)
        r.check_returncode();return json.loads(r.stdout)
    with ThreadPoolExecutor(max_workers=2)as pool:
        left=pool.submit(local);right=pool.submit(apollo)
        values=dict(laptop=left.result(),apollo=right.result())
    number=len(list(TARGET.glob('compatibility-observation-*.json')))+1
    save(TARGET/f'compatibility-observation-{number:03}.json',dict(utc=datetime.now(timezone.utc).isoformat(),hosts=values))
    print(json.dumps({host:{key:row[key]for key in('unit','closed')}for host,row in values.items()}))
    if all(row['closed']for row in values.values())and not(TARGET/'compatibility-complete-01.json').exists():
        folder=TARGET/'compatibility-apollo-01';folder.mkdir(mode=0o700)
        for name,text in values['apollo']['files'].items():(folder/name).write_text(text)
        results={host:json.loads(row['files']['result.json'])if'result.json'in row['files']else None for host,row in values.items()}
        passed=all(row is not None and row['passed']for row in results.values())
        save(TARGET/'compatibility-complete-01.json',dict(hosts=results,both_units_retired=True,
            apollo_container_absent=values['apollo']['closed']['container_absent'],passed=passed,
            music_source_opened=False,physical_readiness_consumed=False,qualified=False))
        print(json.dumps(dict(compatibility_passed=passed,all_owned_resources_retired=True)))


if __name__=='__main__':main()
