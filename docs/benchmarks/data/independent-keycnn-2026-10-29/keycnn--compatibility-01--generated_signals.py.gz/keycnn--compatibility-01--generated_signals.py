def fixtures():
    import numpy as np
    rate = 22050
    t = np.arange(rate*12+37, dtype=np.float64)/rate
    rng = np.random.default_rng(380117)
    impulse = np.zeros(len(t), dtype=np.float32)
    impulse[0] = .25
    impulse[-1] = -.5
    impulse[len(t)//2] = .125
    return {
        'silence': np.zeros(len(t), dtype=np.float32),
        'E1_tone': (.2*np.sin(2*np.pi*41.20344461410875*t)).astype(np.float32),
        'A4_detuned': (.2*np.sin(2*np.pi*440*2**(.25/12)*t)).astype(np.float32),
        'C_major_chord': sum(.08*np.sin(2*np.pi*frequency*t) for frequency in
                             (130.8127826502993, 164.81377845643496, 195.99771799087463)).astype(np.float32),
        'impulses_edges_and_middle': impulse,
        'seeded_noise': (.03*rng.standard_normal(len(t))).astype(np.float32),
    }
