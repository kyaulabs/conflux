"""Freeze the existing Winterreise/CQT recipe for the new source sample."""
from pathlib import Path
import hashlib
import json
import os

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
TARGET=BASE/'keycnn-01'
OLD=ROOT/'build/m2-fmak-assessment-01/keycnn-01'
DATA=ROOT/'build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/model-data-audit-01'


def pin(path):
    assert path.is_file()and not path.is_symlink()
    with path.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest)


def save(path,value):
    with path.open('x')as stream:stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def main():
    TARGET.mkdir(mode=0o700,exist_ok=True)
    assert not(TARGET/'asset-manifest-01.json').exists()
    original=json.loads((OLD/'music-plan-01.json').read_text())
    assets={}
    for row in original['input_pins']:
        path=Path(row['path'])
        if path.is_relative_to(DATA):
            resolved=path.resolve(strict=True)
            assert resolved.is_relative_to(DATA)
            assert pin(resolved)==dict(row,path=str(resolved))
            if not path.is_symlink():assets[str(path.relative_to(DATA))]=path
    assert len(assets)==122
    links=[]
    for folder in ('feature-compatibility-01/python','feature-compatibility-01/venv'):
        for path in sorted((DATA/folder).rglob('*')):
            relative=str(path.relative_to(DATA))
            if path.is_symlink():
                resolved=path.resolve(strict=True);assert resolved.is_relative_to(DATA)
                target=os.path.relpath(resolved,path.parent)
                assert os.path.normpath(str(Path(relative).parent/target))==str(resolved.relative_to(DATA))
                links.append(dict(file=relative,original_target=os.readlink(path),target=target))
            elif path.is_file():assets[relative]=path
    files=[]
    for name,path in sorted(assets.items()):
        row=pin(path);row.update(file=name,mode=0o755 if path.stat().st_mode&0o111 else 0o644)
        files.append(row)
    assert len(files)<10000 and sum(row['bytes']for row in files)<768*1024**2
    assert max(row['bytes']for row in files)<192*1024**2
    save(TARGET/'asset-manifest-01.json',dict(schema=1,container_asset_root=str(DATA),
        files=files,links=links,regular_bytes=sum(row['bytes']for row in files),
        source_assets_verified_against_old_pins=123,
        symlink_rebinding_only=True,packages_installed=False,model_or_recipe_changed=False))
    for host in ('laptop','apollo'):
        folder=TARGET/host;folder.mkdir(mode=0o700)
        worker=(OLD/'keycnn_worker.py').read_text()
        old="os.environ['NUMBA_CACHE_DIR'] = str(feature/'numba-cache')"
        assert worker.count(old)==1
        worker=worker.replace(old,"os.environ['NUMBA_CACHE_DIR'] = str(BASE/'output-01/numba-cache')")
        (folder/'keycnn_worker.py').write_text(worker)
        (folder/'protocol.py').write_text((OLD/'protocol.py').read_text())
        previous=json.loads((BASE/'keyfinder-01'/host/'plan.json').read_text())
        plan=dict(schema=1,status='frozen_CPU_correctness_only',host=host,
            recipe='private-keycnn-winterreise-nfold16-legacycqt-hop8-v1',
            model_sha256='b425f2e8d5165415c8863b6666aa82d7573121ee675bd2fd8b59d7594f5f11e9',
            cases=previous['cases'],preparer=previous['preparer'],
            python=str(DATA/'feature-compatibility-01/venv/bin/python'),
            worker=str(folder/'keycnn_worker.py')if host=='laptop'else'/operations/keycnn_worker.py',
            unit='conflux-independent-keycnn-'+host+'-20261029-01.service',
            physical_readiness_required=False,fixed_denominator=24,
            case_seconds=160,worker_CPU_seconds=80,worker_address_space_bytes=3*1024**3,
            inner_total_seconds=3900,reference_labels_in_runtime=False,
            confidence='Unknown',qualified=False)
        save(folder/'music-plan-01.json',plan)
    save(TARGET/'prospective-01.json',dict(schema=1,
        reference=pin(BASE/'selection-plan-02.json'),original_plan=pin(OLD/'music-plan-01.json'),
        original_global_rule=pin(OLD/'global-key-rule-01.json'),
        numeric_reference=pin(ROOT/'build/m2-winterreise-tf115-reference-01/plan-01.json'),
        worker_change='Only the private Numba cache destination moves to the owned output directory',
        raw_source_and_PCM_identity_rechecked_per_case=True,
        original_fixed_denominator=24,expected_inferable=23,source_failure_retained='003956',
        posterior_cross_host_atol=2e-6,posterior_cross_host_rtol=2e-6,
        global_rule='Arithmetic mean of every raw posterior row with math.fsum float64; largest class; lowest index on ties; all-zero feature population Unknown',
        scoring_after_both_owned_captures_close=True,comparison_selected_after_KeyFinder_screen=True,
        KeyCNN_settings_tuned_using_this_sample=False,
        reference_metadata_exposed_by_selection=True,upstream_training_independence_established=False,
        performance_or_confidence_qualification=False,production_backend_enabled=False))
    print(json.dumps(dict(frozen=True,asset_files=len(files),asset_bytes=sum(row['bytes']for row in files),
        links=len(links),packages_installed=False,music_inference_started=False)))


if __name__=='__main__':main()
