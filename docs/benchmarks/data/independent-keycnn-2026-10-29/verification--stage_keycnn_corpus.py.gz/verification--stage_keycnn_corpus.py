"""Freeze complete-source CPU captures and run generated protocol regressions."""
import hashlib
import json
from pathlib import Path
import subprocess
from prepare_keycnn import TARGET,DATA,pin,save
from stage_keycnn_runtime import REMOTE,SSH


def main():
    compat=json.loads((TARGET/'compatibility-complete-01.json').read_text())
    assert compat['passed']and compat['both_units_retired']and compat['apollo_container_absent']
    assert not(TARGET/'corpus-staged-01.json').exists()
    names=('run_corpus.py','protocol.py','aggregate.py','score_global.py',
        'test_global.py','test_protocol.py','test_lifecycle.py','test_pipeline.py')
    tests=subprocess.run(['/usr/bin/python3.14','-B','-m','unittest','-v',
        'test_global','test_protocol','test_lifecycle','test_pipeline'],cwd=TARGET,
        capture_output=True,text=True,timeout=15)
    (TARGET/'corpus-protocol-local.stdout.log').write_text(tests.stdout)
    (TARGET/'corpus-protocol-local.stderr.log').write_text(tests.stderr)
    assert tests.returncode==0 and'Ran 23 tests'in tests.stderr and tests.stderr.rstrip().endswith('OK')
    files={name:(TARGET/name).read_text()for name in names}
    asset_raw=(TARGET/'asset-manifest-01.json').read_text()
    local=TARGET/'laptop'
    for name,text in files.items():
        path=local/name
        if path.exists():assert path.read_text()==text
        else:path.write_text(text)
    (local/'asset-manifest.json').write_text(asset_raw)
    plan=json.loads((local/'music-plan-01.json').read_text())
    plan['asset_manifest']=str(local/'asset-manifest.json')
    plan['input_pins']=[plan['preparer']]+[case['source']for case in plan['cases']]+[pin(local/name)for name in names+('keycnn_worker.py','asset-manifest.json')]
    (local/'music-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
    # Importing the supervisor itself loads no NumPy/model or source audio.
    import importlib.util
    spec=importlib.util.spec_from_file_location('fixed_candidate_capture',TARGET/'run_corpus.py')
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    for row in plan['input_pins']:runner.verify(row)
    runner.verify_assets(plan)
    remote_plan=json.loads((TARGET/'apollo/music-plan-01.json').read_text())
    remote_files=dict(files,**{'keycnn_worker.py':(TARGET/'apollo/keycnn_worker.py').read_text(),
        'asset-manifest.json':asset_raw})
    setup='BASE='+repr(REMOTE)+'\nPLAN='+repr(remote_plan)+'\nFILES='+repr(remote_files)+'\nIMAGE='+repr('sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919')+'\n'+r'''
from pathlib import Path
import hashlib,json,subprocess
base=Path(BASE);folder=base/'corpus-01';assert not folder.exists();folder.mkdir(mode=0o700)
operations=folder/'operations';operations.mkdir(mode=0o700)
for name,text in FILES.items():(operations/name).write_text(text)
PLAN['asset_manifest']='/operations/asset-manifest.json'
def pin(path,target):
 with path.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 return dict(path=target,bytes=path.stat().st_size,sha256=digest)
PLAN['input_pins']=[PLAN['preparer']]+[case['source']for case in PLAN['cases']]+[pin(operations/name,'/operations/'+name)for name in FILES]
(operations/'music-plan-01.json').write_text(json.dumps(PLAN,indent=2)+chr(10))
output=folder/'output-01';output.mkdir(mode=0o700);(operations/'output-01').mkdir(mode=0o700)
for name in('unit.stdout.log','unit.stderr.log'):(folder/name).touch(mode=0o600,exist_ok=False)
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
name='conflux-independent-keycnn-protocol-20261029-01';label='independent-keycnn-protocol-20261029-01'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
inside=("import json,sys\n"
 "sys.path.insert(0,'/operations')\n"
 "import run_corpus\n"
 "plan=json.load(open('/operations/music-plan-01.json'))\n"
 "run_corpus.verify_assets(plan)\n"
 "import subprocess\n"
 "r=subprocess.run(['python','-B','-m','unittest','-v','test_global','test_protocol','test_lifecycle','test_pipeline'],cwd='/operations',capture_output=True,text=True,timeout=15)\n"
 "print(json.dumps(dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)))\n"
 "raise SystemExit(r.returncode)\n")
command=D+['run','--rm','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL',
 '--security-opt=no-new-privileges:true','--user=1000:1000','--cpus=1','--memory=1g','--pids-limit=128',
 '--label','org.kyaulabs.conflux.run='+label,'--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777',
 '--mount','type=bind,src='+str(base/'assets')+',dst='+json.loads(FILES['asset-manifest.json'])['container_asset_root']+',readonly',
 '--mount','type=bind,src='+str(operations)+',dst=/operations,readonly',IMAGE,'python','-c',inside]
try:r=subprocess.run(command,capture_output=True,text=True,timeout=45)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  value=json.loads(found.stdout)[0]
  assert value['Image']==IMAGE and value['Config']['Labels']['org.kyaulabs.conflux.run']==label
  subprocess.run(D+['rm','--force',value['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
(folder/'protocol.stdout.log').write_text(r.stdout);(folder/'protocol.stderr.log').write_text(r.stderr)
receipt=dict(exit=r.returncode,container_absent=True,stdout=r.stdout,stderr=r.stderr,plan=PLAN,
 media_or_classifier_started=False)
(folder/'protocol-receipt-01.json').write_text(json.dumps(receipt,indent=2)+chr(10))
print(json.dumps(receipt));r.check_returncode()
assert'Ran 23 tests'in json.loads(r.stdout)['stderr']
'''
    r=subprocess.run(SSH+['python3 -'],input=setup,capture_output=True,text=True,timeout=70)
    (TARGET/'corpus-stage-apollo.stdout.log').write_text(r.stdout)
    (TARGET/'corpus-stage-apollo.stderr.log').write_text(r.stderr);r.check_returncode()
    remote=json.loads(r.stdout);test=json.loads(remote['stdout'])
    assert remote['exit']==test['exit']==0 and remote['container_absent']
    assert'Ran 23 tests'in test['stderr']and test['stderr'].rstrip().endswith('OK')
    save(TARGET/'corpus-staged-01.json',dict(local_protocol_exit=tests.returncode,
        apollo=remote,tests_per_host=23,local_plan=pin(local/'music-plan-01.json'),
        prospective=pin(TARGET/'prospective-01.json'),asset_manifest=pin(TARGET/'asset-manifest-01.json'),
        unchanged_runtime_assets_verified_on_both_hosts=True,
        music_classifier_started=False,physical_readiness_consumed=False))
    print(json.dumps(dict(staged=True,tests_per_host=23,asset_hashes_unchanged=True,music_started=False)))


if __name__=='__main__':main()
