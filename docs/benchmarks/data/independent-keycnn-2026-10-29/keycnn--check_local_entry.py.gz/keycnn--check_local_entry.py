OUTPUT='/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/keycnn-01/compatibility-laptop-01'
PYTHON='/home/kyau/projects/kyaulabs/conflux/build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/model-data-audit-01/feature-compatibility-01/venv/bin/python'
CHECK='/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/keycnn-01/check_environment.py'
INPUTS='/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/keycnn-01/compatibility-01'

from pathlib import Path
import json,os
output=Path(OUTPUT);group=Path('/proc/self/cgroup').read_text().strip()
(output/'entry-binding.json').write_text(json.dumps(dict(pid=os.getpid(),invocation=os.environ['INVOCATION_ID'],cgroup=group),indent=2)+chr(10))
os.execv(PYTHON,[PYTHON,'-I','-B',CHECK,'--inputs',INPUTS,'--output',str(output/'result.json')])
