"""Reject invalid counter clocks and changed native build inputs without launching."""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch
import test_host_player as harness

driver = harness.driver


class GetterProfileTests(unittest.TestCase):
    def fixture(self):
        return harness.NormalAssessmentTests().result_fixture()['native']

    def test_complete_calling_thread_clock_profile_is_retained(self):
        native=self.fixture()
        self.assertEqual(driver.verify_getter_profile(native),native['private_decks_getter_profile'])

    def test_missing_foreign_or_invalid_clock_capture_is_rejected(self):
        mutations=[lambda n:n.pop('private_decks_getter_profile'),lambda n:n.update(pid=101)]
        mutations += [lambda n,k=k,v=v:n['private_decks_getter_profile'].update({k:v}) for k,v in
            [('schema',True),('clock_errors',False),('clock_errors',1),('calls',True),('calls',0),
             ('cpu_ns',-1),('cpu_ns',600000),('wall_ns',540000000001),('maximum_cpu_ns',501)]]
        for mutation in mutations:
            native=self.fixture();mutation(native)
            with self.subTest(native=native),self.assertRaisesRegex(ValueError,'CPU-clock capture'):
                driver.verify_getter_profile(native)

    def build_fixture(self):
        plan=json.loads(driver.PLAN.read_text())
        record=json.loads(Path(plan['helpers']['getter_build']['path']).read_text())
        payloads={plan['helpers'][key]['path']:Path(plan['helpers'][key]['path']).read_bytes()
                  for key in ('compile_commands','ui_build','getter_smoke')}
        def pin(path,*args,**kwargs):return {},payloads.get(str(path))
        return plan,record,pin

    def test_known_instrumented_build_keeps_the_original_recipes(self):
        plan,record,pin=self.build_fixture()
        with patch.object(driver,'pin_read',side_effect=pin):driver.verify_getter_build(plan,record,float('inf'))

    def test_changed_compile_link_or_binary_binding_cannot_pass(self):
        plan,record,pin=self.build_fixture()
        for change in (lambda r:r['native_compile'].append('-DQT_QML_DEBUG'),
                       lambda r:r['controller_compile'].append('-ffast-math'),
                       lambda r:r['native_link'].append('-lother'),
                       lambda r:r['native_binary'].update(sha256='a'*64)):
            candidate=copy.deepcopy(record);change(candidate)
            with self.subTest(change=change),patch.object(driver,'pin_read',side_effect=pin),self.assertRaises(ValueError):
                driver.verify_getter_build(plan,candidate,float('inf'))


if __name__=='__main__':unittest.main()
