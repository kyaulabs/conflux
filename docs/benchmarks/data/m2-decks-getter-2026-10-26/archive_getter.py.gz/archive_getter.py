"""Archive the completed getter diagnostic without audio, models or executables."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
RUN = BASE / 'player-01'
ROOT = BASE.parent.parent
WORK = ROOT / 'build/m2-profile-reporting-worktree'
DEST = WORK / 'docs/benchmarks/data/m2-decks-getter-2026-10-26'
RAW = BASE / 'archive-raw-01'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    assert not DEST.exists() and not RAW.exists()
    result = json.loads((RUN / 'root-audio-getter-results-01.json').read_text())
    closed = json.loads((RUN / 'root-finished-01.json').read_text())
    assert result['hop_count'] == 21 and result['late_hops'] == 0
    assert closed['cleanup_complete'] and closed['automated_owner_finished_within_original_600_seconds']
    assert not closed['root_verification_within_original_600_seconds']
    sources = [(p, 'player-' + p.name) for p in RUN.iterdir()
               if p.is_file() and (p.suffix in ('.json', '.py') or p.name in
                   ('offline-checks-final-01.log', 'file-preflight-01.log', 'launch-command-01.txt'))]
    sources += [(RUN / 'output-01' / name, 'output-' + name) for name in (
        'result.json', 'native-result.json', 'progress.json', 'observations.jsonl',
        'host-observations.jsonl', 'owned-pipewire-cleanup.json', 'native.stdout.log', 'native.stderr.log')]
    sources += [(BASE / name, 'build-' + name) for name in (
        'root-build-01.json', 'root-build-02.json', 'root-smoke-01.json',
        'build_getter_profile.py', 'resume_build_02.py', 'prepare_player_probe.py',
        'DeckController-profile.cpp', 'manual-soak-profile.cpp', 'getter-smoke.cpp',
        'DeckController-profile.cpp.patch', 'manual-soak-profile.cpp.patch')]
    sources += [(ROOT / 'build/m2-meter-stability-01/analyze_ui_comparison.py', 'shared-audio-thread-analysis.py'),
                (Path(__file__), 'archive_getter.py')]
    assert len(sources) == len({name for _, name in sources})
    RAW.mkdir(mode=0o700)
    rows = []
    for path, name in sorted(sources, key=lambda row: row[1]):
        assert path.resolve(strict=True) == path and path.stat().st_size < 32 * 1024**2
        raw = path.read_bytes()
        raw.decode('utf-8')
        if path.suffix == '.json':
            json.loads(raw)
        if path.suffix == '.jsonl':
            assert raw.endswith(b'\n')
            for line in raw.splitlines():
                json.loads(line)
        (RAW / name).write_bytes(raw)
        rows.append(dict(original_path=str(path), raw_file=name, raw_bytes=len(raw), raw_sha256=sha(raw)))
    scanner = shutil.which('gitleaks')
    assert scanner
    command = [scanner, 'dir', '--no-banner', '--redact', '--max-target-megabytes', '32', str(RAW)]
    with (BASE / 'archive-gitleaks-01.log').open('xb') as stream:
        scan = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=90)
    log = (BASE / 'archive-gitleaks-01.log').read_bytes()
    total = sum(row['raw_bytes'] for row in rows)
    count = re.search(rb'scanned ~(\d+) bytes', log)
    assert scan.returncode == 0 and count and int(count[1]) == total
    DEST.mkdir()
    for row in rows:
        raw = (RAW / row['raw_file']).read_bytes()
        compressed = gzip.compress(raw, compresslevel=9, mtime=0)
        assert gzip.decompress(compressed) == raw
        name = row['raw_file'] + '.gz'
        (DEST / name).write_bytes(compressed)
        row.update(archive_file=name, archive_bytes=len(compressed), archive_sha256=sha(compressed))
    manifest = dict(schema=1, qualified=False, production_code_changed=False,
        mode='m2-player-decks-getter-cpu-120-01', strict_service_target_ms=4095,
        diagnostic_ordinary_assessment=result['ordinary_assessment'],
        getter=result['getter'], complete_service_population=True,
        automated_cleanup_within_original600s=True, later_root_verification_within_original600s=False,
        power_ceiling_W=15, guard_unchanged=True, milestone_or_release_gate_changed=False,
        scope='One instrumented two-minute diagnostic. No causal speedup, uninstrumented, sustained, musical or physical-output-latency qualification.',
        files=rows, total_raw_bytes=total,
        total_archive_bytes=sum(row['archive_bytes'] for row in rows),
        gzip_roundtrip_and_original_hashes_verified=True,
        no_audio_models_executables_PCM_or_cache_published=True,
        raw_secret_scan=dict(command=command, exit=0, scanned_bytes=total, log_sha256=sha(log)))
    with (DEST / 'verification.json').open('x') as stream:
        stream.write(json.dumps(manifest, indent=2, allow_nan=False) + '\n')
    for row in rows:
        compressed = (DEST / row['archive_file']).read_bytes()
        raw = gzip.decompress(compressed)
        assert sha(compressed) == row['archive_sha256'] and sha(raw) == row['raw_sha256']
        (RAW / row['raw_file']).unlink()
    RAW.rmdir()
    print(json.dumps(dict(files=len(rows), raw_bytes=total, gzip_bytes=manifest['total_archive_bytes'],
                         all_raw_bytes_secret_scanned=True, all_round_trips_verified=True)))


if __name__ == '__main__':
    main()
