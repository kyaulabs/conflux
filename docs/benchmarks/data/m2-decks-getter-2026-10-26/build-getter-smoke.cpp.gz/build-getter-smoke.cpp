
#include "ui/DeckController.hpp"
#include <QCoreApplication>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>
#include <ctime>
#include <iostream>
#include <unistd.h>
namespace conflux::m2_decks_profile { QJsonObject snapshot(); }
quint64 cpuNs() {
    timespec value{};
    if (clock_gettime(CLOCK_THREAD_CPUTIME_ID, &value) != 0) throw std::runtime_error("clock failed");
    return quint64(value.tv_sec)*1000000000ULL+quint64(value.tv_nsec);
}
int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);
    QTemporaryDir directory;
    if (!directory.isValid() || !qputenv("XDG_DATA_HOME", directory.path().toUtf8())) return 2;
    conflux::DeckController controller;
    QVariantList first, last;
    const auto start = cpuNs();
    for (int i = 0; i < 1200; ++i) {
        last = controller.decks();
        if (!i) first = last;
        if (last.size() != 2) return 3;
    }
    const auto total = cpuNs()-start;
    const auto profile = conflux::m2_decks_profile::snapshot();
    const bool passed = first == last && profile["calls"].toInteger() == 1200 &&
        profile["calling_tid"].toInteger() == gettid() && !profile["clock_errors"].toInteger() &&
        profile["cpu_ns"].toInteger() > 0 && quint64(profile["cpu_ns"].toInteger()) <= total+500000;
    controller.shutdown();
    std::cout << QJsonDocument(QJsonObject{{"passed", passed}, {"external_thread_cpu_ns", qint64(total)},
        {"getter_profile", profile}, {"player_model_or_audio_started", false}}).toJson().constData();
    return passed ? 0 : 1;
}
