"""Retain the failed build; add its missing existing experiment-header directory."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
OLD = BASE.parent/'m2-flash-rows8-player-2026-10-25/build-01'
WORK = BASE.parent/'m2-profile-reporting-worktree'


def pin(path):
    path = Path(path).resolve(strict=True); raw = path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    result = json.loads((BASE/'root-build-01.json').read_text())
    assert result['status'] == 'failed' and result['controller_exit'] == 0 and result['native_exit'] != 0
    assert not (BASE/'root-build-02.json').exists()
    assert all(pin(row['path']) == row for row in result['private_sources'].values())
    assert [pin(row['path']) for row in result['original_build_inputs']] == result['original_build_inputs']
    assert all(pin(v['source']['path']) == v['source'] for v in result['original_sources'].values())
    result.update(status='started',prior_failure=pin(BASE/'root-build-01.json'),
        prior_successful_controller_object=pin(BASE/'DeckController-profile.cpp.o'),
        header_lookup_fix='Add -iquote for the existing tools/experiments directory; no source, quality, runtime or UI change.')
    result.pop('error',None)
    result['native_compile'][1:1] = ['-iquote',str(WORK/'tools/experiments')]
    started = time.monotonic()
    try:
        for label,command in [('native',result['native_compile']),('link',result['native_link'])]:
            with (BASE/(label+'-02.stdout')).open('xb') as out,(BASE/(label+'-02.stderr')).open('xb') as err:
                done = subprocess.run(command,cwd=OLD,stdout=out,stderr=err,timeout=120)
            result[label+'_exit'] = done.returncode; assert done.returncode == 0,label
        smoke_compile = [str(BASE/'getter-smoke.cpp') if t == str(BASE/'manual-soak-profile.cpp') else
            str(BASE/'getter-smoke.o') if t == str(BASE/'manual-soak-profile.cpp.o') else t for t in result['native_compile']]
        smoke_link = [str(BASE/'getter-smoke.o') if t == str(BASE/'manual-soak-profile.cpp.o') else
            str(BASE/'getter-smoke') if t == str(BASE/'conflux-manual-playback-getter-profile') else
            '-Wl,--dependency-file='+str(BASE/'smoke-link.d') if t.startswith('-Wl,--dependency-file=') else t for t in result['native_link']]
        result.update(smoke_compile=smoke_compile,smoke_link=smoke_link)
        for label,command in [('smoke-compile',smoke_compile),('smoke-link',smoke_link)]:
            with (BASE/(label+'-02.stdout')).open('xb') as out,(BASE/(label+'-02.stderr')).open('xb') as err:
                done = subprocess.run(command,cwd=OLD,stdout=out,stderr=err,timeout=90)
            result[label+'_exit'] = done.returncode; assert done.returncode == 0,label
        assert [pin(row['path']) for row in result['original_build_inputs']] == result['original_build_inputs']
        assert pin(BASE/'DeckController-profile.cpp.o') == result['prior_successful_controller_object']
        result.update(status='complete',base_inputs_unchanged=True,
            native_binary=pin(BASE/'conflux-manual-playback-getter-profile'),smoke_binary=pin(BASE/'getter-smoke'),
            private_objects=[pin(BASE/name) for name in ('DeckController-profile.cpp.o','manual-soak-profile.cpp.o')])
    except Exception as error:
        result.update(status='failed',error=dict(type=type(error).__name__,message=str(error)));raise
    finally:
        result['elapsed_seconds'] = time.monotonic()-started
        with (BASE/'root-build-02.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({k:result[k] for k in ('status','elapsed_seconds','base_inputs_unchanged','native_binary','smoke_binary')}))


if __name__ == '__main__':main()
