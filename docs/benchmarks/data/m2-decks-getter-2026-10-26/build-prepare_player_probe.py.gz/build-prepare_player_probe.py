"""Prepare one unarmed visible-player probe with verified getter counters."""
import copy
import hashlib
import json
from pathlib import Path
import re
import shutil

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
TEMPLATE = ROOT/'build/m2-meter-stability-01/ui-comparison-01/cases/candidate'
OLD = ROOT/'build/m2-player-thread-cpu-trace-01'
DEST = BASE/'player-01'

ADDITION = '''def verify_getter_build(plan,record,deadline):
    require(record.get('status')=='complete' and record.get('base_inputs_unchanged') is True and
        record.get('base_source')==SOURCE_HEAD and record.get('player_model_or_audio_started') is False and
        record.get('runtime_UI_root')==str(UI_ROOT) and record.get('native_binary')==plan['assets']['binary'],
        'Getter diagnostic build/source identity differs')
    for row in [*record['private_sources'].values(),*record['private_objects'],
                *record['original_build_inputs'],record['native_binary'],record['smoke_binary'],record['prior_successful_controller_object']]:
        pin_read(row['path'],row,deadline=deadline)
    commands=decode(pin_read(plan['helpers']['compile_commands']['path'],plan['helpers']['compile_commands'],
        maximum=1024**2,deadline=deadline,keep=True)[1])
    for source,key,private,output in [('src/ui/DeckController.cpp','controller_compile','DeckController-profile.cpp','DeckController-profile.cpp.o'),
            ('tools/experiments/manual_playback_soak.cpp','native_compile','manual-soak-profile.cpp','manual-soak-profile.cpp.o')]:
        old=record['original_sources'][source]
        pin_read(old['source']['path'],old['source'],deadline=deadline)
        rows=[r for r in commands if r['file']==str(W/source)]
        require(len(rows)==1,'One original source compilation row required')
        tokens=rows[0].get('arguments') or shlex.split(rows[0]['command'])
        require(old['argv']==tokens,'Original getter compilation recipe differs')
        original_object=tokens[tokens.index('-o')+1]
        root=Path(record['native_binary']['path']).parent
        expected=[str(root/private) if x==str(W/source) else str(root/output) if x==original_object else
            x.replace(str(W),str(UI_ROOT)) if x.startswith('-DCONFLUX_SOURCE_DIR=') else x for x in tokens]
        expected[1:1]=['-iquote',str(W/('src/ui' if source.startswith('src/') else 'tools/experiments'))]
        require(record[key]==expected,'Getter instrumentation compile flags differ')
    ui_record=decode(pin_read(plan['helpers']['ui_build']['path'],plan['helpers']['ui_build'],
        maximum=256*1024,deadline=deadline,keep=True)[1])['arms']['candidate']
    root=Path(record['native_binary']['path']).parent
    expected=[]
    for token in ui_record['link_argv']:
        if token=='libconflux-ui.a':expected.append(str(root/'DeckController-profile.cpp.o'))
        expected.append(str(root/'manual-soak-profile.cpp.o') if token==ui_record['object']['path'] else
            str(root/'conflux-manual-playback-getter-profile') if token==ui_record['binary']['path'] else
            '-Wl,--dependency-file='+str(root/'native-link.d') if token.startswith('-Wl,--dependency-file=') else token)
    require(record['native_link']==expected,'Getter instrumentation link recipe differs')
    smoke=decode(pin_read(plan['helpers']['getter_smoke']['path'],plan['helpers']['getter_smoke'],
        maximum=16384,deadline=deadline,keep=True)[1])
    require(smoke.get('passed') is True and smoke.get('child_reaped') is True and smoke.get('owned_group_absent') is True and
        smoke.get('no_player_model_audio_or_visible_window_started') is True and smoke.get('timeout') is False and
        smoke.get('build_sha256')==plan['helpers']['getter_build']['sha256'] and
        smoke.get('smoke_binary')==record['smoke_binary'] and smoke.get('player_binary_same_getter_object')==record['native_binary'] and
        smoke['fixture_result']['getter_profile']['calls']==1200 and smoke['fixture_result']['getter_profile']['clock_errors']==0,
        'Getter CPU-clock fixture missing or failed')


def verify_getter_profile(native):
    profile=native.get('private_decks_getter_profile')
    require(type(profile) is dict and type(profile.get('schema')) is int and profile['schema']==1 and
        type(profile.get('calling_tid')) is int and profile['calling_tid']==native.get('pid') and
        type(profile.get('calls')) is int and 0<profile['calls']<=1000000 and
        type(profile.get('clock_errors')) is int and profile['clock_errors']==0 and
        all(type(profile.get(k)) is int and profile[k]>=0 for k in ('wall_ns','cpu_ns','maximum_wall_ns','maximum_cpu_ns')) and
        0<profile['maximum_cpu_ns']<=profile['cpu_ns']<=profile['wall_ns']+500000 and
        0<profile['maximum_wall_ns']<=profile['wall_ns']<=540000000000, 'Getter CPU-clock capture incomplete or invalid')
    return profile


'''


def pin(path):
    path = Path(path).resolve(strict=True);raw = path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def once(text,old,new):
    assert text.count(old) == 1,old[:100]
    return text.replace(old,new)


def main():
    assert not DEST.exists()
    record = json.loads((BASE/'root-build-02.json').read_text())
    assert record['status'] == 'complete' and json.loads((BASE/'root-smoke-01.json').read_text())['passed']
    DEST.mkdir(mode=0o700)
    plan = json.loads((TEMPLATE/'plan.json').read_text())
    mode = 'm2-player-decks-getter-cpu-120-01'
    text = (TEMPLATE/'run_host_player.py').read_text()
    text = once(text,'BINARY = Path('+repr(plan['assets']['binary']['path'])+')',
        'BINARY = Path('+repr(record['native_binary']['path'])+')')
    text = once(text,'BINARY_SHA = '+repr(plan['assets']['binary']['sha256']),
        'BINARY_SHA = '+repr(record['native_binary']['sha256']))
    text = once(text,'MODE = '+repr(plan['mode']),'MODE = '+repr(mode))
    text = re.sub(r'\b1200\b','600',text).replace('original1200s','original600s')
    text = once(text,'def verify_files(plan,deadline=math.inf):',ADDITION+'def verify_files(plan,deadline=math.inf):')
    text = once(text,'    verify_ui_build(plan,record,deadline)',
        "    ui_plan=copy.deepcopy(plan);ui_plan['assets']['binary']=plan['original_fixed_UI_binary']\n"
        "    verify_ui_build(ui_plan,record,deadline)\n"
        "    getter=decode(pin_read(plan['helpers']['getter_build']['path'],plan['helpers']['getter_build'],maximum=128*1024,deadline=deadline,keep=True)[1])\n"
        "    verify_getter_build(plan,getter,deadline)")
    text = once(text,"        n = result['native']; c = result['cleanup']; counters = n['observation_counters']; recording = n['recording']",
        "        n = result['native']; c = result['cleanup']; counters = n['observation_counters']; recording = n['recording']\n"
        '        verify_getter_profile(n)')
    text = once(text,"        'scope':'Original/fixed meter UI comparison; same original C++/audio, Best runtime, visible16-controls workload and read-only CPU/thread observer. Isolated UI snapshots; no profiler, sustained, physical-latency or milestone qualification.'}",
        "        'scope':'Private decks() wall/thread-CPU counter diagnostic; fixed meter UI, same audio and Best stem runtime. Clock overhead is included; no latency or milestone qualification.'}")
    (DEST/'run_host_player.py').write_text(text)
    owner = (TEMPLATE/'run_player_owned.py').read_text()
    owner = re.sub(r"LAUNCHER_SHA = '[0-9a-f]{64}'",'LAUNCHER_SHA = '+repr(pin(DEST/'run_host_player.py')['sha256']),owner,count=1)
    (DEST/'run_player_owned.py').write_text(owner);(DEST/'run_player_owned.py').chmod(0o755)
    (DEST/'launch-command-01.txt').write_text('/usr/bin/kde-inhibit --power --screenSaver '+str(DEST/'run_player_owned.py')+' --run\n')
    tests = (TEMPLATE/'test_host_player.py').read_text()
    oldtests = (OLD/'test_host_player.py').read_text()
    for current,nextclass in [('BudgetTests','RendererEnvironmentTests'),('OwnerClockTests','ReportingAndOrderingTests')]:
        pattern=r'class '+current+r'\(.*?(?=\nclass '+nextclass+r'\()'
        original = re.search(pattern,oldtests,re.S).group(0)
        tests,n = re.subn(pattern,lambda m:original,tests,count=1,flags=re.S);assert n == 1
    tests = once(tests,"        native.update(source_root='/offline/merged-source',error='',",
        "        native.update(pid=100,private_decks_getter_profile={'schema':1,'calling_tid':100,'calls':5,'clock_errors':0,\n"
        "            'cpu_ns':500,'wall_ns':1000,'maximum_cpu_ns':100,'maximum_wall_ns':200},source_root='/offline/merged-source',error='',")
    (DEST/'test_host_player.py').write_text(tests)
    for name in ('test_process_cpu.py','test_thread_cpu.py'):shutil.copy2(TEMPLATE/name,DEST/name)
    ui_tests = (TEMPLATE/'test_ui_provenance.py').read_text()
    ui_tests = once(ui_tests,"        plan=json.loads(driver.PLAN.read_text())", "        plan=json.loads(driver.PLAN.read_text())\n        plan['assets']['binary']=plan['original_fixed_UI_binary']")
    (DEST/'test_ui_provenance.py').write_text(ui_tests)
    plan.update(mode=mode,status='draft_unarmed_pending_root_review',operator_seconds=600,
        original_fixed_UI_binary=copy.deepcopy(plan['assets']['binary']),
        assets=dict(plan['assets'],binary=record['native_binary']),
        actual_checkout_head_at_preparation='e971e60e0b37b124328bf03baad4c133447ef5f2',
        workload_scope='One instrumented two-minute visible Best-quality player run. Getter clock overhead included; no latency qualification, source cache change or power-profile selection.')
    for key,name in [('getter_build','root-build-02.json'),('getter_smoke','root-smoke-01.json'),
                     ('getter_builder','build_getter_profile.py'),('getter_resume','resume_build_02.py'),('getter_preparer','prepare_player_probe.py')]:
        plan['helpers'][key] = pin(BASE/name)
    for key,name in [('launcher','run_host_player.py'),('outer_owner','run_player_owned.py'),('operator_launch','launch-command-01.txt')]:
        plan['sources'][key] = pin(DEST/name)
    with (DEST/'plan.json').open('x') as stream:json.dump(plan,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(status='draft_unarmed',mode=mode,operator_seconds=600,native=record['native_binary'],readiness_absent=True)))


if __name__ == '__main__':main()
