"""Build an isolated getter CPU-counter diagnostic; do not alter product sources."""
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import time

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
WORK = ROOT/'build/m2-profile-reporting-worktree'
OLD = ROOT/'build/m2-flash-rows8-player-2026-10-25/build-01'
UI = ROOT/'build/m2-meter-stability-01/ui-comparison-build-01/candidate/ui-source'
ORIGINAL = '119a579e4ca717a1d59d7a7a6f9752534d68dcaf'

COUNTERS = r'''
#include <QJsonObject>
#include <ctime>
#include <unistd.h>

namespace conflux::m2_decks_profile {
struct Counters {
    quint64 calls{}, wallNs{}, cpuNs{}, maximumWallNs{}, maximumCpuNs{}, clockErrors{};
};
thread_local Counters counters;
quint64 clockNs(clockid_t clock) noexcept {
    timespec value{};
    if (clock_gettime(clock, &value) != 0 || value.tv_sec < 0 || value.tv_nsec < 0) {
        ++counters.clockErrors;
        return 0;
    }
    return quint64(value.tv_sec) * 1000000000ULL + quint64(value.tv_nsec);
}
struct ReadScope {
    quint64 wall{clockNs(CLOCK_MONOTONIC)}, cpu{clockNs(CLOCK_THREAD_CPUTIME_ID)};
    ~ReadScope() noexcept {
        const auto cpuEnd = clockNs(CLOCK_THREAD_CPUTIME_ID), wallEnd = clockNs(CLOCK_MONOTONIC);
        ++counters.calls;
        if (!wall || !cpu || cpuEnd < cpu || wallEnd < wall) { ++counters.clockErrors; return; }
        const auto cpuDelta = cpuEnd-cpu, wallDelta = wallEnd-wall;
        counters.cpuNs += cpuDelta; counters.wallNs += wallDelta;
        counters.maximumCpuNs = std::max(counters.maximumCpuNs, cpuDelta);
        counters.maximumWallNs = std::max(counters.maximumWallNs, wallDelta);
    }
};
QJsonObject snapshot() {
    return {{"schema", 1}, {"calling_tid", qint64(gettid())}, {"calls", qint64(counters.calls)},
        {"wall_ns", qint64(counters.wallNs)}, {"cpu_ns", qint64(counters.cpuNs)},
        {"maximum_wall_ns", qint64(counters.maximumWallNs)},
        {"maximum_cpu_ns", qint64(counters.maximumCpuNs)}, {"clock_errors", qint64(counters.clockErrors)},
        {"scope", "Instrumented decks() body on this calling thread; inclusive wall and thread CPU, including timer overhead. Does not include QVariant-to-JavaScript conversion or identify other GUI work."}};
}
} // namespace conflux::m2_decks_profile

'''

SMOKE = r'''
#include "ui/DeckController.hpp"
#include <QCoreApplication>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>
#include <ctime>
#include <iostream>
#include <unistd.h>
namespace conflux::m2_decks_profile { QJsonObject snapshot(); }
quint64 cpuNs() {
    timespec value{};
    if (clock_gettime(CLOCK_THREAD_CPUTIME_ID, &value) != 0) throw std::runtime_error("clock failed");
    return quint64(value.tv_sec)*1000000000ULL+quint64(value.tv_nsec);
}
int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);
    QTemporaryDir directory;
    if (!directory.isValid() || !qputenv("XDG_DATA_HOME", directory.path().toUtf8())) return 2;
    conflux::DeckController controller;
    QVariantList first, last;
    const auto start = cpuNs();
    for (int i = 0; i < 1200; ++i) {
        last = controller.decks();
        if (!i) first = last;
        if (last.size() != 2) return 3;
    }
    const auto total = cpuNs()-start;
    const auto profile = conflux::m2_decks_profile::snapshot();
    const bool passed = first == last && profile["calls"].toInteger() == 1200 &&
        profile["calling_tid"].toInteger() == gettid() && !profile["clock_errors"].toInteger() &&
        profile["cpu_ns"].toInteger() > 0 && quint64(profile["cpu_ns"].toInteger()) <= total+500000;
    controller.shutdown();
    std::cout << QJsonDocument(QJsonObject{{"passed", passed}, {"external_thread_cpu_ns", qint64(total)},
        {"getter_profile", profile}, {"player_model_or_audio_started", false}}).toJson().constData();
    return passed ? 0 : 1;
}
'''


def pin(path):
    path = Path(path).resolve(strict=True); raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    receipt = BASE/'root-build-01.json'; assert not receipt.exists()
    commands = json.loads((OLD/'compile_commands.json').read_text())
    original = {}
    for name in ('src/ui/DeckController.cpp','tools/experiments/manual_playback_soak.cpp'):
        path = WORK/name; raw = path.read_bytes()
        assert raw == subprocess.check_output(['git','show',ORIGINAL+':'+name],cwd=WORK)
        row = next(row for row in commands if row['file'] == str(path))
        original[name] = dict(source=pin(path), argv=row.get('arguments') or shlex.split(row['command']))
    controller = (WORK/'src/ui/DeckController.cpp').read_text()
    anchor = 'QVariantList DeckController::decks() const\n{\n'
    assert controller.count(anchor) == 1 and controller.count('namespace conflux {') == 1
    controller = controller.replace('namespace conflux {',COUNTERS+'namespace conflux {',1)
    controller = controller.replace(anchor,anchor+'    const m2_decks_profile::ReadScope privateGetterTiming;\n',1)
    native = (WORK/'tools/experiments/manual_playback_soak.cpp').read_text()
    assert native.count('namespace {') == 1
    native = native.replace('namespace {','namespace conflux::m2_decks_profile { QJsonObject snapshot(); }\n\nnamespace {',1)
    anchor = '    try { save(output + "/native-result.json", result, hour ? 1024 * 1024 : 0); }'
    assert native.count(anchor) == 1
    native = native.replace(anchor,'    result["private_decks_getter_profile"] = conflux::m2_decks_profile::snapshot();\n'+anchor,1)
    private = {}
    for name,text in [('DeckController-profile.cpp',controller),('manual-soak-profile.cpp',native),('getter-smoke.cpp',SMOKE)]:
        path = BASE/name
        with path.open('x') as stream: stream.write(text)
        private[name] = pin(path)
    for filename,source in [('DeckController-profile.cpp','src/ui/DeckController.cpp'),('manual-soak-profile.cpp','tools/experiments/manual_playback_soak.cpp')]:
        raw = (WORK/source).read_text()
        (BASE/(filename+'.patch')).write_text(''.join(difflib.unified_diff(raw.splitlines(True),(BASE/filename).read_text().splitlines(True),fromfile=source,tofile=filename)))
    objects = {}
    for name,filename in [('src/ui/DeckController.cpp','DeckController-profile.cpp'),('tools/experiments/manual_playback_soak.cpp','manual-soak-profile.cpp')]:
        tokens = original[name]['argv']; original_object = tokens[tokens.index('-o')+1]
        obj = BASE/(filename+'.o')
        argv = [str(BASE/filename) if t == str(WORK/name) else str(obj) if t == original_object else
                t.replace(str(WORK),str(UI)) if t.startswith('-DCONFLUX_SOURCE_DIR=') else t for t in tokens]
        if name.startswith('src/'): argv[1:1] = ['-iquote',str(WORK/'src/ui')]
        objects[name] = dict(path=str(obj),compile_argv=argv)
    link = subprocess.check_output(['ninja','-t','commands','conflux-manual-playback-soak'],cwd=OLD,text=True).splitlines()[-1]
    assert link.startswith(': && ') and link.endswith(' && :')
    original_link = shlex.split(link[5:-5]); native_object = original['tools/experiments/manual_playback_soak.cpp']['argv'][-3]
    assert native_object == 'CMakeFiles/conflux-manual-playback-soak.dir/tools/experiments/manual_playback_soak.cpp.o'
    assert original_link.count('libconflux-ui.a') == 1
    argv = []
    for token in original_link:
        if token == 'libconflux-ui.a': argv.append(objects['src/ui/DeckController.cpp']['path'])
        argv.append(objects['tools/experiments/manual_playback_soak.cpp']['path'] if token == native_object else
            str(BASE/'conflux-manual-playback-getter-profile') if token == 'conflux-manual-playback-soak' else
            '-Wl,--dependency-file='+str(BASE/'native-link.d') if token.startswith('-Wl,--dependency-file=') else token)
    inputs = [pin(OLD/'compile_commands.json'),pin(OLD/'CMakeCache.txt')]
    inputs += [pin(Path(t) if Path(t).is_absolute() else OLD/t) for t in original_link[1:]
        if not t.startswith('-') and t != 'conflux-manual-playback-soak' and (Path(t) if Path(t).is_absolute() else OLD/t).is_file()]
    result = dict(schema=1,status='started',qualified=False,base_source=ORIGINAL,
        actual_worktree_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),
        original_sources=original,private_sources=private,original_build_inputs=inputs,
        controller_compile=objects['src/ui/DeckController.cpp']['compile_argv'],native_compile=objects['tools/experiments/manual_playback_soak.cpp']['compile_argv'],
        native_link=argv,runtime_UI_root=str(UI),changes='Getter body RAII wall/thread-CPU counters and one diagnostic JSON field; original getter logic, UI, audio and stem code unchanged.',
        player_model_or_audio_started=False,created_at_utc=datetime.now(timezone.utc).isoformat())
    started = time.monotonic()
    try:
        for label,command in [('controller',result['controller_compile']),('native',result['native_compile']),('link',argv)]:
            with (BASE/(label+'.stdout')).open('xb') as out,(BASE/(label+'.stderr')).open('xb') as err:
                done = subprocess.run(command,cwd=OLD,stdout=out,stderr=err,timeout=150)
            result[label+'_exit'] = done.returncode; assert done.returncode == 0,label
        smoke_compile = [str(BASE/'getter-smoke.cpp') if t == str(BASE/'manual-soak-profile.cpp') else
            str(BASE/'getter-smoke.o') if t == objects['tools/experiments/manual_playback_soak.cpp']['path'] else t for t in result['native_compile']]
        smoke_link = [str(BASE/'getter-smoke.o') if t == objects['tools/experiments/manual_playback_soak.cpp']['path'] else
            str(BASE/'getter-smoke') if t == str(BASE/'conflux-manual-playback-getter-profile') else
            '-Wl,--dependency-file='+str(BASE/'smoke-link.d') if t.startswith('-Wl,--dependency-file=') else t for t in argv]
        result.update(smoke_compile=smoke_compile,smoke_link=smoke_link)
        for label,command in [('smoke-compile',smoke_compile),('smoke-link',smoke_link)]:
            with (BASE/(label+'.stdout')).open('xb') as out,(BASE/(label+'.stderr')).open('xb') as err:
                done = subprocess.run(command,cwd=OLD,stdout=out,stderr=err,timeout=90)
            result[label+'_exit'] = done.returncode; assert done.returncode == 0,label
        assert [pin(row['path']) for row in inputs] == inputs
        assert all(pin(value['source']['path']) == value['source'] for value in original.values())
        result.update(status='complete',base_inputs_unchanged=True,
            native_binary=pin(BASE/'conflux-manual-playback-getter-profile'),smoke_binary=pin(BASE/'getter-smoke'),
            private_objects=[pin(value['path']) for value in objects.values()])
    except Exception as error:
        result.update(status='failed',error=dict(type=type(error).__name__,message=str(error)))
        raise
    finally:
        result['elapsed_seconds'] = time.monotonic()-started
        with receipt.open('x') as stream: json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','elapsed_seconds','base_inputs_unchanged','native_binary','smoke_binary')}))


if __name__ == '__main__': main()
