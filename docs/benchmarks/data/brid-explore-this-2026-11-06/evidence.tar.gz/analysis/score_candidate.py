"""Score all93 fixed ExploreThis predictions with the unchanged original BRID scorer."""
from pathlib import Path
import argparse,json,hashlib,importlib.util
B=Path(__file__).resolve().parent
RECIPE='explore-this-final0-threshold-diagnostic-v1'

def candidate_row(native,raw):
 assert len(raw)<=4<<20 and raw.endswith(b'\n');values=[json.loads(x)for x in raw.splitlines()];h=values[0]
 assert h['schema']==2 and h['recipe']==RECIPE and h['frames']==native['prepared_frames']and h['pcm_sha256']==native['pcm_sha256']and h['beat_count']==len(values)-1
 assert native['analysis_status']=='Unknown'and native['beats']==[]and native['summary_bpm']is None and native['analysis_error']==''
 return dict(native,beats=values[1:],summary_bpm=h['bpm'],analysis_status='Estimated'if h['bpm']is not None else'Unknown')

def pinned(path,sha):
 raw=Path(path).read_bytes();assert hashlib.sha256(raw).hexdigest()==sha;return raw

def main():
 p=argparse.ArgumentParser();p.add_argument('--collection',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args();assert a.collection.is_absolute()and a.output.is_absolute()and not a.output.exists();plan=json.loads((B/'scoring-plan.json').read_text())
 protocol=json.loads(pinned(plan['protocol_path'],plan['protocol_sha256']));assert protocol['fixed_denominator']==93 and protocol['gates']==plan['gates']and [c['id']for c in protocol['cases']]==list(range(1,94))
 manifest=json.loads((a.collection/'collection-manifest.json').read_text())
 for pin in manifest['files']:
  raw=(a.collection/pin['path']).read_bytes();assert len(raw)==pin['bytes']and hashlib.sha256(raw).hexdigest()==pin['sha256']
 owner=json.loads((a.collection/'full-owner-receipt.json').read_text());report=json.loads((a.collection/'full-result.json').read_text());assert owner['exit']==0 and owner['all_dedicated_containers_absent']and owner['client_reaped'];assert report['complete']and report['child_reaped']and report['fixed_denominator']==93 and report['recipe']==RECIPE and [c['id']for c in report['cases']]==list(range(1,94))and all(c['passed']for c in report['cases'])
 pinned(plan['legacy_scorer_path'],plan['legacy_scorer_sha256']);spec=importlib.util.spec_from_file_location('frozen_b93_scorer',plan['legacy_scorer_path']);score=importlib.util.module_from_spec(spec);spec.loader.exec_module(score)
 rows=[]
 for case,receipt in zip(protocol['cases'],report['cases'],strict=True):
  root=a.collection/'cases'/f"{case['id']:04d}";native,terminal=score.rows((root/'native.stdout').read_bytes());assert len(native)==1 and terminal['complete']and terminal['passed']and terminal['expected']==terminal['completed']==1;native=native[0]
  raw=(root/'candidate.stdout').read_bytes();assert hashlib.sha256(raw).hexdigest()==receipt['response_sha256']and receipt['input_pcm_sha256']==native['pcm_sha256']and receipt['frames']==native['prepared_frames']
  row=candidate_row(native,raw);rows.append(score.score(case,row,native['source']))
 failures=sum(c['operational_status']=='Failed'for c in rows);micro=None
 if failures==0:
  tp=sum(c['downbeat']['matched_beats']for c in rows);fp=sum(c['downbeat']['false_positives']for c in rows);fn=sum(c['downbeat']['false_negatives']for c in rows);micro={'matched':tp,'extras':fp,'misses':fn,'F1':2*tp/(2*tp+fp+fn)if 2*tp+fp+fn else 0.}
 result={'schema':1,'kind':'BRID93_fixed_ExploreThis_backend_diagnosis','denominator':93,'failures':failures,'cases':rows,'beat_passes':sum(c['beat_numeric_pass']for c in rows),'downbeat_passes':sum(c['downbeat_numeric_pass']for c in rows),'both_passes':sum(c['both_numeric_pass']for c in rows),'downbeat_micro':micro,'baseline':{k:v for k,v in json.loads(pinned(plan['baseline_score_path'],plan['baseline_score_sha256']))['variants']['minimal'].items()if k!='cases'},'gates':plan['gates'],'recipe':RECIPE,'standalone_not_player_integrated':True,'predictions_persisted_before_reference_scoring':True,'held_out':False,'qualified':False,'confidence':'Unknown','production_change':False}
 a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['cases','gates']},indent=2))
if __name__=='__main__':main()
