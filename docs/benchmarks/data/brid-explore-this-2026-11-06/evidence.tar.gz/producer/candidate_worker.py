"""Private fixed Explore This CPU diagnostic; never a production analysis recipe."""
from pathlib import Path, PosixPath
import argparse
import hashlib
import importlib.util
import json
import os
import sys

B=Path(__file__).resolve().parent
RECIPE='explore-this-final0-threshold-diagnostic-v1'
CHECKPOINT_SHA='ca262c9848f0b8c232bc82eb22bf4f024011487c8155a0b716b98a1608438ed0'


def helper():
    p=B/'production_worker.py'
    assert hashlib.sha256(p.read_bytes()).hexdigest()=='e76b8ab903aebc76a592ac262b1dd3c7602cdea0606610e866cca31156d753b5'
    spec=importlib.util.spec_from_file_location('fixed_source_transport',p)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.RECIPE=RECIPE
    return module


def run(args):
    from importlib import metadata
    transport=helper()
    for name,version in transport.DEPENDENCIES.items():
        assert metadata.version(name)==version
    pcm=transport.read_pcm(sys.stdin.buffer,args.frames)
    pcm_sha=hashlib.sha256(pcm).hexdigest()
    source=Path(args.source_dir)
    assert source.is_absolute() and source==B/'source'
    manifest=json.loads((B/'source-manifest.json').read_text())
    assert manifest['commit']=='408db038b41bdc18104e70c5a8ac8daabd9cd496'
    for pin in manifest['files']:
        if 'sha256' in pin:
            raw=(source/pin['path']).read_bytes()
            assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
    sys.path.insert(0,str(source))
    import numpy as np
    import soxr
    import torch
    torch.set_num_threads(2);torch.set_num_interop_threads(1)
    assert torch.__version__=='2.11.0+cpu' and torch.version.cuda is None
    from explore_this import inference
    def safe_checkpoint(path,device='cpu'):
        assert str(path)==args.model and str(device)=='cpu'
        stream,before=transport.open_verified(path,78039686,CHECKPOINT_SHA)
        with stream,torch.serialization.safe_globals([PosixPath]):
            value=torch.load(stream,map_location='cpu',weights_only=True)
            assert transport.identity(before)==transport.identity(os.fstat(stream.fileno()))
            assert transport.identity(before)==transport.identity(Path(path).lstat())
        assert isinstance(value,dict) and isinstance(value['hyper_parameters'],dict)
        state=value['state_dict'];assert isinstance(state,dict) and len(state)==174
        assert all(isinstance(v,torch.Tensor)and v.device.type=='cpu'and torch.isfinite(v).all().item()for v in state.values())
        return value
    inference.load_checkpoint=safe_checkpoint
    model=inference.load_model(args.model,device='cpu')
    assert not model.training and model.subgrid_processor.mask_method=='threshold'
    assert model.subgrid_processor.mask_threshold==0.5 and model.subgrid_processor.max_downbeat_meter==7
    stereo=np.frombuffer(pcm,dtype='<f4').reshape(args.frames,2)
    mono=soxr.resample(stereo.mean(axis=1),in_rate=48000,out_rate=22050)
    assert mono.ndim==1 and np.isfinite(mono).all()
    spect=inference.LogMelSpect()(torch.from_numpy(mono))
    assert spect.ndim==2 and spect.shape[1]==128 and torch.isfinite(spect).all().item()
    source_mask=transport.source_mask(args.frames,[len(mono),len(mono)],len(spect))
    with torch.inference_mode():
        output=inference.split_predict_aggregate(spect,1500,'keep_first',model,end_goal='subgrid')
    arrays={name:getattr(output,name).detach().cpu().numpy().copy() for name in
            ('beat_activation','downbeat_activation','grid_mask','beat_mask','downbeat_mask')}
    assert all(v.shape==(len(spect),)and np.isfinite(v).all() for v in arrays.values())
    assert all(arrays[name].dtype==np.bool_ for name in ('grid_mask','beat_mask','downbeat_mask'))
    assert not np.any(arrays['downbeat_mask']&~arrays['beat_mask'])
    arrays['source_mask']=np.asarray(source_mask,dtype=np.bool_)
    seconds=(np.flatnonzero(arrays['beat_mask']&arrays['source_mask'])/50).tolist()
    down_seconds=(np.flatnonzero(arrays['downbeat_mask']&arrays['source_mask'])/50).tolist()
    bpm,_=transport.summarize_beats(seconds,args.frames)
    response=transport.encode_result(args.frames,pcm_sha,bpm,seconds,down_seconds)
    identifier=int(os.environ['CONFLUX_CAPTURE_CASE_ID'])
    root=Path(os.environ['CONFLUX_LOGIT_CAPTURE_ROOT'])
    assert 1<=identifier<=93 and root.is_absolute() and root.resolve()==root and root.is_dir()
    assert root.stat().st_uid==os.geteuid() and root.stat().st_mode&0o077==0
    path=root/f'{identifier:04d}.npz'
    with path.open('xb')as stream:np.savez(stream,**arrays)
    assert path.stat().st_size<=65536
    report=dict(schema=1,case_id=identifier,frames=args.frames,pcm_sha256=pcm_sha,
                recipe=RECIPE,calls=1,logit_frames=len(spect),mask_true_count=sum(source_mask),
                array_bytes=path.stat().st_size,array_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                result_sha256=hashlib.sha256(response).hexdigest(),
                analysis_worker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                source_commit=manifest['commit'],checkpoint_sha256=CHECKPOINT_SHA,
                source_mask_stage='returned masks; no peak pooling',qualified=False)
    with path.with_suffix('.json').open('x')as stream:json.dump(report,stream,indent=2);stream.write('\n')
    return response


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir',required=True)
    parser.add_argument('--model',required=True)
    parser.add_argument('--frames',required=True,type=int)
    args=parser.parse_args()
    try:
        from contextlib import redirect_stdout
        with redirect_stdout(sys.stderr):response=run(args)
        sys.stdout.buffer.write(response);sys.stdout.buffer.flush()
    except Exception as error:
        print(type(error).__name__+': '+str(error)[:1500],file=sys.stderr);raise SystemExit(1)
