#!/usr/bin/env python3
"""Private, unqualified Essentia key candidate on the original prepared clock.

No confidence calibration or automatic musical decisions are provided.  The
frozen prospective recipe is separate from the product's harmony protocol.
"""
import argparse
import hashlib
import json
import math
import sys

RATE, CHANNELS, MAX_FRAMES = 48000, 2, 33554432
CELL, SUPPORT, FFT = 192000, 768000, 4096
MAX_OUTPUT = 128 * 1024
RECIPE = 'private-essentia-bgate36-48k-v1'
PARAMETERS = dict(averageDetuningCorrection=True, frameSize=FFT, hopSize=FFT,
    hpcpSize=36, maxFrequency=3500, maximumSpectralPeaks=60, minFrequency=25,
    pcpThreshold=.2, profileType='bgate', sampleRate=RATE,
    spectralPeaksThreshold=.0001, tuningFrequency=440, weightType='cosine',
    windowType='hann')
PITCHES = {'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3,
    'E': 4, 'F': 5, 'F#': 6, 'Gb': 6, 'G': 7, 'G#': 8, 'Ab': 8,
    'A': 9, 'A#': 10, 'Bb': 10, 'B': 11}


def read_source(stream, frames):
    if type(frames) is not int or not 1 <= frames <= MAX_FRAMES:
        raise ValueError('Invalid prepared frame count')
    count = frames * CHANNELS * 4
    raw = bytearray()
    while len(raw) < count:
        block = stream.read(count - len(raw))
        if not block:
            raise ValueError('Truncated prepared PCM')
        raw.extend(block)
    if stream.read(1):
        raise ValueError('Extra prepared PCM bytes')
    import numpy as np
    stereo = np.frombuffer(raw, dtype='<f4').reshape(frames, CHANNELS)
    mono = np.empty(frames, dtype=np.float32)
    for first in range(0, frames, 131072):
        block = stereo[first:first + 131072]
        if not np.isfinite(block).all():
            raise ValueError('Nonfinite prepared PCM')
        mono[first:first + len(block)] = block.mean(axis=1, dtype=np.float64)
    return mono, hashlib.sha256(raw).hexdigest()


def supports(frames):
    for first in range(0, frames, CELL):
        end = min(frames, first + CELL)
        center = (first + end) // 2
        yield first, end, max(0, center - SUPPORT // 2), min(frames, center + SUPPORT // 2)


def factory():
    import essentia.standard as es
    return es.KeyExtractor(**PARAMETERS)


def estimate(mono, first, end, support_first, support_end, backend_factory):
    window = mono[support_first:support_end]
    row = dict(first_frame=first, end_frame=end, support_first_frame=support_first,
        support_end_frame=support_end, status='Unknown', confidence='Unknown')
    if len(window) < FFT:
        row['reason'] = 'shorter-than-FFT'
        return row
    if (window == window[0]).all():
        row['reason'] = 'silence-or-DC'
        return row
    # A fresh extractor prevents state from an earlier support or track leaking
    # into this estimate; the recipe is fixed before examining musical outputs.
    key, scale, strength = backend_factory()(window)
    if key not in PITCHES or scale not in ('major', 'minor'):
        raise ValueError('Unexpected key descriptor')
    if isinstance(strength, bool):
        raise ValueError('Invalid raw key strength')
    strength = float(strength)
    if not math.isfinite(strength):
        raise ValueError('Nonfinite raw key strength')
    row.update(status='Estimated', reason='uncalibrated-profile-match',
        tonic=PITCHES[key], mode=scale, key_class=PITCHES[key] + (12 if scale == 'minor' else 0),
        raw_key=key, raw_strength=strength)
    return row


def analyze(stream, frames, mode='both', backend_factory=factory):
    if mode not in ('global', 'local', 'both'):
        raise ValueError('Invalid analysis mode')
    mono, digest = read_source(stream, frames)
    rows = []
    if mode in ('global', 'both'):
        rows.append(dict(scope='global', **estimate(mono, 0, frames, 0, frames, backend_factory)))
    if mode in ('local', 'both'):
        rows.extend(dict(scope='local', **estimate(mono, first, end, start, stop, backend_factory))
            for first, end, start, stop in supports(frames))
    header = dict(schema=1, recipe=RECIPE, frames=frames, sample_rate=RATE,
        channels=CHANNELS, pcm_sha256=digest, mode=mode, row_count=len(rows),
        cell_frames=CELL, support_frames=SUPPORT, parameters=PARAMETERS,
        confidence='Unknown', production_enabled=False)
    terminal = dict(schema=1, complete=True, row_count=len(rows))
    payload = ''.join(json.dumps(row, allow_nan=False, separators=(',', ':')) + '\n'
        for row in [header] + rows + [terminal]).encode()
    if len(payload) > MAX_OUTPUT:
        raise ValueError('Private harmony output exceeds128KiB')
    return payload


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--frames', type=int, required=True)
    parser.add_argument('--mode', choices=('global', 'local', 'both'), default='both')
    args = parser.parse_args()
    # Publish only after complete input validation and successful analysis.
    sys.stdout.buffer.write(analyze(sys.stdin.buffer, args.frames, args.mode))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(type(error).__name__ + ': ' + str(error)[:1024], file=sys.stderr)
        raise SystemExit(1)
