"""Reject wrong clocks and missing intervals instead of improving score coverage."""
from pathlib import Path
import copy, importlib.util, io, json, unittest
import numpy as np

BASE=Path(__file__).resolve().parent
def load(name,file):
    spec=importlib.util.spec_from_file_location(name,BASE/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
worker=load('local_contract_worker','worker.py');validator=load('local_contract_validator','local_validate.py')

class LocalValidationTests(unittest.TestCase):
    def fixture(self):
        frames=192001;mono=np.linspace(-.1,.1,frames,dtype=np.float32)
        raw=np.column_stack((mono,mono)).astype('<f4').tobytes()
        rows=[json.loads(v)for v in worker.analyze(io.BytesIO(raw),frames,'local',lambda:lambda samples:('Ab','minor',.7)).splitlines()]
        source=dict(schema=1,case='700002',complete=True,audio_device_opened=False,source_bytes=10,source_sha256='a'*64,
            sample_rate=48000,channels=2,prepared_frames=frames,prepared_pcm_sha256=rows[0]['pcm_sha256'])
        case=dict(id='700002',source=dict(bytes=10,sha256='a'*64),prepared_frames=frames,pcm_sha256=rows[0]['pcm_sha256'])
        return rows,source,case

    def test_exact_cells_clipped_support_and_one_frame_tail_accepted(self):
        validator.validate(*self.fixture(),worker)

    def test_missing_or_extra_window_rejected(self):
        for change in ('missing','extra'):
            rows,source,case=self.fixture()
            if change=='missing':del rows[1]
            else:rows.insert(1,copy.deepcopy(rows[1]))
            with self.assertRaises(AssertionError):validator.validate(rows,source,case,worker)

    def test_changed_support_scope_source_hash_and_clock_rejected(self):
        for field,value in (('support_first_frame',1),('end_frame',191999),('scope','global'),('first_frame',True)):
            rows,source,case=self.fixture();rows[1][field]=value
            with self.subTest(field=field),self.assertRaises(AssertionError):validator.validate(rows,source,case,worker)
        rows,source,case=self.fixture();source['prepared_pcm_sha256']='b'*64
        with self.assertRaises(AssertionError):validator.validate(rows,source,case,worker)

    def test_raw_strength_never_becomes_confidence_and_nonfinite_rejected(self):
        for field,value in (('confidence','High'),('raw_strength',float('nan')),('raw_strength',True),('key_class',8)):
            rows,source,case=self.fixture();rows[1][field]=value
            with self.subTest(field=field),self.assertRaises(AssertionError):validator.validate(rows,source,case,worker)

    def test_boolean_schema_or_counter_is_not_a_valid_integer(self):
        for target,field in (('header','schema'),('source','schema'),('terminal','schema'),('header','row_count')):
            rows,source,case=self.fixture()
            record=source if target=='source' else rows[-1] if target=='terminal' else rows[0]
            record[field]=True
            with self.subTest(target=target,field=field),self.assertRaises(AssertionError):validator.validate(rows,source,case,worker)

if __name__=='__main__':unittest.main(verbosity=2)
