"""Own a bounded CPU-only completion on both hosts; no latency qualification."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import base64
import hashlib
import io
import json
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
REMOTE = '/srv/conflux-tests/work/key-local-swd-20261030-01'
UNIT = 'conflux-key-local-swd-20261030-01.service'
IMAGE = 'sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
NAME = 'conflux-key-local-swd-20261030-01'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'ForwardAgent=no',
       '-o', 'ForwardX11=no', '-o', 'ClearAllForwardings=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'HostName=10.4.20.101', '-o', 'HostKeyAlias=[apollo.kyaulabs]:4222', '-p', '4222',
       'kyau@apollo.kyaulabs', 'python3 -']


def local():
    state = subprocess.check_output(['systemctl', '--user', 'show', UNIT,
        '--property=LoadState,MainPID'], text=True, timeout=5)
    assert 'LoadState=not-found' in state and 'MainPID=0' in state
    cmd = ['systemd-run', '--user', '--wait', '--pipe', '--collect', '--unit=' + UNIT,
        '--property=Type=exec', '--property=RuntimeMaxSec=600s', '--property=TimeoutStopSec=10s',
        '--property=KillMode=control-group', '--property=Restart=no', '--property=MemoryMax=2G',
        '--property=CPUQuota=100%', '--property=TasksMax=64', '--property=Nice=15', '--property=UMask=0077',
        '/usr/bin/python3.14', '-P', '-B', str(BASE / 'complete_two.py'), '--owned', '--host', 'laptop']
    with (BASE / 'laptop.stdout.log').open('x') as out, (BASE / 'laptop.stderr.log').open('x') as err:
        r = subprocess.run(cmd, stdout=out, stderr=err, timeout=620)
    state = subprocess.check_output(['systemctl', '--user', 'show', UNIT,
        '--property=MainPID,ControlPID,ControlGroup'], text=True, timeout=5)
    assert 'MainPID=0' in state and 'ControlPID=0' in state
    return dict(exit=r.returncode, owner_terminal=True, terminal_state=state)


def apollo():
    files = {}
    for path in (BASE / 'source').rglob('*'):
        if path.is_file(): files['source/' + str(path.relative_to(BASE / 'source'))] = path.read_bytes()
    for name in ('worker.py', 'run_corpus.py', 'complete_two.py', 'local_validate.py'):
        files[name] = (BASE / name).read_bytes()
    plan = json.loads((BASE / 'plan-laptop.json').read_text())
    for case in plan['cases']:
        source=Path(case['source']['path']);raw=source.read_bytes()
        assert len(raw)==case['source']['bytes'] and hashlib.sha256(raw).hexdigest()==case['source']['sha256']
        files['media/'+source.name]=raw
    plan.update(unit='', python_command='/runtime/venv/bin/python', python_support='/runtime/support',
                preparer=dict(path='/experiment/native/prepare-fmak-source'),
                worker=dict(path='/experiment/worker.py'), input_pins=[])
    # Native/runtime pins are filled and verified inside the isolated container
    # before either original source is opened or the estimator is started.
    files['plan-apollo-draft.json'] = (json.dumps(plan, indent=2) + '\n').encode()
    manifest = [dict(file=n, bytes=len(v), sha256=hashlib.sha256(v).hexdigest()) for n, v in files.items()]
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w:gz') as archive:
        for n, raw in files.items():
            info = tarfile.TarInfo(n); info.size = len(raw); info.mode = 0o600
            archive.addfile(info, io.BytesIO(raw))
    assert len(buf.getvalue()) <= 16*1024*1024
    remote = r'''
from pathlib import Path,PurePosixPath
import base64,hashlib,io,json,subprocess,tarfile
base=Path(REMOTE);base.mkdir(mode=0o700)
with tarfile.open(fileobj=io.BytesIO(base64.b64decode(ARCHIVE,validate=True)),mode='r:gz')as archive:
 assert set(archive.getnames())=={r['file']for r in MANIFEST}
 for row in MANIFEST:
  n=PurePosixPath(row['file']);assert not n.is_absolute()and'..'not in n.parts
  info=archive.getmember(str(n));assert info.isfile()and info.size==row['bytes']
  raw=archive.extractfile(info).read();assert hashlib.sha256(raw).hexdigest()==row['sha256']
  p=base/str(n);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
(base/'source-manifest.json').write_text(json.dumps(MANIFEST,indent=2)+'\n')
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}'],timeout=5))=='/srv/conflux-tests/docker-data'
assert not subprocess.check_output(D+['ps','-aq','--filter','name=^/'+NAME+'$'],text=True,timeout=5).strip()
inside="""from pathlib import Path
import hashlib,json,subprocess
base=Path('/experiment')
assert not any(Path(p).exists()for p in('/dev/nvidia0','/dev/dri','/dev/snd'))
steps=[]
for index,cmd in enumerate([['cmake','-S','/experiment/source','-B','/experiment/native','-G','Ninja','-DCMAKE_BUILD_TYPE=Release'],['cmake','--build','/experiment/native','-j1']]):
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);steps.append(dict(command=cmd,exit=r.returncode))
 (base/('build-'+str(index)+'.stdout.log')).write_text(r.stdout);(base/('build-'+str(index)+'.stderr.log')).write_text(r.stderr)
 assert r.returncode==0,r.stderr[:1000]
def pin(p):
 p=Path(p);assert p.is_file()and not p.is_symlink()
 with p.open('rb')as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=sha)
plan=json.loads((base/'plan-apollo-draft.json').read_text())
plan['preparer']=pin(base/'native/prepare-fmak-source');plan['worker']=pin(base/'worker.py')
plan['input_pins']=[plan['preparer'],plan['worker'],pin(base/'run_corpus.py'),pin(base/'complete_two.py'),pin(base/'local_validate.py')]
old=json.loads(Path('/runtime/corpus-01/plan.json').read_text())
for row in old['input_pins']:
 p=Path(row['path'])
 if str(p).startswith('/runtime/')and p.name not in('run_corpus.py','worker.py'):
  assert pin(p)==row;plan['input_pins'].append(row)
for case in plan['cases']:assert pin(case['source']['path'])==case['source'];plan['input_pins'].append(case['source'])
with (base/'plan-apollo.json').open('x')as f:f.write(json.dumps(plan,indent=2)+'\\n')
steps.append(dict(command=['/runtime/venv/bin/python','-P','-B','/experiment/complete_two.py','--owned','--host','apollo']))
r=subprocess.run(steps[-1]['command'],capture_output=True,text=True,timeout=550)
(base/'prediction.stdout.log').write_text(r.stdout);(base/'prediction.stderr.log').write_text(r.stderr)
(base/'process-result.json').write_text(json.dumps(dict(exit=r.returncode,steps=steps),indent=2)+'\\n')
raise SystemExit(r.returncode)
"""
runtime=Path('/srv/conflux-tests/work/essentia-key-20261029-01')
media=base/'media'
source_path='/home/kyau/projects/kyaulabs/conflux/build/m2-analysis-qualification-01/swd-metadata-admission-01/sources-original'
cmd=D+['run','--rm','--name',NAME,'--init','--runtime=runc','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--cpus=1','--memory=2g','--pids-limit=128','--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--label','org.kyaulabs.conflux.run='+NAME,'--env','CONFLUX_PRIVATE_ESSENTIA_REFERENCE=1','--env','PYTHONPATH=/runtime/support','--env','PYTHONNOUSERSITE=1','--env','OMP_NUM_THREADS=1','--env','OPENBLAS_NUM_THREADS=1','--mount','type=bind,src='+str(base)+',dst=/experiment','--mount','type=bind,src='+str(runtime)+',dst=/runtime,readonly','--mount','type=bind,src='+str(media)+',dst='+source_path+',readonly',IMAGE,'timeout','--signal=TERM','--kill-after=5s','590','python3','-B','-c',inside]
try:
 with (base/'container.stdout.log').open('x')as out,(base/'container.stderr.log').open('x')as err:r=subprocess.run(cmd,stdout=out,stderr=err,timeout=610)
finally:
 found=subprocess.run(D+['inspect',NAME],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  item=json.loads(found.stdout)[0];assert item['Image']==IMAGE and item['Config']['Labels']['org.kyaulabs.conflux.run']==NAME
  subprocess.run(D+['rm','--force',item['Id']],check=True,capture_output=True,timeout=10)
absent=not subprocess.check_output(D+['ps','-aq','--filter','name=^/'+NAME+'$'],text=True,timeout=5).strip()
receipt=dict(exit=r.returncode,container_absent=absent,hardware_or_latency_qualification=False)
(base/'owner-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));raise SystemExit(r.returncode)
'''
    code = 'REMOTE=' + repr(REMOTE) + '\nIMAGE=' + repr(IMAGE) + '\nNAME=' + repr(NAME) + \
        '\nMANIFEST=' + repr(manifest) + '\nARCHIVE=' + repr(base64.b64encode(buf.getvalue()).decode()) + '\n' + remote
    with (BASE / 'apollo.stdout.log').open('x') as out, (BASE / 'apollo.stderr.log').open('x') as err:
        r = subprocess.run(SSH, input=code, text=True, stdout=out, stderr=err, timeout=645)
    result = json.loads((BASE / 'apollo.stdout.log').read_text()) if r.returncode == 0 else dict(exit=r.returncode)
    return result


assert not (BASE / 'pair-reservation.json').exists()
with (BASE / 'pair-reservation.json').open('x') as f:
    f.write(json.dumps(dict(physical_readiness_required=False, no_automatic_retry=True,
        affected_cases=2, fixed_denominator=2, source_head='b8339e186e6d7228855d169397196ba56e0574dc')) + '\n')
with ThreadPoolExecutor(max_workers=2) as pool:
    laptop = pool.submit(local); other = pool.submit(apollo)
    results = dict(laptop=laptop.result(), apollo=other.result())
with (BASE / 'pair-owner-result.json').open('x') as f:
    f.write(json.dumps(results, indent=2) + '\n')
print(json.dumps(results), flush=True)
