#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Fixed two-source local-key report; stdlib only, no child/model/audio work."""
import csv, hashlib, io, json, re, sys
from decimal import Decimal, localcontext
from pathlib import Path
BASE = Path(__file__).resolve().parent
D = Decimal


def require(value, reason):
    if not value: raise ValueError(reason)


def decode(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, 'Duplicate JSON key'); out[key] = value
        return out
    def constant(value): raise ValueError('Nonfinite JSON constant')
    return json.loads(raw, object_pairs_hook=pairs, parse_float=D, parse_constant=constant)


def pinned(pin, limit=16777216):
    path = Path(pin['path'])
    require(not path.is_symlink() and path.is_file(), 'Pinned input type differs')
    require(type(pin['bytes']) is int and 0 < path.stat().st_size == pin['bytes'] <= limit, 'Pinned input size differs')
    raw = path.read_bytes()
    require(len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256'], 'Pinned input SHA differs')
    return raw


def key(label):
    match = re.fullmatch(r'([A-G])([#b]?):(maj|min)', label)
    require(match, 'Unsupported reference key label')
    letter, accidental, mode = match.groups()
    tonic = ({'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[letter] + {'':0,'#':1,'b':-1}[accidental]) % 12
    return tonic, {'maj':'Major','min':'Minor'}[mode]


def reference(raw):
    reader = csv.DictReader(io.StringIO(raw.decode('utf-8-sig')), delimiter=';')
    require(reader.fieldnames == ['start','end','key'], 'Reference header differs')
    spans = []
    for row in reader:
        first, end = D(row['start']) * 48000, D(row['end']) * 48000
        require(first.is_finite() and end.is_finite() and 0 <= first < end, 'Bad reference interval')
        require(not spans or first >= spans[-1][1], 'Reference overlap/order differs')
        spans.append((first, end, key(row['key'])))
    require(spans, 'Empty reference')
    return spans


def native(raw, case):
    row = decode(raw)
    require(row['schema'] == 1 and type(row['schema']) is int and row['complete'] is True, 'Native case incomplete')
    require(row['case'] == case['id'] and row['source'] == case['source']['path'] and
            row['source_sha256'] == case['source']['sha256'] and row['source_bytes'] == case['source']['bytes'], 'Native original differs')
    frames = row['prepared_frames']
    require(type(frames) is int and 0 < frames <= 8640000 and row['prepared_bytes'] == frames*8 and row['prepared_rate'] == 48000, 'Prepared geometry differs')
    require(re.fullmatch('[0-9a-f]{64}',row['prepared_pcm_sha256']) and row['analysis_status'] == 'Estimated' and
            row['recipe'] == 'local-chroma-krumhansl-v1' and row['confidence'] == 'Unknown' and row['analysis_error'] == '' and not row.get('error'), 'Analysis identity/status differs')
    windows = row['windows']; require(type(windows) is list and len(windows) == (frames+191999)//192000, 'Window denominator differs')
    for index, window in enumerate(windows):
        require(type(window['first_frame']) is int and type(window['end_frame']) is int and
                window['first_frame'] == index*192000 and window['end_frame'] == min(frames,(index+1)*192000), 'Window geometry differs')
        state = window['status']; candidates = window['candidates']; chroma = window['chroma']
        require(state in ('Estimated','Unknown','Ambiguous') and window['confidence'] == 'Unknown', 'Window status differs')
        require(type(chroma) is list and len(chroma) == 12 and all(type(x) in (int,D) and D(x).is_finite() and 0 <= x <= 1 for x in chroma), 'Chroma differs')
        require(type(candidates) is list and len(candidates) == (0 if state == 'Unknown' else 2), 'Candidate count differs')
        for candidate in candidates:
            require(type(candidate['tonic']) is int and 0 <= candidate['tonic'] <= 11 and candidate['mode'] in ('Major','Minor') and
                    type(candidate['correlation']) in (int,D) and D(candidate['correlation']).is_finite() and -1 <= candidate['correlation'] <= 1, 'Candidate differs')
    return row


def overlaps(windows, spans):
    """All arithmetic stays in Decimal source-frame units; no snapped times."""
    known = sum((b-a for a,b,label in spans),D(0)); counts = {s:D(0) for s in ('Estimated','Unknown','Ambiguous','Failed')}
    correct = top_two = D(0); details = []
    all_states = {s:D(0) for s in counts}; unlabelled_states = {s:D(0) for s in counts}
    for window in windows:
        a,b = D(window['first_frame']),D(window['end_frame']); state = window['status']
        all_states[state] += b-a
        candidates = [(x['tonic'],x['mode']) for x in window['candidates']]
        predicted = candidates[0] if state == 'Estimated' else None
        pieces = []; covered = D(0)
        for first,end,label in spans:
            left,right = max(a,first),min(b,end)
            if right <= left: continue
            extent = right-left; covered += extent; counts[state] += extent
            matched = predicted == label
            if matched: correct += extent
            if label in candidates: top_two += extent
            pieces.append({'first_frame_units':str(left),'end_frame_units':str(right),'reference':list(label),'exact_top_one':matched})
        unlabelled_states[state] += b-a-covered
        details.append({'first_frame':int(a),'end_frame':int(b),'state':state,'reference_pieces':pieces,'unlabelled_frame_units':str(b-a-covered)})
    require(sum(counts.values()) == known, 'Reference extends outside emitted source windows')
    return {'known':known,'correct':correct,'top_two':top_two,'states':counts,'windows':details,'source_maps':1,'all_source_states':all_states,'unlabelled_states':unlabelled_states}


def ratios(value):
    known,correct = value['known'],value['correct']; estimated = value['states']['Estimated']
    return {'known_frame_units':str(known),'correct_frame_units':str(correct),
            'exact_top_one_full_denominator':str(correct/known) if known else None,
            'estimated_coverage':str(estimated/known) if known else None,
            'conditional_accuracy':str(correct/estimated) if estimated else None,
            'top_two_full_denominator_secondary':str(value['top_two']/known) if known else None,
            'state_frame_units':{k:str(v) for k,v in value['states'].items()},
            'whole_source_cases_available':value['source_maps'],
            'whole_source_frame_units':str(sum(value['all_source_states'].values())) if value['source_maps'] else None,
            'whole_source_state_frame_units':{k:str(v) for k,v in value['all_source_states'].items()} if value['source_maps'] else None,
            'unlabelled_reference_state_frame_units':{k:str(v) for k,v in value['unlabelled_states'].items()} if value['source_maps'] else None}


def score(plan, outputs):
    require([x['id'] for x in plan['cases']] == ['02','03'], 'Fixed case denominator differs')
    cases = []; totals = {ann:{'known':D(0),'correct':D(0),'top_two':D(0),'states':{s:D(0) for s in ('Estimated','Unknown','Ambiguous','Failed')},'source_maps':0,
                         'all_source_states':{s:D(0) for s in ('Estimated','Unknown','Ambiguous','Failed')},
                         'unlabelled_states':{s:D(0) for s in ('Estimated','Unknown','Ambiguous','Failed')}} for ann in ('ann3','ann1','ann2')}
    for case in plan['cases']:
        pinned(case['source'])
        refs = {ann:reference(pinned(case['annotations'][ann],65536)) for ann in ('ann3','ann1','ann2')}
        item = {'id':case['id'],'operational_pass':False,'references':{}}
        try:
            path = outputs/case['output_name']; require(not path.is_symlink() and 0 < path.stat().st_size <= 131072,'Native capture size/type differs')
            raw = path.read_bytes(); require(len(raw)<=131072,'Native capture grew')
            item['native_capture_sha256'] = hashlib.sha256(raw).hexdigest(); row = native(raw,case)
            require(all(end <= row['prepared_frames'] for spans in refs.values() for first,end,label in spans), 'Native source ends before frozen reference')
            item.update(operational_pass=True,prepared_frames=row['prepared_frames'],prepared_pcm_sha256=row['prepared_pcm_sha256'],window_count=len(row['windows']))
        except (OSError,ValueError,KeyError,TypeError) as error:
            row = None; item['failure'] = str(error)[:1024]
        for ann,spans in refs.items():
            if row is None:
                known = sum((b-a for a,b,label in spans),D(0))
                value = {'known':known,'correct':D(0),'top_two':D(0),'states':{s:(known if s=='Failed' else D(0)) for s in ('Estimated','Unknown','Ambiguous','Failed')},'windows':[],'source_maps':0,'all_source_states':{s:D(0) for s in ('Estimated','Unknown','Ambiguous','Failed')},'unlabelled_states':{s:D(0) for s in ('Estimated','Unknown','Ambiguous','Failed')}}
            else: value = overlaps(row['windows'],spans)
            item['references'][ann] = {**ratios(value),'window_overlaps':value['windows'],'unlabelled_gaps_are_not_filled':True}
            for name in ('known','correct','top_two'): totals[ann][name] += value[name]
            totals[ann]['source_maps'] += value['source_maps']
            for category in ('states','all_source_states','unlabelled_states'):
                for state in value[category]: totals[ann][category][state] += value[category][state]
        cases.append(item)
    return {'schema':1,'scope':'Fixed SC06 original-source local-key diagnostic only','primary':'ann3','confidence':'Unknown',
            'operational_pass':all(x['operational_pass'] for x in cases),'qualified':False,'M2_complete':False,
            'threshold_or_recipe_tuned':False,'case_denominator':2,'cases':cases,'pooled':{a:ratios(v) for a,v in totals.items()}}


def main():
    require(len(sys.argv)==4,'Usage: score_harmony.py EXPECTED_PLAN_SHA OUTPUT_DIRECTORY NEW_SCORE_FILE')
    raw = (BASE/'plan.json').read_bytes(); require(hashlib.sha256(raw).hexdigest()==sys.argv[1],'Plan SHA differs')
    plan = decode(raw); require(plan['status']=='frozen_for_single_accuracy_assessment' and plan['helper_binary_pin'],'Draft is not executable evidence')
    pinned(plan['helper_binary_pin'],33554432); pinned(plan['worker_pin'],65536); pinned(plan['python_pin'],33554432)
    with localcontext() as context:
        context.prec = 50; result = score(plan,Path(sys.argv[2]))
    result['plan_sha256']=sys.argv[1]
    encoded=(json.dumps(result,indent=2,allow_nan=False)+'\n').encode();require(len(encoded)<=524288,'Score output exceeds512KiB')
    with Path(sys.argv[3]).open('xb') as output:output.write(encoded)
    return 0 if result['operational_pass'] else 1

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as error:
        print(type(error).__name__+': '+str(error)[:1024],file=sys.stderr);raise SystemExit(1)
