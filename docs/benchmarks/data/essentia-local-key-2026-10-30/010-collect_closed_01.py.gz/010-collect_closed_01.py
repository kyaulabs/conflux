"""Collect bounded text-only results after both CPU owners have exited."""
from pathlib import Path, PurePosixPath
import base64, hashlib, json, subprocess

BASE=Path(__file__).resolve().parent
REMOTE='/srv/conflux-tests/work/key-local-swd-20261030-01'
NAME='conflux-key-local-swd-20261030-01'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
     '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
     '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','python3 -']
remote=r'''
from pathlib import Path
import base64,hashlib,json,subprocess
base=Path(REMOTE)
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}'],text=True))=='/srv/conflux-tests/docker-data'
assert not subprocess.check_output(D+['ps','-aq','--filter','name=^/'+NAME+'$'],text=True).strip()
assert not subprocess.check_output(D+['ps','-aq','--filter','label=org.kyaulabs.conflux.run='+NAME],text=True).strip()
owner=json.loads((base/'owner-receipt.json').read_text())
assert owner['exit']==0 and owner['container_absent']
names=['owner-receipt.json','plan-apollo.json','source-manifest.json','process-result.json',
       'prediction.stdout.log','prediction.stderr.log']
names+=[str(p.relative_to(base))for p in sorted((base/'output-apollo').iterdir())if p.suffix in('.json','.stderr')]
files=[];total=0
for name in names:
 p=base/name;assert p.is_file()and not p.is_symlink()
 raw=p.read_bytes();assert len(raw)<=131072
 total+=len(raw);assert total<=1048576
 files.append(dict(file=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),base64=base64.b64encode(raw).decode()))
print(json.dumps(dict(files=files,total_bytes=total,container_absent_now=True,audio_copied=False)))
'''
r=subprocess.run(SSH,input='REMOTE='+repr(REMOTE)+'\nNAME='+repr(NAME)+'\n'+remote,
                 text=True,capture_output=True,timeout=30)
assert r.returncode==0,r.stderr
v=json.loads(r.stdout);target=BASE/'apollo-capture-01';target.mkdir(mode=0o700)
for row in v['files']:
    name=PurePosixPath(row['file']);assert not name.is_absolute()and'..'not in name.parts
    raw=base64.b64decode(row.pop('base64'),validate=True)
    assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
    p=target/str(name);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb')as f:f.write(raw)
with (target/'manifest.json').open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
state=dict(line.split('=',1)for line in subprocess.check_output(['systemctl','--user','show',NAME+'.service',
    '--property=MainPID,ControlPID,ControlGroup'],text=True).splitlines())
assert state['MainPID']==state['ControlPID']=='0'and state['ControlGroup']==''
local=json.loads((BASE/'output-laptop/receipt.json').read_text())
other=json.loads((target/'output-apollo/receipt.json').read_text())
assert local['complete']and other['complete']and not local['reference_labels_opened']and not other['reference_labels_opened']
closed=dict(schema=1,laptop_unit=state,Apollo_container_absent=True,reference_labels_opened=False,
    receipts=dict(laptop=local,apollo=other),qualified=False,both_capture_owners_retired=True)
with (BASE/'closed-before-scoring-01.json').open('x')as f:f.write(json.dumps(closed,indent=2)+'\n')
print(json.dumps(dict(files=len(v['files']),bytes=v['total_bytes'],both_owners_closed=True,audio_copied=False)))
