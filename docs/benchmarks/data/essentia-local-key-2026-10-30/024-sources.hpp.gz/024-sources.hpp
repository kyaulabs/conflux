#pragma once
#include <array>
#include <cstdint>
#include <string_view>
struct Source { std::string_view id, path, sha; std::uint64_t bytes; };
inline constexpr std::array<Source,2> sources{{
    {"700002", "/home/kyau/projects/kyaulabs/conflux/build/m2-analysis-qualification-01/swd-metadata-admission-01/sources-original/Schubert_D911-02_SC06.wav", "c6ed76aebbd7a6f2b6fe120ec4689a247a40b8aca61de209e9112d5cf6d1f3cc", 4218668},
    {"700003", "/home/kyau/projects/kyaulabs/conflux/build/m2-analysis-qualification-01/swd-metadata-admission-01/sources-original/Schubert_D911-03_SC06.wav", "40bfb7831f4260dc2340455addf2d9df15f5463cfcd729bad5e751419198418f", 6049196},
}};
