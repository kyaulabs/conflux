"""Score the closed local captures with the retained exact overlap oracle."""
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal,localcontext
import hashlib,importlib.util,json

BASE=Path(__file__).resolve().parent
SWD=BASE.parent.parent/'m2-analysis-qualification-01/swd-harmony-assessment-draft-01'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

protocol=load('closed_local_protocol',BASE/'run_corpus.py')
validator=load('closed_local_validator',BASE/'local_validate.py')
oracle=load('retained_local_overlap_oracle',SWD/'score_harmony.py')
plan=protocol.strict_json((BASE/'plan-laptop.json').read_bytes())
prospective=protocol.strict_json((BASE/'prospective-01.json').read_bytes())
closed=protocol.strict_json((BASE/'closed-before-scoring-01.json').read_bytes())
assert closed['both_capture_owners_retired']and closed['reference_labels_opened'] is False
assert [c['id']for c in plan['cases']]==['700002','700003']
assert prospective['parameters']==protocol.candidate.PARAMETERS
assert prospective['worker']['sha256']==hashlib.sha256((BASE/'worker.py').read_bytes()).hexdigest()
captures={};payloads={};source_rows={};raw_rows={}
for host,root in (('laptop',BASE/'output-laptop'),('apollo',BASE/'apollo-capture-01/output-apollo')):
    raw=(root/'predictions-before-scoring.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==closed['receipts'][host]['captures_sha256']
    captures[host]=protocol.strict_json(raw)
    assert [c['id']for c in captures[host]]==[c['id']for c in plan['cases']]
    payloads[host]={};source_rows[host]={};raw_rows[host]={}
    for case,capture in zip(plan['cases'],captures[host],strict=True):
        identifier=case['id']
        assert capture['complete']and capture['status']=='PredictionCaptured'
        assert capture['producer_reaped']and capture['consumer_reaped']and capture['spool_empty']
        assert capture['prediction_file']==identifier+'-prediction.json'
        payload=(root/capture['prediction_file']).read_bytes()
        assert len(payload)<=131072 and hashlib.sha256(payload).hexdigest()==capture['prediction_sha256']
        source=protocol.strict_json((root/(identifier+'-source.json')).read_bytes())
        assert source==capture['source']
        rows=[protocol.strict_json(line)for line in payload.splitlines()]
        validator.validate(rows,source,case,protocol.candidate)
        payloads[host][identifier]=payload;source_rows[host][identifier]=source;raw_rows[host][identifier]=rows[1:-1]
for case in plan['cases']:
    assert source_rows['laptop'][case['id']]==source_rows['apollo'][case['id']]
validation=dict(schema=1,owners_closed=True,prepared_PCM_and_frames_match_both_hosts=True,
    all_59_windows_per_host_validated=True,reference_labels_opened=False,qualified=False)
protocol.store(BASE/'validated-before-scoring-01.json',validation)

def windows(rows):
    return [dict(first_frame=r['first_frame'],end_frame=r['end_frame'],status=r['status'],
        candidates=[dict(tonic=r['tonic'],mode='Major'if r['mode']=='major'else'Minor')]if r['status']=='Estimated'else[])for r in rows]

def metrics(v):
    known=v['known'];estimated=v['states']['Estimated']
    return dict(known_frame_units=str(known),correct_frame_units=str(v['correct']),
        exact_top_one_full_denominator=str(v['correct']/known)if known else None,
        estimated_coverage=str(estimated/known)if known else None,
        conditional_accuracy=str(v['correct']/estimated)if estimated else None,
        state_frame_units={k:str(x)for k,x in v['states'].items()},
        whole_source_state_frame_units={k:str(x)for k,x in v['all_source_states'].items()},
        unlabelled_reference_state_frame_units={k:str(x)for k,x in v['unlabelled_states'].items()},
        top_two_available=False)

# Source/hash/clock and owner closure checks precede reference parsing.
references={c['id']:{a:oracle.reference(oracle.pinned(c['annotations'][a],65536))for a in('ann3','ann1','ann2')}for c in plan['cases']}
hosts={}
with localcontext()as context:
    context.prec=50
    for host in('laptop','apollo'):
        pooled={};cases=[]
        for case in plan['cases']:
            identifier=case['id'];item=dict(id=case['reference_id'],prediction_id=identifier,references={})
            mapped=windows(raw_rows[host][identifier])
            for ann in('ann3','ann1','ann2'):
                scored=oracle.overlaps(mapped,references[identifier][ann])
                item['references'][ann]={**metrics(scored), 'window_overlaps':scored['windows']}
                if ann not in pooled:
                    pooled[ann]={k:(dict(v)if isinstance(v,dict)else v)for k,v in scored.items()if k!='windows'}
                else:
                    for k in('known','correct','top_two','source_maps'):pooled[ann][k]+=scored[k]
                    for category in('states','all_source_states','unlabelled_states'):
                        for k,v in scored[category].items():pooled[ann][category][k]+=v
            cases.append(item)
        hosts[host]=dict(cases=cases,pooled={a:metrics(v)for a,v in pooled.items()},qualified=False)

agreement=0;differences=[]
for c in plan['cases']:
    identifier=c['id']
    for left,right in zip(raw_rows['laptop'][identifier],raw_rows['apollo'][identifier],strict=True):
        agreement+=((left['status'],left.get('key_class'))==(right['status'],right.get('key_class')))
        if left['status']==right['status']=='Estimated':differences.append(abs(left['raw_strength']-right['raw_strength']))
report=dict(schema=1,scored_utc=datetime.now(timezone.utc).isoformat(),recipe=plan['recipe'],
    mode='local',cell_frames=192000,support_frames=768000,primary='ann3',case_denominator=2,windows_per_host=59,
    hosts=hosts,baseline_primary=protocol.strict_json((SWD/'root-assessment-summary-01.json').read_bytes())['primary_pooled'],
    exact_byte_identical_source_predictions=sum(payloads['laptop'][c['id']]==payloads['apollo'][c['id']]for c in plan['cases']),
    cross_host_class_or_Unknown_agreement_windows=agreement,maximum_absolute_raw_strength_difference=max(differences,default=None),
    reference_read_after_source_capture_validation=True,recipe_or_threshold_tuned=False,
    confidence='Unknown',qualified=False,production_backend_enabled=False,hardware_or_latency_qualified=False,
    milestone_or_release_gate_closed=False,
    scope='Two exposed voice/piano recordings, complete duration-weighted local-key truth. No independent genre holdout, confidence calibration or musical acceptance.')
protocol.store(BASE/'scores-01.json',report)
print(json.dumps(dict(hosts={h:hosts[h]['pooled']['ann3']for h in hosts},cross_host_agreement_windows=agreement,
    byte_identical_source_predictions=report['exact_byte_identical_source_predictions'],qualified=False)))
