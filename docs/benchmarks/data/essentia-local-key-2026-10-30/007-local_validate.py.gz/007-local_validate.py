"""Validate the frozen local source geometry before opening key references."""
import math

def validate(value,source,case,worker):
    frames=case['prepared_frames'];count=(frames+worker.CELL-1)//worker.CELL
    assert type(value)is list and len(value)==count+2
    header,*rows,terminal=value
    for record,keys in ((header,('schema','frames','row_count','sample_rate','channels','cell_frames','support_frames')),
                        (source,('schema','source_bytes','prepared_frames','sample_rate','channels')),
                        (terminal,('schema','row_count'))):
        assert all(type(record[k])is int for k in keys)
    assert 1<=frames<=worker.MAX_FRAMES
    assert header['schema']==source['schema']==terminal['schema']==1
    assert terminal['complete'] is True and type(terminal['row_count'])is int and terminal['row_count']==count
    assert source['case']==case['id'] and source['complete'] is True and source['audio_device_opened'] is False
    assert source['source_bytes']==case['source']['bytes'] and source['source_sha256']==case['source']['sha256']
    assert type(header['frames'])is int and header['frames']==source['prepared_frames']==frames
    assert header['pcm_sha256']==source['prepared_pcm_sha256']==case['pcm_sha256']
    assert header['recipe']==worker.RECIPE and header['mode']=='local' and header['row_count']==count
    assert header['parameters']==worker.PARAMETERS and all(type(header['parameters'][k])is type(v)for k,v in worker.PARAMETERS.items())
    assert header['production_enabled'] is False and header['confidence']=='Unknown'
    assert header['sample_rate']==source['sample_rate']==48000 and header['channels']==source['channels']==2
    assert header['cell_frames']==192000 and header['support_frames']==768000
    for i,row in enumerate(rows):
        first=i*192000;end=min(frames,first+192000);center=(first+end)//2
        assert row['scope']=='local' and row['confidence']=='Unknown'
        expected=dict(first_frame=first,end_frame=end,support_first_frame=max(0,center-384000),support_end_frame=min(frames,center+384000))
        assert all(type(row[k])is int and row[k]==v for k,v in expected.items())
        if row['status']=='Estimated':
            assert row['reason']=='uncalibrated-profile-match'
            assert type(row['tonic'])is int and 0<=row['tonic']<12 and row['mode']in('major','minor')
            assert row['raw_key']in worker.PITCHES and worker.PITCHES[row['raw_key']]==row['tonic']
            assert type(row['key_class'])is int and row['key_class']==row['tonic']+(12 if row['mode']=='minor'else 0)
            assert type(row['raw_strength'])in(int,float) and math.isfinite(row['raw_strength'])
        else:
            assert row['status']=='Unknown' and row['reason']in('shorter-than-FFT','silence-or-DC')
            assert not any(k in row for k in('tonic','mode','key_class','raw_key','raw_strength'))
            assert (row['reason']=='shorter-than-FFT')==(expected['support_end_frame']-expected['support_first_frame']<4096)
    return None
