"""Fixed CPU-only whole-track predictions; never load reference labels."""
from pathlib import Path
import argparse,hashlib,json,os,re,signal,subprocess,time
RECIPE='private-essentia-bgate36-48k-v1'
import importlib.util, math
STOP=Path(__file__).resolve().parent/'stop'
class ChildCleanupError(RuntimeError):pass
spec=importlib.util.spec_from_file_location('fixed_essentia_candidate',Path(__file__).with_name('worker.py'))
candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
assert candidate.RECIPE==RECIPE

def strict_json(raw):
 def pairs(items):
  out={}
  for key,value in items:
   if key in out:raise ValueError('Duplicate JSON field')
   out[key]=value
  return out
 return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda value:(_ for _ in()).throw(ValueError('Nonfinite JSON number')))

def store(path,value):
 with path.open('x')as f:
  f.write(json.dumps(value,indent=2,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())

def verify(row):
 p=Path(row['path']);assert p.is_file()and not p.is_symlink()
 assert p.stat().st_size==row['bytes']
 with p.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256']

def validate(value,source,case):
 assert type(value)is list and len(value)==3 and all(type(row)is dict for row in value)
 header,row,terminal=value
 assert type(header['schema'])is int and header['schema']==source['schema']==terminal['schema']==1
 assert type(terminal['schema'])is int and terminal['complete']is True
 assert type(terminal['row_count'])is int and terminal['row_count']==1
 assert type(header['row_count'])is int and header['row_count']==1 and header['mode']=='global'
 assert source['case']==case['id']and source['complete']is True and source['audio_device_opened']is False
 assert source['source_bytes']==case['source']['bytes']and source['source_sha256']==case['source']['sha256']
 assert type(header['frames'])is int and 1<=header['frames']<=candidate.MAX_FRAMES
 assert source['prepared_frames']==header['frames']==case['prepared_frames']
 assert header['pcm_sha256']==source['prepared_pcm_sha256']==case['pcm_sha256']
 assert header['recipe']==RECIPE and type(header['parameters'])is dict and header['parameters']==candidate.PARAMETERS
 assert all(type(header['parameters'][key])is type(expected)for key,expected in candidate.PARAMETERS.items())
 assert header['production_enabled']is False and header['confidence']==row['confidence']=='Unknown'
 for key,expected in [('sample_rate',48000),('channels',2),('cell_frames',candidate.CELL),('support_frames',candidate.SUPPORT)]:
  assert type(header[key])is int and header[key]==expected
 assert source['sample_rate']==48000 and source['channels']==2 and row['scope']=='global'
 for key,expected in [('first_frame',0),('end_frame',case['prepared_frames']),('support_first_frame',0),('support_end_frame',case['prepared_frames'])]:
  assert type(row[key])is int and row[key]==expected
 if row['status']=='Estimated':
  assert header['frames']>=candidate.FFT and row['reason']=='uncalibrated-profile-match'
  assert type(row['tonic'])is int and 0<=row['tonic']<12 and row['mode']in('major','minor')
  assert row['raw_key']in candidate.PITCHES and candidate.PITCHES[row['raw_key']]==row['tonic']
  assert type(row['key_class'])is int and row['key_class']==row['tonic']+(12 if row['mode']=='minor'else 0)
  assert type(row['raw_strength'])in(int,float)and math.isfinite(row['raw_strength'])
  return row['key_class']
 assert row['status']=='Unknown'and row['reason']in('shorter-than-FFT','silence-or-DC')
 assert not any(key in row for key in('tonic','mode','key_class','raw_key','raw_strength'))
 assert (row['reason']=='shorter-than-FFT')==(header['frames']<candidate.FFT)
 return None

def reap(children):
 failures=[]
 for child in children:
  if child is None:continue
  if child.poll()is None:
   try:os.killpg(child.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:child.wait(timeout=2)
   except subprocess.TimeoutExpired:
    try:os.killpg(child.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    try:child.wait(timeout=2)
    except subprocess.TimeoutExpired:failures.append(child.pid)
  if child.stdout is not None and not child.stdout.closed:child.stdout.close()
 if failures:raise ChildCleanupError('Owned pipeline reap not proven: '+str(failures))

def predict(plan,case,output):
 identifier=case['id'];assert re.fullmatch(r'[0-9]{6}',identifier)
 spool=output/('spool-'+identifier);spool.mkdir(mode=0o700)
 source_path=output/(identifier+'-source.json');prediction_path=output/(identifier+'-prediction.json');error_path=output/(identifier+'-worker.stderr')
 producer=consumer=None;began=time.monotonic()
 try:
  with source_path.open('xb')as metadata,prediction_path.open('xb')as prediction,error_path.open('xb')as errors:
   producer=subprocess.Popen([plan['preparer']['path'],identifier,str(spool),'--pcm'],stdout=subprocess.PIPE,stderr=metadata,start_new_session=True)
   environment=os.environ.copy()
   environment.update(PYTHONPATH=plan['python_support'],PYTHONNOUSERSITE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
   consumer=subprocess.Popen([plan['python_command'],'-P','-B',plan['worker']['path'],'--frames',str(case['prepared_frames']),'--mode','local'],stdin=producer.stdout,stdout=prediction,stderr=errors,start_new_session=True,env=environment)
   producer.stdout.close()
   while consumer.poll()is None or producer.poll()is None:
    if STOP.exists():raise InterruptedError('Operator stopped the CPU-only comparison')
    assert time.monotonic()-began<160,'Original 160-second case budget exhausted'
    assert os.fstat(prediction.fileno()).st_size<=16384 and os.fstat(metadata.fileno()).st_size<=4096 and os.fstat(errors.fileno()).st_size<=4096
    time.sleep(.05)
   assert producer.wait()==consumer.wait()==0,'Fixed preparation or candidate worker failed'
  assert prediction_path.stat().st_size<=16384 and source_path.stat().st_size<=4096 and error_path.stat().st_size<=4096
  assert not list(spool.iterdir()),'Anonymous source spool still contains files'
  source=strict_json(source_path.read_bytes());value=[strict_json(line)for line in prediction_path.read_bytes().splitlines()];key=validate(value,source,case)
  return dict(id=identifier,status='PredictionCaptured',complete=True,predicted_class=key,confidence='Unknown',elapsed_seconds=time.monotonic()-began,
   source=source,prediction_sha256=hashlib.sha256(prediction_path.read_bytes()).hexdigest(),prediction_file=prediction_path.name,
   producer_reaped=producer.poll()is not None,consumer_reaped=consumer.poll()is not None,spool_empty=True)
 finally:
  reap((producer,consumer))


def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--owned',action='store_true');parser.add_argument('--plan',type=Path);parser.add_argument('--output',type=Path);args=parser.parse_args()
 if not args.owned:
  print(json.dumps(dict(unarmed=True,source_opened=False,reference_labels_opened=False,GPU_or_audio_opened=False)));return 0
 assert args.plan and args.output
 plan=strict_json(args.plan.read_bytes());assert plan['status']=='frozen_CPU_correctness_only'and plan['physical_readiness_required']is False and plan['recipe']==RECIPE
 if plan['host']=='laptop':assert any(s.endswith('/'+plan['unit'])for s in Path('/proc/self/cgroup').read_text().splitlines())
 else:assert plan['host']=='apollo'and os.environ.get('CONFLUX_PRIVATE_ESSENTIA_REFERENCE')=='1'and not Path('/dev/nvidia0').exists()and not Path('/dev/dri').exists()
 assert len(plan['cases'])==24 and len({c['id']for c in plan['cases']})==24
 assert all(re.fullmatch(r'[0-9]{6}',c['id'])for c in plan['cases'])
 for row in plan['input_pins']:verify(row)
 began=time.monotonic();deadline=began+1200;output=args.output;output.mkdir(mode=0o700)
 captures=[]
 for case in plan['cases']:
  if case['preparation_status']!='PreparedMetadataMeasured':
   row=dict(id=case['id'],complete=False,status='SourcePreparationFailed',error=case['error'],analysis_started=False)
  elif STOP.exists():
   row=dict(id=case['id'],complete=False,status='NotRunOperatorStop',analysis_started=False)
  elif time.monotonic()+160>=deadline:
   row=dict(id=case['id'],complete=False,status='NotRunBudget',analysis_started=False)
  else:
   try:row=predict(plan,case,output);row['analysis_started']=True
   except ChildCleanupError:raise
   except Exception as error:row=dict(id=case['id'],complete=False,status='InferenceFailed',error=dict(type=type(error).__name__,message=str(error)[:1024]))
  store(output/(case['id']+'-capture.json'),row);captures.append(row)
  print(json.dumps(dict(id=case['id'],status=row['status'])),flush=True)
 closed=output/'predictions-before-scoring.json';store(closed,captures)
 for row in plan['input_pins']:verify(row)
 assert time.monotonic()<deadline
 receipt=dict(schema=1,completed_captures=24,inferred=sum(c['complete']for c in captures),fixed_denominator=24,
  operator_stopped=STOP.exists(),all_inferable_sources_completed=not STOP.exists()and all(c['complete']for case,c in zip(plan['cases'],captures,strict=True)if case['preparation_status']=='PreparedMetadataMeasured'),
  closed_capture_sha256=hashlib.sha256(closed.read_bytes()).hexdigest(),reference_labels_opened=False,confidence='Unknown',qualified=False,
  input_pins_unchanged=True,elapsed_seconds=time.monotonic()-began,hardware_or_latency_qualification=False,GPU_or_audio_opened=False)
 store(output/'prediction-receipt.json',receipt);print(json.dumps(receipt),flush=True)
 return 0 if receipt['all_inferable_sources_completed']else 1

if __name__=='__main__':raise SystemExit(main())
