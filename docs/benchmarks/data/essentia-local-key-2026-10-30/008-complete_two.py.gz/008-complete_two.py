"""Capture the unchanged local recipe; references remain unopened."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, time

BASE=Path(__file__).resolve().parent

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value

def run(host):
    plan=json.loads((BASE/('plan-'+host+'.json')).read_text())
    assert plan['physical_readiness_required'] is False and plan['fixed_denominator']==2
    assert plan['mode']=='local' and [c['id']for c in plan['cases']]==['700002','700003']
    if host=='laptop':
        assert any(s.endswith('/'+plan['unit'])for s in Path('/proc/self/cgroup').read_text().splitlines())
    else:
        assert host=='apollo' and os.environ.get('CONFLUX_PRIVATE_ESSENTIA_REFERENCE')=='1'
        assert not any(Path(p).exists()for p in('/dev/nvidia0','/dev/dri','/dev/snd'))
    protocol=module('local_capture_protocol',BASE/'run_corpus.py')
    validator=module('local_capture_validation',BASE/'local_validate.py')
    protocol.validate=lambda value,source,case:validator.validate(value,source,case,protocol.candidate)
    for row in plan['input_pins']:protocol.verify(row)
    output=BASE/('output-'+host);output.mkdir(mode=0o700)
    begun=time.monotonic();captures=[]
    for case in plan['cases']:
        assert time.monotonic()-begun<350
        try:
            row=protocol.predict(plan,case,output)
            row.pop('predicted_class')
            row.update(analysis_started=True,local_windows=(case['prepared_frames']+191999)//192000)
        except protocol.ChildCleanupError:
            raise
        except Exception as error:
            row=dict(id=case['id'],complete=False,status='InferenceFailed',error=dict(type=type(error).__name__,message=str(error)[:1024]))
        captures.append(row);protocol.store(output/(case['id']+'-capture.json'),row)
        print(json.dumps(dict(id=case['id'],status=row['status'],complete=row['complete'])),flush=True)
    for row in plan['input_pins']:protocol.verify(row)
    protocol.store(output/'predictions-before-scoring.json',captures)
    receipt=dict(schema=1,host=host,complete=all(r['complete']for r in captures),fixed_source_denominator=2,
        expected_local_windows=59,recipe=plan['recipe'],mode='local',source_head=plan['source_head'],
        reference_labels_opened=False,confidence='Unknown',qualified=False,hardware_or_latency_qualification=False,
        elapsed_seconds=time.monotonic()-begun,
        captures_sha256=hashlib.sha256((output/'predictions-before-scoring.json').read_bytes()).hexdigest())
    protocol.store(output/'receipt.json',receipt);print(json.dumps(receipt),flush=True)
    return 0 if receipt['complete'] else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--owned',action='store_true');parser.add_argument('--host',choices=('laptop','apollo'))
    args=parser.parse_args()
    if args.owned:
        assert args.host;raise SystemExit(run(args.host))
    print(json.dumps(dict(unarmed=True,reference_labels_opened=False,hardware_started=False)))
