"""Freeze the existing local estimator on the two previously admitted SWD sources."""
from pathlib import Path
import ast, hashlib, json

BASE=Path(__file__).resolve().parent
NEW=BASE/'local-swd-01'
OLD=BASE/'padded-corpus-01'
SWD=BASE.parent/'m2-analysis-qualification-01/swd-harmony-assessment-draft-01'
assert not NEW.exists();NEW.mkdir(mode=0o700)

def pin(p):
    p=Path(p);assert p.is_file() and not p.is_symlink()
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def save(p,v):
    with p.open('x')as f:f.write(json.dumps(v,indent=2)+'\n')

original=json.loads((SWD/'plan.json').read_text())
geometry={r['case']:r for r in json.loads((SWD/'output-01/root-native-map-binding-01.json').read_text())['cases']}
cases=[]
for case in original['cases']:
    identifier='7000'+case['id'];source=case['source']
    assert pin(source['path'])==source
    prior=geometry[case['id']]
    cases.append(dict(id=identifier,reference_id=case['id'],source=source,
        preparation_status='PreparedMetadataMeasured',prepared_frames=prior['prepared_frames'],
        pcm_sha256=prior['prepared_pcm_sha256'],annotations=case['annotations']))

source=NEW/'source';source.mkdir()
for p in (OLD/'source').rglob('*'):
    if p.is_file():
        q=source/p.relative_to(OLD/'source');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
header='#pragma once\n#include <array>\n#include <cstdint>\n#include <string_view>\nstruct Source { std::string_view id, path, sha; std::uint64_t bytes; };\ninline constexpr std::array<Source,2> sources{{\n'
for c in cases:
    header+='    {'+', '.join(json.dumps(s)for s in (c['id'],c['source']['path'],c['source']['sha256']))+', '+str(c['source']['bytes'])+'},\n'
header+='}};\n';(source/'sources.hpp').write_text(header)
q=source/'prepare_source.cpp';text=q.read_text()
start=text.index('    const auto source = std::string(')
end=text.index('    std::stop_source cancelled;',start)
text=text[:start]+'    const auto source = std::string(found->path);\n'+text[end:]
text=text.replace('// Fixed FMAK source whitelist','// Fixed SWD source whitelist')
q.write_text(text)
(NEW/'worker.py').write_bytes((BASE/'worker.py').read_bytes())
protocol=(OLD/'run_corpus.py').read_text()
needle="'--mode','global'";assert protocol.count(needle)==1
protocol=protocol.replace(needle,"'--mode','local'")
(NEW/'run_corpus.py').write_text(protocol)

old_plan=json.loads((OLD/'plan-laptop.json').read_text())
plan=dict(schema=1,status='frozen_CPU_correctness_only',host='laptop',
    source_head=old_plan['source_head'],unit='conflux-key-local-swd-20261030-01.service',
    physical_readiness_required=False,fixed_denominator=2,cases=cases,
    recipe='private-essentia-bgate36-48k-v1',mode='local',cell_frames=192000,support_frames=768000,
    python_command=old_plan['python_command'],python_support='',input_pins=[],
    preparer=dict(path=str(NEW/'native/prepare-fmak-source')),
    worker=pin(NEW/'worker.py'),parameters_fitted=False,confidence='Unknown',qualified=False,
    reference_policy='ann3 primary; ann1 and ann2 sensitivity; exact Decimal source-frame overlaps; missing/Unknown count in full known-time denominator; no top-two claim for a one-candidate estimator',
    source_selection='Same two complete SC06 recordings as the retained local-key assessment; exposed comparison, not independent holdout',
    no_source_audio_redistribution=True,no_hardware_audio_GPU_or_latency_qualification=True,
    before_scoring='Both capture owners must be retired and every source/PCM/row validated before parsing annotations')
for row in old_plan['input_pins']:
    if not str(row['path']).startswith(str(OLD)) and row['path'] not in [c['source']['path']for c in old_plan['cases']]:
        plan['input_pins'].append(row)
for c in cases:plan['input_pins'].append(c['source'])
save(NEW/'plan-laptop-draft.json',plan)
save(NEW/'prospective-01.json',dict(schema=1,recipe=plan['recipe'],parameters=json.loads((BASE/'prospective-plan-01.json').read_text())['parameters'],
    mode='local',cell_frames=192000,support_frames=768000,cases=cases,
    primary_reference='ann3',metric='Duration-weighted exact tonic/mode over all known annotated source time; unchanged Decimal overlap scorer',
    source_preparation=old_plan['source_head'],worker=pin(NEW/'worker.py'),
    baseline_score=pin(SWD/'output-01/score-01.json'),qualified=False,parameters_fitted=False,
    real_music_started=False,physical_readiness_required=False))
save(NEW/'source-manifest.json',dict(files=[dict(file=str(p.relative_to(source)),**{k:v for k,v in pin(p).items()if k!='path'})for p in sorted(source.rglob('*'))if p.is_file()],
    AudioFile_cpp_matches_signed_source=pin(source/'src/audio/AudioFile.cpp')['sha256']==pin(OLD/'source/src/audio/AudioFile.cpp')['sha256']))
for p in NEW.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
print(json.dumps(dict(prepared=str(NEW),source_cases=2,local_cells_expected=59,hardware_started=False)))
