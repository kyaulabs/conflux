"""Preserve one human condition record and deadline across both comparison arms."""
import hashlib
import json


def validate_initial_cache(case):
    expected = json.loads((case / 'driver-cache-initial-01.json').read_text())['files']
    directory = case / 'driver-cache'
    actual = []
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink(), 'Driver cache must contain regular private files'
        if path.is_file():
            raw = path.read_bytes()
            actual.append(dict(relative_path=str(path.relative_to(directory)), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest()))
    assert actual == expected, 'Initial driver cache changed before this comparison arm'


def validate_pair(base, human, arm, now):
    shared = json.loads((base / 'pair-readiness-received-01.json').read_text())
    assert arm in ('baseline', 'candidate')
    assert shared['schema'] == 1 and shared['order'] == ['baseline', 'candidate']
    assert shared['operator_seconds'] == 1200 and shared['retries'] is False
    origin = shared['original_readiness_monotonic']
    assert shared['operator_deadline_monotonic'] == origin + 1200
    assert 0 <= now - origin <= 600, 'Insufficient original pair room; no renewed clock'
    assert human['recorded_at_utc'] == shared['original_readiness_utc']
    assert human['recorded_at_monotonic'] == origin
    assert human['question_item_id'] == shared['question_item_id']
    assert human['human_reply'] == shared['human_reply']
    if arm == 'candidate':
        first = base / 'cases/baseline'
        closed = json.loads((first / 'root-finished-01.json').read_text())
        assessed = json.loads((first / 'diagnostic-assessment.json').read_text())
        assert closed['cleanup_complete'] is True and closed['requested120s_complete'] is True
        assert assessed['diagnostic_complete'] is True
        # UTC age is reprojected at dispatch and can shorten the bound.
        # Bind the original human record exactly; never extend its deadline.
        assert closed['original_readiness_monotonic'] == origin
        assert closed['original_readiness_utc'] == shared['original_readiness_utc']
        assert (origin <= closed['root_verification_monotonic']
            <= closed['operator_deadline_monotonic'] <= shared['operator_deadline_monotonic'])
    return shared
