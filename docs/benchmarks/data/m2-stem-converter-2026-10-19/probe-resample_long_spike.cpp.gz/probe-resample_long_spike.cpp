// Source-only experiment. Root compiles/runs this; it is not a product test.
#include "audio/AudioFile.hpp"
#include <samplerate.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <limits>
#include <memory>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>
#include <unistd.h>

namespace {
constexpr std::size_t channels = 2, block = 4096, hop = 257985;
constexpr double ratio = 48000.0 / 44100.0;
using Pcm = std::vector<float>;
using State = std::unique_ptr<SRC_STATE, decltype(&src_delete)>;
void require(bool value, const char* message) { if (!value) throw std::runtime_error(message); }
State state() { int error = 0; State s(src_new(SRC_SINC_BEST_QUALITY, 2, &error), src_delete);
    require(bool(s) && !error, "src_new failed"); return s; }

Pcm fixture(std::size_t frames, unsigned role)
{
    Pcm pcm(frames * channels);
    for (std::size_t f = 0; f < frames; ++f) {
        pcm[f * 2] = float(int((f * (11 + role * 2) + role * 73) % 1543) - 771) / 512.F;
        pcm[f * 2 + 1] = float(.37 * std::sin((f + 7 * role) * (.011 + role * .003)));
        if (f == 0 || f == 4095 || f == 4096 || f == hop - 1 || f == hop || f == frames - 1)
            pcm[f * 2] += (role & 1) ? -.75F : .75F;
    }
    return pcm;
}

struct Descriptor {
    int fd = -1;
    ~Descriptor() { if (fd >= 0) ::close(fd); }
};
Pcm preparedReference(std::span<const float> input)
{
    auto name = (std::filesystem::temp_directory_path() / "conflux-src-spike-XXXXXX").string();
    Descriptor raw{::mkstemp(name.data())};
    require(raw.fd >= 0, "Cannot create synthetic raw input");
    if (::unlink(name.c_str()) != 0) throw std::runtime_error("Cannot unlink synthetic raw input");
    std::array<unsigned char, block * 8> bytes{};
    for (std::size_t first = 0; first < input.size();) {
        const auto count = std::min(bytes.size() / 4, input.size() - first);
        for (std::size_t i = 0; i < count; ++i) {
            const auto bits = std::bit_cast<std::uint32_t>(input[first + i]);
            for (unsigned b = 0; b < 4; ++b) bytes[i * 4 + b] = static_cast<unsigned char>(bits >> (8 * b));
        }
        for (std::size_t written = 0; written < count * 4;) {
            const auto got = ::write(raw.fd, bytes.data() + written, count * 4 - written);
            require(got > 0, "Synthetic input write failed"); written += std::size_t(got);
        }
        first += count;
    }
    const auto n = input.size() / 2;
    auto converted = conflux::audio::prepareStemOutput(raw.fd, n, (n * 2 + 8192) * 8);
    Pcm result(converted.frames() * 2);
    auto* out = reinterpret_cast<char*>(result.data());
    for (std::size_t read = 0; read < result.size() * sizeof(float);) {
        const auto got = ::pread(converted.descriptor(), out + read, result.size() * sizeof(float) - read, off_t(read));
        require(got > 0, "Prepared reference read failed"); read += std::size_t(got);
    }
    return result;
}

struct ZeroInput {
    std::size_t remaining;
    std::array<float, block * 2> zero{};
    static long read(void* context, float** data) noexcept {
        auto& self = *static_cast<ZeroInput*>(context); *data = self.zero.data();
        const auto count = std::min(block, self.remaining); self.remaining -= count; return long(count);
    }
};
std::size_t callbackCount(std::size_t n)
{
    ZeroInput input{n}; int error = 0;
    State s(src_callback_new(ZeroInput::read, SRC_SINC_BEST_QUALITY, 2, &error, &input), src_delete);
    require(bool(s) && !error, "Callback count state failed");
    std::array<float, block * 2> output{}; std::size_t total = 0;
    for (std::size_t calls = 0; calls < n * 2 + 64; ++calls) {
        const auto got = src_callback_read(s.get(), ratio, block, output.data());
        require(got >= 0 && !src_error(s.get()), "Callback count failed");
        if (!got) { require(input.remaining == 0, "Callback count skipped input"); return total; }
        total += std::size_t(got);
    }
    throw std::runtime_error("Callback count did not terminate");
}

struct Run { Pcm pcm; std::size_t frames = 0, calls = 0, inputUsed = 0, zeroFlushCalls = 0; };
Run process(std::span<const float> input, std::span<const std::size_t> inPlan,
            std::span<const std::size_t> outPlan, bool lastPositiveEof, bool countOnly = false,
            bool finish = true)
{
    require(!inPlan.empty() && !outPlan.empty(), "Empty partition plan");
    auto s = state(); Run result; std::array<float, block * 2> out{}, zeros{};
    const auto n = input.size() / 2;
    auto call = [&](std::size_t first, std::size_t count, bool final) {
        const auto outputCount = outPlan[result.calls % outPlan.size()];
        require(outputCount && outputCount <= block && count <= std::size_t(std::numeric_limits<long>::max()),
                "Invalid bounded partition");
        SRC_DATA data{};
        data.data_in = count ? input.data() + first * 2 : zeros.data();
        data.data_out = out.data(); data.input_frames = long(count); data.output_frames = long(outputCount);
        data.end_of_input = final; data.src_ratio = ratio;
        require(++result.calls < n * 3 + 65536, "Process call bound exceeded");
        require(src_process(s.get(), &data) == 0 && !src_error(s.get()), "src_process failed");
        require(data.input_frames_used >= 0 && std::size_t(data.input_frames_used) <= count &&
                data.output_frames_gen >= 0 && std::size_t(data.output_frames_gen) <= outputCount,
                "Invalid library progress counts");
        const auto generated = std::size_t(data.output_frames_gen);
        require(result.frames + generated <= n * 2 + 8192, "Output storage bound exceeded");
        require(std::ranges::all_of(std::span(out).first(generated * 2), [](float v) { return std::isfinite(v); }),
                "Nonfinite converted PCM");
        if (!countOnly) result.pcm.insert(result.pcm.end(), out.begin(), out.begin() + generated * 2);
        result.frames += generated; result.inputUsed += std::size_t(data.input_frames_used);
        return std::array{std::size_t(data.input_frames_used), generated};
    };
    std::size_t part = 0;
    for (std::size_t first = 0; first < n;) {
        const auto count = std::min(inPlan[part++ % inPlan.size()], n - first);
        require(count != 0, "Zero input partition");
        std::size_t used = 0;
        while (used < count) {
            const auto progress = call(first + used, count - used, lastPositiveEof && first + count == n);
            require(progress[0] || progress[1], "Unconsumed input made no progress"); used += progress[0];
        }
        first += count;
    }
    for (;;) {
        ++result.zeroFlushCalls;
        const auto progress = call(n, 0, finish);
        if (!progress[1]) break;
    }
    require(result.inputUsed == n, "Streamed input coverage differs");
    return result;
}

struct Difference { std::int64_t frameDelta = 0; std::size_t compared = 0, unequal = 0;
    double maximum = 0, rms = 0, firstMaximum = 0, tailMaximum = 0; };
Difference difference(std::span<const float> reference, std::span<const float> actual)
{
    Difference d; d.frameDelta = std::int64_t(actual.size() / 2) - std::int64_t(reference.size() / 2);
    const auto count = std::min(reference.size(), actual.size()); double square = 0;
    for (std::size_t i = 0; i < count; ++i) {
        const auto error = std::abs(double(reference[i]) - actual[i]);
        d.maximum = std::max(d.maximum, error); square += error * error;
        d.unequal += std::bit_cast<std::uint32_t>(reference[i]) != std::bit_cast<std::uint32_t>(actual[i]);
        if (i < 2048) d.firstMaximum = std::max(d.firstMaximum, error);
        if (i + 2048 >= reference.size()) d.tailMaximum = std::max(d.tailMaximum, error);
    }
    d.compared = count / 2; d.rms = count ? std::sqrt(square / count) : 0; return d;
}
void printDifference(const Difference& d)
{
    std::cout << "\"frame_delta\":" << d.frameDelta << ",\"compared_frames\":" << d.compared
        << ",\"unequal_samples\":" << d.unequal << ",\"max_abs\":" << d.maximum
        << ",\"rms\":" << d.rms << ",\"first_1024_max_abs\":" << d.firstMaximum
        << ",\"last_1024_max_abs\":" << d.tailMaximum;
}
} // namespace

int main()
{
    try {
        std::cout.precision(17);
        std::cout << "{\"status\":\"exploration_complete\",\"library\":\"" << src_get_version()
                  << "\",\"prepared_recipe_unchanged\":true,\"performance_qualification\":false,\"cases\":[";
        constexpr std::array<std::size_t, 1> fixed{4096}, hopPlan{hop};
        constexpr std::array<std::size_t, 4> mixedIn{1, 146, 4095, 257985}, mixedOut{257, 4096, 511, 13};
        constexpr std::array<std::size_t, 10> sizes{1, 2, 146, 147, 148, 4095, 4096, 4097, hop, hop + 1};
        bool comma = false;
        auto row = [&](std::size_t n, unsigned role, const char* recipe, const Pcm& reference,
                       const Run& run, std::size_t countPass) {
            if (comma) std::cout << ','; comma = true;
            std::cout << "{\"input_frames\":" << n << ",\"role\":" << role << ",\"recipe\":\"" << recipe
                << "\",\"reference_frames\":" << reference.size() / 2 << ",\"produced_frames\":" << run.frames
                << ",\"same_recipe_count\":" << countPass << ",\"count_matches\":" << (countPass == run.frames ? "true" : "false")
                << ",\"calls\":" << run.calls << ",\"zero_flush_calls\":" << run.zeroFlushCalls << ',';
            printDifference(difference(reference, run.pcm)); std::cout << '}';
        };
        for (const auto n : sizes) {
            const auto pcm = fixture(n, 0), reference = preparedReference(pcm);
            require(callbackCount(n) == reference.size() / 2, "Actual prepared reference differs from its callback count recipe");
            const Pcm zero(n * 2);
            row(n, 0, "process4096_deferred_zero_eof", reference, process(pcm, fixed, fixed, false),
                process(zero, fixed, fixed, false, true).frames);
            row(n, 0, "process_mixed_last_positive_eof", reference, process(pcm, mixedIn, mixedOut, true),
                process(zero, mixedIn, mixedOut, true, true).frames);
        }
        constexpr std::size_t n = 4 * hop + 211;
        std::array<Pcm, 4> inputs, references;
        std::array<std::size_t, 4> totals{};
        for (unsigned role = 0; role < 4; ++role) {
            inputs[role] = fixture(n, role); references[role] = preparedReference(inputs[role]);
            const auto run = process(inputs[role], mixedIn, mixedOut, false); totals[role] = run.frames;
            row(n, role, "process_mixed_deferred_zero_eof", references[role], run,
                process(Pcm(n * 2), mixedIn, mixedOut, false, true).frames);
            row(n, role, "process_hop_deferred_zero_eof", references[role], process(inputs[role], hopPlan, fixed, false),
                process(Pcm(n * 2), hopPlan, fixed, false, true).frames);
        }
        std::cout << "],\"first_hop_without_later_input_or_eof\":[";
        for (unsigned role = 0; role < 4; ++role) {
            // Drain only currently available output. A zero-input process call
            // with end_of_input=0 is NOT an EOF flush and supplies no future PCM.
            const auto prefix = process(std::span(inputs[role]).first(hop * 2), fixed, fixed, false, false, false);
            if (role) std::cout << ',';
            std::cout << "{\"role\":" << role << ",\"input_frames_used\":" << prefix.inputUsed
                << ",\"output_frames_available\":" << prefix.frames << ",\"whole_hop_output_frames\":280800"
                << ",\"output_frame_delta_from_whole_hop\":" << std::int64_t(prefix.frames) - 280800
                << ",\"zero_input_non_eof_calls\":" << prefix.zeroFlushCalls
                << ",\"all_calls_end_of_input_zero\":true,\"later_input_supplied\":false}";
        }
        std::cout << "],\"four_stem_equal_counts\":"
            << (std::ranges::all_of(totals, [&](auto value) { return value == totals.front(); }) ? "true" : "false")
            << ",\"seeks\":[";
        comma = false;
        const auto total48 = references[0].size() / 2;
        const std::array<std::size_t, 8> targets{280799, 280800, 280801, 561599, 561601, 842523, total48 - 1, total48};
        for (const auto target : targets) for (const auto prerollUnits : {std::size_t(0), std::size_t(4), std::size_t(32)}) {
            const auto cell = target / 160;
            const auto anchor44 = (cell > prerollUnits ? cell - prerollUnits : 0) * 147;
            const auto anchor48 = anchor44 / 147 * 160;
            const auto discard = target - anchor48;
            for (unsigned role = 0; role < 4; ++role) {
                // All four roles exercise the conservative candidate. Role0
                // also retains short/no-preroll controls without multiplying
                // this exploratory CPU workload unnecessarily.
                if (role && prerollUnits != 32) continue;
                const auto tail = process(std::span(inputs[role]).subspan(anchor44 * 2), mixedIn, mixedOut, false);
                const auto available = tail.pcm.size() / 2;
                const auto actual = std::span(tail.pcm).subspan(std::min(discard, available) * 2);
                if (comma) std::cout << ','; comma = true;
                std::cout << "{\"target48\":" << target << ",\"role\":" << role << ",\"anchor44\":" << anchor44
                    << ",\"anchor48\":" << anchor48 << ",\"preroll147_units\":" << prerollUnits
                    << ",\"discard48\":" << discard << ",\"discard_available\":" << (discard <= available ? "true" : "false") << ',';
                printDifference(difference(std::span(references[role]).subspan(target * 2), actual)); std::cout << '}';
            }
        }
        std::cout << "],\"scope\":\"Synthetic only; all differences/count deltas retained. No tolerance, seek-preroll bound, production API or latency claim is approved by this exploratory receipt.\"}\n";
    } catch (const std::exception& error) {
        std::cerr << "Resampler spike failed: " << error.what() << '\n'; return 1;
    }
}
