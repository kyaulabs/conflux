// Ignored numerical experiment; no model, GPU, playback or performance claim.
#include "audio/AudioFile.hpp"
#include "audio/StemRateConverter.hpp"
#include <QByteArrayView>
#include <QCryptographicHash>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <samplerate.h>

#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <fcntl.h>
#include <iostream>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <sys/stat.h>
#include <unistd.h>

namespace {
using Converter = conflux::audio::StemRateConverter;
constexpr std::uint64_t frameBytes = 8;
constexpr auto maximumBytes = conflux::audio::PreparedAudio::defaultMaxPreparedBytes;
constexpr std::uint64_t maximumFrames = maximumBytes / frameBytes;
// Choose this point before observing data. No retries/selecting an easier tail.
constexpr std::uint64_t inputFrames = (maximumFrames / 160) * 147;
constexpr std::uint64_t mathematicalOutputFrames = (maximumFrames / 160) * 160;
constexpr std::size_t block = 4096;
struct Scratch {
    std::array<unsigned char, block * frameBytes> bytes{};
    std::array<float, block * 2> input{}, reference{};
    std::array<std::array<float, block * 2>, 4> output{};
};
struct Descriptor {
    explicit Descriptor(int value) : fd(value) {}
    ~Descriptor() { if (fd >= 0) ::close(fd); }
    Descriptor(const Descriptor&) = delete;
    Descriptor& operator=(const Descriptor&) = delete;
    int fd;
};
void require(bool value, const char* message) { if (!value) throw std::runtime_error(message); }

float sample(std::uint64_t frame, unsigned channel)
{
    auto hash = frame + 0x9e3779b97f4a7c15ULL * (channel + 1U);
    hash = (hash ^ (hash >> 30)) * 0xbf58476d1ce4e5b9ULL;
    hash = (hash ^ (hash >> 27)) * 0x94d049bb133111ebULL;
    hash ^= hash >> 31;
    // Exact dyadic, finite headroom, channel- and absolute-frame-specific.
    return float(std::int64_t(hash % 3145729U) - 1572864) / 1048576.F;
}

void readBytes(int fd, std::uint64_t offset, std::span<unsigned char> output)
{
    for (std::size_t done = 0; done < output.size();) {
        const auto got = ::pread(fd, output.data() + done, output.size() - done, off_t(offset + done));
        require(got > 0, "Bounded synthetic/reference pread ended early"); done += std::size_t(got);
    }
}
QString hashFile(int fd, std::uint64_t bytes, Scratch& scratch)
{
    QCryptographicHash hash(QCryptographicHash::Sha256);
    for (std::uint64_t first = 0; first < bytes;) {
        const auto count = std::size_t(std::min<std::uint64_t>(scratch.bytes.size(), bytes - first));
        readBytes(fd, first, std::span(scratch.bytes).first(count));
        hash.addData(QByteArrayView(reinterpret_cast<const char*>(scratch.bytes.data()), qsizetype(count)));
        first += count;
    }
    return QString::fromLatin1(hash.result().toHex());
}
QString writeInput(int fd, Scratch& scratch)
{
    QCryptographicHash hash(QCryptographicHash::Sha256);
    for (std::uint64_t first = 0; first < inputFrames;) {
        const auto count = std::size_t(std::min<std::uint64_t>(block, inputFrames - first));
        for (std::size_t frame = 0; frame < count; ++frame) for (unsigned channel = 0; channel < 2; ++channel) {
            const auto value = sample(first + frame, channel);
            require(std::isfinite(value), "Synthetic input is nonfinite");
            const auto bits = std::bit_cast<std::uint32_t>(value);
            for (unsigned byte = 0; byte < 4; ++byte)
                scratch.bytes[frame * 8 + channel * 4 + byte] = static_cast<unsigned char>(bits >> (8 * byte));
        }
        const auto bytes = count * 8;
        hash.addData(QByteArrayView(reinterpret_cast<const char*>(scratch.bytes.data()), qsizetype(bytes)));
        for (std::size_t done = 0; done < bytes;) {
            const auto got = ::write(fd, scratch.bytes.data() + done, bytes - done);
            require(got > 0, "Bounded synthetic input write failed"); done += std::size_t(got);
        }
        first += count;
    }
    return QString::fromLatin1(hash.result().toHex());
}
void readInput(int fd, std::uint64_t first, std::size_t frames, Scratch& scratch)
{
    readBytes(fd, first * 8, std::span(scratch.bytes).first(frames * 8));
    for (std::size_t sampleIndex = 0; sampleIndex < frames * 2; ++sampleIndex) {
        std::uint32_t bits = 0;
        for (unsigned byte = 0; byte < 4; ++byte)
            bits |= std::uint32_t(scratch.bytes[sampleIndex * 4 + byte]) << (8 * byte);
        scratch.input[sampleIndex] = std::bit_cast<float>(bits);
    }
}
void readReference(int fd, std::uint64_t first, std::size_t frames, Scratch& scratch)
{
    auto bytes = std::span(reinterpret_cast<unsigned char*>(scratch.reference.data()), frames * 8);
    readBytes(fd, first * 8, bytes); // PreparedAudio is native-endian float PCM.
}

struct Metric {
    std::uint64_t compared = 0, bitDifferences = 0, firstMismatchFrame = 0;
    std::uint32_t firstReferenceBits = 0, firstActualBits = 0;
    double maximum = 0, square = 0;
    QJsonObject json() const {
        QJsonObject result{{"compared_samples", qint64(compared)}, {"bit_differences", qint64(bitDifferences)},
            {"max_abs", maximum}, {"rmse", compared ? std::sqrt(square / double(compared)) : 0}};
        if (bitDifferences) {
            result["first_mismatch_frame48"] = qint64(firstMismatchFrame);
            result["first_reference_bits"] = qint64(firstReferenceBits);
            result["first_actual_bits"] = qint64(firstActualBits);
        }
        return result;
    }
};
QJsonObject inspectWindow(const Converter::FramePlan& plan, int rawFd, int referenceFd,
                          std::uint64_t target, std::uint64_t wanted, bool fullTail,
                          Scratch& scratch, bool& allMatch)
{
    std::array<std::array<Metric, 2>, 4> metrics{};
    std::uint64_t next = target, offeredInput = 0, calls = 0, anchor = 0;
    bool finished = false;
    QString error;
    try {
        Converter converter(plan, target);
        anchor = converter.inputStartFrame();
        auto input = anchor;
        for (;;) {
            if ((!fullTail && next == target + wanted) || (fullTail && finished)) break;
            require(++calls < (plan.inputFrames() - anchor + 1) * 4 + 65536, "Window converter made no bounded progress");
            const auto available = std::size_t(std::min<std::uint64_t>(block, plan.inputFrames() - input));
            const auto remaining = target + wanted - next;
            const auto capacity = std::size_t(std::min<std::uint64_t>(block, remaining ? remaining : 1));
            std::array<std::span<const float>, 4> in{};
            std::array<std::span<float>, 4> out{};
            if (available) readInput(rawFd, input, available, scratch);
            for (unsigned role = 0; role < 4; ++role) {
                in[role] = available ? std::span<const float>(scratch.input).first(available * 2) : std::span<const float>{};
                scratch.output[role].fill(12345.F);
                out[role] = std::span(scratch.output[role]).first(capacity * 2);
            }
            const auto step = converter.process(in, out, !available);
            require(step.inputFramesUsed <= available && step.outputFrames <= capacity && step.firstOutputFrame == next,
                    "Window progress or absolute output origin differs");
            require(step.outputFrames <= remaining, "Converter emitted a frame beyond the counted sample range");
            require(!available || step.inputFramesUsed || step.outputFrames, "Positive window input made no progress");
            input += step.inputFramesUsed; offeredInput += step.inputFramesUsed;
            if (step.outputFrames) readReference(referenceFd, next, step.outputFrames, scratch);
            for (unsigned role = 0; role < 4; ++role) {
                for (std::size_t frame = 0; frame < step.outputFrames; ++frame) for (unsigned channel = 0; channel < 2; ++channel) {
                    const auto actual = scratch.output[role][frame * 2 + channel];
                    const auto reference = scratch.reference[frame * 2 + channel];
                    require(std::isfinite(actual) && std::isfinite(reference), "Sample comparison contains nonfinite output");
                    auto& value = metrics[role][channel];
                    const auto actualBits = std::bit_cast<std::uint32_t>(actual);
                    const auto referenceBits = std::bit_cast<std::uint32_t>(reference);
                    if (actualBits != referenceBits) {
                        if (!value.bitDifferences) {
                            value.firstMismatchFrame = next + frame;
                            value.firstActualBits = actualBits; value.firstReferenceBits = referenceBits;
                        }
                        ++value.bitDifferences;
                    }
                    const auto difference = std::abs(double(actual) - reference);
                    value.maximum = std::max(value.maximum, difference); value.square += difference * difference; ++value.compared;
                }
                require(std::ranges::all_of(std::span(scratch.output[role]).subspan(step.outputFrames * 2),
                                           [](float sample) { return sample == 12345.F; }), "Converter wrote unavailable suffix");
            }
            next += step.outputFrames; finished = step.finished;
            require(!finished || next == plan.outputFrames(), "Converter finished before authoritative global EOF");
        }
        require(next == target + wanted && (!fullTail || (finished && input == plan.inputFrames())),
                "Sampled window or complete short EOF tail is incomplete");
    } catch (const std::exception& failure) { error = QString::fromUtf8(failure.what()); }
    bool bitsMatch = true;
    QJsonArray roles;
    for (const auto& role : metrics) {
        QJsonArray channels;
        for (const auto& metric : role) {
            bitsMatch &= metric.bitDifferences == 0 && metric.compared == wanted;
            channels.append(metric.json());
        }
        roles.append(channels);
    }
    const bool complete = error.isEmpty() && next == target + wanted && (!fullTail || finished);
    allMatch &= complete && bitsMatch;
    return {{"target_frame48", qint64(target)}, {"input_anchor44", qint64(anchor)},
        {"expected_compared_frames", qint64(wanted)}, {"actual_compared_frames", qint64(next - target)},
        {"input_frames_used", qint64(offeredInput)}, {"calls", qint64(calls)}, {"full_eof_tail", fullTail},
        {"actual_eof_confirmed", finished}, {"complete", complete}, {"count_alignment_only", wanted == 0},
        {"all_compared_bits_match", wanted ? QJsonValue(bitsMatch) : QJsonValue(QJsonValue::Null)},
        {"error", error}, {"role_channel_metrics", roles}};
}

QJsonObject limits()
{
    return {{"output_budget_bytes", qint64(maximumBytes)}, {"output_budget_frames", qint64(maximumFrames)},
        {"input_budget_bytes", qint64(conflux::audio::PreparedStemInput::defaultMaxPreparedBytes)},
        {"input_frames44", qint64(inputFrames)}, {"input_bytes", qint64(inputFrames * 8)},
        {"maximum_anonymous_pcm_file_bytes", qint64(inputFrames * 8 + maximumBytes)},
        {"mathematical_output_frames_not_eof", qint64(mathematicalOutputFrames)},
        {"fixed_pcm_scratch_bytes", qint64(sizeof(Scratch))}, {"count_passes", 1},
        {"reference_files", 1}, {"raw_input_files", 1}, {"read_only_input_roles_alias", true},
        {"state_storage", "Four libsamplerate states plus private converter scratch; not an exact RSS claim"},
        {"whole_track_pcm_vectors", false}, {"source_recipe", "absolute-frame SplitMix64 dyadic stereo v1"}};
}
QJsonObject run(const std::filesystem::path& spool)
{
    Descriptor directory(::open(spool.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW));
    struct stat status{};
    require(directory.fd >= 0 && ::fstat(directory.fd, &status) == 0 && S_ISDIR(status.st_mode) &&
            status.st_uid == ::getuid() && !(status.st_mode & 077), "Run requires an existing owned private0700 spool directory");
    require(std::filesystem::is_empty(spool), "Spool must start empty; use a fresh task-owned directory");
    require(inputFrames * 8 <= conflux::audio::PreparedStemInput::defaultMaxPreparedBytes,
            "Fixed synthetic input exceeds the existing separator input budget");
    Scratch scratch;
    auto pattern = (spool / "max-range-XXXXXX").string();
    Descriptor raw(::mkstemp(pattern.data()));
    require(raw.fd >= 0, "Cannot create bounded synthetic raw input");
    require(::unlink(pattern.c_str()) == 0, "Cannot unlink owned raw input");
    const auto generatedHash = writeInput(raw.fd, scratch);
    require(::fstat(raw.fd, &status) == 0 && std::uint64_t(status.st_size) == inputFrames * 8, "Generated raw size differs");
    const auto sourceHash = hashFile(raw.fd, inputFrames * 8, scratch);
    require(sourceHash == generatedHash, "Retained synthetic input differs from generated wire bytes");
    const auto plan = Converter::countFrames(inputFrames, maximumFrames);
    auto reference = conflux::audio::prepareStemOutput(raw.fd, inputFrames, maximumBytes, {}, spool);
    require(reference.frames() == plan.outputFrames(), "Single count plan differs from actual prepared reference EOF");
    require(::fstat(reference.descriptor(), &status) == 0 && std::uint64_t(status.st_size) == reference.frames() * 8,
            "Prepared reference file size differs from actual frames");
    const auto referenceHash = hashFile(reference.descriptor(), reference.frames() * 8, scratch);
    const auto total = plan.outputFrames();
    require(total <= maximumFrames && maximumFrames - total < 160, "Probe did not reach the declared near-budget frame range");
    const auto lateGrid = ((total - 1048576) / 160) * 160;
    const std::array<std::uint64_t, 5> targets{(1ULL << 24) - 1, (1ULL << 24) + 1,
                                            lateGrid, lateGrid + 1, total - 65536 + 123};
    QJsonArray windows; bool allMatch = true;
    for (const auto target : targets) windows.append(inspectWindow(plan, raw.fd, reference.descriptor(), target, 4096, false, scratch, allMatch));
    windows.append(inspectWindow(plan, raw.fd, reference.descriptor(), total - 8192, 8192, true, scratch, allMatch));
    windows.append(inspectWindow(plan, raw.fd, reference.descriptor(), total, 0, true, scratch, allMatch));
    return {{"status", "numerical_probe_complete"}, {"all_compared_bits_match", allMatch}, {"limits", limits()},
        {"input_sha256", sourceHash}, {"generated_input_sha256", generatedHash}, {"input_format", "stereo44100 F32LE"},
        {"reference_sha256", referenceHash}, {"reference_format", "stereo48000 native float32"},
        {"reference_native_endian", std::endian::native == std::endian::little ? "little" : "big"},
        {"reference_frames", qint64(total)}, {"reference_bytes", qint64(total * 8)},
        {"distance_from_output_budget_frames", qint64(maximumFrames - total)}, {"windows", windows}};
}
} // namespace

int main(int argc, char** argv)
{
    QJsonObject result{{"status", "dry_plan"}, {"limits", limits()}, {"run_started", false},
        {"model_gpu_physical_audio_used", false}, {"performance_qualification", false},
        {"universal_numerical_equivalence_claim", false},
        {"scope", "Near-budget synthetic count/reference plus bounded late windows and complete short EOF tail; no musical or latency claim"}};
    if (argc == 1) {
        std::cout << QJsonDocument(result).toJson(QJsonDocument::Compact).constData() << '\n'; return 0;
    }
    if (argc != 3 || std::string(argv[1]) != "--run") {
        std::cerr << "Usage: resample-max-range [--run NEW_PRIVATE_SPOOL_DIRECTORY]\n"; return 2;
    }
    const auto began = std::chrono::steady_clock::now();
    result["run_started"] = true;
    result["library"] = QString::fromUtf8(src_get_version());
    int code = 1;
    try {
        const auto measured = run(std::filesystem::absolute(argv[2]));
        for (auto value = measured.begin(); value != measured.end(); ++value) result[value.key()] = value.value();
        code = result["all_compared_bits_match"].toBool() ? 0 : 1;
        const auto empty = std::filesystem::is_empty(std::filesystem::absolute(argv[2]));
        require(empty, "Owned synthetic spool is not empty after closing anonymous files");
        result["spool_empty_after_cleanup"] = empty;
        result["anonymous_files_released_on_return"] = true;
    } catch (const std::exception& error) {
        code = 1;
        result["status"] = "failed_or_incomplete"; result["error"] = QString::fromUtf8(error.what());
    }
    result["elapsed_seconds_informational"] = std::chrono::duration<double>(std::chrono::steady_clock::now() - began).count();
    std::cout << QJsonDocument(result).toJson(QJsonDocument::Compact).constData() << '\n'; return code;
}
