"""Pure-stdlib fixtures; no helper imports, native processes or host reads."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import importlib.util
import io
import json
from pathlib import Path
from types import SimpleNamespace
import signal
import struct
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('host_pcm_under_test',Path(__file__).with_name('run_host_pcm.py'))
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
BASE=Path(__file__).resolve().parent
PLAN=driver.decode(driver.pin_read(driver.PLAN,maximum=256*1024,keep=True)[1])
consumer=driver.load_helper('fixture_consumer',PLAN['helpers']['consumer'])
host_validator=driver.load_helper('fixture_original_validator',PLAN['helpers']['host_validator'])


def fixture():
    ready = {'event':'ready','process_environment':{'OMP_WAIT_POLICY':'PASSIVE','GOMP_SPINCOUNT':'0'}}
    requests,hosts = [],[]
    for n in range(1,17):
        metrics = {k:1.0 for k in driver.NATIVE_FIELDS}
        metrics.update(event='result',id=n,frames=343980,stems=4,voluntary_context_switches=0,involuntary_context_switches=0)
        identity={'schema':1,'sample_format':'f32le','shape':[343980,2],'bytes':2751840,'sha256':format(n,'064x')}
        requests.append({'request_id':n,'case_id':driver.CASE_IDS[n-1],
                         'producer_identity':deepcopy(identity),'written_identity':deepcopy(identity),'expected_identity':deepcopy(identity),'completed':True,'exact_pcm_match':True,'started_ns':n*100,
                         'finished_ns':n*100+50,'native_metrics':metrics})
        row = {k:0 for k in (*driver.HOST_INTS,*consumer.INTERVAL_INTS)}
        row.update(schema=1,record_limit=64,graph_ordinal=n,outcome=1,begin_ns=n*100+10,end_ns=n*100+20,wall_ns=10,
                   correlation_valid=True,perf_logger_enabled=False,backend_graph_calls=1,backend_sync_calls=1,
                   submit_calls=1,direct_sync_submit_calls=1,
                   record_calls=1,record_begin_ns=n*100+12,record_end_ns=n*100+18,record_ns=6,
                   gpu_status=1,gpu_valid=True,gpu_queue_family=0,gpu_valid_bits=64,
                   gpu_period_f32_bits=struct.unpack('<I',struct.pack('<f',1.0))[0],
                   gpu_begin_commands=1,gpu_end_commands=1,gpu_begin_available=1,gpu_end_available=1,
                   gpu_begin_ticks=100,gpu_end_ticks=105,gpu_delta_ticks=5,gpu_interval_ns=5,gpu_wrapped=False,gpu_query_ns=1)
        hosts.append(row)
    return ready,requests,hosts


def capture(ready,requests,hosts):
    stderr=b'ordinary pinned backend diagnostic\n'+b''.join(driver.PREFIX+json.dumps(r).encode()+b'\n' for r in hosts)
    stdout=b''.join(json.dumps(r).encode()+b'\n' for r in
        [{k:v for k,v in ready.items() if k!='process_environment'},*[r['native_metrics'] for r in requests]])
    return stderr,stdout


class CaptureTests(unittest.TestCase):
    def setUp(self): self.ready,self.requests,self.hosts=fixture()
    def parse(self):
        a,b=capture(self.ready,self.requests,self.hosts)
        return driver.parse_capture(a,b,self.ready,self.requests,consumer,host_validator)
    def test_complete_serial_graph_and_real_native_fields(self):
        self.assertEqual(self.parse()['request_ids'],list(range(1,17)))
    def test_missing_duplicate_extra_and_truncated_records_rejected(self):
        for hosts in (self.hosts[:-1],self.hosts+[self.hosts[-1]],self.hosts[:2]+self.hosts[1:3]):
            with self.subTest(records=len(hosts)),self.assertRaises(ValueError):
                a,b=capture(self.ready,self.requests,hosts);driver.parse_capture(a,b,self.ready,self.requests,consumer,host_validator)
        a,b=capture(self.ready,self.requests,self.hosts)
        for aa,bb in ((a[:-1],b),(a,b[:-1])):
            with self.assertRaises(ValueError):driver.parse_capture(aa,bb,self.ready,self.requests,consumer,host_validator)
    def test_failure_inflight_wrong_thread_or_logger_never_pass(self):
        for key,value in [('outcome',3),('correlation_valid',False),('perf_logger_enabled',True),
                          ('backend_graph_calls',0),('backend_sync_calls',0),('create_inflight_end',1),
                          ('create_failed_delta',1),('submit_failed_calls',1),('graph_ordinal',True)]:
            with self.subTest(key=key):
                old=self.hosts[2][key];self.hosts[2][key]=value
                with self.assertRaises(ValueError):self.parse()
                self.hosts[2][key]=old
    def test_clock_escape_and_nonmonotonic_create_total_rejected(self):
        self.hosts[1]['begin_ns']=99
        with self.assertRaises(ValueError):self.parse()
        self.hosts=fixture()[2];self.hosts[0].update(create_started_delta=1,create_completed_delta=1)
        with self.assertRaises(ValueError):self.parse()
    def test_every_native_phase_required_no_fake_service_phases(self):
        for name in driver.NATIVE_FIELDS:
            row=deepcopy(self.requests[0]['native_metrics']);row.pop(name)
            with self.subTest(name=name),self.assertRaises(ValueError):driver.validate_metrics(row,1)
        for value in (True,-1,float('nan'),float('inf')):
            row=deepcopy(self.requests[0]['native_metrics']);row['graph_compute_ms']=value
            with self.assertRaises(ValueError):driver.validate_metrics(row,1)
        self.assertEqual(driver.UNOBSERVED_SERVICE_FIELDS,('source_read_ms','request_ms','overlap_ms'))
    def test_raw_response_substitution_and_duplicate_json_rejected(self):
        a,b=capture(self.ready,self.requests,self.hosts)
        packets=b.splitlines();value=json.loads(packets[2]);value['id']=1;packets[2]=json.dumps(value).encode()
        with self.assertRaises(ValueError):driver.parse_capture(a,b'\n'.join(packets)+b'\n',self.ready,self.requests,consumer,host_validator)
        with self.assertRaises(ValueError):driver.decode('{"schema":1,"schema":1}')

    def test_last_case_pcm_identity_and_gpu_fail_closed(self):
        for mutation in ('case','pcm','producer','written','expected','gpu','availability'):
            self.ready,self.requests,self.hosts=fixture()
            if mutation=='case':self.requests[-1]['case_id']=driver.CASE_IDS[0]
            elif mutation=='pcm':self.requests[-1]['exact_pcm_match']=False
            elif mutation in ('producer','written','expected'):
                self.requests[-1][mutation+'_identity']['sha256']='f'*64
            elif mutation=='gpu':self.hosts[-1]['gpu_valid']=False
            else:self.hosts[-1]['gpu_end_available']=0
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):self.parse()



class AdmissionAndOwnerTests(unittest.TestCase):
    def human(self, now):
        return {'schema':1,'decision':'ready','diagnostic_mode':driver.MODE,'ready_for_run':'output-01',
            'recorded_at_utc':now.isoformat(),'plan_sha256':'a'*64,'maximum_operator_seconds':600,
            'maximum_command_seconds':480,'AC_power':True,'lid_open':True,'Codex_minimized':True,
            'other_work_paused':True,'no_suspend':True,'human_reply':'ready','human_question':'bounded diagnostic?',
            'question_item_id':'human-question'}
    def test_one_original_600s_clock_and_480s_remaining(self):
        now=datetime(2026,10,23,tzinfo=timezone.utc);h=self.human(now-timedelta(seconds=120))
        value=driver.budget(h,'a'*64,now,1000)
        self.assertEqual(value['operator_deadline'],1480);self.assertEqual(value['command_deadline'],1480)
        for age in (120.001,-.001):
            h=self.human(now-timedelta(seconds=age))
            with self.assertRaises(ValueError):driver.budget(h,'a'*64,now,1000)
        h=self.human(now);h['plan_sha256']='b'*64
        with self.assertRaises(ValueError):driver.budget(h,'a'*64,now,1000)
    def test_complete16_is_diagnostic_and_every_gate_remains_required(self):
        ready,requests,hosts=fixture()
        report={'candidate_graph':{'complete':True},'cleanup_complete':True,'pins_unchanged':True,'guard_before':{},'guard_after':{},
            'within_command_budget':True,'capture':{'complete':True},'host_boundaries':{'complete':True,'gpu_intervals_complete':True,'input_identities_complete':True},
            'native_shutdown':{'graceful_complete':True},'retained_streams':{'stderr':{'truncated':False},'stdout':{'truncated':False}},
            'errors':[],'watchdog_errors':[],'requests':requests}
        report['configured_power_caps_after'] = deepcopy(driver.CAP_CEILINGS)
        driver.final_gates(report)
        self.assertEqual(report['conclusion'],'all16_exact_normal_PCM_and_valid_coarse_GPU_intervals')
        self.assertFalse(report['timing_qualification'])
        for key in ('cleanup_complete','pins_unchanged','within_command_budget'):
            bad=deepcopy(report);bad[key]=False
            with self.subTest(key=key),self.assertRaises(ValueError):driver.final_gates(bad)
        bad=deepcopy(report);bad['requests'][2]['native_metrics']['elapsed_ms']=4095
        driver.final_gates(bad);self.assertEqual(bad['native_elapsed_at_or_above_4095'],[3])
        self.assertFalse(bad['service_timing_qualification'])
    def test_original_owner_clock_limits_and_foreign_checkpoint_rejection(self):
        plan_pin={'sha256':'a'*64};human_pin={'sha256':'b'*64}
        row={'schema':1,'mode':driver.MODE,'plan_pin':plan_pin,'human_pin':human_pin,
            'started_monotonic':1000,'deadline_monotonic':1480,
            'command_maximum_seconds':480,'term_seconds':465,'kill_seconds':477}
        with patch.object(driver,'pin_read',return_value=({},json.dumps(row).encode())):
            clock=driver.read_owner_clock(plan_pin,human_pin,1481,1001)
        self.assertEqual(driver.stage_limits(clock,1600),(1480,1270))
        self.assertEqual(clock['term_monotonic'],1465);self.assertEqual(clock['kill_monotonic'],1477)
        # A delayed launcher cannot reset preparation/native/cleanup to its own origin.
        self.assertEqual(min(clock['started_monotonic']+270+120,1480-45,1269+120),1389)
        self.assertEqual(clock['started_monotonic']+270+120+45,1435)
        for key,value in [('started_monotonic',1002),('deadline_monotonic',1481),('term_seconds',345),('mode','foreign')]:
            with self.subTest(key=key),patch.object(driver,'pin_read',return_value=({},json.dumps({**row,key:value}).encode())):
                with self.assertRaises(ValueError):driver.read_owner_clock(plan_pin,human_pin,1481,1001)

    def test_fixed16_reference_checks_include_last_case_and_no_reordering(self):
        cases=[{'id':key,'input_sha256':format(n,'064x'),'normalization':{'valid_frames':343980,'mean':.1,'std':.2}}
            for n,key in enumerate(driver.CASE_IDS,1)]
        expected={row['id']:deepcopy(row) for row in cases}
        driver.validate_prepared_cases(cases,expected)
        for mutation in ('last_hash','last_stats','order','missing'):
            bad=deepcopy(cases)
            if mutation=='last_hash':bad[-1]['input_sha256']='f'*64
            elif mutation=='last_stats':bad[-1]['normalization']['std']=.3
            elif mutation=='order':bad[-2:]=reversed(bad[-2:])
            else:bad.pop()
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):driver.validate_prepared_cases(bad,expected)

    def test_duplicate_host_profile_and_package_cannot_contradict_cool_or_fresh(self):
        package=Path('/fixture/temp')
        row={'temperatures_millidegrees_C':{str(package):55000},'profile_epp_read_only':{
            '/sys/firmware/acpi/platform_profile':'balanced',
            '/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference':'balance_power'}}
        self.assertTrue(driver.host_admission_ok(row,package,55000))  # EPP required only at fresh boundary.
        for key,value in [('profile','low-power'),('temp',55001),('temp',None),('temp',True)]:
            bad=deepcopy(row)
            if key=='profile':bad['profile_epp_read_only']['/sys/firmware/acpi/platform_profile']=value
            else:bad['temperatures_millidegrees_C'][str(package)]=value
            with self.subTest(key=key,value=value):self.assertFalse(driver.host_admission_ok(bad,package,55000))
        row['temperatures_millidegrees_C'][str(package)]=70000
        self.assertFalse(driver.host_admission_ok(row,package,70000,fresh=True))
        row['profile_epp_read_only']['/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference']='balance_performance'
        self.assertTrue(driver.host_admission_ok(row,package,70000,fresh=True))
        row['temperatures_millidegrees_C'][str(package)]=70001
        self.assertFalse(driver.host_admission_ok(row,package,70000,fresh=True))

    def test_actual_run_rejects_contradictory_fresh_host_before_constructor(self):
        # Exercise actual run/cooldown/fresh/catch/finalization, with generated
        # helpers and source pins only. No NumPy/native/host/real readiness.
        for scenario in ('valid','hot','profile','read_error','cap'):
            with self.subTest(scenario=scenario),tempfile.TemporaryDirectory() as directory:
                scratch=Path(directory);zone=scratch/'zone';zone.mkdir();package=zone/'temp'
                package.write_text('50000')
                fixture=scratch/'fixture.json';fixture.write_text('{}')
                human=scratch/'human.json';human.write_text('{}')
                proof_pin=driver.pin_read(fixture)[0];human_pin=driver.pin_read(human)[0]
                file_pin={k:proof_pin[k] for k in ('path','bytes','sha256')}
                plan={'assets':{key:dict(file_pin) for key in ('reference','guard_script','guard_unit','candidate','model')},
                      'helpers':{key:dict(file_pin) for key in PLAN['helpers']},'sources':{},'build_receipt':dict(file_pin)}
                now=[0.0];captures=[];observed=[];constructed=[]
                guard={'service':{'MainPID':'123','InvocationID':'a'*32}}
                def observation(_):
                    fresh=len(observed)>=7
                    row={'read_errors':['fixture read failure'] if fresh and scenario=='read_error' else [],
                        'temperatures_millidegrees_C':{str(package):79000 if fresh and scenario=='hot' else 50000},
                        'profile_epp_read_only':{'/sys/firmware/acpi/platform_profile':
                            'low-power' if fresh and scenario=='profile' else 'balanced',
                            '/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference':'balance_performance'}}
                    observed.append(row);return row
                owner=SimpleNamespace(power_state=lambda:{'ac_online':True,'lid_open':True},
                    observation=observation,guard_identity=lambda *_:deepcopy(guard),sensor_paths=lambda:{str(package):'x86_pkg_temp'})
                def capture(*_):
                    row={'finished_monotonic':now[0],'errors':[],'package_millidegrees_C':50000,'profile':'balanced',
                        'holds':'','latest_message_claims_recovered':True,'journal_identity_matches_service':True}
                    captures.append(row);return row
                observer=SimpleNamespace(capture=capture,identity=lambda _:guard['service'],ready=lambda *_:True)
                cases=[{'id':key,'input_sha256':format(n,'064x'),'normalization':{'valid_frames':343980,'mean':.1,'std':.2}}
                    for n,key in enumerate(driver.CASE_IDS,1)]
                expected={row['id']:deepcopy(row) for row in cases}
                original=SimpleNamespace(CASE_IDS=driver.CASE_IDS,validate_reference=lambda *_:expected,
                    cleanup_native=lambda *_:({'native_reaped':True,'native_resources_closed':True,'temporary_directory_removed':True},None,[]))
                comparison=SimpleNamespace(load_track_plan=lambda _:[],prepare_cases=lambda *_:(None,None,cases))
                class ConstructorTrap:
                    def __init__(self,*args,**kwargs):
                        constructed.append((args,kwargs));raise ValueError('FixtureConstructorTrap')
                helpers={'owner':owner,'original':original,'normalizer':SimpleNamespace(),'readiness':observer,
                    'capture':SimpleNamespace(CapturedNativeRuntime=ConstructorTrap,STDERR_LIMIT=256*1024),
                    'comparison':comparison,'consumer':consumer,'host_validator':host_validator,'input_identity':SimpleNamespace()}
                clock={'started_monotonic':0,'deadline_monotonic':480,'term_monotonic':465,'kill_monotonic':477}
                def caps():
                    values=deepcopy(driver.CAP_CEILINGS)
                    if scenario=='cap' and len(observed)>=8:
                        path=next(p for p in values if 'intel-rapl-mmio' in p and p.endswith('constraint_0_power_limit_uw'))
                        values[path]=64000000
                    return values
                with (patch.object(driver,'BASE',scratch),patch.object(driver,'HUMAN',human),patch.object(driver,'OUTPUT',scratch/'output-01'),
                    patch.object(driver,'Path',side_effect=lambda value:SimpleNamespace(read_text=lambda:'systemd')
                        if str(value)=='/proc/1/comm' else Path(value)),
                    patch.object(driver,'read_power_caps',side_effect=caps),
                    patch.object(driver,'budget',return_value={'command_deadline':480,'operator_deadline':600}),
                    patch.object(driver,'read_owner_clock',return_value=clock),
                    patch.object(driver,'load_helper',side_effect=lambda name,*_:helpers[name]),
                    patch.object(driver.time,'monotonic',side_effect=lambda:now[0]),
                    patch.object(driver.time,'sleep',side_effect=lambda value:now.__setitem__(0,now[0]+value)),
                    patch.object(driver.signal,'signal',return_value=None),patch.dict(driver.os.environ,{},clear=True)):
                    self.assertEqual(driver.run(plan,proof_pin,{},human_pin),1)
                report=json.loads((scratch/'diagnostic-assessment.json').read_text())
                self.assertEqual(report,json.loads((scratch/'output-01/result.json').read_text()))
                self.assertEqual(len(report['cool_readiness']),7);self.assertEqual(report['cool_readiness'][-1]['consecutive_span_seconds'],60)
                self.assertEqual(len(captures),8);self.assertEqual(report['status'],'failed');self.assertFalse(report['diagnostic_complete'])
                self.assertEqual(report['host_observations'][-1]['phase'],'immediately_before_native')
                self.assertEqual(len(constructed),1 if scenario=='valid' else 0)
                message=report['errors'][0]['message']
                self.assertIn('FixtureConstructorTrap' if scenario=='valid' else
                    ('Configured power cap increased' if scenario=='cap' else
                     'Host observation failed' if scenario=='read_error' else 'Fresh same-package'),message)
                if scenario=='read_error':self.assertEqual(report['host_observations'][-1]['read_errors'],['fixture read failure'])

    def test_cleanup_errors_normalized_for_same_canonical_owner_receipt(self):
        report={'errors':[{'type':'Original','message':'primary'},{'phase':'cleanup','message':'secondary'}]}
        driver.normalize_errors(report)
        self.assertEqual(report['errors'][0],{'type':'Original','message':'primary'})
        self.assertEqual(report['errors'][1]['type'],'cleanup')

    def test_capture_error_preserves_primary_and_does_not_skip_cleanup(self):
        events=[]
        class Process:
            pid=123
            returncode=None
            def poll(self):return self.returncode
            def wait(self,timeout):events.append('wait');self.returncode=-9;return -9
        class Sink:
            closed=False
            def close(self):events.append('stdout_close');self.closed=True
        class Native:
            process=Process();stdout_capture=Sink()
            def abort(self):events.append('abort')
            def finish_capture(self,deadline):raise OSError('capture failure')
        def cleanup(native,initialized,output):
            events.append('cleanup');return {'native_reaped':True,'native_resources_closed':True,'temporary_directory_removed':True},None,[]
        original=SimpleNamespace(cleanup_native=cleanup,original_identity_absent=lambda identity:True)
        report={'errors':[{'phase':'primary','message':'original failure'}],'native_identity':{'pid':123}}
        with patch.object(driver.os,'killpg',side_effect=ProcessLookupError):
            driver.cleanup_owned(Native(),True,original,Path('/mock'),1000,report,
                lambda:(_ for _ in ()).throw(OSError('retention failure')))
        self.assertEqual(events,['abort','wait','cleanup','stdout_close'])
        self.assertEqual(report['errors'][0]['phase'],'primary')
        self.assertIn('capture_retention',[e['phase'] for e in report['errors']])
        self.assertTrue(report['native_group_absent'])
    def test_dry_cli_neither_reads_plan_nor_imports_helpers(self):
        with patch.object(driver.sys,'argv',['run_host_pcm.py']),patch.object(driver,'load_helper',side_effect=AssertionError),\
             patch.object(driver.os,'open',side_effect=AssertionError),patch('sys.stdout',new_callable=io.StringIO) as stream:
            self.assertEqual(driver.main(),0)
            self.assertFalse(json.loads(stream.getvalue())['native_started'])




def owner_module():
    spec=importlib.util.spec_from_file_location('pcm16_actual_owner',BASE/'run_owned.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


class EntryTests(unittest.TestCase):
    def dispatch(self,*,missing_human=False,mutate=None,completed=False,late_signal=False):
        owner=owner_module();actual_load=owner.load_driver
        actual=actual_load()  # Real sibling digest/import chain, including literal launcher hash.
        plan=actual.decode(actual.pin_read(actual.PLAN,maximum=256*1024,keep=True)[1])
        plan['status']='frozen_pending_fresh_readiness'
        if mutate:mutate(plan)
        loaded=[];attempts=[];callbacks={};started=10.0
        class BeforePopenTrap(BaseException):pass
        class Process:
            pid=123456
            stdout=io.BytesIO();stderr=io.BytesIO()
            def poll(self):return 0
            def wait(self,timeout):
                if late_signal:callbacks[signal.SIGTERM](signal.SIGTERM,None)
                return 0
        class Selector:
            def register(self,*args):pass
            def get_map(self):return {}
            def close(self):pass
        def popen(argv,**kwargs):
            attempts.append((argv,kwargs))
            if completed:return Process()
            raise BeforePopenTrap('Generated fixture reached Popen; no process created')
        with tempfile.TemporaryDirectory() as directory:
            scratch=Path(directory);plan_path=scratch/'plan.json';human_path=scratch/'readiness.json'
            plan_path.write_text(json.dumps(plan))
            if not missing_human:
                human_path.write_text(json.dumps({'fixture_only':True,'recorded_at_utc':'2000-01-01T00:00:00+00:00',
                    'human_reply':'GENERATED OFFLINE FIXTURE; NOT HOST AUTHORIZATION'}))
            def load():
                module=actual_load()  # Actual digest/exec again; do not stub pin_read/validate_plan.
                module.PLAN=plan_path;module.HUMAN=human_path;module.OUTPUT=scratch/'never-native'
                module.budget=lambda *_:{'fixture_only':True,'operator_deadline':610,'command_deadline':490}
                loaded.append(module);return module
            def install(number,handler):
                if callable(handler):callbacks[number]=handler
                return None
            def receipt(module,report,plan_pin,human_pin,deadline):
                # Write a generated coherent inner receipt, then exercise the actual reader.
                driver.save(scratch/'diagnostic-assessment.json',{'mode':module.MODE,'plan_pin':plan_pin,'human_pin':human_pin,
                    'diagnostic_complete':True,'cleanup_complete':True,'status':'complete','errors':[]})
                owner.retain_inner_receipt_original(module,report,plan_pin,human_pin,deadline)
            owner.retain_inner_receipt_original=owner.retain_inner_receipt
            error=None;code=None
            with (patch.object(owner,'BASE',scratch),patch.object(owner,'load_driver',side_effect=load),
                  patch.object(owner.time,'monotonic',return_value=started),
                  patch.object(owner.signal,'signal',side_effect=install),
                  patch.object(owner.subprocess,'Popen',side_effect=popen),
                  patch.object(owner.selectors,'DefaultSelector',return_value=Selector()),
                  patch.object(owner,'process_record',return_value={'pid':123456,'start_ticks':1,'group':123456,'session':123456,'ppid':0,'command':[]}) if completed
                    else patch.object(owner,'process_record',side_effect=AssertionError('No process observation allowed')),
                  patch.object(owner,'live_owned',return_value={}),patch.object(owner,'absent_groups',side_effect=lambda groups:{str(g):True for g in groups}),
                  patch.object(owner,'signal_owned',side_effect=AssertionError('No process signal allowed')),
                  patch.object(owner,'retain_inner_receipt',side_effect=receipt) if completed
                    else patch.object(owner,'retain_inner_receipt',wraps=owner.retain_inner_receipt)):
                try:code=owner.run(started)
                except (ValueError,FileNotFoundError) as caught:error=caught
            outcome=json.loads((scratch/'dispatch-01.json').read_text()) if (scratch/'dispatch-01.json').exists() else None
            self.assertFalse((scratch/'never-native').exists())
        return code,error,outcome,attempts,owner,loaded

    def test_actual_digest_plan_and_pin_read_reach_one_exact_popen_trap(self):
        code,error,report,attempts,owner,loaded=self.dispatch()
        self.assertIsNone(error);self.assertEqual(code,1);self.assertEqual(len(attempts),1)
        self.assertEqual(attempts[0][0],[PLAN['assets']['python']['path'],'-I','-B',str(owner.LAUNCHER),'--run'])
        self.assertTrue(attempts[0][1]['start_new_session']);self.assertEqual(attempts[0][1]['bufsize'],0)
        self.assertEqual(report['errors'][0]['type'],'BeforePopenTrap');self.assertFalse(report['passed'])
        self.assertEqual(report['known_processes'],[]);self.assertEqual(report['command_maximum_seconds'],480)
        self.assertEqual((report['term_seconds'],report['kill_seconds']),(465,477));self.assertEqual(len(loaded),1)

    def test_missing_readiness_and_launcher_digest_mutation_never_reach_popen(self):
        code,error,report,attempts,owner,loaded=self.dispatch(missing_human=True)
        self.assertIsInstance(error,FileNotFoundError);self.assertIsNone(report);self.assertEqual(attempts,[])
        for key,value in [('sha256','f'*64),('path','/unapproved/launcher.py')]:
            def mutation(plan):plan['sources']['launcher'][key]=value
            code,error,report,attempts,owner,loaded=self.dispatch(mutate=mutation)
            self.assertEqual(attempts,[]);self.assertIsNotNone(error if report is None else report['errors'])

    def test_late_signal_after_reap_cannot_pass_otherwise_complete_owner(self):
        for late in (False,True):
            with self.subTest(late=late):
                code,error,report,attempts,owner,loaded=self.dispatch(completed=True,late_signal=late)
                self.assertIsNone(error);self.assertEqual(report['errors'],[]);self.assertTrue(report['inner_complete'])
                self.assertTrue(report['launcher_reaped']);self.assertTrue(report['complete_capture'])
                self.assertEqual(report['external_signals'],[]);self.assertEqual(report['remaining_known_processes'],[])
                self.assertEqual(report['passed'],not late);self.assertEqual(code,1 if late else 0)
                if late:self.assertEqual(report['interruption_signal'],signal.SIGTERM)


if __name__=='__main__':unittest.main()
