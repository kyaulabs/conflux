"""Build one unpromoted Vulkan TU; never start a model, GPU context or audio."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import time

P = Path(__file__).resolve().parent
ROOT = P.parent.parent
BASE = ROOT / "build/m2-graph-interval-01/build-reuse"
assert Path("/proc/1/comm").read_text().strip() == "systemd"

def read_json(path):
    return json.loads(path.read_text())

def pin(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

def verify(item):
    assert pin(Path(item["path"])) == {k: item[k] for k in ("path", "bytes", "sha256")}, item["path"]
    if "canonical_path" in item:
        assert str(Path(item["path"]).resolve()) == item["canonical_path"], item["path"]

def members(path):
    raw = path.read_bytes()
    assert raw[:8] == b"!<arch>\n"
    offset, table, result = 8, b"", []
    while offset < len(raw):
        h = raw[offset:offset + 60]
        assert len(h) == 60 and h[58:] == b"`\n"
        size = int(h[48:58]); data = raw[offset + 60:offset + 60 + size]
        assert len(data) == size
        name = h[:16].decode("ascii").rstrip()
        if name == "//":
            table = data
        elif name not in ("/", "/SYM64/"):
            if name.startswith("/") and name[1:].isdigit():
                start = int(name[1:]); end = table.index(b"\n", start)
                name = table[start:end].decode().removesuffix("/")
            else:
                assert not name.startswith("#1/")
                name = name.removesuffix("/")
            result.append({"name": name, "bytes": size, "sha256": hashlib.sha256(data).hexdigest()})
        offset += 60 + size + size % 2
    assert offset == len(raw)
    return result

def dependencies(path, cwd):
    lines = [s for s in path.read_text().replace("\\\n", "").splitlines() if s.strip()]
    tokens = shlex.split(lines[0])
    assert tokens[0].endswith(":")
    normalize = lambda v: os.path.normpath(str(Path(v) if Path(v).is_absolute() else cwd / v))
    result = list(dict.fromkeys(normalize(v) for v in tokens[1:]))
    # GNU ld emits empty target rules after the actual dependency rule.
    # Verify their provenance rather than treating the trailing colon as a file.
    for line in lines[1:]:
        empty_rule = shlex.split(line)
        assert len(empty_rule) == 1 and empty_rule[0].endswith(":")
        assert normalize(empty_rule[0][:-1]) in result
    return result

review = read_json(P / "source-review-01.json")
for name in ("baseline", "candidate", "patch"):
    verify(review[name])
assert read_json(P / "selector-result-01.json")["passed"]
assert not read_json(P / "selector-red-result-01.json")["passed"]
recipe = read_json(BASE / "argv-plan.json")
cwd = Path(recipe["original_compile_cwd"])
old_pins = read_json(BASE / "input-pins.json")["pins"]
closure = read_json(BASE / "final-build-closure-review-01.json")
assert closure["all_original_input_pins_and_canonical_paths_unchanged"]
for item in old_pins + closure["link_dependencies"]["pins"]:
    verify(item)
headers = []
for name in ("graph_interval_hooks.inc", "graph_interval_math.hpp"):
    source = Path(review["baseline"]["path"]).parent / name
    destination = P / name
    assert not destination.exists()
    destination.write_bytes(source.read_bytes())
    assert pin(source)["sha256"] == pin(destination)["sha256"]
    headers.append({"original": pin(source), "copy": pin(destination)})
output = P / "output-01"
assert not output.exists()
assert shutil.disk_usage(P).free > 2 * 1024**3
output.mkdir(mode=0o700)
steps = []

def run(name, argv, step_cwd):
    start = time.monotonic()
    result = subprocess.run(argv, cwd=step_cwd, capture_output=True, timeout=240)
    (P / (name + ".stdout.log")).write_bytes(result.stdout)
    (P / (name + ".stderr.log")).write_bytes(result.stderr)
    step = {"name": name, "argv": argv, "cwd": str(step_cwd), "exit": result.returncode,
            "seconds": time.monotonic() - start}
    steps.append(step)
    (P / "build-steps.json").write_text(json.dumps(steps, indent=2) + "\n")
    assert result.returncode == 0, name

obj = output / "ggml-vulkan.cpp.o"
dep = output / "ggml-vulkan.cpp.o.d"
compile_argv = recipe["steps"][0]["argv"].copy()
assert compile_argv[-1] == review["baseline"]["path"]
compile_argv[-1] = str(P / "ggml-vulkan.cpp")
for flag, value in (("-MT", obj), ("-MF", dep), ("-o", obj)):
    compile_argv[compile_argv.index(flag) + 1] = str(value)
run("compile-vulkan-only", compile_argv, cwd)
old_dep = BASE / "output-01/ggml-vulkan.cpp.o.d"
verify(read_json(BASE / "dependency-review-01.json")["depfile"])
old_dependencies = dependencies(old_dep, cwd)
relocations = {review["baseline"]["path"]: str(P / "ggml-vulkan.cpp")}
relocations.update({h["original"]["path"]: h["copy"]["path"] for h in headers})
expected = [relocations.get(v, v) for v in old_dependencies]
actual = dependencies(dep, cwd)
assert set(actual) == set(expected), {"missing": sorted(set(expected)-set(actual)), "added": sorted(set(actual)-set(expected))}

original_archive = BASE / "output-01/libggml-vulkan.a"
original_pin = pin(original_archive)
original_members = members(original_archive)
assert len(original_members) == 160
assert sum(v["name"] == obj.name for v in original_members) == 1
archive = output / "libggml-vulkan.a"
shutil.copyfile(original_archive, archive)
assert pin(archive)["sha256"] == original_pin["sha256"]
run("replace-only-backend", ["/bin/ar", "r", str(archive), str(obj)], output)
run("refresh-index", ["/bin/ranlib", str(archive)], output)
changed_members = members(archive)
assert [v["name"] for v in changed_members] == [v["name"] for v in original_members]
changed = [b for a,b in zip(original_members, changed_members) if a != b]
assert len(changed) == 1 and changed[0]["name"] == obj.name
assert changed[0]["sha256"] == pin(obj)["sha256"]
link_argv = recipe["steps"][-1]["argv"].copy()
link_argv = ["-Wl,--dependency-file=" + str(output / "link.d") if v.startswith("-Wl,--dependency-file=")
             else str(archive) if v == str(original_archive) else v for v in link_argv]
link_argv[link_argv.index("-o") + 1] = str(output / "conflux-stem-runtime")
assert str(archive) in link_argv
run("link-same-adapter", link_argv, cwd)
old_link = dependencies(BASE / "output-01/link.d", cwd)
new_link = dependencies(output / "link.d", cwd)
assert new_link == [str(archive) if v == str(original_archive) else v for v in old_link]
for item in old_pins + closure["link_dependencies"]["pins"]:
    verify(item)
for name in ("baseline", "candidate", "patch"):
    verify(review[name])
for h in headers:
    verify(h["original"]); verify(h["copy"])
assert pin(original_archive) == original_pin
receipt = {"schema": 1, "state": "private_unpromoted_runtime_built", "source": review,
           "recipe": pin(BASE / "argv-plan.json"), "compiler_and_original_pins_verified": len(old_pins),
           "original_link_inputs_verified": len(closure["link_dependencies"]["pins"]),
           "selector_checks": pin(P / "selector-result-01.json"), "headers": headers,
           "steps": steps, "compile_dependencies": len(actual),
           "compile_closure_equal_except_three_source_relocations": True,
           "original_archive": original_pin, "archive": pin(archive),
           "archive_member_count": len(original_members), "unchanged_members": len(original_members)-1,
           "changed_member": changed[0], "object": pin(obj), "depfile": pin(dep),
           "link_dependency_count": len(new_link), "link_closure_equal_except_one_archive": True,
           "executable": pin(output / "conflux-stem-runtime"), "GPU_model_audio_started": False,
           "limits": "Build and CPU selector only; exact real-model output, activation and loaded/sustained performance are unqualified. Normal runtime and 15 W ceiling stay unchanged."}
(P / "runtime-build-receipt-01.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({k: receipt[k] for k in ("state", "executable", "unchanged_members", "compile_dependencies", "GPU_model_audio_started")}, indent=2))
