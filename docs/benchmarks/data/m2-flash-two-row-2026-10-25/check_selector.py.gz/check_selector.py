"""Compile the real selector/shmem functions against CPU-only device fixtures."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

P = Path(__file__).resolve().parent
assert Path("/proc/1/comm").read_text().strip() == "systemd", "actual host required for the pinned compiler"
review = json.loads((P / "source-review-01.json").read_text())

def pinned(item):
    raw = Path(item["path"]).read_bytes()
    assert len(raw) == item["bytes"] and hashlib.sha256(raw).hexdigest() == item["sha256"]
    return raw.decode()

baseline = pinned(review["baseline"])
candidate = baseline if "--red" in sys.argv else pinned(review["candidate"])

def function(text, name):
    start = text.index(name)
    return text[start:text.index("\n}", start) + 2]

def selected_functions(text, namespace):
    struct_start = text.index("struct vk_fa_tuning_params {")
    struct = text[struct_start:text.index("\n};", struct_start) + 3]
    shared = function(text, "static bool ggml_vk_flash_attn_scalar_shmem_support(const vk_device& device, const vk_fa_tuning_params& params, uint32_t hsk, uint32_t hsv, bool f32acc, ggml_type k_type, ggml_type v_type) {")
    scalar = function(text, "static vk_fa_tuning_params get_fa_tuning_params_scalar(")
    start = text.index("static vk_fa_tuning_params get_fa_tuning_params(")
    # This fixture covers the exact full-F32 branch. It deliberately does not
    # model the separate coopmat/non-F32 branches or driver capabilities.
    branch = text[start:text.index("    FaCodePath path =", start)]
    branch += '    throw std::runtime_error("outside full-F32 fixture");\n}\n'
    return "namespace " + namespace + " {\n" + struct + "\n" + shared + "\n" + scalar + "\n" + branch + "\n}\n"

header = r'''
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <tuple>
using ggml_fp16_t = uint16_t;
enum ggml_type { GGML_TYPE_F32, GGML_TYPE_F16 };
enum FaCodePath { FA_SCALAR, FA_COOPMAT1, FA_COOPMAT2 };
constexpr uint32_t VK_VENDOR_ID_INTEL = 0x8086, VK_VENDOR_ID_AMD = 0x1002, VK_VENDOR_ID_NVIDIA = 0x10de;
constexpr uint32_t AMD_GCN = 1;
struct Device {
    uint32_t vendor_id = VK_VENDOR_ID_INTEL, architecture = 0, subgroup_size = 32;
    bool fp16 = true, uma = true;
    struct { struct { uint32_t maxComputeSharedMemorySize = 32768; } limits; } properties;
};
using vk_device = std::shared_ptr<Device>;
static bool ggml_vk_fa_scalar_uses_mmq(const vk_device&, ggml_type type) {
    if (type != GGML_TYPE_F32) throw std::runtime_error("fixture only supports F32 K/V");
    return false;
}
#define VK_LOG_DEBUG(...) ((void)0)
#define GGML_ABORT(message) throw std::runtime_error(message)
template<class T> auto key(const T& p) {
    return std::make_tuple(p.path,p.workgroup_size,p.subgroup_size,p.block_rows,p.block_cols,
                          p.d_split,p.row_split,p.shmem_staging,p.disable_subgroups,p.limit_occupancy_shmem);
}
static void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}
'''
main = r'''
int main() {
    try {
        auto device = std::make_shared<Device>();
        int checked = 0;
        for (bool fp16 : {true, false}) {
            device->fp16 = fp16;
            for (uint32_t q : {1344u, 2688u}) for (uint32_t k : {1344u, 2688u}) {
                auto a = original::get_fa_tuning_params(device,64,64,q,k,GGML_TYPE_F32,GGML_TYPE_F32,true);
                auto b = proposed::get_fa_tuning_params(device,64,64,q,k,GGML_TYPE_F32,GGML_TYPE_F32,true);
                require(a.block_rows == 4 && b.block_rows == 2, "target row tile did not change from four to two");
                require(a.block_cols == 32 && b.block_cols == 32, "key traversal changed");
                require(b.workgroup_size == 128 && b.d_split == 8 && b.row_split == 1 && b.disable_subgroups,
                        "target workgroup/reduction contract changed");
                b.block_rows = a.block_rows;
                require(key(a) == key(b), "non-row target parameters changed");
                ++checked;
            }
        }
        device->fp16 = true;
        // Adjacent token/head geometries must keep the original selector.
        for (auto shape : {std::make_tuple(64u,64u,1343u,1344u), {64u,64u,1345u,1344u},
                           {64u,64u,1344u,1343u}, {64u,64u,1344u,1345u},
                           {128u,64u,1344u,1344u}, {64u,128u,1344u,1344u},
                           {64u,64u,1u,1344u}, {64u,64u,4u,1344u}}) {
            auto [hsk,hsv,q,k] = shape;
            require(key(original::get_fa_tuning_params(device,hsk,hsv,q,k,GGML_TYPE_F32,GGML_TYPE_F32,true)) ==
                    key(proposed::get_fa_tuning_params(device,hsk,hsv,q,k,GGML_TYPE_F32,GGML_TYPE_F32,true)),
                    "non-target shape changed");
            ++checked;
        }
        for (uint32_t vendor : {VK_VENDOR_ID_AMD, VK_VENDOR_ID_NVIDIA}) {
            device->vendor_id = vendor;
            require(key(original::get_fa_tuning_params(device,64,64,1344,2688,GGML_TYPE_F32,GGML_TYPE_F32,true)) ==
                    key(proposed::get_fa_tuning_params(device,64,64,1344,2688,GGML_TYPE_F32,GGML_TYPE_F32,true)),
                    "non-Intel selection changed");
            ++checked;
        }
        device->vendor_id = VK_VENDOR_ID_INTEL;
        device->properties.limits.maxComputeSharedMemorySize = 3504;
        require(proposed::get_fa_tuning_params(device,64,64,1344,2688,GGML_TYPE_F32,GGML_TYPE_F32,true).block_rows == 2,
                "exact shared-memory boundary rejected");
        ++checked;
        device->properties.limits.maxComputeSharedMemorySize = 3503;
        bool rejected = false;
        try { proposed::get_fa_tuning_params(device,64,64,1344,2688,GGML_TYPE_F32,GGML_TYPE_F32,true); }
        catch (const std::runtime_error& e) { rejected = std::string(e.what()) == "Full-F32 Flash scalar shared memory is unsupported"; }
        require(rejected, "candidate bypassed shared-memory rejection");
        ++checked;
        std::cout << "selector_cases=" << checked << " target_tile=2 key_tile=32 required_shmem_bytes=3504 no_GPU=1\n";
        return 0;
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
'''
stem = "selector-red" if "--red" in sys.argv else "selector"
source = P / (stem + ".cpp")
source.write_text(header + selected_functions(baseline, "original") + selected_functions(candidate, "proposed") + main)
steps = []
for argv in (["/bin/c++", "-std=c++17", "-O2", "-Wall", "-Wextra", "-Werror", str(source), "-o", str(P / stem)],
             [str(P / stem)]):
    run = subprocess.run(argv, capture_output=True, timeout=60)
    steps.append({"argv": argv, "exit": run.returncode, "stdout": run.stdout.decode(), "stderr": run.stderr.decode()})
    if run.returncode:
        break
result = {"schema": 1, "generated_CPU_device_fixtures": True, "GPU_model_audio_started": False,
          "baseline": review["baseline"], "candidate": review["candidate"], "steps": steps,
          "passed": all(s["exit"] == 0 for s in steps),
          "limits": "Actual extracted selector and memory arithmetic only; no driver, shader execution, model PCM or speed qualification."}
(P / (stem + "-result-01.json")).write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
raise SystemExit(0 if result["passed"] else 1)
