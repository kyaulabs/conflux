#!/usr/bin/env python3
"""Dry by default; one fixed Best-quality row-tile comparison arm.

Two fixed arms share one original1200s human window.
Same current player, public service, default UI and Best precision. No profile or cap writes.
"""
import argparse
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shlex
import stat
import sys
import time
from types import SimpleNamespace

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
# Root-receipted merged source/build; readiness and final packet admission remain absent.
W = Path('/home/kyau/projects/kyaulabs/conflux/build/m2-profile-reporting-worktree')
SOURCE_HEAD = '119a579e4ca717a1d59d7a7a6f9752534d68dcaf'
WRAPPER = W/'tools/experiments/run_manual_playback_soak.py'
WRAPPER_SHA = '7c95909534f8fa21f80dd86b9014f2871b228b99b6b89c8f2c06e12d11b2a413'
BINARY = Path('/home/kyau/projects/kyaulabs/conflux/build/m2-flash-rows8-player-2026-10-25/build-01/conflux-manual-playback-soak')
BINARY_SHA = '3e8c252fd8534dddc458e63f6d99dc373ce05b9d8de40b451b321ac6a756a7dc'
COMPILE_COMMANDS_COUNT = 98
PLAN, HUMAN, OUTPUT = BASE/'plan.json', BASE/'readiness.json', BASE/'output-01'
MODE = 'm2-flash-rows2-visible-recovery-pair-120-01-baseline'
NORMAL = '6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53'
ARM = 'baseline'
RUNTIME = Path('/home/kyau/projects/kyaulabs/conflux/build/m2-graph-interval-01/build-reuse/output-01/conflux-stem-runtime')
RUNTIME_SHA = 'c63b1299877d0f7f6df9d8ca688f0bd88be1406a5da1be71233bc01231b4a6c6'
PCM_PREREQUISITE = {'path': '/home/kyau/projects/kyaulabs/conflux/build/m2-flash-rows2-01/player-pair-recovery-01/prerequisites/baseline.json', 'bytes': 3098, 'sha256': '235ba17d0486e05b1397f64875621155a37461fbc1c38cb948e55a8ccf59707e'}
CAP_CEILINGS = {'/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/enabled': 1, '/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_power_limit_uw': 15000000, '/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_time_window_us': 27983872, '/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_1_power_limit_uw': 64000000, '/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_1_time_window_us': 2440, '/sys/devices/virtual/powercap/intel-rapl/intel-rapl:0/enabled': 1, '/sys/devices/virtual/powercap/intel-rapl/intel-rapl:0/constraint_0_power_limit_uw': 64000000, '/sys/devices/virtual/powercap/intel-rapl/intel-rapl:0/constraint_0_time_window_us': 27983872, '/sys/devices/virtual/powercap/intel-rapl/intel-rapl:0/constraint_1_power_limit_uw': 64000000, '/sys/devices/virtual/powercap/intel-rapl/intel-rapl:0/constraint_1_time_window_us': 2440}
MODEL = 'f8c54ba35df95aafea7881eac214b58ec18a73cbcb6ff5a90f4b762631a286b6'
UTILITY = ROOT/'build/m2-host-boundaries-01/run_host_pcm.py'
UTILITY_SHA = '4ac0103c30eadf24da25a8cc295abbb8ddaa8501b4a8d0e0cb7b1764662ba75c'
ORACLE = ROOT/'benchmarks-local/m2-live-fallback-2026-10-22/current-product-background-balanced-01/run_background.py'
ORACLE_SHA = '37efb1ef3be51af3d7aaef0864bccd00550f501c17fe0893f65ab89fa8805c57'
PHASES = ('source_read_ms', 'request_ms', 'overlap_ms', 'native_elapsed_ms', 'native_inference_wall_ms',
    'native_inference_cpu_ms', 'native_frontend_ms', 'native_graph_ms', 'native_graph_upload_ms',
    'native_graph_compute_ms', 'native_graph_readback_ms', 'native_postprocess_ms', 'native_graph_rebuild_ms')
# Minimum attempt room, not a promise that all allowed timeout maxima fit:
#120s measured +60s live prime +30s setup/tail/final-check reserve.
MINIMUM_NATIVE_WORK_SECONDS = 210
PUBLIC_WORK_SECONDS = 120 + 180 - 45
FINAL_SETTLE_SECONDS, FINAL_SETTLE_PAIRS = 5, 6
RENDERER_ENVIRONMENT_KEYS = ('QT_QPA_PLATFORM','QT_QUICK_BACKEND','QSG_RHI_BACKEND',
    'XDG_SESSION_TYPE','MESA_SHADER_CACHE_DIR','MESA_SHADER_CACHE_MAX_SIZE')
_utility = None


def require(ok,message):
    if not ok: raise ValueError(message)


def load_source(name,path,digest):
    require(path.resolve(strict=True)==path and path.is_file() and 0<path.stat().st_size<=256*1024,'Fixed helper path/type/size differs')
    raw=path.read_bytes();require(hashlib.sha256(raw).hexdigest()==digest,'Fixed helper differs: '+str(path))
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;exec(compile(raw,str(path),'exec'),module.__dict__)
    return module


def utility():
    global _utility
    if _utility is None:
        _utility=load_source('player_host_stdlib_utility',UTILITY,UTILITY_SHA)
        _utility.MODE=MODE  # Private stdlib utility instance, not a product module.
    return _utility


def pin_read(*args,**kwargs): return utility().pin_read(*args,**kwargs)
def decode(raw): return utility().decode(raw)
def save(path,value): return utility().save(path,value)
def budget(record,plan_sha,now_utc,now_mono):
    # Exact retained utility schema/conditions, with this packet's explicit
    #540s whole-command inside the original1200s human envelope.
    issued=datetime.fromisoformat(record.get('recorded_at_utc',''))
    require(issued.tzinfo is not None,'Human UTC must have timezone')
    age=(now_utc-issued).total_seconds()
    require(record.get('schema')==1 and record.get('decision')=='ready' and
        record.get('diagnostic_mode')==MODE and record.get('ready_for_run')=='output-01' and
        record.get('plan_sha256')==plan_sha and record.get('maximum_operator_seconds')==1200 and
        record.get('maximum_command_seconds')==540 and 0<=age and 1200-age>=150 and
        record.get('ui_mode')=='visible' and
        all(record.get(k) is True for k in ('AC_power','lid_open','visible_window','screen_awake','Codex_minimized','other_work_paused','no_suspend')) and
        all(type(record.get(k)) is str and 0<len(record[k])<=8192 for k in ('human_reply','human_question','question_item_id')),
        'Fresh human conditions/plan binding required within original1200s envelope')
    return {'age_seconds':age,'sampled_monotonic':now_mono,
        'operator_deadline':now_mono+1200-age,'command_deadline':now_mono+540}


def renderer_environment(plan,environment):
    requested=plan.get('requested_qt_quick_backend')
    require('requested_qt_quick_backend' in plan and
        (requested is None or type(requested) is str and requested=='software'),
        'Fixed renderer request absent/differs')
    require(('QT_QUICK_BACKEND' not in environment) if requested is None else
        environment.get('QT_QUICK_BACKEND')=='software', 'Inherited Qt Quick backend request differs')
    return {key:environment.get(key) for key in RENDERER_ENVIRONMENT_KEYS}


def validate_plan(plan):
    require(isinstance(W,Path) and W.is_absolute() and type(SOURCE_HEAD) is str and
        re.fullmatch('[0-9a-f]{40}',SOURCE_HEAD) and isinstance(WRAPPER,Path) and WRAPPER==W/'tools/experiments/run_manual_playback_soak.py' and
        type(WRAPPER_SHA) is str and re.fullmatch('[0-9a-f]{64}',WRAPPER_SHA) and
        isinstance(BINARY,Path) and BINARY.is_absolute() and type(BINARY_SHA) is str and re.fullmatch('[0-9a-f]{64}',BINARY_SHA) and
        type(COMPILE_COMMANDS_COUNT) is int and COMPILE_COMMANDS_COUNT>0,
        'Merged source/build bindings are absent; draft is unarmed')
    require(plan.get('schema')==1 and plan.get('mode')==MODE and plan.get('status') in ('draft_unarmed_pending_root_review','frozen_pending_fresh_readiness') and
        plan.get('source_root')==str(W) and plan.get('source_head')==SOURCE_HEAD and
        plan.get('seconds')==120 and plan.get('qualified') is False and plan.get('operator_seconds')==1200 and
        plan.get('requested_power_profile') == 'balanced' and
        plan.get('command_seconds')==540 and plan.get('no_retries') is True and
        plan.get('background') is False and plan.get('active_controls') is True,'Fixed source/visible-controls workload differs')
    require('requested_qt_quick_backend' in plan and
        (plan['requested_qt_quick_backend'] is None or
         type(plan['requested_qt_quick_backend']) is str and plan['requested_qt_quick_backend']=='software'),
        'Fixed renderer request absent/differs')
    require(plan['requested_qt_quick_backend'] is None,'Profile pair requires the same default UI')
    a=plan['assets'];require(a['runtime']['sha256']==RUNTIME_SHA and a['model']['sha256']==MODEL,
        'Normal runtime/model identities differ')
    fixed={'binary':BINARY,
        'runtime':RUNTIME,
        'service':W/'tools/stems/service.py','python':Path('/usr/bin/python3.14'),'model':Path('/tmp/conflux-stem-m0/models/htdemucs-f16.gguf'),
        'exporter':W/'tools/stems/export.py','worker':W/'tools/stems/worker.py',
        'track_a':ROOT/'benchmarks-local/user-tracks-2026-10-17/assets/club_xl-30s-23p4s.wav',
        'track_b':ROOT/'benchmarks-local/m1-handoff-2026-10-17/quiet-soak-1.wav',
        'guard_script':Path('/home/kyau/.local/bin/thermal-guard'),'guard_unit':Path('/home/kyau/.config/systemd/user/thermal-guard.service')}
    require(set(a)==set(fixed) and all(a[k]['path']==str(path) for k,path in fixed.items()) and
        a['binary']['sha256']==BINARY_SHA and
        a['track_a']['sha256']=='1b959a945c5169b3bbfcfb8b1c1c7a3b8ca5aa885bfda36a56d967d74d700023',
        'Fixed normal asset path/binary/track differs')
    rows=[*a.values(),*plan['helpers'].values(),*plan['sources'].values(),plan['build_receipt'],plan['source_build_attestation']]
    require(all(type(r) is dict and type(r.get('bytes')) is int and r['bytes']>0 and
        Path(r.get('path','')).is_absolute() and re.fullmatch('[0-9a-f]{64}',r.get('sha256') or '') for r in rows),'Frozen file pins incomplete')
    require(plan['sources']['launcher']['path']==str(Path(__file__).resolve()) and
        plan['helpers']['wrapper']['path']==str(WRAPPER) and plan['helpers']['wrapper']['sha256']==WRAPPER_SHA and
        plan['helpers']['oracle']['sha256']==ORACLE_SHA and plan['helpers']['utility']['sha256']==UTILITY_SHA and
        plan.get('diagnostic_environment')=='absent','Fixed private binding differs')
    require(plan['helpers'].get('admission_readiness')=={'path': '/home/kyau/projects/kyaulabs/conflux/build/m2-host-boundaries-01/native-profile-read-01/normal_ready_native.py', 'bytes': 12727, 'sha256': '0498ae5e42b21ef36526dc2cd62d3dcd09e59c67a219d2224d48dd2650dee1a4'} and
        plan['helpers'].get('native_profile_binary')=={'path': '/usr/bin/busctl', 'bytes': 91184, 'sha256': '37e2862597d54c8148ebaa8ae048c1635c647a7cc4e2f73011835489a0308bd0'},
        'Fixed native profile readiness closure differs')
    require(plan.get('arm')==ARM and plan.get('power_limits')==CAP_CEILINGS and
        plan['helpers'].get('exact_pcm_prerequisite')==PCM_PREREQUISITE, 'Fixed row-tile/cap/prerequisite binding differs')
    return plan


def verify_files(plan,deadline=math.inf):
    for row in [*plan['assets'].values(),*plan['helpers'].values(),*plan['sources'].values(),plan['build_receipt'],plan['source_build_attestation']]:
        pin_read(row['path'],row,maximum=1024**3 if row['path']==plan['assets']['track_b']['path'] else 256*1024**2,deadline=deadline)
    receipt=decode(pin_read(plan['build_receipt']['path'],plan['build_receipt'],maximum=1024**2,deadline=deadline,keep=True)[1])
    require(receipt.get('refresh_exit')==0 and receipt.get('all_compiles_O2_without_coverage_or_fast_math') is True and receipt.get('compile_commands_count')==COMPILE_COMMANDS_COUNT and
        receipt.get('source_head')==plan['source_head'] and receipt.get('source_root')==str(W) and
        receipt.get('binary')==plan['assets']['binary'] and receipt.get('cache')==plan['helpers']['build_cache'] and receipt.get('compile_commands')==plan['helpers']['compile_commands'],
        'Final optimized current-player build/source binding differs')
    commands=decode(pin_read(plan['helpers']['compile_commands']['path'],plan['helpers']['compile_commands'],maximum=1024**2,deadline=deadline,keep=True)[1])
    require(len(commands)==COMPILE_COMMANDS_COUNT,'Compilation row count differs')
    for command in commands:
        tokens=command.get('arguments') or shlex.split(command['command'])
        require([x for x in tokens if re.fullmatch(r'-O[0-9sgz]|-Ofast',x)]==['-O2'] and
            not any(x in ('--coverage','-ffast-math','-funsafe-math-optimizations') or
                x.startswith(('-fprofile','-fcoverage')) for x in tokens), 'Optimized noninstrumented player flags differ')
    cache=pin_read(plan['helpers']['build_cache']['path'],plan['helpers']['build_cache'],maximum=1024**2,deadline=deadline,keep=True)[1]
    require(b'\nCMAKE_BUILD_TYPE:STRING=RelWithDebInfo\n' in cache,'Player build type differs')
    attestation=decode(pin_read(plan['source_build_attestation']['path'],plan['source_build_attestation'],maximum=128*1024,deadline=deadline,keep=True)[1])
    require(attestation.get('source_root')==str(W) and attestation.get('source_head')==plan['source_head'] and
        attestation.get('binary')==plan['assets']['binary'] and attestation.get('source_pins')==plan['current_source_pins'] and
        attestation.get('build_receipt_sha256')==plan['build_receipt']['sha256'] and
        attestation.get('tracked_sources_match_head') is True and attestation.get('build_completed_from_pinned_source') is True,
        'Root source-to-optimized-build attestation absent/different')
    for row in plan['current_source_pins']:
        require(Path(row['path']).is_relative_to(W) and plan['sources'].get(row['path'])==row,'Current source closure differs')
    for name in ('worker.py','export.py','service.py'):
        require(pin_read(ROOT/'tools/stems'/name,deadline=deadline)[0]['sha256']==
                pin_read(W/'tools/stems'/name,deadline=deadline)[0]['sha256'],'Production Python alias drift')

    proof=decode(pin_read(plan['helpers']['exact_pcm_prerequisite']['path'],PCM_PREREQUISITE,maximum=128*1024,deadline=deadline,keep=True)[1])
    require(proof.get('status')=='retained_result_verified' and proof.get('qualified') is False and
        proof.get('runtime')==plan['assets']['runtime'] and proof.get('arm')==ARM and
        all(proof.get(k)==16 for k in ('completed_requests','exact_reference_pcm_matches','input_producer_and_written_identity_matches','valid_coarse_gpu_intervals')) and
        proof.get('cleanup_verified') is True and proof.get('guard_unchanged') is True and
        proof.get('candidate_graph',{}).get('graph_nodes')==2871 and
        proof['candidate_graph'].get('query_tile_rows')==(4 if ARM=='baseline' else 2), 'Exact16 current-runtime tile prerequisite differs')


def decode_lines(path,maximum,deadline=math.inf):
    raw=pin_read(path,maximum=maximum,deadline=deadline,keep=True)[1];require(raw.endswith(b'\n'),'Partial context line')
    require(all(len(x)<=32768 for x in raw.splitlines()) if maximum<=4*1024**2 else True,'Context row bound exceeded')
    return [decode(x) for x in raw.splitlines()]



def validate_measurement(native):
    wall=native.get('measured_wall_ms');begin=native.get('measurement_begin_output_frame');end=native.get('measurement_end_output_frame')
    require(type(wall) in (int,float) and math.isfinite(wall) and 120000<=wall<=122000 and
        type(begin) is int and type(end) is int and 0<=begin<end and
        abs((end-begin)/48000-wall/1000)<=max(.25,wall/1000*.002) and
        native.get('requested_seconds')==120 and native.get('measurement_intervals_closed') is True and
        native.get('last_recovery_complete') is True,'Completed120s wall/output/closed-control evidence absent')
    intervals=native.get('intervals');require(type(intervals) is list and 0<len(intervals)<=2048,'Measurement partition absent')
    cursor=begin
    for row in intervals:
        first,last=row.get('output_begin'),row.get('output_end')
        require(type(first) is int and type(last) is int and first==cursor and first<=last<=end and
            type(row.get('frames')) is int and row['frames']==last-first and row.get('aborted') is False,
            'Measurement partition open/aborted/noncontiguous')
        cursor=last
    require(cursor==end,'Measurement endpoint omitted')
    return {'complete_120s':True,'measured_wall_ms':wall,'output_frames':end-begin,
        'output_seconds':(end-begin)/48000,'closed_intervals':len(intervals),
        'scope':'Duration/completeness only; original functional/audio/target/qualification flags remain separate.'}


def verify_capture(path,row,deadline):
    expected=row['retained_file']
    require(type(expected.get('bytes')) is int and 0<=expected['bytes']<=32*1024**2 and
        expected.get('path')==str(path) and row.get('complete') is True and
        type(row.get('bytes_received')) is int and row['bytes_received']==expected['bytes'],
        'Native bounded capture receipt differs')
    if expected['bytes']:
        actual=pin_read(path,expected,maximum=32*1024**2,deadline=deadline)[0]
    else:
        # The normal soak writes native-result.json and may emit no stdout or
        # stderr. Only these capture files admit an exactly empty regular file.
        require(time.monotonic()<deadline and path.resolve(strict=True)==path,'Capture deadline/path differs')
        fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_CLOEXEC|os.O_NOFOLLOW)
        try:
            before=os.fstat(fd)
            require(stat.S_ISREG(before.st_mode) and before.st_size==0,'Empty capture size/type differs')
            signature=lambda value:(value.st_dev,value.st_ino,value.st_mode,value.st_size,value.st_mtime_ns,value.st_ctime_ns)
            require(signature(before)==signature(os.fstat(fd))==signature(path.stat(follow_symlinks=False)),
                'Empty capture identity changed')
            actual={'path':str(path),'bytes':0,'sha256':hashlib.sha256(b'').hexdigest()}
        finally:os.close(fd)
    require(time.monotonic()<deadline and {k:actual[k] for k in ('path','bytes','sha256')}==expected and row.get('sha256_received')==actual['sha256'],
        'Native bounded capture byte/hash completion differs')
    return actual


def number(value):
    return type(value) in (int,float) and math.isfinite(value) and value>=0


def zeroes(value,keys):
    return all(type(value.get(k)) is int and value[k]==0 for k in keys)


def assess_visible(result,wrapper):
    """Recompute the service oracle; retain functional and timing verdicts separately."""
    errors, target, count, p99, misses = [], False, 0, None, None
    try:
        o = result['observations']; hops = o['service_hops']; rows = o['chunk_phases']['hops']; fields = o['chunk_phases']['fields']
        telemetry = o['service_telemetry_loss']
        count = hops['count']
        require(type(count) is int and 0 < count <= 16384 and len(rows) == count
            and o['kind_counts']['ChunkValidated'] == count and hops['complete'] is True
            and hops['strict_target_ms'] == 4095 and o['service_metrics_complete'] is True
            and type(telemetry) is list and bool(telemetry) and telemetry[-1].get('kind') == 'ServiceClosed'
            and all(type(x.get('dropped')) is int and x['dropped'] == 0 for x in telemetry), 'Hop population/final loss evidence differs')
        require(set(fields) == set(PHASES) and all(type(fields[k].get('count')) is int and fields[k]['count'] == count
            and fields[k].get('present_for_all_chunks') is True for k in PHASES)
            and all(number(row.get(k)) for row in rows for k in PHASES), 'All thirteen finite phase populations required')
        values = [row['hop_service_ms'] for row in rows]
        require(all(number(v) for v in values), 'Invalid hop duration')
        p99 = sorted(values)[math.ceil(.99*count)-1]; misses = sum(v >= 4095 for v in values)
        require(number(hops.get('nearest_rank_p99_ms')) and hops['nearest_rank_p99_ms'] == p99
            and number(hops.get('maximum_ms')) and hops['maximum_ms'] == max(values) and type(hops.get('at_or_above_target')) is int
            and hops['at_or_above_target'] == misses, 'Reported service statistics differ')
        target = p99 < 4095
        n = result['native']; c = result['cleanup']; counters = n['observation_counters']; recording = n['recording']
        require(result.get('passed') is True and zeroes(result, ('native_exit',)) and result.get('stop_reason') is None
            and result.get('qualified') is False and result.get('ui_mode') == 'visible'
            and result.get('visible_ui_required') is True and result.get('within_wall_budget') is True
            and result.get('wall_budget_seconds') == 300 and result.get('pins_unchanged') is True
            and bool(result['pins_before']) and result['pins_before'] == result['pins_after']
            and bool(result['guard_before']) and result['guard_before'] == result['guard_after']
            and not any(v for k,v in result.items() if k == 'error' or k.endswith('_error')), 'Wrapper functional completion differs')
        require(n.get('passed') is True and n.get('error') == '' and n.get('shutdown_completed') is True
            and n.get('functional_only') is False and n.get('host_audio') is True and n.get('source_root') == str(W)
            and n.get('ui_mode') == n.get('window_policy') == 'visible'
            and n['ui_coverage']['visible_ui_qualification_eligible'] is True
            and n['ui_coverage']['any_gap'] is False
            and n['ui_coverage']['visible_healthy_checks'] == n['ui_coverage']['checks']
            and zeroes(n['ui_coverage'], ('missing_window_checks','hidden_checks','unexposed_checks','stale_frame_checks','missing_frame_checks')) and type(n['ui_coverage']['checks']) is int
            and n['ui_coverage']['checks'] > 0
            and zeroes(n, ('steady_starved_frames', 'starved_frames_outside_measured_intervals',
                'execution_deadline_misses', 'invalid_buffers', 'rejected_commands', 'source_read_failures'))
            and n['intervals'] and all(zeroes(x, ('starved_b',)) for x in n['intervals']), 'Native visible/audio health differs')
        actions=wrapper.validate_active_controls(n,o)
        require(actions==result.get('active_controls') and actions.get('actions')==16 and
            actions.get('functional_only') is False and actions.get('qualified') is False,
            'Actual16-action visible evidence differs')
        require(counters.get('producer_finished') is True and type(counters.get('attempted')) is int
            and type(counters.get('retained')) is int and counters['attempted'] == counters['retained'] > 0
            and zeroes(counters, ('dropped', 'invalid_clock_reads')), 'Observation loss or incomplete producer')
        require(recording.get('status') == 'Complete' and recording.get('error') == '' and recording.get('active') is False
            and zeroes(recording, ('overflowFrames',)) and type(recording.get('writtenFrames')) is int
            and recording['acceptedFrames'] == recording['writtenFrames'] == n['recorded_audio']['frames'] > 0
            and n['recorded_audio']['sample_rate'] == 48000 and n['recorded_audio']['channels'] == 2, 'Recording completion differs')
        require(result.get('cleanup_proven') is True and result.get('owned_cache_removed') is True and result.get('cache_preserved') is False
            and all(c.get(k) is True for k in ('ownership_complete', 'leader_reaped', 'cooperative_native_shutdown', 'engine_processes_observed'))
            and c.get('remaining_known_processes') == c.get('remaining_live_jobs') == []
            and zeroes(c, ('remaining_pipewire_count', 'ownership_failure_count'))
            and bool(c.get('owned_group_absent')) and all(v is True for v in c['owned_group_absent'].values())
            and c.get('ownership_failure_overflow') is False
            and set(result['capture']) == {'stdout', 'stderr'} and all(x.get('complete') is True for x in result['capture'].values()), 'Cleanup/capture incomplete')
        require(all(result['power_'+x]['ac_online'] is True and result['power_'+x]['lid_open'] is True for x in ('before', 'after')), 'Power/lid completion differs')
    except (RuntimeError, KeyError, TypeError, ValueError, OverflowError, AttributeError, IndexError) as error:
        errors.append(str(error))
    return dict(functional_passed=not errors, service_target_met=target, passed=not errors and target,
        qualified=False, timing_qualification=False, visible_ui_qualification=False, errors=errors,
        hop_count=count, nearest_rank_p99_ms=p99, at_or_above_target=misses, strict_target_ms=4095)



def read_owner_clock(plan_pin,human_pin,deadline,driver_started):
    # Existing owner checkpoint is committed before it starts this launcher.
    row,raw=pin_read(BASE/'dispatch-01.json',maximum=4*1024**2,deadline=deadline,keep=True)
    owned=decode(raw);began=owned.get('started_monotonic');end=owned.get('deadline_monotonic')
    require(type(owned.get('schema')) is int and owned.get('schema')==1 and owned.get('mode')==MODE and
        owned.get('plan_pin')==plan_pin and owned.get('human_pin')==human_pin and
        owned.get('command_maximum_seconds')==540 and owned.get('term_seconds')==525 and
        owned.get('kill_seconds')==537 and number(began) and began<=driver_started and
        number(end) and end==began+540 and end<=deadline,
        'Existing original owner clock/plan/human binding differs')
    return {'started_monotonic':began,'deadline_monotonic':end,
        'term_monotonic':began+525,'kill_monotonic':began+537,'checkpoint_pin':row}


def retain_post_run_evidence(plan,plan_pin,human_pin,result,report,deadline):
    if isinstance(result,dict) and report.get('native_launched') is True:
        c=result.get('cleanup',{})
        report['public_cleanup_proven']=result.get('cleanup_proven')
        report['cleanup_complete']=False
        try:
            require(report.get('raw_capture_complete') is True and result.get('cleanup_proven') is True and
                result.get('owned_cache_removed') is True and result.get('cache_preserved') is False and
                all(c.get(k) is True for k in ('ownership_complete','leader_reaped','cooperative_native_shutdown','engine_processes_observed')) and
                c.get('remaining_known_processes')==c.get('remaining_live_jobs')==[] and
                zeroes(c,('remaining_pipewire_count','ownership_failure_count')) and
                bool(c.get('owned_group_absent')) and all(v is True for v in c['owned_group_absent'].values()) and
                c.get('ownership_failure_overflow') is False and set(result['capture'])=={'stdout','stderr'} and
                all(x.get('complete') is True for x in result['capture'].values()),'Independent cleanup/capture evidence incomplete')
            report['cleanup_complete']=True
        except Exception as error:
            report['errors'].append({'phase':'cleanup_evidence','type':type(error).__name__,'message':str(error)[:8192]})
    report['post_run_frozen_inputs_unchanged']=False
    try:
        verify_files(plan,deadline)
        require(pin_read(PLAN,plan_pin,maximum=256*1024,deadline=deadline)[0]==plan_pin and
            pin_read(HUMAN,human_pin,maximum=16384,deadline=deadline)[0]==human_pin,'Plan/readiness changed')
        report['post_run_frozen_inputs_unchanged']=True
    except Exception as error:
        report['errors'].append({'phase':'post_run_frozen_inputs','type':type(error).__name__,'message':str(error)[:8192]})


def prepare_admission(plan,report,deadline,started,checkpoint):
    # These exact read-only helpers already owned fixed4's normal admission.
    owner=load_source('player_host_admission_owner',Path(plan['helpers']['admission_owner']['path']),
        '722784d8a1f5448791f43e46a94d3fa4e2dc2128c4faa2878c40dd372c532cfd')
    observer=load_source('player_host_admission_readiness',Path(plan['helpers']['admission_readiness']['path']),
        '0498ae5e42b21ef36526dc2cd62d3dcd09e59c67a219d2224d48dd2650dee1a4')
    requested=plan['requested_power_profile']
    require(requested in ('balanced','performance'),'Fixed power profile absent/differs')
    guard_args=[Path(plan['assets'][k]['path']) for k in ('guard_script','guard_unit')]
    guard=owner.guard_identity(*guard_args);sensors=owner.sensor_paths()
    zones=[Path(p).parent for p,t in sensors.items() if t=='x86_pkg_temp']
    require(len(zones)==1,'Exactly one package zone required')
    limit=min(started+270,deadline-150)
    recovery_limit=min(started+120,limit-60)
    require(time.monotonic()<limit,'No original budget for cooldown and120s workload')
    report.update(guard_before=guard,cooldown_deadline=limit,initial_recovery_deadline=recovery_limit,
        initial_recovery_samples=[],cool_readiness=[],fresh_admissions=[])
    def conditions(label):
        power=owner.power_state();require(power['ac_online'] and power['lid_open'],'AC/open lid changed: '+label)
        row=owner.observation(sensors);row.update(power=power,phase=label)
        report.setdefault('host_observations',[]).append(row);checkpoint()
        require(len(report['host_observations'])<=32+FINAL_SETTLE_PAIRS-1,'Admission sample bound exceeded')
        require(not row['read_errors'],'Host observation failed: '+label)
        values=row['profile_epp_read_only']
        require(values.get('/sys/firmware/acpi/platform_profile') in ('balanced','low-power','performance') and
            values.get('/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference') in
            ('performance','balance_performance','balance_power','power','default'),'Unknown/empty platform/EPP admission value')
        return row
    expected={k:guard['service'][k] for k in ('MainPID','InvocationID')}
    require(str(expected['MainPID']).isdigit() and int(expected['MainPID'])>0 and
        re.fullmatch('[0-9a-fA-F]{32}',expected['InvocationID']), 'Initial guard identity malformed')
    def observer_fresh_ok(row):
        temp=row.get('package_millidegrees_C')
        return (not row['errors'] and observer.identity(row)==expected and row.get('profile')=='balanced' and
            row.get('holds')=='' and row.get('latest_message_claims_recovered') and row.get('journal_identity_matches_service') and
            type(temp) is int and 0<=temp<=70000)
    def host_fresh_ok(observed):
        temp=observed['temperatures_millidegrees_C'].get(str(zones[0]/'temp'))
        epp=observed['profile_epp_read_only']
        return (type(temp) is int and 0<=temp<=70000 and epp.get('/sys/firmware/acpi/platform_profile')=='balanced' and
            epp.get('/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference')=='balance_performance')
    recovery_started=False
    def initial_recovery():
        nonlocal recovery_started
        require(not recovery_started,'Single initial natural recovery already attempted; no retry')
        recovery_started=True;report['initial_recovery_started']=True;checkpoint()
        while time.monotonic()<recovery_limit:
            row=observer.capture(zones[0],recovery_limit);observer.ready(row,expected)
            row.update(phase='initial_natural_recovery',ready_observation=False)
            report['initial_recovery_samples'].append(row);checkpoint()
            require(len(report['initial_recovery_samples'])<=16,'Initial recovery sample bound exceeded')
            try:
                require(not row['errors'],'Initial recovery observation failed')
                require(observer.identity(row)==expected,'Guard changed during initial recovery')
                require(row.get('profile') in ('balanced','power-saver','performance'),'Unknown initial recovery profile')
                observed=conditions('initial_natural_recovery')
                require(owner.guard_identity(*guard_args)==guard,'Guard identity changed during initial recovery')
                good=observer_fresh_ok(row) and host_fresh_ok(observed)
                row['ready_observation']=good
                if good:
                    require(time.monotonic()<recovery_limit,'Original initial recovery deadline exhausted')
                    report['initial_recovery_complete']=True;checkpoint();return row
            except Exception as error:
                row['rejection']={'type':type(error).__name__,'message':str(error)[:8192]}
                raise
            finally:checkpoint()
            time.sleep(max(0,min(10,recovery_limit-time.monotonic())))
        raise ValueError('Initial natural guard recovery not observed within original120s bound')
    cooldown_started=False
    def cooldown():
        nonlocal cooldown_started
        require(report.get('initial_recovery_complete') is True,'Initial natural recovery must complete before cooldown')
        require(not cooldown_started,'Single cooldown already attempted; no retry')
        cooldown_started=True;report['cooldown_started']=True;checkpoint()
        require(time.monotonic()<limit,'Original cooldown deadline already exhausted')
        since=previous=None
        while time.monotonic()<limit:
            row=observer.capture(zones[0],limit);now=row['finished_monotonic'];current=observer.identity(row)
            require(current is None or current==expected,'Guard changed during cooldown')
            good=observer.ready(row,expected) and (previous is None or now-previous<=20)
            observed=conditions('cool_readiness')
            observed_temp=observed['temperatures_millidegrees_C'].get(str(zones[0]/'temp'))
            good=(good and observed['profile_epp_read_only'].get('/sys/firmware/acpi/platform_profile')=='balanced' and
                type(observed_temp) is int and 0<=observed_temp<=55000)
            since=(since if since is not None else now) if good else None
            row.update(ready_observation=good,consecutive_span_seconds=now-since if since is not None else 0)
            report['cool_readiness'].append(row);checkpoint()
            if good and now-since>=60:break
            previous=now;time.sleep(max(0,min(10,limit-time.monotonic())))
        require(since is not None and time.monotonic()<limit and report['cool_readiness'][-1]['consecutive_span_seconds']>=60,
            'Original bounded60s<=55C normal cooldown failed')
        report['cooldown_complete']=True;checkpoint()
    def fresh(label,thermal_work_deadline=None):
        require(report.get('initial_recovery_complete') is True,'Initial natural recovery must complete before strict fresh admission')
        require(time.monotonic()<deadline-150,'Original command has insufficient dispatch/cleanup room')
        final=label=='public_readiness_before_Popen'
        settle_started=time.monotonic();limit=min(deadline-150,settle_started+FINAL_SETTLE_SECONDS) if final else deadline-150
        if final and thermal_work_deadline is not None:limit=min(limit,thermal_work_deadline)
        command=owner.read_command if final else None
        if final:
            settle={'started_monotonic':settle_started,'deadline_monotonic':limit,
                'temperature_only_working_room_deadline_monotonic':thermal_work_deadline,
                'maximum_seconds':FINAL_SETTLE_SECONDS,'maximum_pairs':FINAL_SETTLE_PAIRS,'accepted':False}
            report['final_temperature_settle']=settle;checkpoint()
            def bounded_command(argv,timeout=3):
                remaining=limit-time.monotonic()
                require(remaining>0,'Fresh<=70C final heat-only sampling deadline exhausted')
                return command(argv,timeout=min(timeout,remaining))
            owner.read_command=bounded_command
        try:
            for attempt in range(1,(FINAL_SETTLE_PAIRS if final else 1)+1):
                if final and time.monotonic()>=limit:
                    reason=('Insufficient original210s native working room during final heat-only settling' if
                        thermal_work_deadline is not None and thermal_work_deadline<=limit else
                        'Fresh<=70C final heat-only settling exhausted original5s bound')
                    settle['stop_reason']=reason;checkpoint();raise ValueError(reason)
                row=observer.capture(zones[0],min(limit,time.monotonic()+15))
                observer.ready(row,expected)  # Derive flags; fresh threshold remains70C.
                row.update(phase=label,accepted=False)
                if final:row.update(settle_attempt=attempt,settle_started_monotonic=settle_started,settle_deadline_monotonic=limit)
                report['fresh_admissions'].append(row);checkpoint()
                require(len(report['fresh_admissions'])<=4+FINAL_SETTLE_PAIRS-1,'Fresh admission sample bound exceeded')
                try:
                    temp=row.get('package_millidegrees_C')
                    require(not row['errors'] and observer.identity(row)==expected and row.get('profile')==requested and
                        row.get('holds')=='' and row.get('latest_message_claims_recovered') and row.get('journal_identity_matches_service') and
                        type(temp) is int and temp>=0,'Fresh<=70C requested-profile/recovered/same-guard admission failed')
                    observed=conditions(label)
                    row['paired_host_observation_index']=len(report['host_observations'])-1
                    host_temp=observed['temperatures_millidegrees_C'].get(str(zones[0]/'temp'))
                    row['host_package_millidegrees_C']=host_temp
                    values=observed['profile_epp_read_only']
                    require(values.get('/sys/firmware/acpi/platform_profile')==requested and
                        values.get('/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference')==
                        ('balance_performance' if requested=='balanced' else 'performance'),
                        'Requested profile/EPP admission absent')
                    require(type(host_temp) is int and host_temp>=0,'Fresh package temperature read invalid')
                    require(owner.guard_identity(*guard_args)==guard,'Guard identity changed before dispatch')
                    require(time.monotonic()<deadline-150,'Final admission exhausted original dispatch/cleanup reserve')
                    require(not final or time.monotonic()<limit,'Fresh<=70C final heat-only sampling deadline exhausted')
                    if temp<=70000 and host_temp<=70000:
                        row['accepted']=True
                        if final:settle.update(accepted=True,accepted_attempt=attempt,finished_monotonic=time.monotonic())
                        return row
                    row['rejection_kind']='temperature_only'
                    row['rejection']={'type':'ValueError','message':f'Fresh<=70C package temperature above limit: observer={temp/1000:g}C, host={host_temp/1000:g}C'}
                except Exception as error:
                    row['rejection_kind']='fatal'
                    row['rejection']={'type':type(error).__name__,'message':str(error)[:8192]}
                    raise
                finally:checkpoint()
                if not final:raise ValueError(row['rejection']['message'])
                if thermal_work_deadline is not None:limit=min(limit,thermal_work_deadline)
                settle['effective_deadline_monotonic']=limit
                if attempt==FINAL_SETTLE_PAIRS or time.monotonic()>=limit:
                    reason=('Insufficient original210s native working room during final heat-only settling' if
                        thermal_work_deadline is not None and thermal_work_deadline<=limit else
                        'Fresh<=70C final heat-only settling exhausted original5s/pair bound')
                    settle['stop_reason']=reason;checkpoint();raise ValueError(reason)
                time.sleep(max(0,min(1,limit-time.monotonic())))
        finally:
            if final:
                owner.read_command=command
                settle['finished_monotonic']=time.monotonic();checkpoint()
    return fresh,initial_recovery,cooldown


def native_launch_state(result):
    group=result.get('owned_direct_group')
    if type(group) is int and group>1:return True
    # Exact public wrapper writes command before Popen and cleanup_proven only
    # after its no-child branch. An attempted but unrecorded launch is unknown.
    if ('command' not in result and 'native' not in result and group is None and
            result.get('cleanup_proven') is True):return False
    return None


def retain_prelaunch_failure(result,report,admission):
    detail=report.get('workload_error') or {'type':'RuntimeError',
        'message':'Public workload returned without launching a native child'}
    report.update(status='prelaunch_failed',failure_phase='public_wrapper_before_native_launch',
        ordinary_assessment={'functional_passed':False,'service_target_met':False,'passed':False,
            'qualified':False,'timing_qualification':False,'visible_ui_qualification':False,
            'errors':[detail['message']],'hop_count':0,'nearest_rank_p99_ms':None,'at_or_above_target':None,'strict_target_ms':4095})
    cleanup=result.get('cleanup',{})
    report['cleanup_complete']=(result.get('cleanup_proven') is True and result.get('owned_cache_removed') is True and
        cleanup.get('ownership_complete') is True and cleanup.get('proven_command_history')==[] and
        cleanup.get('ownership_failure_count')==0 and cleanup.get('ownership_failures')==[] and
        cleanup.get('ownership_failure_overflow') is False)
    report['cleanup_scope']='No native child launched; public-wrapper no-child/cache cleanup proof only'
    report['errors'].append(detail);admission['errors'].append(detail)


def validate_power_caps(values):
    require(type(values) is dict and set(values)==set(CAP_CEILINGS),'Power-cap field set differs')
    for path,ceiling in CAP_CEILINGS.items():
        value=values[path]
        require(type(value) is int and value>0,'Invalid power-cap value: '+path)
        require(value<=ceiling if path.endswith('_power_limit_uw') else value==ceiling,
            'Configured power cap increased or changed: '+path)
    return values


def read_power_caps():
    values={}
    for path in CAP_CEILINGS:
        with open(path,'rb',buffering=0) as stream:raw=stream.read(65)
        require(0<len(raw)<=64 and raw.strip().isdigit(),'Unreadable power-cap field: '+path)
        values[path]=int(raw)
    return values


def run(plan,plan_pin,human,human_pin):
    started=time.monotonic();clocks=budget(human,plan_pin['sha256'],datetime.now(timezone.utc),started)
    deadline=min(clocks['command_deadline'],clocks['operator_deadline'])
    verify_files(plan,deadline)
    require(not OUTPUT.exists() and not (BASE/'admission-01.json').exists() and
        not (BASE/'diagnostic-assessment.json').exists(),'One fresh player/admission output; no retries')
    require(not any(k.startswith(('GGML_VK_','GGML_VULKAN_','CONFLUX_DRM_','CONFLUX_REQUEST_TRACE_')) or
        k in ('MESA_GPU_TRACES','MESA_GPU_TRACEFILE','INTEL_DEBUG','CONFLUX_PRIVATE_ROUTING_CHECK') for k in os.environ),
        'Inherited diagnostic environment forbidden')
    inherited_environment=renderer_environment(plan,os.environ)
    oracle=load_source('private_host_player_oracle',ORACLE,ORACLE_SHA)
    oracle.environment_contract(os.environ)
    wrapper=load_source('private_host_player_workload',WRAPPER,WRAPPER_SHA)
    require(wrapper.FLASH_RUNTIME_SHA256==NORMAL and wrapper.FLASH_MODEL_SHA256==MODEL,'Public normal binding changed')
    original_runtime=wrapper.FLASH_RUNTIME_SHA256
    original_observation=wrapper.observation
    original_readiness=wrapper.live_readiness
    readiness_calls=0;public_started=None;result=None;owner_clock=None
    def ready(path,label,background=False):
        nonlocal readiness_calls
        require(path==HUMAN and label=='output-01' and background is False,'Fixed readiness scope differs')
        sample_caps('public_readiness')
        readiness_calls+=1
        require(readiness_calls in (1,2),'Public readiness call count/order differs')
        require(admission.get('cooldown_complete') is True and
            ((readiness_calls==1 and admission.get('public_readiness_calls') is None) or
             (readiness_calls==2 and admission.get('public_readiness_calls')==1)), 'Public readiness phase out of order')
        admission['public_readiness_calls']=readiness_calls;admission_checkpoint()
        current=original_readiness(path,label,background=False)
        require(current['pin']=={k:human_pin[k] for k in ('path','bytes','sha256')},'Human pin changed')
        require(current['record']==human,'Human record changed')
        budget(current['record'],plan_pin['sha256'],datetime.now(timezone.utc),time.monotonic())
        require(time.monotonic()<deadline,'Original command window exhausted')
        if readiness_calls==1:
            fresh_admission('public_readiness_before_setup')
        else:
            fresh_admission('public_readiness_before_Popen',thermal_work_deadline=min(
                deadline,owner_clock['term_monotonic'],public_started+PUBLIC_WORK_SECONDS)-MINIMUM_NATIVE_WORK_SECONDS)
            reserve_native_work('public_readiness_before_Popen')
        budget(current['record'],plan_pin['sha256'],datetime.now(timezone.utc),time.monotonic())
        return current
    def reserve_native_work(label):
        now=time.monotonic()
        public_stop=public_started+PUBLIC_WORK_SECONDS if public_started is not None else None
        stop=min(deadline,owner_clock['term_monotonic'],public_stop if public_stop is not None else math.inf)
        row={'label':label,'sampled_monotonic':now,'owner_term_monotonic':owner_clock['term_monotonic'],
            'public_working_stop_monotonic':public_stop,'working_seconds_remaining':stop-now,
            'minimum_working_seconds':MINIMUM_NATIVE_WORK_SECONDS,'accepted':stop-now>=MINIMUM_NATIVE_WORK_SECONDS}
        admission.setdefault('native_budget_samples',[]).append(row);admission_checkpoint()
        require(len(admission['native_budget_samples'])<=2,'Native dispatch sample bound exceeded')
        require(row['accepted'],'Insufficient original210s native working room; no clock renewal')

    report={'schema':1,'mode':MODE,'status':'failed','diagnostic_complete':False,'cleanup_complete':False,
        'qualified':False,'timing_qualification':False,'raw_capture_complete':False,'plan_pin':plan_pin,'human_pin':human_pin,
        'operator_clock':clocks,'errors':[],'diagnostic_environment_absent':True,
        'requested_qt_quick_backend':plan['requested_qt_quick_backend'],
        'requested_power_profile':plan['requested_power_profile'],
        'inherited_environment':inherited_environment,
        'scope':'Row-tile short visible16-controls actual-player diagnostic; no sustained/M2/M3, physical latency, pointer/touch or assistive-technology qualification.'}
    admission={'schema':1,'mode':MODE,'plan_pin':plan_pin,'human_pin':human_pin,'launched':False,'errors':[]}
    def admission_checkpoint():save(BASE/'admission-01.json',admission)
    report['admission']=admission
    def sample_caps(label):
        values=read_power_caps()
        snapshots=report.setdefault('configured_power_cap_snapshots',[])
        require(len(snapshots)<512,'Bounded cap snapshot limit exceeded')
        snapshots.append({'phase':label,'monotonic':time.monotonic(),'values':values})
        validate_power_caps(values)
        return values
    def monitored_observation(sensors):
        row=original_observation(sensors)
        row['configured_power_caps_read_only']=sample_caps('public_host_monitor')
        return row
    try:
        sample_caps('before_admission')
        owner_clock=read_owner_clock(plan_pin,human_pin,deadline,started)
        report['owner_clock']=owner_clock;deadline=min(deadline,owner_clock['deadline_monotonic'])
        fresh_admission,initial_recovery,cooldown=prepare_admission(plan,admission,deadline,started,admission_checkpoint)
        initial_recovery();cooldown()  # Single observed cooldown BEFORE the public wall clock.
        report['profile_selection']={'requested_profile':'balanced','setting_changed':False,'holds_created':False}
        reserve_native_work('before_public_wrapper')
        budget(human,plan_pin['sha256'],datetime.now(timezone.utc),time.monotonic())
        fresh_admission('cooldown_complete');fresh_admission('before_dispatch')
        sample_caps('before_public_wrapper')
        wrapper.FLASH_RUNTIME_SHA256=RUNTIME_SHA
        wrapper.observation=monitored_observation
        wrapper.live_readiness=ready
        args=SimpleNamespace(**{k:Path(v['path']) for k,v in plan['assets'].items()},seconds=120,
            live_stems=True,live_stems_hour=False,background=False,active_controls=True,output=OUTPUT,readiness_decision=HUMAN)
        admission['workload_dispatch_entered']=True;admission['launched']=None;admission_checkpoint()
        report['workload_dispatch_entered']=True;report['native_launched']=None
        # The public wrapper already saves result.json before printing its duplicate.
        # Leave native PIPE/file captures and stderr under their original limits.
        public_started=time.monotonic()  # Conservative lower bound on run_live's own unchanged clock origin.
        with open(os.devnull,'w') as summary_sink, contextlib.redirect_stdout(summary_sink):
            code=wrapper.run_live(args)
        result_pin,raw=pin_read(OUTPUT/'result.json',maximum=4*1024**2,deadline=deadline,keep=True);result=decode(raw)
        admission['launched']=native_launch_state(result);report['native_launched']=admission['launched'];admission_checkpoint()
        report['workload_exit']=code;report['workload_result_pin']=result_pin
        stop_reason=result.get('stop_reason')
        native=result.get('native',{})
        native_error=native.get('error') if isinstance(native,dict) and native.get('passed') is False else None
        if stop_reason or native_error or result.get('error') is not None:
            report['workload_error']={'type':'RuntimeError' if stop_reason or native_error else str(result.get('error_type','RuntimeError'))[:256],
                'message':str(stop_reason or native_error or result['error'])[:8192]}
        if admission['launched'] is False:
            retain_prelaunch_failure(result,report,admission);admission_checkpoint()
            return 1
        if report.get('workload_error'):
            report['errors'].append(report['workload_error']);admission['errors'].append(report['workload_error']);admission_checkpoint()
        require(readiness_calls==2,'Launched workload lacks both exact public readiness phases')
        report['native_quick_backend_environment']=native.get('quick_backend_environment')
        require(report['native_quick_backend_environment']==(plan['requested_qt_quick_backend'] or ''),
            'Native Qt Quick backend environment differs; requested renderer only, not graphics API proof')
        report['ordinary_assessment']=assess_visible(result,wrapper)
        rows=decode_lines(OUTPUT/'observations.jsonl',32*1024**2)
        hops=[r for r in rows if r.get('type')=='record' and r.get('hop_service_present') is True]
        require(set(result['capture'])=={'stdout','stderr'},'Native stdout/stderr capture population differs')
        for name,row in result['capture'].items():
            verify_capture(OUTPUT/('native.'+name+'.log'),row,deadline)
        report['raw_capture_complete']=True
        report['measurement']=validate_measurement(result['native'])
        require(len(result['cleanup']['runtime_processes'])==len(result['cleanup']['service_processes'])==1,
            'Native/service restart or ownership population differs')
        require(result['requested_seconds']==120 and result['ui_mode']=='visible' and result['qualified'] is False and
            bool(result.get('pins_before')) and result.get('pins_before')==result.get('pins_after') and
            bool(result.get('guard_before')) and result.get('guard_before')==result.get('guard_after') and
            result['cleanup_proven'] is True and result['owned_cache_removed'] is True and
            result['cleanup']['remaining_known_processes']==[] and all(result['cleanup']['owned_group_absent'].values()) and
            all(x['complete'] is True for x in result['capture'].values()),'Actual-player cleanup/source/capture gate failed')
        require(result['native']['setup']['runtime_sha256']==RUNTIME_SHA and result['native']['setup']['model_sha256']==MODEL and
            result['native']['setup']['input_frames']==1031940 and result['native']['setup']['output_frames']==1123201,
            'Actual engine/geometry binding differs')
        require(result['native']['configuration']==dict(backend='vulkan',threads=2,request_timeout_seconds=30,
            prime_bound_seconds=60,deck_a_gain=.25,deck_b_gain=1,master_gain=.25,stem_gains=[1,1,1,1]),
            'Normal Best/two-thread workload configuration differs')
        obs=result['observations'];count=obs['service_hops']['count'];phases=obs['chunk_phases']
        require(count==len(hops)>0 and all(all(number(row.get(k)) for k in PHASES) for row in hops) and set(phases['fields'])==set(PHASES) and
            all(phases['fields'][k]['count']==count and phases['fields'][k]['present_for_all_chunks'] is True for k in PHASES) and
            obs['service_metrics_complete'] is True and obs['service_hops']['complete'] is True and
            obs['service_telemetry_loss'][-1]['kind']=='ServiceClosed' and
            all(x['dropped']==0 for x in obs['service_telemetry_loss']) and
            result['native']['observation_counters']['dropped']==0 and
            result['native']['observation_counters']['attempted']==result['native']['observation_counters']['retained'],'Thirteen service phases/loss population incomplete')
        report['workload_evidence_complete']=True
    except Exception as error:
        detail={'type':type(error).__name__,'message':str(error)[:8192]}
        report['errors'].append(detail);admission['errors'].append(detail);admission_checkpoint()
        if not admission.get('workload_dispatch_entered'):
            report.update(status='admission_failed',failure_phase='before_public_wrapper',
                workload_dispatch_entered=False,native_launched=False,workload_cleanup_applicable=False,
                cleanup_scope='Public wrapper never entered; no public native/cache cleanup receipt exists. Outer owner remains process-absence authority.')
    finally:
        wrapper.FLASH_RUNTIME_SHA256=original_runtime
        wrapper.observation=original_observation
        wrapper.live_readiness=original_readiness
        try: sample_caps('after_workload')
        except Exception as cap_error:
            report['errors'].append({'phase':'final_power_caps','type':type(cap_error).__name__,'message':str(cap_error)[:8192]})
            report['power_caps_failed']=True
        if report.get('workload_dispatch_entered'):
            retain_post_run_evidence(plan,plan_pin,human_pin,result,report,deadline)
            if (report.get('workload_evidence_complete') is True and report.get('cleanup_complete') is True and
                    report.get('post_run_frozen_inputs_unchanged') is True):
                report.update(status='complete',diagnostic_complete=True,pins_unchanged=True,
                    passed=report['ordinary_assessment']['passed'] and not report.get('power_caps_failed'))
        report['finished_monotonic']=time.monotonic();report['within_command_budget']=time.monotonic()<=deadline
        if not report['within_command_budget']:report.update(status='failed',diagnostic_complete=False,passed=False)
        # Driver-owned receipt exists even when public wrapper/output never did.
        save(BASE/'diagnostic-assessment.json',report)
    return 0 if report.get('passed') is True and report['diagnostic_complete'] else 1


def main():
    parser=argparse.ArgumentParser(description=__doc__);group=parser.add_mutually_exclusive_group()
    group.add_argument('--run',action='store_true');group.add_argument('--verify-files',action='store_true');args=parser.parse_args()
    if not args.run and not args.verify_files:
        print(json.dumps({'status':'unarmed_dry_guarded_profile_pair','native_started':False,'host_queried':False,'seconds':120,'qualified':False}));return 0
    plan_pin,raw=pin_read(PLAN,maximum=256*1024,keep=True);plan=validate_plan(decode(raw))
    if args.verify_files:
        verify_files(plan);print(json.dumps({'status':'files_verified_only','native_started':False,'host_queried':False}));return 0
    require(plan.get('status')=='frozen_pending_fresh_readiness','Draft packet is unarmed pending root review')
    human_pin,raw=pin_read(HUMAN,maximum=16384,keep=True)
    return run(plan,plan_pin,decode(raw),human_pin)


if __name__=='__main__':raise SystemExit(main())
