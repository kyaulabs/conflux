"""Report both SALAMI annotators, both levels, and all eight admitted recordings."""
from pathlib import Path
import argparse
import hashlib
import json
import statistics
import sys

p = argparse.ArgumentParser()
p.add_argument('--policy', type=Path, required=True)
p.add_argument('--predictions', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
sys.path.insert(0, str(Path(__file__).resolve().parent))
from boundary_metrics import match_boundaries

policy = json.loads(a.policy.read_text())
assert policy['denominator'] == 8 and policy['tolerances_seconds'] == [.5, 3.]
references = policy['references']
ids = sorted({row['salami_id'] for row in references})
assert len(ids) == 8 and len(references) == 32
owner = json.loads(a.predictions.read_text())
assert owner['denominator'] == 8 and owner['GPU_used'] is False
predictions = {row['salami_id']: row.get('result') if row['completed'] else None for row in owner['cases']}
assert set(predictions).issubset(set(ids))
rows = []
summaries = []
agreement = []
for layer in policy['layers']:
    for tolerance in policy['tolerances_seconds']:
        agreement_cases = []
        for case_id in ids:
            first = next(r for r in references if r['salami_id'] == case_id and r['layer'] == layer and r['annotator'] == 1)
            second = next(r for r in references if r['salami_id'] == case_id and r['layer'] == layer and r['annotator'] == 2)
            agreement_cases.append(dict(salami_id=case_id, **match_boundaries(first['times'], second['times'], tolerance)))
        agreement.append(dict(layer=layer, tolerance_seconds=tolerance,
            mean_F1=statistics.mean(r['F1'] for r in agreement_cases), cases=agreement_cases))
        for annotator in policy['annotators']:
            subset = []
            for case_id in ids:
                reference = next(r for r in references if r['salami_id'] == case_id and r['layer'] == layer and r['annotator'] == annotator)
                predicted = predictions.get(case_id)
                available = predicted is not None and predicted['analysis_available']
                value = dict(salami_id=case_id, layer=layer, annotator=annotator,
                    tolerance_seconds=tolerance, available=available, metrics=None,
                    reference_count=len(reference['times']),
                    outside_EOF_annotations=reference['events_beyond_decoded_EOF_retained'])
                if available:
                    value['metrics'] = match_boundaries(reference['times'], predicted['internal_boundary_times'], tolerance)
                subset.append(value)
            complete = [r['metrics'] for r in subset if r['available']]
            summaries.append(dict(layer=layer, annotator=annotator, tolerance_seconds=tolerance,
                available_cases=len(complete), denominator=8,
                fixed_eight_mean_F1=sum(r['F1'] for r in complete) / 8,
                available_case_mean_F1=statistics.mean(r['F1'] for r in complete) if complete else None,
                available_case_mean_precision=statistics.mean(r['precision'] for r in complete) if complete else None,
                available_case_mean_recall=statistics.mean(r['recall'] for r in complete) if complete else None))
            rows += subset
report = dict(schema=1, denominator=8, inference_cases_completed=sum(v is not None for v in predictions.values()),
              analyses_available=sum(v is not None and v['analysis_available'] for v in predictions.values()),
              summaries=summaries, per_case=rows, inter_annotator_agreement=agreement,
              policy_sha256=hashlib.sha256(a.policy.read_bytes()).hexdigest(),
              prediction_receipt_sha256=hashlib.sha256(a.predictions.read_bytes()).hexdigest(),
              source_time_shift_seconds=0, annotations_clipped=False, best_annotator_selected=False,
              functional_class_accuracy_scored=False, phrase_or_bar_accuracy_qualified=False,
              confidence_calibrated=False, musical_accuracy_qualified=False,
              latency_qualified=False, production_enabled=False)
with a.output.open('x') as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({key: value for key, value in report.items() if key in
                 ['denominator', 'inference_cases_completed', 'analyses_available', 'summaries']}))
