"""Private graph-only loading of the pinned structure-model sources and tensors."""
from pathlib import Path
from types import ModuleType,SimpleNamespace
import hashlib,importlib,io,json,math,os,stat,sys,zipfile

def pinned_checkpoint(path,expected_sha256):
    fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_CLOEXEC|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb')as stream:
        before=os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode)or not 0<before.st_size<=2*1024*1024:
            raise ValueError('Checkpoint must be a bounded nonempty regular file')
        raw=stream.read(before.st_size+1)
        after=os.fstat(stream.fileno())
    if len(raw)!=before.st_size or (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)or hashlib.sha256(raw).hexdigest()!=expected_sha256:
        raise ValueError('Checkpoint identity differs')
    return raw

def check_archive(raw):
    try:
        with zipfile.ZipFile(io.BytesIO(raw))as archive:
            entries=archive.infolist()
            if not 0<len(entries)<=512 or sum(item.file_size for item in entries)>16*1024*1024:
                raise ValueError('Checkpoint archive exceeds its expanded-data bound')
    except zipfile.BadZipFile as error:
        raise ValueError('Checkpoint must use the published ZIP format')from error

class ConfigView(SimpleNamespace):
    def copy(self):
        return ConfigView(**vars(self))

def view(value):
    if isinstance(value,dict):
        return ConfigView(**{k:view(v)for k,v in value.items()})
    if isinstance(value,list):
        return [view(v)for v in value]
    if type(value)is float and not math.isfinite(value):raise ValueError('Nonfinite checkpoint configuration')
    if value is None or type(value)in(str,int,float,bool):return value
    raise ValueError('Checkpoint configuration contains a non-data value')

def load_graph(source,checkpoint,expected_sha256):
    import torch
    if torch.version.cuda is not None:raise ValueError('CPU-only assessment runtime required')
    raw=pinned_checkpoint(checkpoint,expected_sha256)
    check_archive(raw)
    data=torch.load(io.BytesIO(raw),map_location='cpu',weights_only=True)
    if not isinstance(data,dict)or set(data)!={'state_dict','config'}:
        raise ValueError('Unexpected checkpoint schema')
    state=data['state_dict'];cfg=data['config']
    if not isinstance(state,dict)or len(state)!=491 or not isinstance(cfg,dict):
        raise ValueError('Unexpected graph/configuration extent')
    if not(cfg['sample_rate']==44100 and cfg['hop_size']==441 and cfg['fps']==100 and
           cfg['data']['num_instruments']==4 and cfg['data']['num_labels']==10 and cfg['dim_input']==81 and
           cfg['depth']==11 and cfg['dim_embed']==24 and cfg['num_heads']==2 and
           cfg['kernel_size']==5 and cfg['dilation_factor']==2 and cfg['dilation_max']==3200):
        raise ValueError('Unexpected source-clock or input geometry')
    elements=0
    for name,value in state.items():
        if not isinstance(name,str)or not isinstance(value,torch.Tensor)or value.device.type!='cpu'or value.dtype!=torch.float32 or not torch.isfinite(value).all():
            raise ValueError('Unexpected nonfinite or non-F32 CPU weights')
        elements+=value.numel()
    if elements!=300631:raise ValueError('Unexpected parameter extent')
    package=Path(source)/'src/allin1'
    if 'allin1'not in sys.modules:
        # Load only the original graph modules. The CLI would start separation,
        # download models, register training services and remove byproducts.
        top=ModuleType('allin1');top.__path__=[str(package)];sys.modules['allin1']=top
        models=ModuleType('allin1.models');models.__path__=[str(package/'models')];sys.modules['allin1.models']=models
        config=ModuleType('allin1.config');config.Config=ConfigView;sys.modules['allin1.config']=config
    module=importlib.import_module('allin1.models.allinone')
    model=module.AllInOne(view(cfg))
    model.load_state_dict(state,strict=True)
    model.eval()
    return model
