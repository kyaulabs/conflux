"""Verify the explicitly interrupted publisher run before reusing its six tracks."""
from pathlib import Path
import hashlib
import json
import stat
import wave

IDS = [1342, 1268, 1100, 1278, 990, 1394, 1036, 1290]


def verify_pin(row):
    path = Path(row['path'])
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size != row['bytes']:
        raise ValueError('Preserved input is not the expected regular file')
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.lstat()
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    if digest != row['sha256'] or identity(before) != identity(after):
        raise ValueError('Preserved input changed')
    return path


def validate_preserved(plan):
    if ([c['salami_id'] for c in plan['cases']] != IDS
            or plan['fixed_denominator'] != 8
            or [r['salami_id'] for r in plan['preserved']] != IDS[:6]
            or plan['remaining_ids'] != IDS[6:]):
        raise ValueError('Continuation changed the fixed corpus partition')
    root = Path(plan['predecessor_root'])
    if not root.is_absolute() or root.is_symlink():
        raise ValueError('Invalid preserved corpus root')
    if Path(plan['predecessor_owner']['path']) != root / 'owner-result.json':
        raise ValueError('Wrong predecessor owner receipt')
    owner_path = verify_pin(plan['predecessor_owner'])
    owner = json.loads(owner_path.read_text())
    if (owner['passed'] is not False or owner['container_absent'] is not True
            or owner['inputs_unchanged'] is not True):
        raise ValueError('The interrupted predecessor is not closed and unchanged')
    if Path(plan['predecessor_plan']['path']) != root / 'plan.json':
        raise ValueError('Wrong predecessor plan')
    original = json.loads(verify_pin(plan['predecessor_plan']).read_text())
    for key in ('cases', 'fixed_denominator', 'roles', 'publisher_settings', 'assets', 'seed_rule'):
        if original[key] != plan[key]:
            raise ValueError('Continuation changed original source, settings or seeds')
    completed = []
    for case, frozen in zip(plan['cases'][:6], plan['preserved'], strict=True):
        folder = root / 'cases' / str(case['salami_id'])
        if folder.is_symlink() or Path(frozen['receipt']['path']) != folder / 'complete.json':
            raise ValueError('Unexpected preserved case path')
        receipt_path = verify_pin(frozen['receipt'])
        receipt = json.loads(receipt_path.read_text())
        if (receipt['salami_id'] != case['salami_id']
                or receipt['frames'] != case['decoded_frames']
                or receipt['input_sha256'] != case['decoded_F32_sha256']
                or receipt['seed'] != case['seed']
                or receipt['settings'] != plan['publisher_settings']
                or receipt['source_pcm_unchanged'] is not True
                or [o['role'] for o in receipt['outputs']] != plan['roles']):
            raise ValueError('Preserved receipt does not match its original input')
        for row in receipt['outputs']:
            path = folder / (row['role'] + '.wav')
            n = case['decoded_frames']
            if (row['file'] != str(path) or row['frames'] != n
                    or row['sample_rate'] != 44100 or row['channels'] != 2
                    or row['bits'] != 16 or not 0 < row['bytes'] <= n * 4 + 4096):
                raise ValueError('Preserved stem path, clock or format changed')
            verify_pin(dict(path=str(path), bytes=row['bytes'], sha256=row['sha256']))
            with wave.open(str(path), 'rb') as stream:
                if (stream.getnchannels(), stream.getsampwidth(), stream.getframerate(),
                        stream.getnframes(), stream.getcomptype()) != (2, 2, 44100, n, 'NONE'):
                    raise ValueError('Preserved WAV header changed')
        if verify_pin(frozen['receipt']) != receipt_path:
            raise ValueError('Preserved receipt changed while validating')
        completed.append(receipt)
    verify_pin(plan['predecessor_owner'])
    verify_pin(plan['predecessor_plan'])
    return completed
