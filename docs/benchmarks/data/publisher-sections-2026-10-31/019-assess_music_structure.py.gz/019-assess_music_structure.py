"""Run the unchanged eight-fold graph on one pinned full-recording feature file."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import resource
import stat
import sys
import time

p = argparse.ArgumentParser()
for name in ['packet', 'graph', 'natten', 'addons', 'features', 'output']:
    p.add_argument('--' + name, type=Path, required=True)
p.add_argument('--case', type=int, required=True)
a = p.parse_args()
assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
assert not any(Path(path).exists() for path in ['/dev/nvidia0', '/dev/dri', '/dev/snd'])
a.output.mkdir(mode=0o700, exist_ok=False)
sys.path[:0] = [str(a.packet), str(a.addons), str(a.natten)]
import numpy as np
import torch
assert torch.__version__ == '2.11.0+cpu' and torch.version.cuda is None
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
from boundary_metrics import predicted_boundaries
from model_bootstrap import load_graph
from postprocess_bootstrap import clock_view, load_postprocessors

started = time.monotonic()
folds = []
handles = []
models = []
error = None
result = dict(schema=1, salami_id=a.case, completed=False, analysis_available=False,
              GPU_used=False, audio_output=False, latency_qualified=False,
              musical_accuracy_qualified=False, production_enabled=False)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def progress(phase, model=None):
    value = dict(phase=phase, salami_id=a.case, model=model, completed_folds=folds,
                 seconds=time.monotonic() - started, GPU_used=False)
    temp = a.output / 'progress.tmp'
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(a.output / 'progress.json')


try:
    plan = json.loads((a.packet / 'plan.json').read_text())
    case = next(row for row in plan['features'] if row['salami_id'] == a.case)
    feature = a.features / (str(a.case) + '.npy')
    fd = os.open(feature, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        assert stat.S_ISREG(before.st_mode) and before.st_size == case['feature_bytes'] <= 64 * 1024**2
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == case['feature_sha256']
        stream.seek(0)
        array = np.load(stream, allow_pickle=False)
        after = os.fstat(stream.fileno())
        assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    assert list(array.shape) == case['shape'] and array.dtype == np.float32 and np.isfinite(array).all()
    assert array.shape[0] == 4 and array.shape[2] == 81 and 0 < array.shape[1] <= 40000
    assert case['role_order'] == ['bass', 'drums', 'other', 'vocals']
    frames = array.shape[1]
    source_duration = case['source_frames_48k'] / 48000
    assert (frames - 1) / 100 < source_duration
    features = torch.from_numpy(array).unsqueeze(0)
    manifest = json.loads((a.graph / 'checkpoint-acquisition-01.json').read_text())
    assert len(manifest['models']) == 8
    progress('loading-pinned-models')
    for row in manifest['models']:
        model = load_graph(a.graph / 'source', a.graph / 'models' / row['file'], row['sha256'])
        assert not model.training
        def before_fold(module, args, name=row['name']):
            progress('running-publisher-fold', name)
        def after_fold(module, args, output, name=row['name']):
            for field, shape in [('logits_beat', (1, frames)), ('logits_downbeat', (1, frames)),
                                 ('logits_section', (1, frames)), ('logits_function', (1, 10, frames)),
                                 ('embeddings', (1, 4, frames, 24))]:
                value = getattr(output, field)
                assert tuple(value.shape) == shape and value.dtype == torch.float32 and torch.isfinite(value).all()
            folds.append(name)
            progress('completed-publisher-fold', name)
        handles += [model.register_forward_pre_hook(before_fold), model.register_forward_hook(after_fold)]
        models.append(model)
    from allin1.models.ensemble import Ensemble
    ensemble = Ensemble(models).eval()
    clock_binding = json.loads((a.packet / 'clock/binding.json').read_text())
    clock_pin = next(row for row in clock_binding['files'] if row['file'] == 'librosa-convert.py')
    clock = clock_view(a.packet / 'clock/librosa-convert.py', clock_pin['sha256'])
    stock_functional, _ = load_postprocessors(a.graph / 'source', clock)
    candidate = a.packet / 'postprocess-source/src/allin1/postprocessing/functional.py'
    spec = importlib.util.spec_from_file_location('allin1.postprocessing.functional_candidate', candidate)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    with torch.no_grad():
        output = ensemble(features)
        assert len(folds) == 8 and len(set(folds)) == 8
        arrays = {}
        for field in ['logits_beat', 'logits_downbeat', 'logits_section', 'logits_function']:
            value = getattr(output, field)
            assert value.dtype == torch.float32 and torch.isfinite(value).all()
            arrays[field] = value.numpy()
        logits = a.output / 'ensemble-logits.npz'
        with logits.open('xb') as stream:
            np.savez_compressed(stream, **arrays)
        result['logits'] = dict(file=logits.name, bytes=logits.stat().st_size, sha256=sha(logits),
            fields={name: dict(shape=list(value.shape), sha256=hashlib.sha256(value.tobytes()).hexdigest())
                    for name, value in arrays.items()})
        progress('decoding-original-and-fixed-sections')
        try:
            stock = [dict(start=float(row.start), end=float(row.end), label=row.label)
                     for row in stock_functional(output, ensemble.cfg)]
            stock_error = None
        except Exception as exc:
            stock = None
            stock_error = type(exc).__name__ + ': ' + str(exc)
        fixed = [dict(start=float(row.start), end=float(row.end), label=row.label)
                 for row in module.postprocess_functional_structure(output, ensemble.cfg)]
        boundaries = predicted_boundaries(fixed, source_duration, frames)
    assert sha(feature) == case['feature_sha256']
    result.update(completed=True, analysis_available=bool(fixed), feature=case,
                  feature_frames=frames, source_duration_seconds=source_duration,
                  stock_segments=stock, stock_error=stock_error, candidate_segments=fixed,
                  stock_and_candidate_sections_identical=stock == fixed,
                  internal_boundary_times=boundaries, completed_folds=folds,
                  model_config=dict(fps=ensemble.cfg.fps, hop_size=ensemble.cfg.hop_size,
                                    sample_rate=ensemble.cfg.sample_rate,
                                    best_threshold_beat=ensemble.cfg.best_threshold_beat,
                                    best_threshold_downbeat=ensemble.cfg.best_threshold_downbeat),
                  class_labels_scored=False, source_time_shift_seconds=0)
    progress('complete')
except BaseException as exc:
    error = type(exc).__name__ + ': ' + str(exc)
    progress('stopped-with-error')
finally:
    for handle in handles:
        handle.remove()
result.update(error=error, seconds=time.monotonic() - started,
              peak_rss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
(a.output / 'result.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in
                 ['feature', 'model_config', 'logits', 'stock_segments', 'candidate_segments', 'completed_folds']}))
raise SystemExit(0 if result['completed'] and error is None else 1)
