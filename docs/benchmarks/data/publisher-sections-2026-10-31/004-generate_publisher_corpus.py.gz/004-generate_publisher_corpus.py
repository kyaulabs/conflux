"""Generate the fixed-eight publisher-default reference with the original API."""
from pathlib import Path
import fractions
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import random
import resource
import shutil
import signal
import sys
import time
import traceback
import wave as wavfile

import numpy as np
import torch
from demucs.apply import BagOfModels, apply_model
from demucs.audio import save_audio
from demucs.htdemucs import HTDemucs

ROOT = Path('/srv/conflux-tests/work/structure-analysis-20261031-01/publisher-corpus-continuation-01')
plan = json.loads((ROOT/'plan.json').read_text())
started = time.monotonic()
deadline = started+8700
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.manual_seed(0)
report = dict(passed=False, model_instantiated=False, model_started=False,
              GPU_used=False, audio_played=False, physical_readiness_consumed=False,
              production_runtime_modified=False, latency_qualified=False,
              musical_accuracy_qualified=False, fixed_denominator=8, tracks=[], errors=[])


def sha(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def progress(phase, identifier=None):
    temporary = ROOT/'progress.tmp'
    temporary.write_text(json.dumps(dict(phase=phase, salami_id=identifier,
        completed_tracks=len(report['tracks']), seconds=time.monotonic()-started))+'\n')
    temporary.replace(ROOT/'progress.json')


def interrupted(number, frame):
    raise InterruptedError('Owned publisher corpus signal '+str(number))


class ClassReference:
    def __new__(cls, *args, **kwargs):
        raise RuntimeError('Serialized model class must not be constructed')


for number in (signal.SIGTERM, signal.SIGINT):
    signal.signal(number, interrupted)


try:
    assert torch.__version__ == '2.8.0+cpu' and not torch.cuda.is_available()
    assert len(plan['cases']) == plan['fixed_denominator'] == 8
    assert {c['salami_id'] for c in plan['cases']} == {1342,1268,1100,1278,990,1394,1036,1290}
    spec = importlib.util.spec_from_file_location('continuation_inputs', ROOT/'continuation_inputs.py')
    continuation = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(continuation)
    preserved = continuation.validate_preserved(plan)
    report['tracks'] = preserved.copy()
    report.update(preserved_tracks=6, newly_requested_tracks=2,
                  original_attempt_retained_as_interrupted=True,
                  preserved_root=plan['predecessor_root'])
    proof = json.loads(Path(plan['decoder_proof']).read_text())
    assert proof['closed'] and proof['decode']['passed'] and proof['decode']['all_sample_bytes_equal']
    for row in plan['assets']:
        path = Path(row['path'])
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], str(path)
    checkpoint = Path(plan['checkpoint'])
    progress('restricted-checkpoint-load')
    allowed = [(ClassReference, 'demucs.htdemucs.HTDemucs'), fractions.Fraction,
               (np._core.multiarray.scalar, 'numpy.core.multiarray.scalar'), np.dtype,
               np.dtypes.Float64DType, np.dtypes.Float32DType,
               np.dtypes.Int64DType, np.dtypes.Int32DType, np.dtypes.BoolDType]
    assert set(torch.serialization.get_unsafe_globals_in_checkpoint(checkpoint)) <= {
        'demucs.htdemucs.HTDemucs','fractions.Fraction','numpy.core.multiarray.scalar','numpy.dtype'}
    with torch.serialization.safe_globals(allowed):
        package = torch.load(checkpoint, map_location='cpu', weights_only=True, mmap=True)
    assert package['klass'] is ClassReference
    model = HTDemucs(*package['args'], **package['kwargs'])
    model.load_state_dict(package['state'], strict=True)
    model.eval()
    assert list(model.sources) == plan['roles'] and model.audio_channels == 2 and model.samplerate == 44100
    assert int(model.segment*model.samplerate) == 343980
    assert all(p.device.type == 'cpu' and p.dtype == torch.float32 for p in model.parameters())
    bag = BagOfModels([model])
    bag.eval()
    report['model_instantiated'] = True
    report['versions'] = {name:importlib.metadata.version(name) for name in ('torch','torchaudio','numpy','soundfile','demucs')}
    del package
    cases_root = ROOT/'cases'
    cases_root.mkdir(mode=0o700)
    for case in plan['cases'][6:]:
        assert time.monotonic() < deadline, 'Original corpus deadline expired'
        identifier = case['salami_id']
        case_started = time.monotonic()
        progress('read-verified-common-PCM', identifier)
        source = Path(case['decoded_file'])
        assert source.stat().st_size == case['decoded_bytes'] and sha(source) == case['decoded_F32_sha256']
        frames = case['decoded_frames']
        assert source.stat().st_size == frames*8 and 0 < source.stat().st_size <= 256*1024**2
        assert shutil.disk_usage(ROOT).free >= frames*16+1024**3, 'Insufficient space for the next complete track'
        # Reconstruct the publisher loader's interleaved-backed channel-first layout.
        pcm = np.fromfile(source, dtype='<f4').reshape(frames, 2)
        wav = torch.from_numpy(pcm.T)
        ref = wav.mean(0)
        scale = float(ref.std())
        mean = float(ref.mean())
        assert math.isfinite(scale) and scale > 0 and math.isfinite(mean)
        # These in-place normalization and restoration steps match separate.main.
        wav -= ref.mean()
        wav /= ref.std()
        random.seed(case['seed'])
        report['model_started'] = True
        progress('publisher-apply-model-default-shift-and-split', identifier)
        inference_started = time.monotonic()
        sources = apply_model(bag, wav[None], device='cpu', shifts=1, split=True,
                              overlap=0.25, progress=True, num_workers=0, segment=None)[0]
        inference_seconds = time.monotonic()-inference_started
        assert tuple(sources.shape) == (4, 2, frames) and sources.dtype == torch.float32
        sources *= ref.std()
        sources += ref.mean()
        progress('save-publisher-rescaled-PCM16', identifier)
        destination = cases_root/str(identifier)
        destination.mkdir(mode=0o700)
        output_rows = []
        for tensor, role in zip(sources, plan['roles']):
            peak = 0.
            for first in range(0, frames, 65536):
                block = tensor[:, first:first+65536]
                assert torch.isfinite(block).all().item()
                peak = max(peak, float(block.abs().max()))
            path = destination/(role+'.wav')
            save_audio(tensor, path, samplerate=44100, bitrate=320, preset=2,
                       clip='rescale', as_float=False, bits_per_sample=16)
            with wavfile.open(str(path), 'rb') as stream:
                assert (stream.getnchannels(),stream.getsampwidth(),stream.getframerate(),stream.getnframes()) == (2,2,44100,frames)
                assert stream.getcomptype() == 'NONE'
            assert path.stat().st_size <= frames*4+4096
            output_rows.append(dict(role=role,file=str(path),bytes=path.stat().st_size,
                sha256=sha(path),frames=frames,sample_rate=44100,channels=2,bits=16,
                raw_output_peak=peak,publisher_rescale_gain=1/max(1.01*peak,1)))
        assert sha(source) == case['decoded_F32_sha256']
        row = dict(salami_id=identifier,frames=frames,input_sha256=case['decoded_F32_sha256'],
            source_pcm_unchanged=True,seed=case['seed'],mean=mean,sample_std=scale,
            settings=plan['publisher_settings'],outputs=output_rows,
            inference_seconds=inference_seconds,seconds=time.monotonic()-case_started,
            max_rss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        temporary = destination/'complete.tmp'
        temporary.write_text(json.dumps(row,indent=2)+'\n')
        temporary.replace(destination/'complete.json')
        report['tracks'].append(row)
        progress('track-complete', identifier)
        print(json.dumps(dict(track_complete=identifier,completed_tracks=len(report['tracks']),inference_seconds=inference_seconds)),flush=True)
        del sources, wav, pcm, ref, tensor, block
    assert continuation.validate_preserved(plan) == preserved
    assert [r['salami_id'] for r in report['tracks']] == [c['salami_id'] for c in plan['cases']]
    for asset in plan['assets']:
        assert sha(Path(asset['path'])) == asset['sha256']
    report.update(passed=True,assets_unchanged=True,complete_tracks=8,
                  output_total_bytes=sum(o['bytes'] for t in report['tracks'] for o in t['outputs']),
                  input_clock_unchanged=True,no_case_replacement=True,no_label_or_time_fitting=True)
    progress('corpus-complete')
except BaseException as error:
    report['errors'].append(type(error).__name__+': '+str(error))
    (ROOT/'corpus-error.log').write_text(traceback.format_exc())
report['seconds'] = time.monotonic()-started
(ROOT/'corpus-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='tracks'}),flush=True)
raise SystemExit(0 if report['passed'] else 1)
