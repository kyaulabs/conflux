"""Bound the CPU-only feature step after the exact publisher corpus is closed."""
from pathlib import Path
import hashlib
import json
import shutil
import signal
import subprocess
import sys

ROOT = Path('/srv/conflux-tests/work/structure-analysis-20261031-01/publisher-features-continuation-01')
NAME = 'conflux-publisher-features-continuation-20261031-01'
IMAGE = 'sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
DOCKER = ['sudo', '-n', 'env', 'DOCKER_CONFIG=/srv/conflux-tests/docker-client',
          'docker', '--host', 'unix:///srv/conflux-tests/daemon/docker.sock']


def verify(rows, *, local=False):
    for row in rows:
        path = ROOT / row['file'] if local else Path(row['path'])
        assert path.is_file() and not path.is_symlink() and path.stat().st_size == row['bytes']
        with path.open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256']


def interrupted(number, frame):
    raise InterruptedError('Owned feature extraction signal ' + str(number))


if sys.argv[1:] != ['--run']:
    if sys.argv[1:]:
        raise SystemExit('Only --run starts this owner')
    verify(json.loads((ROOT/'staging-manifest.json').read_text()), local=True)
    print(json.dumps(dict(verified=True, unarmed=True, neural_forward_passes=0, GPU_started=False)))
    raise SystemExit(0)
# Actual input binding is assembled only after the complete source owner closes.
# Missing binding stops before output, service, Docker or data-processing actions.
handoff = json.loads((ROOT/'binding.json').read_text())
assert handoff['schema'] == 1 and handoff['fixed_denominator'] == 8
assert handoff['source_corpus_complete_and_closed'] is True
verify(handoff['input_pins'])

report = dict(passed=False, exit=None, container_absent=False, inputs_unchanged=False,
              corpus_owner_closed=False, GPU_used=False, audio_output=False,
              neural_forward_passes=0, physical_readiness_consumed=False, errors=[])
child = None
local_rows = None
plan = None
for number in (signal.SIGTERM, signal.SIGINT):
    signal.signal(number, interrupted)
try:
    local_rows = json.loads((ROOT / 'staging-manifest.json').read_text())
    verify(local_rows, local=True)
    plan = json.loads((ROOT / 'plan.json').read_text())
    verify(plan['external_assets'])
    former = subprocess.run(['systemctl', 'show', plan['corpus_unit'],
        '--property=LoadState,ActiveState,MainPID,ControlGroup,InvocationID'],
        capture_output=True, text=True, timeout=5)
    state = dict(line.split('=', 1) for line in former.stdout.splitlines() if '=' in line)
    assert former.returncode in (0, 1) and state.get('MainPID') == '0'
    assert state.get('ControlGroup') == '' and state.get('ActiveState') in ('inactive', 'failed')
    assert state.get('InvocationID') in ('', plan['corpus_invocation'])
    corpus = Path(plan['corpus_root'])
    previous = json.loads((corpus / 'owner-result.json').read_text())
    assert previous['passed'] is True and previous['container_absent'] is True
    assert previous['completed_tracks'] == 8
    report['corpus_owner_closed'] = True
    report['former_corpus_unit'] = state
    assert json.loads(subprocess.check_output(DOCKER + ['info', '--format', '{{json .DockerRootDir}}'], timeout=5)) == '/srv/conflux-tests/docker-data'
    assert not subprocess.check_output(DOCKER + ['ps', '-aq'], text=True, timeout=5).strip()
    assert shutil.disk_usage(ROOT).free >= 1024**3
    with (ROOT / 'run-reservation.json').open('x') as stream:
        json.dump(dict(operator_seconds=600, CPU_feature_extraction_only=True,
                       neural_forward_passes=0, no_automatic_retry=True), stream)
    runtime = Path(plan['runtime_assets'])
    command = DOCKER + ['run', '--rm', '--name', NAME, '--init', '--runtime=runc',
        '--label', 'org.kyaulabs.conflux.run=' + NAME,
        '--network=none', '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges:true',
        '--user=1000:1000', '--cpus=1', '--memory=2g', '--pids-limit=128',
        '--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777',
        '--env', 'CUDA_VISIBLE_DEVICES=', '--env', 'PYTHONDONTWRITEBYTECODE=1',
        '--env', 'OMP_NUM_THREADS=1', '--env', 'MKL_NUM_THREADS=1', '--env', 'OPENBLAS_NUM_THREADS=1',
        '--env', 'OMP_WAIT_POLICY=PASSIVE', '--env', 'GOMP_SPINCOUNT=0',
        '--env', 'HOME=' + str(ROOT), '--env', 'XDG_CACHE_HOME=' + str(ROOT / 'cache'),
        '--mount', 'type=bind,src=' + str(ROOT) + ',dst=' + str(ROOT),
        '--mount', 'type=bind,src=' + str(corpus) + ',dst=' + str(corpus) + ',readonly',
        '--mount', 'type=bind,src=' + plan['preserved_corpus_root'] + ',dst=' + plan['preserved_corpus_root'] + ',readonly',
        '--mount', 'type=bind,src=' + str(runtime / 'venv') + ',dst=' + plan['source_venv'] + ',readonly',
        '--mount', 'type=bind,src=' + str(runtime / 'base') + ',dst=' + plan['source_base_python'] + ',readonly',
        '--mount', 'type=bind,src=' + plan['addons'] + ',dst=' + plan['addons'] + ',readonly',
        '--mount', 'type=bind,src=' + plan['progress'] + ',dst=' + plan['progress'] + ',readonly',
        IMAGE, 'timeout', '--signal=TERM', '--kill-after=10s', '540',
        plan['source_venv'] + '/bin/python', '-I', '-B', str(ROOT / 'extract_publisher_pcm16.py'),
        '--plan', str(ROOT / 'plan.json'), '--source', str(ROOT / 'spectrogram.py'),
        '--addons', plan['addons'], '--progress', plan['progress'], '--output', str(ROOT / 'output')]
    (ROOT / 'container-dispatch.json').write_text(json.dumps(dict(command=command), indent=2) + '\n')
    with (ROOT / 'container.stdout.log').open('x') as out, (ROOT / 'container.stderr.log').open('x') as err:
        child = subprocess.Popen(command, stdout=out, stderr=err)
        report['exit'] = child.wait(timeout=555)
except BaseException as error:
    report['errors'].append(type(error).__name__ + ': ' + str(error))
finally:
    for number in (signal.SIGTERM, signal.SIGINT):
        signal.signal(number, signal.SIG_IGN)
    try:
        found = subprocess.run(DOCKER + ['inspect', NAME], capture_output=True, text=True, timeout=5)
        if found.returncode == 0:
            value = json.loads(found.stdout)[0]
            assert value['Image'] == IMAGE and value['Config']['Labels'].get('org.kyaulabs.conflux.run') == NAME
            subprocess.run(DOCKER + ['rm', '--force', value['Id']], check=True, capture_output=True, timeout=10)
        assert not subprocess.check_output(DOCKER + ['ps', '-aq', '--filter', 'name=^/' + NAME + '$'], text=True, timeout=5).strip()
        if child is not None:
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=3)
        report['container_absent'] = True
        if local_rows is not None and plan is not None:
            verify(local_rows, local=True)
            verify(plan['external_assets'])
            report['inputs_unchanged'] = True
    except BaseException as error:
        report['errors'].append('cleanup: ' + str(error))
    result = ROOT / 'output/result.json'
    if result.is_file():
        try:
            report['result'] = json.loads(result.read_text())
        except ValueError as error:
            report['errors'].append('result: ' + str(error))
    report['passed'] = (report['exit'] == 0 and report['container_absent'] and report['inputs_unchanged']
                        and report['corpus_owner_closed'] and not report['errors']
                        and report.get('result', {}).get('passed') is True)
    with (ROOT / 'owner-result.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
print(json.dumps({key: value for key, value in report.items() if key != 'result'}))
raise SystemExit(0 if report['passed'] else 1)
