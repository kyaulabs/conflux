"""Own the controlled original/native CONFLUX CPU comparison container."""
from pathlib import Path
import hashlib
import json
import signal
import subprocess
import sys

ROOT = Path('/srv/conflux-tests/work/structure-analysis-20261031-01/publisher-corpus-continuation-01')
NAME = 'conflux-publisher-corpus-continuation-20261031-01'
IMAGE = 'sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
DOCKER = ['sudo', '-n', 'env', 'DOCKER_CONFIG=/srv/conflux-tests/docker-client',
          'docker', '--host', 'unix:///srv/conflux-tests/daemon/docker.sock']


def verify():
    for row in json.loads((ROOT / 'staging-manifest.json').read_text()):
        path = ROOT / row['file']
        assert path.is_file() and not path.is_symlink() and path.stat().st_size == row['bytes']
        with path.open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256']


verify()
if sys.argv[1:] != ['--run']:
    if sys.argv[1:]:
        raise SystemExit('Only --run starts this new owner')
    print(json.dumps(dict(verified=True, unarmed=True, model_started=False)))
    raise SystemExit(0)
plan = json.loads((ROOT/'plan.json').read_text())
original = subprocess.check_output(['systemctl', 'show', plan['predecessor_unit'],
    '--property=LoadState,ActiveState,MainPID,ControlGroup,InvocationID'], text=True, timeout=5)
state = dict(line.split('=',1) for line in original.splitlines() if '=' in line)
assert state['MainPID'] == '0' and state['ControlGroup'] == ''
assert state['ActiveState'] in ('inactive','failed') and state['InvocationID'] in ('',plan['predecessor_invocation'])
assert json.loads((ROOT/'approved-interruption.json').read_text())['closed'] is True
assert json.loads(subprocess.check_output(DOCKER + ['info', '--format', '{{json .DockerRootDir}}'], timeout=5)) == '/srv/conflux-tests/docker-data'
assert not subprocess.check_output(DOCKER + ['ps', '-aq'], text=True, timeout=5).strip()
with (ROOT / 'run-reservation.json').open('x') as stream:
    json.dump(dict(operator_seconds=9000, CPU_reference_generation_only=True, model_started=None, no_automatic_retry=True), stream)
plan = json.loads((ROOT / 'plan.json').read_text())
base_python = Path(plan['base_python'])
base_root = base_python.parent.parent
command = DOCKER + ['run', '--rm', '--name', NAME, '--init', '--runtime=runc',
    '--label', 'org.kyaulabs.conflux.run=' + NAME,
    '--network=none', '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges:true',
    '--user=1000:1000', '--cpus=1', '--memory=4g', '--pids-limit=128',
    '--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777',
    '--env', 'CUDA_VISIBLE_DEVICES=', '--env', 'PYTHONDONTWRITEBYTECODE=1',
    '--env', 'OMP_NUM_THREADS=1', '--env', 'MKL_NUM_THREADS=1', '--env', 'OPENBLAS_NUM_THREADS=1',
    '--env', 'OMP_WAIT_POLICY=PASSIVE', '--env', 'GOMP_SPINCOUNT=0',
    '--env', 'HOME=' + str(ROOT), '--env', 'XDG_CACHE_HOME=' + str(ROOT / 'cache'),
    '--mount', 'type=bind,src=' + str(ROOT) + ',dst=' + str(ROOT),
    '--mount', 'type=bind,src=' + plan['predecessor_root'] + ',dst=' + plan['predecessor_root'] + ',readonly',
    '--mount', 'type=bind,src=' + str(base_root) + ',dst=' + str(base_root) + ',readonly',
    '--mount', 'type=bind,src=' + str(Path(plan['venv']).parent) + ',dst=' + str(Path(plan['venv']).parent) + ',readonly',
    '--mount', 'type=bind,src=' + str(Path(plan['checkpoint']).parent) + ',dst=' + str(Path(plan['checkpoint']).parent) + ',readonly',
    '--mount', 'type=bind,src=/srv/conflux-tests/work/structure-analysis-20261031-01/publisher-decoder-parity-01,dst=/srv/conflux-tests/work/structure-analysis-20261031-01/publisher-decoder-parity-01,readonly',
    IMAGE, 'timeout', '--signal=TERM', '--kill-after=12s', '8800',
    str(Path(plan['venv']) / 'bin/python'), '-I', '-B', str(ROOT / 'generate_publisher_corpus.py')]
report = dict(passed=False, exit=None, container_absent=False, inputs_unchanged=False,
              CPU_reference_generation_only=True, GPU_used=False, model_started=None,
              physical_readiness_consumed=False, errors=[])
child = None


def interrupted(number, frame):
    raise InterruptedError('Owned reference setup signal ' + str(number))


for number in (signal.SIGTERM, signal.SIGINT):
    signal.signal(number, interrupted)
try:
    (ROOT / 'container-dispatch.json').write_text(json.dumps(dict(command=command), indent=2) + '\n')
    with (ROOT / 'container.stdout.log').open('x') as out, (ROOT / 'container.stderr.log').open('x') as err:
        child = subprocess.Popen(command, stdout=out, stderr=err)
        report['exit'] = child.wait(timeout=8850)
except BaseException as error:
    report['errors'].append(type(error).__name__ + ': ' + str(error))
finally:
    for number in (signal.SIGTERM, signal.SIGINT):
        signal.signal(number, signal.SIG_IGN)
    try:
        found = subprocess.run(DOCKER + ['inspect', NAME], capture_output=True, text=True, timeout=5)
        if found.returncode == 0:
            value = json.loads(found.stdout)[0]
            assert value['Image'] == IMAGE and value['Config']['Labels'].get('org.kyaulabs.conflux.run') == NAME
            subprocess.run(DOCKER + ['rm', '--force', value['Id']], check=True, capture_output=True, timeout=10)
        assert not subprocess.check_output(DOCKER + ['ps', '-aq', '--filter', 'name=^/' + NAME + '$'], text=True, timeout=5).strip()
        if child is not None:
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=3)
        report['container_absent'] = True
        verify()
        report['inputs_unchanged'] = True
    except BaseException as error:
        report['errors'].append('cleanup: ' + str(error))
    result = ROOT / 'corpus-result.json'
    if result.is_file():
        try:
            report['result'] = json.loads(result.read_text())
            report['model_started'] = report['result'].get('model_started')
            report['completed_tracks'] = len(report['result'].get('tracks', []))
        except ValueError as error:
            report['errors'].append('result: ' + str(error))
    report['passed'] = (report['exit'] == 0 and report['container_absent'] and report['inputs_unchanged']
                        and not report['errors'] and report.get('result', {}).get('passed') is True)
    with (ROOT / 'owner-result.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
print(json.dumps({key: value for key, value in report.items() if key != 'result'}))
raise SystemExit(0 if report['passed'] else 1)
