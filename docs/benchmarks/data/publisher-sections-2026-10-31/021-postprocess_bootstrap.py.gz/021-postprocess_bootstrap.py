"""Load pinned publisher decoders with the existing Librosa clock functions."""
from pathlib import Path
from types import ModuleType
import ast
import hashlib
import importlib
import sys


def clock_view(convert_path, sha256):
    import numpy as np
    path = Path(convert_path)
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != sha256:
        raise ValueError('Librosa unit-conversion source differs')
    original = ast.parse(raw, filename=str(path))
    chosen = []
    for name in ['frames_to_samples', 'samples_to_time', 'frames_to_time']:
        matches = [n for n in original.body if isinstance(n, ast.FunctionDef) and
                   n.name == name and not n.decorator_list]
        if len(matches) != 1:
            raise ValueError('Unexpected original conversion-function definition')
        chosen.append(matches[0])
    future = ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)
    tree = ast.fix_missing_locations(ast.Module(body=[future] + chosen, type_ignores=[]))
    namespace = dict(np=np)
    exec(compile(tree, str(path), 'exec'), namespace)
    module = ModuleType('librosa')
    module.frames_to_time = namespace['frames_to_time']
    module.frames_to_samples = namespace['frames_to_samples']
    module.samples_to_time = namespace['samples_to_time']
    return module


def load_postprocessors(source, clock):
    from model_bootstrap import ConfigView
    package = Path(source) / 'src/allin1'
    config_raw = (package / 'config.py').read_bytes()
    if hashlib.sha256(config_raw).hexdigest() != 'caebb47c20cda6ca43df22f4a74481982620e3aeeb869f682cae51e7addb37e2':
        raise ValueError('Publisher configuration source differs')
    config_ast = ast.parse(config_raw)
    labels = [n for n in config_ast.body if isinstance(n, ast.Assign) and
              any(isinstance(t, ast.Name) and t.id == 'HARMONIX_LABELS' for t in n.targets)]
    if len(labels) != 1:
        raise ValueError('Publisher label dictionary differs')
    names = ast.literal_eval(labels[0].value)
    if type(names) is not list or len(names) != 10 or any(type(n) is not str for n in names):
        raise ValueError('Publisher label geometry differs')
    if 'allin1' not in sys.modules:
        top = ModuleType('allin1')
        top.__path__ = [str(package)]
        sys.modules['allin1'] = top
    if 'allin1.config' not in sys.modules:
        config = ModuleType('allin1.config')
        config.Config = ConfigView
        sys.modules['allin1.config'] = config
    sys.modules['allin1.config'].HARMONIX_LABELS = names
    if 'librosa' in sys.modules or 'allin1.postprocessing' in sys.modules:
        raise ValueError('Postprocessor scope already initialized')
    sys.modules['librosa'] = clock
    post = ModuleType('allin1.postprocessing')
    post.__path__ = [str(package / 'postprocessing')]
    sys.modules['allin1.postprocessing'] = post
    functional = importlib.import_module('allin1.postprocessing.functional')
    metrical = importlib.import_module('allin1.postprocessing.metrical')
    return functional.postprocess_functional_structure, metrical.postprocess_metrical_structure
