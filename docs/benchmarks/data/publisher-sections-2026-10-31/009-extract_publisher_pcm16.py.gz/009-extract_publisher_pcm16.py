"""Extract the fixed publisher reference through its original PCM16 file path."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import resource
import stat
import sys
import time
import wave

IDS = [1342, 1268, 1100, 1278, 990, 1394, 1036, 1290]
ROLES = ['bass', 'drums', 'other', 'vocals']
SOURCE_SHA = '14fb203a73e44e2b0a585e5b829b4e2964e5839ea8dd4bd9e4a5fea2c5a23cf9'


def checked_file(path, *, size=None, maximum=None, digest=None):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode):
            raise ValueError('Input is not a regular file: ' + str(path))
        if size is not None and before.st_size != size:
            raise ValueError('Input byte count changed: ' + str(path))
        if maximum is not None and before.st_size > maximum:
            raise ValueError('Input byte budget exceeded: ' + str(path))
        actual = hashlib.file_digest(stream, 'sha256').hexdigest()
        if digest is not None and actual != digest:
            raise ValueError('Input hash changed: ' + str(path))
        after = os.fstat(stream.fileno())
        identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        if identity(before) != identity(after):
            raise ValueError('Input changed while reading: ' + str(path))
    return dict(file=str(path), bytes=before.st_size, sha256=actual)


def read_json(path):
    pin = checked_file(path, maximum=1024 * 1024)
    value = json.loads(path.read_text())
    if checked_file(path) != pin:
        raise ValueError('JSON changed while reading: ' + str(path))
    return value, pin


def validate_corpus(plan):
    """Require the closed composite run and validate all six preserved/two new receipts."""
    root = Path(plan['corpus_root'])
    if not root.is_absolute() or root.is_symlink():
        raise ValueError('Invalid corpus root')
    if [r['salami_id'] for r in plan['cases']] != IDS or plan['role_order'] != ROLES:
        raise ValueError('Fixed corpus denominator or role order changed')
    preserved_root = Path(plan['preserved_corpus_root'])
    if not preserved_root.is_absolute() or preserved_root.is_symlink() or preserved_root == root:
        raise ValueError('Invalid preserved corpus root')
    original_owner, original_owner_pin = read_json(preserved_root / 'owner-result.json')
    if (original_owner.get('passed') is not False or original_owner.get('container_absent') is not True
            or original_owner.get('inputs_unchanged') is not True):
        raise ValueError('Original interrupted owner is not closed and preserved')
    owner, owner_pin = read_json(root / 'owner-result.json')
    result, result_pin = read_json(root / 'corpus-result.json')
    if (owner.get('passed') is not True or owner.get('exit') != 0
            or owner.get('container_absent') is not True
            or owner.get('inputs_unchanged') is not True
            or owner.get('completed_tracks') != 8
            or owner.get('result') != result or result.get('passed') is not True
            or [r['salami_id'] for r in result.get('tracks', [])] != IDS
            or result.get('original_attempt_retained_as_interrupted') is not True
            or result.get('preserved_tracks') != 6 or result.get('newly_requested_tracks') != 2
            or result.get('preserved_root') != str(preserved_root)):
        raise ValueError('Full publisher corpus has not completed successfully')
    pins = [original_owner_pin, owner_pin, result_pin]
    rows = []
    for expected, completed in zip(plan['cases'], result['tracks'], strict=True):
        case_id = expected['salami_id']
        case_root = preserved_root if case_id in IDS[:6] else root
        folder = case_root / 'cases' / str(case_id)
        if expected['complete_receipt'] != str(folder / 'complete.json'):
            raise ValueError('Fixed six/two source partition changed')
        if folder.is_symlink():
            raise ValueError('Symlinked corpus case')
        receipt, receipt_pin = read_json(folder / 'complete.json')
        if (receipt != completed or receipt['salami_id'] != case_id
                or receipt['frames'] != expected['frames_44100']
                or receipt['input_sha256'] != expected['input_sha256']
                or receipt['seed'] != expected['seed']
                or receipt['source_pcm_unchanged'] is not True
                or receipt['settings'] != plan['publisher_settings']):
            raise ValueError('Complete receipt does not match the fixed input')
        outputs = receipt['outputs']
        if len(outputs) != 4 or {r['role'] for r in outputs} != set(ROLES):
            raise ValueError('Incomplete or duplicate stem roles')
        pins.append(receipt_pin)
        for role in ROLES:
            row = next(r for r in outputs if r['role'] == role)
            path = folder / (role + '.wav')
            n = expected['frames_44100']
            if (row['file'] != str(path) or row['frames'] != n
                    or row['sample_rate'] != 44100 or row['channels'] != 2 or row['bits'] != 16):
                raise ValueError('Unexpected stem path or format')
            pin = checked_file(path, size=row['bytes'], maximum=4 * n + 4096, digest=row['sha256'])
            with wave.open(str(path), 'rb') as stream:
                if (stream.getnchannels(), stream.getsampwidth(), stream.getframerate(),
                        stream.getnframes(), stream.getcomptype()) != (2, 2, 44100, n, 'NONE'):
                    raise ValueError('Stem WAV header differs from its receipt')
            pins.append(pin)
        rows.append(dict(salami_id=case_id, folder=str(folder), expected=expected,
                         complete_receipt=receipt_pin))
    return rows, pins


def main():
    parser = argparse.ArgumentParser()
    for name in ['plan', 'source', 'addons', 'progress', 'output']:
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(mode=0o700, exist_ok=False)
    started = time.monotonic()
    result = dict(schema=1, passed=False, fixed_tracks=8, cases=[], error=None,
                  neural_forward_passes=0, GPU_used=False, audio_output=False,
                  production_changed=False, musical_accuracy_qualified=False,
                  latency_qualified=False, source_time_shift_seconds=0)
    try:
        plan, plan_pin = read_json(args.plan)
        rows, pins = validate_corpus(plan)
        source_pin = checked_file(args.source, digest=SOURCE_SHA)
        if os.environ.get('CUDA_VISIBLE_DEVICES') != '' or any(
                Path(p).exists() for p in ['/dev/dri', '/dev/nvidia0', '/dev/snd']):
            raise ValueError('This extraction requires the isolated CPU-only container')
        sys.path[:0] = [str(args.addons), str(args.progress)]
        import numpy as np
        import scipy
        import madmom
        import tqdm
        if (np.__version__, scipy.__version__, madmom.__version__, tqdm.__version__) != (
                '2.5.4', '1.18.1', '0.17.dev0', '4.70.1'):
            raise ValueError('Feature dependency versions changed')
        if {p.name for p in Path(madmom.models.__file__).parent.iterdir()} != {
                '__init__.py', 'LICENSE', 'README.rst'}:
            raise ValueError('Unexpected madmom model data')
        spec = importlib.util.spec_from_file_location('pinned_publisher_spectrogram', args.source)
        upstream = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(upstream)
        destination = args.output / 'features'
        destination.mkdir(mode=0o700)
        result.update(plan=plan_pin, source=source_pin, input_pins=pins,
                      role_order=ROLES, frame_centers='i/100 seconds',
                      implementation='Unmodified publisher extract_spectrograms; PCM16 Signal; multiprocess=False')
        for row in rows:
            if time.monotonic() - started > 480:
                raise TimeoutError('Original feature extraction budget expired')
            case_id = row['salami_id']
            progress = dict(salami_id=case_id, completed_cases=len(result['cases']),
                            seconds=time.monotonic() - started)
            temp = args.output / 'progress.tmp'
            temp.write_text(json.dumps(progress, indent=2) + '\n')
            temp.replace(args.output / 'progress.json')
            produced = upstream.extract_spectrograms([Path(row['folder'])], destination, multiprocess=False)
            path = destination / (str(case_id) + '.npy')
            if produced != [path]:
                raise ValueError('Publisher returned an unexpected feature path')
            checked_file(path, maximum=64 * 1024**2)
            array = np.load(path, allow_pickle=False, mmap_mode='r')
            expected = row['expected']
            if (list(array.shape) != expected['expected_feature_shape']
                    or array.dtype != np.float32 or not np.isfinite(array).all()):
                raise ValueError('Invalid publisher feature output')
            eligible = sum(i * 48000 < expected['source_frames_48k'] * 100
                           for i in range(array.shape[1]))
            result['cases'].append(dict(salami_id=case_id, feature=checked_file(path),
                shape=list(array.shape), dtype=str(array.dtype), source_frames_48k=expected['source_frames_48k'],
                role_order=ROLES, eligible_centers=eligible, complete_receipt=row['complete_receipt']))
            del array
        _, after = validate_corpus(plan)
        if after != pins or checked_file(args.source) != source_pin or checked_file(args.plan) != plan_pin:
            raise ValueError('Inputs changed during extraction')
        if 'torch' in sys.modules:
            raise ValueError('Unexpected neural runtime import')
        result.update(passed=True, inputs_unchanged=True, dependencies=dict(
            numpy=np.__version__, scipy=scipy.__version__, madmom=madmom.__version__, tqdm=tqdm.__version__))
    except BaseException as exc:
        result['error'] = type(exc).__name__ + ': ' + str(exc)
    result.update(seconds=time.monotonic() - started,
                  peak_rss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    with (args.output / 'result.json').open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ['cases', 'input_pins']}, allow_nan=False))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
