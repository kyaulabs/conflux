"""Own one CPU-only Apollo structure assessment, with no player or host changes."""
from pathlib import Path
import argparse
import hashlib
import json
import signal
import subprocess

BASE = Path('/srv/conflux-tests/work/structure-analysis-20261031-01/publisher-structure-continuation-01')
NAME = 'conflux-publisher-structure-continuation-cpu-20261031-01'
FEATURE_ROOT = Path('/srv/conflux-tests/work/structure-analysis-20261031-01/publisher-features-continuation-01')
FEATURE_UNIT = 'conflux-publisher-features-continuation-20261031-01.service'
IDS = [1342, 1268, 1100, 1278, 990, 1394, 1036, 1290]
DOCKER = ['sudo', '-n', 'env', 'DOCKER_CONFIG=/srv/conflux-tests/docker-client', 'docker',
          '--host', 'unix:///srv/conflux-tests/daemon/docker.sock']


def digest(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def validate_feature_handoff(plan, expected, owner, extracted):
    assert plan['ready_to_run'] is True and plan['execution_allowed'] is True
    assert [r['salami_id'] for r in plan['features']] == IDS
    assert [r['salami_id'] for r in expected['expected_features']] == IDS
    assert owner['passed'] is True and owner['exit'] == 0 and owner['errors'] == []
    assert owner['container_absent'] is True and owner['inputs_unchanged'] is True
    assert owner['corpus_owner_closed'] is True and owner['result'] == extracted
    assert extracted['passed'] is True and extracted['fixed_tracks'] == 8
    assert extracted['inputs_unchanged'] is True
    assert extracted['plan']['sha256'] == expected['source_feature_plan_sha256']
    assert extracted['source']['sha256'] == '14fb203a73e44e2b0a585e5b829b4e2964e5839ea8dd4bd9e4a5fea2c5a23cf9'
    assert extracted['frame_centers'] == 'i/100 seconds'
    assert extracted['implementation'] == 'Unmodified publisher extract_spectrograms; PCM16 Signal; multiprocess=False'
    assert [r['salami_id'] for r in extracted['cases']] == IDS
    for row, shape, produced in zip(plan['features'], expected['expected_features'], extracted['cases'], strict=True):
        assert row['shape'] == shape['shape'] == produced['shape']
        assert row['role_order'] == shape['role_order'] == produced['role_order'] == ['bass', 'drums', 'other', 'vocals']
        assert row['source_frames_48k'] == shape['source_frames_48k'] == produced['source_frames_48k']
        assert row['input_frames_44100'] == shape['input_frames_44100']
        path = FEATURE_ROOT / 'output/features' / (str(row['salami_id']) + '.npy')
        assert row['remote'] == produced['feature']['file'] == str(path)
        assert row['feature_bytes'] == produced['feature']['bytes']
        assert row['feature_sha256'] == produced['feature']['sha256']
        assert produced['dtype'] == 'float32' and produced['eligible_centers'] == row['shape'][1]


def verify():
    binding = json.loads((BASE / 'binding.json').read_text())
    plan = json.loads((BASE / 'plan.json').read_text())
    assert plan == binding['plan'] and len(plan['features']) == plan['denominator'] == 8
    assert plan['ready_to_run'] is True and plan['execution_allowed'] is True
    assert plan['GPU_used'] is False and plan['production_enabled'] is False
    for row in binding['packet_files']:
        path = BASE / row['file']
        assert path.is_relative_to(BASE) and path.stat().st_size == row['bytes'] and digest(path) == row['sha256']
    for group in binding['existing_pin_groups']:
        root = Path(group['base'])
        for row in group['files']:
            path = root / row['file']
            assert path.is_relative_to(root) and path.stat().st_size == row['bytes'] and digest(path) == row['sha256']
    for row in plan['features']:
        path = Path(row['remote'])
        assert path.stat().st_size == row['feature_bytes'] and digest(path) == row['feature_sha256']
    predecessor = binding['feature_predecessor']
    assert predecessor['unit'] == FEATURE_UNIT and predecessor['root'] == str(FEATURE_ROOT)
    assert {r['file'] for r in predecessor['files']} == {'owner-result.json', 'output/result.json'}
    assert len(predecessor['files']) == 2
    for row in predecessor['files']:
        path = FEATURE_ROOT / row['file']
        assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256']
    state = subprocess.run(['systemctl', 'show', FEATURE_UNIT,
        '--property=LoadState,ActiveState,MainPID,ControlGroup,InvocationID'],
        capture_output=True, text=True, timeout=5)
    properties = dict(line.split('=', 1) for line in state.stdout.splitlines() if '=' in line)
    assert state.returncode in (0, 1) and properties.get('MainPID') == '0'
    assert properties.get('ControlGroup') == '' and properties.get('ActiveState') in ('inactive', 'failed')
    assert properties.get('InvocationID') in ('', predecessor['invocation_id'])
    validate_feature_handoff(plan, json.loads((BASE / 'handoff-plan.json').read_text()),
        json.loads((FEATURE_ROOT / 'owner-result.json').read_text()),
        json.loads((FEATURE_ROOT / 'output/result.json').read_text()))
    assert json.loads(subprocess.check_output(DOCKER + ['info', '--format', '{{json .DockerRootDir}}'], timeout=5)) == '/srv/conflux-tests/docker-data'
    return binding


def remove_owned(image):
    found = subprocess.run(DOCKER + ['inspect', NAME], capture_output=True, text=True, timeout=5)
    if found.returncode == 0:
        item = json.loads(found.stdout)[0]
        assert item['Image'] == image and item['Config']['Labels'].get('org.kyaulabs.conflux.run') == NAME
        subprocess.run(DOCKER + ['rm', '--force', item['Id']], capture_output=True, check=True, timeout=10)
    assert not subprocess.check_output(DOCKER + ['ps', '-aq', '--filter', 'name=^/' + NAME + '$'], text=True, timeout=5).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    binding = verify()
    plan = binding['plan']
    if not args.run:
        print(json.dumps(dict(verified=True, unarmed=True, neural_inference_started=False,
                              cases=8, CPU_only=True, laptop_used=False)))
        return 0
    assert not subprocess.check_output(DOCKER + ['ps', '-aq'], text=True, timeout=5).strip()
    save(BASE / 'run-reservation.json', dict(ordinary_offline_assessment=True, no_automatic_retry=True,
                                           GPU_used=False, physical_readiness_consumed=False))
    output = BASE / 'output'
    output.mkdir(mode=0o700)
    assets = Path(binding['CPU_runtime'])
    command = DOCKER + ['run', '--rm', '--name', NAME, '--init', '--runtime=runc',
        '--label', 'org.kyaulabs.conflux.run=' + NAME,
        '--network=none', '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges:true',
        '--user=1000:1000', '--cpus=1', '--memory=4g', '--pids-limit=128',
        '--tmpfs=/tmp:rw,nosuid,nodev,size=128m,mode=1777']
    for key, value in {'CUDA_VISIBLE_DEVICES': '', 'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
                       'MKL_NUM_THREADS': '1', 'PYTHONDONTWRITEBYTECODE': '1',
                       'XDG_CACHE_HOME': '/results/cache'}.items():
        command += ['--env', key + '=' + value]
    for source, target, readonly in [(BASE, '/packet', True), (output, '/results', False),
        (Path(binding['graph']), '/graph', True), (Path(binding['natten']), '/natten', True),
        (Path(binding['addons']), '/addons', True),
        (Path(binding['input_dirs']['01']), '/inputs01', True),
        (Path(binding['input_dirs']['02']), '/inputs02', True),
        (assets / 'venv', binding['source_venv'], True),
        (assets / 'base', binding['source_base_python'], True)]:
        command += ['--mount', 'type=bind,src=' + str(source) + ',dst=' + str(target) + (',readonly' if readonly else '')]
    command += [plan['image'], 'timeout', '--signal=TERM', '--kill-after=15s', '3650',
        binding['source_venv'] + '/bin/python', '-I', '-B', '/packet/structure_music_owner.py',
        '--packet', '/packet', '--graph', '/graph', '--natten', '/natten', '--addons', '/addons',
        '--inputs01', '/inputs01', '--inputs02', '/inputs02', '--output', '/results/cases']
    report = dict(passed=False, exit=None, cleanup_complete=False, inputs_unchanged=False,
                  ordinary_offline_assessment=True, GPU_used=False, laptop_used=False,
                  latency_qualified=False, musical_accuracy_qualified=False, errors=[])
    child = None
    def interrupted(number, frame):
        raise InterruptedError('Owned CPU assessment signal ' + str(number))
    for number in (signal.SIGTERM, signal.SIGINT):
        signal.signal(number, interrupted)
    try:
        save(BASE / 'container-dispatch.json', dict(command=command))
        with (BASE / 'container.stdout.log').open('x') as out, (BASE / 'container.stderr.log').open('x') as err:
            child = subprocess.Popen(command, stdout=out, stderr=err)
            report['exit'] = child.wait(timeout=3680)
    except BaseException as error:
        report['errors'].append(type(error).__name__ + ': ' + str(error))
    finally:
        for number in (signal.SIGTERM, signal.SIGINT):
            signal.signal(number, signal.SIG_IGN)
        try:
            remove_owned(plan['image'])
            if child is not None:
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait(timeout=3)
            report['cleanup_complete'] = True
        except BaseException as error:
            report['errors'].append('cleanup: ' + str(error))
        try:
            verify()
            report['inputs_unchanged'] = True
        except BaseException as error:
            report['errors'].append('pins: ' + str(error))
        try:
            report['result'] = json.loads((output / 'cases/result.json').read_text())
        except (OSError, ValueError) as error:
            report['errors'].append('result: ' + str(error))
        report['passed'] = (report['exit'] == 0 and report['cleanup_complete'] and report['inputs_unchanged']
                            and not report['errors'] and report.get('result', {}).get('all_inference_cases_completed') is True)
        save(BASE / 'owner-result.json', report)
    print(json.dumps({key: value for key, value in report.items() if key != 'result'}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
