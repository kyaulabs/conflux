"""Bound the eight independent CPU inference cases; retain every failed case."""
from pathlib import Path
import argparse
import json
import os
import signal
import subprocess
import sys
import time

p = argparse.ArgumentParser()
for name in ['packet', 'graph', 'natten', 'addons', 'inputs01', 'inputs02', 'output']:
    p.add_argument('--' + name, type=Path, required=True)
a = p.parse_args()
plan = json.loads((a.packet / 'plan.json').read_text())
assert len(plan['features']) == plan['denominator'] == 8
assert not plan['GPU_used'] and not plan['production_enabled']
a.output.mkdir(mode=0o700, exist_ok=False)
started = time.monotonic()
deadline = started + 3550
cases = []
error = None


def exists(pid):
    try:
        os.killpg(pid, 0)
        return True
    except ProcessLookupError:
        return False


def cancelled(number, frame):
    raise InterruptedError('Owned CPU assessment signal ' + str(number))


for number in (signal.SIGTERM, signal.SIGINT):
    signal.signal(number, cancelled)
try:
    for row in plan['features']:
        case_id = row['salami_id']
        if deadline - time.monotonic() < 45:
            raise TimeoutError('Original eight-case assessment deadline expired')
        entry = dict(salami_id=case_id, completed=False, exit=None, child_group_gone=False)
        feature_root = a.inputs01 if row['input_bank'] == '01' else a.inputs02
        assert row['input_bank'] in ('01', '02')
        command = [sys.executable, '-I', '-B', str(a.packet / 'assess_music_structure.py'),
            '--packet', str(a.packet), '--graph', str(a.graph), '--natten', str(a.natten),
            '--addons', str(a.addons), '--features', str(feature_root),
            '--case', str(case_id), '--output', str(a.output / str(case_id))]
        child = None
        case_error = None
        try:
            with (a.output / (str(case_id) + '.stdout.log')).open('x') as out, (a.output / (str(case_id) + '.stderr.log')).open('x') as err:
                child = subprocess.Popen(command, stdout=out, stderr=err, start_new_session=True)
                entry['exit'] = child.wait(timeout=min(480, deadline - time.monotonic() - 25))
        except subprocess.TimeoutExpired:
            case_error = 'Original per-case CPU budget expired'
        finally:
            if child is not None:
                if exists(child.pid):
                    os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    if exists(child.pid):
                        os.killpg(child.pid, signal.SIGKILL)
                    child.wait(timeout=5)
                until = time.monotonic() + 3
                while exists(child.pid) and time.monotonic() < until:
                    time.sleep(.05)
                entry['child_group_gone'] = not exists(child.pid)
                assert entry['child_group_gone'], 'Case process group closure unproven'
        result = a.output / str(case_id) / 'result.json'
        if result.is_file():
            entry['result'] = json.loads(result.read_text())
            entry['completed'] = entry['exit'] == 0 and entry['result']['completed']
        entry['owner_error'] = case_error
        cases.append(entry)
        (a.output / 'progress.json').write_text(json.dumps(dict(completed_cases=len(cases),
            denominator=8, last_case=case_id, cases_with_results=sum(r['completed'] for r in cases),
            seconds=time.monotonic() - started), indent=2) + '\n')
except BaseException as exc:
    error = type(exc).__name__ + ': ' + str(exc)
result = dict(schema=1, completed=len(cases) == 8 and error is None,
              all_inference_cases_completed=len(cases) == 8 and all(r['completed'] for r in cases),
              denominator=8, cases=cases, error=error, seconds=time.monotonic() - started,
              GPU_used=False, audio_output=False, production_enabled=False,
              latency_qualified=False, musical_accuracy_qualified=False)
(a.output / 'result.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'cases'}))
raise SystemExit(0 if result['completed'] else 1)
