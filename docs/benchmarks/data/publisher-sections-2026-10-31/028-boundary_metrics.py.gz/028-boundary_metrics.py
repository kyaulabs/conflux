"""Unshifted boundary scoring for the fixed private SALAMI diagnostic."""
import math


def ordered(values):
    result = list(values)
    if any(type(v) not in (float, int) or not math.isfinite(v) or v < 0 for v in result):
        raise ValueError('Boundary times must be finite nonnegative numbers')
    if any(a >= b for a, b in zip(result, result[1:])):
        raise ValueError('Boundary events must be strictly increasing')
    return result


def reference_boundaries(text, source_duration):
    if type(text) is not str or len(text.encode()) > 65536 or not math.isfinite(source_duration) or source_duration <= 0:
        raise ValueError('Invalid reference extent')
    rows = []
    for line in text.splitlines():
        timestamp, label = line.split(None, 1)
        value = float(timestamp)
        if not math.isfinite(value) or value < 0 or value > source_duration + 1:
            raise ValueError('Annotation is not within the admitted source-clock extent')
        rows.append((value, label))
    if not rows or any(a[0] > b[0] for a, b in zip(rows, rows[1:])):
        raise ValueError('Reference events must be ordered')
    endpoints = [(t, label) for t, label in rows if t == 0 or t == source_duration or label.casefold() == 'end']
    internal = [(t, label) for t, label in rows if t != 0 and t != source_duration and label.casefold() != 'end']
    events = ordered(sorted({t for t, _ in internal}))
    return dict(times=events, semantic_endpoints_excluded=endpoints,
                duplicate_internal_times=len(internal) - len(events),
                events_beyond_decoded_EOF_retained=[(t, label) for t, label in internal if t > source_duration],
                offset_seconds=0, crop_or_stretch=False)


def predicted_boundaries(segments, source_duration, feature_frames):
    if not segments:
        return []
    if type(feature_frames) is not int or feature_frames <= 0:
        raise ValueError('Invalid feature extent')
    extent = feature_frames / 100
    for row in segments:
        if not isinstance(row, dict) or type(row.get('label')) is not str:
            raise ValueError('Invalid predicted section')
        start, end = row['start'], row['end']
        if any(type(v) not in (float, int) or not math.isfinite(v) for v in (start, end)) or not 0 <= start < end <= extent:
            raise ValueError('Invalid predicted interval')
    if segments[0]['start'] != 0 or segments[-1]['end'] != extent:
        raise ValueError('Predicted sections do not cover the original feature extent')
    if any(a['end'] != b['start'] for a, b in zip(segments, segments[1:])):
        raise ValueError('Predicted sections are not contiguous')
    events = ordered(row['start'] for row in segments[1:])
    if any(t >= source_duration for t in events):
        raise ValueError('Internal prediction is outside the decoded source')
    return events


def match_boundaries(reference, predicted, tolerance):
    reference, predicted = ordered(reference), ordered(predicted)
    if type(tolerance) not in (float, int) or not math.isfinite(tolerance) or tolerance <= 0:
        raise ValueError('Positive finite tolerance required')
    # Earliest feasible pair gives maximum cardinality on two ordered time sets.
    # Neither event can match more than once. This does not minimize timing error.
    i = j = 0
    pairs = []
    while i < len(reference) and j < len(predicted):
        if abs(reference[i] - predicted[j]) <= tolerance:
            pairs.append(dict(reference=reference[i], predicted=predicted[j],
                              signed_error=predicted[j] - reference[i]))
            i += 1
            j += 1
        elif reference[i] < predicted[j]:
            i += 1
        else:
            j += 1
    count = len(pairs)
    precision = count / len(predicted) if predicted else 0
    recall = count / len(reference) if reference else 0
    f1 = 2 * count / (len(reference) + len(predicted)) if reference or predicted else 0
    return dict(tolerance_seconds=tolerance, matches=count, reference_count=len(reference),
                predicted_count=len(predicted), precision=precision, recall=recall, F1=f1, pairs=pairs,
                offset_search=False, one_to_one=True)
