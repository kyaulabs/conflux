# Prepared stem-bank lookup

Add only this worker-thread operation to `PreparedTrackStore` (and `<optional>` to its header):

```cpp
std::optional<PreparedStemTrack> findPreparedStemBank(
    const QString& sourcePath, const StemEngine& engine,
    std::stop_token stop = {});
```

A value is a fully validated four-role stereo 48 kHz bank with `cacheHit=true`, the original source SHA and the unchanged five-asset pipeline key. It uses the existing bounded source descriptor capture/hash/revalidation, engine pin/verify, permitted bounded `--describe`, key recipe and `readStemEntry` validation. It returns read-only retained descriptors and recomputed overviews just like the existing warm path. The optional service path is not an argument or part of this identity.

Absence means only that the cache root or the exact keyed artifact is absent after validating the used source and engine inputs. A normal-only cache, another source's bank, or a bank for a different valid engine identity may therefore miss. A non-directory or symlink root is an error, not absence; only ENOENT means the root is missing. Revalidate captured source and used engine files before either successful hit or absence; a change during the operation is an error. This preserves the existing ordinary change-detection scope, not an adversarial immutable filesystem snapshot.

Present malformed, incomplete, non-finite, digest-mismatched or unsafe entries are errors, never misses. Use existing exception types and specific diagnostics; do not catch `invalid_argument` to remove/regenerate a present bank. Current tighter PCM, manifest, aggregate byte or entry limits also reject without altering the entry. Validate aggregate existing usage even for a keyed miss. An exact existing-entry byte/entry budget permits a hit: no input/native/conversion staging reserve is needed.

Never create a missing root, chmod an existing root, publish a stage/artifact, export, load a model, create a live job or invoke native inference to discover absence. An existing root may use the existing cancellable 2 s cooperative `.lock`; its temporary lock leaf is the sole permitted root write. The normal usage helper currently collects stale stages. Lookup must not collect or repair them: a surviving `.stage-*` is a specific busy/unsafe error mentioning staging and remains untouched. The test includes a recognized regular `audio.f32` leaf that ordinary cleanup would remove, rather than an unknown leaf that already fails validation. Invalid surviving live reservations likewise remain admission failures. No new accounting registry or eviction policy is needed.

The thin caller is explicit service-mode LOAD STEMS: hit uses the finite bank; only genuine absence may proceed to `prepareLiveStem`. That factory still verifies the final requested original SHA before installation. Lookup errors do not select live inference or original-mix playback. Existing offline `prepareStemBank` retains its current cold/repair behavior.

The independent test patch adds four behavior groups to the existing store QTest and reuses its actual stdlib export fixture, normal preparation and exact PCM/overview helpers. `--describe` may create the fixture's `.prefix`; `.calls` and `.started` identify forbidden full export. Cases cover root/key absence, same-content alias reuse, exact current storage budget, present bad entries and tightened limits, invalid used assets/source, cancellation and bounded busy lock. Unsafe FIFO checks retain the existing 5 s child guard. Source mutation during a concurrent read and pin mutation during a child are not newly forced here; same-FD verification is a source-review requirement, with existing store regressions retained.

This is an API/test freeze for root-owned actual RED. No lookup implementation, controller activation, model execution, build or test has been performed by the draft author. Existing target wiring suffices; no CMake change is required.
