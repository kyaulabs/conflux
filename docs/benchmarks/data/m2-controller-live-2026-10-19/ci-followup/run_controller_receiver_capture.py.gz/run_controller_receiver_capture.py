import hashlib,json,os,signal,subprocess,time
from pathlib import Path
b=Path('benchmarks-local/m2-live-delivery-2026-10-19')
source=Path('tools/experiments/manual_routing_check.cpp')
pin=lambda p:dict(bytes=Path(p).stat().st_size,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest())
initial=pin(source);rows=[];artifacts={}
env=os.environ|{'QT_QPA_PLATFORM':'offscreen','QT_QUICK_BACKEND':'software','QT_QUICK_CONTROLS_STYLE':'Basic'}
launcher="import runpy,signal,sys\ndef stop(*_):\n signal.signal(signal.SIGTERM,signal.SIG_IGN)\n raise InterruptedError('Receiver capture check timed out')\nsignal.signal(signal.SIGTERM,stop)\nsys.argv=sys.argv[1:]\nrunpy.run_path(sys.argv[0],run_name='__main__')\n"
commands=[
 ('normal-build',['cmake','--build','build/dev','--target','conflux-manual-routing-check','--parallel','2'],180),
 ('instrumented-build',['cmake','--build','build/coverage','--target','conflux-manual-routing-check','--parallel','2'],180),
 ('normal',['python3','-c',launcher,'tools/experiments/private_routing_check.py','build/dev/conflux-manual-routing-check',str(b/'controller-live-receiver-normal-01')],180),
 ('instrumented',['benchmarks-local/coverage-venv/bin/python','-c',launcher,'tools/experiments/private_routing_check.py','build/coverage/conflux-manual-routing-check',str(b/'controller-live-receiver-instrumented-01'),'--functional-only'],180)]
assert not (b/'controller-live-receiver-capture-result.json').exists()
for stage,cmd,limit in commands:
 assert pin(source)==initial
 start=time.monotonic();timed=False
 with (b/('controller-live-receiver-'+stage+'.log')).open('w') as log:
  c=subprocess.Popen(cmd,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=c.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(c.pid,signal.SIGTERM)
   try:code=c.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(c.pid,signal.SIGKILL);code=c.wait(timeout=5)
 row=dict(stage=stage,command=cmd,exit=code,timed_out=timed,elapsed_seconds=time.monotonic()-start)
 rows.append(row);(b/'controller-live-receiver-capture-result.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if code or timed:raise SystemExit(code or 1)
 if stage.endswith('-build'):
  folder='build/dev' if stage=='normal-build' else 'build/coverage';path=folder+'/conflux-manual-routing-check';artifacts[path]=pin(path)
assert pin(source)==initial
for p,v in artifacts.items():assert pin(p)==v
(b/'controller-live-receiver-capture-pins.json').write_text(json.dumps(dict(source={str(source):initial},binaries=artifacts,source_and_binaries_stable=True),indent=2)+'\n')
