"""Root-only media-free receiver follow-up archive. Dry unless --run is supplied."""
import argparse
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
DEST = ROOT / 'docs/benchmarks/data/m2-controller-live-2026-10-19/ci-followup'
INITIAL = BASE / 'controller-live-initial-push-artifacts/coverage-reports/private-routing'
SOURCE = 'tools/experiments/manual_routing_check.cpp'
HISTORICAL = '32f363ba1987d5493bd61f27b05d8ce64984f318'
PRODUCT_BASE = '5c3e4d0d7578516c9179b2ecbc34139db473ce30'
EXPECTED_FIX = 'fd7236e27710600fa601a17409974229e85a0249'
MAX_FILE = 32 * 1024 * 1024


def require(value, message):
    if not value:
        raise RuntimeError(message)


def meta(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read(path):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and 0 <= info.st_size <= MAX_FILE,
            'Nonregular/oversized text artifact: ' + str(path))
    data = path.read_bytes()
    require(len(data) == info.st_size and b'\0' not in data, 'Changed/binary text artifact: ' + str(path))
    data.decode('utf-8')
    return data


def load(path):
    return json.loads(read(path))


def command(argv, timeout=20):
    result = subprocess.run(argv, cwd=ROOT, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    require(result.returncode == 0, 'Command failed: ' + repr(argv) + '\n' + result.stderr.decode(errors='replace'))
    return result.stdout


def file_pin(path):
    info = path.stat()
    require(stat.S_ISREG(info.st_mode) and 0 < info.st_size <= 512 * 1024 * 1024,
            'Invalid pinned executable/source: ' + str(path))
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return {'bytes': info.st_size, 'sha256': digest.hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--head', default=EXPECTED_FIX)
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({'status': 'dry', 'destination': str(DEST), 'expected_signed_head': args.head,
                          'scope': 'Named text evidence only; no files/processes read or changed in dry mode'}))
        return 0
    require(args.head == EXPECTED_FIX, 'Use the exact receiver-only signed source commit')
    require(command(['git', 'rev-parse', 'HEAD']).decode().strip() == args.head, 'Current source HEAD differs')
    signature = command(['git', 'show', '-s', '--format=%H %G? %GF %ae', args.head]).decode().strip()
    require(signature.split()[0:2] == [args.head, 'G'] and signature.split()[-1] == 'kyau@kyau.net',
            'Receiver source commit is not a verified kyau signature')
    require(command(['git', 'diff', '--name-only', HISTORICAL, args.head]).decode().splitlines() == [SOURCE],
            'Receiver commit contains changes beyond the one helper')
    require(command(['git', 'diff', PRODUCT_BASE, '--', 'src', 'qml']) == b'', 'Product src/qml changed')
    require(command(['git', 'diff', args.head, '--', SOURCE, 'tools/experiments/private_routing_check.py']) == b'',
            'Helper/wrapper worktree differs from signed source')
    old_source = command(['git', 'show', HISTORICAL + ':' + SOURCE])
    fixed_source = read(ROOT / SOURCE)
    anchor = (b'            for (std::size_t frame = 0; frame < frames; ++frame) {\n'
              b'                // Constant-sample validation is armed only after startup\n')
    require(old_source.count(anchor) == 1, 'Ambiguous original sample loop')
    reconstructed = old_source.replace(anchor, anchor.replace(b'                //',
        b'                const float sample = samples[frame];\n                //', 1), 1)
    for old, new in [
        (b'if (samples[frame] == 0.F)', b'if (sample == 0.F)'),
        (b'if (samples[frame] != self.expected_[channel])', b'if (sample != self.expected_[channel])'),
        (b'std::bit_cast<std::uint32_t>(samples[frame]);', b'std::bit_cast<std::uint32_t>(sample);'),
    ]:
        require(reconstructed.count(old) == 1, 'Ambiguous original operand')
        reconstructed = reconstructed.replace(old, new, 1)
    require(reconstructed == fixed_source, 'Change is not exactly one capture reused at three sites')
    patch = BASE / 'controller-live-receiver-capture.patch'
    require(read(patch) == command(['git', 'diff', HISTORICAL, args.head, '--', SOURCE]), 'Retained patch differs')
    manual_blob = command(['git', 'rev-parse', args.head + ':' + SOURCE]).decode().strip()
    require(command(['git', 'hash-object', SOURCE]).decode().strip() == manual_blob, 'Manual helper blob differs')

    stages_path = BASE / 'controller-live-receiver-capture-result.json'
    stages = load(stages_path)
    require([row['stage'] for row in stages] == ['normal-build', 'instrumented-build', 'normal', 'instrumented'],
            'Four local stages are incomplete or unexpected')
    require(all(type(row['exit']) is int and row['exit'] == 0 and row['timed_out'] is False and
                isinstance(row['elapsed_seconds'], (int, float)) and not isinstance(row['elapsed_seconds'], bool) and
                math.isfinite(row['elapsed_seconds']) and row['elapsed_seconds'] >= 0 for row in stages),
            'A required local stage failed/timed out')
    require('--functional-only' not in stages[2]['command'] and '--functional-only' in stages[3]['command'],
            'Normal/instrumented mode changed')
    for row, tree in zip(stages[:2], ['dev', 'coverage']):
        require(row['command'] == ['cmake', '--build', 'build/' + tree, '--target',
                'conflux-manual-routing-check', '--parallel', '2'], 'Build target/command changed')
    for row, mode, tree, interpreter in [(stages[2], 'normal', 'dev', 'python3'),
            (stages[3], 'instrumented', 'coverage', 'benchmarks-local/coverage-venv/bin/python')]:
        tail = ['tools/experiments/private_routing_check.py', 'build/' + tree + '/conflux-manual-routing-check',
                'benchmarks-local/m2-live-delivery-2026-10-19/controller-live-receiver-' + mode + '-01']
        if mode == 'instrumented':
            tail.append('--functional-only')
        require(row['command'][:2] == [interpreter, '-c'] and row['command'][3:] == tail and
                "runpy.run_path(sys.argv[0],run_name='__main__')" in row['command'][2],
                'Private helper command/known cleanup launcher differs')
    pins_path = BASE / 'controller-live-receiver-capture-pins.json'
    pins = load(pins_path)
    require(pins['source_and_binaries_stable'] is True and set(pins['source']) == {SOURCE}, 'Missing fixed source pins')
    expected_binaries = {'build/dev/conflux-manual-routing-check', 'build/coverage/conflux-manual-routing-check'}
    require(set(pins['binaries']) == expected_binaries and meta(fixed_source) == pins['source'][SOURCE], 'Wrong pins')

    def verify_pins():
        for name, expected in (pins['source'] | pins['binaries']).items():
            require(file_pin(ROOT / name) == expected, 'Pinned bytes changed: ' + name)
    verify_pins()

    ci = {}
    for kind, run, event, outcome in [('push', 39260790364, 'push', 'failure'),
                                      ('pr', 39260827689, 'pull_request', 'success')]:
        value = load(BASE / ('controller-live-initial-' + kind + '-ci.json'))
        require(value['databaseId'] == run and value['headSha'] == HISTORICAL and value['event'] == event and
                value['status'] == 'completed' and value['conclusion'] == outcome, 'Historical CI identity/outcome differs')
        jobs = {job['name']: job for job in value['jobs']}
        require(set(jobs) == {'linux', 'coverage'} and jobs['linux']['conclusion'] == 'success' and
                jobs['coverage']['conclusion'] == outcome, 'Historical CI job outcome differs')
        ci[kind] = {key: value[key] for key in ['databaseId', 'headSha', 'event', 'status', 'conclusion', 'url']}

    failure = load(INITIAL / 'result.json')
    live = load(INITIAL / 'live-failure.json')
    receiver = load(INITIAL / 'source-handoff-receiver.json')
    recording = load(INITIAL / 'source-handoff-failed-recording.json')
    require(failure['passed'] is False and failure['check_exit'] == 1 and failure['execution_deadline_gate'] is False,
            'Historical functional failure classification differs')
    require(failure['daemon_reaped'] and not failure['cleanup']['remaining_nodes_or_links'], 'Historical cleanup incomplete')
    require(live['stage'] == 'source-handoff' and live['execution_deadline_gate'] is False and
            live['state']['callbacks'] == 23 and live['state']['execution_deadline_misses'] == 8 and
            live['state']['output_frame'] == 5888 and not live['state']['invalid_buffers'] and not live['state']['rejected'],
            'Historical callback observations differ')
    require(receiver['wrong_nonzero_samples'] == 1 and len(receiver['channels']) == 2, 'Historical receiver count differs')
    wrong = receiver['channels'][0]['first_wrong']
    require(wrong == {'expected_f32_bits': 1025507328, 'actual_f32_bits': 0,
                     'receiver_clock_position': 18527153, 'quantum': 256, 'sample_index': 16} and
            receiver['channels'][1]['first_wrong'] is None, 'Historical inconsistent operand differs')
    require(recording['passed'] is True and recording['error'] == '' and
            recording['accepted_frames'] == recording['written_frames'] == 5888 and recording['overflow_count'] == 0,
            'Historical independently checked recording differs')

    local = {}
    for mode, gate in [('normal', True), ('instrumented', False)]:
        directory = BASE / ('controller-live-receiver-' + mode + '-01')
        value = load(directory / 'result.json')
        require(value['passed'] and value['check_exit'] == 0 and value['check']['passed'] and
                not value['check'].get('error') and len(value['check']['checks']) > 0 and
                value['daemon_reaped'] and not value['cleanup']['remaining_nodes_or_links'], 'Local private graph failed: ' + mode)
        require(value['execution_deadline_gate'] is gate and value['check']['execution_deadline_gate'] is gate,
                'Local execution mode differs')
        handoff = load(directory / 'source-handoff.json')
        operands = load(directory / 'source-handoff-receiver.json')
        require(handoff['passed'] and handoff['execution_deadline_gate'] is gate and
                handoff['virtual_sink_zero_gate'] is gate and handoff['wrong_nonzero_sink_samples'] == 0 and
                handoff['output_frames'] > 0 and handoff['callbacks'] > 0 and
                operands['wrong_nonzero_samples'] == 0 and len(operands['channels']) == 2 and
                all(channel['first_wrong'] is None for channel in operands['channels']), 'Local coherent strict operand checks failed')
        if gate:
            require(handoff['execution_deadline_misses'] == 0 and handoff['zero_samples_after_signal'] == [0, 0],
                    'Normal strict callback/zero gate failed')
        local[mode] = {'checks': len(value['check']['checks']), 'wrapper_execution_deadline_gate': gate,
                       'handoff': handoff, 'receiver': operands, 'daemon_reaped': True, 'remaining_nodes_or_links': []}

    historical_verification = DEST.parent / 'verification.json'
    historical_pin = meta(read(historical_verification))
    raw = BASE / 'controller-live-receiver-capture-raw-scan'
    stage = DEST.with_name('.ci-followup.stage')
    require(not os.path.lexists(DEST) and not os.path.lexists(stage) and not os.path.lexists(raw), 'Fresh archive/raw directories required')
    stage.mkdir(mode=0o700)
    raw.mkdir(mode=0o700)
    files, uncompressed, origins = {}, {}, {}
    total = 0

    def add(path, name, compress=False):
        nonlocal total
        require('/' not in name and name not in files, 'Unsafe/duplicate archive name')
        data = read(path)
        total += len(data)
        require(total <= 64 * 1024 * 1024, 'Raw archive exceeds bounded text allowance')
        raw_name = name.removesuffix('.gz')
        require(not (raw / raw_name).exists(), 'Raw name collision')
        (raw / raw_name).write_bytes(data)
        origins[name] = {'path': str(path.relative_to(ROOT)), **meta(data)}
        if compress:
            uncompressed[name] = meta(data)
            data = gzip.compress(data, mtime=0)
        (stage / name).write_bytes(data)
        files[name] = meta(data)

    for name in ['controller-live-initial-push-ci.json', 'controller-live-initial-pr-ci.json',
                 'controller-live-receiver-capture-result.json', 'controller-live-receiver-capture-pins.json']:
        add(BASE / name, name)
    add(BASE / 'controller-live-initial-push-ci-failed.log', 'initial-push-ci-failed.log.gz', True)
    add(patch, 'capture.patch.gz', True)
    add(BASE / 'run_controller_receiver_capture.py', 'run_controller_receiver_capture.py.gz', True)
    add(Path(__file__).resolve(), 'archive_controller_receiver_capture.py.gz', True)
    for row in stages:
        add(BASE / ('controller-live-receiver-' + row['stage'] + '.log'), row['stage'] + '.log.gz', True)
    for name in ['result.json', 'live-failure.json', 'source-handoff-receiver.json',
                 'source-handoff-failed-recording.json', 'source-handoff.json']:
        add(INITIAL / name, 'initial-' + name)
    for name in ['failure-pw-dump.json', 'check.stdout.json', 'check.stderr.log', 'daemon.log']:
        add(INITIAL / name, 'initial-' + name + '.gz', True)
    for mode in ['normal', 'instrumented']:
        directory = BASE / ('controller-live-receiver-' + mode + '-01')
        for name in ['result.json', 'source-handoff.json', 'source-handoff-receiver.json']:
            add(directory / name, mode + '-' + name)
        for name in ['check.stdout.json', 'check.stderr.log', 'cleanup-pw-dump.json']:
            add(directory / name, mode + '-' + name + '.gz', True)

    scan_log = BASE / 'controller-live-receiver-capture-gitleaks.log'
    scan_report = BASE / 'controller-live-receiver-capture-gitleaks-findings.json'
    require(not os.path.lexists(scan_log) and not os.path.lexists(scan_report), 'Fresh secret-scan outputs required')
    scanned_input_bytes = total
    with scan_log.open('xb') as output:
        scanned = subprocess.run(['gitleaks', 'dir', str(raw), '--redact', '--no-color', '--report-format', 'json',
            '--report-path', str(scan_report)], cwd=ROOT, stdin=subprocess.DEVNULL,
            stdout=output, stderr=subprocess.STDOUT, timeout=90)
    require(scanned.returncode == 0, 'Raw secret scan failed; archive remains unpublished')
    require(load(scan_report) == [], 'Unexpected secret-scan findings')
    add(scan_log, 'raw-gitleaks.log.gz', True)
    add(scan_report, 'raw-redacted-gitleaks-findings.json')

    verification = {
        'schema': 'conflux.m2-controller-receiver-followup.v1',
        'status': 'coherent_receiver_capture_checks_passed_mutation_cause_unresolved',
        'source_head': args.head, 'source_signature': signature, 'manual_helper_git_blob': manual_blob,
        'product_baseline': PRODUCT_BASE, 'product_src_qml_unchanged': True,
        'helper_change_only': True, 'exact_one_capture_three_use_reconstruction': True,
        'oracles_tolerances_and_mode_gates_unchanged': True,
        'historical_controller_archive': {'path': '../verification.json', **historical_pin,
                                          'unchanged_historical_record': True},
        'initial_ci': ci, 'initial_failure': {'receiver': receiver, 'recording': recording,
            'application_state': live['state'], 'private_graph_cleanup_confirmed': True},
        'local_stages': stages, 'local_private_checks': local, 'pins': pins,
        'source_and_binaries_stable': True,
        'interpretation': 'Repeated reads gave inconsistent zero/nonzero/operand observations. Capturing one value keeps classification and evidence coherent. The exact mutation/overrun mechanism remains unresolved; an early-release ownership defect is not established.',
        'primary_source': 'https://github.com/PipeWire/pipewire/blob/1.0.5/src/pipewire/filter.c#L957-L1041',
        'limitations': ['No model, physical audio, sustained latency or M2 qualification.',
            'Instrumented mode retains its existing disabled execution-deadline/virtual-zero gates and strict nonzero sample oracle.',
            'Initial PR success does not replace failed push evidence; fresh source/docs push and PR CI remain required and are not claimed here.',
            'The original controller archive/source pins remain historical; these helper/binary pins are separate.'],
        'raw_secret_scan_exit': 0, 'raw_scanned_input_bytes': scanned_input_bytes,
        'scan_scope': 'Named uncompressed input evidence, before generated manifest/scanner-output packaging',
        'no_scan_suppression_or_allowlist': True, 'deterministic_gzip_roundtrip_verified': True,
        'files': files, 'uncompressed': uncompressed, 'origins': origins,
    }
    for name, expected in files.items():
        require(meta((stage / name).read_bytes()) == expected, 'Archived bytes changed: ' + name)
    for name, expected in uncompressed.items():
        require(meta(gzip.decompress((stage / name).read_bytes())) == expected, 'Gzip roundtrip failed: ' + name)
    for expected in origins.values():
        require(meta(read(ROOT / expected['path'])) == {k: expected[k] for k in ['bytes', 'sha256']}, 'Input changed during archive')
    verify_pins()
    require(command(['git', 'rev-parse', 'HEAD']).decode().strip() == args.head and
            command(['git', 'diff', PRODUCT_BASE, '--', 'src', 'qml']) == b'' and
            meta(read(historical_verification)) == historical_pin, 'Source/history changed during archive')
    (stage / 'verification.json').write_text(json.dumps(verification, indent=2, allow_nan=False) + '\n')
    stage.rename(DEST)
    print(json.dumps({'status': verification['status'], 'files': len(files) + 1,
                      'raw_input_bytes': total, 'local_checks': {k: v['checks'] for k, v in local.items()},
                      'destination': str(DEST)}, allow_nan=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
