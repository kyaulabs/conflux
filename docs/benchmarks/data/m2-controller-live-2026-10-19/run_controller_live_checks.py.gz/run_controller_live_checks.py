"""Run final combined controller/cache checks; preserve exact eligible prior runs."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

b = Path('benchmarks-local/m2-live-delivery-2026-10-19')
runner = b / 'run_controller_live_checks.py'
cli = b / 'check_controller_live_cli.py'
names = ['CMakeLists.txt', str(runner), str(cli), 'tools/coverage/requirements.txt',
         '.github/workflows/build.yml', 'tools/experiments/preparation_controller_check.cpp',
         'tools/experiments/private_routing_check.py', 'tools/coverage/run.py',
         'tools/experiments/manual_routing_check.cpp']
for folder in ['src', 'qml', 'tests', 'tools/stems']:
    names += [str(p) for p in Path(folder).rglob('*') if p.is_file() and p.suffix in {'.cpp', '.hpp', '.qml', '.py'}]
def pin(path):
    data = Path(path).read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def pins():
    return {name: pin(name) for name in sorted(set(names))}
def load(path):
    return json.loads(Path(path).read_text())
def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')

result_path = b / 'controller-live-functional-result.json'
assert not result_path.exists(), 'Use a distinct evidence run after any failure; never overwrite it'
initial = pins()
save(b / 'controller-live-source-pins.json', initial)
rows, artifacts = [], {}
binaries = ['conflux', 'conflux-live-stem-bridge-test', 'conflux-prepared-track-store-test',
            'conflux-deck-controller-test', 'conflux-manual-ui-test',
            'conflux-manual-routing-check', 'conflux-preparation-controller-check']
def artifact_pins(folder):
    return {str(Path(folder) / name): pin(Path(folder) / name) for name in binaries}
env = os.environ | {'QT_QPA_PLATFORM': 'offscreen', 'QT_QUICK_BACKEND': 'software',
                    'QT_QUICK_CONTROLS_STYLE': 'Basic'}
launcher = "import runpy, signal, sys\ndef stop(*_):\n    signal.signal(signal.SIGTERM, signal.SIG_IGN)\n    raise InterruptedError('Controller validation stage timed out')\nsignal.signal(signal.SIGTERM, stop)\nsys.argv = sys.argv[1:]\nrunpy.run_path(sys.argv[0], run_name='__main__')\n"

def reuse(kind):
    name = 'build/dev/conflux-' + ('manual-routing-check' if kind == 'routing' else 'preparation-controller-check')
    if kind == 'routing':
        prior = load('docs/benchmarks/data/m2-session-prime-ci-2026-10-19/verification.json')
        expected = prior['current_binaries'][name]
        eligible = pin('tools/experiments/manual_routing_check.cpp') == prior['normal_source'] and pin(name) == expected
        evidence = b / 'session-prime-diagnostic-normal-01/result.json'
        reason = 'Exact prior diagnostic normal-routing source and executed binary; unchanged strict oracle and owned cleanup'
    else:
        expected = load(b / 'controller-live-green-artifact-pins.json')[name]
        freeze = load(b / 'controller-live-implementation-freeze.json')
        eligible = pin(name) == expected
        for path, expected_source in freeze['independent_test_inputs'].items():
            eligible &= pin(path) == expected_source
        for entry in freeze['files']:
            eligible &= pin(entry['path']) == dict(bytes=entry['output_bytes'], sha256=entry['output_sha256'])
        evidence = b / 'controller-live-green-private-01/result.json'
        reason = 'Exact first controller GREEN binary and unchanged frozen product/test source outputs; no second execution attributed'
    if not eligible:
        return None
    value = load(evidence)
    assert value['passed'] and value['check_exit'] == 0 and value['check']['passed'] and not value['check'].get('error')
    assert value['daemon_reaped'] and not value['cleanup']['remaining_nodes_or_links']
    if kind == 'routing':
        assert pin(evidence) == prior['uncompressed']['normal-result.json.gz']
    return dict(stage='controller-live-normal-' + kind, exit=0, timed_out=False,
                reused=True, executed_in_this_pipeline=False, elapsed_seconds=None,
                evidence_path=str(evidence), evidence_pin=pin(evidence), binary_pin=expected,
                reuse_reason=reason)

commands = [
    ('full-build', ['cmake', '--build', 'build/dev', '--parallel', '2'], 600),
    ('ctest', ['ctest', '--test-dir', 'build/dev', '--output-on-failure', '--timeout', '120'], 900),
    ('smoke', ['build/dev/conflux', '--smoke-test'], 30),
    ('cli', ['python3', '-B', str(cli), str(Path('build/dev/conflux').resolve())], 120),
    ('normal-routing', None, 180),
    ('normal-preparation', None, 180),
    ('coverage', ['benchmarks-local/coverage-venv/bin/python', '-c', launcher, 'tools/coverage/run.py', '--private-routing', '--jobs', '2'], 1800),
]
for short, command, limit in commands:
    assert pins() == initial, 'Source changed during final checks'
    stage = 'controller-live-' + short
    row = None
    if short.startswith('normal-'):
        kind = short.removeprefix('normal-')
        row = reuse(kind)
        if row is None:
            evidence = b / ('controller-live-normal-' + kind + '-01')
            assert not evidence.exists(), 'Private evidence path must be fresh'
            binary = 'build/dev/conflux-' + ('manual-routing-check' if kind == 'routing' else 'preparation-controller-check')
            command = ['python3', '-c', launcher, 'tools/experiments/private_routing_check.py', binary, str(evidence)]
    if row is None:
        start = time.monotonic()
        timed = False
        with (b / (stage + '.log')).open('w') as log:
            child = subprocess.Popen(command, env=env, stdin=subprocess.DEVNULL, stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = child.wait(timeout=limit)
            except subprocess.TimeoutExpired:
                timed = True
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    code = child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    code = child.wait(timeout=5)
        row = dict(stage=stage, command=command, exit=code, timed_out=timed,
                   reused=False, executed_in_this_pipeline=True, elapsed_seconds=time.monotonic() - start)
        if short.startswith('normal-'):
            row['evidence_path'] = str(evidence / 'result.json')
            row['evidence_pin'] = pin(evidence / 'result.json')
    rows.append(row)
    save(result_path, rows)
    print(json.dumps(row), flush=True)
    if row['exit'] != 0 or row['timed_out']:
        if (b / (stage + '.log')).exists():
            print((b / (stage + '.log')).read_text()[-6000:], flush=True)
        raise SystemExit(row['exit'] or 1)
    if short in ['full-build', 'coverage']:
        folder = 'build/dev' if short == 'full-build' else 'build/coverage'
        artifacts[folder] = artifact_pins(folder)
        save(b / 'controller-live-artifact-pins.json', artifacts)
assert pins() == initial
for folder, expected in artifacts.items():
    assert artifact_pins(folder) == expected, folder
save(b / 'controller-live-source-stable.json', dict(status='all_pins_unchanged', files=len(initial)))
