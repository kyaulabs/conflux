"""Freeze generated numeric fixtures using the retained NumPy prototype."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import numpy as np

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
DATA = BASE / 'input'
PLAN = json.loads((BASE / 'plan-01.json').read_text())
path = ROOT / 'build/m2-deepspec-assessment-01/numeric-forward-01/keycnn_numeric.py'
spec = importlib.util.spec_from_file_location('retained_keycnn_numeric', path)
numeric = importlib.util.module_from_spec(spec)
spec.loader.exec_module(numeric)
assert np.__version__ == '1.23.5'
features = np.zeros((4, 168, 60, 1), dtype=np.float64)
features[1, :, :, 0] = np.linspace(0, 2, 168)[:, None] * np.linspace(.25, 1.25, 60)[None, :]
features[2, 9, 3, 0] = 3
features[2, 74, 31, 0] = 1
features[2, 162, 58, 0] = 2
features[3, :, :, 0] = np.random.RandomState(PLAN['features']['seed']).uniform(size=(168, 60))
weights = numeric.weights()
posterior, traces = numeric.forward(features, weights)
directory = DATA / 'expected'
directory.mkdir(exist_ok=False)


def store(filename, value):
    raw = value.tobytes(order='C')
    (DATA / filename).write_bytes(raw)
    return dict(file=filename, shape=list(value.shape), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


raw = store('features.f64', features.astype('<f8'))
expected = []
for index, (name, value) in enumerate(traces):
    row = store('expected/trace-%02d.f32' % index, value.astype('<f4'))
    expected.append(dict(name=name, **row))
assert len(expected) == 34
manifest = dict(schema=1, features=raw, expected=expected, model_config_sha256=PLAN['config_sha256'],
                numeric_source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                numpy=np.__version__, top_one=posterior.argmax(axis=1).tolist(), labels_used=False)
(DATA / 'fixtures.json').write_text(json.dumps(manifest, indent=2) + '\n')
files = []
for path in sorted(DATA.rglob('*')):
    if path.is_file():
        content = path.read_bytes()
        files.append(dict(file=str(path.relative_to(DATA)), bytes=len(content),
                          sha256=hashlib.sha256(content).hexdigest()))
(BASE / 'input-manifest-01.json').write_text(json.dumps(dict(files=files), indent=2) + '\n')
print(json.dumps(dict(fixtures=4, traces=len(expected), top_one=manifest['top_one'],
                      total_bytes=sum(r['bytes'] for r in files), labels_used=False)))
