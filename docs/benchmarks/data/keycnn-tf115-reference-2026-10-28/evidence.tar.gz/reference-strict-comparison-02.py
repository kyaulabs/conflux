"""Compare the exact data-only graph with upstream TensorFlow1.15.2 on CPU."""
from pathlib import Path
import hashlib
import json
import os
import sys
import time
import numpy as np

DATA, OUTPUT = Path('/input'), Path('/out')
began = time.monotonic()
report = dict(schema=1, passed=False, musical_accuracy_qualified=False,
              production_backend_enabled=False, audio_device_opened=False, GPU_used=False,
              scope='Generated fixed-shape CPU forward/normalization reference only; no music, training provenance or confidence qualification.')


def checked_file(row, dtype):
    path = DATA / row['file']
    try:
        path.resolve().relative_to(DATA.resolve())
    except ValueError:
        raise ValueError('Fixture/tensor path escapes input')
    raw = path.read_bytes()
    if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
        raise ValueError('Fixture/tensor bytes or hash differs')
    value = np.frombuffer(raw, dtype=dtype).reshape(row['shape']).copy()
    if not np.isfinite(value).all():
        raise ValueError('Nonfinite fixture/tensor')
    return value


def main():
    plan = json.loads((DATA / 'plan.json').read_text())
    fixture = json.loads((DATA / 'fixtures.json').read_text())
    config_raw = (DATA / 'model-config.json').read_bytes()
    if hashlib.sha256(config_raw).hexdigest() != plan['config_sha256']:
        raise ValueError('Audited graph configuration hash differs')
    config = json.loads(config_raw)
    allowed = {'Model', 'InputLayer', 'Conv2D', 'BatchNormalization', 'MaxPooling2D',
               'Dropout', 'GlobalAveragePooling2D', 'Activation', 'VarianceScaling', 'Zeros', 'Ones'}
    def validate(value):
        if isinstance(value, dict):
            if 'class_name' in value and value['class_name'] not in allowed:
                raise ValueError('Unapproved serialized class')
            for item in value.values():
                validate(item)
        elif isinstance(value, list):
            for item in value:
                validate(item)
    validate(config)
    raw = checked_file(fixture['features'], '<f8')
    if raw.shape != (4, 168, 60, 1) or np.__version__ != '1.16.0':
        raise ValueError('Fixed input or NumPy version differs')
    mean, std = np.mean(raw), np.std(raw)
    if std != 0:
        raw = (raw - mean) / std
    normalized = raw.astype(np.float16).astype(np.float32)
    expected = [(r['name'], checked_file(r, '<f4')) for r in fixture['expected']]
    report['normalization_bit_exact'] = bool(np.array_equal(normalized.view('u4'), expected[0][1].view('u4')))
    if not report['normalization_bit_exact']:
        raise ValueError('Legacy normalized float16 input differs')
    tensors = {}
    for row in json.loads((DATA / 'tensors.json').read_text())['tensors']:
        key = tuple(row['name'])
        if key in tensors:
            raise ValueError('Duplicate numeric tensor')
        tensors[key] = checked_file(row, '<f4')
    if len(tensors) != 74 or sum(v.size for v in tensors.values()) != 290376:
        raise ValueError('Numeric parameter population differs')
    import tensorflow as tf
    from tensorflow.python.keras import backend as K
    from tensorflow.python.keras.models import Model, model_from_json
    if tf.__version__ != '1.15.2' or sys.version_info[:3] != (3, 7, 17):
        raise ValueError('Pinned legacy runtime differs')
    session = tf.Session(config=tf.ConfigProto(intra_op_parallelism_threads=1,
                         inter_op_parallelism_threads=1, device_count={'GPU': 0}))
    K.set_session(session)
    devices = [dict(name=d.name, type=d.device_type) for d in session.list_devices()]
    if any(d['type'] not in ('CPU', 'XLA_CPU') for d in devices):
        raise ValueError('CPU-only reference required')
    model = model_from_json(config_raw.decode('utf8'), custom_objects={})
    consumed = []
    for layer in model.layers:
        keys = [(layer.name, v.name.rsplit('/', 1)[-1]) for v in layer.weights]
        if keys:
            layer.set_weights([tensors[key] for key in keys])
            consumed += keys
    if len(consumed) != 74 or set(consumed) != set(tensors) or model.count_params() != 290376:
        raise ValueError('Original graph parameter assignment differs')
    names = {}
    for name, _ in expected[1:]:
        actual_name = ('global_average_pooling2d_125' if name == 'global_average_pooling2d'
                       else 'activation_125' if name == 'activation' else name)
        names[name] = model.get_layer(actual_name).output
    traced = Model(inputs=model.input, outputs=[names[name] for name, _ in expected[1:]])
    report.update(tensorflow=tf.__version__, numpy=np.__version__, python=sys.version.split()[0],
                  devices=devices, graph_layers=len(model.layers), numeric_tensors=len(consumed),
                  parameters=model.count_params(), normalized_input_sha256=hashlib.sha256(normalized.tobytes()).hexdigest(),
                  comparisons=[], batch_sizes=plan['batch_sizes'])
    for batch in plan['batch_sizes']:
        values = traced.predict(normalized, batch_size=batch, verbose=0)
        if len(values) != len(expected) - 1:
            raise ValueError('Reference trace population differs')
        for (name, wanted), observed in zip(expected[1:], values):
            if observed.shape != wanted.shape or not np.isfinite(observed).all():
                raise ValueError('Reference output geometry or values differ')
            tolerance = plan['posterior_tolerance'] if name == 'activation' else plan['layer_tolerance']
            delta = np.abs(observed.astype(np.float64) - wanted.astype(np.float64))
            passed = bool(np.allclose(observed, wanted, **tolerance))
            report['comparisons'].append(dict(batch=batch, layer=name, passed=passed,
                elements=int(observed.size), maximum_absolute_error=float(delta.max()),
                mean_absolute_error=float(delta.mean()), tolerance=tolerance))
        posterior = values[-1]
        (OUTPUT / ('posterior-%d.f32' % batch)).write_bytes(posterior.astype('<f4').tobytes())
        if not np.all(posterior >= 0) or not np.allclose(posterior.sum(axis=1), 1, atol=1e-6, rtol=0):
            raise ValueError('Invalid posterior probabilities')
    session.close()
    report['passed'] = all(r['passed'] for r in report['comparisons'])
    report['posterior_top_one_matches'] = bool(np.array_equal(posterior.argmax(axis=1), fixture['top_one']))
    report['passed'] = report['passed'] and report['posterior_top_one_matches']


try:
    main()
except Exception as error:
    report['error'] = dict(type=type(error).__name__, message=str(error)[:2000])
finally:
    report['seconds'] = time.monotonic() - began
    (OUTPUT / 'result.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'comparisons'}, allow_nan=False))
raise SystemExit(0 if report['passed'] else 1)
