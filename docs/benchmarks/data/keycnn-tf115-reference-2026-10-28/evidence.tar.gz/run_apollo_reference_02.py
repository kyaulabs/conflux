from pathlib import Path
import hashlib,json,subprocess,time
p=Path('/srv/conflux-tests/keycnn-tf115-reference-20261028-01')
docker=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
image=json.loads(subprocess.check_output(docker+['image','inspect','conflux-keycnn-tf115-reference:20261028-01']))[0]
assert image['Config']['Labels']['io.kyaulabs.conflux.test']=='keycnn-tf115-reference-20261028-01'
assert image['Id']==json.loads((p/'execution-plan-01.json').read_text())['image_id']
expected=(p/'reference.sha256').read_text().strip();assert len(expected)==64 and hashlib.sha256((p/'reference.py').read_bytes()).hexdigest()==expected
manifest=json.loads((p/'input-manifest-01.json').read_text())
def verify():
 for row in manifest['files']:
  raw=(p/'input'/row['file']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
verify();out=p/'output-02';out.mkdir(mode=0o755,exist_ok=False);name='conflux-keycnn-tf115-reference-20261028-02'
command=docker+['run','--name',name,'--label','io.kyaulabs.conflux.test=keycnn-tf115-reference-20261028-01','--runtime=runc','--network=none','--read-only','--cpus=1','--memory=2g','--pids-limit=128','--cap-drop=ALL','--security-opt=no-new-privileges','--user=1000:1000','--tmpfs=/tmp:rw,noexec,nosuid,size=64m,mode=1777','--env=CUDA_VISIBLE_DEVICES=-1','--env=HOME=/tmp','--env=TF_CPP_MIN_LOG_LEVEL=2','--env=OPENBLAS_NUM_THREADS=1','--env=OMP_NUM_THREADS=1','--env=MKL_NUM_THREADS=1','--env=PYTHONHASHSEED=0','--mount','type=bind,src='+str(p/'input')+',dst=/input,readonly','--mount','type=bind,src='+str(p/'reference.py')+',dst=/reference.py,readonly','--mount','type=bind,src='+str(out)+',dst=/out','--entrypoint=/usr/local/bin/python',image['Id'],'-B','/reference.py']
plan=dict(image_id=image['Id'],reference_sha256=expected,input_manifest_sha256=hashlib.sha256((p/'input-manifest-01.json').read_bytes()).hexdigest(),command=command,execution_seconds=120,GPU_requested=False,network='none',read_only=True,protected_resources_changed=False)
(p/'execution-plan-02.json').write_text(json.dumps(plan,indent=2)+'\n');began=time.monotonic();timed_out=False
with (p/'runtime.stdout-02.log').open('x') as stdout,(p/'runtime.stderr-02.log').open('x') as stderr:
 try:r=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=120);code=r.returncode
 except subprocess.TimeoutExpired:
  timed_out=True;subprocess.run(docker+['stop','--time','5',name],capture_output=True,timeout=10);code=124
container=json.loads(subprocess.check_output(docker+['inspect',name]))[0]
assert container['Image']==image['Id'] and container['Config']['Labels']['io.kyaulabs.conflux.test']=='keycnn-tf115-reference-20261028-01'
assert container['State']['Running'] is False and container['State']['Pid']==0
subprocess.run(docker+['rm',container['Id']],check=True,capture_output=True)
assert subprocess.run(docker+['inspect',container['Id']],capture_output=True).returncode!=0
verify();result=json.loads((out/'result.json').read_text()) if (out/'result.json').exists() else {}
receipt=dict(exit=code,timed_out=timed_out,elapsed_seconds=time.monotonic()-began,container_removed=True,input_hashes_unchanged=True,container_state=container['State'],host_config={k:container['HostConfig'].get(k) for k in ['Runtime','NetworkMode','ReadonlyRootfs','NanoCpus','Memory','PidsLimit','Devices','DeviceRequests','CapDrop','SecurityOpt']},numerical_passed=result.get('passed',False),error=result.get('error'),comparison_count=len(result.get('comparisons',[])))
(p/'execution-result-02.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if code:print((p/'runtime.stderr-02.log').read_text()[-2000:])
raise SystemExit(code)
