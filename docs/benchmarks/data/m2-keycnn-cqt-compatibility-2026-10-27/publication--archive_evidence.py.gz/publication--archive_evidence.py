"""Retain generated CQT experiment text; omit binary arrays and dependencies."""
from datetime import datetime, timezone
import ast
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
SOURCE = BASE.parent
DEST = BASE/'stage/docs/benchmarks/data/m2-keycnn-cqt-compatibility-2026-10-27'
RAW = BASE/'uncompressed-review-01'
DEST.mkdir(parents=True, exist_ok=False)
RAW.mkdir(mode=0o700)
selected = sorted(p for p in SOURCE.iterdir() if p.is_file() and p.suffix in ('.py', '.json', '.log'))
selected.append(Path(__file__).resolve())
records = []
for path in selected:
    if path.is_symlink():
        raise ValueError('Evidence source must be a regular file')
    raw = path.read_bytes()
    raw.decode('utf-8')
    if path.suffix == '.json':
        json.loads(raw)
    if path.suffix == '.py':
        ast.parse(raw)
    name = ('publication--' if path.parent == BASE else '')+path.name
    packed = gzip.compress(raw, mtime=0)
    with (RAW/name).open('xb') as stream:
        stream.write(raw)
    with (DEST/(name+'.gz')).open('xb') as stream:
        stream.write(packed)
    records.append(dict(file=name+'.gz', private_source=str(path.relative_to(ROOT)),
                        bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                        gzip_bytes=len(packed), gzip_sha256=hashlib.sha256(packed).hexdigest(),
                        UTF8=True, source_bytes_unmodified=True))
manifest = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(), records=records,
                scope='Generated-only feature and numeric-posterior diagnostic; no production integration',
                compressed_file_count=len(records), compressed_bytes=sum(r['gzip_bytes'] for r in records),
                prior_evidence_manifest='../m2-keycnn-diagnostic-2026-10-27/manifest.json',
                prior_evidence='The retained prior manifest includes the generated fixtures, comparison helpers, '
                               'dependency lock, source-package provenance, legacy reference results and numeric model prototype.',
                omitted=['Generated NPZ arrays; their complete file hashes remain in the receipts and plans',
                         'Installed runtimes, libraries and caches', 'Model checkpoint and raw weights',
                         'Unmodified upstream source packages; prior download hashes remain available'],
                no_audio_recordings_or_reference_labels_used=True,
                model_provenance='The same audited key-CNN checkpoint and hashed data-only tensors as the prior diagnostic; '
                                 'no checkpoint or tensor distribution.',
                original_training_dependencies_reproduced=False, original_framework_compatibility_qualified=False,
                held_out_musical_accuracy_qualified=False, confidence_calibrated=False,
                M2_complete=False, M3_complete=False, release_authorized=False)
with (DEST/'manifest.json').open('x') as stream:
    stream.write(json.dumps(manifest, indent=2, allow_nan=False)+'\n')
print(json.dumps(dict(files=len(records), compressed_bytes=manifest['compressed_bytes'], destination=str(DEST))))
