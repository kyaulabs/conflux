"""Compare entire generated feature arrays and retained numeric posteriors."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource

for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMBA_NUM_THREADS'):
    os.environ[key] = '1'
resource.setrlimit(resource.RLIMIT_AS, (3*1024**3, 3*1024**3))
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
import numpy as np

BASE = Path(__file__).resolve().parent
PRIOR = BASE.parent/'feature-compatibility-01'
MODES = ('modern_reflect_fast_f64', 'modern_matched_q_f32', 'modern_matched_q_f64')


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def load_features(directory, mode, cases):
    path = directory/(mode+'-features-01.npz')
    receipt = json.loads(path.with_suffix('.json').read_text())
    if hashlib.sha256(path.read_bytes()).hexdigest() != receipt['feature_sha256']:
        raise ValueError('Generated feature archive hash differs')
    with np.load(path, allow_pickle=False) as archive:
        keys = {case+suffix for case in cases for suffix in ('', '_padded_0', '_padded_1')}
        if set(archive.files) != keys:
            raise ValueError('Generated feature population differs')
        result = {key:archive[key] for key in keys}
    if any(not np.isfinite(value).all() for value in result.values()):
        raise ValueError('Nonfinite generated features')
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--posteriors', action='store_true')
    args = parser.parse_args()
    target = BASE/('generated-pipeline-01.json' if args.posteriors else 'assessment-01.json')
    if target.exists():
        raise FileExistsError('Never replace a comparison result')
    plan = json.loads((BASE/'plan-01.json').read_text())
    for row in plan['files']:
        raw = Path(row['path']).read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('Frozen source or retained baseline changed')
    helper = module('audited_feature_comparison', PRIOR/'compare_features.py')
    cases = helper.CASES
    legacy = load_features(PRIOR, 'legacy', cases)
    old_modern = load_features(PRIOR, 'modern_reflect_fast', cases)
    loaded = {mode:load_features(BASE, mode, cases) for mode in MODES}
    # Generated PCM must be identical for every new mode, before any result is compared.
    receipts = [json.loads((BASE/(mode+'-features-01.json')).read_text()) for mode in MODES]
    populations = [[(r['case'], r['source_samples'], r['source_sha256']) for r in item['records']]
                   for item in receipts]
    if any(population != populations[0] for population in populations):
        raise ValueError('Generated source population changed between modes')
    records = []
    aggregates = {}
    if args.posteriors:
        numeric_path = BASE.parent/'numeric-forward-03/keycnn_numeric.py'
        numeric = module('audited_numeric_keycnn', numeric_path)
        tensors = numeric.weights()
        previous = json.loads((PRIOR/'generated-pipeline-01.json').read_text())
        reference = {row['case']:np.asarray(row['probabilities'], dtype=np.float32)
                     for row in previous['full_population'] if row['mode'] == 'legacy'}
        for mode, values in loaded.items():
            errors = []
            changed = 0
            for case in cases:
                value = values[case+'_padded_1']
                if value.shape != (3, 168, 60, 1):
                    raise ValueError('Generated classifier window geometry differs')
                probabilities = numeric.predict(value, tensors, batch_size=3)
                if (probabilities.shape != (3, 24) or not np.isfinite(probabilities).all()
                        or np.any(probabilities < 0) or np.any(probabilities > 1)
                        or not np.allclose(probabilities.sum(axis=1), 1, rtol=1e-6, atol=1e-6)):
                    raise ValueError('Invalid generated probability distribution')
                errors.append(np.abs(probabilities-reference[case]))
                changed += int(np.count_nonzero(probabilities.argmax(axis=1) != reference[case].argmax(axis=1)))
                records.append(dict(mode=mode, case=case, probabilities=probabilities.tolist(),
                                    argmax_indices=probabilities.argmax(axis=1).tolist(),
                                    legacy_argmax_indices=reference[case].argmax(axis=1).tolist()))
            error = np.concatenate(errors)
            aggregates[mode] = dict(max_probability_difference=float(error.max()),
                                    mean_probability_difference=float(error.mean()),
                                    different_argmax_windows=changed, denominator_windows=18)
    else:
        for mode, values in {'retained_modern_reflect_fast':old_modern, **loaded}.items():
            mode_records = []
            for case in cases:
                row = dict(mode=mode, case=case, full_CQT=helper.difference(legacy[case], values[case]),
                           model_input_unpadded=helper.difference(helper.normalize(legacy[case+'_padded_0']),
                                                                 helper.normalize(values[case+'_padded_0'])),
                           model_input_padded=helper.difference(helper.normalize(legacy[case+'_padded_1']),
                                                               helper.normalize(values[case+'_padded_1'])))
                records.append(row)
                mode_records.append(row)
            aggregates[mode] = dict(
                full_CQT_close_cases=sum(row['full_CQT']['close_rtol_1e_5_atol_1e_7'] for row in mode_records),
                largest_full_CQT_relative_L2=max(row['full_CQT']['relative_L2_error'] for row in mode_records),
                largest_normalized_padded_max_absolute_error=max(row['model_input_padded']['max_absolute_error']
                                                                for row in mode_records), denominator=len(cases))
    report = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                  status='generated_posterior_comparison_complete' if args.posteriors else 'generated_feature_comparison_complete',
                  generated_cases=cases, modes=list(MODES), full_population=records, aggregates=aggregates,
                  model_started=args.posteriors, generated_only=True, audio_device_opened=False, GPU_started=False,
                  product_configuration_changed=False, musical_accuracy_qualified=False,
                  original_training_dependencies_reproduced=False, original_framework_compatibility_qualified=False,
                  interpretation='Source-derived filter-length and precision diagnostics only. '
                                 'No musical labels or fitted parameters were used. This does not establish '
                                 'held-out accuracy, confidence calibration or training-framework equivalence.')
    if args.posteriors:
        report['numeric_source_sha256'] = hashlib.sha256(numeric_path.read_bytes()).hexdigest()
        report['model_sha256'] = numeric.MODEL_SHA
    with target.open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(status=report['status'], aggregates=aggregates)))


if __name__ == '__main__':
    main()
