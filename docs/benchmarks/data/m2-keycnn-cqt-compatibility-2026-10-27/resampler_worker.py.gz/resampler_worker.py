"""One-factor generated comparison: modern corrected CQT, legacy resampler."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import warnings

BASE = Path(__file__).resolve().parent
PRIOR = BASE.parent/'feature-compatibility-01'
MODE = 'modern_matched_q_f32_legacy_resampy'


def main():
    plan = json.loads((BASE/'resampler-plan-01.json').read_text())
    for row in plan['files']:
        raw = Path(row['path']).read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('Frozen source or input differs')
    output = BASE/(MODE+'-features-01.npz')
    if output.exists() or output.with_suffix('.json').exists():
        raise FileExistsError('Never replace a generated comparison')
    spec = importlib.util.spec_from_file_location('audited_generated_features', PRIOR/'feature_worker.py')
    helpers = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helpers)
    helpers.audited_sources()
    sys.path.insert(0, str(PRIOR/'legacy-source/resampy'))
    import librosa
    import numpy as np
    import resampy
    if librosa.__version__ != '0.11.0' or resampy.__version__ != '0.2.2':
        raise ValueError('Unexpected feature runtime')
    scale = ((2.0**(2.0/24)-1.0)/(2.0**(2.0/24)+1.0))/(2.0**(1.0/24)-1.0)
    arrays = {}
    records = []
    with warnings.catch_warnings(record=True) as emitted:
        warnings.simplefilter('always')
        for name, signal in helpers.fixtures().items():
            magnitude = np.abs(librosa.cqt(
                signal, sr=22050, hop_length=4096, fmin=librosa.note_to_hz('E1'),
                n_bins=168, bins_per_octave=24, tuning=0.0, filter_scale=scale,
                pad_mode='reflect', res_type='kaiser_fast', dtype=np.complex64))
            if magnitude.shape != (168, 1+len(signal)//4096) or not np.isfinite(magnitude).all():
                raise ValueError('Generated CQT geometry or finite check differs')
            arrays[name] = magnitude
            for padded in (False, True):
                arrays[name+'_padded_'+str(int(padded))] = helpers.windows(magnitude, padded)
            records.append(dict(case=name, source_samples=len(signal), source_dtype=str(signal.dtype),
                                source_sha256=hashlib.sha256(signal.tobytes()).hexdigest(),
                                CQT_shape=list(magnitude.shape), CQT_dtype=str(magnitude.dtype)))
    with output.open('xb') as stream:
        np.savez_compressed(stream, **arrays)
    report = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(), mode=MODE,
                  librosa_version=librosa.__version__, resampy_version=resampy.__version__,
                  resampy_path=resampy.__file__, filter_scale=scale, complex_dtype='complex64',
                  records=records, warning_count=len(emitted), warnings=dict(Counter(str(row.message) for row in emitted)),
                  feature_sha256=hashlib.sha256(output.read_bytes()).hexdigest(), generated_only=True,
                  product_configuration_changed=False, GPU_started=False, audio_device_opened=False,
                  original_training_dependencies_reproduced=False, musical_accuracy_qualified=False)
    with output.with_suffix('.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(mode=MODE, filter_scale=scale, generated_cases=len(records))))


if __name__ == '__main__':
    main()
