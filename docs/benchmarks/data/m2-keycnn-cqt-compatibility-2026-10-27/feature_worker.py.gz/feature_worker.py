"""Generated-only CQT comparison using a source-derived filter-length correction."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import warnings

BASE = Path(__file__).resolve().parent
PRIOR = BASE.parent/'feature-compatibility-01'
MODES = ('modern_reflect_fast_f64', 'modern_matched_q_f32', 'modern_matched_q_f64')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', required=True, choices=MODES)
    args = parser.parse_args()
    plan = json.loads((BASE/'plan-01.json').read_text())
    for row in plan['files']:
        raw = Path(row['path']).read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('Frozen source or input hash differs')
    target = BASE/(args.mode+'-features-01.npz')
    if target.exists() or target.with_suffix('.json').exists():
        raise FileExistsError('Never replace a prior generated experiment')
    spec = importlib.util.spec_from_file_location('audited_generated_features', PRIOR/'feature_worker.py')
    helpers = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helpers)
    helpers.audited_sources()
    # Importing helpers applies the unchanged 2 GiB/90 CPU-second bounds and
    # single-thread settings before any numerical library is imported.
    import librosa
    import numpy as np
    import resampy
    if librosa.__version__ != '0.11.0' or resampy.__version__ != '0.4.3':
        raise ValueError('Unexpected feature runtime')
    bins = 24
    alpha_old = 2.0**(1.0/bins)-1.0
    alpha_new = (2.0**(2.0/bins)-1.0)/(2.0**(2.0/bins)+1.0)
    scale = alpha_new/alpha_old if 'matched_q' in args.mode else 1.0
    dtype = np.complex128 if args.mode.endswith('f64') else np.complex64
    frequencies = librosa.cqt_frequencies(168, fmin=librosa.note_to_hz('E1'), bins_per_octave=bins)
    expected_lengths = (1.0/alpha_old)*22050/frequencies
    actual_lengths, _ = librosa.filters.wavelet_lengths(
        freqs=frequencies, sr=22050, filter_scale=scale, gamma=0.0)
    arrays = {}
    records = []
    with warnings.catch_warnings(record=True) as emitted:
        warnings.simplefilter('always')
        for name, signal in helpers.fixtures().items():
            magnitude = np.abs(librosa.cqt(
                signal, sr=22050, hop_length=4096, fmin=librosa.note_to_hz('E1'),
                n_bins=168, bins_per_octave=bins, tuning=0.0, filter_scale=scale,
                pad_mode='reflect', res_type='kaiser_fast', dtype=dtype))
            if magnitude.shape != (168, 1+len(signal)//4096) or not np.isfinite(magnitude).all():
                raise ValueError('Generated CQT extent or finite check differs')
            arrays[name] = magnitude
            for padded in (False, True):
                arrays[name+'_padded_'+str(int(padded))] = helpers.windows(magnitude, padded)
            records.append(dict(case=name, source_samples=len(signal), source_dtype=str(signal.dtype),
                                source_sha256=hashlib.sha256(signal.tobytes()).hexdigest(),
                                CQT_shape=list(magnitude.shape), CQT_dtype=str(magnitude.dtype)))
    with target.open('xb') as stream:
        np.savez_compressed(stream, **arrays)
    report = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(), mode=args.mode,
                  librosa_version=librosa.__version__, resampy_version=resampy.__version__,
                  numpy_version=np.__version__, alpha_old=alpha_old, alpha_new=alpha_new,
                  filter_scale=scale, complex_dtype=np.dtype(dtype).name,
                  filter_length_max_relative_difference=float(np.max(np.abs(
                      actual_lengths-expected_lengths)/expected_lengths)),
                  recipe=dict(sample_rate=22050, bins_per_octave=24, bins=168, fmin_note='E1',
                              tuning=0.0, hop_length=4096, pad_mode='reflect', res_type='kaiser_fast'),
                  records=records, warning_count=len(emitted), warnings=dict(Counter(
                      str(row.message) for row in emitted)),
                  feature_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                  generated_only=True, product_configuration_changed=False, GPU_started=False,
                  audio_device_opened=False, model_started=False,
                  original_training_dependencies_reproduced=False, musical_accuracy_qualified=False)
    with target.with_suffix('.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(mode=args.mode, filter_scale=scale, generated_cases=len(records),
                         feature_bytes=target.stat().st_size,
                         filter_length_max_relative_difference=report['filter_length_max_relative_difference'])))


if __name__ == '__main__':
    main()
