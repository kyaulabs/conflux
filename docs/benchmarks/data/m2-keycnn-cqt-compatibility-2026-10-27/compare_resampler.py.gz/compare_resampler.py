"""Compare the frozen one-factor resampler case without reading music labels."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
PRIOR = BASE.parent/'feature-compatibility-01'
MODE = 'modern_matched_q_f32_legacy_resampy'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def main():
    output = BASE/'resampler-assessment-01.json'
    if output.exists():
        raise FileExistsError('Never replace a diagnostic result')
    plan = json.loads((BASE/'resampler-comparison-plan-01.json').read_text())
    for row in plan['files']:
        raw = Path(row['path']).read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('Frozen source or input differs')
    compare = module('audited_comparison', BASE/'compare_features.py')
    import numpy as np
    helper = module('audited_prior_comparison', PRIOR/'compare_features.py')
    cases = helper.CASES
    legacy = compare.load_features(PRIOR, 'legacy', cases)
    current = compare.load_features(BASE, 'modern_matched_q_f32', cases)
    candidate = compare.load_features(BASE, MODE, cases)
    baseline_receipt = json.loads((BASE/'modern_matched_q_f32-features-01.json').read_text())
    candidate_receipt = json.loads((BASE/(MODE+'-features-01.json')).read_text())
    population = lambda r:[(x['case'], x['source_samples'], x['source_sha256']) for x in r['records']]
    if population(baseline_receipt) != population(candidate_receipt):
        raise ValueError('Generated source PCM changed')
    numeric = module('audited_numeric', BASE.parent/'numeric-forward-03/keycnn_numeric.py')
    tensors = numeric.weights()
    prior = json.loads((PRIOR/'generated-pipeline-01.json').read_text())
    references = {row['case']:np.asarray(row['probabilities'], dtype=np.float32)
                  for row in prior['full_population'] if row['mode'] == 'legacy'}
    records = []
    errors = []
    changes = 0
    for case in cases:
        values = candidate[case+'_padded_1']
        if values.shape != (3, 168, 60, 1):
            raise ValueError('Generated classifier window geometry differs')
        probabilities = numeric.predict(values, tensors, batch_size=3)
        if (probabilities.shape != (3, 24) or not np.isfinite(probabilities).all()
                or np.any(probabilities < 0) or np.any(probabilities > 1)
                or not np.allclose(probabilities.sum(axis=1), 1, rtol=1e-6, atol=1e-6)):
            raise ValueError('Invalid generated posterior')
        errors.append(np.abs(probabilities-references[case]))
        changes += int(np.count_nonzero(probabilities.argmax(axis=1) != references[case].argmax(axis=1)))
        records.append(dict(case=case, full_CQT=helper.difference(legacy[case], candidate[case]),
                            change_from_modern_resampler=helper.difference(current[case], candidate[case]),
                            model_input_padded=helper.difference(helper.normalize(legacy[case+'_padded_1']),
                                                                helper.normalize(values)),
                            probabilities=probabilities.tolist(),
                            argmax_indices=probabilities.argmax(axis=1).tolist(),
                            legacy_argmax_indices=references[case].argmax(axis=1).tolist()))
    error = np.concatenate(errors)
    aggregate = dict(full_CQT_close_cases=sum(r['full_CQT']['close_rtol_1e_5_atol_1e_7'] for r in records),
                     largest_full_CQT_relative_L2=max(r['full_CQT']['relative_L2_error'] for r in records),
                     largest_normalized_padded_max_absolute_error=max(r['model_input_padded']['max_absolute_error'] for r in records),
                     max_probability_difference=float(error.max()), mean_probability_difference=float(error.mean()),
                     different_argmax_windows=changes, denominator_cases=6, denominator_windows=18)
    result = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                  status='generated_resampler_and_posterior_comparison_complete', mode=MODE,
                  full_population=records, aggregate=aggregate, generated_PCM_identical=True,
                  generated_only=True, labels_read=False, model_started=True, GPU_started=False,
                  audio_device_opened=False, product_configuration_changed=False,
                  musical_accuracy_qualified=False, original_training_dependencies_reproduced=False,
                  original_framework_compatibility_qualified=False)
    with output.open('x') as stream:
        stream.write(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(status=result['status'], aggregate=aggregate)))


if __name__ == '__main__':
    main()
