"""Retain verified text evidence without audio or unrelated host processes."""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
CASE = BASE / 'cases/candidate'
DEST = ROOT / 'docs/benchmarks/data/m2-runtime-thread-waits-2026-10-26'
STAGE = BASE / 'archive-stage-01'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def filtered_host(row):
    value = dict(row)
    if 'process_cpu_read_only' in value:
        cpu = dict(value['process_cpu_read_only'])
        omitted = cpu.pop('processes')
        cpu['unrelated_process_inventory_omitted'] = True
        cpu['omitted_process_inventory_rows'] = len(omitted)
        value['process_cpu_read_only'] = cpu
    return value


def main():
    DEST.mkdir(exist_ok=False)
    STAGE.mkdir(exist_ok=False)
    entries = []
    selected = {
        'results.json': BASE / 'results-01.json',
        'wait-results.json': BASE / 'wait-results-01.json',
        'analyze_results.py': BASE / 'analyze_results.py',
        'analyze_waits.py': BASE / 'analyze_waits.py',
        'archive_results.py': Path(__file__).resolve(),
        'capability.json': BASE / 'capability-01.json',
        'build-attestation.json': BASE / 'root-source-build-attestation-01.json',
        'build-receipt.json': BASE / 'root-build-receipt-01.json',
        'offline-checks.log': BASE / 'offline-checks-01.log',
        'natural-guard-checks.log': BASE / 'natural-guard-checks-01.log',
        'wait-checks-red.log': BASE / 'new-wait-checks-red-01.log',
        'wait-checks-green.log': BASE / 'new-wait-checks-green-01.log',
        'file-verification.log': BASE / 'file-verification-01.log',
        'root-launcher.py': BASE / 'launch_case.py',
    }
    for name in ('plan.json', 'readiness.json', 'root-launch-plan-01.json',
                 'root-launch-clearance-01.json', 'root-single-entry-check-01.json',
                 'root-unit-dispatch-01.json', 'dispatch-01.json',
                 'admission-01.json', 'diagnostic-assessment.json', 'root-finished-01.json',
                 'run_host_player.py', 'run_player_owned.py', 'close_case.py', 'test_thread_wait.py'):
        selected[name] = CASE / name
    for name in ('native-result.json', 'native.stdout.log', 'native.stderr.log', 'observations.jsonl'):
        selected[name] = CASE / 'output-01' / name
    for name, path in selected.items():
        raw = path.read_bytes()
        raw.decode('utf-8')
        (STAGE / name).write_bytes(raw)
        packed = gzip.compress(raw, mtime=0)
        assert gzip.decompress(packed) == raw
        target = DEST / (name + '.gz')
        target.write_bytes(packed)
        entries.append(dict(file=target.name, bytes=len(packed), sha256=digest(packed),
            text_bytes=len(raw), text_sha256=digest(raw), original_path=str(path), filtered=False))
    result_path = CASE / 'output-01/result.json'
    result = json.loads(result_path.read_text())
    for key in ('host_before', 'host_after'):
        result[key] = filtered_host(result[key])
    host_path = CASE / 'output-01/host-observations.jsonl'
    hosts = [filtered_host(json.loads(line)) for line in host_path.read_text().splitlines()]
    filtered = {
        'wrapper-result-filtered.json': (result_path, (json.dumps(result, indent=2, allow_nan=False) + '\n').encode()),
        'host-task-observations-filtered.jsonl': (host_path, ''.join(json.dumps(r, allow_nan=False) + '\n' for r in hosts).encode()),
    }
    for name, (path, raw) in filtered.items():
        original = path.read_bytes()
        packed = gzip.compress(raw, mtime=0)
        assert gzip.decompress(packed) == raw
        (STAGE / name).write_bytes(raw)
        target = DEST / (name + '.gz')
        target.write_bytes(packed)
        entries.append(dict(file=target.name, bytes=len(packed), sha256=digest(packed),
            text_bytes=len(raw), text_sha256=digest(raw), original_path=str(path),
            original_bytes=len(original), original_sha256=digest(original), filtered=True,
            filter='Remove only process_cpu_read_only.processes and retain omission counts; exact player/runtime tasks, observer costs, thermal and power observations remain.'))
    manifest = dict(schema=1, source='303cf6209c3573ff74cc5fad2c5852ea85246e2b',
        measured_wall_ms=120016, service_p99_ms=8810.37350994302, strict_target_ms=4095,
        native_passed=False, wrapper_passed=False, qualified=False, original_failures_retained=True,
        independently_closed=True, exact_runqueue_wait_measured=False,
        quality='Best', power_ceiling_W=15, thermal_guard_unchanged=True,
        entries=entries, compressed_text_files=len(entries),
        compressed_bytes=sum(r['bytes'] for r in entries),
        exclusions=['Audio', 'Models', 'Binaries', 'Driver caches', 'Unrelated host process inventories'],
        scope='Read-only diagnostic, not timing qualification, improvement proof, sustained qualification or a gate waiver.')
    (DEST / 'verification.json').write_text(json.dumps(manifest, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: manifest[k] for k in ('compressed_text_files', 'compressed_bytes', 'qualified')}))


if __name__ == '__main__':
    main()
