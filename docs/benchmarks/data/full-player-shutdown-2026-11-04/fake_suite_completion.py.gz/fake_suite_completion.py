"""CPU-only real-Main.qml lifecycle cases, never a model/GPU qualification."""
from pathlib import Path
import array,hashlib,json,os,subprocess,sys,wave,time

B=Path(__file__).resolve().parent
FAKE=r'''# CONFLUX CPU-only native fixture
import argparse,json,os,pathlib,signal,sys,time
p=argparse.ArgumentParser();p.add_argument('--model');p.add_argument('--backend');p.add_argument('--threads',type=int);a=p.parse_args()
signal.signal(signal.SIGTERM,signal.SIG_IGN)
print(json.dumps(dict(event='ready',sample_rate=44100,channels=2,segment_frames=343980,stems=['drums','bass','other','vocals'],pid=os.getpid(),backend=a.backend,threads=a.threads,revision='0'*40,weight_storage='native',fence_wait_mode='blocking')),flush=True)
for line in sys.stdin:
 q=json.loads(line);data=pathlib.Path(q['input']).read_bytes();assert len(data)==343980*2*4
 log=pathlib.Path(os.environ['CONFLUX_FENCE_TRACE_FILE']);pid=os.getpid()+(1 if MODE=='foreign-pid'else 0);ns=1 if MODE=='stale-fence'else time.monotonic_ns()
 text=f'U {pid} 1 {ns} graph\n'
 if MODE=='completed-fence':text+=f'D {pid} 1 {ns+1} graph\n'
 if MODE=='no-fence':text=''
 if MODE=='output-started':pathlib.Path(q['output']).write_bytes(b'')
 with log.open('a')as f:f.write(text)
 def finish(number,frame):
  with log.open('a')as f:f.write(f'D {os.getpid()} 1 {time.monotonic_ns()} graph\n')
  raise SystemExit(0)
 signal.signal(signal.SIGTERM,finish)
 while True:time.sleep(.01)
'''

def pin(p):
 p=Path(p)
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h)

def main():
 source=Path(sys.argv[1]).resolve(strict=True);player=Path(sys.argv[2]).resolve(strict=True);out=Path(sys.argv[3]).absolute();out.mkdir(mode=0o700)
 python=Path(sys.argv[4]).resolve(strict=True)
 rows=[]
 for mode in('complete-on-stop',):
  case=out/mode;case.mkdir(mode=0o700);runtime=case/'native.py';runtime.write_text('#!'+str(python)+'\nMODE='+repr(mode)+'\n'+FAKE);runtime.chmod(0o700)
  model=case/'model.fixture';model.write_bytes(b'CONFLUX CPU-only model placeholder; no inference library is imported\n')
  track=case/'silent.wav'
  with wave.open(str(track),'wb')as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(48000);f.writeframes(array.array('h',[0])*(12*48000*2))
  paths={'player':player,'python':python,'runtime':runtime,'model':model,'track':track}
  paths.update({k:source/'tools/stems'/n for k,n in(('exporter','export.py'),('worker','worker.py'),('service','service.py'))})
  cfg=dict(fake_native=True,backend='cpu',source_root=str(source),source_head='9e35bda2eeb75c54630b392a9b631d3fca212684',observation_seconds=8,pins={k:pin(p)for k,p in paths.items()})
  config=case/'config.json';config.write_text(json.dumps(cfg,indent=2)+'\n');env=os.environ.copy();env['CONFLUX_PLAYER_FENCE_CONFIG']=str(config)
  command=[str(python),'-B',str(B/'private_routing_check.py'),str(B/'probe_driver.py'),str(case/'evidence')]
  began=time.monotonic()
  with(case/'owner.stdout.log').open('x')as stdout,(case/'owner.stderr.log').open('x')as stderr:r=subprocess.run(command,env=env,stdout=stdout,stderr=stderr,timeout=40)
  report_path=case/'evidence/recordings/player-fence/result.json'
  report=json.loads(report_path.read_text())if report_path.is_file()else{}
  expected=mode=='complete-on-stop';match=(r.returncode==0)==expected and report.get('passed')is expected
  if report:
   match=match and report.get('app_reaped')is True and report.get('native_inputs_remaining')==[]and not report.get('fallback_cleanup_used')and report.get('actual_GPU_wait_observed')is False
   match=match and report.get('completion_mode')=='completed during cancellation'
   app=report.get('app_report',{});match=match and app.get('controller_shutdown_returned')is True and app.get('source_frames_after_shutdown')==0
  else:match=False
  row=dict(mode=mode,expected_pass=expected,exit=r.returncode,matched_expected=match,seconds=time.monotonic()-began,result=report)
  rows.append(row)
  with(case/'case-result.json').open('x')as f:json.dump(row,f,indent=2);f.write('\n')
  print(json.dumps({k:row[k]for k in('mode','exit','matched_expected','seconds')}),flush=True)
  if not match:break
 result=dict(all_passed=len(rows)==1 and all(x['matched_expected']for x in rows),cases=rows,model_GPU_physical_audio_or_visible_UI_started=False)
 with(out/'result.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 return 0 if result['all_passed']else 1

if __name__=='__main__':raise SystemExit(main())
