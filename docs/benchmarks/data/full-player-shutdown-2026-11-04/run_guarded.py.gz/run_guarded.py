#!/usr/bin/env python3
"""Dry-by-default owner for one native cancellation observation, without audio."""
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import signal
import stat
import subprocess
import sys
import threading
import time

MODE = 'm2-player-fence-close-20261031-01'
OPERATOR_SECONDS = 300


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def pin(path):
    path = Path(path)
    require(path.is_absolute(), 'Absolute file paths required')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'Regular nonsymlink file required: ' + str(path))
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.lstat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'File changed while hashing')
    return dict(path=str(path), bytes=before.st_size, sha256=digest)


def save_new(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def load(name, row):
    require(pin(row['path']) == row, 'Import changed: ' + name)
    spec = importlib.util.spec_from_file_location(name, row['path'])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify(plan):
    require(plan['schema'] == 1 and plan['mode'] == MODE and plan['host'] in ('laptop', 'apollo'), 'Wrong plan')
    require(plan['operator_seconds'] == OPERATOR_SECONDS and plan['probe_seconds'] == 40 and
            plan['requests'] == 1 and plan['retries'] is False and plan['latency_qualification'] is False,
            'Workload or budget differs')
    for row in plan['pins'].values():
        require(pin(row['path']) == row, 'Frozen input changed: ' + row['path'])
    source = Path(plan['source_root'])
    require(source.is_absolute() and Path(plan['pins']['worker']['path']) == source / 'tools/stems/worker.py',
            'Wrong source closure')
    require(Path(sys.executable).resolve() == Path(plan['pins']['python']['path']) and
            platform.python_version() == plan['python_version'] and
            importlib.metadata.version('numpy') == plan['numpy_version'], 'Interpreter or NumPy version changed')
    require(not any(name.startswith(('GGML_VK_', 'GGML_VULKAN_', 'MESA_', 'INTEL_DEBUG',
                                   'CONFLUX_DRM_', 'CONFLUX_REQUEST_TRACE_')) for name in os.environ),
            'Inherited GPU experiment switch')


def validate_human(human, plan_hash, now_utc, now_mono):
    require(type(human) is dict, 'Human readiness must be an object')
    original = datetime.fromisoformat(human['original_readiness_utc'])
    require(original.tzinfo is not None, 'Readiness needs a timezone')
    age = (now_utc - original).total_seconds()
    deadline = human['deadline_monotonic']
    require(type(deadline) in (float, int) and math.isfinite(deadline), 'Invalid deadline')
    require(human['schema'] == 1 and human['mode'] == MODE and human['plan_sha256'] == plan_hash and
            human['operator_seconds'] == OPERATOR_SECONDS and 0 <= age <= 90 and
            200 <= deadline - now_mono <= OPERATOR_SECONDS - age + 2 and
            human.get('physical_conditions_confirmed') is True and
            all(human.get(key) is True for key in ('AC_power', 'lid_open', 'Codex_minimized',
                'other_work_paused', 'CONFLUX_closed', 'no_suspend')) and
            all(type(human.get(key)) is str and 0 < len(human[key]) <= 8192 for key in
                ('question_item_id', 'human_question', 'human_reply')), 'Fresh physical readiness required')
    return deadline


def check_caps(values, ceilings):
    require(values.keys() == ceilings.keys(), 'Cap fields changed')
    for name, limit in ceilings.items():
        value = values[name]
        require(type(value) is int and value > 0 and
                (value <= limit if name.endswith('_power_limit_uw') else value == limit),
                'Power ceiling or time window differs: ' + name)


def snapshot(reader, sensors, guard, plan):
    row = reader.observation(sensors)
    row['power'] = reader.power_state()
    row['caps'] = {name: int(Path(name).read_text()) for name in plan['cap_ceilings']}
    check_caps(row['caps'], plan['cap_ceilings'])
    require(not row['read_errors'] and row['power']['ac_online'] and row['power']['lid_open'],
            'AC, lid or read-only sensor state changed')
    require(row['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'] in ('balanced', 'low-power'),
            'Performance mode is outside this diagnostic')
    require(reader.process_identity(guard['process']['pid']) == guard['process'], 'Active guard identity changed')
    require(reader.pin(Path(plan['pins']['guard_script']['path'])) == plan['pins']['guard_script'] and
            reader.pin(Path(plan['pins']['guard_unit']['path'])) == plan['pins']['guard_unit'], 'Guard files changed')
    require(max(row['temperatures_millidegrees_C'].values()) < 95000, 'Critical temperature observed')
    return row


def group_absent(pid):
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return True
    return False


def reap_probe(process):
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=2)
    if not group_absent(process.pid):
        # The core was launched in this owner's new session. A live group keeps
        # its identity reserved after its leader exits; no unrelated group is adopted.
        os.killpg(process.pid, signal.SIGKILL)
        until = time.monotonic() + 2
        while not group_absent(process.pid) and time.monotonic() < until:
            time.sleep(.01)
    require(group_absent(process.pid), 'Owned probe session still contains members')


def run(plan_path, *, live=False):
    plan_path = Path(plan_path)
    plan = json.loads(plan_path.read_text())
    if not live:
        verify(plan)
        return dict(verified=True, unarmed=True, model_started=False)
    # Missing or declined readiness must stop before output, host queries or imports.
    human = json.loads(Path(plan['readiness']).read_text())
    started = time.monotonic()
    deadline = validate_human(human, pin(plan_path)['sha256'], datetime.now(timezone.utc), started)
    output = Path(plan['output'])
    output.mkdir(mode=0o700)
    report = dict(schema=1, host=plan['host'], mode=MODE, passed=False, cleanup_complete=False,
                  latency_qualified=False, GPU_fence_preemption_proven=False,
                  full_player_shutdown_observed=False, errors=[], probe_dispatched=False,
                  original_readiness_utc=human['original_readiness_utc'], operator_deadline_monotonic=deadline,
                  context=dict(hostname=platform.node(), python=platform.python_version(),
                      numpy=importlib.metadata.version('numpy'), pid=os.getpid(),
                      boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                      namespaces={name: os.readlink('/proc/self/ns/' + name) for name in ('pid', 'mnt', 'user')},
                      cgroup=Path('/proc/self/cgroup').read_text().splitlines()))
    process = monitor = None
    stop, failed = threading.Event(), threading.Event()
    handlers = {}
    def interrupted(number, _frame):
        raise InterruptedError('Owned cancellation diagnostic signal ' + str(number))
    for number in (signal.SIGALRM, signal.SIGTERM, signal.SIGINT):
        handlers[number] = signal.signal(number, interrupted)
    signal.setitimer(signal.ITIMER_REAL, max(.1, deadline - time.monotonic() - 30))
    try:
        verify(plan)
        core = load('cancel_core', plan['pins']['core'])
        if plan['host'] == 'laptop':
            reader = load('cancel_host_reader', plan['pins']['host_reader'])
            guard = reader.guard_identity(Path(plan['pins']['guard_script']['path']), Path(plan['pins']['guard_unit']['path']))
            sensors = reader.sensor_paths()
            report['guard_before'] = guard
            require(guard['script'] == plan['pins']['guard_script'] and guard['unit'] == plan['pins']['guard_unit'], 'Guard pin changed')
            cool_deadline = min(started + 165, deadline - 90)
            since = None
            with (output / 'settling.jsonl').open('x') as log:
                while time.monotonic() < cool_deadline:
                    row = snapshot(reader, sensors, guard, plan)
                    now = time.monotonic()
                    log.write(json.dumps(row) + '\n'); log.flush()
                    cool = max(row['temperatures_millidegrees_C'].values()) <= 70000
                    since = (now if since is None else since) if cool else None
                    if since is not None and now - since >= 60:
                        break
                    time.sleep(min(2, max(0, cool_deadline - now)))
                else:
                    raise TimeoutError('Bounded 60-second settling interval at or below 70C not reached')
            def observe():
                try:
                    with (output / 'host-observations.jsonl').open('x') as log:
                        while not stop.is_set():
                            log.write(json.dumps(snapshot(reader, sensors, guard, plan)) + '\n'); log.flush()
                            stop.wait(2)
                except BaseException as error:
                    report['errors'].append(dict(phase='host_observation', error=str(error)))
                    failed.set()
            monitor = threading.Thread(target=observe, name='cancel-host-observer', daemon=True)
            monitor.start()
        require(deadline - time.monotonic() >= 90, 'Insufficient original probe/cleanup budget')
        require(not failed.is_set(), 'Host observation failed before dispatch')
        config_path = Path(plan['config'])
        require(pin(config_path) == plan['pins']['config'], 'Player configuration changed')
        config = json.loads(config_path.read_text())
        require(config['fake_native'] is False and config['backend'] == 'vulkan' and
                config['hardware_readiness'] == plan['readiness'], 'Live player configuration differs')
        args = [plan['pins']['python']['path'], '-B', plan['pins']['virtual_wrapper']['path'],
                plan['pins']['core']['path'], str(output / 'probe')]
        environment = os.environ.copy()
        environment['CONFLUX_PLAYER_FENCE_CONFIG'] = str(config_path)
        environment['PYTHONDONTWRITEBYTECODE'] = '1'
        with (output / 'probe.stdout').open('x') as out, (output / 'probe.stderr').open('x') as err:
            process = subprocess.Popen(args, start_new_session=True, stdout=out, stderr=err, env=environment)
            report['probe_dispatched'] = True
            report['probe_identity'] = core.identity(process.pid)
            require(report['probe_identity']['group'] == process.pid and os.getsid(process.pid) == process.pid,
                    'Probe session ownership differs')
            wait_deadline = min(time.monotonic() + 65, deadline - 25)
            while process.poll() is None:
                require(not failed.is_set(), 'Host observation failed during request')
                require(time.monotonic() < wait_deadline, 'Probe exceeded its original budget')
                time.sleep(.01)
            report['probe_returncode'] = process.wait(timeout=1)
        result_path = output / 'probe/recordings/player-fence/result.json'
        daemon_path = output / 'probe/result.json'
        require(result_path.stat().st_size <= 256 * 1024 and daemon_path.stat().st_size <= 256 * 1024,
                'Oversized shutdown observation')
        result = json.loads(result_path.read_text())
        daemon = json.loads(daemon_path.read_text())
        report['native'] = result
        report['private_daemon'] = {key: daemon[key] for key in
            ('passed', 'check_exit', 'cleanup', 'daemon_reaped')}
        require(report['probe_returncode'] == 0 and result['passed'] is True and
                result['fake_native'] is False and result['actual_GPU_wait_observed'] is True and
                result['qualified'] is False and result['app_reaped'] is True and
                result['native_reaped'] is True and result['native_spool_removed'] is True and
                result['native_pidfd_readable'] is True and result['native_inputs_remaining'] == [] and
                result['fallback_cleanup_used'] is False and result['partial_source_installed'] is False and
                result['app_report']['controller_shutdown_returned'] is True,
                'Real player shutdown or exact cleanup unproven')
        require(daemon['passed'] is True and daemon['check_exit'] == 0 and daemon['daemon_reaped'] is True and
                daemon['cleanup']['remaining_nodes_or_links'] == [], 'Private daemon cleanup unproven')
        report['full_player_shutdown_observed'] = True
        report['passed'] = True
    except BaseException as error:
        report['errors'].append(dict(phase='run', error=type(error).__name__ + ': ' + str(error)))
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        stop.set()
        try:
            if process is not None:
                reap_probe(process)
        except BaseException as error:
            report['errors'].append(dict(phase='probe_cleanup', error=str(error)))
        try:
            if monitor is not None:
                monitor.join(timeout=8)
                require(not monitor.is_alive(), 'Host observer still running')
                report['host_final'] = snapshot(reader, sensors, guard, plan)
            report['cleanup_complete'] = process is None or group_absent(process.pid)
        except BaseException as error:
            report['errors'].append(dict(phase='cleanup', error=str(error)))
        report['passed'] = report['passed'] and report['cleanup_complete'] and not report['errors']
        for number, handler in handlers.items():
            signal.signal(number, handler)
        save_new(output / 'result.json', report)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True, type=Path)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    result = run(args.plan, live=args.run)
    print(json.dumps({key: result[key] for key in ('verified', 'unarmed', 'passed', 'cleanup_complete', 'errors') if key in result}))
    raise SystemExit(0 if result.get('verified') or result.get('passed') else 1)
