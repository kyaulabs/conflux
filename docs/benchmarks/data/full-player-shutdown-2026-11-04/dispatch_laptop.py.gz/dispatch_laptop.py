#!/usr/bin/env python3
"""Unarmed by default; one laptop retry with the existing readiness/deadline rules."""
import argparse,json,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
import run_guarded as driver
BASE=Path(__file__).resolve().parent
UNIT='conflux-player-fence-close-laptop-20261104-01.service'
CONDITIONS=('AC_power','lid_open','Codex_minimized','other_work_paused','CONFLUX_closed','no_suspend')

def verify():
 plan=json.loads((BASE/'laptop-plan.json').read_text());driver.verify(plan)
 driver.require(not any((BASE/n).exists() for n in ('readiness.json','launch-reservation.json','unit-dispatch.json','output-01','unit.stdout.log','unit.stderr.log','desktop-owner-result.json')),'Earlier attempt already owns this packet')
 return plan

def command(remaining):
 driver.require(200<=remaining<=300,'Insufficient original dispatch/cleanup budget')
 task=BASE.parent
 args=['systemd-run','--user','--unit='+UNIT,'--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no','--property=RuntimeMaxSec='+str(int(remaining)-45)+'s','--property=TimeoutStopSec=15s','--property=KillMode=control-group','--property=MemoryMax=8G','--property=TasksMax=256','--property=UMask=0077','--property=WorkingDirectory='+str(task),'--property=StandardOutput=append:'+str(BASE/'unit.stdout.log'),'--property=StandardError=append:'+str(BASE/'unit.stderr.log')]
 for key,leaf in [('TMPDIR','t'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data'),('XDG_STATE_HOME','state'),('XDG_CONFIG_HOME','config')]:args.append('--setenv='+key+'='+str(task/leaf))
 return args+['/usr/bin/python3.14','-B',str(BASE/'desktop_entry.py'),'--plan',str(BASE/'laptop-plan.json')]

def main():
 parser=argparse.ArgumentParser(description=__doc__);mode=parser.add_mutually_exclusive_group();mode.add_argument('--launch',action='store_true');mode.add_argument('--verify',action='store_true');args=parser.parse_args()
 if not args.launch:
  verify();print(json.dumps(dict(verified=True,unarmed=True,hardware_started=False)));return 0
 raw=sys.stdin.read(32769);driver.require(len(raw)<=32768,'Oversized human reply');reply=json.loads(raw)
 driver.require(reply.get('physical_conditions_confirmed')is True and all(reply.get(k)is True for k in CONDITIONS) and all(type(reply.get(k))is str and 0<len(reply[k])<=8192 for k in ('question_item_id','human_question','human_reply')),'Fresh physical readiness required')
 started=time.monotonic();utc=datetime.now(timezone.utc).isoformat();plan=verify()
 state=subprocess.run(['systemctl','--user','show',UNIT,'--property=LoadState,MainPID'],capture_output=True,text=True,timeout=5)
 fields=dict(line.split('=',1) for line in state.stdout.splitlines() if '=' in line)
 driver.require(state.returncode==0 and fields.get('LoadState')=='not-found' and fields.get('MainPID')=='0','Test unit already exists or manager query failed')
 human=dict(schema=1,mode=driver.MODE,operator_seconds=300,original_readiness_utc=utc,original_monotonic=started,deadline_monotonic=started+300,plan_sha256=driver.pin(BASE/'laptop-plan.json')['sha256'],**reply)
 driver.validate_human(human,human['plan_sha256'],datetime.now(timezone.utc),time.monotonic())
 driver.require(time.monotonic()-started<45,'Readiness dispatch window expired')
 driver.save_new(BASE/'readiness.json',human);driver.save_new(BASE/'launch-reservation.json',dict(original_readiness_utc=utc,original_monotonic=started,deadline_monotonic=started+300,retries=False))
 argv=command(started+300-time.monotonic());receipt=dict(unit=UNIT,command=argv,original_readiness_utc=utc,operator_deadline_monotonic=started+300,retries=False,Apollo_rerun=False)
 try:
  result=subprocess.run(argv,capture_output=True,text=True,timeout=15);receipt.update(exit=result.returncode,stdout=result.stdout,stderr=result.stderr)
 except BaseException as error:receipt.update(error=str(error),outcome_requires_unit_observation=True)
 driver.save_new(BASE/'unit-dispatch.json',receipt);print(json.dumps(receipt));return 0 if receipt.get('exit')==0 else 1

if __name__=='__main__':raise SystemExit(main())
