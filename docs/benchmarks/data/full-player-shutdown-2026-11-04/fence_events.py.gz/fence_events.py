"""Bounded parser for the private unsignaled-fence wait capture."""
import os,stat
from pathlib import Path

LIMIT=65536
class FenceEvents:
    def __init__(self,path):
        self.path=Path(path)
        self.fd=os.open(self.path,os.O_CREAT|os.O_EXCL|os.O_RDWR|os.O_CLOEXEC,0o600)
        self.identity=os.fstat(self.fd)
    def close(self):
        if self.fd>=0:os.close(self.fd);self.fd=-1
    def read(self,pid,*,final=False):
        s=os.fstat(self.fd)
        if (s.st_dev,s.st_ino)!=(self.identity.st_dev,self.identity.st_ino)or not stat.S_ISREG(s.st_mode)or s.st_uid!=os.getuid()or s.st_mode&0o777!=0o600 or s.st_size>LIMIT:
            raise ValueError('fence trace identity, permissions or extent differs')
        raw=os.pread(self.fd,LIMIT+1,0)
        if len(raw)>LIMIT:raise ValueError('fence trace exceeds bound')
        if raw and not raw.endswith(b'\n'):
            if final:raise ValueError('final fence trace has a partial event')
            raw=raw[:raw.rfind(b'\n')+1]
        began={};completed={}
        for line in raw.splitlines():
            fields=line.decode('ascii').split()
            if len(fields)!=5:raise ValueError('invalid fence trace event')
            event,owner,sequence,ns,kind=fields
            if event not in('U','D')or kind not in('graph','almost_ready')or not all(v.isascii()and v.isdecimal()for v in(owner,sequence,ns)):
                raise ValueError('invalid fence trace fields')
            owner,sequence,ns=map(int,(owner,sequence,ns))
            if owner!=pid or sequence<=0 or ns<=0:raise ValueError('fence trace PID, sequence or clock differs')
            row=dict(pid=owner,sequence=sequence,monotonic_ns=ns,kind=kind)
            if event=='U':
                if sequence in began:raise ValueError('duplicate unsignaled fence event')
                began[sequence]=row
            else:
                start=began.get(sequence)
                if not start or sequence in completed or kind!=start['kind']or ns<start['monotonic_ns']:
                    raise ValueError('invalid fence completion event')
                completed[sequence]=row
        return began,completed
