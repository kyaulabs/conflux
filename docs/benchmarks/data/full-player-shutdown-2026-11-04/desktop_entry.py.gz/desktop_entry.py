#!/usr/bin/env python3
"""Preserve the test outcome across KDE's exit-status-masking inhibitor."""
import argparse
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True, type=Path)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    output = Path(plan['output'])
    receipt = args.plan.parent / 'desktop-owner-result.json'
    if output.exists() or receipt.exists():
        raise RuntimeError('An earlier attempt already owns this output')
    command = ['/usr/bin/kde-inhibit', '--power', sys.executable, '-B',
               plan['pins']['driver']['path'], '--plan', str(args.plan), '--run']
    child = subprocess.run(command)
    report = dict(inhibitor_exit=child.returncode, test_passed=False,
                  cleanup_complete=False, errors=[])
    try:
        result_path = output / 'result.json'
        if result_path.stat().st_size > 256 * 1024:
            raise RuntimeError('Oversized test result')
        result = json.loads(result_path.read_text())
        report['test_passed'] = result['passed'] is True
        report['cleanup_complete'] = result['cleanup_complete'] is True
        report['errors'] = result['errors']
    except (OSError, ValueError, KeyError) as error:
        report['errors'] = [type(error).__name__ + ': ' + str(error)]
    passed = (child.returncode == 0 and report['test_passed'] and
              report['cleanup_complete'] and not report['errors'])
    report['exit'] = 0 if passed else 1
    with receipt.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(report))
    return report['exit']


if __name__ == '__main__':
    raise SystemExit(main())
