#!/usr/bin/env python3
"""Offline admission/ownership fixtures; never dispatch systemd, SSH or Docker."""
from datetime import datetime, timedelta, timezone
import copy
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

BASE = Path(__file__).resolve().parent
OUT = BASE / 'offline-packet-02'


def module(name):
    spec = importlib.util.spec_from_file_location('cancel_test_' + name, BASE / (name + '.py'))
    value = importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value


runner, launcher, owner, desktop = (module(name) for name in
                                  ('run_guarded', 'launch_both', 'apollo_owner', 'desktop_entry'))


def human(plan_hash='a'*64):
    return dict(schema=1, mode=runner.MODE, operator_seconds=300,
        original_readiness_utc=datetime.now(timezone.utc).isoformat(), deadline_monotonic=runner.time.monotonic()+300,
        plan_sha256=plan_hash, physical_conditions_confirmed=True, AC_power=True, lid_open=True,
        Codex_minimized=True, other_work_paused=True, CONFLUX_closed=True, no_suspend=True,
        question_item_id='OFFLINE-FIXTURE', human_question='Fixture only; no hardware permission.',
        human_reply='Fixture only; no real model or GPU.')


class PacketBehavior(unittest.TestCase):
    def directory(self):
        path = OUT / self._testMethodName
        path.mkdir(mode=0o700)
        return path

    def test_dry_runner_has_no_host_or_process_operations(self):
        root = self.directory();path = root/'plan.json';path.write_text('{}')
        with patch.object(runner, 'verify'), patch.object(runner, 'load') as load, \
             patch.object(runner.subprocess, 'Popen') as process, patch.object(runner, 'snapshot') as snapshot:
            result = runner.run(path)
        self.assertTrue(result['unarmed'])
        load.assert_not_called();process.assert_not_called();snapshot.assert_not_called()

    def test_declined_readiness_precedes_host_query_import_or_output(self):
        root = self.directory();path = root/'plan.json';ready = root/'readiness.json'
        plan = dict(readiness=str(ready), output=str(root/'output'))
        path.write_text(json.dumps(plan))
        value = human(runner.pin(path)['sha256']);value['physical_conditions_confirmed'] = False
        ready.write_text(json.dumps(value))
        with patch.object(runner, 'verify') as verify, patch.object(runner, 'load') as load, \
             patch.object(runner.subprocess, 'Popen') as process:
            with self.assertRaisesRegex(RuntimeError, 'Fresh physical readiness'):
                runner.run(path, live=True)
        verify.assert_not_called();load.assert_not_called();process.assert_not_called()
        self.assertFalse((root/'output').exists())

    def test_stale_changed_or_partial_readiness_is_refused(self):
        value = human();now = runner.time.monotonic();utc = datetime.now(timezone.utc)
        for change in ({'original_readiness_utc':(utc-timedelta(seconds=91)).isoformat()},
                       {'plan_sha256':'b'*64}, {'deadline_monotonic':now+400}, {'AC_power':1},
                       {'lid_open':False}, {'human_reply':''}, {'operator_seconds':4380}):
            with self.subTest(change=change):
                altered = dict(value, **change)
                with self.assertRaises(RuntimeError):runner.validate_human(altered, 'a'*64, utc, now)
        self.assertEqual(runner.validate_human(value,'a'*64,utc,now),value['deadline_monotonic'])

    def test_launcher_decline_precedes_host_state_or_dispatch(self):
        reply = human();reply['physical_conditions_confirmed'] = False
        with patch.object(launcher, 'verify', return_value={}), patch.object(sys,'argv',['launch','--launch']), \
             patch.object(sys,'stdin',io.StringIO(json.dumps(reply))), patch.object(launcher.subprocess,'check_output') as query, \
             patch.object(launcher.subprocess,'run') as dispatch:
            with self.assertRaisesRegex(RuntimeError,'Fresh physical readiness'):launcher.main()
        query.assert_not_called();dispatch.assert_not_called()

    def test_launcher_dry_mode_never_dispatches(self):
        with patch.object(launcher,'verify',return_value={}), patch.object(sys,'argv',['launch']), \
             patch.object(launcher.subprocess,'run') as dispatch, patch.object(launcher.subprocess,'check_output') as query, \
             patch.object(sys,'stdout',io.StringIO()):
            self.assertEqual(launcher.main(),0)
        dispatch.assert_not_called();query.assert_not_called()

    def desktop_case(self, result, *, inhibitor_exit=0):
        root=self.directory();output=root/'output';path=root/'plan.json'
        path.write_text(json.dumps(dict(output=str(output),pins={'driver':{'path':'/fixture/driver.py'}})))
        def child(command):
            self.assertEqual(command[:2],['/usr/bin/kde-inhibit','--power'])
            output.mkdir()
            if result is not None:(output/'result.json').write_text(json.dumps(result))
            return SimpleNamespace(returncode=inhibitor_exit)
        with patch.object(sys,'argv',['desktop','--plan',str(path)]), \
             patch.object(desktop.subprocess,'run',side_effect=child),patch.object(sys,'stdout',io.StringIO()):
            code=desktop.main()
        return code,json.loads((root/'desktop-owner-result.json').read_text())

    def test_desktop_child_failure_is_not_masked_by_successful_inhibitor(self):
        code,result=self.desktop_case(dict(passed=False,cleanup_complete=True,errors=['fixture failure']))
        self.assertEqual(code,1);self.assertEqual(result['inhibitor_exit'],0)
        self.assertFalse(result['test_passed'])

    def test_desktop_missing_result_cannot_pass(self):
        code,result=self.desktop_case(None)
        self.assertEqual(code,1);self.assertTrue(result['errors'])

    def test_desktop_success_requires_clean_result_and_wrapper(self):
        code,result=self.desktop_case(dict(passed=True,cleanup_complete=True,errors=[]))
        self.assertEqual(code,0);self.assertTrue(result['test_passed'])

    def test_desktop_inhibitor_failure_cannot_pass(self):
        code,result=self.desktop_case(dict(passed=True,cleanup_complete=True,errors=[]),inhibitor_exit=7)
        self.assertEqual(code,1);self.assertEqual(result['inhibitor_exit'],7)

    def test_desktop_existing_output_is_not_adopted(self):
        root=self.directory();output=root/'output';output.mkdir();(output/'sentinel').write_text('retain')
        path=root/'plan.json';path.write_text(json.dumps(dict(output=str(output))))
        with patch.object(sys,'argv',['desktop','--plan',str(path)]),patch.object(desktop.subprocess,'run') as child:
            with self.assertRaisesRegex(RuntimeError,'earlier attempt'):desktop.main()
        child.assert_not_called();self.assertEqual((output/'sentinel').read_text(),'retain')

    def remote_fixture(self, root):
        remote=root/'remote';remote.mkdir(mode=0o700)
        binding=remote/'remote-binding.json';binding.write_text('{}')
        (remote/'apollo-plan.json').write_text('{}')
        return remote,runner.pin(binding)

    def test_positive_launch_submits_both_hosts_concurrently_without_resetting_time(self):
        root=self.directory();local=root/'local';local.mkdir(mode=0o700)
        (local/'laptop-plan.json').write_text('{}')
        remote,binding=self.remote_fixture(root)
        value=human()
        reply={key:value[key] for key in ('physical_conditions_confirmed',*launcher.CONDITIONS,
               'question_item_id','human_question','human_reply')}
        barrier=threading.Barrier(2);calls=[]
        def fake_run(command,**kw):
            calls.append(command)
            if command[0] in ('/usr/bin/ssh','systemd-run'):barrier.wait(timeout=2)
            if command[0]=='/usr/bin/ssh':exec(compile(kw['input'],'generated_remote_entry','exec'),{})
            return SimpleNamespace(returncode=0,stdout='',stderr='')
        before=runner.time.monotonic()
        with patch.object(launcher,'BASE',local),patch.object(launcher,'REMOTE',str(remote)), \
             patch.object(launcher,'verify',return_value={'remote_binding':binding}), \
             patch.object(sys,'argv',['launch','--launch']),patch.object(sys,'stdin',io.StringIO(json.dumps(reply))), \
             patch.object(launcher.subprocess,'check_output',return_value='LoadState=not-found\nMainPID=0'), \
             patch.object(launcher.subprocess,'run',side_effect=fake_run),patch.object(sys,'stdout',io.StringIO()):
            self.assertEqual(launcher.main(),0)
        receipt=json.loads((local/'both-dispatch.json').read_text())
        self.assertTrue(receipt['hosts_dispatched_concurrently'])
        self.assertLessEqual(receipt['operator_deadline_monotonic'],before+301)
        self.assertEqual({command[0] for command in calls},{'/usr/bin/ssh','systemd-run','sudo'})
        for command in calls:
            if command[0] in ('systemd-run','sudo'):
                runtime=next(int(word.split('=')[-1][:-1]) for word in command if word.startswith('--property=RuntimeMaxSec='))
                self.assertLessEqual(runtime,255)
                self.assertLess(runtime+15+20,300)

    def test_generated_remote_entry_keeps_the_original_delayed_deadline(self):
        root=self.directory();remote,binding=self.remote_fixture(root)
        value=human();value['original_readiness_utc']=(datetime.now(timezone.utc)-timedelta(seconds=45)).isoformat()
        with patch.object(launcher,'REMOTE',str(remote)):
            code=launcher.remote_script({'remote_binding':binding},value)
        with patch.object(subprocess,'check_output',return_value='LoadState=not-found\nMainPID=0'), \
             patch.object(subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='',stderr='')), \
             patch.object(sys,'stdout',io.StringIO()):
            exec(compile(code,'generated_remote_entry','exec'),{})
        receipt=json.loads((remote/'unit-dispatch.json').read_text())
        remaining=receipt['deadline_monotonic']-runner.time.monotonic()
        self.assertGreater(remaining,250);self.assertLessEqual(remaining,255)
        runtime=next(int(word.split('=')[-1][:-1]) for word in receipt['command'] if word.startswith('--property=RuntimeMaxSec='))
        self.assertLessEqual(runtime,210)
        self.assertLess(runtime+15+20,remaining+1)

    def test_generated_remote_entry_rejects_decline_before_host_query(self):
        root=self.directory();remote,binding=self.remote_fixture(root)
        value=human();value['physical_conditions_confirmed']=False
        with patch.object(launcher,'REMOTE',str(remote)):
            code=launcher.remote_script({'remote_binding':binding},value)
        with patch.object(subprocess,'check_output') as query,patch.object(subprocess,'run') as dispatch:
            with self.assertRaisesRegex(RuntimeError,'Physical readiness declined'):
                exec(compile(code,'generated_remote_entry','exec'),{})
        query.assert_not_called();dispatch.assert_not_called()
        self.assertFalse((remote/'readiness.json').exists())

    def test_lower_thermal_caps_are_accepted_but_increases_and_window_changes_fail(self):
        name='/fixture/constraint_0_power_limit_uw';window='/fixture/constraint_0_time_window_us'
        ceilings={name:15000000,window:27983872}
        runner.check_caps({name:7500000,window:27983872},ceilings)
        for values in ({name:25000000,window:27983872},{name:15000000,window:1}, {name:0,window:27983872}):
            with self.subTest(values=values):
                with self.assertRaises(RuntimeError):runner.check_caps(values,ceilings)

    def test_snapshot_rejects_critical_heat_power_lid_profile_and_guard_changes(self):
        root=self.directory();cap=root/'constraint_0_power_limit_uw';cap.write_text('15000000')
        proof={'pid':123,'start_ticks':456,'command':['fixture guard']}
        plan=dict(cap_ceilings={str(cap):15000000},pins={'guard_script':{'path':'/fixture/script'},'guard_unit':{'path':'/fixture/unit'}})
        row={'read_errors':{},'temperatures_millidegrees_C':{'fixture':69000},
             'profile_epp_read_only':{'/sys/firmware/acpi/platform_profile':'balanced'}}
        reader=SimpleNamespace(observation=lambda _:copy.deepcopy(row),power_state=lambda:{'ac_online':True,'lid_open':True},
            process_identity=lambda _:proof,pin=lambda p:plan['pins']['guard_script' if p.name=='script' else 'guard_unit'])
        runner.snapshot(reader,{'fixture':'CPU'},{'process':proof},plan)
        changes=[lambda:setattr(reader,'power_state',lambda:{'ac_online':False,'lid_open':True}),
                 lambda:setattr(reader,'power_state',lambda:{'ac_online':True,'lid_open':False}),
                 lambda:row['temperatures_millidegrees_C'].update(fixture=95000),
                 lambda:row['profile_epp_read_only'].update({'/sys/firmware/acpi/platform_profile':'performance'}),
                 lambda:setattr(reader,'process_identity',lambda _:dict(proof,start_ticks=999))]
        for change in changes:
            row['temperatures_millidegrees_C']['fixture']=69000
            row['profile_epp_read_only']['/sys/firmware/acpi/platform_profile']='balanced'
            reader.power_state=lambda:{'ac_online':True,'lid_open':True}
            reader.process_identity=lambda _:proof
            change()
            with self.assertRaises(RuntimeError):runner.snapshot(reader,{'fixture':'CPU'},{'process':proof},plan)

    def test_offline_container_has_no_GPU_and_uses_only_the_private_daemon(self):
        command=owner.command(Path('/fixture/results'),live=False)
        self.assertNotIn('--device',command)
        self.assertIn('--runtime=runc',command)
        self.assertIn('unix:///srv/conflux-tests/daemon/docker.sock',command)
        self.assertIn('--network=none',command)
        live=owner.command(Path('/fixture/results'),live=True)
        self.assertEqual(live[live.index('--device')+1],owner.GPU)

    def test_foreign_container_identity_is_never_removed(self):
        foreign={'Image':'foreign-image','Config':{'Labels':{'org.kyaulabs.conflux.run':owner.NAME}},'Id':'foreign'}
        with patch.object(owner.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout=json.dumps([foreign]))) as call:
            with self.assertRaisesRegex(RuntimeError,'refusing adoption'):owner.remove_owned(owner.NAME)
        self.assertEqual(call.call_count,1)
        self.assertNotIn('rm',call.call_args.args[0])

    def test_daemon_failure_is_not_container_absence(self):
        with patch.object(owner.subprocess,'run',return_value=SimpleNamespace(returncode=1,stdout='')), \
             patch.object(owner.subprocess,'check_output',side_effect=subprocess.CalledProcessError(1,['docker','ps'])):
            with self.assertRaises(subprocess.CalledProcessError):owner.remove_owned(owner.NAME)

    def test_remote_decline_precedes_Docker_and_asset_queries(self):
        root=self.directory();value=human();value['physical_conditions_confirmed']=False
        (root/'readiness.json').write_text(json.dumps(value))
        with patch.object(owner,'BASE',root),patch.object(sys,'argv',['owner','--run']), \
             patch.object(owner,'verify') as verify,patch.object(owner.subprocess,'check_output') as query:
            with self.assertRaisesRegex(RuntimeError,'Fresh current physical readiness'):owner.main()
        verify.assert_not_called();query.assert_not_called()


if __name__=='__main__':
    OUT.mkdir(mode=0o700)
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(PacketBehavior))
    (OUT/'verification.json').write_text(json.dumps(dict(tests=result.testsRun,failures=len(result.failures),
        errors=len(result.errors),passed=result.wasSuccessful(),actual_model_executed=False,
        GPU_used=False,systemd_SSH_or_Docker_dispatched=False,audio_or_UI_started=False),indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
