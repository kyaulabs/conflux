#!/usr/bin/env python3
"""Private real-window close diagnostic; the default entry cannot start a model."""
from pathlib import Path
import hashlib,json,os,select,signal,stat,subprocess,sys,time
from fence_events import FenceEvents


def identity(pid):
 fields=Path(f'/proc/{pid}/stat').read_text().rsplit(') ',1)[1].split()
 return dict(pid=pid,start_ticks=int(fields[19]),parent=int(fields[1]),group=int(fields[2]))

def owned_descendant(pid,app_pid):
 current=pid;chain=[]
 for _ in range(16):
  if current==app_pid:return chain
  value=identity(current);chain.append(value);current=value['parent']
  if current<=1:break
 raise ValueError('native marker is not an owned app descendant')

def pinned(row):
 p=Path(row['path']);s=p.lstat()
 if not p.is_absolute()or not stat.S_ISREG(s.st_mode)or s.st_size!=row['bytes']:raise ValueError('input type or extent differs')
 with p.open('rb')as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 if digest!=row['sha256']:raise ValueError('input digest differs')
 return p

def inputs(root):
 found=[];count=0
 for base in (root/'tmp',root/'cache'):
  for folder,dirs,files in os.walk(base,followlinks=False):
   count+=len(dirs)+len(files)
   if count>1024:raise ValueError('private input tree exceeds observation bound')
   for name in files:
    if name=='input.f32':
     p=Path(folder)/name;s=p.lstat()
     if not stat.S_ISREG(s.st_mode)or s.st_size<=0 or s.st_size%8:raise ValueError('private input extent/type differs')
     if p.parent.name=='native'and s.st_size!=343980*2*4:raise ValueError('native input extent differs')
     found.append(p)
 return found

def run():
 if len(sys.argv)!=3:raise ValueError('private daemon runtime and recording directory required')
 output=Path(sys.argv[2]).resolve(strict=True);job=output/'player-fence';job.mkdir(mode=0o700)
 config_path=Path(os.environ['CONFLUX_PLAYER_FENCE_CONFIG']);config=json.loads(config_path.read_text())
 source=Path(config['source_root']);asset={k:pinned(v)for k,v in config['pins'].items()}
 fake=config.get('fake_native')is True
 if fake:
  if config['backend']!='cpu'or b'CONFLUX CPU-only native fixture'not in asset['runtime'].read_bytes()[:512]or asset['model'].read_bytes()!=b'CONFLUX CPU-only model placeholder; no inference library is imported\n':
   raise ValueError('fake entry requires the explicit CPU-only native/model fixtures')
 else:
  # The guarded owner supplies this record only after fresh physical readiness.
  # No such record is made by the default or offline entry.
  human_path=Path(config['hardware_readiness']);human=json.loads(human_path.read_text())
  age=time.monotonic()-human['original_monotonic']
  if not(0<=age<=225 and human['deadline_monotonic']-time.monotonic()>75 and human['physical_conditions_confirmed']and human['question_item_id']and human['human_reply']and config['backend']=='vulkan'):
   raise ValueError('current guarded hardware readiness is missing or expired')
  for key in('AC_power','lid_open','other_work_paused','Codex_minimized','no_suspend'):
   if human.get(key)is not True:raise ValueError('physical condition absent: '+key)
 if not os.environ.get('PIPEWIRE_REMOTE','').startswith('conflux-private-routing-'):raise ValueError('isolated virtual PipeWire context required')
 for n in('tmp','cache','data','config'): (job/n).mkdir(mode=0o700)
 trace=FenceEvents(job/'fence-events.log');close_file=job/'close-request';cpp_report=job/'app-report.json'
 environment=os.environ.copy();environment.update(QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software',QT_QUICK_CONTROLS_STYLE='Basic',XDG_CACHE_HOME=str(job/'cache'),XDG_DATA_HOME=str(job/'data'),XDG_CONFIG_HOME=str(job/'config'),TMPDIR=str(job/'tmp'),CONFLUX_FENCE_TRACE_FILE=str(trace.path),PYTHONDONTWRITEBYTECODE='1')
 wait_seconds=config.get('observation_seconds',40)
 if not isinstance(wait_seconds,(int,float))or not .1<=wait_seconds<=40:raise ValueError('observation budget must be bounded')
 command=[str(asset['player']),'--stem-python',str(asset['python']),'--stem-exporter',str(asset['exporter']),'--stem-worker',str(asset['worker']),'--stem-service',str(asset['service']),'--stem-runtime',str(asset['runtime']),'--stem-model',str(asset['model']),'--stem-backend',config['backend'],'--stem-threads','2','--probe-track',str(asset['track']),'--probe-close-file',str(close_file),'--probe-report',str(cpp_report)]
 result=dict(schema=1,passed=False,qualified=False,fake_native=fake,actual_model_runtime_permitted=not fake,actual_GPU_wait_observed=False,scope='Actual Main.qml close, app.exec return and production controller shutdown while the first live load remains busy. Silent private virtual output; no musical, latency or sustained qualification.',command=command,events=[],fallback_cleanup_used=False)
 app=None;pidfd=None;native=None;pending=None;spools=[];failure=None
 try:
  with(job/'app.stdout.log').open('xb')as out,(job/'app.stderr.log').open('xb')as err:
   app=subprocess.Popen(command,stdout=out,stderr=err,env=environment,start_new_session=True)
  app_identity=identity(app.pid);result['app_identity']=app_identity
  until=time.monotonic()+wait_seconds
  while time.monotonic()<until:
   if app.poll()is not None:raise RuntimeError('player exited before an unfinished graph fence was observed')
   raw=os.pread(trace.fd,65537,0)
   if len(raw)>65536:raise ValueError('trace extent exceeds bound')
   complete=raw[:raw.rfind(b'\n')+1]if raw and not raw.endswith(b'\n')else raw
   lines=complete.splitlines()
   if not lines:time.sleep(.002);continue
   first=lines[0].decode('ascii').split()
   if len(first)!=5:raise ValueError('malformed first fence record')
   candidate_pid=int(first[1]);chain=owned_descendant(candidate_pid,app.pid);candidate=identity(candidate_pid)
   if fake:
    argv=Path(f'/proc/{candidate_pid}/cmdline').read_bytes().split(b'\0')
    if len(argv)<3 or argv[1]!=os.fsencode(asset['runtime']):raise ValueError('fake native command differs')
   elif Path(f'/proc/{candidate_pid}/exe').resolve()!=asset['runtime'].resolve():raise ValueError('pinned native executable differs')
   starts,done=trace.read(candidate_pid)
   candidates=[r for seq,r in starts.items()if seq not in done and r['kind']=='graph']
   if not candidates:time.sleep(.002);continue
   current=[p for p in inputs(job)if p.parent.name=='native']
   if len(current)!=1:time.sleep(.002);continue
   pending=max(candidates,key=lambda r:r['monotonic_ns']);native=candidate;spools=[current[0].parent]
   if(current[0].parent/'output.f32').exists():raise ValueError('native output already started')
   pidfd=os.pidfd_open(candidate_pid,0)
   if identity(candidate_pid)!=native:raise ValueError('native identity changed before close')
   result.update(actual_GPU_wait_observed=not fake,native_identity=native,ancestor_chain=chain,pending_fence=pending,native_input=str(current[0]),native_spool=str(spools[0]),pidfd_opened=True)
   result['close_requested_ns']=time.monotonic_ns();close_file.touch(mode=0o600,exist_ok=False)
   break
  else:raise TimeoutError('no owned unfinished graph fence observed within the observation budget')
  app.wait(timeout=8)
  if app.returncode!=0:raise RuntimeError('player close returned nonzero')
  cpp=json.loads(cpp_report.read_text());result['app_report']=cpp
  if not(cpp['controller_shutdown_returned']and cpp['window_close_accepted']and cpp['busy_at_close']and cpp['source_frames_at_close']==cpp['source_frames_after_shutdown']==0 and cpp['load_issued_ns']<=pending['monotonic_ns']<=cpp['window_close_issued_ns']):
   raise ValueError('real close did not occur during the unfinished first live preparation')
  result['controller_shutdown_ms']=(cpp['shutdown_returned_ns']-cpp['app_exec_returned_ns'])/1e6
  result['window_close_to_shutdown_ms']=(cpp['shutdown_returned_ns']-cpp['window_close_issued_ns'])/1e6
  if not(0<=result['window_close_to_shutdown_ms']<=3000):raise ValueError('existing three-second native close budget exceeded')
  starts,done=trace.read(native['pid'],final=True);completion=done.get(pending['sequence'])
  result['selected_completion']=completion
  if completion and completion['monotonic_ns']<=cpp['window_close_issued_ns']:raise ValueError('selected GPU wait completed before the window-close observation')
  result['completion_mode']='completed during cancellation'if completion else'no wait-return marker before native retirement'
  result['native_pidfd_readable']=bool(select.select([pidfd],[],[],0)[0])
  try:original_gone=identity(native['pid'])['start_ticks']!=native['start_ticks']
  except FileNotFoundError:original_gone=True
  result['native_reaped']=original_gone
  retired=[]
  for original in result['ancestor_chain']:
   try:gone=identity(original['pid'])['start_ticks']!=original['start_ticks']
   except FileNotFoundError:gone=True
   retired.append(dict(**original,reaped=gone))
  result['owned_descendants_after_app_exit']=retired
  if not all(x['reaped']for x in retired):raise ValueError('an original owned descendant remains after app exit')
  result['native_spool_removed']=all(not p.exists()for p in spools)
  if not(result['native_pidfd_readable']and original_gone and result['native_spool_removed']):raise ValueError('native retirement or spool cleanup is incomplete')
  result['passed']=True
 except BaseException as error:
  failure=type(error).__name__+': '+str(error);result['error']=failure
 finally:
  if app is not None and app.poll()is None:
   if not close_file.exists():close_file.touch(mode=0o600,exist_ok=False)
   try:app.wait(timeout=8)
   except subprocess.TimeoutExpired:
    result['fallback_cleanup_used']=True
    os.killpg(app.pid,signal.SIGTERM)
    try:app.wait(timeout=2)
    except subprocess.TimeoutExpired:os.killpg(app.pid,signal.SIGKILL);app.wait(timeout=2)
  if app is not None:result['app_exit']=app.returncode;result['app_reaped']=app.poll()is not None
  if cpp_report.is_file()and'app_report'not in result:
   raw=cpp_report.read_bytes()
   if len(raw)<=65536:result['app_report']=json.loads(raw)
  result['native_inputs_remaining']=[str(p)for p in inputs(job)]
  if pidfd is not None:os.close(pidfd)
  trace.close()
  result['partial_source_installed']=bool(result['app_report']['source_frames_after_shutdown'])if'app_report'in result else None
  with(job/'result.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps(result),flush=True)
 return 0 if result['passed']else 1

if __name__=='__main__':raise SystemExit(run())
