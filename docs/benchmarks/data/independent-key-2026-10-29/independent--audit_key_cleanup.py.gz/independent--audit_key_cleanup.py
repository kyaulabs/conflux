"""Read the original bound cgroups after unit retirement; never rerun captures."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import inspect
import json
import subprocess
from stage_keyfinder import TARGET,REMOTE,SSH,save


def audit(base,local):
    binding=json.loads((base/'unit-binding-01.json').read_text())
    closed=json.loads((base/'unit-closed-01.json').read_text())
    assert closed['before_stop']['InvocationID']==binding['InvocationID']
    unit='conflux-independent-keyfinder-'+('laptop'if local else'apollo')+'-20261029-01.service'
    group=binding['ControlGroup'];assert group.startswith('/')and group.endswith('/'+unit)
    path=Path('/sys/fs/cgroup'+group)
    descendants={}if not path.exists()else{str(p):p.read_text().strip()for p in path.rglob('cgroup.procs')}
    assert not any(descendants.values())
    raw=subprocess.check_output(['systemctl']+(['--user']if local else[])+['show',unit,'--property=LoadState,MainPID'],text=True,timeout=5)
    assert'LoadState=not-found'in raw and'MainPID=0'in raw
    return dict(unit=unit,invocation=binding['InvocationID'],original_group=group,
        original_cgroup_absent=not path.exists(),remaining_members=descendants,
        unit_absent=True,earlier_closed_receipt_retained=True,captures_rerun=False)


def main():
    def local():return audit(TARGET/'laptop',True)
    def apollo():
        code='from pathlib import Path\nimport json,subprocess\n'+inspect.getsource(audit)
        code+='\nprint(json.dumps(audit(Path('+repr(REMOTE)+'),False)))\n'
        r=subprocess.run(SSH+['python3 -'],input=code,capture_output=True,text=True,timeout=20)
        r.check_returncode();return json.loads(r.stdout)
    with ThreadPoolExecutor(max_workers=2)as pool:
        left=pool.submit(local);right=pool.submit(apollo)
        result=dict(laptop=left.result(),apollo=right.result())
    save(TARGET/'original-cgroup-audit-01.json',result)
    print(json.dumps(result))


if __name__=='__main__':main()
