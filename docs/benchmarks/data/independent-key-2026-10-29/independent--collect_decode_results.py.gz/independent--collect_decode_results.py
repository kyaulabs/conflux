"""Collect completed decoder results without rerunning work or changing log permissions."""
import ast
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

BASE=Path(__file__).resolve().parent
PREP=BASE/'preparation-02'
spec=importlib.util.spec_from_file_location('decode_collection_launch',BASE/'run_decode_both.py')
launch=importlib.util.module_from_spec(spec);spec.loader.exec_module(launch)
spec=importlib.util.spec_from_file_location('decode_validation',BASE/'decode_cases.py')
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
assert 'PermissionError' in (PREP/'decode-remote-collect.stderr.log').read_text()
local_closed=json.loads((PREP/'laptop/decode-unit-closed-01.json').read_text())
assert local_closed['after_stop']['LoadState']=='not-found'and local_closed['cgroup_absent_or_empty']
assert launch.show(launch.LOCAL_UNIT)['LoadState']=='not-found'
header='BASE='+repr(launch.REMOTE)+'\nUNIT='+repr(launch.REMOTE_UNIT)+'\nIMAGE='+repr(launch.IMAGE)+'\n'
code=r'''
from pathlib import Path
import base64,hashlib,json,re,subprocess
base=Path(BASE)
raw=subprocess.check_output(['systemctl','show',UNIT,'--property=LoadState,MainPID'],text=True,timeout=5)
state=dict(line.split('=',1)for line in raw.splitlines()if '='in line)
assert state['LoadState']=='not-found'and state['MainPID']=='0'
retired=json.loads((base/'decode-unit-closed-01.json').read_text())
assert retired['after_stop']['LoadState']=='not-found'and retired['container_absent']and retired['cgroup_absent_or_empty']
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert subprocess.run(D+['inspect','conflux-independent-decode-20261029-01'],capture_output=True,timeout=5).returncode!=0
execution=json.loads((base/'execution/execution-plan.json').read_text())
roots={'/operations/':base/'execution','/prepare/':base/'native','/media/':base/'media'}
for row in execution['input_pins']:
 matches=[(prefix,root)for prefix,root in roots.items()if row['path'].startswith(prefix)];assert len(matches)==1
 prefix,root=matches[0];path=root/row['path'][len(prefix):]
 assert path.is_file()and not path.is_symlink()and path.stat().st_size==row['bytes']
 with path.open('rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
paths=[base/'decode-unit-closed-01.json',base/'decode-container-closed-01.json',base/'execution/execution-plan.json',base/'decode-unit.stdout.log',base/'decode-unit.stderr.log']
for path in (base/'decode-results').rglob('*'):
 if not path.is_file()or path.is_symlink():continue
 rel=path.relative_to(base/'decode-results')
 if len(rel.parts)==1 and str(rel)in('protocol-tests.stdout.log','protocol-tests.stderr.log'):paths.append(path)
 elif rel.parent==Path('cases')and (rel.name=='preparation.json'or re.fullmatch(r'[0-9]{6}.(?:stdout.json|stderr.log|receipt.json)',rel.name)):paths.append(path)
privileged_program=r"""
from pathlib import Path
import os,stat,sys
base=Path('/srv/conflux-tests/work/fmak-independent-preparation-20261029-02')
path=Path(sys.argv[1])
assert path in (base/'decode-unit.stdout.log',base/'decode-unit.stderr.log')and base.resolve()==base
descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
try:
 info=os.fstat(descriptor);assert stat.S_ISREG(info.st_mode)and info.st_uid==0 and info.st_size<=128*1024
 raw=os.read(descriptor,128*1024+1);assert len(raw)==info.st_size
 sys.stdout.buffer.write(raw)
finally:os.close(descriptor)
"""
files=[]
for path in paths:
 if path in (base/'decode-unit.stdout.log',base/'decode-unit.stderr.log'):
  data=subprocess.check_output(['sudo','-n','/usr/bin/python3','-c',privileged_program,str(path)],timeout=5)
 else:data=path.read_bytes()
 assert len(data)<128*1024
 files.append(dict(file=str(path.relative_to(base)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),raw_base64=base64.b64encode(data).decode()))
assert sum(row['bytes']for row in files)<2*1024**2
print(json.dumps(dict(retired=retired,files=files,all_execution_input_pins_revalidated=True,only_two_fixed_root_logs_read_privileged=True,permissions_unchanged=True)))
'''
result=subprocess.run(launch.SSH+['python3 -'],input=header+code,capture_output=True,text=True,timeout=60)
(PREP/'decode-remote-collect-02.stderr.log').write_text(result.stderr)
result.check_returncode()
remote=json.loads(result.stdout)
destination=PREP/'apollo-collected-01';destination.mkdir(mode=0o700)
for row in remote['files']:
    relative=Path(row['file']);assert not relative.is_absolute()and '..'not in relative.parts
    raw=base64.b64decode(row['raw_base64'],validate=True)
    assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
    path=destination/relative;path.parent.mkdir(mode=0o700,parents=True,exist_ok=True);path.write_bytes(raw)
manifest={key:value for key,value in remote.items()if key!='files'}
manifest['files']=[{key:value for key,value in row.items()if key!='raw_base64'}for row in remote['files']]
(PREP/'apollo-collected-manifest-01.json').write_text(json.dumps(manifest,indent=2)+'\n')

data={}
for host,root,plan_file in [('laptop',PREP/'laptop/decode-results',PREP/'laptop/execution/execution-plan.json'),
    ('apollo',destination/'decode-results/cases',destination/'execution/execution-plan.json')]:
    plan=protocol.strict_json(plan_file.read_bytes())
    result=protocol.strict_json((root/'preparation.json').read_bytes())
    assert len(result['cases'])==len(plan['cases'])==24 and result['input_pins_unchanged']and not result['PCM_persisted']and not result['spool_artifacts']
    if host=='laptop':
        for row in plan['input_pins']:protocol.verify(row)
    checked=[]
    for case,row in zip(plan['cases'],result['cases'],strict=True):
        assert row['id']==case['id']and row==protocol.strict_json((root/(row['id']+'.receipt.json')).read_bytes())
        if row['status']=='PreparedMetadataMeasured':
            actual=protocol.validate(protocol.strict_json((root/(row['id']+'.stdout.json')).read_bytes()),case)
            for key in ('id','status','prepared_frames','pcm_sha256','source','model_started'):assert actual[key]==row[key]
            checked.append(row['id'])
        else:
            assert row['status']=='SourcePreparationFailed'and row['model_started']is False
            assert (root/(row['id']+'.stderr.log')).stat().st_size>0
    data[host]=dict(result=result,independently_revalidated=checked)

matches=[];mismatches=[];failures=[]
for left,right in zip(data['laptop']['result']['cases'],data['apollo']['result']['cases'],strict=True):
    assert left['id']==right['id']
    if left['status']==right['status']=='PreparedMetadataMeasured':
        if left['prepared_frames']==right['prepared_frames']and left['pcm_sha256']==right['pcm_sha256']:matches.append(left['id'])
        else:mismatches.append(dict(id=left['id'],laptop=left,apollo=right))
    else:failures.append(dict(id=left['id'],laptop=left,apollo=right))
summary=dict(schema=1,fixed_denominator=24,
    hosts={host:dict(prepared=len(value['independently_revalidated']),all_sources_prepared=value['result']['all_sources_prepared'],
        elapsed_seconds=value['result']['elapsed_seconds'],PCM_persisted=False,input_pins_unchanged=True)
        for host,value in data.items()},
    exact_frame_and_PCM_matches=matches,mismatches=mismatches,source_failures_retained=failures,
    both_units_retired=True,apollo_container_absent=True,all_raw_metadata_and_source_pins_revalidated=True,
    root_log_collection_error_retained=True,source_decode_rerun_for_collection=False,
    model_inference_started=False,audio_output_started=False,physical_readiness_consumed=False,qualified=False)
(PREP/'decode-comparison-01.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(hosts=summary['hosts'],exact_frame_and_PCM_matches=len(matches),mismatches=len(mismatches),
    source_failures=len(failures),both_units_retired=True,model_inference_started=False,qualified=False)))
