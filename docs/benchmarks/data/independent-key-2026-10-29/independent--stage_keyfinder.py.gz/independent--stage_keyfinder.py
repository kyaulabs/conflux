"""Stage fixed CPU classifiers only; do not start music inference."""
from pathlib import Path
import hashlib
import json
import subprocess

BASE=Path(__file__).resolve().parent
TARGET=BASE/'keyfinder-01'
REMOTE='/srv/conflux-tests/work/fmak-independent-keyfinder-20261029-01'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no',
    '-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes',
    '-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222',
    '-p','4222','kyau@apollo.kyaulabs']


def pin(path):
    assert path.is_file()and not path.is_symlink()
    with path.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest)


def save(path,value):
    with path.open('x')as stream:stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def main():
    assert not(TARGET/'stage-complete-01.json').exists()
    files={name:(TARGET/name).read_text()for name in ('run_corpus.py','test_corpus.py','test_lifecycle.py')}
    check=subprocess.run(['/usr/bin/python3.14','-B','-m','unittest','-v','test_corpus','test_lifecycle'],
        cwd=TARGET,capture_output=True,text=True,timeout=15)
    (TARGET/'offline-local.stdout.log').write_text(check.stdout)
    (TARGET/'offline-local.stderr.log').write_text(check.stderr)
    assert check.returncode==0 and'Ran 12 tests'in check.stderr and check.stderr.rstrip().endswith('OK')
    local=json.loads((TARGET/'laptop/plan.json').read_text())
    local['input_pins']=[local['preparer'],local['worker']]+[case['source']for case in local['cases']]+[pin(TARGET/name)for name in files]
    (TARGET/'laptop/plan.json').write_text(json.dumps(local,indent=2)+'\n')
    for row in local['input_pins']:assert pin(Path(row['path']))==row
    for name in ('unit.stdout.log','unit.stderr.log'):(TARGET/'laptop'/name).touch(mode=0o600,exist_ok=False)
    plan=json.loads((TARGET/'apollo/plan.json').read_text())
    code='REMOTE='+repr(REMOTE)+'\nPLAN='+repr(plan)+'\nFILES='+repr(files)+'\n'+r'''
from pathlib import Path
import hashlib,json,os,subprocess
base=Path(REMOTE);assert not base.exists();base.mkdir(mode=0o700)
operations=base/'operations';operations.mkdir(mode=0o700)
for name,text in FILES.items():(operations/name).write_text(text)
decoder=Path('/srv/conflux-tests/work/fmak-independent-preparation-20261029-02')
worker=Path('/srv/conflux-tests/work/keyfinder-global-20261028-01/native/keyfinder-global-worker')
def verify(path,row):
 assert path.is_file()and not path.is_symlink()and path.stat().st_size==row['bytes']
 with path.open('rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
def pin(path,target):
 with path.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 return dict(path=target,bytes=path.stat().st_size,sha256=digest)
verify(decoder/'native/prepare-independent-source',PLAN['preparer']);verify(worker,PLAN['worker'])
for case in PLAN['cases']:verify(decoder/'media'/(case['id']+'.mp3'),case['source'])
PLAN['input_pins']=[PLAN['preparer'],PLAN['worker']]+[case['source']for case in PLAN['cases']]+[pin(operations/name,'/operations/'+name)for name in FILES]
(operations/'plan.json').write_text(json.dumps(PLAN,indent=2)+chr(10))
(base/'results').mkdir(mode=0o700)
for name in ('unit.stdout.log','unit.stderr.log'):(base/name).touch(mode=0o600,exist_ok=False)
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
name='conflux-independent-keyfinder-offline-20261029-01'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
command=D+['run','--rm','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL',
 '--security-opt=no-new-privileges:true','--user=1000:1000','--cpus=1','--memory=1g','--pids-limit=128',
 '--label','org.kyaulabs.conflux.run=independent-keyfinder-offline-20261029-01',
 '--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777',
 '--mount','type=bind,src='+str(operations)+',dst=/operations,readonly',
 '--workdir','/operations',image,'python','-B','-m','unittest','-v','test_corpus','test_lifecycle']
try:r=subprocess.run(command,capture_output=True,text=True,timeout=30)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  c=json.loads(found.stdout)[0]
  assert c['Image']==image and c['Config']['Labels']['org.kyaulabs.conflux.run']=='independent-keyfinder-offline-20261029-01'
  subprocess.run(D+['rm','--force',c['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
(base/'offline.stdout.log').write_text(r.stdout);(base/'offline.stderr.log').write_text(r.stderr)
result=dict(exit=r.returncode,tests=12,container_absent=True,plan=PLAN,
 source_pins_verified=True,music_model_started=False,GPU_audio_or_power_changes=False,
 stdout=r.stdout,stderr=r.stderr)
(base/'offline-receipt-01.json').write_text(json.dumps(result,indent=2)+chr(10))
print(json.dumps(result));assert r.returncode==0 and'Ran 12 tests'in r.stderr and r.stderr.rstrip().endswith('OK')
'''
    result=subprocess.run(SSH+['python3 -'],input=code,text=True,capture_output=True,timeout=60)
    (TARGET/'stage-apollo.stdout.log').write_text(result.stdout)
    (TARGET/'stage-apollo.stderr.log').write_text(result.stderr)
    result.check_returncode()
    remote=json.loads(result.stdout)
    save(TARGET/'stage-complete-01.json',dict(local_offline_exit=check.returncode,
        apollo=remote,source_model_inference_started=False,physical_readiness_consumed=False,
        local_plan=pin(TARGET/'laptop/plan.json'),prospective=pin(TARGET/'prospective-01.json')))
    print(json.dumps(dict(staged=True,tests_per_host=12,music_model_started=False)))


if __name__=='__main__':main()
