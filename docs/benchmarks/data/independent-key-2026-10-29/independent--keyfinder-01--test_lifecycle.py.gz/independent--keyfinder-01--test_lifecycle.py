"""Generated ownership regressions; no music, models or host changes."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch
import run_corpus as runner


class LifecycleTests(unittest.TestCase):
    def test_failure_to_reap_one_child_still_reaps_the_other_and_halts(self):
        left=Mock(pid=1111);right=Mock(pid=2222)
        left.poll.return_value=right.poll.return_value=None
        left.wait.side_effect=subprocess.TimeoutExpired('generated-child',2)
        right.wait.return_value=0
        with patch.object(runner.os,'killpg')as killed,self.assertRaises(runner.ChildCleanupError):
            runner.reap((left,right))
        self.assertEqual(left.wait.call_count,2)
        self.assertEqual(right.wait.call_count,1)
        self.assertEqual(killed.call_count,3)

    def test_owner_starts_no_next_case_after_unproven_child_cleanup(self):
        with tempfile.TemporaryDirectory()as temporary:
            root=Path(temporary);plan=root/'plan.json'
            cases=[dict(id=f'{index:06d}',preparation_status='PreparedMetadataMeasured')for index in range(24)]
            plan.write_text(json.dumps(dict(status='frozen_CPU_correctness_only',
                physical_readiness_required=False,recipe=runner.RECIPE,host='apollo',cases=cases,input_pins=[])))
            with (patch.object(sys,'argv',['fixture','--owned','--plan',str(plan),'--output',str(root/'out')]),
                patch.dict('os.environ',CONFLUX_PRIVATE_KEY_REFERENCE='1'),patch.object(Path,'exists',return_value=False),
                patch.object(runner,'predict',side_effect=runner.ChildCleanupError('generated unreaped child'))as predicted,
                self.assertRaises(runner.ChildCleanupError)):
                runner.main()
            self.assertEqual(predicted.call_count,1)

    def test_rejected_source_is_retained_without_starting_the_worker(self):
        with tempfile.TemporaryDirectory()as temporary:
            root=Path(temporary);plan=root/'plan.json';output=root/'out'
            failure=dict(type='ValueError',message='generated unsupported source')
            cases=[dict(id=f'{index:06d}',preparation_status='SourcePreparationFailed',error=failure)for index in range(24)]
            plan.write_text(json.dumps(dict(status='frozen_CPU_correctness_only',
                physical_readiness_required=False,recipe=runner.RECIPE,host='apollo',cases=cases,input_pins=[])))
            with (patch.object(sys,'argv',['fixture','--owned','--plan',str(plan),'--output',str(output)]),
                patch.dict('os.environ',CONFLUX_PRIVATE_KEY_REFERENCE='1'),patch.object(Path,'exists',return_value=False),
                patch.object(runner,'predict')as predicted,redirect_stdout(io.StringIO())):
                self.assertEqual(runner.main(),0)
            predicted.assert_not_called()
            receipt=json.loads((output/'prediction-receipt.json').read_text())
            self.assertEqual(receipt['fixed_denominator'],24)
            self.assertEqual(receipt['inferred'],0)
            self.assertFalse(receipt['PCM_persisted'])
            captures=json.loads((output/'predictions-before-scoring.json').read_text())
            self.assertTrue(all(row['status']=='SourcePreparationFailed'and row['model_started']is False for row in captures))

    def test_dry_default_opens_no_source_or_host_state(self):
        with (patch.object(sys,'argv',['fixture']),patch.object(Path,'read_bytes')as read,
            patch.object(runner.subprocess,'Popen')as launched,redirect_stdout(io.StringIO())):
            self.assertEqual(runner.main(),0)
        read.assert_not_called();launched.assert_not_called()


if __name__=='__main__':unittest.main(verbosity=2)
