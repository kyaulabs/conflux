"""Observe fixed captures, retire owned units and collect bounded text only."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
import base64
import hashlib
import inspect
import json
import subprocess
import time
from stage_keyfinder import TARGET,REMOTE,SSH,save


def state(unit,local):
    raw=subprocess.check_output(['systemctl']+(['--user']if local else[])+['show',unit,
        '--property=LoadState,ActiveState,SubState,MainPID,InvocationID,ControlGroup,Result,ExecMainStatus'],text=True,timeout=5)
    return dict(line.split('=',1)for line in raw.splitlines()if'='in line)


def observe(base,local,expired=False):
    plan=json.loads((base/('plan.json'if local else'operations/plan.json')).read_text())
    unit=plan['unit'];unit_state=state(unit,local)
    closed_path=base/'unit-closed-01.json'
    if closed_path.exists():
        closed=json.loads(closed_path.read_text())
        assert unit_state['LoadState']=='not-found'and unit_state['MainPID']=='0'
    else:
        binding=base/'unit-binding-01.json'
        assert unit_state['LoadState']=='loaded'and len(unit_state['InvocationID'])==32
        if binding.exists():assert json.loads(binding.read_text())['InvocationID']==unit_state['InvocationID']
        else:binding.write_text(json.dumps(unit_state,indent=2)+chr(10))
        if unit_state['MainPID']=='0'or expired:
            prefix=['systemctl']+(['--user']if local else[])
            command=prefix+['stop',unit]
            if not local:command=['sudo','-n']+command
            subprocess.run(command,check=True,capture_output=True,timeout=25)
            after=state(unit,local)
            if after['LoadState']!='not-found':
                assert after['MainPID']=='0'
                command=prefix+['reset-failed',unit]
                if not local:command=['sudo','-n']+command
                subprocess.run(command,check=True,capture_output=True,timeout=5)
                after=state(unit,local)
            assert after['LoadState']=='not-found'and after['MainPID']=='0'
            # RemainAfterExit can clear ControlGroup after the leader exits.
            # Keep the original owned cgroup from the first running observation.
            group=unit_state['ControlGroup']or json.loads(binding.read_text())['ControlGroup']
            if group:
                cgroup=Path('/sys/fs/cgroup'+group)
                assert not cgroup.exists()or not any(path.read_text().strip()for path in cgroup.rglob('cgroup.procs'))
            closed=dict(before_stop=unit_state,after_stop=after,cgroup_absent_or_empty=True,expired=expired)
            if not local:
                D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
                name='conflux-independent-keyfinder-20261029-01'
                found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
                if found.returncode==0:
                    value=json.loads(found.stdout)[0]
                    assert value['Image']=='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
                    assert value['Config']['Labels']['org.kyaulabs.conflux.run']=='independent-keyfinder-20261029-01'
                    subprocess.run(D+['rm','--force',value['Id']],check=True,capture_output=True,timeout=10)
                assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
                closed['container_absent']=True
            closed_path.write_text(json.dumps(closed,indent=2)+chr(10))
        else:closed=None
    output=base/('predictions'if local else'results/predictions')
    rows=[json.loads(path.read_text())for path in output.glob('*-capture.json')]
    result=dict(unit=unit_state,captures=len(rows),statuses=dict(Counter(row['status']for row in rows)),closed=closed)
    receipt=output/'prediction-receipt.json'
    if receipt.exists():result['capture_receipt']=json.loads(receipt.read_text())
    return result


def main():
    reservation=json.loads((TARGET/'launch-reservation-01.json').read_text())
    expired=time.monotonic()>=reservation['deadline_monotonic']-40
    def local():return observe(TARGET/'laptop',True,expired)
    def apollo():
        code='from pathlib import Path\nfrom collections import Counter\nimport json,subprocess\n'+inspect.getsource(state)+'\n'+inspect.getsource(observe)
        code+='\nprint(json.dumps(observe(Path('+repr(REMOTE)+'),False,'+repr(expired)+')))\n'
        r=subprocess.run(SSH+['python3 -'],input=code,capture_output=True,text=True,timeout=50)
        r.check_returncode();return json.loads(r.stdout)
    with ThreadPoolExecutor(max_workers=2)as pool:
        left=pool.submit(local);right=pool.submit(apollo)
        results=dict(laptop=left.result(),apollo=right.result())
    number=len(list(TARGET.glob('observation-*.json')))+1
    save(TARGET/f'observation-{number:03}.json',dict(utc=datetime.now(timezone.utc).isoformat(),hosts=results,reference_labels_read=False))
    print(json.dumps({host:{key:value for key,value in row.items()if key!='capture_receipt'}for host,row in results.items()}))
    if not all(row['closed']for row in results.values()):return
    if (TARGET/'both-closed-before-scoring-01.json').exists():return
    code='BASE='+repr(REMOTE)+'\n'+r'''
from pathlib import Path
import base64,hashlib,json
base=Path(BASE);closed=json.loads((base/'unit-closed-01.json').read_text());assert closed['container_absent']
plan=json.loads((base/'operations/plan.json').read_text())
names=['unit-closed-01.json','unit-binding-01.json','container-closed-01.json','operations/plan.json','owner.py','dispatch-01.json',
 'unit.stdout.log','unit.stderr.log','results/predictions/predictions-before-scoring.json','results/predictions/prediction-receipt.json']
for case in plan['cases']:
 names += ['results/predictions/'+case['id']+suffix for suffix in ('-capture.json','-source.json','-prediction.json','-worker.stderr')]
files=[];total=0
for name in names:
 path=base/name
 if not path.exists():continue
 assert path.is_file()and not path.is_symlink()and path.stat().st_size<=262144
 raw=path.read_bytes();total+=len(raw);assert total<=2*1024*1024
 files.append(dict(file=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),base64=base64.b64encode(raw).decode()))
print(json.dumps(dict(files=files,total_bytes=total)))
'''
    r=subprocess.run(SSH+['python3 -'],input=code,capture_output=True,text=True,timeout=25)
    (TARGET/'collect-apollo.stderr.log').write_text(r.stderr);r.check_returncode()
    value=json.loads(r.stdout);destination=TARGET/'apollo-collected-01';destination.mkdir(mode=0o700)
    manifest=[]
    for row in value['files']:
        path=destination/row['file'];assert path.is_relative_to(destination)
        raw=base64.b64decode(row['base64'],validate=True)
        assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
        path.parent.mkdir(mode=0o700,parents=True,exist_ok=True);path.write_bytes(raw)
        manifest.append({key:row[key]for key in ('file','bytes','sha256')})
    save(TARGET/'apollo-collected-manifest-01.json',manifest)
    hosts={}
    for host,folder in (('laptop',TARGET/'laptop/predictions'),('apollo',destination/'results/predictions')):
        path=folder/'predictions-before-scoring.json';raw=path.read_bytes()
        receipt=json.loads((folder/'prediction-receipt.json').read_text())
        assert hashlib.sha256(raw).hexdigest()==receipt['closed_capture_sha256']
        assert receipt['completed_captures']==receipt['fixed_denominator']==24
        assert receipt['inferred']==23 and receipt['all_inferable_sources_completed']and receipt['PCM_persisted']is False
        assert receipt['reference_labels_opened']is False
        hosts[host]=dict(captures_sha256=hashlib.sha256(raw).hexdigest(),receipt=receipt)
    save(TARGET/'both-closed-before-scoring-01.json',dict(hosts=hosts,both_units_retired=True,
        apollo_container_absent=True,reference_labels_opened=False,physical_readiness_consumed=False))
    print(json.dumps(dict(both_closed=True,inferred_per_host=23,source_failure_retained=1,reference_labels_read=False)))


if __name__=='__main__':main()
