BASE='/srv/conflux-tests/work/fmak-independent-keyfinder-20261029-01'

from pathlib import Path
import json,signal,subprocess,time
base=Path(BASE);D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
name='conflux-independent-keyfinder-20261029-01';label='independent-keyfinder-20261029-01'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
def interrupted(number,frame):raise InterruptedError('Owned classifier stopped')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
decode=Path('/srv/conflux-tests/work/fmak-independent-preparation-20261029-02')
command=D+['run','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL',
 '--security-opt=no-new-privileges:true','--user=1000:1000','--memory=1g','--cpus=1','--pids-limit=128',
 '--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--env','CONFLUX_PRIVATE_KEY_REFERENCE=1',
 '--env','OMP_NUM_THREADS=1','--env','OPENBLAS_NUM_THREADS=1','--label','org.kyaulabs.conflux.run='+label,
 '--mount','type=bind,src='+str(base/'operations')+',dst=/operations,readonly',
 '--mount','type=bind,src='+str(decode/'media')+',dst=/media,readonly',
 '--mount','type=bind,src='+str(decode/'native/prepare-independent-source')+',dst=/prepare/prepare-independent-source,readonly',
 '--mount','type=bind,src=/srv/conflux-tests/work/keyfinder-global-20261028-01/native/keyfinder-global-worker,dst=/worker/keyfinder-global-worker,readonly',
 '--mount','type=bind,src='+str(base/'results')+',dst=/results',image,
 'python','-B','/operations/run_corpus.py','--owned','--plan','/operations/plan.json','--output','/results/predictions']
first=time.monotonic();result=None;error=None
try:result=subprocess.run(command,timeout=1680)
except BaseException as exception:error=dict(type=type(exception).__name__,message=str(exception)[:1024])
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  value=json.loads(found.stdout)[0]
  assert value['Image']==image and value['Config']['Labels']['org.kyaulabs.conflux.run']==label
  subprocess.run(D+['rm','--force',value['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
 receipt=dict(container_absent=True,exit=None if result is None else result.returncode,error=error,elapsed_seconds=time.monotonic()-first)
 (base/'container-closed-01.json').write_text(json.dumps(receipt,indent=2)+chr(10))
raise SystemExit(0 if result is not None and result.returncode==0 and error is None else 1)
