"""Fixed CPU-only whole-track predictions; never load reference labels."""
from pathlib import Path
import argparse,hashlib,json,os,re,signal,subprocess,time
RECIPE='private-keyfinder-2.2.8-stereo-global-stream-v1'

def strict_json(raw):
 def pairs(items):
  out={}
  for key,value in items:
   if key in out:raise ValueError('Duplicate JSON field')
   out[key]=value
  return out
 return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda value:(_ for _ in()).throw(ValueError('Nonfinite JSON number')))

def store(path,value):
 with path.open('x')as f:
  f.write(json.dumps(value,indent=2,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())

def verify(row):
 p=Path(row['path']);assert p.is_file()and not p.is_symlink()
 assert p.stat().st_size==row['bytes']
 with p.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256']

def validate(value,source,case):
 assert value['schema']==source['schema']==1
 assert source['case']==case['id']and source['complete']is True and source['audio_device_opened']is False
 assert source['source_bytes']==case['source']['bytes']and source['source_sha256']==case['source']['sha256']
 assert source['prepared_frames']==value['frames']==case['prepared_frames']
 assert value['pcm_sha256']==source['prepared_pcm_sha256']==case['pcm_sha256']
 assert value['recipe']==RECIPE and value['qualified']is False and value['confidence']=='Unknown'
 assert value['sample_rate']==source['sample_rate']==48000 and value['channels']==source['channels']==2
 assert value['support_first_frame']==0 and value['support_end_frame']==case['prepared_frames']and value['input_block_frames']==48000
 assert type(value['frames'])is int and 1<=value['frames']<=33554432
 key=None
 if value['status']=='Estimated':
  assert value['frames']>=32768
  enum=value['keyfinder_key_enum'];assert type(enum)is int and 0<=enum<24
  assert type(value['tonic'])is int and value['tonic']==(9+enum//2)%12
  assert value['mode']==('Minor'if enum%2 else'Major')and value['reason']=='reference-profile-match'
  key=value['tonic']+(12 if value['mode']=='Minor'else 0)
 else:
  assert value['status']=='Unknown'and value['reason']in('short','silence')and 'tonic'not in value and 'mode'not in value
  if value['reason']=='short':assert value['frames']<32768 and 'keyfinder_key_enum'not in value
  else:assert value['frames']>=32768 and type(value['keyfinder_key_enum'])is int and value['keyfinder_key_enum']==24
 return key

class ChildCleanupError(RuntimeError):
 pass

def reap(children):
 failures=[]
 for child in children:
  if child is None or child.poll()is not None:continue
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:child.wait(timeout=2)
  except subprocess.TimeoutExpired:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   try:child.wait(timeout=2)
   except subprocess.TimeoutExpired:failures.append(child.pid)
 if failures:raise ChildCleanupError('Owned pipeline reap not proven: '+str(failures))

def predict(plan,case,output):
 identifier=case['id'];assert re.fullmatch(r'[0-9]{6}',identifier)
 spool=output/('spool-'+identifier);spool.mkdir(mode=0o700)
 source_path=output/(identifier+'-source.json');prediction_path=output/(identifier+'-prediction.json');error_path=output/(identifier+'-worker.stderr')
 producer=consumer=None;began=time.monotonic()
 try:
  with source_path.open('xb')as metadata,prediction_path.open('xb')as prediction,error_path.open('xb')as errors:
   producer=subprocess.Popen([plan['preparer']['path'],identifier,str(spool),'--pcm'],stdout=subprocess.PIPE,stderr=metadata,start_new_session=True)
   consumer=subprocess.Popen([plan['worker']['path'],'--frames',str(case['prepared_frames'])],stdin=producer.stdout,stdout=prediction,stderr=errors,start_new_session=True)
   producer.stdout.close()
   try:
    while consumer.poll()is None or producer.poll()is None:
     assert time.monotonic()-began<160,'Original 160-second case budget exhausted'
     assert os.fstat(prediction.fileno()).st_size<=16384 and os.fstat(metadata.fileno()).st_size<=4096 and os.fstat(errors.fileno()).st_size<=4096
     time.sleep(.05)
    assert producer.wait()==consumer.wait()==0,'Fixed preparation or reference worker failed'
   finally:reap((producer,consumer))
  assert prediction_path.stat().st_size<=16384 and source_path.stat().st_size<=4096 and error_path.stat().st_size<=4096,'Final capture exceeds bound'
  assert not list(spool.iterdir()),'Anonymous spool still contains files'
  source=strict_json(source_path.read_bytes());value=strict_json(prediction_path.read_bytes());key=validate(value,source,case)
  return dict(id=identifier,status='PredictionCaptured',complete=True,predicted_class=key,confidence='Unknown',elapsed_seconds=time.monotonic()-began,
   source=source,prediction_sha256=hashlib.sha256(prediction_path.read_bytes()).hexdigest(),prediction_file=prediction_path.name,
   producer_reaped=producer.poll()is not None,consumer_reaped=consumer.poll()is not None,spool_empty=True)
 finally:
  reap((producer,consumer))
  if spool.exists()and not list(spool.iterdir()):spool.rmdir()

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--owned',action='store_true');parser.add_argument('--plan',type=Path);parser.add_argument('--output',type=Path);args=parser.parse_args()
 if not args.owned:
  print(json.dumps(dict(unarmed=True,source_opened=False,reference_labels_opened=False,GPU_or_audio_opened=False)));return 0
 assert args.plan and args.output
 plan=strict_json(args.plan.read_bytes());assert plan['status']=='frozen_CPU_correctness_only'and plan['physical_readiness_required']is False and plan['recipe']==RECIPE
 if plan['host']=='laptop':assert any(s.endswith('/'+plan['unit'])for s in Path('/proc/self/cgroup').read_text().splitlines())
 else:assert plan['host']=='apollo'and os.environ.get('CONFLUX_PRIVATE_KEY_REFERENCE')=='1'and not Path('/dev/nvidia0').exists()and not Path('/dev/dri').exists()and not Path('/dev/snd').exists()
 assert len(plan['cases'])==24 and len({c['id']for c in plan['cases']})==24
 assert all(re.fullmatch(r'[0-9]{6}',c['id'])for c in plan['cases'])
 for row in plan['input_pins']:verify(row)
 began=time.monotonic();deadline=began+1650;output=args.output;output.mkdir(mode=0o700)
 captures=[]
 for case in plan['cases']:
  if case['preparation_status']!='PreparedMetadataMeasured':
   row=dict(id=case['id'],complete=False,status='SourcePreparationFailed',error=case['error'],model_started=False)
  elif time.monotonic()+160>=deadline:
   row=dict(id=case['id'],complete=False,status='NotRunBudget',model_started=False)
  else:
   try:row=predict(plan,case,output);row['model_started']=True
   except ChildCleanupError:raise
   except Exception as error:row=dict(id=case['id'],complete=False,status='InferenceFailed',model_started=True,error=dict(type=type(error).__name__,message=str(error)[:1024]))
  store(output/(case['id']+'-capture.json'),row);captures.append(row)
  print(json.dumps(dict(id=case['id'],status=row['status'])),flush=True)
 closed=output/'predictions-before-scoring.json';store(closed,captures)
 for row in plan['input_pins']:verify(row)
 assert time.monotonic()<deadline
 spool_artifacts=sorted(str(p.relative_to(output))for d in output.glob('spool-*')if d.is_dir()for p in d.rglob('*')if p.is_file()or p.is_symlink())
 receipt=dict(schema=1,PCM_persisted=bool(spool_artifacts),spool_artifacts=spool_artifacts,completed_captures=24,inferred=sum(c['complete']for c in captures),fixed_denominator=24,
  all_inferable_sources_completed=not spool_artifacts and all(c['complete']for case,c in zip(plan['cases'],captures,strict=True)if case['preparation_status']=='PreparedMetadataMeasured'),
  closed_capture_sha256=hashlib.sha256(closed.read_bytes()).hexdigest(),reference_labels_opened=False,confidence='Unknown',qualified=False,
  input_pins_unchanged=True,elapsed_seconds=time.monotonic()-began,hardware_or_latency_qualification=False,GPU_or_audio_opened=False)
 store(output/'prediction-receipt.json',receipt);print(json.dumps(receipt),flush=True)
 return 0 if receipt['all_inferable_sources_completed']else 1

if __name__=='__main__':raise SystemExit(main())
