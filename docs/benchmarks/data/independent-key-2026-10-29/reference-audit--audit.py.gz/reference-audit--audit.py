"""Audit independent-artist key-reference coverage from existing metadata only."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
SOURCE = ROOT / 'build/m2-fmak-assessment-01/source-admission-01'


def checked(name, expected):
    path = SOURCE / name
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if path.is_symlink() or digest != expected:
        raise ValueError('Previously admitted reference identity changed: ' + name)
    return json.loads(raw), dict(path=str(path), bytes=len(raw), sha256=digest)


def canonical_candidate(url):
    """Metadata screen only; does not admit/download new media or waive notices."""
    value = urlsplit(url)
    return (value.scheme in ('http', 'https') and value.hostname in
        ('creativecommons.org', 'www.creativecommons.org') and
        value.username is None and value.password is None and value.port is None and
        not value.query and not value.fragment and
        re.fullmatch(r'/licenses/(?:by/(?:1\.0|2\.0|2\.5|3\.0|4\.0)|by/3\.0/us|by-sa/(?:3\.0|4\.0))/?'
                     r'|/publicdomain/zero/1\.0/?', value.path) is not None)


def summarize(rows):
    count = Counter(row['reference_class'] for row in rows)
    return dict(tracks=len(rows), artists=len({row['artist_id'] for row in rows}),
        classes_present=sum(count[index] > 0 for index in range(24)),
        missing_classes=[index for index in range(24) if not count[index]],
        per_class={str(index): dict(tracks=count[index], artists=len({row['artist_id']
            for row in rows if row['reference_class'] == index})) for index in range(24)},
        overlapping_genre_labels=dict(sorted(Counter(genre for row in rows for genre in row['top_genres']).items())),
        track_ids=[row['track_id'] for row in rows],
        artist_ids=sorted({row['artist_id'] for row in rows}))


def main():
    catalogue, catalogue_pin = checked('catalogue-01.json',
        'ae0bc679807fabce8c08073fa335642b389fbf91881b3a7f45235edceeb7ded4')
    prior, prior_pin = checked('selection-plan-02.json',
        'cb1be723751d41049901f0926e5b2d984295089fc8ad4da9defb8daa727a56e4')
    rows = catalogue['records']
    assert len(rows) == 5489 and len({row['track_id'] for row in rows}) == 5489
    assert len(prior['cases']) == 24 and len({row['artist_id'] for row in prior['cases']}) == 24
    excluded_artists = {row['artist_id'] for row in prior['cases']}
    existing = [row for row in rows if row['eligible']]
    independent = [row for row in existing if row['artist_id'] not in excluded_artists]
    candidates = [row for row in rows if row['artist_id'] not in excluded_artists and
        row['artist_id'] is not None and 30 <= row['duration_metadata_seconds'] <= 600 and
        row['top_genres'] and canonical_candidate(row['license_url'])]
    for pool in (independent, candidates):
        assert not excluded_artists.intersection(row['artist_id'] for row in pool)
        assert not {row['track_id'] for row in prior['cases']}.intersection(row['track_id'] for row in pool)
        assert all(type(row['reference_class']) is int and 0 <= row['reference_class'] < 24 for row in pool)
    # Explicit wrong-domain/credentials/restriction cases must never expand the pool.
    for url in ('https://creativecommons.org.evil.test/licenses/by-sa/4.0/',
        'https://attacker@creativecommons.org/licenses/by/4.0/',
        'https://creativecommons.org/licenses/by-nc/4.0/',
        'https://creativecommons.org/licenses/by-nd/4.0/',
        'https://creativecommons.org/licenses/by-sa/4.0/?redirect=elsewhere'):
        assert not canonical_candidate(url)
    report = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
        scope='Existing public metadata only; no new media, model, CPU corpus, player, GPU or audio-output run',
        inputs=[catalogue_pin, prior_pin], prior_sample_tracks=24, prior_sample_artists=24,
        originally_eligible_tracks=len(existing), originally_eligible_artists=len({row['artist_id'] for row in existing}),
        existing_filter_artist_disjoint_pool=summarize(independent),
        prospective_canonical_BY_SA_and_BY_3_US_metadata_pool=summarize(candidates),
        prospective_filter_is_not_media_admission=True,
        primary_license_references=['https://creativecommons.org/licenses/by-sa/3.0/',
            'https://creativecommons.org/licenses/by-sa/4.0/', 'https://creativecommons.org/licenses/by/3.0/us/'],
        conclusions=[
            'The original licensed pool is concentrated in the already screened artists; excluding their recordings leaves ten key classes without a reference.',
            'The prospective broader metadata screen still lacks class 22 (Bb minor), and has only one artist for classes 8 and 10. It cannot supply two complete artist-disjoint calibration/evaluation folds.',
            'FMAK references remain whole-song keys; they cannot qualify local key-change boundaries.',
            'Fresh recording/artist separation alone does not verify upstream model training membership.',
            'No prediction, confidence threshold, corpus score, production configuration or milestone gate changes.'],
        requirements_before_confidence_qualification=['Separate calibration and evaluation artists before fitting',
            'Retain absent classes, source failures and Unknown spans explicitly',
            'Admit any new source with its original attribution/license and bounded media checks',
            'Use timestamped local references for local key-change validation'],
        physical_test_readiness_consumed=False, media_downloaded=False, model_started=False,
        policy_or_eligibility_changed=False, hardware_test_started=False, qualified=False)
    path = BASE / 'reference-coverage-01.json'
    with path.open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: report[key] for key in ('originally_eligible_tracks', 'originally_eligible_artists',
        'physical_test_readiness_consumed', 'hardware_test_started', 'qualified')}))
    for name in ('existing_filter_artist_disjoint_pool', 'prospective_canonical_BY_SA_and_BY_3_US_metadata_pool'):
        print(json.dumps(dict(pool=name, **{key: report[name][key] for key in
            ('tracks', 'artists', 'classes_present', 'missing_classes')})))


if __name__ == '__main__':
    main()
