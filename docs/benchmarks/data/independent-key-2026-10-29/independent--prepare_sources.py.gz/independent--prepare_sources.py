"""Freeze a fresh-artist key sample and reuse bounded source-byte admission."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
OLD = ROOT / 'build/m2-fmak-assessment-01/source-admission-01'
SEED = 'conflux-fmak-independent-artists-20261029-v1'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def pin(path):
    raw = path.read_bytes()
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def write(name, value):
    with (BASE / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    audit = load('independent_reference_audit', ROOT / 'build/m2-music-reference-audit-01/audit.py')
    catalogue, catalogue_pin = audit.checked('catalogue-01.json',
        'ae0bc679807fabce8c08073fa335642b389fbf91881b3a7f45235edceeb7ded4')
    prior, prior_pin = audit.checked('selection-plan-02.json',
        'cb1be723751d41049901f0926e5b2d984295089fc8ad4da9defb8daa727a56e4')
    old_artists = {row['artist_id'] for row in prior['cases']}
    pool = [row for row in catalogue['records'] if row['artist_id'] not in old_artists and
        row['artist_id'] is not None and 30 <= row['duration_metadata_seconds'] <= 600 and
        row['top_genres'] and audit.canonical_candidate(row['license_url'])]
    assert len(pool) == 186 and len({row['artist_id'] for row in pool}) == 46
    classes = sorted({row['reference_class'] for row in pool})
    assert classes == [index for index in range(24) if index != 22]
    pools = {index: [] for index in classes}
    def order(row):
        return hashlib.sha256((SEED + ':' + str(row['track_id'])).encode()).digest()
    for row in pool:
        pools[row['reference_class']].append(row)
    for rows in pools.values():
        rows.sort(key=order)
    select = load('previous_artist_matching', OLD / 'select_sample.py').select
    matched = select(pools)
    # Two available classes (Ab/Bb major) share their only artist. Together
    # with absent Bb minor this gives an independent upper bound of 22 classes.
    assert {row['artist_id'] for index in (8,10) for row in pools[index]} == {7473}
    assert len(matched) == 22 and set(matched) == set(range(24)) - {10,22}
    cases = [matched[index] for index in sorted(matched)]
    selected_artists = {row['artist_id'] for row in cases}
    # Two seeded remaining artists fill the 24-recording budget; neither
    # fabricates a missing class or rebalances after predictions.
    extras = sorted((row for row in pool if row['artist_id'] not in selected_artists), key=order)
    assert extras
    for row in extras:
        if row['artist_id'] not in selected_artists:
            cases.append(row)
            selected_artists.add(row['artist_id'])
        if len(cases) == 24:
            break
    assert len(cases) == 24 and len({row['track_id'] for row in cases}) == 24
    assert len({row['artist_id'] for row in cases}) == 24
    assert old_artists.isdisjoint(row['artist_id'] for row in cases)
    assert {row['track_id'] for row in prior['cases']}.isdisjoint(row['track_id'] for row in cases)
    assert all(row in pool for row in cases)
    plan = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
        status='frozen_before_new_media_or_inference', seed=SEED,
        selection='Deterministic maximum artist matching over the candidate classes, then two seeded unused artists; no acoustic, model or prediction selection',
        cases=cases, denominator=24, selected_tracks=24, selected_unique_artists=24,
        class_counts={str(index):sum(row['reference_class']==index for row in cases) for index in range(24)},
        key_class_coverage=dict(present=22,total=24,missing=[dict(index=10,key='Bb major',reason='Shares its only candidate artist with Ab major'),dict(index=22,key='Bb minor',reason='No artist-disjoint source under the recorded license screen')]),
        old_sample_tracks_and_artists_excluded=True, input_pins=[catalogue_pin,prior_pin,pin(Path(__file__)),pin(OLD/'select_sample.py'),pin(ROOT/'build/m2-music-reference-audit-01/audit.py')],
        global_song_key_labels_only=True, local_key_changes_annotated=False,
        upstream_training_membership_verified=False, confidence_calibration=False,
        genres=dict(sorted(Counter(g for row in cases for g in row['top_genres']).items())),
        license_screen='Exact canonical CC-BY/CC0, CC-BY 3.0 US and CC-BY-SA 3.0/4.0 metadata URIs; retain source artist, title, URL and license per case',
        primary_license_sources=['https://creativecommons.org/licenses/by-sa/3.0/','https://creativecommons.org/licenses/by-sa/4.0/','https://creativecommons.org/licenses/by/3.0/us/'],
        audio_redistribution=False, originals_and_derivatives_excluded_from_product_artifacts=True,
        sample_replacement_allowed=False, musical_or_latency_qualification=False,
        product_configuration_changed=False, physical_readiness_required=False)
    write('selection-plan-02.json', plan)
    for name in ('range_media.py','test_range_media.py','record-01.json'):
        (BASE/name).write_bytes((OLD/name).read_bytes())
    original = json.loads((OLD/'media-admission-plan-01.json').read_text())
    original.update(created_at_utc=datetime.now(timezone.utc).isoformat(),
        status='frozen_before_24_fresh_artist_sources',
        input_pins=[pin(BASE/name) for name in ('range_media.py','test_range_media.py','record-01.json','selection-plan-02.json')],
        scope='Only the 24 frozen fresh-artist MP3 members and bounded publisher ZIP ranges; no decode, playback, model, GPU or latency test',
        license_policy=plan['license_screen'], original_artist_exclusion=True,
        key_class_coverage=plan['key_class_coverage'])
    original['limits']['network_bytes'] = 256 * 1024**2
    original['limits']['seconds'] = 600
    write('media-admission-plan-01.json', original)
    for name in ('media-01','media-admission-01.json','source-launch-reservation-01.json'):
        assert not (BASE/name).exists()
    assert shutil.disk_usage(BASE).free > 2 * 1024**3
    result = subprocess.run(['/usr/bin/python3.14','-B',str(BASE/'test_range_media.py')],capture_output=True,text=True,timeout=30)
    (BASE/'range-tests-stdout-01.log').write_text(result.stdout)
    (BASE/'range-tests-stderr-01.log').write_text(result.stderr)
    result.check_returncode()
    dry = subprocess.run(['/usr/bin/python3.14','-B',str(BASE/'range_media.py')],capture_output=True,text=True,timeout=5)
    (BASE/'range-dry-stdout-01.log').write_text(dry.stdout)
    (BASE/'range-dry-stderr-01.log').write_text(dry.stderr)
    dry.check_returncode()
    assert json.loads(dry.stdout)['network_started'] is False
    print(json.dumps(dict(prepared=True, selected_tracks=24, independent_artists=24,
        classes_present=22,missing_classes=['Bb major','Bb minor'],source_download_started=False,model_started=False)))


if __name__ == '__main__':
    main()
