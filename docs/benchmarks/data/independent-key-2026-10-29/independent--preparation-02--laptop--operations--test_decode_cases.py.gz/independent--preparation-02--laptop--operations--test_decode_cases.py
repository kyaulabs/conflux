"""Generated protocol regressions; no music or host workload."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import sys
import tempfile
import subprocess
import unittest
from unittest.mock import patch, Mock

import decode_cases as decode


class DecodeChecks(unittest.TestCase):
    def setUp(self):
        self.case=dict(id='000123',source=dict(bytes=42,sha256='a'*64))
        self.valid=dict(schema=1,case='000123',complete=True,source_sha256='a'*64,
            source_bytes=42,prepared_frames=48000,prepared_pcm_sha256='b'*64,
            sample_rate=48000,channels=2,audio_device_opened=False)

    def test_complete_original_clock_is_retained(self):
        result=decode.validate(self.valid,self.case)
        self.assertEqual(result['prepared_frames'],48000)
        self.assertEqual(result['pcm_sha256'],'b'*64)
        self.assertFalse(result['model_started'])

    def test_wrong_source_or_case_never_becomes_prepared(self):
        for field,value in [('case','000124'),('source_bytes',43),('source_sha256','c'*64),('complete',False)]:
            with self.subTest(field=field),self.assertRaises(ValueError):
                decode.validate(dict(self.valid,**{field:value}),self.case)

    def test_false_numeric_types_and_wrong_clock_are_rejected(self):
        for field,value in [('prepared_frames',True),('prepared_frames',0),('prepared_frames',33554433),
            ('source_bytes',42.0),('sample_rate',44100),('channels',1),('schema',True),('audio_device_opened',True)]:
            with self.subTest(field=field,value=value),self.assertRaises(ValueError):
                decode.validate(dict(self.valid,**{field:value}),self.case)

    def test_invalid_digest_duplicate_fields_and_nonfinite_json_are_rejected(self):
        for digest in ('b'*63,'B'*64,'g'*64):
            with self.assertRaises(ValueError):
                decode.validate(dict(self.valid,prepared_pcm_sha256=digest),self.case)
        for raw in ('{"case":1,"case":2}','{"frames":NaN}','{"frames":Infinity}'):
            with self.assertRaises(ValueError):
                decode.strict_json(raw)

    def test_dry_default_does_not_query_or_open_any_source(self):
        output=io.StringIO()
        with (patch.object(sys,'argv',['fixture']),patch.object(Path,'read_bytes') as read,
            patch.object(decode.subprocess,'Popen') as run,redirect_stdout(output)):
            self.assertEqual(decode.main(),0)
        read.assert_not_called()
        run.assert_not_called()
        self.assertTrue(json.loads(output.getvalue())['unarmed'])

    def test_unproven_child_reap_is_distinct_from_an_ordinary_decode_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            output=Path(temp)
            child=Mock(pid=1234)
            child.poll.return_value=None
            child.wait.side_effect=subprocess.TimeoutExpired(['offline-decoder'],2)
            with (patch.object(decode.subprocess,'Popen',return_value=child),
                patch.object(decode.time,'monotonic',side_effect=[0,65]),
                patch.object(decode.os,'killpg') as killed,self.assertRaises(decode.ChildCleanupError)):
                decode.prepare('/offline-fixture',self.case,output)
            self.assertEqual(killed.call_count,2)

    def test_owner_starts_no_later_case_after_unproven_cleanup(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            plan=root/'plan.json'
            cases=[dict(self.case,id=f'{index:06d}')for index in range(24)]
            plan.write_text(json.dumps(dict(status='frozen_decode_execution',physical_readiness_required=False,
                host='apollo',cases=cases,input_pins=[],binary={'path':'/offline-fixture'})))
            with (patch.object(sys,'argv',['fixture','--owned','--plan',str(plan),'--output',str(root/'output')]),
                patch.dict('os.environ',CONFLUX_PRIVATE_DECODE='1'),patch.object(Path,'exists',return_value=False),
                patch.object(decode,'prepare',side_effect=decode.ChildCleanupError('offline failure')) as prepared,
                self.assertRaises(decode.ChildCleanupError)):
                decode.main()
            self.assertEqual(prepared.call_count,1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
