"""Freeze the unchanged global key recipe against the new artist sample."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
TARGET = BASE/'keyfinder-01'
OLD = BASE.parent/'m2-keyfinder-global-01'
PREP = BASE/'preparation-02'


def pin(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False)+'\n')


def main():
    comparison = json.loads((PREP/'decode-comparison-01.json').read_text())
    assert comparison['both_units_retired'] and comparison['apollo_container_absent']
    assert len(comparison['exact_frame_and_PCM_matches']) == 23 and not comparison['mismatches']
    TARGET.mkdir(mode=0o700)
    runner = (OLD/'run_corpus.py').read_text()
    cleanup = '''class ChildCleanupError(RuntimeError):
 pass

def reap(children):
 failures=[]
 for child in children:
  if child is None or child.poll()is not None:continue
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:child.wait(timeout=2)
  except subprocess.TimeoutExpired:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   try:child.wait(timeout=2)
   except subprocess.TimeoutExpired:failures.append(child.pid)
 if failures:raise ChildCleanupError('Owned pipeline reap not proven: '+str(failures))

'''
    runner = runner.replace('def predict(plan,case,output):', cleanup+'def predict(plan,case,output):')
    inner = '''   finally:
    for child in(producer,consumer):
     if child is not None and child.poll()is None:
      try:os.killpg(child.pid,signal.SIGKILL)
      except ProcessLookupError:pass
      child.wait(timeout=2)
'''
    assert runner.count(inner) == 1
    runner = runner.replace(inner, '   finally:reap((producer,consumer))\n')
    outer = ''' finally:
  for child in(producer,consumer):
   if child is not None and child.poll()is None:
    try:os.killpg(child.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    child.wait(timeout=2)
'''
    assert runner.count(outer) == 1
    runner = runner.replace(outer, ''' finally:
  reap((producer,consumer))
  if spool.exists()and not list(spool.iterdir()):spool.rmdir()
''')
    runner = runner.replace("and not Path('/dev/dri').exists()", "and not Path('/dev/dri').exists()and not Path('/dev/snd').exists()")
    runner = runner.replace('deadline=began+1200', 'deadline=began+1650')
    runner = runner.replace('   except Exception as error:row=', '   except ChildCleanupError:raise\n   except Exception as error:row=')
    runner = runner.replace("status='InferenceFailed',error=", "status='InferenceFailed',model_started=True,error=")
    runner = runner.replace("receipt=dict(schema=1,completed_captures=24", "spool_artifacts=sorted(str(p.relative_to(output))for d in output.glob('spool-*')if d.is_dir()for p in d.rglob('*')if p.is_file()or p.is_symlink())\n receipt=dict(schema=1,PCM_persisted=bool(spool_artifacts),spool_artifacts=spool_artifacts,completed_captures=24")
    runner = runner.replace("all_inferable_sources_completed=all(c['complete']", "all_inferable_sources_completed=not spool_artifacts and all(c['complete']")
    compile(runner, 'fixed-independent-global-corpus', 'exec')
    (TARGET/'run_corpus.py').write_text(runner)
    (TARGET/'test_corpus.py').write_text((OLD/'test_corpus.py').read_text())
    recipe = 'private-keyfinder-2.2.8-stereo-global-stream-v1'
    worker = pin(OLD/'native-build-01/keyfinder-global-worker')
    assert worker['sha256'] == '4f8a35737dc8124c193eb95fe5f5777d568a10340b6f967879545c24a05c45a8'
    for host in ('laptop','apollo'):
        folder = TARGET/host
        folder.mkdir(mode=0o700)
        if host == 'laptop':
            execution = PREP/'laptop/execution/execution-plan.json'
            measured = PREP/'laptop/decode-results/preparation.json'
        else:
            execution = PREP/'apollo-collected-01/execution/execution-plan.json'
            measured = PREP/'apollo-collected-01/decode-results/cases/preparation.json'
        previous = json.loads(execution.read_text())
        prepared = json.loads(measured.read_text())
        assert len(prepared['cases']) == 24 and prepared['PCM_persisted'] is False
        assert [row['id'] for row in prepared['cases']] == [row['id'] for row in previous['cases']]
        cases=[]
        for case,row in zip(previous['cases'], prepared['cases'], strict=True):
            value=dict(id=case['id'], source=case['source'], preparation_status=row['status'])
            if row['status'] == 'PreparedMetadataMeasured':
                assert row['source'] == case['source']
                value.update(prepared_frames=row['prepared_frames'], pcm_sha256=row['pcm_sha256'])
            else:
                assert case['id'] == '003956' and row['model_started'] is False
                value['error']=row['error']
            cases.append(value)
        binary=previous['binary']
        if host=='laptop':assert pin(Path(binary['path'])) == binary
        plan=dict(schema=1,status='frozen_CPU_correctness_only',host=host,recipe=recipe,
            unit='conflux-independent-keyfinder-'+host+'-20261029-01.service',
            physical_readiness_required=False,preparer=binary,
            worker=worker if host=='laptop' else dict(worker,path='/worker/keyfinder-global-worker'),
            cases=cases,fixed_denominator=24,case_seconds=160,owner_seconds=1650,
            reference_labels_in_runtime=False,confidence='Unknown',qualified=False)
        plan['input_pins']=[plan['preparer'],plan['worker']]+[case['source'] for case in cases]
        if host=='laptop':plan['input_pins'] += [pin(TARGET/'run_corpus.py'),pin(TARGET/'test_corpus.py')]
        save(folder/'plan.json', plan)
    save(TARGET/'prospective-01.json',dict(schema=1,
        recipe=recipe,worker=worker,reference=pin(BASE/'selection-plan-02.json'),
        decode_comparison=pin(PREP/'decode-comparison-01.json'),
        fixed_denominator=24,expected_inferable=23,retained_source_failure='003956',
        settings_changed=False,case_replacement_or_transcoding=False,
        scoring_only_after_both_captures_closed_and_owned_units_retired=True,
        artist_disjoint_from_our_prior_24_song_screen=True,
        upstream_training_independence_established=False,
        calibration_or_general_genre_qualification=False,
        hardware_readiness_consumed=False,production_backend_enabled=False))
    print(json.dumps(dict(prepared=True,cases=24,inferable=23,model_started=False)))


if __name__=='__main__':main()
