"""Add the actual decoder header closure in a fresh build attempt, retaining failures."""
import hashlib
import json
from pathlib import Path
import re

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
OLD=BASE/'preparation-01'
DEST=BASE/'preparation-02'
SOURCE=ROOT/'build/m2-prepared-miss-01/player-build-01/source/src'
REMOTE='/srv/conflux-tests/work/fmak-independent-preparation-20261029-02'


def pin(path):
    raw=path.read_bytes()
    assert not path.is_symlink()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


failed=json.loads((OLD/'builds-complete-01.json').read_text())
assert all(not row['passed']for row in failed['hosts'].values())and not failed['source_decoded']
assert not DEST.exists()
DEST.mkdir(mode=0o700)
dependencies={}


def include(path):
    relative=path.relative_to(SOURCE)
    if str(relative)in dependencies:
        return
    raw=path.read_bytes()
    dependencies[str(relative)]=raw
    for name in re.findall(r'^#include "([^"]+)"',raw.decode(),flags=re.M):
        matches=[candidate for candidate in (path.parent/name,SOURCE/name)if candidate.is_file()]
        assert matches,'Missing quoted decoder dependency: '+name
        chosen=matches[0].resolve()
        assert chosen.is_relative_to(SOURCE.resolve())
        include(chosen)


include(SOURCE/'audio/AudioFile.cpp')
include(SOURCE/'audio/AudioFile.hpp')
assert 'audio/RenderCore.hpp'in dependencies
for host in ('laptop','apollo'):
    target=DEST/host
    (target/'source').mkdir(parents=True,mode=0o700)
    (target/'operations').mkdir(mode=0o700)
    for name in ('CMakeLists.txt','prepare_source.cpp','sources.hpp'):
        (target/'source'/name).write_bytes((OLD/host/'source'/name).read_bytes())
    for name,raw in dependencies.items():
        path=target/'source'/name
        path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        path.write_bytes(raw)
    for name in ('decode_cases.py','test_decode_cases.py','build_preparer.py'):
        text=(BASE/name).read_text()
        if name=='build_preparer.py':
            text=text.replace('conflux-independent-preparer-build-laptop-20261029-01.service',
                'conflux-independent-preparer-build-laptop-20261029-02.service')
        (target/'operations'/name).write_text(text)
    plan=json.loads((OLD/host/'operations/plan.json').read_text())
    plan.update(original_host_root=str(target),remote_root=REMOTE,
        previous_failed_build_preserved=True,header_dependency_closure_added=True)
    for field,prefix in [('source_files','source'),('operation_files','operations')]:
        plan[field]=[dict(file=str(path.relative_to(target)),**pin(path))
            for path in sorted((target/prefix).rglob('*'))if path.is_file()]
    (target/'operations/plan.json').write_text(json.dumps(plan,indent=2)+'\n')
report=dict(schema=1,earlier_failed_builds=str(OLD/'builds-complete-01.json'),
    product_decoder_unchanged=True,product_source='48b82030fcf6ab768c4f7b89d65021485cbf9b40',
    added_header_closure=[dict(file=name,**pin(SOURCE/name))for name in dependencies],
    raw_media_reused_without_new_local_copy=True,build_started=False,decode_started=False,
    model_or_audio_started=False,physical_readiness_consumed=False,qualified=False)
(DEST/'header-correction-01.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(prepared=True,decoder_dependency_files=len(dependencies),earlier_builds_retained=True,build_started=False)))
