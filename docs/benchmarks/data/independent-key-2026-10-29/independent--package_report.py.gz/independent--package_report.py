"""Stage a text-only evidence bundle and concise report after both captures close."""
from pathlib import Path
import gzip
import hashlib
import json
from stage_keyfinder import BASE,TARGET,save


def main():
    score=json.loads((TARGET/'scores-01.json').read_text())
    assert score['both_captures_closed_and_units_retired_before_scoring']
    stage=BASE/'report-stage-01';stage.mkdir(mode=0o700)
    data=stage/'data';decoded=stage/'decoded';data.mkdir();decoded.mkdir()
    files=[]
    excluded={'native','media-01','media','__pycache__','report-stage-01','publication-01'}
    for path in sorted(BASE.rglob('*')):
        if not path.is_file()or path.is_symlink():continue
        relative=path.relative_to(BASE)
        if any(part in excluded for part in relative.parts):continue
        if 'source'in relative.parts and path.name not in('CMakeLists.txt','prepare_source.cpp','sources.hpp'):continue
        if path.suffix not in('.json','.py','.log','.cpp','.hpp')and path.name!='CMakeLists.txt':continue
        files.append((path,'independent--'+'--'.join(relative.parts)))
    audit=BASE.parent/'m2-music-reference-audit-01'
    for name in('audit.py','reference-coverage-01.json'):
        files.append((audit/name,'reference-audit--'+name))
    members=[];total=0
    for path,name in files:
        raw=path.read_bytes();raw.decode('utf-8');total+=len(raw)
        assert len(raw)<=2*1024*1024 and total<=12*1024*1024
        encoded=gzip.compress(raw,compresslevel=9,mtime=0)
        output=data/(name+'.gz');assert not output.exists();output.write_bytes(encoded)
        (decoded/name).write_bytes(raw)
        members.append(dict(file=output.name,decoded_file=name,original_path=str(path),
            original_bytes=len(raw),original_sha256=hashlib.sha256(raw).hexdigest(),
            gzip_bytes=len(encoded),gzip_sha256=hashlib.sha256(encoded).hexdigest()))
    save(data/'manifest.json',dict(schema=1,members=members,
        scope='Fixed artist-disjoint global-key screen; text only, no audio/binaries/cache/third-party code',
        classifier_recipe_unchanged=True,source_failure_retained='003956',
        reference_selection_metadata_exposed=True,production_backend_enabled=False,qualified=False))
    for member in members:
        encoded=(data/member['file']).read_bytes();raw=gzip.decompress(encoded)
        assert len(encoded)==member['gzip_bytes']and hashlib.sha256(encoded).hexdigest()==member['gzip_sha256']
        assert len(raw)==member['original_bytes']and hashlib.sha256(raw).hexdigest()==member['original_sha256']
        assert raw==(decoded/member['decoded_file']).read_bytes()
    a=score['hosts']['laptop'];b=score['hosts']['apollo']
    assert a['global_exact']==b['global_exact']and a['estimated_subset']==b['estimated_subset']
    count=a['global_exact']['matches'];subset=a['estimated_subset']['percent'];overall=a['global_exact']['percent']
    report=f'''# Independent-artist global key screen

The unchanged whole-track KeyFinder recipe matched {count} of 23 decoded tracks
on each host ({subset:.2f}%), or {count} of the original 24 selections ({overall:.2f}%)
with the rejected MP3 retained. All 23 emitted prediction files were byte-identical
across hosts. This new artist sample provides no calibrated confidence or
local key-change truth. The production key backend
stays disabled, confidence stays Unknown, and M2/M3 and release gates remain open.

| Host | Exact matches among decoded tracks | Original denominator | Source failures |
| --- | ---: | ---: | ---: |
| Laptop | {count}/23 | {count}/24 | 1 |
| Apollo | {count}/23 | {count}/24 | 1 |

The selection excludes every artist and track in the earlier 24-song FMAK screen.
Its seed, `conflux-fmak-independent-artists-20261029-v1`, was fixed before audio
acquisition. Selection used metadata, class coverage and artist identity without
model scores or listening. The original attribution-only license screen left
32 tracks from 23 unused artists covering fourteen global key classes. Including
the recorded CC BY-SA 3.0/4.0 and CC BY 3.0 US license entries gave 186 eligible
tracks from 46 unused artists. The selection retains each track's artist, title,
source URL and license; audio is excluded from this evidence and product artifacts.
The applicable license deeds are linked in the selection record.

Those candidates cover 23 classes, but the only A-flat-major and B-flat-major
candidates share one artist. Matching one artist per class therefore reached
22 classes; two seeded unused artists filled the fixed 24-track sample. The
construction error that initially assumed 23 distinct artists was caught and
retained before the selection froze. B-flat major and B-flat minor are absent.
The later rejected B-minor source leaves 21 classes among the decoded tracks.
This metadata-balanced sample cannot establish general genre accuracy or
independence from an upstream model's training data. Its selection metadata
exposed reference labels; no classifier settings were changed after selection.

All 24 original MP3s passed bounded source admission, ZIP CRC32 and SHA-256 checks.
Two incomplete HTTP range responses were rejected, with the original failures
retained; smaller bounded ranges completed the same sources without replacement.
The first private decoder build omitted a required header and failed on both
hosts. Adding the unchanged product include closure fixed the helper build.
The product audio decoder itself was not modified.

Both hosts decoded 23 sources to exactly the same complete stereo 48 kHz float32
PCM hashes and frame counts. Both rejected `003956`, Miss Derringer's
"Better Run Away From Me," as `Format not recognised`. A header-only FFprobe check
recognized a stereo 44.1 kHz MP3; it does not prove complete decoding or erase the
native failure. This source was neither converted nor substituted. Decoder
durations are CPU correctness observations, without latency qualification.

The [existing stock-profile recipe](keyfinder-global-2026-10-28.md) and pinned
worker binary were reused. Each successful key capture re-decoded the original
source and checked its complete PCM identity before one global decision.
Scoring waited until both captures closed and both owned units were retired.
No reference file was mounted into Apollo's inference container. Byte-identical
emitted predictions compare keys and metadata, not unrecorded internal chroma.

Twelve protocol and process-lifecycle regressions passed on each host before
inference, including timeout, preparation failure, malformed output, full-clock
binding and stopping after unproven child cleanup. The fixed batches retained
every outcome. Both ran with one CPU and 1 GiB limits and no GPU or sound output;
Apollo used only the isolated CONFLUX daemon with no network or devices. Both
units and the private container are retired, with empty cgroups and no retained
PCM. Root-owned service logs initially blocked collection of the earlier decode
batch; a bounded read recovered those exact logs without another decode run.
No power setting, thermal guard, OneDrive state or desktop inhibitor changed.

The [evidence manifest](data/independent-key-2026-10-29/manifest.json) binds
{len(members)} compressed text records: selection and attribution, complete source
and PCM pins, all per-case results, failed acquisition/build/collection attempts,
recipe and protocol code, scoring order and resource cleanup. These software
checks consume no physical client-test readiness and provide no laptop service,
cancellation, physical audio or sustained thermal qualification.
'''
    (stage/'report.md').write_text(report)
    save(stage/'archive-verification-01.json',dict(members=len(members),
        decoded_bytes=total,gzip_bytes=sum(row['gzip_bytes']for row in members),
        all_archive_and_decoded_hashes_verified=True,audio_binaries_or_PCM_included=False))
    print(json.dumps(dict(members=len(members),decoded_bytes=total,gzip_bytes=sum(row['gzip_bytes']for row in members))))


if __name__=='__main__':main()
