"""Launch the frozen CPU-only corpus on both hosts; no hardware qualification."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
import argparse
import json
import subprocess
import time
from stage_keyfinder import TARGET,REMOTE,SSH,pin,save


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--launch',action='store_true');args=parser.parse_args()
    stage=json.loads((TARGET/'stage-complete-01.json').read_text())
    assert stage['local_offline_exit']==stage['apollo']['exit']==0 and stage['apollo']['container_absent']
    assert pin(Path(stage['local_plan']['path']))==stage['local_plan']
    assert pin(Path(stage['prospective']['path']))==stage['prospective']
    plan=json.loads((TARGET/'laptop/plan.json').read_text())
    for row in plan['input_pins']:assert pin(Path(row['path']))==row
    assert not(TARGET/'launch-reservation-01.json').exists()
    if not args.launch:
        print(json.dumps(dict(unarmed=True,input_pins_verified=True,music_model_started=False)));return
    local_unit=plan['unit']
    state=subprocess.check_output(['systemctl','--user','show',local_unit,'--property=LoadState,MainPID'],text=True,timeout=5)
    assert'LoadState=not-found'in state and'MainPID=0'in state
    assert not(TARGET/'laptop/predictions').exists()
    start=time.monotonic()
    save(TARGET/'launch-reservation-01.json',dict(utc=datetime.now(timezone.utc).isoformat(),
        started_monotonic=start,deadline_monotonic=start+1800,no_retry=True,
        scope='Goal-authorized CPU correctness; no GPU, sound output, power changes, sync pause or physical qualification'))
    local=['systemd-run','--user','--unit='+local_unit,'--property=Type=exec',
        '--property=RemainAfterExit=yes','--property=Restart=no','--property=RuntimeMaxSec=1710s',
        '--property=TimeoutStopSec=15s','--property=KillMode=control-group','--property=OOMPolicy=kill',
        '--property=MemoryMax=1G','--property=CPUQuota=100%','--property=Nice=19',
        '--property=TasksMax=128','--property=UMask=0077',
        '--property=StandardOutput=append:'+str(TARGET/'laptop/unit.stdout.log'),
        '--property=StandardError=append:'+str(TARGET/'laptop/unit.stderr.log'),
        '/usr/bin/python3.14','-B',str(TARGET/'run_corpus.py'),'--owned',
        '--plan',str(TARGET/'laptop/plan.json'),'--output',str(TARGET/'laptop/predictions')]
    remote='BASE='+repr(REMOTE)+'\n'+r'''
from pathlib import Path
import hashlib,json,subprocess
base=Path(BASE);plan=json.loads((base/'operations/plan.json').read_text());unit=plan['unit']
state=subprocess.check_output(['systemctl','show',unit,'--property=LoadState,MainPID'],text=True,timeout=5)
assert'LoadState=not-found'in state and'MainPID=0'in state
offline=json.loads((base/'offline-receipt-01.json').read_text())
assert offline['exit']==0 and offline['container_absent']and offline['plan']==plan
mapping={'/operations':base/'operations','/media':Path('/srv/conflux-tests/work/fmak-independent-preparation-20261029-02/media'),
 '/prepare':Path('/srv/conflux-tests/work/fmak-independent-preparation-20261029-02/native'),
 '/worker':Path('/srv/conflux-tests/work/keyfinder-global-20261028-01/native')}
for row in plan['input_pins']:
 p=Path(row['path']);path=mapping['/'+p.parts[1]]/p.name
 assert path.is_file()and not path.is_symlink()and path.stat().st_size==row['bytes']
 with path.open('rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
owner=r"""
from pathlib import Path
import json,signal,subprocess,time
base=Path(BASE);D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
name='conflux-independent-keyfinder-20261029-01';label='independent-keyfinder-20261029-01'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
def interrupted(number,frame):raise InterruptedError('Owned classifier stopped')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
decode=Path('/srv/conflux-tests/work/fmak-independent-preparation-20261029-02')
command=D+['run','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL',
 '--security-opt=no-new-privileges:true','--user=1000:1000','--memory=1g','--cpus=1','--pids-limit=128',
 '--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--env','CONFLUX_PRIVATE_KEY_REFERENCE=1',
 '--env','OMP_NUM_THREADS=1','--env','OPENBLAS_NUM_THREADS=1','--label','org.kyaulabs.conflux.run='+label,
 '--mount','type=bind,src='+str(base/'operations')+',dst=/operations,readonly',
 '--mount','type=bind,src='+str(decode/'media')+',dst=/media,readonly',
 '--mount','type=bind,src='+str(decode/'native/prepare-independent-source')+',dst=/prepare/prepare-independent-source,readonly',
 '--mount','type=bind,src=/srv/conflux-tests/work/keyfinder-global-20261028-01/native/keyfinder-global-worker,dst=/worker/keyfinder-global-worker,readonly',
 '--mount','type=bind,src='+str(base/'results')+',dst=/results',image,
 'python','-B','/operations/run_corpus.py','--owned','--plan','/operations/plan.json','--output','/results/predictions']
first=time.monotonic();result=None;error=None
try:result=subprocess.run(command,timeout=1680)
except BaseException as exception:error=dict(type=type(exception).__name__,message=str(exception)[:1024])
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  value=json.loads(found.stdout)[0]
  assert value['Image']==image and value['Config']['Labels']['org.kyaulabs.conflux.run']==label
  subprocess.run(D+['rm','--force',value['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
 receipt=dict(container_absent=True,exit=None if result is None else result.returncode,error=error,elapsed_seconds=time.monotonic()-first)
 (base/'container-closed-01.json').write_text(json.dumps(receipt,indent=2)+chr(10))
raise SystemExit(0 if result is not None and result.returncode==0 and error is None else 1)
"""
path=base/'owner.py';assert not path.exists();path.write_text('BASE='+repr(BASE)+'\n'+owner)
compile(path.read_text(),'bounded-keyfinder-owner','exec')
command=['sudo','-n','systemd-run','--unit='+unit,'--uid=1000','--gid=1000',
 '--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no',
 '--property=RuntimeMaxSec=1710s','--property=TimeoutStopSec=20s','--property=KillMode=control-group',
 '--property=MemoryMax=2G','--property=TasksMax=256','--property=Nice=19','--property=UMask=0077',
 '--property=StandardOutput=append:'+str(base/'unit.stdout.log'),
 '--property=StandardError=append:'+str(base/'unit.stderr.log'),'/usr/bin/python3','-B',str(path)]
r=subprocess.run(command,capture_output=True,text=True,timeout=15)
(base/'dispatch-01.json').write_text(json.dumps(dict(command=command,exit=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2)+chr(10))
print(json.dumps(dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)));r.check_returncode()
'''
    compile(remote,'keyfinder-remote-dispatch','exec')
    def dispatch(host,command,data=None):
        r=subprocess.run(command,input=data,capture_output=True,text=True,timeout=30)
        row=dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
        save(TARGET/(host+'-dispatch-01.json'),row);return row
    with ThreadPoolExecutor(max_workers=2)as pool:
        left=pool.submit(dispatch,'laptop',local)
        right=pool.submit(dispatch,'apollo',SSH+['python3 -'],remote)
        results=dict(laptop=left.result(),apollo=right.result())
    save(TARGET/'dispatched-01.json',dict(hosts=results,concurrent=True,physical_readiness_consumed=False))
    print(json.dumps(dict(dispatched={host:row['exit']for host,row in results.items()},CPU_correctness_only=True)))
    assert all(row['exit']==0 for row in results.values())


if __name__=='__main__':main()
