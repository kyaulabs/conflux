"""Resume missing frozen source bytes once, retaining the partial publisher response."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
DEST = BASE / 'resume-01'


def pin(path):
    raw = path.read_bytes()
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


def main():
    prior = json.loads((BASE/'media-admission-01.json').read_text())
    closed = json.loads((BASE/'source-closed-01.json').read_text())
    assert closed['service_retired'] and closed['cgroup_absent_or_empty'] and not prior['complete']
    assert prior['audio_files_extracted'] == 8 and prior['error']['detail'] == 'Truncated or oversized remote range'
    assert not DEST.exists()
    DEST.mkdir(mode=0o700)
    originals = [pin(BASE/'media-admission-01.json'),pin(BASE/'source-closed-01.json')]
    for row in prior['sources']:
        if row['status'] == 'SourceBytesAdmitted':
            actual = pin(Path(row['path']))
            assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['SHA256']
            originals.append(actual)
    for name in ('selection-plan-02.json','record-01.json'):
        (DEST/name).write_bytes((BASE/name).read_bytes())
    (DEST/'prior-admission.json').write_bytes((BASE/'media-admission-01.json').read_bytes())
    text = (BASE/'range_media.py').read_text()
    text = once(text,'MAX_MEMBER = 32*1024**2','MAX_MEMBER = 32*1024**2\nMAX_HTTP_RANGE = 4*1024**2')
    marker = '    def read(self, size=-1):\n'
    methods = '''    def read(self, size=-1):
        self._checkClosed()
        if size is None:
            size = -1
        if type(size) is not int or size < -1:
            raise ValueError('Invalid remote read extent')
        count = self.size-self.position if size == -1 else min(size,self.size-self.position)
        if count > MAX_MEMBER or self.budget.bytes+count+1 > self.budget.byte_limit:
            raise ValueError('Remote request exceeds the frozen byte budget')
        chunks = []
        while count:
            amount = min(MAX_HTTP_RANGE,count)
            chunks.append(self._read_one(amount))
            count -= amount
        return b''.join(chunks)

    def _read_one(self, size=-1):
'''
    text = once(text,marker,methods)
    text = once(text,"raise ValueError('Truncated or oversized remote range')",
        "raise ValueError(f'Truncated or oversized remote range: offset={start}, expected={count}, received={len(raw)}')")
    text = once(text,"    archives = {}\n    error = None",
        "    prior=json.loads((BASE/'prior-admission.json').read_text())\n    assert [r['track_id']for r in prior['sources']]==[r['track_id']for r in cases]\n    reused=0\n    archives = {}\n    error = None")
    text = once(text,"                budget.check()\n                prefix = case['track_id']//1000",
        "                budget.check()\n                old=prior['sources'][offset]\n                if old['status']=='SourceBytesAdmitted':\n                    existing=Path(old['path']);data=existing.read_bytes()\n                    assert not existing.is_symlink() and len(data)==old['bytes'] and hashlib.sha256(data).hexdigest()==old['SHA256']\n                    records[offset]=dict(old,reused_from_prior_verified_admission=True);reused+=1\n                    continue\n                records[offset]['status']='SourceAttempted'\n                prefix = case['track_id']//1000")
    text = once(text,"        error = dict(type=type(caught).__name__, detail=str(caught)[:1000])",
        "        error = dict(type=type(caught).__name__, detail=str(caught)[:1000])\n        for record in records:\n            if record['status']=='SourceAttempted':record.update(status='SourceAdmissionFailed',error=error)")
    text = once(text,"        audio_decoded=False, audio_played=False, model_started=False, GPU_started=False,",
        "        reused_from_prior_admission=reused,new_audio_files_extracted=sum(r['status']=='SourceBytesAdmitted' and not r.get('reused_from_prior_verified_admission',False) for r in records),\n        audio_decoded=False, audio_played=False, model_started=False, GPU_started=False,")
    (DEST/'range_media.py').write_text(text)
    tests = (BASE/'test_range_media.py').read_text()
    marker = "    def test_ignored_range_rejected_without_body_read(self):\n"
    additional = '''    def test_bounded_chunks_preserve_full_read_and_exact_offsets(self):
        data=b'0123456789ab'
        requested=[]
        def respond(request, timeout):
            start,end=map(int,re.fullmatch(r'bytes=(\\d+)-(\\d+)',request.get_header('Range')).groups())
            requested.append((start,end))
            return Response(data[start:end+1],start,end,len(data))
        with patch('range_media.MAX_HTTP_RANGE',4),patch('range_media.urllib.request.urlopen',side_effect=respond):
            reader=RangeFile('https://example.invalid/a',len(data),Budget())
            self.assertEqual(reader.read(10),data[:10])
            self.assertEqual(reader.tell(),10)
        self.assertEqual(requested,[(0,3),(4,7),(8,9)])

    def test_a_partial_chunk_is_rejected_without_retry_or_following_chunk(self):
        def respond(request,timeout):
            start,end=map(int,re.fullmatch(r'bytes=(\\d+)-(\\d+)',request.get_header('Range')).groups())
            return Response(b'0123'if start==0 else b'01',start,end,12)
        with patch('range_media.MAX_HTTP_RANGE',4),patch('range_media.urllib.request.urlopen',side_effect=respond)as called:
            reader=RangeFile('https://example.invalid/a',12,Budget())
            with self.assertRaisesRegex(ValueError,'offset=4, expected=4, received=2'):
                reader.read(10)
            self.assertEqual(reader.tell(),4)
            self.assertEqual(called.call_count,2)

'''
    (DEST/'test_range_media.py').write_text(once(tests,marker,additional+marker))
    plan = json.loads((BASE/'media-admission-plan-01.json').read_text())
    plan.update(created_at_utc=datetime.now(timezone.utc).isoformat(),status='frozen_explicit_missing_source_resume',
        input_pins=originals+[pin(DEST/name)for name in ('range_media.py','test_range_media.py','selection-plan-02.json','record-01.json','prior-admission.json')],
        scope='Reuse the eight checksum-verified sources and fetch only the sixteen remaining original selections with <=4 MiB HTTP ranges. No case replacement, inference or audio.',
        original_failure_retained=True,missing_sources_resume=True,already_admitted_sources_refetched=False)
    plan['limits']['seconds']=1200
    plan['limits']['max_range_bytes']=4*1024**2
    (DEST/'media-admission-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
    tests = subprocess.run(['/usr/bin/python3.14','-B',str(DEST/'test_range_media.py')],capture_output=True,text=True,timeout=30)
    (DEST/'range-tests-stdout-01.log').write_text(tests.stdout)
    (DEST/'range-tests-stderr-01.log').write_text(tests.stderr)
    tests.check_returncode()
    dry = subprocess.run(['/usr/bin/python3.14','-B',str(DEST/'range_media.py')],capture_output=True,text=True,timeout=5)
    (DEST/'range-dry-stdout-01.log').write_text(dry.stdout)
    (DEST/'range-dry-stderr-01.log').write_text(dry.stderr)
    dry.check_returncode()
    assert json.loads(dry.stdout)['network_started'] is False
    print(json.dumps(dict(prepared=True,original_fixed_cases=24,prior_verified_sources=8,missing_sources=16,
        max_HTTP_range_bytes=4*1024**2,checks=8,source_download_started=False,model_started=False)))


if __name__ == '__main__':
    main()
