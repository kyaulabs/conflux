"""Offline regressions for exact range handling; synthetic bytes, no music."""
import io
import re
import time
import unittest
from unittest.mock import patch
import zipfile

from range_media import Budget, MAX_MEMBER, RangeFile


class Response(io.BytesIO):
    def __init__(self, data, start, end, total, status=206, encoding=None, length=None):
        super().__init__(data)
        self.status = status
        self.headers = {'Content-Range':f'bytes {start}-{end}/{total}',
                        'Content-Length':str(end-start+1) if length is None else length}
        if encoding:
            self.headers['Content-Encoding'] = encoding
        self.read_calls = 0

    def read(self, size=-1):
        self.read_calls += 1
        return super().read(size)


class RangeChecks(unittest.TestCase):
    def test_zip64_member_roundtrip_and_exact_EOF(self):
        raw = io.BytesIO()
        payload = b'generated archive bytes; not audio'*32
        with zipfile.ZipFile(raw, 'w', zipfile.ZIP_DEFLATED) as archive:
            with archive.open('000/000010.mp3', 'w', force_zip64=True) as output:
                output.write(payload)
        data = raw.getvalue()
        def respond(request, timeout):
            match = re.fullmatch(r'bytes=(\d+)-(\d+)', request.get_header('Range'))
            start, end = map(int, match.groups())
            return Response(data[start:end+1], start, end, len(data))
        budget = Budget()
        with patch('range_media.urllib.request.urlopen', side_effect=respond):
            with RangeFile('https://example.invalid/a.zip', len(data), budget) as reader:
                with zipfile.ZipFile(reader) as archive:
                    self.assertEqual(archive.read('000/000010.mp3'), payload)
                reader.seek(0, io.SEEK_END)
                calls = len(budget.requests)
                self.assertEqual(reader.read(), b'')
                self.assertEqual(len(budget.requests), calls)
            with self.assertRaises(ValueError):
                reader.read(1)

    def test_bounded_chunks_preserve_full_read_and_exact_offsets(self):
        data=b'0123456789ab'
        requested=[]
        def respond(request, timeout):
            start,end=map(int,re.fullmatch(r'bytes=(\d+)-(\d+)',request.get_header('Range')).groups())
            requested.append((start,end))
            return Response(data[start:end+1],start,end,len(data))
        with patch('range_media.MAX_HTTP_RANGE',4),patch('range_media.urllib.request.urlopen',side_effect=respond):
            reader=RangeFile('https://example.invalid/a',len(data),Budget())
            self.assertEqual(reader.read(10),data[:10])
            self.assertEqual(reader.tell(),10)
        self.assertEqual(requested,[(0,3),(4,7),(8,9)])

    def test_a_partial_chunk_is_rejected_without_retry_or_following_chunk(self):
        def respond(request,timeout):
            start,end=map(int,re.fullmatch(r'bytes=(\d+)-(\d+)',request.get_header('Range')).groups())
            return Response(b'0123'if start==0 else b'01',start,end,12)
        with patch('range_media.MAX_HTTP_RANGE',4),patch('range_media.urllib.request.urlopen',side_effect=respond)as called:
            reader=RangeFile('https://example.invalid/a',12,Budget())
            with self.assertRaisesRegex(ValueError,'offset=4, expected=4, received=2'):
                reader.read(10)
            self.assertEqual(reader.tell(),4)
            self.assertEqual(called.call_count,2)

    def test_ignored_range_rejected_without_body_read(self):
        response = Response(b'wrong full response', 0, 9, 100, status=200)
        with patch('range_media.urllib.request.urlopen', return_value=response):
            with self.assertRaisesRegex(ValueError, 'ignored'):
                RangeFile('https://example.invalid/a', 100, Budget()).read(10)
        self.assertEqual(response.read_calls, 0)

    def test_wrong_offset_total_encoding_or_length_rejected(self):
        for response in (Response(b'0123456789', 1, 10, 100),
                         Response(b'0123456789', 0, 9, 101),
                         Response(b'0123456789', 0, 9, 100, encoding='gzip'),
                         Response(b'0123456789', 0, 9, 100, length='11')):
            with self.subTest(headers=response.headers), patch('range_media.urllib.request.urlopen', return_value=response):
                with self.assertRaises(ValueError):
                    RangeFile('https://example.invalid/a', 100, Budget()).read(10)
                self.assertEqual(response.read_calls, 0)

    def test_short_or_oversized_body_rejected(self):
        for data in (b'123456789', b'12345678901'):
            with self.subTest(size=len(data)), patch('range_media.urllib.request.urlopen', return_value=Response(data, 0, 9, 100)):
                with self.assertRaisesRegex(ValueError, 'Truncated or oversized'):
                    RangeFile('https://example.invalid/a', 100, Budget()).read(10)

    def test_invalid_seek_and_read_caps_do_not_start_network(self):
        with patch('range_media.urllib.request.urlopen') as network:
            reader = RangeFile('https://example.invalid/a', MAX_MEMBER+10, Budget())
            for offset in (-1, MAX_MEMBER+11):
                with self.assertRaises(ValueError):
                    reader.seek(offset)
            for size in (-2, MAX_MEMBER+1, -1):
                with self.assertRaises(ValueError):
                    reader.read(size)
            with self.assertRaises(ValueError):
                RangeFile('https://example.invalid/a', 100, Budget(byte_limit=9)).read(10)
            network.assert_not_called()

    def test_original_deadline_and_request_count_enforced(self):
        with patch('range_media.urllib.request.urlopen') as network:
            budget = Budget()
            budget.deadline = time.monotonic()-1
            with self.assertRaises(TimeoutError):
                RangeFile('https://example.invalid/a', 100, budget).read(1)
            budget = Budget()
            budget.requests = [{}]*256
            with self.assertRaises(ValueError):
                RangeFile('https://example.invalid/a', 100, budget).read(1)
            network.assert_not_called()


if __name__ == '__main__':
    unittest.main()
