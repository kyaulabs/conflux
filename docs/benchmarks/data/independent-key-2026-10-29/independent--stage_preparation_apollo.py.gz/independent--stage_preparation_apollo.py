"""Stream verified decode inputs into a new private Apollo directory; no test starts."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

BASE=Path(__file__).resolve().parent
PREP=BASE/'preparation-01'
REMOTE='/srv/conflux-tests/work/fmak-independent-preparation-20261029-01'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
    '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
    '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']


def pin(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb')as stream:
        digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(bytes=path.stat().st_size,sha256=digest)


def main():
    assert not (PREP/'apollo-staging-complete-01.json').exists()
    inputs=[]
    for prefix in ('source','operations'):
        for path in sorted((PREP/'apollo'/prefix).rglob('*')):
            if path.is_file():inputs.append((str(path.relative_to(PREP/'apollo')),path))
    admission=json.loads((BASE/'source-admission-complete-01.json').read_text())
    assert admission['source_bytes_complete']
    for row in admission['sources']:
        path=Path(row['path'])
        assert pin(path)=={key:row[key]for key in ('bytes','sha256')}
        inputs.append(('media/'+row['id']+'.mp3',path))
    manifest=[dict(file=name,**pin(path))for name,path in inputs]
    assert len({row['file']for row in manifest})==len(manifest)
    assert sum(row['bytes']for row in manifest)<256*1024**2
    receive=r'''
from pathlib import Path,PurePosixPath
import hashlib,json,sys,tarfile
base=Path(ROOTPATH)
expected={row['file']:row for row in SPEC}
seen=set()
assert not (base/'input-transfer-complete.json').exists()
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|')as archive:
 for member in archive:
  name=PurePosixPath(member.name)
  assert member.isfile()and not name.is_absolute()and '..'not in name.parts and member.name in expected and member.name not in seen
  row=expected[member.name];assert member.size==row['bytes']and member.size<=32*1024**2
  stream=archive.extractfile(member);raw=stream.read(member.size+1)
  assert len(raw)==member.size and hashlib.sha256(raw).hexdigest()==row['sha256']
  path=base/member.name;path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
  with path.open('xb')as output:output.write(raw)
  seen.add(member.name)
assert seen==set(expected)
result=dict(schema=1,files=len(seen),source_files=24,total_bytes=sum(row['bytes']for row in SPEC),all_hashes_verified=True,reference_labels_transferred=False,decode_started=False)
(base/'input-transfer-complete.json').write_text(json.dumps(result,indent=2)+chr(10))
print(json.dumps(result))
'''
    receiver='ROOTPATH='+repr(REMOTE)+'\nSPEC='+repr(manifest)+'\n'+receive
    bootstrap='ROOTPATH='+repr(REMOTE)+'\nRECEIVER='+repr(receiver)+'\n'+r'''
from pathlib import Path
import json,shutil
base=Path(ROOTPATH)
assert base.parent.resolve()==base.parent and not base.exists()
assert shutil.disk_usage(base.parent).free>1024**3
base.mkdir(mode=0o700)
(base/'receive_inputs.py').write_text(RECEIVER)
(base/'receive_inputs.py').chmod(0o700)
print(json.dumps(dict(prepared=True,decode_started=False)))
'''
    result=subprocess.run(SSH+['python3 -'],input=bootstrap,capture_output=True,text=True,timeout=20)
    (PREP/'apollo-bootstrap.stdout.log').write_text(result.stdout)
    (PREP/'apollo-bootstrap.stderr.log').write_text(result.stderr)
    result.check_returncode()
    with (PREP/'apollo-transfer.stdout.log').open('x')as out,(PREP/'apollo-transfer.stderr.log').open('x')as err:
        process=subprocess.Popen(SSH+['python3 '+REMOTE+'/receive_inputs.py'],stdin=subprocess.PIPE,stdout=out,stderr=err)
        try:
            with tarfile.open(fileobj=process.stdin,mode='w|')as archive:
                for name,path in inputs:
                    info=tarfile.TarInfo(name);info.size=path.stat().st_size;info.mode=0o600
                    with path.open('rb')as stream:archive.addfile(info,stream)
            process.stdin.close()
            code=process.wait(timeout=600)
        finally:
            if process.poll()is None:
                process.kill();process.wait(timeout=5)
    assert code==0,(PREP/'apollo-transfer.stderr.log').read_text()
    transferred=json.loads((PREP/'apollo-transfer.stdout.log').read_text())
    assert transferred['all_hashes_verified']and transferred['files']==len(manifest)
    receipt=dict(schema=1,remote_root=REMOTE,manifest=manifest,remote=transferred,
        source_staging_only=True,reference_labels_excluded=True,model_or_audio_started=False)
    (PREP/'apollo-staging-complete-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(staged=True,files=len(manifest),bytes=transferred['total_bytes'],decode_started=False)))


if __name__=='__main__':
    main()
