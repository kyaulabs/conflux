"""Score frozen complete captures; keep the original 24-song denominator."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
import importlib.util
import json
from stage_keyfinder import TARGET,pin,save


def main():
    prospective=json.loads((TARGET/'prospective-01.json').read_text())
    closed=json.loads((TARGET/'both-closed-before-scoring-01.json').read_text())
    assert closed['both_units_retired']and closed['apollo_container_absent']
    cleanup=json.loads((TARGET/'original-cgroup-audit-01.json').read_text())
    assert all(row['unit_absent']and not any(row['remaining_members'].values())for row in cleanup.values())
    assert not(TARGET/'scores-01.json').exists()
    spec=importlib.util.spec_from_file_location('frozen_global_protocol',TARGET/'run_corpus.py')
    protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
    predictions={};raw_predictions={};statuses={};case_lists={}
    for host,base,output in (
        ('laptop',TARGET/'laptop',TARGET/'laptop/predictions'),
        ('apollo',TARGET/'apollo-collected-01',TARGET/'apollo-collected-01/results/predictions')):
        plan=json.loads((base/('plan.json'if host=='laptop'else'operations/plan.json')).read_text())
        case_lists[host]=plan['cases']
        raw=(output/'predictions-before-scoring.json').read_bytes()
        assert hashlib.sha256(raw).hexdigest()==closed['hosts'][host]['captures_sha256']
        captures=protocol.strict_json(raw)
        assert len(captures)==24 and [row['id']for row in captures]==[row['id']for row in plan['cases']]
        predictions[host]={};raw_predictions[host]={};statuses[host]={}
        for case,capture in zip(plan['cases'],captures,strict=True):
            identifier=case['id'];statuses[host][identifier]=capture['status']
            if case['preparation_status']!='PreparedMetadataMeasured':
                assert identifier=='003956'and capture['status']=='SourcePreparationFailed'
                assert capture['complete']is False and capture['model_started']is False and capture['error']==case['error']
                predictions[host][identifier]=None;continue
            assert capture['status']=='PredictionCaptured'and capture['complete']is True
            assert capture['producer_reaped']and capture['consumer_reaped']and capture['spool_empty']
            assert capture['prediction_file']==identifier+'-prediction.json'
            raw=(output/capture['prediction_file']).read_bytes()
            assert len(raw)<=16384 and hashlib.sha256(raw).hexdigest()==capture['prediction_sha256']
            source=protocol.strict_json((output/(identifier+'-source.json')).read_bytes())
            assert source==capture['source']
            result=protocol.validate(protocol.strict_json(raw),source,case)
            assert result==capture['predicted_class']
            predictions[host][identifier]=result;raw_predictions[host][identifier]=raw
    assert [case['id']for case in case_lists['laptop']]==[case['id']for case in case_lists['apollo']]
    # Selection metadata necessarily exposed global labels before the screen.
    # No model settings were tuned, and scoring happens only after both captures close.
    reference=prospective['reference'];assert pin(Path(reference['path']))==reference
    selected=protocol.strict_json(Path(reference['path']).read_bytes())
    truth={f"{row['track_id']:06d}":row['reference_class']for row in selected['cases']}
    assert len(truth)==24 and set(truth)==set(predictions['laptop'])
    assert len({row['artist_id']for row in selected['cases']})==24
    results={}
    for host,values in predictions.items():
        rows=[dict(id=case['id'],reference_class=truth[case['id']],predicted_class=values[case['id']],
            match=values[case['id']]is not None and values[case['id']]==truth[case['id']],
            status=statuses[host][case['id']],confidence='Unknown')for case in case_lists[host]]
        correct=sum(row['match']for row in rows);estimated=sum(row['predicted_class']is not None for row in rows)
        results[host]=dict(cases=rows,global_exact=dict(matches=correct,denominator=24,percent=correct/24*100),
            estimated_subset=dict(matches=correct,denominator=estimated,percent=correct/estimated*100 if estimated else None),
            source_preparation_failures=sum(row['status']=='SourcePreparationFailed'for row in rows),
            confidence='Unknown',qualified=False)
    ready={case['id']for case in case_lists['laptop']if case['preparation_status']=='PreparedMetadataMeasured'}
    identical=[identifier for identifier in ready if raw_predictions['laptop'][identifier]==raw_predictions['apollo'][identifier]]
    differences=sorted(ready-set(identical))
    report=dict(schema=1,scored_at_utc=datetime.now(timezone.utc).isoformat(),recipe=prospective['recipe'],
        worker=prospective['worker'],reference=reference,hosts=results,fixed_denominator=24,
        cross_host_byte_identical_prediction_count=len(identical),cross_host_prediction_differences=differences,
        inferred_per_host=23,selected_artist_count=24,selected_key_class_count=22,prepared_key_class_count=21,
        missing_prepared_classes=[10,22,23],both_captures_closed_and_units_retired_before_scoring=True,
        selection_metadata_exposed_labels=True,model_or_recipe_changed_after_labels=False,
        source_failure_retained='003956',case_replacement_or_transcoding=False,
        confidence='Unknown',qualified=False,production_key_backend_enabled=False,
        upstream_training_independence_established=False,local_key_changes_qualified=False,
        confidence_calibration_or_general_genre_qualification=False,hardware_or_latency_qualified=False,
        milestone_or_release_gate_closed=False)
    save(TARGET/'scores-01.json',report)
    print(json.dumps(dict(hosts={host:{key:row[key]for key in('global_exact','estimated_subset')}for host,row in results.items()},
        identical_predictions=len(identical),prediction_differences=differences,source_failures=1,qualified=False),indent=2))


if __name__=='__main__':main()
