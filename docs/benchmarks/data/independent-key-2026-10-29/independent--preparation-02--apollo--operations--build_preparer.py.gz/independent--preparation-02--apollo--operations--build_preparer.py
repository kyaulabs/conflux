"""Build the pinned decode helper and check rejection paths; unarmed by default."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile


def pin(path):
    raw=path.read_bytes()
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--owned',action='store_true')
    parser.add_argument('--source',type=Path)
    parser.add_argument('--build',type=Path)
    parser.add_argument('--operations',type=Path)
    parser.add_argument('--receipt',type=Path)
    args=parser.parse_args()
    if not args.owned:
        print(json.dumps(dict(unarmed=True,compiler_started=False,source_decoded=False)))
        return 0
    source,build,operations=args.source,args.build,args.operations
    plan=json.loads((operations/'plan.json').read_text())
    assert plan['status']=='frozen_decode_correctness_only'
    if plan['host']=='laptop':
        assert any(line.endswith('/conflux-independent-preparer-build-laptop-20261029-02.service')
            for line in Path('/proc/self/cgroup').read_text().splitlines())
    else:
        assert plan['host']=='apollo' and os.environ.get('CONFLUX_PRIVATE_DECODE_BUILD')=='1'
        assert not any(Path(path).exists()for path in ('/dev/nvidia0','/dev/dri','/dev/snd'))
    for row in plan['source_files']+plan['operation_files']:
        prefix,relative=row['file'].split('/',1)
        path=(source if prefix=='source' else operations)/relative
        actual=pin(path)
        assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],str(path)
    assert not (build/'build.ninja').exists()
    build.mkdir(mode=0o700,exist_ok=True)
    environment=os.environ.copy()
    for name in ('CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LD_PRELOAD','LD_LIBRARY_PATH'):
        environment.pop(name,None)
    for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
        environment[name]='1'
    steps=[]
    commands=[['cmake','-S',str(source),'-B',str(build),'-G','Ninja',
        '-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DCMAKE_CXX_COMPILER=/usr/bin/c++'],
        ['cmake','--build',str(build),'-j','1']]
    for index,command in enumerate(commands):
        result=subprocess.run(command,env=environment,capture_output=True,text=True,timeout=180)
        (build/('build-step-'+str(index)+'.stdout.log')).write_text(result.stdout)
        (build/('build-step-'+str(index)+'.stderr.log')).write_text(result.stderr)
        steps.append(dict(command=command,exit=result.returncode))
        result.check_returncode()
    compiled=subprocess.check_output(['ninja','-C',str(build),'-t','commands'],text=True,env=environment,timeout=5)
    assert '-O2' in compiled and not any(flag in compiled for flag in ('--coverage','-fprofile-arcs','-ftest-coverage','-ffast-math'))
    (build/'compile-commands.txt').write_text(compiled)
    binary=build/'prepare-independent-source'
    rejected=[]
    for command,expected,diagnostic in [([str(binary)],2,'Expected FIXED_CASE_ID'),
        ([str(binary),'999999','/no-spool','--metadata-only'],2,'frozen source whitelist')]:
        result=subprocess.run(command,env=environment,capture_output=True,text=True,timeout=5)
        assert result.returncode==expected and diagnostic in result.stderr and not result.stdout
        rejected.append(dict(command=command,exit=result.returncode,stderr=result.stderr))
    with tempfile.TemporaryDirectory()as temporary:
        spool=Path(temporary)/'public-spool'
        spool.mkdir(mode=0o755)
        spool.chmod(0o755)
        result=subprocess.run([str(binary),plan['cases'][0]['id'],str(spool),'--metadata-only'],
            env=environment,capture_output=True,text=True,timeout=5)
        assert result.returncode==1 and 'owner-only directory' in result.stderr and not result.stdout
        rejected.append(dict(kind='unsafe_spool',exit=result.returncode,stderr=result.stderr))
    tests=subprocess.run(['/usr/bin/python3' if plan['host']=='apollo' else '/usr/bin/python3.14',
        '-B',str(operations/'test_decode_cases.py')],env=environment,cwd=operations,
        capture_output=True,text=True,timeout=15)
    (build/'protocol-tests.stdout.log').write_text(tests.stdout)
    (build/'protocol-tests.stderr.log').write_text(tests.stderr)
    tests.check_returncode()
    assert 'Ran 7 tests' in tests.stderr and tests.stderr.rstrip().endswith('OK')
    versions=subprocess.check_output(['pkg-config','--modversion','Qt6Core','sndfile','samplerate'],text=True,timeout=5)
    libraries=subprocess.check_output(['ldd',str(binary)],text=True,timeout=5)
    assert 'not found' not in libraries
    result=dict(schema=1,host=plan['host'],passed=True,binary=pin(binary),build_steps=steps,
        dependency_versions=versions,linked_libraries=libraries,O2_without_coverage_or_fast_math=True,
        rejection_checks=rejected,protocol_checks=7,source_decoded=False,
        model_started=False,GPU_or_audio_started=False,physical_readiness_consumed=False,qualified=False)
    with args.receipt.open('x')as stream:
        stream.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(host=plan['host'],passed=True,binary=result['binary'],source_decoded=False)))
    return 0


if __name__=='__main__':
    raise SystemExit(main())
