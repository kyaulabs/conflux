"""Freeze data-only decode helpers for both hosts; no build or decoding here."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
DEST = BASE / 'preparation-01'
OLD = ROOT / 'build/m2-fmak-assessment-01/preparation-02'
SOURCE = ROOT / 'build/m2-prepared-miss-01/player-build-01/source/src/audio'
REMOTE = '/srv/conflux-tests/work/fmak-independent-preparation-20261029-01'


def pin(path):
    raw = path.read_bytes()
    assert not path.is_symlink()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    admission = json.loads((BASE/'source-admission-complete-01.json').read_text())
    assert admission['source_bytes_complete'] and admission['selected_tracks'] == 24
    assert json.loads((BASE/'source-unit-retirement-01.json').read_text())['all_source_units_absent']
    for row in admission['sources']:
        assert pin(Path(row['path'])) == {key:row[key]for key in ('path','bytes','sha256')}
    assert not DEST.exists()
    DEST.mkdir(mode=0o700)
    for host in ('laptop','apollo'):
        target = DEST/host
        (target/'source/audio').mkdir(parents=True,mode=0o700)
        (target/'operations').mkdir(mode=0o700)
        for name in ('AudioFile.cpp','AudioFile.hpp'):
            (target/'source/audio'/name).write_bytes((SOURCE/name).read_bytes())
        text = (OLD/'prepare_source.cpp').read_text()
        old = ('    const auto source = std::string("/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-assessment-01/") +\n'
               '        "source-admission-01/media-01/" + argv[1] + ".mp3";')
        assert text.count(old) == 1
        text = text.replace(old,'    const auto source = std::string(found->path);')
        (target/'source/prepare_source.cpp').write_text(text)
        header = '#pragma once\n#include <array>\n#include <cstdint>\n#include <string_view>\n'
        header += 'struct Source { std::string_view id, sha, path; std::uint64_t bytes; };\ninline constexpr std::array<Source,24> sources{{\n'
        cases = []
        for row in admission['sources']:
            source = dict(path=row['path'] if host=='laptop' else '/media/'+row['id']+'.mp3',bytes=row['bytes'],sha256=row['sha256'])
            header += '    {'+', '.join(json.dumps(value) for value in (row['id'],row['sha256'],source['path']))+', '+str(row['bytes'])+'},\n'
            cases.append(dict(id=row['id'],source=source))
        header += '}};\n'
        (target/'source/sources.hpp').write_text(header)
        cmake = '''cmake_minimum_required(VERSION 3.22)
project(conflux_independent_source_preparation LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
find_package(Qt6 REQUIRED COMPONENTS Core)
find_package(PkgConfig REQUIRED)
pkg_check_modules(FilePreparation REQUIRED IMPORTED_TARGET sndfile samplerate)
add_executable(prepare-independent-source prepare_source.cpp audio/AudioFile.cpp)
target_include_directories(prepare-independent-source PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(prepare-independent-source PRIVATE Qt6::Core PkgConfig::FilePreparation)
target_compile_options(prepare-independent-source PRIVATE -Wall -Wextra -Wpedantic)
'''
        (target/'source/CMakeLists.txt').write_text(cmake)
        source_pins = [dict(file=str(path.relative_to(target)),**{key:value for key,value in pin(path).items()if key!='path'})
            for path in sorted((target/'source').rglob('*')) if path.is_file()]
        plan = dict(schema=1,status='frozen_decode_correctness_only',host=host,
            cases=cases,fixed_denominator=24,physical_readiness_required=False,
            source_algorithm='Unchanged product AudioFile.cpp/AudioFile.hpp; private fixed input whitelist path rebinding only',
            product_source='48b82030fcf6ab768c4f7b89d65021485cbf9b40',source_files=source_pins,
            helper_deadline_seconds=60,case_deadline_seconds=64,owner_seconds=1680,
            model_started=False,reference_labels_in_runtime=False,qualified=False,
            original_host_root=str(target),remote_root=REMOTE,
            source_byte_identity_verified=True)
        (target/'operations/plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    receipt = dict(schema=1,recorded_at_utc=datetime.now(timezone.utc).isoformat(),
        source_admission=pin(BASE/'source-admission-complete-01.json'),
        decoder_inputs=[pin(SOURCE/name)for name in ('AudioFile.cpp','AudioFile.hpp')],
        helper_input=pin(OLD/'prepare_source.cpp'),creator=pin(Path(__file__)),
        host_plans={host:pin(DEST/host/'operations/plan.json')for host in ('laptop','apollo')},
        labels_excluded_from_decode_runtime=True,build_started=False,decode_started=False,
        physical_readiness_consumed=False,qualified=False)
    (DEST/'preparation-binding-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(prepared=True,hosts=['laptop','apollo'],fixed_sources=24,
        labels_excluded=True,product_decoder_unchanged=True,build_started=False,decode_started=False)))


if __name__ == '__main__':
    main()
