#pragma once
#include <array>
#include <cstdint>
#include <string_view>
struct Source { std::string_view id, sha, path; std::uint64_t bytes; };
inline constexpr std::array<Source,24> sources{{
    {"108006", "21f4e566569e1dc6893a3690f57528bae32c90474dada01f194c90fecaef3d26", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/media-01/108006.mp3", 6915854},
    {"092761", "3401d2801c90e34371e266061647ad46b3e8665fe8475074f8ae8a3b699be835", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/media-01/092761.mp3", 6860541},
    {"085787", "49962cbd7e77ba925fa3c37f89e8034f85780ab0d4fef281727e8761a27845d0", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/media-01/085787.mp3", 5681030},
    {"051118", "7284dbc46b101801cd00687fdba3415ec6617c232027970474dc5b7785b0b8f6", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/media-01/051118.mp3", 16392456},
    {"003941", "65b932eeef5b02954f55acba3d88284e982692bf4f38c27d939d051e9325a0b7", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/media-01/003941.mp3", 3086648},
    {"055121", "3f7caacb175d0c7e58b01d13ffab0e352b9e46a73ae8e7b3f4a7572b00edfe16", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/media-01/055121.mp3", 8972756},
    {"091473", "365ed817a852d0f30a4a5363335cd1078b1e246c3df4551582a0c8918b79d66b", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/media-01/091473.mp3", 9756409},
    {"052929", "bb67250fab035ce35475dda08bc575b216ed02a341eb87474c49a454647869fe", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/media-01/052929.mp3", 7800632},
    {"083715", "90a0b53f8f951550dff1ee1ff67d99e9b48525455734f3261331a1c405a1eb41", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/083715.mp3", 9288594},
    {"082508", "a56da8b411efadb69c93d484c0c8166c552989c03e030e19c7d6307757ef5f7a", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/082508.mp3", 10238834},
    {"007487", "f21085673534f870abfa1d1cffa5db690fa06b353b8636cc1a502abdbeae68ef", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/007487.mp3", 2941275},
    {"121209", "ca8b760ba863fc1712ea8d72d6a0de2aab8b7f8670ce44d8f2c5ebed46f4eb5d", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/121209.mp3", 12199172},
    {"013090", "6f2450c7f5a9407d018efb38e7733e68d44b7f2e85a018845913af89da4428e7", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/013090.mp3", 4066161},
    {"107503", "8d7dffcfa83d8f0c9eba46da0694c4f06a55feecda8aa4911617b269570c7f0d", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/107503.mp3", 8984089},
    {"039811", "5399a2fd81524b2756df987921ddbc644716a107dcb7690d4560bcac030af347", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/039811.mp3", 11220064},
    {"071504", "e5a8afa59d86a6caac6dafec6e01542816012c8f3c568fbc9a40cf0c61a03356", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/071504.mp3", 13632479},
    {"094357", "c7502b605237fbe935342b54ad5f5f59271fddad5c93ad4eee918b7946c0bfa8", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/094357.mp3", 7509293},
    {"077577", "72f7898507fe0e94fa6440083c895d2c4856d36a5ae22895ef64f1a825d0ca09", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/077577.mp3", 9741890},
    {"103557", "006e9e2b200e0827a068b5592e3a9d65a041fcf3c4f47f6bb3cf91c9e6c5e9de", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/103557.mp3", 10260277},
    {"115681", "f2fe86727409363cde6fbabe9484951b97ddbcb90d41be219fce78419b050d26", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/115681.mp3", 4619238},
    {"084992", "b6bbd154057cdb33d8395ca421d62f93cf903a20208160c19fa8db9c652b7146", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/084992.mp3", 11745260},
    {"003956", "0726cbb2aa7544e5b6dfdaef66d80f0ad9203878d08116a26067602f7e8e09df", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/003956.mp3", 5070848},
    {"098837", "916ff7e696c1edc7116aecb81421692e516c122f37ad253569099e66190b0465", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-01/media-01/098837.mp3", 5535803},
    {"056187", "69187b3d11b2fbe465ccaf79e1d1611da0bd56a771ae687f1efa90badff9f934", "/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-independent-01/resume-last-01/media-01/056187.mp3", 6182324},
}};
