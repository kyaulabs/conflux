"""Build decoder-only helpers concurrently; fixed resources, no media processing."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

BASE=Path(__file__).resolve().parent
PREP=BASE/'preparation-02'
REMOTE='/srv/conflux-tests/work/fmak-independent-preparation-20261029-02'
UNIT='conflux-independent-preparer-build-laptop-20261029-02.service'
IMAGE='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
    '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
    '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']


def show():
    raw=subprocess.check_output(['systemctl','--user','show',UNIT,
        '--property=LoadState,MainPID,InvocationID,ControlGroup,ActiveState,SubState,Result,ExecMainStatus'],text=True,timeout=5)
    return dict(line.split('=',1)for line in raw.splitlines()if '='in line)


def laptop():
    root=PREP/'laptop'
    assert show()['LoadState']=='not-found'
    command=['systemd-run','--user','--unit='+UNIT,'--property=Type=exec','--property=RemainAfterExit=yes',
        '--property=Restart=no','--property=RuntimeMaxSec=240s','--property=TimeoutStopSec=15s',
        '--property=KillMode=control-group','--property=OOMPolicy=kill','--property=MemoryMax=1G',
        '--property=TasksMax=128','--property=CPUQuota=100%','--property=Nice=19','--property=UMask=0077',
        '--property=StandardOutput=append:'+str(root/'build-unit.stdout.log'),
        '--property=StandardError=append:'+str(root/'build-unit.stderr.log'),
        '/usr/bin/python3.14','-B',str(root/'operations/build_preparer.py'),'--owned',
        '--source',str(root/'source'),'--build',str(root/'native'),'--operations',str(root/'operations'),
        '--receipt',str(root/'build-receipt-01.json')]
    result=subprocess.run(command,capture_output=True,text=True,timeout=10)
    (root/'build-dispatch-01.json').write_text(json.dumps(dict(command=command,exit=result.returncode,
        stdout=result.stdout,stderr=result.stderr),indent=2)+'\n')
    result.check_returncode()
    invocation=re.search('invocation ID: ([0-9a-f]{32})',result.stderr).group(1)
    original_group=None
    terminal=None
    try:
        until=time.monotonic()+270
        while True:
            state=show()
            assert state['InvocationID']==invocation
            original_group=original_group or state.get('ControlGroup')
            if state['MainPID']=='0':
                terminal=state
                break
            assert time.monotonic()<until
            time.sleep(1)
        assert terminal['Result']=='success' and terminal['ExecMainStatus']=='0',terminal
        receipt=json.loads((root/'build-receipt-01.json').read_text())
        assert receipt['passed'] and receipt['source_decoded'] is False
        return receipt
    finally:
        state=show()
        assert state['InvocationID']==invocation
        subprocess.run(['systemctl','--user','stop',UNIT],check=True,capture_output=True,text=True,timeout=20)
        after=show()
        if after['LoadState']!='not-found':
            assert after['MainPID']=='0'
            subprocess.run(['systemctl','--user','reset-failed',UNIT],check=True,capture_output=True,text=True,timeout=5)
            after=show()
        assert after['LoadState']=='not-found'and after['MainPID']=='0'
        if original_group:
            cgroup=Path('/sys/fs/cgroup'+original_group)
            assert not cgroup.exists()or not any(path.read_text().strip()for path in cgroup.rglob('cgroup.procs'))
        (root/'build-unit-closed-01.json').write_text(json.dumps(dict(unit=UNIT,invocation=invocation,
            terminal=terminal,after_stop=after,cgroup_absent_or_empty=True),indent=2)+'\n')


def apollo():
    code='BASE='+repr(REMOTE)+'\nIMAGE='+repr(IMAGE)+'\n'+r'''
from pathlib import Path
import hashlib,json,subprocess
base=Path(BASE)
assert json.loads((base/'input-transfer-complete.json').read_text())['all_hashes_verified']
(base/'native').mkdir(mode=0o700)
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
name='conflux-independent-preparer-build-20261029-02'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
command=D+['run','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL',
 '--security-opt=no-new-privileges:true','--user=1000:1000','--memory=1g','--cpus=1','--pids-limit=128',
 '--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--env','CONFLUX_PRIVATE_DECODE_BUILD=1',
 '--label','org.kyaulabs.conflux.run=independent-preparer-build-20261029-02',
 '--mount','type=bind,src='+str(base/'source')+',dst=/src,readonly',
 '--mount','type=bind,src='+str(base/'operations')+',dst=/operations,readonly',
 '--mount','type=bind,src='+str(base/'native')+',dst=/native',IMAGE,
 'python','-B','/operations/build_preparer.py','--owned','--source','/src','--build','/native',
 '--operations','/operations','--receipt','/native/build-receipt-01.json']
try:
 r=subprocess.run(command,capture_output=True,text=True,timeout=240)
 (base/'build.stdout.log').write_text(r.stdout);(base/'build.stderr.log').write_text(r.stderr)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  container=json.loads(found.stdout)[0]
  assert container['Image']==IMAGE and container['Config']['Labels']['org.kyaulabs.conflux.run']=='independent-preparer-build-20261029-02'
  subprocess.run(D+['rm','--force',container['Id']],capture_output=True,check=True,timeout=15)
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
r.check_returncode()
receipt=json.loads((base/'native/build-receipt-01.json').read_text())
assert receipt['passed']and receipt['source_decoded']is False
receipt['container_absent']=True
(base/'build-complete-01.json').write_text(json.dumps(receipt,indent=2)+chr(10))
print(json.dumps(receipt))
'''
    result=subprocess.run(SSH+['python3 -'],input=code,capture_output=True,text=True,timeout=280)
    (PREP/'apollo-build.stdout.log').write_text(result.stdout)
    (PREP/'apollo-build.stderr.log').write_text(result.stderr)
    result.check_returncode()
    return json.loads(result.stdout)


def main():
    assert json.loads((PREP/'apollo-staging-complete-01.json').read_text())['reference_labels_excluded']
    assert not(PREP/'builds-complete-01.json').exists()
    began=time.monotonic()
    results={}
    with ThreadPoolExecutor(max_workers=2)as pool:
        jobs={host:pool.submit(function)for host,function in [('laptop',laptop),('apollo',apollo)]}
        for host,job in jobs.items():
            try:
                results[host]=dict(passed=True,receipt=job.result())
            except BaseException as error:
                results[host]=dict(passed=False,error=dict(type=type(error).__name__,message=str(error)))
    result=dict(schema=1,hosts=results,builds_submitted_concurrently=True,elapsed_seconds=time.monotonic()-began,
        source_decoded=False,model_or_audio_started=False,physical_readiness_consumed=False,qualified=False)
    (PREP/'builds-complete-01.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(hosts={host:row['passed']for host,row in results.items()},elapsed_seconds=result['elapsed_seconds'],source_decoded=False)))
    assert all(row['passed']for row in results.values())


if __name__=='__main__':
    main()
