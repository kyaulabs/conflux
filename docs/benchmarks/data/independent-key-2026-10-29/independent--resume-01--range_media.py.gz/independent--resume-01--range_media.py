"""Read selected public ZIP members with bounded HTTP ranges and stdlib ZIP CRCs."""
from contextlib import ExitStack
from datetime import datetime, timezone
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import resource
import time
import urllib.request
import zipfile
import zlib

BASE = Path(__file__).resolve().parent
MAX_MEMBER = 32*1024**2
MAX_HTTP_RANGE = 4*1024**2


class Budget:
    def __init__(self, seconds=600, byte_limit=384*1024**2):
        self.started = time.monotonic()
        self.deadline = self.started+seconds
        self.byte_limit = byte_limit
        self.bytes = 0
        self.requests = []

    def check(self):
        if time.monotonic() >= self.deadline:
            raise TimeoutError('Original media-admission deadline')
        if len(self.requests) >= 256:
            raise ValueError('Remote range request count exceeds the frozen budget')


class RangeFile(io.RawIOBase):
    def __init__(self, url, size, budget):
        super().__init__()
        self.url, self.size, self.budget, self.position = url, size, budget, 0

    def seekable(self):
        return True

    def readable(self):
        return True

    def tell(self):
        return self.position

    def seek(self, offset, whence=io.SEEK_SET):
        self._checkClosed()
        if type(offset) is not int or whence not in (io.SEEK_SET, io.SEEK_CUR, io.SEEK_END):
            raise ValueError('Invalid remote-file seek')
        target = offset+(self.position if whence == io.SEEK_CUR else self.size if whence == io.SEEK_END else 0)
        if not 0 <= target <= self.size:
            raise ValueError('Remote seek outside published archive')
        self.position = target
        return target

    def read(self, size=-1):
        self._checkClosed()
        if size is None:
            size = -1
        if type(size) is not int or size < -1:
            raise ValueError('Invalid remote read extent')
        count = self.size-self.position if size == -1 else min(size,self.size-self.position)
        if count > MAX_MEMBER or self.budget.bytes+count+1 > self.budget.byte_limit:
            raise ValueError('Remote request exceeds the frozen byte budget')
        chunks = []
        while count:
            amount = min(MAX_HTTP_RANGE,count)
            chunks.append(self._read_one(amount))
            count -= amount
        return b''.join(chunks)

    def _read_one(self, size=-1):
        self._checkClosed()
        if size is None:
            size = -1
        if type(size) is not int or size < -1:
            raise ValueError('Invalid remote read extent')
        count = self.size-self.position if size == -1 else min(size, self.size-self.position)
        if count == 0:
            return b''
        if count > MAX_MEMBER or self.budget.bytes+count+1 > self.budget.byte_limit:
            raise ValueError('Remote request exceeds the frozen byte budget')
        self.budget.check()
        start, end = self.position, self.position+count-1
        request = urllib.request.Request(self.url, headers={
            'Range':f'bytes={start}-{end}', 'Accept-Encoding':'identity',
            'User-Agent':'CONFLUX-M2-research/0.1'})
        raw = bytearray()
        with urllib.request.urlopen(request, timeout=min(20., self.budget.deadline-time.monotonic())) as response:
            if response.status != 206:
                raise ValueError('Publisher ignored the bounded Range request')
            match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
            if not match or tuple(map(int, match.groups())) != (start, end, self.size):
                raise ValueError('Returned Content-Range differs from the published archive')
            if response.headers.get('Content-Encoding') not in (None, 'identity'):
                raise ValueError('Encoded remote ranges are not accepted')
            length = response.headers.get('Content-Length')
            if length is not None and (not length.isdigit() or int(length) != count):
                raise ValueError('Returned range length differs')
            while len(raw) <= count:
                self.budget.check()
                chunk = response.read(min(65536, count+1-len(raw)))
                if not chunk:
                    break
                self.budget.bytes += len(chunk)
                raw.extend(chunk)
            self.budget.check()
            if len(raw) != count:
                raise ValueError(f'Truncated or oversized remote range: offset={start}, expected={count}, received={len(raw)}')
        self.budget.requests.append(dict(url=self.url, first_byte=start, bytes=count,
                                        SHA256=hashlib.sha256(raw).hexdigest()))
        self.position += count
        return bytes(raw)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if not args.run:
        print(json.dumps(dict(status='dry_default', network_started=False, model_started=False)))
        return
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
    plan_raw = (BASE/'media-admission-plan-01.json').read_bytes()
    plan = json.loads(plan_raw)
    for row in plan['input_pins']:
        raw = Path(row['path']).read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('Frozen media admission input differs')
    selection = json.loads((BASE/'selection-plan-02.json').read_text())
    metadata = json.loads((BASE/'record-01.json').read_text())
    cases = selection['cases']
    assert len(cases) == 24 and len({r['track_id'] for r in cases}) == 24
    assert len({r['artist_id'] for r in cases}) == 24
    audio = BASE/'media-01'
    audio.mkdir(mode=0o700)
    budget = Budget(plan['limits']['seconds'], plan['limits']['network_bytes'])
    records = [dict(track_id=r['track_id'], reference_class=r['reference_class'], status='NotAttempted') for r in cases]
    prior=json.loads((BASE/'prior-admission.json').read_text())
    assert [r['track_id']for r in prior['sources']]==[r['track_id']for r in cases]
    reused=0
    archives = {}
    error = None
    try:
        with ExitStack() as owned:
            for offset, case in enumerate(cases):
                budget.check()
                old=prior['sources'][offset]
                if old['status']=='SourceBytesAdmitted':
                    existing=Path(old['path']);data=existing.read_bytes()
                    assert not existing.is_symlink() and len(data)==old['bytes'] and hashlib.sha256(data).hexdigest()==old['SHA256']
                    records[offset]=dict(old,reused_from_prior_verified_admission=True);reused+=1
                    continue
                records[offset]['status']='SourceAttempted'
                prefix = case['track_id']//1000
                bundles = []
                for item in metadata['files']:
                    match = re.fullmatch(r'(\d{3})-(\d{3})\.zip', item['key'])
                    if match and int(match[1]) <= prefix <= int(match[2]):
                        bundles.append(item)
                if len(bundles) != 1:
                    raise ValueError('Selected track does not have one published source archive')
                item = bundles[0]
                key = item['key']
                if key not in archives:
                    remote = owned.enter_context(RangeFile(
                        'https://zenodo.org/records/10719860/files/'+key+'?download=1', item['size'], budget))
                    archives[key] = owned.enter_context(zipfile.ZipFile(remote))
                archive = archives[key]
                filename = f'{case["track_id"]:06d}.mp3'
                matches = [i for i in archive.infolist() if PurePosixPath(i.filename).name == filename]
                if len(matches) != 1:
                    raise ValueError('Selected track member is missing or duplicated')
                member = matches[0]
                path = PurePosixPath(member.filename)
                if (path.is_absolute() or '..' in path.parts or '\\' in member.filename or member.is_dir()
                        or member.flag_bits & 1 or ((member.external_attr >> 16) & 0o170000) == 0o120000
                        or member.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)
                        or not 256 <= member.file_size <= MAX_MEMBER or member.compress_size > MAX_MEMBER):
                    raise ValueError('Selected ZIP member exceeds the admitted data-only geometry')
                with archive.open(member) as stream:
                    data = stream.read(MAX_MEMBER+1)
                budget.check()
                if len(data) != member.file_size or zlib.crc32(data) != member.CRC:
                    raise ValueError('Selected source length or ZIP CRC differs')
                target = audio/filename
                with target.open('xb') as stream:
                    stream.write(data)
                    stream.flush()
                    os.fsync(stream.fileno())
                budget.check()
                records[offset] = dict(track_id=case['track_id'], reference_class=case['reference_class'],
                    status='SourceBytesAdmitted', path=str(target), bytes=len(data), SHA256=hashlib.sha256(data).hexdigest(),
                    archive=key, archive_published_MD5=item['checksum'], full_archive_MD5_computed=False,
                    archive_member=member.filename, ZIP_CRC32=f'{member.CRC:08x}', ZIP_CRC_verified=True,
                    license_url=case['license_url'], artist=case['artist'], title=case['title'])
                print(json.dumps(dict(admitted=offset+1, track_id=case['track_id'], source_bytes=len(data),
                                      transferred_MiB=round(budget.bytes/1024**2,2))), flush=True)
    except Exception as caught:
        error = dict(type=type(caught).__name__, detail=str(caught)[:1000])
        for record in records:
            if record['status']=='SourceAttempted':record.update(status='SourceAdmissionFailed',error=error)
    result = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
        status='all_24_sources_admitted' if error is None else 'source_admission_stopped',
        complete=error is None, error=error, fixed_denominator=24, sources=records,
        source_bytes=sum(r.get('bytes', 0) for r in records), transferred_bytes=budget.bytes,
        elapsed_seconds=time.monotonic()-budget.started, requests=budget.requests,
        plan_SHA256=hashlib.sha256(plan_raw).hexdigest(),
        integrity='HTTPS publisher ranges, exact published archive extent, standard ZIP member CRC and new per-source SHA256 pins. Whole audio-archive MD5s were not computed.',
        audio_files_extracted=sum(r['status'] == 'SourceBytesAdmitted' for r in records),
        reused_from_prior_admission=reused,new_audio_files_extracted=sum(r['status']=='SourceBytesAdmitted' and not r.get('reused_from_prior_verified_admission',False) for r in records),
        audio_decoded=False, audio_played=False, model_started=False, GPU_started=False,
        source_time_or_musical_accuracy_qualified=False, product_configuration_changed=False)
    with (BASE/'media-admission-01.json').open('x') as stream:
        stream.write(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ('status','error','source_bytes','transferred_bytes','elapsed_seconds','audio_files_extracted')}), flush=True)
    if error:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
