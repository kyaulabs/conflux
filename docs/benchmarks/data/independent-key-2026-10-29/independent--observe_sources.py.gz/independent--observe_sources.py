"""Observe and retire only the already-launched bounded source-admission unit."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
UNIT = 'conflux-fmak-independent-source-admission-20261029-01.service'
INVOCATION = 'acaca7a5fd5c44aabdc648a305ba9f42'


def show():
    raw = subprocess.check_output(['systemctl','--user','show',UNIT,
        '--property=LoadState,ActiveState,SubState,MainPID,InvocationID,Result,ExecMainStatus,ControlGroup'],text=True,timeout=5)
    return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


reservation = json.loads((BASE/'source-launch-reservation-01.json').read_text())
assert reservation['unit'] == UNIT and reservation['retries'] is False
last = None
sequence = 0
while True:
    try:
        state = show()
    except subprocess.SubprocessError as error:
        sequence += 1
        save(BASE/f'source-observation-{sequence:03d}.json',dict(query_error=str(error),terminal_not_inferred=True))
        if time.monotonic() > reservation['deadline_monotonic']:
            raise
        time.sleep(10)
        continue
    assert state['InvocationID'] == INVOCATION, 'Never act on a different same-name unit'
    files = sorted((BASE/'media-01').glob('*.mp3'))
    progress = dict(service=state,sources_present=len(files),source_bytes=sum(path.stat().st_size for path in files),
        result_exists=(BASE/'media-admission-01.json').exists())
    if progress != last:
        sequence += 1
        save(BASE/f'source-observation-{sequence:03d}.json',dict(progress,
            observed_at_utc=datetime.now(timezone.utc).isoformat(),observed_monotonic=time.monotonic()))
        print(json.dumps(progress),flush=True)
        last = progress
    if state['MainPID'] == '0':
        break
    if time.monotonic() > reservation['deadline_monotonic']:
        raise TimeoutError('Original source-admission unit remains live; inspect ownership, do not restart')
    time.sleep(10)

cgroup = Path('/sys/fs/cgroup'+state['ControlGroup']) if state.get('ControlGroup') else None
if cgroup and cgroup.exists():
    assert not any(path.read_text().strip() for path in cgroup.rglob('cgroup.procs'))
terminal = state
result_path = BASE/'media-admission-01.json'
result = json.loads(result_path.read_text()) if result_path.exists() else None
validated = []
if result is not None:
    assert len(result['sources']) == 24 and result['transferred_bytes'] <= 256*1024**2
    for row in result['sources']:
        if row['status'] != 'SourceBytesAdmitted':
            continue
        path = Path(row['path'])
        assert path.parent == BASE/'media-01' and not path.is_symlink()
        raw = path.read_bytes()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['SHA256'] and row['ZIP_CRC_verified']
        validated.append(row['track_id'])
    assert len(files) == len(validated) == result['audio_files_extracted']
    assert result['model_started'] is False and result['audio_decoded'] is False

# MainPID=0 and matching invocation are required before stopping the exact unit.
again = show()
assert again['MainPID'] == '0' and again['InvocationID'] == INVOCATION
subprocess.run(['systemctl','--user','stop',UNIT],check=True,capture_output=True,text=True,timeout=15)
after = show()
assert after['MainPID'] == '0'
if cgroup and cgroup.exists():
    assert not any(path.read_text().strip() for path in cgroup.rglob('cgroup.procs'))
receipt = dict(schema=1,unit=UNIT,invocation=INVOCATION,terminal=terminal,after_stop=after,
    service_retired=True,cgroup_absent_or_empty=True,validated_source_ids=validated,
    source_admission_complete=result is not None and result.get('complete') is True,
    failed_or_unattempted_sources=[] if result is None else [row for row in result['sources'] if row['status']!='SourceBytesAdmitted'],
    original_error=None if result is None else result.get('error'),
    no_inference_or_audio=True,physical_test_readiness_consumed=False,qualified=False)
save(BASE/'source-closed-01.json',receipt)
print(json.dumps(receipt),flush=True)
