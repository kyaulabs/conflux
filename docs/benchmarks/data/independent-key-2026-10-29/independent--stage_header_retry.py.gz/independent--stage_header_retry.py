"""Stage only corrected code; verify and reuse Apollo's existing source bytes."""
import base64
import hashlib
import json
from pathlib import Path
import subprocess

BASE=Path(__file__).resolve().parent
PREP=BASE/'preparation-02'
REMOTE='/srv/conflux-tests/work/fmak-independent-preparation-20261029-02'
MEDIA='/srv/conflux-tests/work/fmak-independent-preparation-20261029-01/media'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
    '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
    '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']

files=[]
for prefix in ('source','operations'):
    for path in sorted((PREP/'apollo'/prefix).rglob('*')):
        if path.is_file():
            raw=path.read_bytes()
            files.append(dict(file=str(path.relative_to(PREP/'apollo')),bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest(),raw_base64=base64.b64encode(raw).decode()))
assert sum(row['bytes']for row in files)<512*1024
admission=json.loads((BASE/'source-admission-complete-01.json').read_text())
sources=[{key:row[key]for key in ('id','bytes','sha256')}for row in admission['sources']]
header='BASE='+repr(REMOTE)+'\nMEDIA='+repr(MEDIA)+'\nFILES='+repr(files)+'\nSOURCES='+repr(sources)+'\n'
code=r'''
from pathlib import Path,PurePosixPath
import base64,hashlib,json,os
base=Path(BASE);media=Path(MEDIA)
assert base.parent.resolve()==base.parent and not base.exists()
assert media.resolve()==media
for row in SOURCES:
 path=media/(row['id']+'.mp3');assert path.is_file()and not path.is_symlink()and path.stat().st_size==row['bytes']
 with path.open('rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
base.mkdir(mode=0o700);(base/'media').mkdir(mode=0o700)
for row in SOURCES:os.link(media/(row['id']+'.mp3'),base/'media'/(row['id']+'.mp3'))
for row in FILES:
 name=PurePosixPath(row['file']);assert not name.is_absolute()and '..'not in name.parts
 raw=base64.b64decode(row['raw_base64'],validate=True)
 assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
 path=base/row['file'];path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
 with path.open('xb')as stream:stream.write(raw)
result=dict(schema=1,files=len(FILES),source_files=24,total_bytes=sum(row['bytes']for row in FILES),
 all_hashes_verified=True,existing_media_reused=True,reference_labels_transferred=False,decode_started=False)
(base/'input-transfer-complete.json').write_text(json.dumps(result,indent=2)+chr(10))
print(json.dumps(result))
'''
result=subprocess.run(SSH+['python3 -'],input=header+code,capture_output=True,text=True,timeout=30)
(PREP/'apollo-transfer.stdout.log').write_text(result.stdout)
(PREP/'apollo-transfer.stderr.log').write_text(result.stderr)
result.check_returncode()
remote=json.loads(result.stdout)
assert remote['all_hashes_verified']and remote['existing_media_reused']
receipt=dict(schema=1,remote_root=REMOTE,remote=remote,
    manifest=[{key:value for key,value in row.items()if key!='raw_base64'}for row in files],
    reference_labels_excluded=True,source_staging_only=True,model_or_audio_started=False)
(PREP/'apollo-staging-complete-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(remote))
