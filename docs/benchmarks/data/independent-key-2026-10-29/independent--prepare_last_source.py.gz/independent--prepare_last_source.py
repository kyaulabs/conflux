"""Preserve both incomplete responses and stage only the last unchanged source."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
PRIOR = BASE / 'resume-01'
DEST = BASE / 'resume-last-01'


def pin(path):
    raw = path.read_bytes()
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


prior = json.loads((PRIOR/'media-admission-01.json').read_text())
closed = json.loads((PRIOR/'source-closed-01.json').read_text())
assert not prior['complete'] and prior['audio_files_extracted'] == 23
assert closed['service_retired'] and closed['cgroup_absent_or_empty']
failed = [row for row in prior['sources'] if row['status'] != 'SourceBytesAdmitted']
assert len(failed) == 1 and failed[0]['track_id'] == 56187
assert failed[0]['error']['detail'] == 'Truncated or oversized remote range: offset=2439143271, expected=4194304, received=4193260'
inputs = [pin(PRIOR/'media-admission-01.json'),pin(PRIOR/'source-closed-01.json')]
for row in prior['sources']:
    if row['status'] != 'SourceBytesAdmitted':
        continue
    actual = pin(Path(row['path']))
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['SHA256']
    inputs.append(actual)
assert not DEST.exists()
DEST.mkdir(mode=0o700)
for name in ('selection-plan-02.json','record-01.json','test_range_media.py'):
    (DEST/name).write_bytes((PRIOR/name).read_bytes())
(DEST/'prior-admission.json').write_bytes((PRIOR/'media-admission-01.json').read_bytes())
text = (PRIOR/'range_media.py').read_text()
assert text.count('MAX_HTTP_RANGE = 4*1024**2') == 1
(DEST/'range_media.py').write_text(text.replace('MAX_HTTP_RANGE = 4*1024**2','MAX_HTTP_RANGE = 1024**2'))
plan = json.loads((PRIOR/'media-admission-plan-01.json').read_text())
plan.update(created_at_utc=datetime.now(timezone.utc).isoformat(),status='frozen_single_remaining_source',
    input_pins=inputs+[pin(DEST/name)for name in ('range_media.py','test_range_media.py','selection-plan-02.json','record-01.json','prior-admission.json')],
    scope='Reuse all 23 verified sources; fetch only original source 056187 in <=1 MiB checked ranges. Both incomplete responses remain unchanged. No source replacement, decode, inference or audio.',
    missing_source_id=56187,prior_failures_retained=2,already_admitted_sources_refetched=False)
plan['limits']['seconds']=300
plan['limits']['network_bytes']=64*1024**2
plan['limits']['max_range_bytes']=1024**2
(DEST/'media-admission-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
for script, prefix in [('test_range_media.py','range-tests'),('range_media.py','range-dry')]:
    result=subprocess.run(['/usr/bin/python3.14','-B',str(DEST/script)],capture_output=True,text=True,timeout=30)
    (DEST/(prefix+'-stdout-01.log')).write_text(result.stdout)
    (DEST/(prefix+'-stderr-01.log')).write_text(result.stderr)
    result.check_returncode()
print(json.dumps(dict(prepared=True,verified_sources_reused=23,remaining_source_id=56187,
    max_HTTP_range_bytes=1024**2,checks=8,source_download_started=False,model_started=False)))
