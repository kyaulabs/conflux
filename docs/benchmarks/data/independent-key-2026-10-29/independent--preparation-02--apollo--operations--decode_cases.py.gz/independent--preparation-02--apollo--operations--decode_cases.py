"""Bounded decode metadata capture for a fixed corpus; dry unless explicitly owned."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time


class ChildCleanupError(RuntimeError):
    pass


def strict_json(raw):
    def pairs(items):
        result = {}
        for key,value in items:
            if key in result:
                raise ValueError('Duplicate JSON field')
            result[key] = value
        return result
    return json.loads(raw,object_pairs_hook=pairs,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON value')))


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def verify(row):
    path = Path(row['path'])
    if not path.is_file() or path.is_symlink() or path.stat().st_size != row['bytes']:
        raise ValueError('Frozen source type/extent changed: '+str(path))
    with path.open('rb') as stream:
        if hashlib.file_digest(stream,'sha256').hexdigest() != row['sha256']:
            raise ValueError('Frozen source hash changed: '+str(path))


def validate(value, case):
    expected = {'schema','case','complete','source_sha256','source_bytes','prepared_frames',
        'prepared_pcm_sha256','sample_rate','channels','audio_device_opened'}
    if set(value) != expected or type(value['schema']) is not int or value['schema'] != 1:
        raise ValueError('Unexpected preparation metadata schema')
    if value['complete'] is not True or value['audio_device_opened'] is not False or value['case'] != case['id']:
        raise ValueError('Preparation did not prove this case without audio output')
    if (type(value['source_bytes']) is not int or value['source_bytes'] != case['source']['bytes'] or
        value['source_sha256'] != case['source']['sha256']):
        raise ValueError('Original source identity mismatch')
    if type(value['prepared_frames']) is not int or not 0 < value['prepared_frames'] <= 33554432:
        raise ValueError('Invalid complete PCM extent')
    if (type(value['sample_rate']) is not int or value['sample_rate'] != 48000 or
        type(value['channels']) is not int or value['channels'] != 2):
        raise ValueError('PCM clock/channel mismatch')
    if not isinstance(value['prepared_pcm_sha256'],str) or re.fullmatch('[0-9a-f]{64}',value['prepared_pcm_sha256']) is None:
        raise ValueError('Invalid complete PCM digest')
    return dict(id=case['id'],status='PreparedMetadataMeasured',prepared_frames=value['prepared_frames'],
        pcm_sha256=value['prepared_pcm_sha256'],source=case['source'],model_started=False)


def prepare(binary, case, output):
    spool = output/('spool-'+case['id'])
    spool.mkdir(mode=0o700)
    stdout = output/(case['id']+'.stdout.json')
    stderr = output/(case['id']+'.stderr.log')
    child = None
    first = time.monotonic()
    try:
        with stdout.open('xb') as out,stderr.open('xb') as err:
            child = subprocess.Popen([str(binary),case['id'],str(spool),'--metadata-only'],
                stdout=out,stderr=err,start_new_session=True)
            while child.poll() is None:
                if time.monotonic()-first >= 64:
                    raise TimeoutError('Original 64-second case budget exhausted')
                if os.fstat(out.fileno()).st_size > 16384 or os.fstat(err.fileno()).st_size > 16384:
                    raise ValueError('Native metadata/error capture exceeded 16 KiB')
                time.sleep(.05)
            code = child.wait()
        if stdout.stat().st_size > 16384 or stderr.stat().st_size > 16384:
            raise ValueError('Native metadata/error capture exceeded 16 KiB')
        if code != 0:
            raise ValueError('Native preparation failed ('+str(code)+'): '+stderr.read_text(errors='replace')[:1024])
        result = validate(strict_json(stdout.read_bytes()),case)
        if list(spool.iterdir()):
            raise ValueError('Anonymous PCM spool not retired')
        result.update(elapsed_seconds=time.monotonic()-first,native_reaped=True,spool_empty=True)
        return result
    finally:
        if child is not None and child.poll() is None:
            # Popen owns the unreaped leader and its fresh process group.
            try:
                os.killpg(child.pid,signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:
                    pass
                try:
                    child.wait(timeout=2)
                except subprocess.TimeoutExpired as error:
                    raise ChildCleanupError('Native decoder reap not proven; stop this owner') from error
        if spool.exists() and not list(spool.iterdir()):
            spool.rmdir()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--owned',action='store_true')
    parser.add_argument('--plan',type=Path)
    parser.add_argument('--output',type=Path)
    args = parser.parse_args()
    if not args.owned:
        print(json.dumps(dict(unarmed=True,source_opened=False,model_started=False,host_queried=False)))
        return 0
    plan = strict_json(args.plan.read_bytes())
    assert plan['status'] == 'frozen_decode_execution' and plan['physical_readiness_required'] is False
    if plan['host'] == 'laptop':
        assert any(line.endswith('/'+plan['unit']) for line in Path('/proc/self/cgroup').read_text().splitlines())
    else:
        assert plan['host'] == 'apollo' and os.environ.get('CONFLUX_PRIVATE_DECODE') == '1'
        assert not any(Path(path).exists() for path in ('/dev/nvidia0','/dev/dri','/dev/snd'))
    assert len(plan['cases']) == 24 and len({case['id'] for case in plan['cases']}) == 24
    assert all(re.fullmatch('[0-9]{6}',case['id']) for case in plan['cases'])
    for row in plan['input_pins']:
        verify(row)
    began = time.monotonic()
    deadline = began+1650
    args.output.mkdir(mode=0o700)
    rows = []
    for case in plan['cases']:
        first = time.monotonic()
        try:
            if time.monotonic()+70 > deadline:
                raise TimeoutError('No room for another bounded preparation')
            row = prepare(plan['binary']['path'],case,args.output)
        except ChildCleanupError:
            raise
        except Exception as error:
            row = dict(id=case['id'],status='SourcePreparationFailed',model_started=False,
                error=dict(type=type(error).__name__,message=str(error)[:1200]),elapsed_seconds=time.monotonic()-first)
        save(args.output/(case['id']+'.receipt.json'),row)
        rows.append(row)
        print(json.dumps(dict(id=case['id'],status=row['status'])),flush=True)
    for row in plan['input_pins']:
        verify(row)
    result = dict(schema=1,host=plan['host'],fixed_denominator=24,cases=rows,
        all_sources_prepared=all(row['status']=='PreparedMetadataMeasured' for row in rows),
        input_pins_unchanged=True,elapsed_seconds=time.monotonic()-began,
        model_started=False,audio_device_opened=False,GPU_started=False,
        PCM_persisted=False,physical_readiness_consumed=False,qualified=False)
    save(args.output/'preparation.json',result)
    print(json.dumps({key:result[key] for key in ('host','all_sources_prepared','elapsed_seconds','qualified')}),flush=True)
    return 0 if result['all_sources_prepared'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
