from pathlib import Path
import gzip,hashlib,json,os,stat,subprocess
root=Path.cwd();base=root/'benchmarks-local/hour-player-01';runs=root/'benchmarks-local/m2-live-delivery-2026-10-19'
head='ac03b6c23367ac3a7aca11e6e3bdcb67306a8147';dest=root/'docs/benchmarks/data/m2-actual-player-hour-2026-10-19';stage=base/'archive-stage';rawdir=base/'archive-raw'
assert not any(os.path.lexists(p) for p in (dest,stage,rawdir))
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size<=64*1024**2
 b=p.read_bytes();a=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)
 assert len(b)==s.st_size and b'\0' not in b;b.decode('utf8');return b
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
sig=subprocess.check_output(['git','show','-s','--format=%H %G? %GF %ae',head],text=True).strip();assert sig==head+' G F621F658D66098CBE9E5C55D66788CCBB5E215AC kyau@kyau.net'
final=json.loads(read(base/'finalization-check/execution.json'));assert final['passed'] and final['pins_unchanged']
for name,expected in final['pins_after'].items():assert pin((root/name).read_bytes())==expected
paths={base/n for n in ('archive_hour.py','summary.json','prepared-result.json','source.patch','source-commit.log','source-commit-message.txt','source.sha256','focused-result.json','code-review.json','verification-crosscheck.json','product-coverage-source-check.json','host-run-01-host-crosscheck.json','host-run-01-phase-review.json','host-run-02-crosscheck.json','gpu-hang-supplement.json','runtime-submission-review.json','kernel-graphics-window.log','compositor-window.log','powerdevil-window.log','guard-window.log','host-graphics-version-and-header.json','run_normal.py','run_finalization_check.py','red.log','green.log','phase-analysis.log','ctest-hour.log','build.log','PAUSED.json','RESUMED.json')}
paths.update(base/(n+'.query.json') for n in ('kernel-graphics-window.log','compositor-window.log','powerdevil-window.log','guard-window.log'))
paths.add(runs/'short_live_stop_fixture_owner.cpp')
for check in ('normal','finalization-check'):
 folder=base/check
 paths.update(p for p in folder.iterdir() if p.is_file() and p.suffix in ('.json','.log'))
 paths.update(p for p in (folder/'stop').iterdir() if p.is_file() and p.suffix in ('.json','.log','.conf'))
 paths.update(p for p in (folder/'stop/recordings').iterdir() if p.is_file() and p.suffix in ('.json','.jsonl','.log'))
for name in ('hour-live-actual-model-01','hour-live-actual-model-02'):
 r=json.loads(read(runs/name/'result.json'));assert not r['passed'] and not r['qualified'] and r['cleanup_proven'] and r['owned_cache_removed'] and r['pins_unchanged']
 paths.update(runs/name/n for n in ('result.json','native-result.json','observations.jsonl','host-observations.jsonl','progress.json','native.stdout.log','native.stderr.log','owned-pipewire-cleanup.json'))
 paths.update(runs/(name+n) for n in ('-readiness.json','-launch.json','-recipe.json','-cool-start.json','-wait-launch.py','.stdout.json','.stderr.log'))
paths.add(runs/'hour-live-actual-model-01-thermal-guard.log')
allowed={'.json','.jsonl','.log','.conf','.py','.cpp','.patch','.txt','.sha256'}
assert all(p.suffix in allowed for p in paths)
inputs={str(p.relative_to(root)):pin(read(p)) for p in sorted(paths)};assert sum(v['bytes'] for v in inputs.values())<=128*1024**2
stage.mkdir(mode=0o700);rawdir.mkdir(mode=0o700);files={};uncompressed={};origins={}
def add(p):
 b=read(p);origin={'path':str(p.relative_to(root)),**pin(b)};name=origin['path'].replace('/','--');packedname=name+'.gz';assert packedname not in files
 if origin['path'] in inputs:assert pin(b)==inputs[origin['path']]
 (rawdir/name).write_bytes(b);packed=gzip.compress(b,mtime=0);(stage/packedname).write_bytes(packed)
 files[packedname]=pin(packed);uncompressed[packedname]=pin(b);origins[packedname]=origin
for p in sorted(paths):add(p)
scanlog=base/'archive-gitleaks.log';scanreport=base/'archive-gitleaks-findings.json';assert not scanlog.exists() and not scanreport.exists()
with scanlog.open('xb') as out:
 result=subprocess.run(['gitleaks','dir',str(rawdir),'--redact','--no-color','--report-format','json','--report-path',str(scanreport)],stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,timeout=90)
assert result.returncode==0 and json.loads(read(scanreport))==[]
for p in (scanlog,scanreport):add(p)
for name,expected in files.items():
 packed=(stage/name).read_bytes();b=gzip.decompress(packed);origin=origins[name];assert pin(packed)==expected and pin(b)==uncompressed[name]=={k:origin[k] for k in ('bytes','sha256')};assert b==read(root/origin['path'])
for name,expected in final['pins_after'].items():assert pin((root/name).read_bytes())==expected
summary=json.loads(read(base/'summary.json'))
v={'schema':'conflux.m2-actual-player-hour.v1','source_head':head,'source_signature':sig,'status':'harness_verified_both_physical_hour_attempts_incomplete_failed','m2_open':True,'sustained_actual_player_qualified':False,'summary':summary,'files':files,'uncompressed':uncompressed,'origins':origins,'raw_secret_scan_exit':0,'raw_scanned_input_bytes':sum(x['bytes'] for x in inputs.values()),'scope':'Named closed UTF8 metadata/source patch/verification only. No WAV/binary/model/cache/HTML/XML. Native reports retain failed latency/starvation/exposure; kernel supplement follows earlier unknown-cause review. Raw scan predates scanner output/verification packaging.'}
(stage/'verification.json').write_text(json.dumps(v,indent=2,allow_nan=False)+'\n');stage.rename(dest)
print(json.dumps({'destination':str(dest),'files':len(files)+1,'raw_bytes':sum(x['bytes'] for x in inputs.values()),'source_head':head,'qualified':False}))
