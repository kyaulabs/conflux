// SPDX-License-Identifier: AGPL-3.0-or-later
// Ignored targeted reporting regression: stop actual private native playback after two measured progress pulses.
#define main inheritedPreparationControllerMain
#include "../../tools/experiments/preparation_controller_check.cpp"
#undef main
#include "library/StemEngineSupport.hpp"
#include "audio/StemRateConverter.hpp"
#include <QCryptographicHash>
#include <QProcessEnvironment>
#include <exception>
#include <sndfile.h>

namespace {
volatile std::sig_atomic_t shortOwnerStop = 0;
void stopShortOwner(int) { shortOwnerStop = 1; }
QJsonObject shortObject(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly) || file.size() > 1024 * 1024)
        throw std::runtime_error("Cannot read bounded native result");
    const auto document = QJsonDocument::fromJson(file.readAll());
    if (!document.isObject()) throw std::runtime_error("Native result is not one JSON object");
    return document.object();
}
QString shortSha(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly) || file.size() <= 0 || file.size() > 128 * 1024 * 1024)
        throw std::runtime_error("Cannot hash bounded generated input/tool");
    QCryptographicHash hash(QCryptographicHash::Sha256);
    if (!hash.addData(&file)) throw std::runtime_error("Cannot hash complete generated input/tool");
    return QString::fromLatin1(hash.result().toHex());
}
void shortDirectory(const QString& path)
{
    if (QFileInfo::exists(path) || !QDir().mkdir(path) || ::chmod(QFile::encodeName(path).constData(), 0700))
        throw std::runtime_error("Need fresh mode0700 short-live directory");
}
} // namespace

int main(int argc, char** argv)
{
    QJsonArray checks;
    // STOP targets measured playback reporting, not a particular model/recovery phase.
    QJsonObject observations;
    QString error, report;
    bool passed = false;
    auto require = [&](bool value, const char* message) {
        if (!value) throw std::runtime_error(message);
        checks.append(message);
    };
    try {
        if (argc != 3 && (argc != 4 || std::string_view(argv[3]) != "--functional-only"))
            throw std::runtime_error("Usage: short-live-stop-fixture-owner PRIVATE_RUNTIME EMPTY_RECORDING_DIR [--functional-only]");
        const rlimit noCore{0, 0};
        require(::setrlimit(RLIMIT_CORE, &noCore) == 0 && ::prctl(PR_SET_DUMPABLE, 0) == 0,
                "Private fixture owner disables core dumps");
        const std::filesystem::path runtime(argv[1]), recording(argv[2]);
        validatePrivate(runtime, recording);
        std::signal(SIGINT, stopShortOwner); std::signal(SIGTERM, stopShortOwner);
        QCoreApplication app(argc, argv);
        const auto output = QString::fromStdString(recording.string());
        const auto parent = QFileInfo(output).absolutePath();
        report = QDir(parent).filePath("fixture-owner-result.json");
        const auto fixtures = QDir(parent).filePath("fixture-inputs");
        shortDirectory(fixtures); shortDirectory(output + "/cache");
        const auto a = QDir(fixtures).filePath("tiny-live-a.wav"), b = QDir(fixtures).filePath("quiet-peer-b.wav");
        writeFixture(a, 8192, -4096, 211, 44100); // .25/-.125, independent fake roles are k/4 of this.
        writeFixture(b, 1, -1, 30 * 48000, 48000); // Quiet finite peer; private output only.
        const auto fixture = conflux::test::makeStemServiceFixture(fixtures);
        const auto binary = QStringLiteral(CONFLUX_SOURCE_DIR "/build/dev/conflux-manual-playback-soak");
        require(QFileInfo(binary).isExecutable(), "Actual existing native soak binary is available");
        observations["native_binary"] = binary;
        observations["native_binary_sha256"] = shortSha(binary);
        observations["source_sha256"] = shortSha(a);
        observations["peer_sha256"] = shortSha(b);
        observations["source_frames44100"] = 211;
        const auto expectedFrames = conflux::audio::StemRateConverter::countFrames(211, 4096).outputFrames();
        observations["expected_output_frames48000"] = qint64(expectedFrames);
        pw_init(nullptr, nullptr);
        // Existing Sink is an endpoint owner here. Its constant .125/-.0625
        // sample oracle is deliberately unarmed for changing live/quiet audio.
        Sink sink("conflux-short-live-test-sink");
        ServiceTrace services(fixture); // Fallback only after the proof checks below.
        bool groupsGone = true;
        conflux::library::detail::OwnedStemProcess owned(groupsGone);
        auto& child = owned.process();
        auto env = QProcessEnvironment::systemEnvironment();
        env.insert("XDG_CACHE_HOME", output + "/cache");
        env.insert("QT_QPA_PLATFORM", "offscreen"); env.insert("QT_QUICK_BACKEND", "software");
        env.insert("QT_QUICK_CONTROLS_STYLE", "Basic"); env.remove("CONFLUX_ALLOW_HOST_SOAK");
        child.setProcessEnvironment(env);
        child.setStandardOutputFile(QDir(parent).filePath("native.stdout.log"));
        child.setStandardErrorFile(QDir(parent).filePath("native.stderr.log"));
        const auto stopFile = output + "/STOP";
        std::exception_ptr primary;
        QJsonObject firstMeasuredPulse, stopPulse;
        bool measuredStopIssued = false;
        try {
            child.start(binary, {"--live-stems", a, b, output, "10", stopFile,
                fixture.engine.pythonExecutable, fixture.engine.exporterPath, fixture.engine.workerPath,
                fixture.service, fixture.engine.runtimePath, fixture.engine.modelPath});
            require(child.waitForStarted(3000) && owned.group() > 1,
                    "Native live child starts in one independently owned process group");
            observations["native_pid"] = child.processId(); observations["native_group"] = owned.group();
            const auto deadline = Clock::now() + std::chrono::seconds(65);
            while (child.state() != QProcess::NotRunning) {
                QCoreApplication::processEvents(QEventLoop::AllEvents, 5);
                services.capture();
                if (!measuredStopIssued && QFileInfo::exists(output + "/progress.json")) {
                    const auto progress = shortObject(output + "/progress.json");
                    const auto phase = progress["phase"].toString();
                    const bool measured = phase == "steady" || phase == "replay_recovery" || phase == "incomplete_generation_seek";
                    if (measured && progress["monotonic_ns"].toInteger() > 0 && progress["output_frame"].toInteger() > 0) {
                        if (firstMeasuredPulse.isEmpty()) firstMeasuredPulse = progress;
                        else if (progress["monotonic_ns"].toInteger() > firstMeasuredPulse["monotonic_ns"].toInteger() &&
                                 progress["output_frame"].toInteger() > firstMeasuredPulse["output_frame"].toInteger()) {
                            QFile stop(stopFile); const QByteArray payload("private-measured-stop\n");
                            require(stop.open(QIODevice::WriteOnly | QIODevice::NewOnly) && stop.write(payload) == payload.size() && stop.flush(),
                                    "One fresh STOP is published only after native measured progress and output clock advance");
                            stop.close(); measuredStopIssued = true; stopPulse = progress;
                            observations["stop_request"] = QJsonObject{{"first_measured_progress", firstMeasuredPulse},
                                {"later_measured_progress", stopPulse}, {"stop_path", stopFile},
                                {"issued_monotonic_ns", qint64(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now().time_since_epoch()).count())},
                                {"issued_once", true}};
                        }
                    }
                }
                if (shortOwnerStop) throw std::runtime_error("Private fixture owner stopped");
                if (Clock::now() >= deadline) throw std::runtime_error("Private native fixture exceeded65s setup/playback bound");
                QThread::msleep(2);
            }
        } catch (...) { primary = std::current_exception(); }
        // A failed owner still requests cooperative native shutdown, then uses
        // the existing bounded known-group finish. Never delete cache charges.
        if (child.state() != QProcess::NotRunning) {
            QFile stop(stopFile); const bool requested = stop.open(QIODevice::WriteOnly | QIODevice::NewOnly);
            if (requested) { stop.write("private-owner-stop\n"); stop.close(); }
            const auto grace = Clock::now() + std::chrono::seconds(10);
            while (child.state() != QProcess::NotRunning && Clock::now() < grace) {
                QCoreApplication::processEvents(QEventLoop::AllEvents, 5); QThread::msleep(2);
            }
        }
        const bool groupClean = owned.finish();
        observations["native_group_gone"] = groupClean && groupsGone;
        observations["native_exit"] = child.exitCode();
        observations["native_normal_exit"] = child.exitStatus() == QProcess::NormalExit;
        services.capture(); observations["services"] = services.identities();
        bool serviceClean = services.size() == 1;
        for (std::size_t i = 0; i < services.size(); ++i) serviceClean = services.gone(i) && serviceClean;
        observations["service_and_job_gone_before_fallback"] = serviceClean;
        observations["sink_name"] = QString::fromStdString(sink.name());
        observations["sink_constant_sample_oracle_armed"] = false;
        if (QFileInfo::exists(output + "/native-result.json")) observations["native"] = shortObject(output + "/native-result.json");
        if (primary) std::rethrow_exception(primary);
        require(groupClean && groupsGone && child.exitStatus() == QProcess::NormalExit && child.exitCode() == 2,
                "Gracefully cancelled native child exits2 and its known group is gone before fallback cleanup");
        require(serviceClean, "One observed fake-service identity and its live job disappear before safety cleanup");
        require(services.count(0, "command", "load") == 1 && services.count(0, "fixture", "runtime") == 1,
                "Cancelled measured playback uses one persistent fake service/runtime");
        const auto native = observations["native"].toObject();
        require(measuredStopIssued && !firstMeasuredPulse.isEmpty() && !stopPulse.isEmpty() &&
                native["cancelled"].toBool() && native["passed"].isBool() && !native["passed"].toBool() &&
                native["error"].toString() == "Stop file requested graceful live cancellation" &&
                native["functional_only"].toBool() && !native["host_audio"].toBool() &&
                native["mode"].toString() == "live-stems" && native["requested_seconds"].toInt() == 10 &&
                native["shutdown_completed"].toBool(),
                "The measured STOP is an explicit cancellation with exit2 and private functional scope");
        require(native["measurement_begin_output_frame"].isDouble() && native["measurement_end_output_frame"].isDouble() &&
                native["measurement_intervals_closed"].toBool(),
                "Cancelled measurement reports explicit beginning/end output clocks and closed intervals");
        const auto begin = native["measurement_begin_output_frame"].toInteger(-1);
        const auto end = native["measurement_end_output_frame"].toInteger(-1);
        const auto intervals = native["intervals"].toArray();
        require(begin >= 0 && end > begin && !intervals.isEmpty(), "Cancelled measured output range is nonempty");
        qint64 covered = 0, expectedBegin = begin;
        for (const auto& entry : intervals) {
            const auto interval = entry.toObject();
            const auto first = interval["output_begin"].toInteger(-1), last = interval["output_end"].toInteger(-1);
            require(first == expectedBegin && last >= first && interval["frames"].toInteger(-1) == last - first &&
                    interval["aborted"].isBool(), "Measured intervals remain contiguous, bounded and explicitly marked");
            covered += last - first; expectedBegin = last;
        }
        require(intervals.last().toObject()["aborted"].toBool() && expectedBegin == end && covered == end - begin,
                "Aborted final interval reaches measurement end and all interval frames exactly cover the measured range");
        observations["measurement_coverage"] = QJsonObject{{"begin", begin}, {"end", end}, {"covered_frames", covered},
            {"interval_count", intervals.size()}, {"last_interval", intervals.last().toObject()}};
        const auto setup = native["setup"].toObject(), counters = native["observation_counters"].toObject();
        require(setup["source_token"].toInteger() > 0 && setup["input_frames"].toInteger() == 211 &&
                setup["output_frames"].toInteger() == qint64(expectedFrames) &&
                setup["source_sha256"].toString() == observations["source_sha256"].toString() &&
                setup["model_sha256"].toString() == shortSha(fixture.engine.modelPath) &&
                setup["runtime_sha256"].toString() == shortSha(fixture.engine.runtimePath) &&
                setup["service_sha256"].toString() == shortSha(fixture.service),
                "Native live metadata binds the actual tiny source, exact conversion count and fake tool identities");
        require(counters["producer_finished"].toBool() && counters["attempted"].toInteger() == counters["retained"].toInteger() &&
                counters["retained"].toInteger() > 0 && !counters["dropped"].toInteger() && !counters["invalid_clock_reads"].toInteger(),
                "Cancelled native observation retirement remains complete and loss-free");
        const auto recorded = native["recorded_audio"].toObject(), writer = native["recording"].toObject();
        require(recorded["frames"].toInteger() > 0 && recorded["nonzero_samples"].toInteger() > 0 &&
                writer["acceptedFrames"].toInteger() == recorded["frames"].toInteger() &&
                writer["writtenFrames"].toInteger() == recorded["frames"].toInteger() && !writer["overflowFrames"].toInteger(),
                "Native finite float-WAV recording retains exact accepted/written counts without overflow");
        SF_INFO wavInfo{};
        auto* wavRaw = sf_open(QFile::encodeName(output + "/master.wav").constData(), SFM_READ, &wavInfo);
        require(wavRaw, "Cancelled native recording can be independently reopened");
        const auto wav = std::unique_ptr<SNDFILE, decltype(&sf_close)>(wavRaw, sf_close);
        require(wavInfo.channels == 2 && wavInfo.samplerate == 48000 && wavInfo.frames == recorded["frames"].toInteger() &&
                wavInfo.frames > 0 && wavInfo.frames <= 48000LL * 130 &&
                (wavInfo.format & SF_FORMAT_TYPEMASK) == SF_FORMAT_WAV &&
                (wavInfo.format & SF_FORMAT_SUBMASK) == SF_FORMAT_FLOAT,
                "Cancelled recording independently has bounded stereo48k float-WAV geometry");
        std::array<float, 4096> pcm{}; sf_count_t checked = 0; bool finite = true;
        for (;;) {
            const auto count = sf_readf_float(wav.get(), pcm.data(), pcm.size() / 2);
            if (!count) break;
            for (sf_count_t index = 0; index < count * 2; ++index) finite = finite && std::isfinite(pcm[std::size_t(index)]);
            checked += count;
        }
        require(finite && checked == wavInfo.frames && sf_error(wav.get()) == SF_ERR_NO_ERROR,
                "Independent full recording read retains only finite PCM and exact frame count");
        passed = true;
    } catch (const std::exception& failure) { error = QString::fromUtf8(failure.what()); }
    const QJsonObject result{{"passed", passed}, {"error", error}, {"checks", checks},
        {"execution_deadline_gate", false}, {"observations", observations},
        {"scope", "Private measured STOP reporting regression on actual native live path with generated211-frame source, quiet finite peer and fake service. Ten-second maximum stopped after two advancing measured progress pulses. No exact recovery/preemption, model, host audio, physical latency, sustained or musical qualification."}};
    if (!report.isEmpty() && !save(report, result)) {
        std::cerr << "Cannot save fixture-owner-result.json\n";
        return 1;
    }
    std::cout << QJsonDocument(result).toJson(QJsonDocument::Compact).constData() << '\n';
    return passed ? 0 : 1;
}
