from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
root=Path.cwd();base=root/'benchmarks-local/hour-player-01';out=base/'finalization-check';old=root/'benchmarks-local/phase-timing-01/normal/plan.json'
paths=set(json.loads(old.read_text())['pins']);paths.add('tests/manual_playback_hour_test.py');paths.add('benchmarks-local/m2-live-delivery-2026-10-19/short_live_stop_fixture_owner.cpp');paths.add('benchmarks-local/m2-live-delivery-2026-10-19/short-live-stop-fixture-owner')
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
before={n:pin(root/n) for n in sorted(paths)}
smoke={'QT_QPA_PLATFORM':'offscreen','QT_QUICK_BACKEND':'software','QT_QUICK_CONTROLS_STYLE':'Basic'}
launcher="import runpy,signal,sys\ndef stop(*_):\n signal.signal(signal.SIGTERM,signal.SIG_IGN)\n raise InterruptedError('Normal verification timed out')\nsignal.signal(signal.SIGTERM,stop)\nsys.argv=sys.argv[1:]\nrunpy.run_path(sys.argv[0],run_name='__main__')\n"
steps=[('build',['cmake','--build','build/dev','--parallel','2'],{},900),('ctest',['ctest','--test-dir','build/dev','--output-on-failure','--timeout','120'],{},900),('smoke',['build/dev/conflux','--smoke-test'],smoke,30)]
steps.append(('stop',['/bin/python3','-B','-c',launcher,str(root/'tools/experiments/private_routing_check.py'),str(root/'benchmarks-local/m2-live-delivery-2026-10-19/short-live-stop-fixture-owner'),str(out/'stop')],{},180))
steps=[('build',['cmake','--build','build/dev','--target','conflux-manual-playback-soak','--parallel','2'],{},900),('hour',['/bin/python3','-B','tests/manual_playback_hour_test.py'],{},30),steps[-1]]
plan={'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pins':before,'steps':[{'name':n,'command':c,'environment_overrides':e,'timeout_seconds':t} for n,c,e,t in steps],'scope':'Affected-path rebuild/hour regression and existing private common-path STOP check after the finalization progress fix; full37CTest/smoke passed immediately before the two-line metadata change; no model/host service qualification. Product audio/library code is unchanged from the separately retained phase coverage run.'}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');rows=[]
for name,command,extra,timeout in steps:
 print('Starting '+name,flush=True);began=time.monotonic();timed=False
 with (out/(name+'.log')).open('wb') as stream:
  child=subprocess.Popen(command,cwd=root,env=os.environ|extra,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
   code=1
 rows.append({'name':name,'exit_code':code,'timed_out':timed,'seconds':time.monotonic()-began,'log':pin(out/(name+'.log'))});print(name+' exit '+str(code),flush=True)
 if code:break
after={n:pin(root/n) for n in sorted(paths)};artifacts={n:pin(root/n) for n in ('build/dev/conflux','build/dev/conflux-manual-playback-soak','build/dev/conflux-manual-routing-check','build/dev/conflux-preparation-controller-check','build/dev/libconflux-audio.a')}
passed=len(rows)==len(steps) and all(r['exit_code']==0 and not r['timed_out'] for r in rows) and before==after
receipt={'closed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':passed,'qualified':False,'pins_before':before,'pins_after':after,'pins_unchanged':before==after,'rows':rows,'artifacts':artifacts,'scope':plan['scope']};(out/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n');raise SystemExit(0 if passed else 1)
