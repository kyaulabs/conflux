"""Generated integration regressions; no native/model/audio/host execution."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


retained = load('interval_trace_retained_generated', BASE/'test_host_player.py')
driver = retained.driver
wire = load('interval_trace_real_wire_fixture', ROOT/'build/m2-graph-interval-01/player-consumer-draft-02/test_player_capture_consumer.py')


class TraceIntegrationTests(unittest.TestCase):
    def test_actual_driver_parser_preserves_completed_and_owner_aborted_wire(self):
        for abort in (False, True):
            with self.subTest(abort=abort), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                _, _, hops, native, _ = wire.CaptureTests().fixture(root, abort=abort, extra_host=abort)
                parsed = driver.parse_capture(root, hops, native)
                self.assertTrue(parsed['complete'])
                self.assertEqual(parsed['native_completed_request_count'], 1)
                self.assertTrue(parsed['requests'][0]['input_identity_match'])
                self.assertTrue(parsed['requests'][0]['gpu_interval']['complete'])
                for key in ('qualified', 'timing_qualification', 'native_read_attested', 'reference_pcm_validated'):
                    self.assertIs(parsed[key], False)
                if abort:
                    tail = parsed['intentionally_aborted_final_request']
                    self.assertEqual(tail['input_metadata_status'], 'producer_only')
                    self.assertFalse(tail['gpu_timing_complete'])
                    self.assertFalse(tail['native_request_completed'])

    def test_actual_driver_parser_rejects_incomplete_input_or_gpu_capture(self):
        for mutation in ('input_hash', 'gpu_availability', 'outer_schema', 'capture_hash'):
            with self.subTest(mutation=mutation), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                summary, trace, hops, native, hosts = wire.CaptureTests().fixture(root)
                if mutation == 'input_hash':
                    next(row for row in trace if row['event'] == 'request_complete')['gpu_trace']['written_input_identity']['sha256'] = 'b'*64
                    wire.CaptureTests().write_trace(root, trace)
                elif mutation == 'gpu_availability':
                    hosts[0]['gpu_end_available'] = 0
                    wire.CaptureTests().write_hosts(root, summary, hosts)
                elif mutation == 'outer_schema':
                    trace[-1]['schema'] = True
                    wire.CaptureTests().write_trace(root, trace)
                else:
                    summary['streams']['stdout']['sha256'] = 'f'*64
                    (root/'native-profiler.capture.json').write_text(json.dumps(summary))
                with self.assertRaises(ValueError):
                    driver.parse_capture(root, hops, native)

    def test_runtime_trace_does_not_mark_a_service_miss_as_qualified(self):
        def miss(output, result):
            hops = result['observations']['service_hops']
            hops.update(nearest_rank_p99_ms=5000., maximum_ms=5000., at_or_above_target=21)
            for row in result['observations']['chunk_phases']['hops']:
                row['hop_service_ms'] = 5000.
        code, report = retained.CompletedRunCaptureTests().exercise(miss)
        self.assertEqual(code, 0)  # Diagnostic completion, explicitly separate from the service oracle.
        self.assertTrue(report['diagnostic_complete'])
        self.assertFalse(report['ordinary_assessment']['service_target_met'])
        self.assertFalse(report['ordinary_assessment']['passed'])
        self.assertFalse(report['service_target_met'])
        self.assertFalse(report['qualified'])
        self.assertFalse(report['timing_qualification'])

    def test_capture_failure_or_foreign_owner_cannot_complete_diagnostic(self):
        for options, message in (({'trace_error': 'generated missing trace'}, 'generated missing trace'),
                                 ({'trace_owner_pid': 999}, 'Capture/native/service cleanup ownership differs')):
            with self.subTest(options=options):
                code, report = retained.CompletedRunCaptureTests().exercise(**options)
                self.assertEqual(code, 1)
                self.assertFalse(report['diagnostic_complete'])
                self.assertFalse(report['qualified'])
                self.assertTrue(any(message in error['message'] for error in report['errors']))

    def test_current_plan_rejects_normal_runtime_wrong_service_or_renderer(self):
        original = json.loads(driver.PLAN.read_text())
        driver.validate_plan(original)
        for kind in ('runtime', 'service', 'renderer', 'context'):
            plan = copy.deepcopy(original)
            if kind == 'runtime':
                plan['assets']['runtime'] = plan['helpers']['normal_runtime']
            elif kind == 'service':
                plan['assets']['service'] = plan['helpers']['root_service']
            elif kind == 'renderer':
                plan['requested_qt_quick_backend'] = 'software'
            else:
                plan['diagnostic_environment']['CONFLUX_DRM_USAGE_RUN_ID'] = 'foreign'
            with self.assertRaises(ValueError):
                driver.validate_plan(plan)


if __name__ == '__main__':
    unittest.main(verbosity=2)
