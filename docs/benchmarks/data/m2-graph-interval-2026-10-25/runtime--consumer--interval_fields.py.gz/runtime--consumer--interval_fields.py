"""Pure validation of additive private fields; no I/O, imports of profilers or ownership."""
import math
import re
import struct

U64 = (1 << 64) - 1
INTERVAL_INTS = (
    'record_calls', 'record_begin_ns', 'record_end_ns', 'record_ns',
    'gpu_status', 'gpu_queue_family', 'gpu_valid_bits', 'gpu_period_f32_bits',
    'gpu_begin_commands', 'gpu_end_commands', 'gpu_begin_available', 'gpu_end_available',
    'gpu_begin_ticks', 'gpu_end_ticks', 'gpu_delta_ticks', 'gpu_interval_ns', 'gpu_query_ns')
INTERVAL_KEYS = frozenset(INTERVAL_INTS) | {'gpu_valid', 'gpu_wrapped'}
IDENTITY_KEYS = {'schema', 'sample_format', 'shape', 'bytes', 'sha256'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def original_fields(host, original_keys):
    require(type(host) is dict and not (set(original_keys) & INTERVAL_KEYS) and
            set(host) == set(original_keys) | INTERVAL_KEYS, 'Exact additive host schema required')
    return {key: host[key] for key in original_keys}


def validate_completed_host(host, ordinal, previous, *, original_keys, original_validate_host):
    """Caller supplies the unchanged pinned validator; incomplete graphs stay raw/invalid."""
    stripped = original_fields(host, original_keys)
    prior = None if previous is None else original_fields(previous, original_keys)
    # Reuse all original serial/creation/submit/fence/logger checks unchanged.
    original_validate_host(stripped, ordinal, prior, completed=True)
    require(all(type(host[key]) is int and 0 <= host[key] <= U64 for key in INTERVAL_INTS),
            'Interval integer/type/range differs')
    require(type(host['gpu_valid']) is bool and type(host['gpu_wrapped']) is bool and
            host['gpu_status'] == 1 and host['gpu_valid'], 'Completed GPU interval must be explicitly valid')
    require(host['record_calls'] == 1 and
            host['begin_ns'] <= host['record_begin_ns'] <= host['record_end_ns'] <= host['end_ns'] and
            host['record_ns'] == host['record_end_ns'] - host['record_begin_ns'],
            'Inclusive recording bracket differs')
    require(host['gpu_begin_commands'] == host['gpu_end_commands'] == 1 and
            host['gpu_begin_available'] > 0 and host['gpu_end_available'] > 0,
            'One available timestamp pair required')
    bits, period_bits = host['gpu_valid_bits'], host['gpu_period_f32_bits']
    require(1 <= bits <= 64 and period_bits <= (1 << 32) - 1 and
            host['gpu_queue_family'] <= (1 << 32) - 1, 'Timestamp capability metadata differs')
    period = struct.unpack('<f', struct.pack('<I', period_bits))[0]
    require(math.isfinite(period) and period > 0, 'Finite positive timestamp period required')
    numerator, denominator = period.as_integer_ratio()  # Exact recorded IEEE-f32 value.
    mask = (1 << bits) - 1
    begin, end = host['gpu_begin_ticks'], host['gpu_end_ticks']
    require(begin <= mask and end <= mask, 'Timestamp values must already be valid-bit masked')
    delta = (end - begin) & mask
    require(host['gpu_delta_ticks'] == delta and host['gpu_wrapped'] == (end < begin),
            'Timestamp modulo delta/wrap differs')
    require(host['wall_ns'] * denominator < numerator * (1 << bits),
            'Host scope permits ambiguous counter wraps')
    nanoseconds = delta * numerator // denominator
    require(nanoseconds <= U64 and host['gpu_interval_ns'] == nanoseconds,
            'Floored timestamp nanoseconds differ or overflow')
    return {'complete': True, 'graph_ordinal': ordinal, 'gpu_interval_ns': nanoseconds,
            'gpu_valid_bits': bits, 'gpu_period_f32_bits': period_bits, 'gpu_wrapped': host['gpu_wrapped']}


def _identity(value):
    require(type(value) is dict and set(value) == IDENTITY_KEYS and
            type(value['schema']) is int and value['schema'] == 1 and type(value['sample_format']) is str and value['sample_format'] == 'f32le' and
            type(value['shape']) is list and len(value['shape']) == 2 and
            all(type(item) is int for item in value['shape']) and value['shape'] == [343980, 2] and
            type(value['bytes']) is int and value['bytes'] == 2751840 and
            type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None,
            'Exact normalized-window identity schema required')


def validate_input_identity(producer, written, expected=None):
    """Existing request/epoch/process parser owns lineage; these are metadata, not PCM."""
    _identity(producer)
    _identity(written)
    require(producer == written, 'Producer/written normalized input identity differs')
    if expected is not None:
        _identity(expected)
        require(producer == expected, 'Normalized input differs from the bound expected metadata')
    return {**producer, 'shape': list(producer['shape'])}
