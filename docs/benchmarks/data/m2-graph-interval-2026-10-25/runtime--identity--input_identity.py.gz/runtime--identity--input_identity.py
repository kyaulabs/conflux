"""Private producer/written-input identity; this does not attest native reads."""
import hashlib
import os
from pathlib import Path
import re
import stat

import numpy as np

FRAMES, CHANNELS = 343980, 2
INPUT_BYTES = FRAMES * CHANNELS * 4
READ_BYTES = 65536
KEYS = {"schema", "sample_format", "shape", "bytes", "sha256"}


def fingerprint(samples):
    """Hash the exact existing contiguous interleaved F32LE producer buffer."""
    if (type(samples) is not np.ndarray or samples.shape != (FRAMES, CHANNELS)
            or samples.dtype.str != "<f4" or not samples.flags.c_contiguous):
        raise ValueError("Input identity requires contiguous stereo343980 <f4 samples")
    if not np.isfinite(samples).all():
        raise ValueError("Input identity requires finite samples")
    return {"schema": 1, "sample_format": "f32le", "shape": [FRAMES, CHANNELS],
            "bytes": INPUT_BYTES, "sha256": hashlib.sha256(memoryview(samples).cast("B")).hexdigest()}


def _signature(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def verify_written(path, expected):
    """After infer returns, require an unchanged exact regular input descriptor."""
    if (type(expected) is not dict or set(expected) != KEYS
            or type(expected["schema"]) is not int or expected["schema"] != 1
            or expected["sample_format"] != "f32le" or expected["shape"] != [FRAMES, CHANNELS]
            or type(expected["bytes"]) is not int or expected["bytes"] != INPUT_BYTES
            or type(expected["sha256"]) is not str
            or re.fullmatch("[0-9a-f]{64}", expected["sha256"]) is None):
        raise ValueError("Invalid producer input identity")
    path = Path(path)
    before_path = path.lstat()
    descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        before = os.fstat(descriptor)
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or before.st_uid != os.getuid() or before.st_size != INPUT_BYTES
                or not stat.S_ISREG(before_path.st_mode)
                or _signature(before_path) != _signature(before)):
            raise ValueError("Written input must be one exact owned regular segment")
        digest, remaining = hashlib.sha256(), INPUT_BYTES
        while remaining:
            data = os.read(descriptor, min(READ_BYTES, remaining))
            if not data:
                raise ValueError("Written input ended before its exact segment length")
            digest.update(data)
            remaining -= len(data)
        if os.read(descriptor, 1):
            raise ValueError("Written input exceeds its exact segment length")
        after, after_path = os.fstat(descriptor), path.lstat()
        if (not stat.S_ISREG(after_path.st_mode) or after.st_nlink != 1
                or _signature(before) != _signature(after)
                or _signature(before) != _signature(after_path)):
            raise ValueError("Written input changed during identity verification")
        actual = digest.hexdigest()
        if actual != expected["sha256"]:
            raise ValueError("Written input hash differs from producer bytes")
        return {**expected, "shape": list(expected["shape"]), "sha256": actual}
    finally:
        os.close(descriptor)
