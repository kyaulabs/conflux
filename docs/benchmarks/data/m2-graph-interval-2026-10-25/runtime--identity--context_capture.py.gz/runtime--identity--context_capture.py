"""Private passive-DRM context binding; original worker and wire remain unchanged."""
import hashlib
import importlib.util
import os
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
TRACE_ROOT = ROOT / "benchmarks-local/background-player-01/request-trace-candidate"
TRACE_HELPER = TRACE_ROOT / "trace_sidecar.py"
TRACE_PARSER = TRACE_ROOT / "parse_trace.py"
PINNED = {
    Path(__file__).with_name("input_identity.py"): "a9b872e9ca833c963608ad53c381be574331e95d9314dfc698396a1de70f1901",
    TRACE_HELPER: "b5ecc93b9eb470341966c97080bfc435dd8452a2a12b11c3440464e37531b7f7",
    TRACE_PARSER: "594689155eb935546004b5d7afc67d5a86e47f87f1c85f9b6d2f7ac828984acd",
    ROOT / "tools/stems/worker.py": "b38ab1dae456f9da69cbb30563595559f10e018246e86763dffffa89b9bacdff",
}
for path, expected in PINNED.items():
    if not path.is_file() or path.stat().st_size > 128 * 1024 or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise RuntimeError("Frozen original context helper/worker differs")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(TRACE_ROOT))
spec = importlib.util.spec_from_file_location("conflux_drm_original_trace", TRACE_HELPER)
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
process_identity = original.process_identity
inflight_context = original.inflight_context
identity_spec = importlib.util.spec_from_file_location("conflux_private_input_identity",
    Path(__file__).with_name("input_identity.py"))
input_identity = importlib.util.module_from_spec(identity_spec)
identity_spec.loader.exec_module(input_identity)


def idle_quit(process, *, completed_idle, deadline, clock=time.monotonic):
    """Existing quit command and kill/reap share one original two-second close budget."""
    result = {"requested_quit": False, "quit_write_complete": False, "killed": False}
    primary = None
    try:
        if process.poll() is None and completed_idle and clock() < deadline:
            result["requested_quit"] = True
            descriptor = process.stdin.fileno()
            was_blocking = os.get_blocking(descriptor)
            try:
                os.set_blocking(descriptor, False)
                wire = b'{"command":"quit"}\n'
                result["quit_write_complete"] = os.write(descriptor, wire) == len(wire)
            finally:
                os.set_blocking(descriptor, was_blocking)
            if result["quit_write_complete"]:
                try:
                    process.wait(timeout=max(0, deadline - clock() - .25))
                except subprocess.TimeoutExpired:
                    pass
    except BaseException as error:
        primary = error
        result["quit_error"] = type(error).__name__ + ": " + str(error)[:256]
    finally:
        if process.poll() is None:
            result["killed"] = True
            try:
                process.kill()
            except ProcessLookupError:
                pass
        try:
            process.wait(timeout=max(0, deadline - clock()))
        except BaseException as error:
            if primary is None:
                primary = error
            result["reap_error"] = type(error).__name__ + ": " + str(error)[:256]
        result.update(exit_code=process.poll(), process_reaped=process.poll() is not None,
                      within_same_shutdown_budget=clock() <= deadline)
    result["graceful_complete"] = bool(result["requested_quit"] and result["quit_write_complete"]
        and not result["killed"] and result["exit_code"] == 0 and result["process_reaped"]
        and result["within_same_shutdown_budget"] and primary is None)
    return result


class TraceSink(original.TraceSink):
    native_shutdown = None

    def begin(self, context, native_identity):
        if self.started >= 64 or self.bytes + 4 * original.RECORD_BYTES > original.FILE_BYTES:
            raise RuntimeError("Passive DRM context request/finalization reserve exhausted")
        return super().begin(context, native_identity)

    def finish(self, *, worker_joined):
        try:
            if self.native_shutdown is not None:
                self._append({"event": "native_shutdown", **self.native_shutdown}, reserve=original.RECORD_BYTES)
                if self.native_shutdown.get("graceful_complete") is not True:
                    self.mark_failure(RuntimeError("Native trace did not exit through bounded idle quit"))
        except BaseException as error:
            self.mark_failure(error)
        return super().finish(worker_joined=worker_joined)


class ContextNativeRuntime(original.TraceNativeRuntime):
    """Retain every actual infer context without requiring the old GPU-query envelope."""

    def __init__(self, *args, context_run_id, **kwargs):
        self.context_run_id = context_run_id
        self._infer_active = self._ready_completed = self._last_infer_completed = False
        self._shutdown_deadline = None
        super().__init__(*args, **kwargs)

    def start(self):
        ready = super().start()
        self._ready_completed = True
        return ready

    def infer(self, samples, request_id):
        begun = False
        self._infer_active = True
        self._last_infer_completed = False
        try:
            producer_identity = input_identity.fingerprint(samples)
            worker = self.trace_worker()
            context = inflight_context(worker.statistics(), request_id, self.trace_sink.source_digest)
            context["input_identity"] = producer_identity
            if process_identity(self.process.pid) != self.trace_native_identity:
                raise RuntimeError("DRM context native lifetime changed")
            self.trace_sink.begin(context, self.trace_native_identity)
            begun = True
            output, result = original.NativeRuntime.infer(self, samples, request_id)
            written_identity = input_identity.verify_written(self.root / "input.f32", producer_identity)
            self.trace_sink.complete(request_id, {
                "schema": 1, "kind": "passive_drm_request_binding", "run_id": self.context_run_id,
                "native": self.trace_native_identity, "request_id": request_id,
                "written_input_identity": written_identity,
            }, worker.statistics())
            self._last_infer_completed = True
            return output, result
        except BaseException as error:
            self.trace_sink.mark_failure(error, request_id)
            if begun:
                try:
                    self.trace_sink.request_failed(request_id, error)
                except BaseException as secondary:
                    error.add_note("Context failure record unavailable: " + type(secondary).__name__)
            raise
        finally:
            self._infer_active = False

    def _close_process(self):
        if self._shutdown_deadline is None:
            self._shutdown_deadline = time.monotonic() + 2
        record = idle_quit(self.process, completed_idle=(self._ready_completed
            and self._last_infer_completed and not self._infer_active), deadline=self._shutdown_deadline)
        self.trace_sink.native_shutdown = {"native": getattr(self, "trace_native_identity", None), **record}
        self._process_reaped = record["process_reaped"]
        if not self._process_reaped:
            raise RuntimeError("Native owner not reaped within original shutdown budget")
