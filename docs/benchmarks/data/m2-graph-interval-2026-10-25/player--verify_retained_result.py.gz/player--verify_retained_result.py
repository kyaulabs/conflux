#!/usr/bin/env python3
"""Verify saved failed-workload evidence without rerunning any workload."""
from collections import Counter
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics
import sys

BASE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True


def audit(event, args):
    if event.startswith(('subprocess.', 'socket.', 'os.exec', 'os.spawn', 'os.fork')) or event in ('os.system', 'os.kill', 'os.killpg'):
        raise RuntimeError('Retained-file verification forbids ' + event)
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)) and os.fsdecode(args[0]).startswith(('/proc/', '/sys/', '/dev/')):
        raise RuntimeError('Live host reads forbidden')


sys.addaudithook(audit)


def pin(path):
    raw = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stats(values):
    values = sorted(values)
    assert values and all(math.isfinite(x) and x >= 0 for x in values)
    return {'count': len(values), 'minimum': values[0], 'median': statistics.median(values),
            'p99_nearest_rank': values[math.ceil(.99*len(values))-1], 'maximum': values[-1]}


def read(name):
    return json.loads((BASE/name).read_bytes())


def main():
    for row in read('manifest-01.json')['files'].values():
        assert pin(row['path']) == row
    plan, report, result = read('plan.json'), read('diagnostic-assessment.json'), read('output-01/result.json')
    owner, cleanup, guard = read('dispatch-01.json'), read('root-post-host-cleanup-01.json'), read('root-post-host-guard-01.json')
    spec = importlib.util.spec_from_file_location('retained_interval_player', BASE/'run_host_player.py')
    driver = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = driver
    spec.loader.exec_module(driver)
    driver.validate_plan(plan)
    driver.verify_files(plan)
    observations = [driver.decode(line) for line in (BASE/'output-01/observations.jsonl').read_bytes().splitlines()]
    hops = [row for row in observations if row.get('type') == 'record' and row.get('hop_service_present') is True]
    parsed = driver.parse_capture(BASE/'host-capture-01', hops, result['native'])
    assert parsed == report['host_capture'] and parsed['complete']
    assert parsed['native_completed_request_count'] == 18 and parsed['published_hops'] == len(hops) == 17
    assert parsed['intentionally_aborted_final_request'] is None
    for name, row in result['capture'].items():
        driver.verify_capture(BASE/('output-01/native.'+name+'.log'), row, math.inf)
    native = result['native']
    measurement = driver.validate_measurement(native)
    latency = stats([row['hop_service_ms'] for row in hops])
    assert latency['p99_nearest_rank'] == result['observations']['service_hops']['nearest_rank_p99_ms']
    assert result['observations']['service_hops']['at_or_above_target'] == 8
    assert cleanup['passed'] and guard['passed'] and owner['exit_code'] == 1 and not owner['external_signals']
    assert not owner['remaining_known_processes'] and all(owner['owned_groups_absent'].values())
    assert result['cleanup_proven'] and report['cleanup_complete'] and report['post_run_frozen_inputs_unchanged']
    assert native['recording']['acceptedFrames'] == native['recording']['writtenFrames'] == native['recorded_audio']['frames'] == 6074112
    assert native['recording']['overflowFrames'] == 0 and native['recording']['status'] == 'Complete'
    assert native['steady_starved_frames'] == sum(x['starved_frames'] for x in native['intervals'] if x['kind'] == 'steady') == 210432
    assert native['control_starved_frames'] == sum(x['starved_frames'] for x in native['intervals'] if x['kind'] != 'steady') == 1303296
    assert all(x['starved_b'] == 0 for x in native['intervals'])
    assert len(native['manual_controls']) == 16 and all(x['acknowledged'] is True for x in native['manual_controls'])
    assert native['shutdown_completed'] and parsed['capture_summary']['native_shutdown']['graceful_complete']
    hosts = [json.loads(line) for line in (BASE/'output-01/host-observations.jsonl').read_bytes().splitlines()]
    assert all(not x['read_errors'] and x['power']['ac_online'] and x['power']['lid_open'] for x in hosts)
    requests = []
    for row in parsed['requests']:
        host = row['host']
        inside = [x for x in hosts if host['begin_ns'] < x['monotonic_ns'] < host['end_ns']]
        requests.append({'request_id': row['request_id'], 'generation': row['generation'], 'classification': row['classification'],
                         'input_sha256': row['producer_input_identity']['sha256'],
                         'service_ms': None if row['published_hop'] is None else row['published_hop']['hop_service_ms'],
                         'native_elapsed_ms': row['native_metrics']['elapsed_ms'], 'native_CPU_ms': row['native_metrics']['inference_cpu_ms'],
                         'graph_compute_ms': row['native_metrics']['graph_compute_ms'], 'host_record_ms': host['record_ns']/1e6,
                         'coarse_GPU_ms': host['gpu_interval_ns']/1e6,
                         'graph_wall_minus_GPU_ms': (host['wall_ns']-host['gpu_interval_ns'])/1e6,
                         'GPU_fraction_of_graph_percent': 100*host['gpu_interval_ns']/host['wall_ns'],
                         'interior_profile_sample_counts': dict(Counter(x['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'] for x in inside)),
                         'interior_package_C': [x['temperatures_millidegrees_C']['/sys/class/thermal/thermal_zone7/temp']/1000 for x in inside]})
    worst = max((x for x in requests if x['service_ms'] is not None), key=lambda x: x['service_ms'])
    assert worst['request_id'] == 12
    misses = [x for x in requests if x['service_ms'] is not None and x['service_ms'] >= 4095]
    assert len(misses) == 8
    record = {'schema': 1, 'status': 'completed_failed_workload_evidence_verified', 'qualified': False, 'timing_qualification': False,
              'scope': 'Completed120s instrumented visible Best-quality workload failed latency and steady audio availability. Parse-only verification does not replace failed launcher/public results.',
              'evidence': {name: pin(BASE/name) for name in ['plan.json', 'readiness.json', 'dispatch-01.json', 'diagnostic-assessment.json',
                          'output-01/result.json', 'output-01/observations.jsonl', 'output-01/host-observations.jsonl', 'output-01/master.wav',
                          'root-post-host-cleanup-01.json', 'root-post-host-guard-01.json', 'root-guard-journal-01.json']},
              'measurement': measurement, 'service_ms': latency, 'target_ms': 4095, 'service_target_met': False, 'misses': 8,
              'native_completed_requests': 18, 'published_hops': 17, 'matching_input_identities': 18, 'valid_GPU_intervals': 18,
              'requests': requests, 'worst_published_request': worst,
              'slow_hop_GPU_fraction_of_graph_percent': stats([x['GPU_fraction_of_graph_percent'] for x in misses]),
              'UI': {'reported_control_acknowledgements': 16, 'coverage': native['ui_coverage'], 'qualified': False,
                     'scope': 'Raw acknowledged actions and visible-frame observations. The original broad validator rejects this failed native workload; no overall functional pass is invented.'},
              'audio': {'steady_starved_frames': 210432, 'steady_starved_seconds': 210432/48000,
                        'control_interval_starved_frames': 1303296, 'control_interval_starved_seconds': 1303296/48000,
                        'peer_starved_frames': 0, 'invalid_buffers': native['invalid_buffers'], 'source_read_failures': native['source_read_failures'],
                        'callback_execution_deadline_misses': native['execution_deadline_misses'], 'recording': native['recording'],
                        'recorded_audio': native['recorded_audio'], 'availability_passed': False, 'physical_output_or_listening_qualified': False},
              'cancellation_and_seeks': {'incomplete_generation_seek_exercised': result['observations']['incomplete_generation_seek']['exercised'],
                        'replay_count': native['replay_count'], 'obsolete_request': {'id': 2, 'classification': parsed['requests'][1]['classification']},
                        'native_in_flight_preemption_proved': False, 'packet_discards': result['observations']['kind_counts'].get('PacketDiscarded', 0),
                        'source_cursor_recovery': [{'kind': x['kind'], 'issued_to_observed_cursor_ms': (x['recovered_cursor_observed_ns']-x['issued_ns'])/1e6} for x in native['controls']],
                        'native_shutdown': parsed['capture_summary']['native_shutdown'], 'intentional_final_active_abort': False,
                        'scope': 'Supersession, discard and observed recovery; not native preemption or a general cancellation-latency bound.'},
              'thermal': {'profile_sample_counts': dict(Counter(x['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'] for x in hosts)),
                          'maximum_sampled_package_C': max(x['temperatures_millidegrees_C']['/sys/class/thermal/thermal_zone7/temp'] for x in hosts)/1000,
                          'guard_entries': read('root-guard-journal-01.json')['entries'], 'same_postrun_guard_lifetime': True,
                          'guard_files_unchanged': True, 'limits_modified': False,
                          'scope': 'Point samples and guard events, not continuous temperatures, actual GPU clocks or causal proof. Passing and slow requests both occurred in low-power mode.'},
              'cleanup_verified': True, 'frozen_files_unchanged': True,
              'public_pins_after_present': 'pins_after' in result, 'public_guard_after_present': 'guard_after' in result,
              'reporting_error': {'primary': native['error'], 'secondary': 'KeyError: pins_after',
                                  'scope': 'Health failure prevented final public pin/guard fields. Separate root frozen-file and actual-host checks are retained, never fabricated into public fields.'},
              'interpretation': 'All8 service misses spend almost all graph wall time inside the inclusive coarse GPU interval. This is not exclusive kernel time. Policy reduction coincides with the slow period but was not isolated causally; no current-build performance-profile comparison was run.',
              'remaining_gates': 'M2/M3 and0.1.0 remain open; Best quality and strict4095ms service target unchanged.'}
    with (BASE/'root-result-verification-01.json').open('x') as stream:
        json.dump(record, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'status': record['status'], 'service_ms': latency, 'misses': 8,
                      'worst_GPU_ms': worst['coarse_GPU_ms'], 'steady_starved_seconds': 210432/48000,
                      'cleanup_verified': True, 'qualified': False}))


if __name__ == '__main__':
    main()
