"""Private tee on the existing service-owned runtime; no model/protocol/session change."""
import hashlib
import json
import os
from pathlib import Path
import selectors
import stat
import time
import context_capture as _context

_BaseContext = _context.ContextNativeRuntime
if getattr(_context,'_PROFILE_VERIFIED_SHA',None)!='98743333e9c7c39101a882f49ff0c0c7d868d47050d971279b87dbaf508e4978':
    raise RuntimeError('Load the exact verified original context through service_profile')
STREAMS = {'stderr': ('native-profiler.stderr', 40*1024**2), 'stdout': ('native-profiler.stdout', 128*1024)}
SUMMARY = 'native-profiler.capture.json'
SUMMARY_LIMIT = 16384


class ProfileNativeRuntime(_BaseContext):
    def __init__(self, *args, spool_directory, max_stderr_bytes, trace_sink, worker, context_run_id, **kwargs):
        if type(max_stderr_bytes) is not int or max_stderr_bytes != 65536:
            raise ValueError('The unchanged service job must retain its64KiB tail limit')
        self._profile_trace, self._profile_run = trace_sink, context_run_id
        self._profile_fds, self._profile_hashes, self._profile_rows = {}, {}, {}
        self._profile_errors, self._profile_done, self._profile_parent_valid = [], False, False
        self._profile_success=False
        self._profile_native, self._profile_summary_fd = {}, None
        try:
            parent=trace_sink.parent
            if (parent != parent.resolve(strict=True) or
                    parent.is_relative_to(Path(spool_directory).resolve(strict=False).parent.parent)):
                raise ValueError('Profiler sidecars must be outside the service job')
            trace_sink._check_parent()
            self._profile_parent_valid = True
            self._profile_parent = parent
            flags=os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC
            self._profile_summary_fd=os.open(SUMMARY,flags,0o600,dir_fd=trace_sink.parent_fd)
            for name,(filename,limit) in STREAMS.items():
                self._profile_rows[name]={'path':str(parent/filename),'limit_bytes':limit,'received_bytes':0,
                    'written_bytes':0,'sha256':'','eof':False,'overflow':False,'read_errors':0,'write_errors':0,'close_errors':0}
                self._profile_fds[name]=os.open(filename,flags,0o600,dir_fd=trace_sink.parent_fd)
                self._profile_hashes[name]=hashlib.sha256()
                self._check_stream(name)
            # Preserve the existing constructor, inherited service session and job allowlist.
            super().__init__(*args,spool_directory=spool_directory,max_stderr_bytes=65536,
                trace_sink=trace_sink,worker=worker,context_run_id=context_run_id,**kwargs)
            self._profile_native=dict(self.trace_native_identity)
        except BaseException as error:
            self._profile_error('constructor',error)
            try:self._finish_profile(parent_closed=False)
            except BaseException as cleanup_error:error.add_note('Capture cleanup: '+str(cleanup_error)[:256])
            raise

    def _profile_error(self,phase,error,stream=None,kind=None):
        if stream is not None and stream in self._profile_rows and kind is not None:
            self._profile_rows[stream][kind+'_errors']+=1
        if len(self._profile_errors)<16:
            self._profile_errors.append(phase+': '+type(error).__name__+': '+str(error)[:256])
        try:self._profile_trace.mark_failure(error)
        except BaseException:pass  # Preserve the capture/cleanup failure as the primary evidence.

    def _check_stream(self,name):
        fd=self._profile_fds[name];filename,_=STREAMS[name]
        a=os.fstat(fd);b=os.stat(filename,dir_fd=self._profile_trace.parent_fd,follow_symlinks=False)
        if (not stat.S_ISREG(a.st_mode) or a.st_uid!=os.getuid() or a.st_nlink!=1
                or stat.S_IMODE(a.st_mode)!=0o600 or (a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino)
                or a.st_size!=self._profile_rows[name]['written_bytes']):
            raise ValueError('Owned profiler capture identity/size changed')

    def _tee_read(self,key,selector):
        name='stderr' if key.fileobj is self.process.stderr else 'stdout'
        row=self._profile_rows[name]
        try:data=os.read(key.fileobj.fileno(),4096)
        except OSError as error:
            self._profile_error('pipe_read',error,name,'read');selector.unregister(key.fileobj);return b''
        if not data:
            row['eof']=True;selector.unregister(key.fileobj);return b''
        row['received_bytes']+=len(data)
        if name=='stderr':
            self._stderr_tail.extend(data);del self._stderr_tail[:-65536]
        remaining=row['limit_bytes']-row['written_bytes']
        if len(data)>remaining:row['overflow']=True
        # Overflow/write failure never blocks a native pipe: keep draining/discarding.
        if not row['write_errors'] and remaining:
            payload=memoryview(data)[:remaining]
            try:
                while payload:
                    written=os.write(self._profile_fds[name],payload)
                    if written<=0:raise OSError('Short profiler sidecar write')
                    self._profile_hashes[name].update(payload[:written]);row['written_bytes']+=written
                    payload=payload[written:]
            except OSError as error:self._profile_error('capture_write',error,name,'write')
        return b'' if name=='stderr' else data

    def _receive_bounded(self):
        deadline=time.monotonic()+self.timeout
        while b'\n' not in self.buffer:
            remaining=deadline-time.monotonic()
            if remaining<=0:
                self.abort();self._flush_diagnostics()
                raise TimeoutError('Native request timed out; child terminated')
            for key,_ in self.selector.select(remaining):
                if time.monotonic()>=deadline:break
                data=self._tee_read(key,self.selector)
                if key.fileobj is self.process.stdout:
                    if not data:raise RuntimeError('Native closed protocol: '+self._stderr_tail[-4096:].decode(errors='replace'))
                    self.buffer.extend(data)
                    if len(self.buffer)>65536:raise RuntimeError('Native protocol line exceeds limit')
        self._flush_diagnostics()
        line,_,rest=self.buffer.partition(b'\n');self.buffer=bytearray(rest)
        result=json.loads(line)
        if not isinstance(result,dict):raise RuntimeError('Native protocol requires an object')
        if self._profile_errors or any(row['overflow'] for row in self._profile_rows.values()):
            raise RuntimeError('Full native profiler capture failed')
        return result

    def _flush_diagnostics(self):
        try:super()._flush_diagnostics()
        except BaseException as error:
            self._profile_error('job_tail_flush',error,'stderr','write');raise

    def _close_process(self):
        if self._shutdown_deadline is None:self._shutdown_deadline=time.monotonic()+2
        deadline=self._shutdown_deadline
        result={'requested_quit':False,'quit_write_complete':False,'killed':False}
        primary=None
        try:
            # Parent ExitStack has already closed self.selector; pipes are still open.
            with selectors.DefaultSelector() as closing:
                for pipe in (self.process.stdout,self.process.stderr):
                    if not pipe.closed:closing.register(pipe,selectors.EVENT_READ)
                idle=self._ready_completed and self._last_infer_completed and not self._infer_active
                if self.process.poll() is None and idle and time.monotonic()<deadline:
                    result['requested_quit']=True
                    fd=self.process.stdin.fileno();blocking=os.get_blocking(fd)
                    try:
                        os.set_blocking(fd,False);wire=b'{"command":"quit"}\n'
                        result['quit_write_complete']=os.write(fd,wire)==len(wire)
                    finally:os.set_blocking(fd,blocking)
                while (result['quit_write_complete'] and time.monotonic()<deadline-.25
                       and (self.process.poll() is None or closing.get_map())):
                    for key,_ in closing.select(min(.02,max(0,deadline-.25-time.monotonic()))):self._tee_read(key,closing)
                if self.process.poll() is None:
                    result['killed']=True
                    try:self.process.kill()
                    except ProcessLookupError:pass
                while time.monotonic()<deadline and (self.process.poll() is None or closing.get_map()):
                    for key,_ in closing.select(min(.01,max(0,deadline-time.monotonic()))):self._tee_read(key,closing)
                self.process.wait(timeout=max(0,deadline-time.monotonic()))
            self._flush_diagnostics()  # Include close-time bytes in the same64KiB job tail.
        except BaseException as error:
            primary=error;result['quit_error']=type(error).__name__+': '+str(error)[:256]
        finally:
            if self.process.poll() is None:
                result['killed']=True
                try:self.process.kill()
                except ProcessLookupError:pass
                try:self.process.wait(timeout=max(0,deadline-time.monotonic()))
                except BaseException as error:
                    primary=primary or error;result['reap_error']=type(error).__name__+': '+str(error)[:256]
            result.update(exit_code=self.process.poll(),process_reaped=self.process.poll() is not None,
                          within_same_shutdown_budget=time.monotonic()<=deadline)
        result['graceful_complete']=bool(result['requested_quit'] and result['quit_write_complete']
            and not result['killed'] and result['exit_code']==0 and result['process_reaped']
            and result['within_same_shutdown_budget'] and primary is None)
        self.trace_sink.native_shutdown={'native':getattr(self,'trace_native_identity',None),**result}
        self._process_reaped=result['process_reaped']
        if not self._process_reaped:raise RuntimeError('Native not reaped within original close deadline')

    def _finish_profile(self,*,parent_closed):
        if self._profile_done:
            if not self._profile_success:raise RuntimeError('Native profiler capture remains failed')
            return
        self._profile_done=True
        try:
            self._profile_trace._check_parent()
        except BaseException as error:
            self._profile_parent_valid=False;self._profile_error('capture_parent',error)
        for name,fd in self._profile_fds.items():
            try:self._check_stream(name)
            except BaseException as error:self._profile_error('capture_identity',error,name,'write')
            finally:
                try:os.close(fd)
                except OSError as error:self._profile_error('capture_close',error,name,'close')
            self._profile_rows[name]['sha256']=self._profile_hashes[name].hexdigest()
        shutdown=getattr(self._profile_trace,'native_shutdown',None) or {}
        complete=bool(parent_closed and getattr(self,'_closed',False) and self._profile_parent_valid
            and self._shutdown_deadline is not None and time.monotonic()<=self._shutdown_deadline
            and self._profile_native and shutdown.get('graceful_complete') is True and not self._profile_errors
            and len(self._profile_rows)==2 and all(row['eof'] and not row['overflow']
                and row['received_bytes']==row['written_bytes'] and not row['read_errors']
                and not row['write_errors'] and not row['close_errors'] for row in self._profile_rows.values()))
        summary={'schema':1,'kind':'player_node_capture_v1','run_id':self._profile_run,'native':self._profile_native,
            'complete':complete,'parent_valid':self._profile_parent_valid,'native_shutdown':shutdown,
            'streams':self._profile_rows,'errors':self._profile_errors}
        try:
            raw=(json.dumps(summary,allow_nan=False,sort_keys=True)+'\n').encode()
            if len(raw)>SUMMARY_LIMIT:raise ValueError('Profiler summary exceeds bound')
            if self._profile_summary_fd is None:raise ValueError('Profiler summary reservation absent')
            view=memoryview(raw)
            while view:
                count=os.write(self._profile_summary_fd,view)
                if count<=0:raise OSError('Short profiler summary write')
                view=view[count:]
        except BaseException as error:
            self._profile_error('capture_summary',error);complete=False
        finally:
            if self._profile_summary_fd is not None:
                try:os.close(self._profile_summary_fd)
                except OSError as error:self._profile_error('summary_close',error);complete=False
                self._profile_summary_fd=None
        self._profile_success=complete
        if not complete:raise RuntimeError('Complete native profiler capture unproven')

    def close(self):
        primary=None
        try:super().close()
        except BaseException as error:
            primary=error;self._profile_error('parent_close',error)
        finally:
            try:self._finish_profile(parent_closed=primary is None)
            except BaseException as error:
                if primary is None:primary=error
        if primary is not None:raise primary
