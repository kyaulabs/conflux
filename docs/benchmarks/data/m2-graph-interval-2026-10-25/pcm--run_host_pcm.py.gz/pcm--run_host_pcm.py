#!/usr/bin/env python3
"""Dry by default: sixteen fixed accepted full/seek exact-PCM native requests.

Owning/deadline/cleanup pattern: retained run_drm_pcm.py/run_profile_pcm.py.
No UI/audio load, service timing oracle, policy mutation or qualification.
Only --run imports frozen helpers/NumPy, observes the host or starts a child.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import sys
import threading
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
PLAN, HUMAN, OUTPUT = BASE/'execution-plan-01.json', BASE/'readiness.json', BASE/'output-01'
MODE = 'm2-graph-interval-pcm16-01'
TOTAL, READINESS, PROFILE, CLEANUP, REQUEST = 480, 270, 120, 45, 30
NATIVE_FIELDS = ('elapsed_ms', 'inference_wall_ms', 'inference_cpu_ms', 'frontend_ms', 'graph_ms',
                 'graph_upload_ms', 'graph_compute_ms', 'graph_readback_ms', 'postprocess_ms', 'graph_rebuild_ms')
UNOBSERVED_SERVICE_FIELDS = ('source_read_ms', 'request_ms', 'overlap_ms')
PREFIX = b'conflux_m2_host_boundaries '
HOST_INTS = ('schema', 'graph_ordinal', 'outcome', 'begin_ns', 'end_ns', 'wall_ns',
 'backend_graph_calls', 'backend_sync_calls', 'create_started_total_begin', 'create_completed_total_begin',
 'create_started_delta', 'create_completed_delta', 'create_failed_delta', 'create_concurrent_sum_ns',
 'create_inflight_begin', 'create_inflight_end', 'shader_load_calls', 'shader_load_ns', 'shader_join_calls',
 'shader_join_ns', 'submit_calls', 'direct_sync_submit_calls', 'queue_lock_ns', 'submit_ns',
 'submit_failed_calls', 'almost_fence_calls', 'almost_fence_ns', 'graph_fence_calls', 'graph_fence_ns',
 'other_fence_calls', 'other_fence_ns', 'record_limit')
HOST_KEYS = set(HOST_INTS) | {'correlation_valid', 'perf_logger_enabled'}
FIXED = {'normal_runtime': '6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53',
 'model': 'f8c54ba35df95aafea7881eac214b58ec18a73cbcb6ff5a90f4b762631a286b6',
 'reference': '44554b8e1caca9e92a49be7b9cc0e05ba7248f0091b4cdfc005e87e2c87ffe70'}
CASE_IDS = tuple(f'{track}:{start}' for track in ('club_xl','when_the_light_breaks','under_my_skin','stfu')
                 for start in (0,257985,515970,773955))
CANDIDATE = ROOT/'build/m2-graph-interval-01/build-reuse/output-01/conflux-stem-runtime'
CANDIDATE_SHA = 'c63b1299877d0f7f6df9d8ca688f0bd88be1406a5da1be71233bc01231b4a6c6'
DEBUG_PREFIXES = ('GGML_VK_', 'GGML_VULKAN_', 'MESA_', 'INTEL_DEBUG', 'CONFLUX_DRM_', 'CONFLUX_REQUEST_TRACE_')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def decode(raw):
    def invalid(value):
        raise ValueError('Nonfinite JSON token: ' + value)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid)


def pin_read(path, expected=None, maximum=256*1024**2, deadline=math.inf, keep=False):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path, 'Canonical absolute pin required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= maximum, 'Pin size/type differs')
        digest, data, size = hashlib.sha256(), bytearray(), 0
        while size < before.st_size:
            require(time.monotonic() < deadline, 'Original command budget exhausted hashing')
            block = os.read(fd, min(1024*1024, before.st_size-size))
            require(bool(block), 'Pinned file shortened')
            size += len(block); digest.update(block)
            if keep: data.extend(block)
        require(signature(before) == signature(os.fstat(fd)) == signature(path.lstat()), 'Pin changed while reading')
        value = {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest(), 'identity': list(signature(before))}
        if expected is not None:
            require(value['sha256'] == expected['sha256'] and value['bytes'] == expected['bytes'], 'Pin differs: '+str(path))
        return value, bytes(data) if keep else None
    finally:
        os.close(fd)


def save(path, value):
    temporary = path.with_name(path.name+'.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
    temporary.replace(path)


def load_helper(name, row, deadline=math.inf):
    _, raw = pin_read(row['path'], row, maximum=256*1024, deadline=deadline, keep=True)
    spec = importlib.util.spec_from_file_location('conflux_host_'+name, row['path'])
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    exec(compile(raw, row['path'], 'exec'), module.__dict__)
    return module


def validate_plan(plan):
    require(plan.get('schema') == 1 and plan.get('mode') == MODE and
            plan.get('status') in ('draft_unarmed','frozen_pending_fresh_readiness'), 'Plan schema/mode/status differs')
    require(plan.get('requests') == 16 and plan.get('case_ids') == list(CASE_IDS) and plan.get('threads') == 2 and
            plan.get('window_frames') == 343980 and plan.get('source_rate') == 44100 and plan.get('source_frames') == 1031940 and
            plan.get('qualified') is False and plan.get('command_seconds') == TOTAL and plan.get('operator_seconds') == 600 and
            plan.get('readiness_preparation_max_seconds') == READINESS and plan.get('native_profile_max_seconds') == PROFILE and
            plan.get('cleanup_reserve_seconds') == CLEANUP and plan.get('request_max_seconds') == REQUEST and
            plan.get('no_retries') is True and plan.get('service_phases_observed') is False, 'Fixed workload/budgets differ')
    for name, digest in FIXED.items():
        require(plan['assets'][name]['sha256'] == digest, 'Fixed normal/model/reference pin differs')
    require(Path(plan['assets']['candidate']['path']) == CANDIDATE and
            plan['assets']['candidate']['sha256'] == CANDIDATE_SHA, 'Separate frozen candidate required')
    all_rows = [*plan['assets'].values(), *plan['helpers'].values(), *plan['sources'].values(), plan['build_receipt']]
    require(all(type(row) is dict and type(row.get('bytes')) is int and row['bytes'] > 0 and
                type(row.get('path')) is str and Path(row['path']).is_absolute() and
                re.fullmatch('[0-9a-f]{64}', row.get('sha256') or '') for row in all_rows), 'Incomplete frozen pins')
    require(set(plan['helpers']) == {'owner','original','comparison','normalizer','readiness','capture','consumer','host_validator','input_identity'},
            'Fixed helper roles required')
    require(plan['sources']['launcher']['path'] == str(Path(__file__).resolve()) and
            plan['sources']['outer_owner']['path'] == str(BASE/'run_owned.py') and
            plan['helpers']['capture']['path'] == str(BASE/'host_capture.py'), 'Private adapter path differs')
    return plan


def budget(record, plan_sha, now_utc, now_mono):
    issued = datetime.fromisoformat(record.get('recorded_at_utc', ''))
    require(issued.tzinfo is not None, 'Human UTC must have timezone')
    age = (now_utc-issued).total_seconds()
    require(record.get('schema') == 1 and record.get('decision') == 'ready' and
            record.get('diagnostic_mode') == MODE and record.get('ready_for_run') == 'output-01' and
            record.get('plan_sha256') == plan_sha and record.get('maximum_operator_seconds') == 600 and
            record.get('maximum_command_seconds') == TOTAL and 0 <= age <= 120 and
            all(record.get(k) is True for k in ('AC_power', 'lid_open', 'Codex_minimized', 'other_work_paused', 'no_suspend')) and
            all(type(record.get(k)) is str and 0 < len(record[k]) <= 8192 for k in ('human_reply', 'human_question', 'question_item_id')),
            'Fresh human conditions/plan binding required, with >=480s original600s left')
    return {'age_seconds': age, 'sampled_monotonic': now_mono,
            'operator_deadline': now_mono+600-age, 'command_deadline': now_mono+TOTAL}


def validate_metrics(metrics, request_id):
    require(metrics.get('event') == 'result' and type(metrics.get('id')) is int and metrics['id'] == request_id and
            metrics.get('frames') == 343980 and metrics.get('stems') == 4, 'Native result identity/geometry differs')
    for name in NATIVE_FIELDS:
        value = metrics.get(name)
        require(type(value) in (int, float) and math.isfinite(value) and value >= 0, 'Missing/invalid native phase: '+name)
    for name in ('voluntary_context_switches', 'involuntary_context_switches'):
        value = metrics.get(name)
        require(type(value) in (int, float) and math.isfinite(value) and value >= 0 and value == int(value), 'Invalid switch count')


def parse_capture(stderr, stdout, ready, requests, consumer, host_validator):
    require(type(stderr) is bytes and 0 < len(stderr) <= 256*1024 and stderr.endswith(b'\n') and
            type(stdout) is bytes and 0 < len(stdout) <= 128*1024 and stdout.endswith(b'\n'), 'Incomplete/oversized capture')
    packets = [decode(line) for line in stdout.splitlines()]
    require(len(packets) == 17 and len(requests) == 16 and packets[0] ==
            {k:v for k,v in ready.items() if k != 'process_environment'}, 'Ready/stdout packet count differs')
    hosts = [decode(line[len(PREFIX):]) for line in stderr.splitlines() if line.startswith(PREFIX)]
    require(len(hosts) == 16, 'Host records missing, extra or capped')
    previous = None; intervals = []
    for request_id, (case_id, row, packet, host) in enumerate(zip(CASE_IDS, requests, packets[1:], hosts, strict=True), 1):
        validate_metrics(packet, request_id)
        require(row.get('completed') is True and row.get('exact_pcm_match') is True and
                row.get('case_id') == case_id and row.get('request_id') == request_id and
                packet == row.get('native_metrics'), 'Raw response/retained ordered request mismatch')
        intervals.append(consumer.validate_completed_host(host, request_id, previous,
            original_keys=HOST_KEYS, original_validate_host=host_validator.validate_host))
        require(row['started_ns'] <= host['begin_ns'] <= host['end_ns'] <= row['finished_ns'],
                'Serial RPC/host monotonic clock bounds differ')
        consumer.validate_input_identity(row['producer_identity'],row['written_identity'],row['expected_identity'])
        previous = host
    return {'complete':True, 'gpu_intervals_complete':True, 'input_identities_complete':True,
            'records':hosts, 'intervals':intervals, 'request_ids':list(range(1,17)),
            'scope':'Ordered one-process RPCs and common Linux monotonic clock. Coarse GPU intervals are inclusive, not pure kernel time. Producer/written metadata are not native-read attestation.'}


def final_gates(report):
    require(report.get('cleanup_complete') is True and report.get('pins_unchanged') is True and
            report.get('guard_after') == report.get('guard_before') and report.get('within_command_budget') is True and
            report.get('capture',{}).get('complete') is True and report.get('host_boundaries',{}).get('complete') is True and
            report['host_boundaries'].get('gpu_intervals_complete') is True and
            report['host_boundaries'].get('input_identities_complete') is True and
            report.get('native_shutdown',{}).get('graceful_complete') is True and
            set(report.get('retained_streams',{})) == {'stderr','stdout'} and
            all(v.get('truncated') is False for v in report['retained_streams'].values()) and not report.get('errors') and
            not report.get('watchdog_errors') and not report.get('interruption_signal') and
            [r.get('case_id') for r in report.get('requests',[])] == list(CASE_IDS) and
            all(r.get('completed') is True and r.get('exact_pcm_match') is True for r in report['requests']),
            'Final ownership/pin/complete16/PCM/GPU/identity/capture gate failed')
    report.update(diagnostic_complete=True, qualified=False, timing_qualification=False,
        service_timing_qualification=False, conclusion='all16_exact_normal_PCM_and_valid_coarse_GPU_intervals',
        native_elapsed_at_or_above_4095=[r['request_id'] for r in report['requests'] if r['native_metrics']['elapsed_ms'] >= 4095])


def read_owner_clock(plan_pin,human_pin,deadline,driver_started):
    row,raw=pin_read(BASE/'dispatch-01.json',maximum=4*1024**2,deadline=deadline,keep=True)
    owned=decode(raw);began=owned.get('started_monotonic');end=owned.get('deadline_monotonic')
    number=lambda value:type(value) in (int,float) and math.isfinite(value) and value>=0
    require(type(owned.get('schema')) is int and owned.get('schema')==1 and owned.get('mode')==MODE and
        owned.get('plan_pin')==plan_pin and owned.get('human_pin')==human_pin and
        owned.get('command_maximum_seconds')==480 and owned.get('term_seconds')==465 and owned.get('kill_seconds')==477 and
        number(began) and began<=driver_started and number(end) and end==began+480 and end<=deadline,
        'Existing original owner clock/plan/human binding differs')
    return {'started_monotonic':began,'deadline_monotonic':end,'term_monotonic':began+465,
            'kill_monotonic':began+477,'checkpoint_pin':row}


def stage_limits(owner_clock, operator_deadline):
    deadline=min(owner_clock['deadline_monotonic'],operator_deadline)
    # All stages share the original owner origin; 270+120+45=435 < TERM465.
    admission=min(owner_clock['started_monotonic']+READINESS,deadline-PROFILE-CLEANUP)
    return deadline,admission


def validate_prepared_cases(cases, expected):
    require([case['id'] for case in cases] == list(CASE_IDS), 'Fixed full/seek case order differs')
    for case in cases:
        proven=expected[case['id']]
        require(case['input_sha256']==proven['input_sha256'] and case['normalization']==proven['normalization'],
                'Immutable normalized input/reference differs: '+case['id'])


def host_admission_ok(row, package_path, ceiling, *, fresh=False):
    temp=row['temperatures_millidegrees_C'].get(str(package_path))
    values=row['profile_epp_read_only']
    return (type(temp) is int and 0<=temp<=ceiling and
            values.get('/sys/firmware/acpi/platform_profile')=='balanced' and
            (not fresh or values.get('/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference')=='balance_performance'))


def normalize_errors(report):
    # Existing cleanup helpers also emit phase/message errors. Keep original order.
    report['errors']=[{**row,'type':str(row.get('type') or row.get('phase') or 'Error')[:256],
                      'message':str(row.get('message',''))[:8192]} for row in report['errors'][:64]]


def cleanup_owned(native, initialized, original, output, deadline, report, retain_streams):
    """Every independent owner is closed even when capture/identity retention fails."""
    # Log/identity failures cannot skip owned reaping or independent sinks.
    process = getattr(native,'process',None)
    try:
        if process is not None:
            if process.poll() is None: native.abort()
            process.wait(timeout=3)
            if initialized: report['capture'] = native.finish_capture(min(deadline,time.monotonic()+2))
    except Exception as error:
        report['errors'].append({'phase':'native_reap_capture','message':str(error)[:8192]})
    try:
        if process is not None and process.poll() is not None:
            retain_streams()
    except Exception as error:
        report['errors'].append({'phase':'capture_retention','message':str(error)[:8192]})
    try:
        if 'native_identity' in report:
            report['native_identity_absent'] = original.original_identity_absent(report['native_identity'])
        if process is not None:
            try:
                os.killpg(process.pid,0); report['native_group_absent'] = False
            except ProcessLookupError: report['native_group_absent'] = True
    except Exception as error:
        report['errors'].append({'phase':'native_identity_cleanup','message':str(error)[:8192]})
    try:
        cleanup,stderr_info,errors = original.cleanup_native(native,initialized,output/'cleanup')
        report['cleanup'] = cleanup; report['errors'].extend(errors)
        if stderr_info is not None: report['stderr_cleanup_capture'] = stderr_info
    except Exception as error:
        report['errors'].append({'phase':'native_cleanup','message':str(error)[:8192]})
    finally:
        try:
            sink = getattr(native,'stdout_capture',None)
            if sink is not None and not sink.closed: sink.close()
        except Exception as error:
            report['errors'].append({'phase':'stdout_sink_cleanup','message':str(error)[:8192]})


def run(plan, plan_pin, human, human_pin):
    started = time.monotonic(); clocks = budget(human, plan_pin['sha256'], datetime.now(timezone.utc), started)
    deadline = min(clocks['command_deadline'], clocks['operator_deadline'])
    owner_clock = read_owner_clock(plan_pin,human_pin,deadline,started)
    deadline,before_native = stage_limits(owner_clock,clocks['operator_deadline'])
    cleanup_deadline=min(deadline,owner_clock['started_monotonic']+READINESS+PROFILE+CLEANUP)
    require(not OUTPUT.exists(), 'One fresh output; no retries/reuse')
    OUTPUT.mkdir(mode=0o700)
    (OUTPUT/'cleanup').mkdir(mode=0o700)
    report = {'schema':1, 'mode':MODE, 'status':'checking', 'qualified':False, 'timing_qualification':False,
              'service_phases_observed':False, 'native_phase_names':list(NATIVE_FIELDS),
              'unobserved_service_phases':list(UNOBSERVED_SERVICE_FIELDS), 'plan_pin':plan_pin, 'human_pin':human_pin,
              'operator_clock':clocks, 'owner_clock':owner_clock, 'started_monotonic':started, 'cleanup_deadline_monotonic':cleanup_deadline, 'requests':[], 'errors':[],
              'diagnostic_complete':False, 'native_started':False, 'cleanup_complete':False,
              'scope':'One candidate persistent native process, sixteen fixed accepted full/seek inputs, exact normal6f4 PCM. Process first-request does not assert cold caches. No baseline process, UI/audio/service, latency or causal qualification.'}
    native = owner = original = capture = None
    initialized = constructing = False
    handlers = {}; stop = threading.Event(); watcher = None; watch_errors = []
    specs = {**{'asset:'+k:v for k,v in plan['assets'].items()}, **{'helper:'+k:v for k,v in plan['helpers'].items()},
             **{'source:'+k:v for k,v in plan['sources'].items()}, 'build_receipt':plan['build_receipt']}
    def checkpoint(): save(OUTPUT/'result.json', report)
    def interrupted(signum, frame):
        report['interruption_signal'] = signum
        if not constructing: raise KeyboardInterrupt
    def verify(when, limit):
        values = {k:pin_read(v['path'], v, deadline=limit)[0] for k,v in specs.items()}
        report[when] = values
        return values
    def retain_streams():
        retained = {}
        for name, limit in (('stderr',256*1024),('stdout',128*1024)):
            source = native.root/('runtime.'+name)
            if not source.exists(): continue
            require(source.stat().st_size <= limit, 'Capture exceeds fixed limit')
            data = source.read_bytes()
            target = OUTPUT/('native.'+name)
            if target.exists(): require(target.read_bytes() == data, 'Complete capture changed after retention')
            else:
                with target.open('xb') as stream: require(stream.write(data) == len(data), 'Short retained capture write')
            retained[name] = {'path':str(target),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'truncated':False}
        report['retained_streams'] = retained

    def owner_conditions(label):
        power = owner.power_state()
        require(power['ac_online'] and power['lid_open'], 'AC/open lid changed: '+label)
        row = owner.observation(sensor_paths); row['power'] = power; row['phase'] = label
        report.setdefault('host_observations', []).append(row)
        require(not row['read_errors'], 'Host observation failed: '+label)
        return row
    try:
        handlers = {s:signal.signal(s, interrupted) for s in (signal.SIGINT, signal.SIGTERM)}
        verify('pins_before', before_native)
        require(not any(k.startswith(DEBUG_PREFIXES) for k in os.environ), 'Unset inherited GPU/DRM/trace switches; logger must be OFF')
        sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT/'tools/benchmarks'))
        owner = load_helper('owner', plan['helpers']['owner'], before_native)
        original = load_helper('original', plan['helpers']['original'], before_native)
        normalizer = load_helper('normalizer', plan['helpers']['normalizer'], before_native)
        observer = load_helper('readiness', plan['helpers']['readiness'], before_native)
        capture = load_helper('capture', plan['helpers']['capture'], before_native)
        proof = decode(pin_read(plan['assets']['reference']['path'], plan['assets']['reference'], maximum=2*1024**2, deadline=before_native, keep=True)[1])
        expected = original.validate_reference(proof,FIXED['model'])
        comparison = load_helper('comparison',plan['helpers']['comparison'],before_native)
        consumer = load_helper('consumer',plan['helpers']['consumer'],before_native)
        host_validator = load_helper('host_validator',plan['helpers']['host_validator'],before_native)
        input_identity = load_helper('input_identity',plan['helpers']['input_identity'],before_native)
        require(tuple(original.CASE_IDS)==CASE_IDS, 'Accepted case order differs')
        tracks = comparison.load_track_plan(before_native)
        np,unused_runtime,cases = comparison.prepare_cases(tracks,before_native)
        validate_prepared_cases(cases,expected)
        report['reference']={'runtime_sha256':FIXED['normal_runtime'],'proof_pin':plan['assets']['reference'],
            'case_ids':list(CASE_IDS),'normalization':'Existing whole-source mono statistics, valid frames normalized before zero padding'}
        verify('full_hashes_before_cool_readiness', before_native)
        require(report['pins_before'] == report['full_hashes_before_cool_readiness'], 'Preparation changed pins')
        guard_script, guard_unit = (Path(plan['assets'][k]['path']) for k in ('guard_script','guard_unit'))
        report['guard_before'] = owner.guard_identity(guard_script, guard_unit)
        sensor_paths = owner.sensor_paths()
        zones = [Path(p).parent for p,t in sensor_paths.items() if t == 'x86_pkg_temp']
        require(len(zones) == 1, 'One package zone required')
        expected_guard = None; since = previous = None; cool_rows = []
        while time.monotonic() < before_native:
            row = observer.capture(zones[0], before_native); now = row['finished_monotonic']
            current = observer.identity(row)
            if expected_guard is None and current is not None: expected_guard = current
            require(current is None or current == expected_guard, 'Guard changed during cooldown')
            good = observer.ready(row, expected_guard) and (previous is None or now-previous <= 20)
            observed=owner_conditions('cool_readiness')
            good=good and host_admission_ok(observed,zones[0]/'temp',55000)
            since = (since if since is not None else now) if good else None
            row.update(ready_observation=good, consecutive_span_seconds=now-since if since is not None else 0)
            cool_rows.append(row); report['cool_readiness'] = cool_rows; checkpoint()
            if good and now-since >= 60: break
            previous = now
            time.sleep(max(0,min(10,before_native-time.monotonic())))
        require(since is not None and time.monotonic() < before_native and cool_rows[-1]['consecutive_span_seconds'] >= 60, 'Original bounded normal cooldown failed')
        require(pin_read(HUMAN, human_pin, maximum=16384, deadline=before_native)[0] == human_pin, 'Original human record changed')
        for old in report['pins_before'].values():
            now = Path(old['path']).lstat()
            require([now.st_dev,now.st_ino,now.st_size,now.st_mtime_ns,now.st_ctime_ns] == old['identity'], 'Pin metadata changed after cooldown')
        fresh = observer.capture(zones[0], before_native); observer.ready(fresh, expected_guard)
        temp = fresh.get('package_millidegrees_C')
        require(not fresh['errors'] and observer.identity(fresh) == expected_guard and fresh.get('profile') == 'balanced' and
                fresh.get('holds') == '' and fresh.get('latest_message_claims_recovered') and fresh.get('journal_identity_matches_service') and
                type(temp) is int and 0 <= temp <= 70000, 'Fresh <=70C/balanced/recovered/same-guard admission failed')
        row = owner_conditions('immediately_before_native')
        require(host_admission_ok(row,zones[0]/'temp',70000,fresh=True),
                'Fresh same-package <=70C/natural balanced/EPP admission absent')
        require(owner.guard_identity(guard_script, guard_unit) == report['guard_before'] and time.monotonic() < before_native,
                'Guard identity/admission deadline changed')
        report['fresh_admission'] = fresh
        profile_deadline = min(owner_clock['started_monotonic']+READINESS+PROFILE,deadline-CLEANUP,time.monotonic()+PROFILE)
        require(profile_deadline-time.monotonic() >= 2 and clocks['operator_deadline']-time.monotonic() >= PROFILE+CLEANUP,
                'Original operator window cannot fit bounded diagnostic and cleanup')
        checkpoint(); constructing = True; report['native_construction_attempted'] = True
        try:
            native = capture.CapturedNativeRuntime.__new__(capture.CapturedNativeRuntime)
            capture.CapturedNativeRuntime.__init__(native, Path(plan['assets']['candidate']['path']), Path(plan['assets']['model']['path']),
                'vulkan', 2, min(REQUEST,profile_deadline-time.monotonic()), passive_openmp=True,
                spool_directory=OUTPUT/'native-spool', max_stderr_bytes=capture.STDERR_LIMIT)
            initialized = True
        finally:
            constructing = False
            report['native_started'] = getattr(native,'process',None) is not None
        if 'interruption_signal' in report: raise KeyboardInterrupt
        report['native_identity'] = original.process_identity(native.process.pid,
            [plan['assets']['candidate']['path'],'--model',plan['assets']['model']['path'],'--backend','vulkan','--threads','2'])
        require(os.getpgid(native.process.pid) == native.process.pid, 'Owned native session group differs')
        checkpoint()
        def watch():
            next_host = 0
            while not stop.wait(.05):
                try:
                    require(time.monotonic() < profile_deadline, 'Original native profile deadline exhausted')
                    require(not (native.capture['overflow'] or native.capture['read_errors'] or native.capture['write_errors']), 'Bounded capture failed')
                    if time.monotonic() >= next_host:
                        owner_conditions('native_monitor')
                        require(owner.guard_identity(guard_script,guard_unit) == report['guard_before'], 'Active guard identity changed')
                        next_host = time.monotonic()+2
                except Exception as error:
                    watch_errors.append(str(error)[:1024]); native.abort(); return
        watcher = threading.Thread(target=watch, name='host-pcm-deadline', daemon=True); watcher.start()
        ready = report['ready'] = native.start()
        require(ready.get('backend') == 'vulkan' and ready.get('threads') == 2 and ready.get('pid') == native.process.pid and
                ready.get('revision') == '0097d365a00b52a6991ad7618f0a04e8d2935e47' and
                ready.get('fence_wait_mode') == 'blocking' and ready.get('weight_storage') == 'native' and
                ready.get('model') == plan['assets']['model']['path'] and
                ready.get('process_environment') == {'OMP_WAIT_POLICY':'PASSIVE','GOMP_SPINCOUNT':'0'}, 'Ready identity/policy differs')
        for request_id,case in enumerate(cases,1):
            owner_conditions('before_request_'+str(request_id))
            require(time.monotonic() < profile_deadline and not watch_errors, 'Original native profile exhausted')
            native.timeout = min(REQUEST,profile_deadline-time.monotonic())
            row = {'request_id':request_id,'case_id':case['id'],'start_frame':case['start_frame'],
                   'valid_frames':case['valid_frames'],'completed':False, 'process_first_request':request_id == 1}
            report['requests'].append(row); checkpoint()
            try:
                row['started_ns'] = time.monotonic_ns()
                samples=case['samples'];proven=expected[case['id']]
                row['expected_identity']={'schema':1,'sample_format':'f32le','shape':[343980,2],
                    'bytes':2751840,'sha256':proven['input_sha256']}
                row['producer_identity']=input_identity.fingerprint(samples)
                require(time.monotonic()<profile_deadline and not watch_errors,'Comparison deadline exhausted before RPC')
                produced,metrics = native.infer(samples,request_id)
                row['finished_ns'] = time.monotonic_ns(); validate_metrics(metrics,request_id)
                require(produced.shape == (4,343980,2) and produced.dtype.str == '<f4' and produced.flags.c_contiguous and
                        hashlib.sha256(memoryview(produced)).hexdigest() == proven['output_sha256'], 'Exact normal-reference PCM mismatch')
                row['written_identity']=input_identity.verify_written(native.root/'input.f32',row['expected_identity'])
                consumer.validate_input_identity(row['producer_identity'],row['written_identity'],row['expected_identity'])
                require(time.monotonic()<profile_deadline and not watch_errors,'Comparison deadline exhausted verifying PCM/input')
                row.update(native_metrics=metrics,output_sha256=proven['output_sha256'],input_sha256=proven['input_sha256'],completed=True,exact_pcm_match=True)
                produced = None
            finally:
                original.cleanup_request(native,row); checkpoint()
            owner_conditions('after_request_'+str(request_id))
        stop.set(); watcher.join(timeout=min(8,max(0,deadline-time.monotonic())))
        report['native_shutdown'] = native.idle_quit(completed_idle=True, deadline=min(cleanup_deadline,time.monotonic()+2))
        require(report['native_shutdown']['graceful_complete'], 'Owned native did not idle-quit/reap within original2s')
        report['capture'] = native.finish_capture(min(cleanup_deadline,time.monotonic()+2))
        stderr = pin_read(native.root/'runtime.stderr', maximum=256*1024, deadline=cleanup_deadline, keep=True)[1]
        stdout = pin_read(native.root/'runtime.stdout', maximum=128*1024, deadline=cleanup_deadline, keep=True)[1]
        retain_streams()
        report['host_boundaries'] = parse_capture(stderr,stdout,ready,report['requests'],consumer,host_validator)
        report['status'] = 'captured'
    except KeyboardInterrupt:
        report['status'] = 'interrupted'
    except Exception as error:
        report['status'] = 'failed'; report['errors'].append({'type':type(error).__name__, 'message':str(error)[:8192]})
    finally:
        for sig in handlers: signal.signal(sig,signal.SIG_IGN)
        stop.set()
        if watcher is not None: watcher.join(timeout=min(8,max(0,deadline-time.monotonic())))
        report['watchdog_errors'] = watch_errors
        if native is not None and original is not None:
            cleanup_owned(native,initialized,original,OUTPUT,cleanup_deadline,report,retain_streams)
        try:
            verify('pins_after',cleanup_deadline)
            report['pins_unchanged'] = report.get('pins_before') == report['pins_after']
            if owner is not None and 'guard_before' in report:
                report['guard_after'] = owner.guard_identity(Path(plan['assets']['guard_script']['path']),Path(plan['assets']['guard_unit']['path']))
        except Exception as error:
            report['errors'].append({'phase':'finalization','message':str(error)[:8192]})
        c = report.get('cleanup',{})
        report['cleanup_complete'] = (all(c.get(k) is True for k in ('native_reaped','native_resources_closed','temporary_directory_removed')) and
            report.get('native_identity_absent') is True and report.get('native_group_absent') is True and
            (watcher is None or not watcher.is_alive()))
        report['finished_monotonic'] = time.monotonic()
        report['within_command_budget'] = report['finished_monotonic'] <= cleanup_deadline
        if report['status'] == 'captured':
            try: final_gates(report); report['status'] = 'complete'
            except Exception as error:
                report['status'] = 'failed'; report['errors'].append({'phase':'final_gates','message':str(error)})
        normalize_errors(report)
        checkpoint()
        save(BASE/'diagnostic-assessment.json',report)  # Same canonical report consumed by the unchanged owner.
        for sig,handler in handlers.items(): signal.signal(sig,handler)
    return 0 if report['diagnostic_complete'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--run', action='store_true'); group.add_argument('--verify-files', action='store_true')
    args = parser.parse_args()
    if not args.run and not args.verify_files:
        print(json.dumps({'status':'unarmed_dry_plan','mode':MODE,'host_queried':False,'native_started':False,
                          'requests':16,'command_seconds':TOTAL,'operator_seconds':600,'native_fields':10,'service_fields_unobserved':3}))
        return 0
    plan_pin,raw = pin_read(PLAN,maximum=256*1024,keep=True); plan=validate_plan(decode(raw))
    if args.verify_files:
        for row in [*plan['assets'].values(),*plan['helpers'].values(),*plan['sources'].values(),plan['build_receipt']]: pin_read(row['path'],row)
        print(json.dumps({'status':'files_verified_only','native_started':False,'host_queried':False})); return 0
    require(plan.get('status')=='frozen_pending_fresh_readiness','Draft packet is unarmed pending root review')
    human_pin,raw = pin_read(HUMAN,maximum=16384,keep=True)
    return run(plan,plan_pin,decode(raw),human_pin)


if __name__ == '__main__':
    raise SystemExit(main())
