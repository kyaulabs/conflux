#!/usr/bin/env python3
"""Private verified input-identity/profile/owner-close service composition.

Loading composes classes only. Only explicit main() enters the original service.
No worker, wire, inference, capture or shutdown implementation is replaced here.
"""
import hashlib
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
HERE = Path(__file__).resolve().parent
ENTRY = ROOT/'benchmarks-local/m2-live-fallback-2026-10-20/packed-attention-views-01/matrix-dispatch-metadata-01/service_profile.py'
ENTRY_BYTES = 2405
ENTRY_SHA = '9d6cb61bf401b359f22e37bcefd4673cf4904d72e3e6f40562b1627f2c1196a9'
CONTEXT = ROOT/'build/m2-graph-interval-01/identity/context_capture.py'
CONTEXT_SHA = '98743333e9c7c39101a882f49ff0c0c7d868d47050d971279b87dbaf508e4978'
PROFILE = HERE/'native_profile_capture.py'
PROFILE_SHA = '7dad2be318c8df7854c1d0a203465cee8ba0cfee0cf2e534a2f53cc7be2b4af2'
SERVICE = ROOT/'benchmarks-local/m2-live-fallback-2026-10-20/packed-attention-views-01/service_drm.py'
SERVICE_SHA = '50f5b94bbcee0ac4087dbd438deb8e1b0532502ad0d770b56bff20a2ff9b5586'
OWNER_CLOSE = ROOT/'build/m2-host-boundaries-01/player-diagnostic-08/service_host_profile.py'
OWNER_CLOSE_SHA = '3f9809ba214b1301d1e826486e9362438f015ffbb558c906cdc67cf10fd40897'


def _verified_loader():
    # Same small stdlib-only bootstrap as the retained owner-close entry. Every
    # actual context/profile/service/installer then uses its unchanged _load.
    if ENTRY.resolve(strict=True) != ENTRY or not ENTRY.is_file() or ENTRY.stat().st_size != ENTRY_BYTES:
        raise ValueError('Canonical retained loader size/type differs')
    raw = ENTRY.read_bytes()
    if len(raw) != ENTRY_BYTES or hashlib.sha256(raw).hexdigest() != ENTRY_SHA:
        raise ValueError('Retained loader differs')
    spec = importlib.util.spec_from_file_location('graph_interval_verified_loader', ENTRY)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    exec(compile(raw, str(ENTRY), 'exec'), module.__dict__)
    return module


def load_service():
    loader = _verified_loader()
    context = loader._load('context_capture', CONTEXT, CONTEXT_SHA)
    context._PROFILE_VERIFIED_SHA = CONTEXT_SHA
    profile = loader._load('native_profile_capture', PROFILE, PROFILE_SHA)
    context.ContextNativeRuntime = profile.ProfileNativeRuntime
    service = loader._load('private_profile_service', SERVICE, SERVICE_SHA)
    owner_close = loader._load('graph_interval_owner_close', OWNER_CLOSE, OWNER_CLOSE_SHA)
    service = owner_close.install(service, profile, context)
    # install() keeps its historical source identity. The public service pin
    # must instead describe this actual launched entry, after composition.
    service.__file__ = str(Path(__file__).resolve())
    return service, profile, context


def main():
    service, _profile, _context = load_service()
    return service.main()


if __name__ == '__main__':
    raise SystemExit(main())
