"""Private offline capture consumer; no launch, readiness, model or audio path.

The exact corrected08 parser retains all serial/service/native/owner-abort checks. Added
fields qualify only completed coarse GPU intervals and producer/written metadata.
They do not attest native-read bytes or reference PCM for arbitrary player input.
"""
import hashlib
import importlib.util
import math
import os
from pathlib import Path
import stat
import sys
import time

MODE='m2-graph-interval-player-120-01'
ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
ORIGINAL={'path':str(ROOT/'build/m2-host-boundaries-01/player-trace-schema-fix-01/run_host_player.py'),
    'bytes':44150,'sha256':'7ab7659e86d589a5407c4d06f78c62bdbc73e41a11018e0341e4956253b5c7c6'}
FIELDS={'path':str(ROOT/'build/m2-graph-interval-01/consumer/interval_fields.py'),
    'bytes':4818,'sha256':'2583cd899b127ed65ae8b0f6e8f46b22a35a7f1d8768689885da62ea410ea0cf'}


def require(ok,message):
    if not ok:raise ValueError(message)


def load_pinned(name,pin,deadline=math.inf):
    """Existing stable regular-file/no-follow pattern, before source execution."""
    path=Path(pin['path'])
    require(time.monotonic()<deadline and path.is_absolute() and path.resolve(strict=True)==path,
        'Pinned source deadline/canonical path differs')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    signature=lambda value:(value.st_dev,value.st_ino,value.st_size,value.st_mtime_ns,value.st_ctime_ns)
    try:
        before=os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and 0<before.st_size==pin['bytes']<=256*1024,'Pinned source size/type differs')
        raw=bytearray()
        while len(raw)<before.st_size:
            require(time.monotonic()<deadline,'Pinned source read deadline exhausted')
            block=os.read(fd,min(65536,before.st_size-len(raw)));require(bool(block),'Pinned source shortened')
            raw.extend(block)
        require(signature(before)==signature(os.fstat(fd))==signature(path.lstat()) and
            hashlib.sha256(raw).hexdigest()==pin['sha256'] and time.monotonic()<deadline,
            'Pinned source identity/hash/deadline differs')
    finally:os.close(fd)
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    exec(compile(bytes(raw),str(path),'exec'),module.__dict__)
    return module


def incomplete_host(fields,original_validate,keys,host,ordinal,previous):
    stripped=fields.original_fields(host,keys)
    prior=None if previous is None else fields.original_fields(previous,keys)
    original_validate(stripped,ordinal,prior,completed=False)
    require(all(type(host[key]) is int and 0<=host[key]<=fields.U64 for key in fields.INTERVAL_INTS) and
        type(host['gpu_valid']) is bool and type(host['gpu_wrapped']) is bool and
        host['gpu_valid_bits']<=64 and host['gpu_period_f32_bits']<2**32 and host['gpu_queue_family']<2**32,
        'Incomplete additive field schema/range differs')
    # Raw final records can contain available timestamps even when response/output
    # processing was aborted. Never turn them into a completed request interval.


def parse_capture(capture,observations,native_result,deadline=math.inf):
    original=load_pinned('graph_interval_player_original',ORIGINAL,deadline)
    fields=load_pinned('graph_interval_player_fields',FIELDS,deadline)
    original.MODE=MODE
    saved_validate=original.validate_host
    intervals={}
    def validate(host,ordinal,previous,completed=True):
        if completed:
            require(ordinal not in intervals,'Duplicate completed interval ordinal')
            intervals[ordinal]=fields.validate_completed_host(host,ordinal,previous,
                original_keys=original.utility().HOST_KEYS,original_validate_host=saved_validate)
        else:incomplete_host(fields,saved_validate,original.utility().HOST_KEYS,host,ordinal,previous)
    original.validate_host=validate  # Only MODE and this callback differ in this private instance.
    trace_path=Path(capture)/'native-request-trace.jsonl'
    trace_pin,raw=original.pin_read(trace_path,maximum=4*1024**2,deadline=deadline,keep=True)
    result=original.parse_capture(Path(capture),observations,native_result,deadline)
    require(original.pin_read(trace_path,maximum=4*1024**2,deadline=deadline)[0]==trace_pin,
        'Context changed across original parse and metadata validation')
    context=[original.decode(line) for line in raw.splitlines()]
    begins={};ends={}
    for row in context:
        if row.get('event')=='request_begin':
            key=row['context']['request_id'];require(key not in begins,'Duplicate begin identity');begins[key]=row
        elif row.get('event')=='request_complete':
            key=row['request_id'];require(key not in ends,'Duplicate completion identity');ends[key]=row
    for row in result['requests']:
        request=row['request_id'];begin=begins[request];end=ends[request]
        producer=begin['context'].get('input_identity')
        written=end['gpu_trace'].get('written_input_identity')
        identity=fields.validate_input_identity(producer,written)
        require(begin['context']['generation']==row['generation'] and begin['native']==result['native'] and
            row['graph_ordinal'] in intervals,'Completed metadata/request/native lineage differs')
        row.update(producer_input_identity={**identity,'shape':list(identity['shape'])},
            written_input_identity={**identity,'shape':list(identity['shape'])},input_identity_match=True,
            gpu_interval=dict(intervals[row['graph_ordinal']]),native_read_attested=False,reference_pcm_validated=False)
    require(len(intervals)==len(result['requests'])==len(ends),'Completed interval/metadata population differs')
    tail=result['intentionally_aborted_final_request']
    if tail is not None:
        producer=tail['context'].get('input_identity')
        fields._identity(producer)  # Exact pinned schema validation only; no fabricated written identity.
        tail.update(producer_input_identity={**producer,'shape':list(producer['shape'])},
            input_metadata_status='producer_only',gpu_timing_complete=False,native_read_attested=False,reference_pcm_validated=False,
            retained_final_graph_scope='Raw/unqualified final graph records; no completed request timing or written-input attestation.')
    result.update(mode=MODE,qualified=False,timing_qualification=False,reference_pcm_validated=False,native_read_attested=False,
        context_metadata_pin=trace_pin,
        scope='Unchanged08 serial/service/context/generation/hop/owner-abort checks plus valid coarse intervals for completed requests and matching producer/written normalized metadata. GPU intervals include synchronization; arbitrary player windows have no reference-PCM/native-read proof. Explicit final abort retains producer-only metadata and raw graph/tail evidence.')
    require(time.monotonic()<deadline,'Capture metadata validation deadline exhausted')
    return result
