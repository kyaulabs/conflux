"""Archive both completed repeat attempts; audio/model/binary data stay private."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
DEST=ROOT/'build/m2-profile-reporting-worktree/docs/benchmarks/data/m2-player-repeat-2026-10-26'
RAW=BASE/'archive-raw-01'


def sha(raw):return hashlib.sha256(raw).hexdigest()


def main():
    assert not DEST.exists() and not RAW.exists()
    first=json.loads((BASE/'player-01/root-finished-01.json').read_text())
    second=json.loads((BASE/'player-02/root-finished-01.json').read_text())
    audio=json.loads((BASE/'player-02/root-audio-results-01.json').read_text())
    observation=json.loads((BASE/'player-01/root-user-window-observation-01.json').read_text())
    assert all(x['cleanup_complete'] and x['root_verification_within_original_600_seconds'] for x in (first,second))
    assert first['status']=='stopped_early_window_exposure_failure' and first['p99_for_requested_120s'] is None
    assert second['requested120s_complete']
    assert observation['human_reply']=='I switched, covered or minimized it'
    assert audio['hop_count']==21 and audio['p99_ms']==3764.50896600727 and audio['at_or_above4095_ms']==0
    sources=[]
    for arm in ('player-01','player-02'):
        run=BASE/arm
        sources += [(p,arm+'-'+p.name) for p in run.iterdir() if p.is_file() and
            (p.suffix in ('.json','.py') or p.name in ('offline-checks-01.log','file-preflight-01.log','launch-command-01.txt'))]
        sources += [(run/'output-01'/name,arm+'-output-'+name) for name in (
            'result.json','native-result.json','progress.json','observations.jsonl','host-observations.jsonl',
            'owned-pipewire-cleanup.json','native.stdout.log','native.stderr.log')]
    sources += [(BASE/'close_player02.py','close-player02.py'),
        (ROOT/'build/m2-meter-stability-01/analyze_ui_comparison.py','shared-audio-thread-analysis.py'),
        (Path(__file__).resolve(),'archive-repeat.py')]
    assert len(sources)==len({name for _,name in sources})
    RAW.mkdir(mode=0o700);rows=[]
    for path,name in sorted(sources,key=lambda x:x[1]):
        assert path.resolve(strict=True)==path and path.is_file() and path.stat().st_size<32*1024**2
        raw=path.read_bytes();raw.decode('utf-8')
        if path.suffix=='.json':json.loads(raw)
        if path.suffix=='.jsonl':
            assert raw.endswith(b'\n')
            for line in raw.splitlines():json.loads(line)
        (RAW/name).write_bytes(raw)
        rows.append({'original_path':str(path),'raw_file':name,'raw_bytes':len(raw),'raw_sha256':sha(raw)})
    scanner=shutil.which('gitleaks');assert scanner
    command=[scanner,'dir','--no-banner','--redact','--max-target-megabytes','32',str(RAW)]
    with (BASE/'archive-gitleaks-01.log').open('xb') as stream:
        scan=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
    log=(BASE/'archive-gitleaks-01.log').read_bytes();total=sum(x['raw_bytes'] for x in rows)
    count=re.search(rb'scanned ~(\d+) bytes',log)
    assert scan.returncode==0 and count and int(count[1])==total
    DEST.mkdir()
    for row in rows:
        raw=(RAW/row['raw_file']).read_bytes();compressed=gzip.compress(raw,compresslevel=9,mtime=0)
        assert gzip.decompress(compressed)==raw
        name=row['raw_file']+'.gz';(DEST/name).write_bytes(compressed)
        row.update(archive_file=name,archive_bytes=len(compressed),archive_sha256=sha(compressed))
    manifest={'schema':1,'qualified':False,'production_code_changed':False,'strict_service_target_ms':4095,
        'first_attempt':'Incomplete at20.850s; retained failure and later operator-confirmed exposure interruption',
        'second_attempt':'Complete120.011s;21 service hops;3764.50896600727ms nearest-rank p99',
        'both_root_cleanup_checks_within_original600s':True,'normal_runtime_confirmation_pending':True,
        'getter_counters_enabled':False,'coarse_GPU_interval_instrumentation_enabled':True,
        'power_ceiling_W':15,'guard_unchanged':True,'milestone_or_release_gate_changed':False,
        'scope':'Short diagnostic repeat only. No sustained, normal-runtime, causal speedup, musical or physical-output-latency qualification.',
        'files':rows,'total_raw_bytes':total,'total_archive_bytes':sum(x['archive_bytes'] for x in rows),
        'gzip_roundtrip_and_original_hashes_verified':True,'no_audio_models_executables_PCM_or_cache_published':True,
        'raw_secret_scan':{'command':command,'exit':0,'scanned_bytes':total,'log_sha256':sha(log)}}
    with (DEST/'verification.json').open('x') as stream:json.dump(manifest,stream,indent=2,allow_nan=False);stream.write('\n')
    for row in rows:
        compressed=(DEST/row['archive_file']).read_bytes()
        assert sha(compressed)==row['archive_sha256'] and sha(gzip.decompress(compressed))==row['raw_sha256']
        (RAW/row['raw_file']).unlink()
    RAW.rmdir()
    print(json.dumps({'files':len(rows),'raw_bytes':total,'gzip_bytes':manifest['total_archive_bytes'],
        'all_raw_bytes_secret_scanned':True,'all_round_trips_verified':True}))


if __name__=='__main__':main()
