"""Build the fixed CPU-only reference on both hosts concurrently; no predictions."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import subprocess

BASE = Path(__file__).resolve().parent
SSH = ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no',
    '-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes',
    '-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222',
    '-p','4222','kyau@apollo.kyaulabs','python3 -']


def local():
    environment=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    with (BASE/'local-build.stdout.log').open('x') as out,(BASE/'local-build.stderr.log').open('x') as err:
        result=subprocess.run(['nice','-n','15','cmake','--build',str(BASE/'native-build-01'),'--parallel','1'],
            env=environment,stdout=out,stderr=err,timeout=180)
    result.check_returncode()
    binary=BASE/'native-build-01/keyfinder-global-worker'
    return dict(exit=0,binary=dict(path=str(binary),bytes=binary.stat().st_size,
        sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))


def apollo():
    code=r'''
from pathlib import Path
import hashlib,json,subprocess
base=Path('/srv/conflux-tests/work/keyfinder-global-20261028-01')
manifest=json.loads((base/'source-manifest-01.json').read_text())
for row in manifest['files']:
    path=base/'source'/row['path'];raw=path.read_bytes()
    assert path.is_file() and not path.is_symlink() and len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
assert not subprocess.check_output(D+['ps','-aq'],text=True).strip()
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
name='conflux-keyfinder-global-build-20261028-01';run='keyfinder-global-build-20261028-01'
inside="""from pathlib import Path
import subprocess
assert not Path('/dev/nvidia0').exists() and not Path('/dev/dri').exists()
subprocess.run(['cmake','-S','/src/worker','-B','/build','-G','Ninja','-DKEYFINDER_SOURCE=/src/upstream','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_POLICY_VERSION_MINIMUM=3.5'],check=True,timeout=40)
subprocess.run(['cmake','--build','/build','--parallel','1'],check=True,timeout=180)
"""
command=D+['run','--rm','--name',name,'--runtime=runc','--init',
    '--label','org.kyaulabs.conflux.tests=1','--label','org.kyaulabs.conflux.run='+run,
    '--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true',
    '--user=1000:1000','--memory=1g','--cpus=1','--pids-limit=128',
    '--tmpfs=/tmp:rw,nosuid,nodev,size=256m,mode=1777',
    '--env','OPENBLAS_NUM_THREADS=1','--env','OMP_NUM_THREADS=1',
    '--mount','type=bind,src='+str(base/'source')+',dst=/src,readonly',
    '--mount','type=bind,src='+str(base/'native')+',dst=/build',image,'python','-c',inside]
with (base/'results/build-command-01.json').open('x') as out:out.write(json.dumps(command,indent=2)+chr(10))
try:
    with (base/'results/build.log').open('x') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=230)
    result.check_returncode()
finally:
    found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
    if found.returncode==0:
        value=json.loads(found.stdout)[0]
        assert value['Image']==image and value['Config']['Labels'].get('org.kyaulabs.conflux.run')==run
        subprocess.run(D+['rm','--force',value['Id']],check=True,capture_output=True,timeout=10)
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
binary=base/'native/keyfinder-global-worker'
receipt=dict(exit=0,binary=dict(path=str(binary),bytes=binary.stat().st_size,sha256=hashlib.sha256(binary.read_bytes()).hexdigest()),
    container_absent=True,GPU_audio_model_started=False)
(base/'results/build-receipt-01.json').write_text(json.dumps(receipt,indent=2)+chr(10));print(json.dumps(receipt))
'''
    with (BASE/'apollo-build.stdout.log').open('x') as out,(BASE/'apollo-build.stderr.log').open('x') as err:
        result=subprocess.run(SSH,input=code,text=True,stdout=out,stderr=err,timeout=250)
    result.check_returncode()
    return json.loads((BASE/'apollo-build.stdout.log').read_text())


with ThreadPoolExecutor(max_workers=2) as pool:
    first=pool.submit(local);second=pool.submit(apollo)
    results={}
    for name,future in [('laptop',first),('apollo',second)]:
        try:results[name]=future.result()
        except BaseException as error:results[name]=dict(error=type(error).__name__+': '+str(error))
receipt=dict(schema=1,hosts=results,builds_concurrent=True,generated_tests_started=False,
    corpus_predictions_started=False,GPU_audio_model_started=False)
(BASE/'build-results-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
raise SystemExit(0 if all(result.get('exit')==0 for result in results.values()) else 1)
