"""Stage the fixed CPU-only reference experiment in its own Apollo directory."""
from pathlib import Path, PurePosixPath
import base64
import hashlib
import io
import json
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
OLD = BASE.parent/'m2-keyfinder-assessment-01'
REMOTE = '/srv/conflux-tests/work/keyfinder-global-20261028-01'
SSH = ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no',
    '-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes',
    '-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222',
    '-p','4222','kyau@apollo.kyaulabs','python3 -']
plan = json.loads((BASE/'prospective-plan-01.json').read_text())
for row in plan['source_pins']:
    path=Path(row['path']);raw=path.read_bytes()
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
acquired=json.loads((OLD/'acquisition-01.json').read_text())
upstream=Path(acquired['source'])
files=[]
for row in acquired['source_files']:
    path=upstream/row['path'];raw=path.read_bytes()
    assert path.is_file() and not path.is_symlink()
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    files.append(('upstream/'+row['path'],raw))
for name in ['CMakeLists.txt','keyfinder_global_worker.cpp','test_global_worker.py','prospective-plan-01.json']:
    files.append(('worker/'+name,(BASE/name).read_bytes()))
files.append(('fixtures/test_keyfinder_context.py',(OLD/'test_keyfinder_context.py').read_bytes()))
manifest=dict(schema=1,upstream_commit=plan['upstream_commit'],files=[dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for name,raw in files],
    corpus_predictions_started=False,GPU_audio_model_started=False)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
    for name,raw in files:
        info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;archive.addfile(info,io.BytesIO(raw))
raw=buffer.getvalue();assert len(raw)<2*1024**2 and sum(len(data) for _,data in files)<5*1024**2
(BASE/'source-transfer-01.tar.gz').write_bytes(raw)
header='BASE='+repr(REMOTE)+'\nMANIFEST='+repr(manifest)+'\nARCHIVE='+repr(base64.b64encode(raw).decode())+'\n'
code=r'''
from pathlib import Path,PurePosixPath
import base64,hashlib,io,json,tarfile
base=Path(BASE);assert not base.exists()
base.mkdir(mode=0o700)
for name in ['source','native','results']:(base/name).mkdir(mode=0o700)
source=base/'source';raw=base64.b64decode(ARCHIVE,validate=True);assert len(raw)<2*1024**2
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
    assert set(archive.getnames())=={row['path'] for row in MANIFEST['files']}
    for row in MANIFEST['files']:
        name=PurePosixPath(row['path']);assert not name.is_absolute() and '..' not in name.parts
        member=archive.getmember(str(name));assert member.isfile() and member.size==row['bytes']
        data=archive.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==row['sha256']
        path=source.joinpath(*name.parts);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
with (base/'source-manifest-01.json').open('x') as out:out.write(json.dumps(MANIFEST,indent=2)+'\n')
print(json.dumps(dict(staged=True,files=len(MANIFEST['files']),archive_sha256=hashlib.sha256(raw).hexdigest(),
    GPU_audio_model_started=False,protected_resources_changed=False)))
'''
result=subprocess.run(SSH,input=header+code,capture_output=True,text=True,timeout=45)
(BASE/'source-transfer.stdout.log').write_text(result.stdout)
(BASE/'source-transfer.stderr.log').write_text(result.stderr)
result.check_returncode()
receipt=dict(local_manifest=manifest,remote=json.loads(result.stdout),remote_root=REMOTE)
(BASE/'source-transfer-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(result.stdout.strip())
