"""Retain the noexec fixture failure, update only its interpreter invocation, rerun generated checks."""
from pathlib import Path
import hashlib,json,shlex,subprocess
BASE=Path(__file__).resolve().parent
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
header='TEST='+repr((BASE/'test_corpus.py').read_text())+'\n'
code=r'''
from pathlib import Path
import hashlib,json,subprocess
base=Path('/srv/conflux-tests/work/keyfinder-global-20261028-01/corpus-01')
old=json.loads((base/'offline-preparation-01.json').read_text());assert old['offline_exit']!=0 and 'PermissionError'in old['stderr']
manifest=json.loads((base/'input-manifest-01.json').read_text())
for row in manifest:
 p=base/row['file'];assert p.stat().st_size==row['bytes']
 with p.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256']
p=base/'operations/test_corpus.py';p.rename(base/'operations/test_corpus-before-noexec-01.py');p.write_text(TEST);p.chmod(0o600)
for row in manifest:
 if row['file']=='operations/test_corpus.py':row.update(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(base/'input-manifest-02.json').write_text(json.dumps(manifest,indent=2)+chr(10))
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
assert not subprocess.check_output(D+['ps','-aq'],text=True).strip()
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919';run='keyfinder-global-corpus-offline-20261028-02';name='conflux-'+run
inside="""from pathlib import Path
import subprocess
assert not Path('/dev/nvidia0').exists()and not Path('/dev/dri').exists()
r=subprocess.run(['ldd','/prepare/prepare-fmak-source'],capture_output=True,text=True,check=True);assert 'not found'not in r.stdout
r=subprocess.run(['/prepare/prepare-fmak-source'],capture_output=True,text=True);assert r.returncode==2
r=subprocess.run(['python','-B','-m','unittest','discover','-s','/operations','-p','test_corpus.py'],timeout=30)
raise SystemExit(r.returncode)
"""
command=D+['run','--rm','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--memory=1g','--cpus=1','--pids-limit=128','--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--label','org.kyaulabs.conflux.run='+run,
 '--mount','type=bind,src='+str(base/'bin')+',dst=/prepare,readonly','--mount','type=bind,src='+str(base/'operations')+',dst=/operations,readonly',image,'python','-c',inside]
try:r=subprocess.run(command,capture_output=True,text=True,timeout=60)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  c=json.loads(found.stdout)[0];assert c['Image']==image and c['Config']['Labels']['org.kyaulabs.conflux.run']==run
  subprocess.run(D+['rm','--force',c['Id']],capture_output=True,check=True,timeout=10)
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
receipt=dict(offline_exit=r.returncode,stdout=r.stdout,stderr=r.stderr,container_absent=True,GPU_audio_or_music_predictions_started=False,
 noexec_mount_unchanged=True,old_failure_retained=True,manifest_sha256=hashlib.sha256((base/'input-manifest-02.json').read_bytes()).hexdigest())
(base/'offline-preparation-02.json').write_text(json.dumps(receipt,indent=2)+chr(10));print(json.dumps(receipt));assert r.returncode==0,r.stderr
'''
compile(header+code,'correct-offline-fixture','exec')
r=subprocess.run(SSH+['python3 -'],input=header+code,capture_output=True,text=True,timeout=90)
(BASE/'corpus-offline-apollo-03.stdout.log').write_text(r.stdout);(BASE/'corpus-offline-apollo-03.stderr.log').write_text(r.stderr)
assert r.returncode==0, r.stderr[-6000:]
receipt=json.loads(r.stdout)
with(BASE/'corpus-preparation-02.json').open('x')as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
