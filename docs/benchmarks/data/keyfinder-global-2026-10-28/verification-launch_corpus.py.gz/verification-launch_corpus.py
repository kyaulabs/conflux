"""Run fixed CPU correctness captures on both hosts; no hardware readiness is consumed."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess,time
BASE=Path(__file__).resolve().parent
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']

def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--launch',action='store_true');args=a.parse_args()
 plan=json.loads((BASE/'corpus-plan-01.json').read_text());checks=json.loads((BASE/'corpus-preparation-02.json').read_text())
 assert checks['offline_exit']==0 and checks['container_absent']and checks['noexec_mount_unchanged']
 for p in plan['input_pins']:
  path=Path(p['path']);assert path.is_file()and not path.is_symlink()and path.stat().st_size==p['bytes']
  with path.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==p['sha256']
 assert plan['status']=='frozen_CPU_correctness_only'and plan['physical_readiness_required']is False
 assert not any((BASE/n).exists()for n in ('music-output-01','corpus-launch-reservation-01.json'))
 if not args.launch:print(json.dumps(dict(unarmed=True,input_pins_verified=True,GPU_audio_or_music_predictions_started=False)));return
 def state(unit):return subprocess.check_output(['systemctl','--user','show',unit,'--property=LoadState,MainPID'],text=True,timeout=5)
 assert 'LoadState=not-found'in state(plan['unit'])and'MainPID=0'in state(plan['unit'])
 with(BASE/'corpus-launch-reservation-01.json').open('x')as f:f.write(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),monotonic=time.monotonic(),scope='Goal-authorized CPU correctness only; no audio, GPU, latency qualification, OneDrive pause or idle inhibitor',no_retry=True,plan_sha256=hashlib.sha256((BASE/'corpus-plan-01.json').read_bytes()).hexdigest()),indent=2)+'\n')
 local=['systemd-run','--user','--unit='+plan['unit'],'--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no','--property=KillMode=control-group','--property=RuntimeMaxSec=1290s','--property=TimeoutStopSec=10s','--property=MemoryMax=1G','--property=TasksMax=128','--property=CPUQuota=100%','--property=Nice=15','--property=UMask=0077',
  '--property=StandardOutput=append:'+str(BASE/'corpus-laptop.stdout.log'),'--property=StandardError=append:'+str(BASE/'corpus-laptop.stderr.log'),'/usr/bin/python3.14','-B',str(BASE/'run_corpus.py'),'--owned','--plan',str(BASE/'corpus-plan-01.json'),'--output',str(BASE/'music-output-01')]
 code=r'''
from pathlib import Path
import hashlib,json,subprocess
base=Path('/srv/conflux-tests/work/keyfinder-global-20261028-01/corpus-01');unit='conflux-keyfinder-global-fmak-apollo-20261028-01.service'
state=subprocess.check_output(['systemctl','show',unit,'--property=LoadState,MainPID'],text=True,timeout=5);assert 'LoadState=not-found'in state and 'MainPID=0'in state
manifest=json.loads((base/'input-manifest-02.json').read_text())
for row in manifest:
 p=base/row['file'];assert p.stat().st_size==row['bytes']and not p.is_symlink()
 with p.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256']
assert json.loads((base/'offline-preparation-02.json').read_text())['offline_exit']==0
assert not(base/'results').exists();(base/'results').mkdir(mode=0o700)
owner=r"""from pathlib import Path
import json,subprocess
base=Path('/srv/conflux-tests/work/keyfinder-global-20261028-01/corpus-01')
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
assert not subprocess.check_output(D+['ps','-aq'],text=True).strip()
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919';run='keyfinder-global-corpus-music-20261028-01';name='conflux-'+run
command=D+['run','--rm','--name',name,'--runtime=runc','--init','--label','org.kyaulabs.conflux.run='+run,'--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--cpus=1','--memory=1g','--pids-limit=128','--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--env','CONFLUX_PRIVATE_KEY_REFERENCE=1',
 '--mount','type=bind,src='+str(base/'media')+',dst=/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-assessment-01/source-admission-01/media-01,readonly',
 '--mount','type=bind,src='+str(base/'bin')+',dst=/prepare,readonly',
 '--mount','type=bind,src='+str(base.parent/'native')+',dst=/worker,readonly',
 '--mount','type=bind,src='+str(base/'operations')+',dst=/operations,readonly',
 '--mount','type=bind,src='+str(base/'results')+',dst=/results',image,'timeout','--signal=TERM','--kill-after=5s','1230','python','-B','/operations/run_corpus.py','--owned','--plan','/operations/plan.json','--output','/results/output-01']
receipt=dict(scope='CPU correctness only; no music output, GPU, performance or physical qualification',command=command,passed=False)
try:
 with(base/'container-music.stdout.log').open('x')as out,(base/'container-music.stderr.log').open('x')as err:r=subprocess.run(command,stdout=out,stderr=err,timeout=1250)
 receipt['exit']=r.returncode
except BaseException as e:receipt['error']=type(e).__name__+': '+str(e)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  c=json.loads(found.stdout)[0];assert c['Image']==image and c['Config']['Labels']['org.kyaulabs.conflux.run']==run
  subprocess.run(D+['rm','--force',c['Id']],capture_output=True,check=True,timeout=10)
 receipt['container_absent']=subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
p=base/'results/output-01/prediction-receipt.json'
if p.exists():receipt['prediction_receipt']=json.loads(p.read_text())
receipt['passed']=receipt.get('exit')==0 and receipt['container_absent']and receipt.get('prediction_receipt',{}).get('all_inferable_sources_completed')is True
with(base/'music-owner-receipt-01.json').open('x')as f:f.write(json.dumps(receipt,indent=2)+chr(10))
print(json.dumps(receipt));raise SystemExit(0 if receipt['passed']else 1)
"""
compile(owner,'private-corpus-owner','exec');path=base/'operations/music_owner.py';path.write_text(owner)
command=['sudo','-n','systemd-run','--unit='+unit,'--uid=1000','--gid=1000','--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no','--property=KillMode=control-group','--property=RuntimeMaxSec=1290s','--property=TimeoutStopSec=15s','--property=MemoryMax=2G','--property=TasksMax=256','--property=UMask=0077',
 '--property=StandardOutput=append:'+str(base/'unit-music.stdout.log'),'--property=StandardError=append:'+str(base/'unit-music.stderr.log'),'/usr/bin/python3','-B',str(path)]
r=subprocess.run(command,capture_output=True,text=True,timeout=15);print(json.dumps(dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)));assert r.returncode==0
'''
 compile(code,'corpus-remote-dispatch','exec')
 def dispatch(host,command,data=None):
  with(BASE/(host+'-music-dispatch.stdout.log')).open('x')as out,(BASE/(host+'-music-dispatch.stderr.log')).open('x')as err:
   r=subprocess.run(command,input=data,text=True,stdout=out,stderr=err,timeout=30)
  return dict(exit=r.returncode)
 with ThreadPoolExecutor(max_workers=2)as pool:
  a=pool.submit(dispatch,'laptop',local);b=pool.submit(dispatch,'apollo',SSH+['python3 -'],code);receipt=dict(laptop=a.result(),apollo=b.result(),concurrent=True,hardware_or_latency_qualification=False,source_plan_frozen_before_inference=True)
 with(BASE/'corpus-dispatch-01.json').open('x')as f:f.write(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt));assert all(receipt[h]['exit']==0 for h in ('laptop','apollo'))
if __name__=='__main__':main()
