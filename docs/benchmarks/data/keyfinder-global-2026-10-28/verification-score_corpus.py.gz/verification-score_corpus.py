"""Score both closed global captures on the original 24-song denominator."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json
BASE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('fixed_global_protocol',BASE/'run_corpus.py');protocol=importlib.util.module_from_spec(s);s.loader.exec_module(protocol)
assert not(BASE/'corpus-scores-01.json').exists()
plan=protocol.strict_json((BASE/'corpus-plan-01.json').read_bytes());closed=protocol.strict_json((BASE/'corpus-closed-before-scoring-01.json').read_bytes());assert closed['both_units_retired']and closed['reference_labels_opened']is False
predictions={};raw_predictions={};case_status={}
for host,root in [('laptop',BASE/'music-output-01'),('apollo',BASE/'corpus-apollo-01/results/output-01')]:
 raw=(root/'predictions-before-scoring.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==closed['hosts'][host]['captures_sha256']
 captures=protocol.strict_json(raw);assert len(captures)==24 and[case['id']for case in captures]==[case['id']for case in plan['cases']]
 predictions[host]={};raw_predictions[host]={};case_status[host]={}
 for case,capture in zip(plan['cases'],captures,strict=True):
  identifier=case['id'];case_status[host][identifier]=capture['status']
  if case['preparation_status']!='PreparedMetadataMeasured':
   assert capture['status']=='SourcePreparationFailed'and capture['complete']is False and capture['model_started']is False and capture['error']==case['error'];predictions[host][identifier]=None;continue
  assert capture['complete']is True and capture['status']=='PredictionCaptured'and capture['producer_reaped']and capture['consumer_reaped']and capture['spool_empty']
  assert capture['prediction_file']==identifier+'-prediction.json'
  raw=(root/capture['prediction_file']).read_bytes();assert len(raw)<=16384 and hashlib.sha256(raw).hexdigest()==capture['prediction_sha256']
  source=protocol.strict_json((root/(identifier+'-source.json')).read_bytes());assert source==capture['source']
  predicted=protocol.validate(protocol.strict_json(raw),source,case);assert predicted==capture['predicted_class']
  predictions[host][identifier]=predicted;raw_predictions[host][identifier]=raw
# The first parse of reference labels occurs after both complete captures have
# passed their original hashes and raw source/prediction validation above.
reference=plan['reference_pin_for_later_separate_scoring'];protocol.verify(reference)
truth_rows=protocol.strict_json(Path(reference['path']).read_bytes())['cases']
truth={f"{row['track_id']:06d}":row['reference_class']for row in truth_rows}
assert len(truth)==24 and set(truth)=={c['id']for c in plan['cases']}and all(type(v)is int and 0<=v<24 for v in truth.values())
results={}
for host,values in predictions.items():
 rows=[dict(id=c['id'],reference_class=truth[c['id']],predicted_class=values[c['id']],match=values[c['id']]is not None and values[c['id']]==truth[c['id']],status=case_status[host][c['id']],confidence='Unknown')for c in plan['cases']]
 correct=sum(r['match']for r in rows);estimated=sum(r['predicted_class']is not None for r in rows)
 results[host]=dict(cases=rows,global_exact=dict(matches=correct,denominator=24,percent=correct/24*100),estimated_subset=dict(matches=correct,denominator=estimated,percent=correct/estimated*100 if estimated else None),source_preparation_failures=3,confidence='Unknown',qualified=False)
ready={c['id']for c in plan['cases']if c['preparation_status']=='PreparedMetadataMeasured'}
equal=sum(raw_predictions['laptop'][identifier]==raw_predictions['apollo'][identifier]for identifier in ready)
report=dict(schema=1,scored_at_utc=datetime.now(timezone.utc).isoformat(),recipe=plan['recipe'],hosts=results,fixed_denominator=24,
 cross_host_byte_identical_predictions=equal,inferred_per_host=21,both_prediction_captures_closed_before_reference_parse=True,
 original_three_decoder_failures_retained=True,reference_sha256=reference['sha256'],confidence='Unknown',qualified=False,
 scope='Reused exposed fixed sample; no training-independence, held-out generalization, local-key-change or confidence-calibration qualification.',
 production_key_backend_enabled=False,hardware_or_latency_qualified=False,milestone_or_release_gate_closed=False)
protocol.store(BASE/'corpus-scores-01.json',report)
print(json.dumps(dict(hosts={h:{k:v[k]for k in('global_exact','estimated_subset')}for h,v in results.items()},byte_identical_predictions=equal,fixed_denominator=24,confidence='Unknown',qualified=False),indent=2))
