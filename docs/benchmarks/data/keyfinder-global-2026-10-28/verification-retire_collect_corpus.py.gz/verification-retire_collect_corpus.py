"""Retire completed CPU units and collect predictions before any reference scoring."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import ast,hashlib,inspect,io,json,subprocess,tarfile
BASE=Path(__file__).resolve().parent
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
def retire(unit,identity,user):
 prefix=['systemctl']+(['--user']if user else[])
 def show():return dict(s.split('=',1)for s in subprocess.check_output(prefix+['show',unit,'--property=LoadState,ActiveState,MainPID,InvocationID,ControlGroup,Result,ExecMainStatus'],text=True,timeout=5).splitlines()if'='in s)
 before=show();assert before['MainPID']=='0'and before['InvocationID']==identity and before['Result']=='success'and before['ExecMainStatus']=='0',before
 group=before['ControlGroup'];p=Path('/sys/fs/cgroup'+group)/'cgroup.procs'if group else None
 assert not p or not p.exists()or not p.read_text().strip()
 subprocess.run(([]if user else['sudo','-n'])+prefix+['stop',unit],check=True,timeout=20)
 after=show();assert after['LoadState']=='not-found'and after['MainPID']=='0'and after['ActiveState']=='inactive'
 return dict(before=before,after=after,cgroup_empty=True)
def local():
 output=BASE/'music-output-01';r=json.loads((output/'prediction-receipt.json').read_text());assert r['inferred']==21 and r['reference_labels_opened']is False
 assert all(not list(p.iterdir())for p in output.glob('spool-*'))and len(list(output.glob('spool-*')))==21
 return retire('conflux-keyfinder-global-fmak-laptop-20261028-01.service','001496c876ac4eecb08c51c4fdd79770',True)
def remote():
 code='from pathlib import Path\nimport json,subprocess\n'+inspect.getsource(retire)+'''
b=Path('/srv/conflux-tests/work/keyfinder-global-20261028-01/corpus-01');o=b/'results/output-01'
r=json.loads((o/'prediction-receipt.json').read_text());assert r['inferred']==21 and r['reference_labels_opened']is False
assert len(list(o.glob('spool-*')))==21 and all(not list(p.iterdir())for p in o.glob('spool-*'))
a=retire('conflux-keyfinder-global-fmak-apollo-20261028-01.service','cb6c67cd48054719879b0888f2553576',False)
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert not subprocess.check_output(D+['ps','-aq'],text=True).strip();a['private_containers_absent']=True;print(json.dumps(a))
'''
 r=subprocess.run(SSH+['python3 -'],input=code,text=True,capture_output=True,timeout=40);assert r.returncode==0,r.stderr;return json.loads(r.stdout)
with ThreadPoolExecutor(max_workers=2)as pool:
 a=pool.submit(local);b=pool.submit(remote);receipt=dict(utc=datetime.now(timezone.utc).isoformat(),laptop=a.result(),apollo=b.result(),reference_labels_opened=False)
with(BASE/'corpus-retirement-01.json').open('x')as f:f.write(json.dumps(receipt,indent=2)+'\n')
code='''from pathlib import Path
import io,sys,tarfile
b=Path('/srv/conflux-tests/work/keyfinder-global-20261028-01/corpus-01')
files=[p for p in(b/'results/output-01').rglob('*')if p.is_file()and not p.is_symlink()and p.suffix in('.json','.stderr')]
for n in ('input-manifest-01.json','input-manifest-02.json','offline-preparation-01.json','offline-preparation-02.json','music-owner-receipt-01.json','container-music.stdout.log','container-music.stderr.log','unit-music.stdout.log','unit-music.stderr.log','operations/plan.json','operations/music_owner.py'):
 files.append(b/n)
assert all(p.stat().st_size<1024*1024 for p in files)and sum(p.stat().st_size for p in files)<4*1024*1024
out=io.BytesIO()
with tarfile.open(fileobj=out,mode='w:gz')as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(b)),recursive=False)
sys.stdout.buffer.write(out.getvalue())
'''
r=subprocess.run(SSH+['sudo -n python3 -'],input=code.encode(),capture_output=True,timeout=30);assert r.returncode==0,r.stderr.decode();assert len(r.stdout)<4*1024*1024
with(BASE/'corpus-apollo-text-01.tar.gz').open('xb')as f:f.write(r.stdout)
out=BASE/'corpus-apollo-01';out.mkdir()
with tarfile.open(fileobj=io.BytesIO(r.stdout),mode='r:gz')as t:
 for m in t.getmembers():
  assert m.isfile()and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts
  p=out/m.name;p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb')as f:f.write(t.extractfile(m).read())
closed={}
for host,p in [('laptop',BASE/'music-output-01'),('apollo',out/'results/output-01')]:
 r=json.loads((p/'prediction-receipt.json').read_text());raw=(p/'predictions-before-scoring.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==r['closed_capture_sha256']
 captures=json.loads(raw);assert len(captures)==24 and sum(c['complete']for c in captures)==21
 closed[host]=dict(captures_sha256=r['closed_capture_sha256'],receipt_sha256=hashlib.sha256((p/'prediction-receipt.json').read_bytes()).hexdigest(),reference_labels_opened=False)
with(BASE/'corpus-closed-before-scoring-01.json').open('x')as f:f.write(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),hosts=closed,both_units_retired=True,reference_labels_opened=False),indent=2)+'\n')
print(json.dumps(dict(cleanup=receipt,closed=closed,reference_labels_opened=False)))
