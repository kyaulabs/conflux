from pathlib import Path
import json,subprocess
base=Path('/srv/conflux-tests/work/keyfinder-global-20261028-01/corpus-01')
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
assert not subprocess.check_output(D+['ps','-aq'],text=True).strip()
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919';run='keyfinder-global-corpus-music-20261028-01';name='conflux-'+run
command=D+['run','--rm','--name',name,'--runtime=runc','--init','--label','org.kyaulabs.conflux.run='+run,'--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--cpus=1','--memory=1g','--pids-limit=128','--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--env','CONFLUX_PRIVATE_KEY_REFERENCE=1',
 '--mount','type=bind,src='+str(base/'media')+',dst=/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-assessment-01/source-admission-01/media-01,readonly',
 '--mount','type=bind,src='+str(base/'bin')+',dst=/prepare,readonly',
 '--mount','type=bind,src='+str(base.parent/'native')+',dst=/worker,readonly',
 '--mount','type=bind,src='+str(base/'operations')+',dst=/operations,readonly',
 '--mount','type=bind,src='+str(base/'results')+',dst=/results',image,'timeout','--signal=TERM','--kill-after=5s','1230','python','-B','/operations/run_corpus.py','--owned','--plan','/operations/plan.json','--output','/results/output-01']
receipt=dict(scope='CPU correctness only; no music output, GPU, performance or physical qualification',command=command,passed=False)
try:
 with(base/'container-music.stdout.log').open('x')as out,(base/'container-music.stderr.log').open('x')as err:r=subprocess.run(command,stdout=out,stderr=err,timeout=1250)
 receipt['exit']=r.returncode
except BaseException as e:receipt['error']=type(e).__name__+': '+str(e)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  c=json.loads(found.stdout)[0];assert c['Image']==image and c['Config']['Labels']['org.kyaulabs.conflux.run']==run
  subprocess.run(D+['rm','--force',c['Id']],capture_output=True,check=True,timeout=10)
 receipt['container_absent']=subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
p=base/'results/output-01/prediction-receipt.json'
if p.exists():receipt['prediction_receipt']=json.loads(p.read_text())
receipt['passed']=receipt.get('exit')==0 and receipt['container_absent']and receipt.get('prediction_receipt',{}).get('all_inferable_sources_completed')is True
with(base/'music-owner-receipt-01.json').open('x')as f:f.write(json.dumps(receipt,indent=2)+chr(10))
print(json.dumps(receipt));raise SystemExit(0 if receipt['passed']else 1)
