"""Generated DSP and failure checks; no corpus, learned model or audio device."""
from array import array
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import resource
import struct
import subprocess
import sys
import unittest

BASE = Path(__file__).resolve().parent
BINARY = Path(sys.argv.pop(1)) if len(sys.argv) > 1 else BASE/'native-build-01/keyfinder-global-worker'
FIXTURE = Path(sys.argv.pop(1)) if len(sys.argv) > 1 else BASE.parent/'m2-keyfinder-assessment-01/test_keyfinder_context.py'
assert hashlib.sha256(FIXTURE.read_bytes()).hexdigest() == '92653e3bf2844fcf39e796b380533047070707996fbc53137f45bd0f4ad47113'
spec = importlib.util.spec_from_file_location('retained_keyfinder_fixtures', FIXTURE)
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)


def bounds():
    resource.setrlimit(resource.RLIMIT_AS, (512*1024**2, 512*1024**2))
    resource.setrlimit(resource.RLIMIT_CPU, (8, 8))


def invoke(raw, frames):
    result = subprocess.run([str(BINARY), '--frames', str(frames)], input=raw,
        capture_output=True, timeout=12, preexec_fn=bounds)
    assert len(result.stdout) <= 16384 and len(result.stderr) <= 4096
    return result


def accepted(raw):
    result = invoke(raw, len(raw)//8)
    assert result.returncode == 0, result.stderr.decode()
    value = json.loads(result.stdout)
    assert value['recipe'] == 'private-keyfinder-2.2.8-stereo-global-stream-v1'
    assert value['pcm_sha256'] == hashlib.sha256(raw).hexdigest()
    assert value['frames'] == len(raw)//8
    assert (value['support_first_frame'], value['support_end_frame']) == (0, len(raw)//8)
    assert value['input_block_frames'] == 48000 and value['confidence'] == 'Unknown'
    assert value['qualified'] is False
    return value


class GlobalKeyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.major = fixtures.progression()
        cls.minor = fixtures.progression(minor=True)

    def test_known_major_minor_progressions(self):
        for raw, tonic, mode in [(self.major, 0, 'Major'), (self.minor, 9, 'Minor')]:
            with self.subTest(mode=mode):
                value = accepted(raw)
                self.assertEqual((value['status'], value['tonic'], value['mode']), ('Estimated', tonic, mode))

    def test_antiphase_and_channel_swap_preserve_tonal_content(self):
        samples = array('f')
        samples.frombytes(self.major)
        if sys.byteorder != 'little': samples.byteswap()
        inverted, swapped = array('f'), array('f')
        for index in range(0, len(samples), 2):
            inverted.extend((samples[index], -samples[index]))
            swapped.extend((samples[index+1], samples[index]))
        for candidate in (inverted, swapped):
            if sys.byteorder != 'little': candidate.byteswap()
            value = accepted(candidate.tobytes())
            self.assertEqual((value['status'], value['tonic'], value['mode']), ('Estimated', 0, 'Major'))

    def test_short_and_silent_sources_remain_unknown(self):
        for frames in (1, 7, 32767, 48000, 48001):
            with self.subTest(frames=frames):
                value = accepted(bytes(frames*8))
                self.assertEqual(value['status'], 'Unknown')
                self.assertNotIn('tonic', value)
                self.assertEqual(value['reason'], 'short' if frames < 32768 else 'silence')

    def test_non_block_aligned_tail_is_hashed_and_consumed(self):
        value = accepted(self.major+bytes(17*8))
        self.assertEqual(value['frames'], len(self.major)//8+17)
        self.assertEqual((value['tonic'], value['mode']), (0, 'Major'))

    def test_truncated_or_extra_input_never_emits_a_prediction(self):
        for raw, frames in [(b'\0'*7, 1), (b'\0'*9, 1),
                            (self.major[:-1], len(self.major)//8),
                            (self.major+b'\0', len(self.major)//8)]:
            with self.subTest(frames=frames, bytes=len(raw)):
                value = invoke(raw, frames)
                self.assertEqual(value.returncode, 2)
                self.assertFalse(value.stdout)
                self.assertTrue(value.stderr)

    def test_nonfinite_values_after_processed_blocks_never_emit_a_prediction(self):
        for scalar in (math.nan, math.inf, -math.inf):
            with self.subTest(scalar=scalar):
                raw = self.major[:2*48000*8]+struct.pack('<ff', scalar, 0.)
                value = invoke(raw, len(raw)//8)
                self.assertEqual(value.returncode, 2)
                self.assertFalse(value.stdout)
                self.assertIn(b'Nonfinite prepared PCM', value.stderr)

    def test_invalid_frame_counts_are_rejected(self):
        for frames in (0, -1, 33554433, '1.5', '1x', 'true', '9'*1000):
            with self.subTest(frames=str(frames)[:20]):
                value = invoke(b'', frames)
                self.assertEqual(value.returncode, 2)
                self.assertFalse(value.stdout)

    def test_maximum_declared_source_does_not_allocate_whole_track(self):
        value = invoke(b'', 33554432)
        self.assertEqual(value.returncode, 2)
        self.assertFalse(value.stdout)
        self.assertIn(b'Truncated prepared PCM', value.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
