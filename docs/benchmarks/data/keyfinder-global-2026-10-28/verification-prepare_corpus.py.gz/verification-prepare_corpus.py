"""Stage fixed CPU-only inputs and run generated checks; no musical predictions."""
from pathlib import Path
import copy,hashlib,io,json,os,shlex,subprocess,tarfile
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent.parent
REMOTE='/srv/conflux-tests/work/keyfinder-global-20261028-01/corpus-01'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
IMAGE='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
def pin(path):
 p=Path(path);assert p.is_file()and not p.is_symlink()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h)
def save(p,r):
 with p.open('x')as f:f.write(json.dumps(r,indent=2)+'\n')
prior=ROOT/'build/m2-fmak-assessment-01/keycnn-01/music-plan-01.json';p=json.loads(prior.read_text())
assert len(p['cases'])==24 and sum(c['preparation_status']=='PreparedMetadataMeasured'for c in p['cases'])==21
assert {c['id']for c in p['cases']if c['preparation_status']!='PreparedMetadataMeasured'}=={'003853','005153','061480'}
checks=json.loads((BASE/'generated-results-01.json').read_text());assert all(r['exit']==0 for r in checks['hosts'].values())
assert 'Ran 8 tests' in(BASE/'corpus-offline-02.log').read_text()and(BASE/'corpus-offline-02.log').read_text().rstrip().endswith('OK')
builds=json.loads((BASE/'build-results-01.json').read_text())['hosts'];worker=pin(builds['laptop']['binary']['path']);assert worker==builds['laptop']['binary']and worker['sha256']==builds['apollo']['binary']['sha256']
assert pin(p['preparer']['path'])==p['preparer']
for c in p['cases']:assert pin(c['source']['path'])==c['source']
plan=dict(schema=1,status='frozen_CPU_correctness_only',host='laptop',unit='conflux-keyfinder-global-fmak-laptop-20261028-01.service',
 recipe='private-keyfinder-2.2.8-stereo-global-stream-v1',physical_readiness_required=False,reference_labels_excluded_from_prediction_runtime=True,
 source_plan=pin(prior),reference_pin_for_later_separate_scoring=p['reference'],cases=p['cases'],worker=worker,preparer=p['preparer'],
 fixed_denominator=24,confidence='Unknown',qualified=False,hardware_or_latency_qualification=False,GPU_audio_or_profile_change=False,no_retry=True,
 input_pins=[worker,p['preparer'],pin(BASE/'run_corpus.py')]+[c['source']for c in p['cases']])
save(BASE/'corpus-plan-01.json',plan)
remote=copy.deepcopy(plan);remote.update(host='apollo',unit='conflux-keyfinder-global-fmak-apollo-20261028-01.service')
remote['worker']['path']='/worker/keyfinder-global-worker';remote['preparer']['path']='/prepare/prepare-fmak-source'
remote['input_pins']=[remote['worker'],remote['preparer'],dict(pin(BASE/'run_corpus.py'),path='/operations/run_corpus.py')]+[c['source']for c in remote['cases']]
# No reference file or labels are included in the transfer.
files=[('media/'+c['id']+'.mp3',Path(c['source']['path']))for c in p['cases']]
files.extend([('bin/prepare-fmak-source',Path(p['preparer']['path'])),('operations/run_corpus.py',BASE/'run_corpus.py'),('operations/test_corpus.py',BASE/'test_corpus.py')])
raw_plan=json.dumps(remote,indent=2).encode()+b'\n';manifest=[dict(file=name,**{k:v for k,v in pin(path).items()if k!='path'})for name,path in files]
manifest.append(dict(file='operations/plan.json',bytes=len(raw_plan),sha256=hashlib.sha256(raw_plan).hexdigest()))
header='BASE='+repr(REMOTE)+'\nFILES='+repr(manifest)+'\nIMAGE='+repr(IMAGE)+'\n'
code=r'''
from pathlib import Path,PurePosixPath
import hashlib,json,subprocess,sys,tarfile
base=Path(BASE);assert not base.exists();base.mkdir(mode=0o700)
expected={r['file']:r for r in FILES};seen=set()
assert sum(r['bytes']for r in FILES)<256*1024*1024
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|')as tar:
 for member in tar:
  name=PurePosixPath(member.name);assert not name.is_absolute()and '..'not in name.parts and member.isfile()
  assert member.name in expected and member.name not in seen;row=expected[member.name];assert member.size==row['bytes']
  data=tar.extractfile(member).read();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
  path=base/member.name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);path.chmod(0o700 if member.name.startswith('bin/')else 0o600);seen.add(member.name)
assert seen==set(expected)
(base/'input-manifest-01.json').write_text(json.dumps(FILES,indent=2)+chr(10))
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
assert not subprocess.check_output(D+['ps','-aq'],text=True).strip()
name='conflux-keyfinder-global-corpus-offline-20261028-01'
inside="""from pathlib import Path
import subprocess
assert not Path('/dev/nvidia0').exists()and not Path('/dev/dri').exists()
r=subprocess.run(['ldd','/prepare/prepare-fmak-source'],capture_output=True,text=True,check=True);assert 'not found'not in r.stdout
r=subprocess.run(['/prepare/prepare-fmak-source'],capture_output=True,text=True);assert r.returncode==2
r=subprocess.run(['python','-B','-m','unittest','discover','-s','/operations','-p','test_corpus.py'],timeout=30)
raise SystemExit(r.returncode)
"""
command=D+['run','--rm','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--memory=1g','--cpus=1','--pids-limit=128','--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--label','org.kyaulabs.conflux.run=keyfinder-global-corpus-offline-20261028-01',
 '--mount','type=bind,src='+str(base/'bin')+',dst=/prepare,readonly','--mount','type=bind,src='+str(base/'operations')+',dst=/operations,readonly',IMAGE,'python','-c',inside]
try:r=subprocess.run(command,capture_output=True,text=True,timeout=60)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  c=json.loads(found.stdout)[0];assert c['Image']==IMAGE and c['Config']['Labels']['org.kyaulabs.conflux.run']=='keyfinder-global-corpus-offline-20261028-01'
  subprocess.run(D+['rm','--force',c['Id']],capture_output=True,check=True,timeout=10)
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
receipt=dict(files=len(seen),bytes=sum(r['bytes']for r in FILES),offline_exit=r.returncode,stdout=r.stdout,stderr=r.stderr,container_absent=True,GPU_audio_or_music_predictions_started=False)
(base/'offline-preparation-01.json').write_text(json.dumps(receipt,indent=2)+chr(10));print(json.dumps(receipt));assert r.returncode==0,r.stderr
'''
compile(header+code,'corpus-stage','exec')
with(BASE/'corpus-preparation.stdout.log').open('x')as out,(BASE/'corpus-preparation.stderr.log').open('x')as err:
 process=subprocess.Popen(SSH+['python3 -c '+shlex.quote(header+code)],stdin=subprocess.PIPE,stdout=out,stderr=err)
 try:
  with tarfile.open(fileobj=process.stdin,mode='w|')as tar:
   for name,path in files:
    info=tarfile.TarInfo(name);info.size=path.stat().st_size;info.mode=0o600
    with path.open('rb')as f:tar.addfile(info,f)
   info=tarfile.TarInfo('operations/plan.json');info.size=len(raw_plan);info.mode=0o600;tar.addfile(info,io.BytesIO(raw_plan))
  process.stdin.close();result=process.wait(timeout=120)
 finally:
  if process.poll()is None:process.kill();process.wait(timeout=5)
assert result==0,(BASE/'corpus-preparation.stderr.log').read_text()
receipt=json.loads((BASE/'corpus-preparation.stdout.log').read_text());save(BASE/'corpus-preparation-01.json',receipt);print(json.dumps(receipt))
