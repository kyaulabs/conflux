// SPDX-License-Identifier: AGPL-3.0-or-later
// Private M2 comparison. No product dependency or qualified key estimate.
#include "src/keyfinder.h"
#include <QByteArray>
#include <QCryptographicHash>
#include <QJsonDocument>
#include <QJsonObject>
#include <algorithm>
#include <bit>
#include <charconv>
#include <cmath>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string_view>

namespace {
constexpr int Rate = 48000;
constexpr int BlockFrames = 48000;
constexpr int MinimumFrames = 32768;
constexpr int MaximumFrames = 33554432;
constexpr int MaximumOutput = 16384;
constexpr auto Recipe = "private-keyfinder-2.2.8-stereo-global-stream-v1";

void require(bool value, const char* message) {
    if (!value) throw std::runtime_error(message);
}

QByteArray analyze(int frames) {
    QCryptographicHash digest(QCryptographicHash::Sha256);
    KeyFinder::KeyFinder detector;
    KeyFinder::Workspace channels[2];
    QByteArray block(BlockFrames * 8, Qt::Uninitialized);
    for (int first = 0; first < frames; first += BlockFrames) {
        const int count = std::min(BlockFrames, frames - first);
        const auto bytes = static_cast<qsizetype>(count) * 8;
        std::cin.read(block.data(), bytes);
        require(std::cin.gcount() == bytes, "Truncated prepared PCM");
        digest.addData(QByteArrayView(block.constData(), bytes));
        KeyFinder::AudioData audio[2];
        if (frames >= MinimumFrames) {
            for (auto& channel : audio) {
                channel.setChannels(1);
                channel.setFrameRate(Rate);
                channel.addToFrameCount(static_cast<unsigned>(count));
            }
        }
        for (int frame = 0; frame < count; ++frame) {
            for (int channel = 0; channel < 2; ++channel) {
                float value;
                std::memcpy(&value, block.constData() + (frame * 2 + channel) * 4, 4);
                require(std::isfinite(value), "Nonfinite prepared PCM");
                if (frames >= MinimumFrames)
                    audio[channel].setSample(static_cast<unsigned>(frame), value);
            }
        }
        if (frames >= MinimumFrames) {
            for (int channel = 0; channel < 2; ++channel)
                detector.progressiveChromagram(audio[channel], channels[channel]);
        }
    }
    // Never emit a prefix prediction before exact EOF and PCM validation.
    require(std::cin.get() == std::char_traits<char>::eof(), "Extra prepared PCM");
    require(std::cin.eof() && !std::cin.bad(), "PCM EOF read failed");
    QJsonObject result{{"schema", 1}, {"recipe", Recipe}, {"frames", frames},
        {"sample_rate", Rate}, {"channels", 2}, {"support_first_frame", 0},
        {"support_end_frame", frames}, {"input_block_frames", BlockFrames},
        {"pcm_sha256", QString::fromLatin1(digest.result().toHex())},
        {"qualified", false}, {"confidence", "Unknown"},
        {"status", "Unknown"}, {"reason", "short"}};
    if (frames >= MinimumFrames) {
        for (auto& channel : channels) {
            detector.finalChromagram(channel);
            require(channel.chromagram != nullptr, "Reference chromagram absent");
            for (double value : channel.chromagram->collapseToOneHop())
                require(std::isfinite(value) && value >= 0, "Reference chromagram invalid");
        }
        // Combine channel magnitudes, preserving antiphase stereo content.
        channels[0].chromagram->append(*channels[1].chromagram);
        const auto key = detector.keyOfChromagram(channels[0]);
        require(key >= KeyFinder::A_MAJOR && key <= KeyFinder::SILENCE,
                "Reference key enum invalid");
        result.insert("keyfinder_key_enum", static_cast<int>(key));
        if (key == KeyFinder::SILENCE) result.insert("reason", "silence");
        else {
            result.insert("status", "Estimated");
            result.insert("reason", "reference-profile-match");
            result.insert("tonic", (9 + static_cast<int>(key) / 2) % 12);
            result.insert("mode", static_cast<int>(key) % 2 ? "Minor" : "Major");
        }
    }
    auto output = QJsonDocument(result).toJson(QJsonDocument::Compact) + '\n';
    require(output.size() <= MaximumOutput, "Reference output exceeds 16 KiB");
    return output;
}
}

int main(int argc, char** argv) {
    static_assert(std::endian::native == std::endian::little && sizeof(float) == 4);
    try {
        require(argc == 3 && std::string_view(argv[1]) == "--frames", "Expected --frames INTEGER");
        int frames = 0;
        const char* end = argv[2] + std::strlen(argv[2]);
        const auto parsed = std::from_chars(argv[2], end, frames);
        require(parsed.ec == std::errc{} && parsed.ptr == end && frames > 0 &&
                frames <= MaximumFrames, "Invalid prepared frame count");
        const auto output = analyze(frames);
        std::cout.write(output.constData(), output.size());
        require(std::cout.good(), "Reference output write failed");
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 2;
    }
}
