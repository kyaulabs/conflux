"""Read counts and closed receipts only, without scoring or starting a workload."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from collections import Counter
import inspect,json,subprocess
BASE=Path(__file__).resolve().parent
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
def status(base,output,unit,local):
 state=subprocess.check_output(['systemctl']+(['--user']if local else[])+['show',unit,'--property=LoadState,ActiveState,SubState,MainPID,InvocationID,Result,ExecMainStatus'],text=True,timeout=5)
 rows=[json.loads(p.read_text())for p in output.glob('*-capture.json')]
 result=dict(unit=state,captures=len(rows),statuses=dict(Counter(r['status']for r in rows)))
 p=output/'prediction-receipt.json'
 if p.exists():result['closed_prediction_receipt']=json.loads(p.read_text())
 if not local and(base/'music-owner-receipt-01.json').exists():
  row=json.loads((base/'music-owner-receipt-01.json').read_text());result['owner']={k:row[k]for k in ('exit','passed','container_absent','error')if k in row}
 return result

def local():return status(BASE,BASE/'music-output-01','conflux-keyfinder-global-fmak-laptop-20261028-01.service',True)
def apollo():
 code='from pathlib import Path\nfrom collections import Counter\nimport json,subprocess\n'+inspect.getsource(status)+"\nb=Path('/srv/conflux-tests/work/keyfinder-global-20261028-01/corpus-01');print(json.dumps(status(b,b/'results/output-01','conflux-keyfinder-global-fmak-apollo-20261028-01.service',False)))\n"
 r=subprocess.run(SSH+['python3 -'],input=code,text=True,capture_output=True,timeout=20);assert r.returncode==0,r.stderr;return json.loads(r.stdout)
with ThreadPoolExecutor(max_workers=2)as pool:
 a=pool.submit(local);b=pool.submit(apollo);result=dict(utc=datetime.now(timezone.utc).isoformat(),laptop=a.result(),apollo=b.result(),reference_labels_read=False)
number=len(list(BASE.glob('corpus-observation-*.json')))+1
with(BASE/f'corpus-observation-{number:03}.json').open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
