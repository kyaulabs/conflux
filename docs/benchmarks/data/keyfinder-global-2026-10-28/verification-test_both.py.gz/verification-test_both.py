"""Run generated DSP/failure regressions concurrently; no corpus or GPU access."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import subprocess

BASE=Path(__file__).resolve().parent
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no',
    '-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes',
    '-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222',
    '-p','4222','kyau@apollo.kyaulabs','python3 -']
builds=json.loads((BASE/'build-results-01.json').read_text())['hosts']
assert all(value['exit']==0 for value in builds.values())
assert builds['laptop']['binary']['sha256']==builds['apollo']['binary']['sha256']


def local():
    binary=Path(builds['laptop']['binary']['path'])
    assert hashlib.sha256(binary.read_bytes()).hexdigest()==builds['laptop']['binary']['sha256']
    command=['nice','-n','15','/usr/bin/python3.14','-B',str(BASE/'test_global_worker.py'),
        str(binary),str(BASE.parent/'m2-keyfinder-assessment-01/test_keyfinder_context.py')]
    with (BASE/'generated-laptop.stdout.log').open('x') as out,(BASE/'generated-laptop.stderr.log').open('x') as err:
        result=subprocess.run(command,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),
            stdout=out,stderr=err,timeout=240)
    return dict(exit=result.returncode,command=command)


def apollo():
    code=r'''
from pathlib import Path
import hashlib,json,subprocess
base=Path('/srv/conflux-tests/work/keyfinder-global-20261028-01')
binary=base/'native/keyfinder-global-worker'
assert hashlib.sha256(binary.read_bytes()).hexdigest()=='4f8a35737dc8124c193eb95fe5f5777d568a10340b6f967879545c24a05c45a8'
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
assert not subprocess.check_output(D+['ps','-aq'],text=True).strip()
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
name='conflux-keyfinder-global-tests-20261028-01';run='keyfinder-global-tests-20261028-01'
inside="""from pathlib import Path
import subprocess
assert not Path('/dev/nvidia0').exists() and not Path('/dev/dri').exists()
result=subprocess.run(['python','-B','/src/worker/test_global_worker.py','/build/keyfinder-global-worker','/src/fixtures/test_keyfinder_context.py'],timeout=240)
raise SystemExit(result.returncode)
"""
command=D+['run','--rm','--name',name,'--runtime=runc','--init',
    '--label','org.kyaulabs.conflux.tests=1','--label','org.kyaulabs.conflux.run='+run,
    '--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true',
    '--user=1000:1000','--memory=1g','--cpus=1','--pids-limit=128',
    '--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--env','OPENBLAS_NUM_THREADS=1','--env','OMP_NUM_THREADS=1',
    '--mount','type=bind,src='+str(base/'source')+',dst=/src,readonly',
    '--mount','type=bind,src='+str(base/'native')+',dst=/build,readonly',image,'python','-c',inside]
try:
    with (base/'results/generated-tests.log').open('x') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=260)
finally:
    found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
    if found.returncode==0:
        value=json.loads(found.stdout)[0]
        assert value['Image']==image and value['Config']['Labels'].get('org.kyaulabs.conflux.run')==run
        subprocess.run(D+['rm','--force',value['Id']],check=True,capture_output=True,timeout=10)
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
log=(base/'results/generated-tests.log').read_text();assert len(log)<128*1024
receipt=dict(exit=result.returncode,container_absent=True,log=log,GPU_audio_model_started=False)
(base/'results/generated-receipt-01.json').write_text(json.dumps(receipt,indent=2)+chr(10));print(json.dumps(receipt))
'''
    result=subprocess.run(SSH,input=code,capture_output=True,text=True,timeout=280)
    (BASE/'generated-apollo.stdout.log').write_text(result.stdout)
    (BASE/'generated-apollo.stderr.log').write_text(result.stderr)
    result.check_returncode()
    return json.loads(result.stdout)


with ThreadPoolExecutor(max_workers=2) as pool:
    first=pool.submit(local);second=pool.submit(apollo);results={}
    for host,future in [('laptop',first),('apollo',second)]:
        try:results[host]=future.result()
        except BaseException as error:results[host]=dict(error=type(error).__name__+': '+str(error))
receipt=dict(schema=1,hosts=results,tests_concurrent=True,corpus_predictions_started=False,
    hardware_or_latency_qualification=False,GPU_audio_model_started=False)
(BASE/'generated-results-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({**receipt,'hosts':{host:{k:v for k,v in row.items() if k!='log'} for host,row in results.items()}}))
raise SystemExit(0 if all(row.get('exit')==0 for row in results.values()) else 1)
