"""Source binding, malformed output and owned-process failures; no corpus."""
from pathlib import Path
import copy,importlib.util,json,sys,tempfile,unittest
from unittest.mock import patch
s=importlib.util.spec_from_file_location('global_corpus',Path(__file__).with_name('run_corpus.py'));runner=importlib.util.module_from_spec(s);s.loader.exec_module(runner)
class CorpusTests(unittest.TestCase):
 def fixtures(self):
  case=dict(id='000001',prepared_frames=16,pcm_sha256='a'*64,source=dict(bytes=128,sha256='b'*64))
  source=dict(schema=1,case=case['id'],complete=True,audio_device_opened=False,source_bytes=128,source_sha256='b'*64,prepared_frames=16,prepared_pcm_sha256='a'*64,sample_rate=48000,channels=2)
  value=dict(schema=1,recipe=runner.RECIPE,frames=16,sample_rate=48000,channels=2,support_first_frame=0,support_end_frame=16,input_block_frames=48000,pcm_sha256='a'*64,qualified=False,confidence='Unknown',status='Unknown',reason='short')
  return case,source,value
 def test_unknown_short_and_global_class_mapping(self):
  case,source,v=self.fixtures();self.assertIsNone(runner.validate(v,source,case))
  case['prepared_frames']=source['prepared_frames']=v['frames']=v['support_end_frame']=32768
  for enum in range(24):
   x=dict(v,status='Estimated',reason='reference-profile-match',keyfinder_key_enum=enum,tonic=(9+enum//2)%12,mode='Minor'if enum%2 else'Major')
   self.assertEqual(runner.validate(x,source,case),(9+enum//2)%12+(12 if enum%2 else 0))
 def test_short_and_silence_require_the_declared_support_and_enum(self):
  case,source,v=self.fixtures()
  with self.assertRaises(AssertionError):runner.validate(dict(v,status='Estimated',keyfinder_key_enum=0),source,case)
  case['prepared_frames']=source['prepared_frames']=v['frames']=v['support_end_frame']=32768
  with self.assertRaises(AssertionError):runner.validate(v,source,case)
  self.assertIsNone(runner.validate(dict(v,reason='silence',keyfinder_key_enum=24),source,case))
  with self.assertRaises(AssertionError):runner.validate(dict(v,reason='silence',keyfinder_key_enum=0),source,case)
 def test_wrong_pcm_frames_source_or_profile_never_estimates(self):
  case,source,v=self.fixtures()
  for changes in ({'pcm_sha256':'c'*64},{'frames':15},{'frames':True},{'sample_rate':44100},{'support_end_frame':15},{'recipe':'different'},{'confidence':'High'},{'qualified':True}):
   with self.subTest(changes=changes),self.assertRaises(AssertionError):runner.validate(dict(v,**changes),source,case)
  for changes in ({'source_sha256':'c'*64},{'source_bytes':129},{'complete':False},{'audio_device_opened':True}):
   with self.subTest(changes=changes),self.assertRaises(AssertionError):runner.validate(v,dict(source,**changes),case)
 def test_inconsistent_enum_or_unknown_with_key_is_rejected(self):
  case,source,v=self.fixtures()
  for changes in ({'status':'Estimated','keyfinder_key_enum':24},{'tonic':3},{'status':'Unsupported'}):
   with self.assertRaises((AssertionError,KeyError)):runner.validate(dict(v,**changes),source,case)
 def test_duplicate_keys_and_nonfinite_values_are_rejected(self):
  for raw in ('{"frames":1,"frames":2}','{"x":NaN}','{"x":Infinity}'):
   with self.assertRaises(ValueError):runner.strict_json(raw)
 def actual_pipe(self,failure=False,timeout=False):
  case,source,v=self.fixtures()
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);out=root/'out';out.mkdir();producer=root/'producer';consumer=root/'consumer'
   producer.write_text('#!'+sys.executable+'\nimport sys,time\n'+('time.sleep(30)\n'if timeout else'')+'sys.stderr.write('+repr(json.dumps(source))+')\nsys.stdout.buffer.write(bytes(128))\n'+('raise SystemExit(1)\n'if failure else''));producer.chmod(0o700)
   consumer.write_text('#!'+sys.executable+'\nimport sys\nsys.stdin.buffer.read()\nprint('+repr(json.dumps(v))+')\n');consumer.chmod(0o700)
   plan=dict(preparer=dict(path=str(producer)),worker=dict(path=str(consumer)))
   children=[];original=runner.subprocess.Popen
   def start(command,**kwargs):
    if command[0]in(str(producer),str(consumer)):command=[sys.executable,*command]
    c=original(command,**kwargs);children.append(c);return c
   with patch.object(runner.subprocess,'Popen',side_effect=start):
    if timeout:
     with patch.object(runner.time,'monotonic',side_effect=[0,161]),self.assertRaisesRegex(AssertionError,'160-second'):runner.predict(plan,case,out)
    elif failure:
     with self.assertRaisesRegex(AssertionError,'Fixed preparation'):runner.predict(plan,case,out)
    else:
     row=runner.predict(plan,case,out);self.assertTrue(row['complete']and row['producer_reaped']and row['consumer_reaped']and row['spool_empty'])
   self.assertEqual(len(children),2);self.assertTrue(all(c.poll()is not None for c in children))
 def test_exact_owned_pipeline_completes_and_reaps(self):self.actual_pipe()
 def test_preparation_failure_reaps_both_children(self):self.actual_pipe(failure=True)
 def test_case_timeout_kills_owned_groups_and_reaps(self):self.actual_pipe(timeout=True)
if __name__=='__main__':unittest.main(verbosity=2)
