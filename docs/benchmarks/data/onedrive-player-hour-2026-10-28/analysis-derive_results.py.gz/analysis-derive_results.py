"""Recompute hour/partial-hour populations without turning a failed capture into a pass."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent


def read(path):
    return json.loads(path.read_text())


def pin(path):
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest)


result = dict(schema=1, source='dfff55ea78b6fcbe633a178e996371238803013d',
    requested_seconds_per_host=3600, strict_target_ms=4095, hosts={},
    hard_cancellation_exercised=False, no_causal_AB_claim=True,
    release_or_milestone_gate_closed=False)
for host, path, wrapper in [
    ('laptop', ROOT/'laptop-results-01/candidate/output-01',
        ROOT/'laptop-results-01/candidate/output-01/result.json'),
    ('apollo', BASE/'apollo/cases/candidate/private-player-01/recordings/actual-player',
        BASE/'apollo/cases/candidate/private-player-01/recordings/actual-player/assessment.json')]:
    native = read(path/'native-result.json')
    owner = read(wrapper)
    observations = owner['observations']
    rows = [json.loads(line) for line in (path/'observations.jsonl').read_text().splitlines()]
    records = [row for row in rows if row['type'] == 'record']
    chunks = [row for row in records if row['kind'] == 5]
    counts = native['observation_counters']
    assert len(records) == counts['retained'] == counts['attempted']
    assert counts['dropped'] == counts['invalid_clock_reads'] == 0
    assert [row['ordinal'] for row in records] == list(range(1,len(records)+1))
    assert all(row['hop_service_present'] and math.isfinite(row['hop_service_ms'])
        and row['hop_service_ms'] >= 0 for row in chunks)
    values = sorted(row['hop_service_ms'] for row in chunks)
    assert values
    hops = dict(count=len(values), maximum_ms=values[-1],
        nearest_rank_p99_ms=values[math.ceil(.99*len(values))-1], strict_target_ms=4095,
        at_or_above_target=sum(value >= 4095 for value in values), complete=True)
    assert hops == observations['service_hops']
    intervals = native['intervals']
    boundary = native['measurement_begin_output_frame']
    steady = [0,0]
    controlled = [0,0]
    for row in intervals:
        assert row['output_begin'] == boundary
        assert row['output_end'] >= boundary and row['frames'] == row['output_end']-boundary
        assert row['starved_frames'] == row['starved_a']+row['starved_b']
        for deck, letter in enumerate(('a','b')):
            (controlled if row[letter+'_recovery'] else steady)[deck] += row['starved_'+letter]
        boundary = row['output_end']
    assert boundary == native['measurement_end_output_frame']
    assert sum(steady) == native['steady_starved_frames']
    assert sum(controlled) == native['control_starved_frames']
    assert steady == [native['steady_starved_a'],native['steady_starved_b']]
    seeks = [control for control in native['controls'] if control['kind']=='incomplete_generation_seek']
    invalidation = False
    if seeks:
        assert len(seeks)==1
        seek = seeks[0]
        accepted = [row for row in records if row['kind']==4 and
            row['generation']==seek['previous_generation'] and row['observed_ns']<=seek['issued_ns']]
        complete = [row for row in records if row['kind']==8 and
            row['generation']==seek['previous_generation'] and row['observed_ns']<=seek['issued_ns']]
        invalidation = bool(accepted and not complete and seek['incomplete_when_last_drained'])
    recording = native.get('recording',{})
    audio = native.get('recorded_audio',{})
    integrity = (recording.get('status')=='Complete' and not recording.get('error')
        and recording.get('acceptedFrames')==recording.get('writtenFrames')==audio.get('frames')
        and type(audio.get('frames')) is int and audio['frames']>0 and recording.get('overflowFrames')==0)
    row = dict(measured_wall_ms=native['measured_wall_ms'],native_passed=native['passed'],
        native_error=native.get('error',''),native_measurement_closed=native['measurement_intervals_closed'],
        full_hour_complete=bool(3600000<=native['measured_wall_ms']<=3602000 and
            native['measurement_intervals_closed'] and not any(value['aborted'] for value in intervals)),
        aborted_intervals=sum(bool(value['aborted']) for value in intervals),service_hops=hops,
        service_target_met=hops['nearest_rank_p99_ms']<4095,all_raw_records_retained=True,
        steady_starved_frames=sum(steady),steady_starved_seconds=sum(steady)/48000,
        steady_starved_by_deck=steady,control_starved_frames=sum(controlled),
        control_starved_seconds=sum(controlled)/48000,control_starved_by_deck=controlled,
        peer_starved_frames=steady[1]+controlled[1],replays=native['replay_count'],
        peer_rewinds=len(native.get('peer_controls',[])),incomplete_generation_seek_proved=invalidation,
        stale_packet_discards=sum(value['kind']==7 for value in records),
        final_recovery_complete=native['last_recovery_complete'],hard_cancellation_exercised=False,
        callback_execution_deadline_misses=native['execution_deadline_misses'],
        driver_discontinuities=sum(value['driver_position_discontinuities'] for value in native['timing']),
        driver_recovery_flags=sum(value['driver_recovery_flags'] for value in native['timing']),
        invalid_buffers=native['invalid_buffers'],rejected_commands=native['rejected_commands'],
        source_read_failures=native['source_read_failures'],scene_errors=native['scene_errors'],
        recording=dict(accepted_frames=recording.get('acceptedFrames'),written_frames=recording.get('writtenFrames'),
            overflow_frames=recording.get('overflowFrames'),integrity_complete=integrity,format=audio),
        first_cursor_poll_upper_seconds=(native['first_advance_observed_ns']-native['load_issued_ns'])/1e9,
        maximum_GUI_heartbeat_gap_ms=native['maximum_gui_heartbeat_gap_ns']/1e6,
        maximum_frame_presentation_gap_ms=native['maximum_frame_presentation_gap_ns']/1e6,
        native_shutdown_complete=native['shutdown_completed'],diagnostic_tail=native.get('diagnostic_tail'),
        raw_observations=pin(path/'observations.jsonl'),native_result=pin(path/'native-result.json'),
        worst_hop=max(chunks,key=lambda value:value['hop_service_ms']),
        wrapper_passed=owner.get('passed'),wrapper_qualified=owner.get('qualified',False))
    if host == 'laptop':
        samples=[json.loads(line) for line in (path/'host-observations.jsonl').read_text().splitlines()]
        profiles=Counter(sample['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'] for sample in samples)
        cap='/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_power_limit_uw'
        caps=Counter(sample['configured_power_caps'][cap] for sample in samples)
        assert set(caps)<={7500000,15000000}
        assert all(sample['power']['ac_online'] and sample['power']['lid_open'] for sample in samples)
        row['thermal']=dict(summary=owner.get('thermal_summary'),profile_samples=dict(profiles),
            MMIO_long_term_limit_samples_uw=dict(caps),
            maximum_sample_gap_seconds=max((second['monotonic_ns']-first['monotonic_ns'])/1e9
                for first,second in zip(samples,samples[1:])),
            guard_identity_unchanged=owner.get('guard_before')==owner.get('guard_after'))
        row['cleanup_proven']=owner.get('cleanup_proven')
        row['hour_gates']=owner.get('hour_gates')
    result['hosts'][host]=row
result['OneDrive_pause']=read(ROOT/'onedrive-pause-state.json')
result['guarded_outcome']=read(ROOT/'guarded-outcome.json')
(BASE/'results-summary-01.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({host:{key:row[key] for key in ('measured_wall_ms','full_hour_complete',
    'native_passed','native_error','service_hops','steady_starved_seconds','control_starved_seconds',
    'replays','peer_rewinds','stale_packet_discards','wrapper_qualified')} for host,row in result['hosts'].items()},indent=2))
