"""Bounded generated-process observation; no media, models, GPU, or audio."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import selectors
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--observer', type=Path, required=True)
parser.add_argument('--sha256', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert hashlib.sha256(args.observer.read_bytes()).hexdigest() == args.sha256
assert not args.output.exists()
spec = importlib.util.spec_from_file_location('frozen_analysis_observer', args.observer)
observer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(observer)
RealPath = Path
events = []


class StatusPath(type(Path())):
    def read_bytes(self):
        raw = super().read_bytes()
        assert len(raw) <= 16384
        values = [line for line in raw.decode().splitlines() if line.startswith(('State:', 'VmRSS:'))]
        if len(events) < 48:
            events.append(dict(kind='status', at_ns=time.monotonic_ns(), fields=values))
        return raw


def identity(pid):
    raw = RealPath('/proc', str(pid), 'stat').read_text()
    fields = raw[raw.rindex(')') + 2:].split()
    value = dict(pid=pid, start_ticks=int(fields[19]), group=int(fields[2]),
                 session=int(fields[3]), ppid=int(fields[1]), state=fields[0])
    if len(events) < 48:
        events.append(dict(kind='stat', at_ns=time.monotonic_ns(), **value))
    return value


def same(a, b):
    return all(a[key] == b[key] for key in ('pid', 'start_ticks', 'group', 'session'))


observer.Path = StatusPath
started = time.monotonic()
deadline = started + 8
rows = []
script = 'import os,sys\npayload=bytearray(16*1024*1024)\nprint("READY",flush=True)\nsys.stdin.buffer.read(1)\nos._exit(0)\n'
for index in range(32):
    if time.monotonic() >= deadline:
        break
    events = []
    child = subprocess.Popen([sys.executable, '-I', '-B', '-c', script], stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    row = dict(index=index, error=None, samples=0)
    try:
        with selectors.DefaultSelector() as selector:
            selector.register(child.stdout, selectors.EVENT_READ)
            assert selector.select(timeout=min(1, max(.01, deadline - time.monotonic())))
        assert child.stdout.readline(32) == b'READY\n'
        expected = identity(child.pid)
        assert expected['pid'] == expected['group'] == expected['session'] and expected['ppid'] == os.getpid()
        owner = dict(live_owned=lambda owned, failures: owned, process_record=identity, same_identity=same)
        child.stdin.write(b'x')
        child.stdin.flush()
        child.stdin.close()
        # Do not poll/reap until observation is over: the exact child PID stays ours.
        for _ in range(32):
            if time.monotonic() >= deadline:
                break
            try:
                rss, zombies = observer.sampled_rss(owner, {(child.pid, expected['start_ticks']): expected}, [])
                row['samples'] += 1
                if zombies:
                    break
            except ValueError as error:
                row['error'] = str(error)
                row['identity_after_error'] = identity(child.pid)
                break
        row['returncode'] = child.wait(timeout=1)
        assert row['returncode'] == 0
    finally:
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=.5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=.5)
        child.stdout.close()
        child.stderr.close()
        row['child_reaped'] = child.returncode is not None
        row['events'] = events
        rows.append(row)
report = dict(schema=1, observer_sha256=args.sha256, cases=rows, requested_cases=32,
              all_children_reaped=all(row['child_reaped'] for row in rows),
              observed_missing_live_RSS=sum(row['error'] == 'Live owned RSS missing' for row in rows),
              seconds=time.monotonic() - started, no_models_media_GPU_or_audio=True,
              scope='Generated exit-boundary observation; not an analysis-corpus rerun or a laptop latency test')
args.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ('requested_cases', 'observed_missing_live_RSS',
                                            'all_children_reaped', 'seconds', 'no_models_media_GPU_or_audio')}))
