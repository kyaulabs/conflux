"""Run the same generated positive-control/exit probe against both frozen samplers."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--input', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
pins = json.loads((args.input / 'source-pins.json').read_text())
for name, sha in pins.items():
    assert hashlib.sha256((args.input / name).read_bytes()).hexdigest() == sha
args.output.mkdir(mode=0o700)
started = time.monotonic()
deadline = started + 20
arms = {}
for arm, observer in [('original', 'production_24.py'), ('candidate', 'rss_candidate.py')]:
    output = args.output / (arm + '.json')
    command = [sys.executable, '-I', '-B', str(args.input / 'probe.py'), '--observer', str(args.input / observer),
               '--sha256', pins[observer], '--output', str(output)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=min(10, deadline - time.monotonic()))
    (args.output / (arm + '-stdout.log')).write_text(result.stdout)
    (args.output / (arm + '-stderr.log')).write_text(result.stderr)
    result.check_returncode()
    data = json.loads(output.read_text())
    assert len(data['cases']) == 32 and data['all_children_reaped']
    assert all(row['positive_control_RSS_bytes'] > 0 and row['returncode'] == 0 for row in data['cases'])
    arms[arm] = dict(observed_missing_live_RSS=data['observed_missing_live_RSS'],
                     actual_errors=[row['error'] for row in data['cases'] if row['error']],
                     terminal_before_reap=sum(row['identity_before_reap']['state'] in ('Z', 'X', 'x') for row in data['cases']),
                     all_children_reaped=True, cases=32, result_sha256=hashlib.sha256(output.read_bytes()).hexdigest())
report = dict(schema=1, arms=arms, original_deadline_seconds=20, seconds=time.monotonic() - started,
              input_sha256=hashlib.sha256((args.input / 'source-pins.json').read_bytes()).hexdigest(),
              all_live_positive_controls_passed=True, no_models_media_GPU_or_audio=True,
              production_source_unchanged=True, corpus_failure_not_reclassified=True,
              candidate_scope='Isolated sampler candidate; no analysis-corpus, musical, latency or release qualification')
with (args.output / 'summary.json').open('x') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
