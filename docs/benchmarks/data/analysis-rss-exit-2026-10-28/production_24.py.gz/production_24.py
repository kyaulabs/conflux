#!/usr/bin/env python3
"""Private fixed production-input comparison. Dry unless an explicit stage is selected."""
import argparse
from decimal import Decimal
import hashlib
import io
import json
import math
import os
from pathlib import Path
import selectors
import signal
import stat
import subprocess
import sys
import time
from types import SimpleNamespace
import wave
import zipfile

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
IDS = tuple(i for i in range(1,26) if i != 21)
TOTAL, TERM_AT, KILL_AT = 600,585,597
STREAM_MAX = 4*1024**2
BASELINE_RECIPE_SHA = 'e840959b16e14f3bdc87df910e8b905a4e03e06f4bd8c5092318594f19c91069'
BASELINE_SCORES_SHA = '10712887a48d1f487b716730dae73c4b9dea05b2cb626169147860d0298662a2' 


def require(ok,message):
    if not ok: raise ValueError(message)


def decode(raw):
    def pairs(items):
        result={}
        for key,value in items:
            require(key not in result,'Duplicate JSON key'); result[key]=value
        return result
    def number(text):
        value=float(text); require(math.isfinite(value),'Nonfinite JSON'); return value
    return json.loads(raw,object_pairs_hook=pairs,parse_float=number,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))


def read_pin(pin,deadline=float('inf'),maximum=128*1024**2):
    require(type(pin) is dict and type(pin.get('bytes')) is int and 0<pin['bytes']<=maximum,'Pin geometry')
    path=Path(pin['path']); require(path.is_absolute() and path.resolve(strict=True)==path,'Pin path differs')
    fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_CLOEXEC|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as stream:
        before=os.fstat(stream.fileno()); require(stat.S_ISREG(before.st_mode) and before.st_size==pin['bytes'],'Pin size/type')
        chunks=[]; size=0
        while size<before.st_size:
            require(time.monotonic()<deadline,'Original deadline exhausted during pins')
            block=stream.read(min(1024**2,before.st_size-size)); require(bool(block),'Truncated pin')
            chunks.append(block); size+=len(block)
        raw=b''.join(chunks); after=os.fstat(stream.fileno()); named=path.stat(follow_symlinks=False)
        signature=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        require(signature(before)==signature(after)==signature(named),'Pin identity changed')
    require(hashlib.sha256(raw).hexdigest()==pin['sha256'],'Pin digest changed')
    return raw


def file_pin(path):
    fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_CLOEXEC|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as stream:
        before=os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and 0<=before.st_size<=8*1024**2,'Artifact pin type/size')
        data=stream.read(8*1024**2+1);after=os.fstat(stream.fileno());named=path.stat(follow_symlinks=False)
        signature=lambda v:(v.st_dev,v.st_ino,v.st_size,v.st_mtime_ns,v.st_ctime_ns)
        require(signature(before)==signature(after)==signature(named) and len(data)==before.st_size,'Artifact changed')
    return {'path':str(path.resolve()),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def module(pin,deadline=float('inf')):
    raw=read_pin(pin,deadline,maximum=256*1024)
    scope={'__name__':'private_production24_'+Path(pin['path']).stem,'__file__':pin['path']}
    exec(compile(raw,pin['path'],'exec'),scope)
    return scope


def save(path,value):
    raw=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
    require(len(raw)<=4*1024**2,'Receipt bound')
    with path.open('xb') as stream: require(stream.write(raw)==len(raw),'Short receipt write')


def plan_at(path):
    raw=path.read_bytes(); require(0<len(raw)<=256*1024,'Plan bound')
    value=decode(raw)
    require(value['ids']==list(IDS) and [x['id'] for x in value['cases']]==list(IDS),'Frozen24 denominator differs')
    require(value['qualified'] is False and value['automatic_retries'] is False,'Plan scope differs')
    require(value['old_recipe_pin']['sha256']==BASELINE_RECIPE_SHA and
        value['old_scores_pin']['sha256']==BASELINE_SCORES_SHA,'Retained baseline differs')
    require(value['numeric_gates']=={'full_F1_min':.9,'median_abs_seconds_max':.035,
        'nearest_rank_p95_seconds_max':.07,'median_relative_adjacent_BPM_error_max':.03,
        'matching_seconds':.07,'nonempty_known_intervals_required':True},'Frozen gates differ')
    return value,{'path':str(path.resolve()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def authorization(plan_pin,stage):
    path=BASE/('root-'+stage+'-authorization.json')
    raw=path.read_bytes(); require(0<len(raw)<=16384,'Authorization bound')
    value=decode(raw)
    require(value.get('stage')==stage and value.get('plan_sha256')==plan_pin['sha256'] and
        value.get('runner_sha256')==file_pin(Path(__file__))['sha256'] and value.get('authorized_once') is True,
        'Exact stage authorization missing')
    return value,file_pin(path)


def helpers(plan):
    return {name:module(pin) for name,pin in plan['helpers'].items()}


def extract(plan,plan_pin):
    """Separate preparation stage: exact archive bytes, no resampler or subprocess."""
    authorization(plan_pin,'extract')
    require(not (BASE/'wav').exists() and not (BASE/'extracted-manifest.json').exists(),'Preserve previous extraction')
    destination=BASE/'wav'; destination.mkdir(mode=0o700)
    rows=[]; total=0; header=decode(read_pin(plan['original_header_pin']))
    by_id={r['id']:r for r in header['tracks']}
    with zipfile.ZipFile(io.BytesIO(read_pin(plan['archive_pin']))) as archive:
        infos={r.filename:r for r in archive.infolist()}
        require(len(infos)==91,'Archive member set differs')
        for row in plan['cases']:
            h=by_id[row['id']]; info=infos[row['member']]
            require(info.file_size==h['ZIP_uncompressed_bytes'] and info.file_size<=5*1024**2,'WAV extent differs')
            raw=archive.read(info); total+=len(raw); require(total<=80*1024**2,'WAV total bound')
            require(hashlib.sha256(raw[:h['header_bytes_read']]).hexdigest()==h['header_sha256'],'WAV header changed')
            with wave.open(io.BytesIO(raw),'rb') as source:
                require((source.getnchannels(),source.getsampwidth(),source.getframerate(),source.getnframes())==
                    (2,2,44100,row['original_frames']) and source.getcomptype()=='NONE','Original WAV geometry differs')
            path=destination/f"{row['id']:02d}.wav"
            with path.open('xb') as stream: require(stream.write(raw)==len(raw),'Short WAV extraction')
            rows.append({'id':row['id'],'wav_pin':file_pin(path)})
    save(BASE/'extracted-manifest.json',{'schema':1,'plan_pin':plan_pin,'archive_pin':plan['archive_pin'],
        'old_recipe_pin':plan['old_recipe_pin'],'cases':rows,'qualified':False})


def measurement_inputs(plan,deadline):
    require(plan['status']=='frozen_pending_root_model_authorization' and plan['native_binary_pin'] and
        plan['native_build_attestation_pin'] and type(plan['native_runtime_pins']) is list and
        bool(plan['native_runtime_pins']),'Draft/build-unbound packet is unarmed')
    for key in ('native_binary_pin','native_build_attestation_pin','worker_pin','model_pin','python_binary_pin',
                'archive_pin','original_header_pin','old_recipe_pin','old_scores_pin'):
        read_pin(plan[key],deadline)
    for pin in plan['upstream_pins']+plan['dependency_pins']+plan['native_runtime_pins']:
        read_pin(pin,deadline)
    extracted=decode(read_pin(plan['extracted_manifest_pin'],deadline))
    require(extracted['archive_pin']==plan['archive_pin'] and extracted['old_recipe_pin']==plan['old_recipe_pin'] and
        extracted['cases']==[{'id':r['id'],'wav_pin':r['wav_pin']} for r in plan['cases']], 'Extraction lineage differs')
    prepared=decode(read_pin(plan['prepared_manifest_pin'],deadline))
    require(prepared['native_binary_pin']==plan['native_binary_pin'] and
        prepared['extracted_manifest_pin']==plan['extracted_manifest_pin'] and prepared['cases']==
        [{'id':r['id'],'prepared_frames':r['prepared_frames'],'pcm_sha256':r['pcm_sha256']} for r in plan['cases']],
        'Actual native preparation lineage differs')
    for row in plan['cases']:
        read_pin(row['wav_pin'],deadline,maximum=5*1024**2);read_pin(row['CSV_pin'],deadline,maximum=16384)
        require(type(row['prepared_frames']) is int and 0<row['prepared_frames']<=24*48000+4096 and
            type(row['pcm_sha256']) is str and len(row['pcm_sha256'])==64,'Actual native preparation is not frozen')
    require(Path(plan['python_invocation']).resolve(strict=True)==Path(plan['python_binary_pin']['path']),
        'Python invocation changed')
    for pin in plan['helpers'].values(): read_pin(pin,deadline,maximum=256*1024)
    owner=module(plan['owner_pin'],deadline)
    require((owner['LIVE_LIMIT'],owner['HISTORY_LIMIT'],owner['HISTORY_BYTES'])==(64,768,2*1024**2),
        'Reviewed ownership limits differ')
    return owner


def parse_rows(raw):
    require(len(raw)<=STREAM_MAX and raw.endswith(b'\n'),'Incomplete/oversized native stream')
    values=[decode(line) for line in raw.splitlines()]
    require(len(values)<=25 and values and all(type(v) is dict for v in values) and
        values[-1].get('kind')=='production-bpm-complete','Native completion missing')
    rows=values[:-1]
    require(all(type(v) is dict and v.get('schema')==1 and type(v.get('schema')) is int and
        v.get('kind')=='production-bpm-case' and v.get('ordinal')==i and type(v.get('ordinal')) is int
        for i,v in enumerate(rows)),'Native case order/schema differs')
    terminal=values[-1]
    require(type(terminal.get('schema')) is int and terminal['schema']==1 and
        type(terminal.get('completed')) is int and terminal['completed']==len(rows) and
        type(terminal.get('expected')) is int and terminal['expected']==24 and
        type(terminal.get('complete')) is bool and type(terminal.get('passed')) is bool,
        'Native terminal schema/count differs')
    require(not terminal['complete'] or len(rows)==24,'Native complete count differs')
    require(not terminal['passed'] or terminal['complete'] and all(r.get('passed') is True for r in rows),
        'Native passed aggregate differs')
    return rows,terminal


def sampled_rss(owner,owned,failures):
    """Sample exact owned lifetimes; a missing RSS requires proved exit state."""
    total=0; zombies=0
    for expected in owner['live_owned'](owned,failures).values():
        pid=expected['pid']
        try:
            before=owner['process_record'](pid)
            require(owner['same_identity'](before,expected),'RSS lifetime changed')
            path=Path('/proc')/str(pid)/'status'
            raw=path.read_bytes();require(len(raw)<=16384,'RSS status bound')
            lines=raw.decode().splitlines()
            after=owner['process_record'](pid)
            require(owner['same_identity'](after,expected),'RSS lifetime changed')
            states=[line.split() for line in lines if line.startswith('State:')]
            require(len(states)==1 and len(states[0])>=2,'RSS process state missing')
            if states[0][1] in ('Z','X','x'):
                zombies+=1;continue
            values=[line.split() for line in lines if line.startswith('VmRSS:')]
            if not values:
                # Exit may release mm after the first status state was printed.
                # One same-lifetime second observation must now prove exit;
                # an unavailable live RSS is still a fatal observation failure.
                raw=path.read_bytes();require(len(raw)<=16384,'RSS status bound')
                require(owner['same_identity'](owner['process_record'](pid),expected),'RSS lifetime changed')
                states=[line.split() for line in raw.decode().splitlines() if line.startswith('State:')]
                require(len(states)==1 and len(states[0])>=2 and states[0][1] in ('Z','X','x'),
                    'Live owned RSS missing')
                zombies+=1;continue
            require(len(values)==1 and len(values[0])==3 and values[0][2]=='kB' and
                values[0][1].isascii() and values[0][1].isdigit(),'Live owned RSS malformed')
            total+=int(values[0][1])*1024
        except (FileNotFoundError,ProcessLookupError): continue
    require(not failures,'Owned identity observation failed')
    return total,zombies


def run(plan,plan_pin):
    """One fixed native invocation; reuse reviewed owner identity/group primitives."""
    started=time.monotonic(); deadline=started+TOTAL
    try:
        auth,auth_pin=authorization(plan_pin,'model')
        require(auth.get('model_forward') is True,'Model authorization missing')
        owner=measurement_inputs(plan,deadline)
        require(not (BASE/'dispatch.json').exists() and not (BASE/'output').exists(),'No retry/output reuse')
        output=BASE/'output'; output.mkdir(mode=0o700)
        command=[plan['native_binary_pin']['path'],'--bpm-analysis',str(output),plan['python_invocation'],
            plan['source_directory'],plan['model_pin']['path'],plan['worker_pin']['path']]+[x['wav_pin']['path'] for x in plan['cases']]
    except BaseException as error:
        failed={'schema':1,'plan_pin':plan_pin,'qualified':False,'complete':False,'failure_phase':'preflight',
            'native_launched':False,'cleanup_proven':False,'cleanup_scope':'No native ownership evidence created',
            'errors':[{'type':type(error).__name__,'message':str(error)[:2048]}],
            'started_monotonic':started,'deadline_monotonic':deadline,'elapsed_seconds':time.monotonic()-started}
        save(BASE/'execution.json',failed)
        return failed
    report={'schema':1,'plan_pin':plan_pin,'authorization_pin':auth_pin,'command':command,'started_monotonic':started,
        'deadline_monotonic':deadline,'qualified':False,
        'errors':[],'signals':[],'complete':False,'cleanup_proven':False,
        'maximum_sampled_owned_rss_bytes':0,'rss_samples':0,'zombie_rss_observations':0,
        'rss_limit_bytes':2147483648,'rss_scope':'Sampled observed owned tree, not a hard peak/RSS bound'}
    child=identity=None; owned={}; groups=set(); captures={}; selector=None; stop_at=None; term_groups=set(); kill_groups=set(); old_handlers={}
    def stop(number,frame):
        nonlocal stop_at
        if stop_at is None: stop_at=time.monotonic()
        report['operator_signal']=number
    def signals():
        if child is None: return
        now=time.monotonic(); term=min(started+TERM_AT,stop_at if stop_at is not None else started+TERM_AT)
        kill=min(started+KILL_AT,term+12)
        for when,number,sent in ((term,signal.SIGTERM,term_groups),(kill,signal.SIGKILL,kill_groups)):
            if now>=when:
                if number==signal.SIGTERM and stop_at is None:
                    report.setdefault('stop_reason','original_whole_command_budget')
                sent_now=owner['signal_owned'](child,identity,owned,number,sent,report['errors']); sent.update(sent_now)
                if sent_now: report['signals'].append({'signal':int(number),'groups':sent_now,'elapsed_seconds':now-started})
    def drain():
        nonlocal stop_at
        if selector is None: return
        for key,_ in selector.select(max(0,min(.05,deadline-time.monotonic()))):
            data=os.read(key.fd,8192)
            if not data: selector.unregister(key.fileobj);key.fileobj.close();continue
            row=captures[key.data];row['received']+=len(data);payload=data[:max(0,STREAM_MAX-row['written'])]
            if payload: require(row['stream'].write(payload)==len(payload),'Short stream write');row['written']+=len(payload)
            if len(payload)!=len(data): row['overflow']=True;stop_at=stop_at or time.monotonic()
    save(BASE/'dispatch.json',report)
    try:
        old_handlers={n:signal.signal(n,stop) for n in (signal.SIGINT,signal.SIGTERM)}
        selector=selectors.DefaultSelector()
        for name in ('stdout','stderr'):
            captures[name]={'stream':(output/(name+'.log')).open('xb'),'written':0,'received':0,'overflow':False}
        env=dict(os.environ);env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
        dispatch_now=time.monotonic()
        require(dispatch_now<deadline,'Original command deadline exhausted before native dispatch')
        require(stop_at is None,'Operator cancellation before native dispatch')
        child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            cwd=ROOT,env=env,start_new_session=True,bufsize=0)
        groups.add(child.pid);identity=owner['process_record'](child.pid)
        require(identity['group']==identity['session']==child.pid,'Native session differs')
        owned[(child.pid,identity['start_ticks'])]=identity
        for name in ('stdout','stderr'): selector.register(getattr(child,name),selectors.EVENT_READ,name)
        while child.poll() is None and time.monotonic()<deadline:
            owner['remember_owned'](child,identity,owned,groups,deadline)
            rss,zombies=sampled_rss(owner,owned,report['errors']);report['rss_samples']+=1
            report['maximum_sampled_owned_rss_bytes']=max(report['maximum_sampled_owned_rss_bytes'],rss)
            report['zombie_rss_observations']+=zombies
            if rss>report['rss_limit_bytes']:
                report['errors'].append({'phase':'rss','message':'Sampled owned RSS exceeds2GiB'});stop_at=stop_at or time.monotonic()
            signals();drain()
        require(child.poll() is not None,'Original600s deadline exhausted')
    except BaseException as error:
        report['errors'].append({'phase':'run','type':type(error).__name__,'message':str(error)[:2048]});stop_at=stop_at or time.monotonic()
    finally:
        for n in old_handlers: signal.signal(n,signal.SIG_IGN)
        while child is not None and time.monotonic()<deadline:
            try:
                if child.poll() is None:
                    if identity is None:
                        identity=owner['process_record'](child.pid)
                        require(identity['group']==identity['session']==child.pid,'Native session differs')
                        owned[(child.pid,identity['start_ticks'])]=identity
                    owner['remember_owned'](child,identity,owned,groups,deadline)
                remaining=owner['live_owned'](owned,report['errors'])
                if child.poll() is not None and not remaining and (selector is None or not selector.get_map()): break
                if child.poll() is not None and remaining: stop_at=stop_at or time.monotonic()
                signals();drain()
            except BaseException as error:
                if len(report['errors'])<64: report['errors'].append({'phase':'cleanup','message':str(error)[:2048]})
                stop_at=stop_at or time.monotonic();signals();time.sleep(max(0,min(.02,deadline-time.monotonic())))
        try:
            if child is not None: child.wait(timeout=max(0,deadline-time.monotonic()))
        except Exception as error: report['errors'].append({'phase':'reap','message':str(error)[:2048]})
        report['complete_capture']=selector is not None and not selector.get_map()
        if selector is not None:
            try: selector.close()
            except Exception as error: report['errors'].append({'phase':'selector_close','message':str(error)[:2048]})
        for row in captures.values():
            try: row['stream'].close()
            except Exception as error: report['errors'].append({'phase':'capture_close','message':str(error)[:2048]})
        if child is not None:
            for name in ('stdout','stderr'):
                try: getattr(child,name).close()
                except Exception as error: report['errors'].append({'phase':'pipe_close','message':str(error)[:2048]})
        report['returncode']=None if child is None else child.returncode
        report['remaining_known_processes']=list(owner['live_owned'](owned,report['errors']).values())
        report['owned_groups_absent']=owner['absent_groups'](groups)
        report['known_processes']=list(owned.values());report['elapsed_seconds']=time.monotonic()-started
        report['cleanup_proven']=child is not None and child.returncode is not None and not report['remaining_known_processes'] and bool(groups) and all(report['owned_groups_absent'].values()) and not report['errors']
        report['captures']={name:{k:v for k,v in row.items() if k!='stream'} for name,row in captures.items()}
        for name in captures:
            try: report['captures'][name]['pin']=file_pin(output/(name+'.log'))
            except Exception as error: report['errors'].append({'phase':'capture_pin','message':str(error)[:2048]})
        try:
            native_rows,terminal=parse_rows(read_pin(report['captures']['stdout']['pin'],maximum=STREAM_MAX))
            report['native_terminal']=terminal
            report['native_completed']=len(native_rows)==24 and terminal['complete'] and terminal['mode']=='analysis'
            report['native_operational_failed_cases']=sum(r.get('passed') is not True for r in native_rows)
        except Exception as error:
            report['native_completed']=False
            report['errors'].append({'phase':'native_capture','type':type(error).__name__,'message':str(error)[:2048]})
        try:
            measurement_inputs(plan,deadline)
            report['inputs_reverified']=True
        except Exception as error:
            report['inputs_reverified']=False
            report['errors'].append({'phase':'final_input_pins','type':type(error).__name__,'message':str(error)[:2048]})
        report['cleanup_scope']='Observed PID/start/group/session lifetimes and direct native reap; numerical/analysis failures remain separate'
        final_now=time.monotonic();report['elapsed_seconds']=final_now-started
        report['within_original_command_budget']=final_now<deadline
        if not report['within_original_command_budget']:
            report['errors'].append({'phase':'final_budget','message':'Original command deadline exhausted during final verification'})
        report['complete']=report['native_completed'] and not report['errors'] and report['cleanup_proven'] and report['complete_capture'] and report['returncode'] in (0,1) and not report['signals'] and stop_at is None and 'operator_signal' not in report and all(not r['overflow'] for r in captures.values())
        save(BASE/'execution.json',report)
        for n,handler in old_handlers.items(): signal.signal(n,handler)
    return report


def failed_case(identifier,reason):
    return {'id':identifier,'status':'Failed','reason':reason,'per_item_accuracy_screen':False,
        'full':None,'confidence':'Unknown','downbeat_accuracy':'Unavailable'}


def score_case(source,row,admitted,helpers):
    """Use actual accepted source-frame events, including Unknown summaries."""
    identifier=source['id']
    if row is None: return failed_case(identifier,'Missing native case')
    try:
        require(row['source']==source['wav_pin']['path'] and row['source_sha256']==source['wav_pin']['sha256'] and
            row['source_bytes']==source['wav_pin']['bytes'],'Original source differs')
        require(row['prepared_frames']==source['prepared_frames'] and row['prepared_bytes']==source['prepared_frames']*8 and
            row['pcm_sha256']==source['pcm_sha256'] and row['prepared_rate_hz']==48000,'Actual prepared source differs')
        require(row['passed'] is True and row['analysis_status'] in ('Estimated','Unknown') and row['analysis_error']=='' and
            row['cache_hit'] is False and row['analysis_frames']==source['prepared_frames'] and
            row['analysis_pcm_sha256']==source['pcm_sha256'],'Native analysis failed or identity differs')
        beats=row['beats'];require(type(beats) is list and len(beats)<=4096,'Beat count differs')
        previous=-1
        for b in beats:
            require(type(b) is dict and set(b)=={'frame','downbeat'} and type(b['frame']) is int and
                previous<b['frame']<source['prepared_frames'] and b['frame']>=0 and type(b['downbeat']) is bool,'Beat schema/order differs')
            previous=b['frame']
        seconds=[b['frame']/48000 for b in beats]
        intervals=helpers['admission']['source_intervals'](seconds,source['prepared_frames'],48000)
        metrics=helpers['challenge']['item_metrics'](SimpleNamespace(metrics=helpers['common']['metrics']),admitted,seconds,intervals,[])
        return {'id':identifier,'status':row['analysis_status'],**metrics,'confidence':'Unknown',
            'downbeat_accuracy':'Unavailable','raw_beats':beats,'source_pcm_sha256':source['pcm_sha256']}
    except (KeyError,TypeError,ValueError,ZeroDivisionError) as error:
        return failed_case(identifier,str(error))


def score(plan,plan_pin):
    h=helpers(plan)
    execution=None; execution_pin=None; operational=False; raw=None; scored_stream_pin=None
    try:
        execution_pin=file_pin(BASE/'execution.json')
        execution=decode(read_pin(execution_pin,maximum=STREAM_MAX))
        operational=(execution.get('plan_pin')==plan_pin and execution.get('complete') is True and
            execution.get('cleanup_proven') is True and execution.get('inputs_reverified') is True)
        if operational:
            scored_stream_pin=execution['captures']['stdout']['pin']
            raw=read_pin(scored_stream_pin,maximum=STREAM_MAX)

    except (OSError,ValueError,KeyError,TypeError): operational=False
    stream_error=None
    try:
        if raw is None:
            scored_stream_pin=file_pin(BASE/'output/stdout.log')
            require(scored_stream_pin['bytes']<=STREAM_MAX,'Scored stream exceeds bound')
            raw=read_pin(scored_stream_pin,maximum=STREAM_MAX) if scored_stream_pin['bytes'] else b''
        rows,terminal=parse_rows(raw)
        require(len(rows)<=24 and terminal.get('mode')=='analysis','Native mode differs')
    except (OSError,ValueError,KeyError,TypeError) as error:
        rows=[];stream_error=str(error)[:2048]
        terminal={'mode':'analysis','complete':False,'error':stream_error}
    by_ordinal={r['ordinal']:r for r in rows};header=decode(read_pin(plan['original_header_pin']))
    headers={r['id']:r for r in header['tracks']};results=[]
    for ordinal,source in enumerate(plan['cases']):
        admitted=h['admission']['admit_artbeat_track'](headers[source['id']],read_pin(source['CSV_pin']).decode())
        results.append(score_case(source,by_ordinal.get(ordinal),admitted,h))
    old=decode(read_pin(plan['old_scores_pin']));require(old['items_passing_numeric_screen']==9 and len(old['cases'])==24,'Retained baseline differs')
    save(BASE/'production-scores.json',{'schema':1,'plan_pin':plan_pin,'qualified':False,'cases':results,
        'items_passing_numeric_screen':sum(r['per_item_accuracy_screen'] for r in results),'denominator':24,
        'operational_pass':operational,'execution_receipt':execution_pin if execution else None,
        'scored_stream_pin':scored_stream_pin,
        'retained_baseline_numeric_passed':9,'retained_baseline_pin':plan['old_scores_pin'],'native_stream_error':stream_error,
        'whole_beat_gate_pass':False,'downbeat_accuracy':'Unavailable','training_independence':'Unknown',
        'scope':'Exposed24 actual production-input comparison only; no shift/octave/threshold fitting or M2 qualification.'})


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--stage',choices=('extract','run','score'))
    args=parser.parse_args()
    if args.stage is None: print('Unarmed; no dataset/model/host read or child without explicit stage.');return
    plan,pin=plan_at(BASE/'plan.json')
    if args.stage=='extract': extract(plan,pin)
    elif args.stage=='run':
        result=run(plan,pin)
        raise SystemExit(0 if result['complete'] else 1)
    else: score(plan,pin)


if __name__=='__main__': main()
