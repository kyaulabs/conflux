"""Memory evidence, lifetime rejection and fixed-budget checks; no real processes."""
import importlib.util
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

module_path = Path(sys.argv.pop(1)) if len(sys.argv) > 1 else Path(__file__).with_name('rss_candidate.py')
spec = importlib.util.spec_from_file_location('rss_under_test', module_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
LIVE = b'State:\tR (running)\n'
DEAD = b'State:\tZ (zombie)\n'


class ObserverTests(unittest.TestCase):
    def sample(self, statuses, identities=None, deadline=None, failures=None, stalled_clock=False):
        expected = dict(pid=42, start_ticks=9, group=42, session=42, ppid=1)
        process = Mock(side_effect=identities) if identities else Mock(return_value=expected)
        owner = dict(live_owned=lambda owned, errors: owned, process_record=process,
                     same_identity=lambda a, b: all(a[key] == b[key] for key in ('pid', 'start_ticks', 'group', 'session')))
        self.reads = 0
        self.now = 0.0
        def read():
            value = statuses[min(self.reads, len(statuses) - 1)]
            self.reads += 1
            if isinstance(value, BaseException):
                raise value
            return value
        def sleep(seconds):
            self.assertGreater(seconds, 0)
            self.assertLessEqual(seconds, .001)
            if not stalled_clock:
                self.now += seconds
        root = Mock()
        root.__truediv__ = Mock(return_value=root)
        root.read_bytes.side_effect = read
        with patch.object(module, 'Path', return_value=root), \
             patch.object(module.time, 'monotonic', side_effect=lambda: self.now), \
             patch.object(module.time, 'sleep', side_effect=sleep):
            kwargs = {} if deadline is None else dict(deadline=deadline)
            return module.sampled_rss(owner, {(42, 9): expected}, [] if failures is None else failures, **kwargs)

    def test_two_nonterminal_missing_samples_then_proved_exit(self):
        self.assertEqual(self.sample([LIVE, LIVE, DEAD]), (0, 1))
        self.assertEqual(self.reads, 3)

    def test_two_missing_samples_then_actual_memory_is_not_zero(self):
        self.assertEqual(self.sample([LIVE, LIVE, LIVE + b'VmRSS:\t123 kB\n']), (123 * 1024, 0))

    def test_live_missing_memory_remains_fatal_within_bound(self):
        with self.assertRaisesRegex(ValueError, 'Live owned RSS missing'):
            self.sample([LIVE])
        self.assertLessEqual(self.reads, 32)
        self.assertLessEqual(self.now, .02)

    def test_read_cap_applies_even_if_clock_stops(self):
        with self.assertRaisesRegex(ValueError, 'Live owned RSS missing'):
            self.sample([LIVE], stalled_clock=True)
        self.assertEqual(self.reads, 32)

    def test_outer_original_deadline_is_not_renewed(self):
        with self.assertRaisesRegex(ValueError, 'Live owned RSS missing'):
            self.sample([LIVE], deadline=.0015)
        self.assertLessEqual(self.now, .0015)
        self.assertLessEqual(self.reads, 3)

    def test_pid_reuse_during_recheck_is_rejected(self):
        expected = dict(pid=42, start_ticks=9, group=42, session=42, ppid=1)
        for key in ('start_ticks', 'group', 'session'):
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, 'lifetime changed'):
                self.sample([LIVE, DEAD], [expected, expected, dict(expected, **{key: 99})])

    def test_live_memory_and_terminal_state_are_distinct(self):
        self.assertEqual(self.sample([LIVE + b'VmRSS:\t123 kB\n']), (123 * 1024, 0))
        self.assertEqual(self.sample([DEAD]), (0, 1))
        self.assertEqual(self.sample([FileNotFoundError()]), (0, 0))

    def test_malformed_or_duplicate_live_memory_still_fails(self):
        for value in (b'-1 kB', b'NaN kB', b'12.5 kB', b'12 KB', b'12 kB\nVmRSS:\t13 kB'):
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, 'RSS malformed'):
                self.sample([LIVE + b'VmRSS:\t' + value + b'\n'])
            self.assertEqual(self.reads, 1)

    def test_missing_process_state_still_fails(self):
        with self.assertRaisesRegex(ValueError, 'process state missing'):
            self.sample([b'VmRSS:\t123 kB\n'])

    def test_unproven_owned_tree_still_fails(self):
        with self.assertRaisesRegex(ValueError, 'Owned identity observation failed'):
            self.sample([LIVE + b'VmRSS:\t123 kB\n'], failures=['lost identity'])


if __name__ == '__main__':
    unittest.main()
