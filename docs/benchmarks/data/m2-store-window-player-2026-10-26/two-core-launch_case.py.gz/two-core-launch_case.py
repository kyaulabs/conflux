"""Single dispatch under direct user authorization; dry unless --run is given."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time
from cache_window import BASE, CACHE, GRANT, INHIBITION, MESSAGE, authorization, manifest, pin, save

ENTRY_MONOTONIC = time.monotonic()
ENTRY_UTC = datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(path.read_text())


def check_pin(row):
    assert pin(Path(row['path'])) == row


def show(unit):
    result = subprocess.run(['systemctl', '--user', 'show', unit,
        '--property=LoadState,ActiveState,SubState,InvocationID,MainPID,Result,ExecMainStatus,ControlGroup'],
        capture_output=True, text=True, timeout=5, check=True)
    return dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)


def conditions():
    ac = [p for p in Path('/sys/class/power_supply').glob('*/online')]
    lids = list(Path('/proc/acpi/button/lid').glob('*/state'))
    assert ac and any(p.read_text().strip() == '1' for p in ac)
    assert lids and all(p.read_text().strip().endswith('open') for p in lids)
    receipt = read(INHIBITION)
    state = show(receipt['unit'])
    assert state['ActiveState'] == 'active' and state['SubState'] == 'running'
    assert state['InvocationID'] == receipt['state']['InvocationID']
    result = subprocess.run(['busctl', '--user', '--timeout=2s', '--json=short', 'call',
        'org.kde.Solid.PowerManagement.PolicyAgent', '/org/kde/Solid/PowerManagement/PolicyAgent',
        'org.kde.Solid.PowerManagement.PolicyAgent', 'ListInhibitions'],
        capture_output=True, text=True, timeout=4, check=True)
    assert len(result.stdout) <= 65536
    rows = json.loads(result.stdout)
    assert rows['type'] == 'aas'
    reason = str(BASE.parent / 'm2-store-window-2026-10-26/hold_awake_exec.py')
    assert sum(row[1] == reason for row in rows['data'][0]) >= 2
    return dict(AC_connected_observed=True, lid_open_observed=True,
        original_awake_inhibitor=state, dimming_lock_sleep_inhibited=True,
        physical_conditions_observed_utc=datetime.now(timezone.utc).isoformat())


def pair_clock(original, grant, now):
    assert original['operator_seconds'] == 1200
    assert original['order'] == ['baseline', 'candidate'] and original['retries'] is False
    assert original['operator_deadline_monotonic'] == original['original_readiness_monotonic'] + 1200
    assert original['authorization_grant'] == grant['grant']
    assert original['operator_deadline_monotonic'] <= grant['cutoff_monotonic']
    assert original['operator_deadline_monotonic'] - now >= 600
    return original


def cache_gate(arm,before,retained=None):
    assert arm in ('baseline','candidate') and retained is not None
    assert retained['files'] and retained['bytes']>0 and before==retained


def affinity_contract(plan,command):
    properties=[v for v in command if v.startswith('--property=CPUAffinity=')]
    expected=plan['cpu_affinity']
    assert expected in (list(range(8)),[0,1])
    assert properties==([] if expected==list(range(8)) else ['--property=CPUAffinity=0 1'])
    return expected


def main():
    import os
    parser=argparse.ArgumentParser(description='Standalone signed-candidate diagnostic; dry by default')
    parser.add_argument('--run',action='store_true');args=parser.parse_args()
    assert Path('/proc/1/comm').read_text().strip()=='systemd'
    directory=BASE/'cases/candidate';launch=read(directory/'root-launch-plan-01.json')
    clearance=read(directory/'root-launch-clearance-01.json')
    for row in clearance['pins']:check_pin(row)
    plan=read(directory/'plan.json');check_pin(launch['plan'])
    assert plan['cpu_affinity']==[0,1] and affinity_contract(plan,launch['command'])==[0,1]
    assert not any((directory/name).exists() for name in ('readiness.json','dispatch-01.json','root-unit-dispatch-01.json','output-01'))
    assert read(Path(launch['prior_run_cleanup']['path']))['cleanup_complete']
    grant=authorization();observed=conditions();now=time.monotonic()
    deadline=min(ENTRY_MONOTONIC+1200,grant['cutoff_monotonic'])
    assert deadline-now>=600 and shutil.disk_usage(BASE).free>=2*1024**3
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=Path(plan['source_root']),text=True,timeout=4).strip()
    assert head==plan['source_head']=='b512dd668973cb708121a70c7de9f34e5326f620'
    assert subprocess.check_output(['git','status','--porcelain'],cwd=Path(plan['source_root']),text=True,timeout=4)==''
    before=show(launch['unit']);guard=show('thermal-guard.service')
    assert before['LoadState']=='not-found' and before['MainPID']=='0'
    assert guard['ActiveState']=='active' and guard['SubState']=='running'
    assert now-ENTRY_MONOTONIC<=20
    if not args.run:
        save(directory/'root-single-entry-check-01.json',dict(passed=True,native_started=False,
            authorization=grant,physical_conditions=observed,remaining_seconds=deadline-now))
        print('Standalone entry verified; no client started.');return
    before_cache=manifest();seed=read(BASE/'cache-seed-01.json');cache_gate('candidate',before_cache,seed)
    save(directory/'cache-before-01.json',before_cache)
    human=dict(schema=1,decision='ready',diagnostic_mode=plan['mode'],ready_for_run='output-01',
        plan_sha256=launch['plan']['sha256'],maximum_operator_seconds=1200,maximum_command_seconds=540,
        ui_mode='visible',AC_power=True,lid_open=True,visible_window=True,screen_awake=True,
        Codex_minimized=True,other_work_paused=True,no_suspend=True,recorded_at_utc=ENTRY_UTC,
        recorded_at_monotonic=ENTRY_MONOTONIC,human_reply=MESSAGE,authorization_kind='direct_user_time_window',
        authorization_grant=grant['grant'],original_direct_user_authorization=grant,
        automatic_physical_conditions=observed,fresh_human_reply_claimed=False,
        scope='One standalone diagnostic after a separately closed admission failure; no paired or qualified result.')
    save(directory/'readiness.json',human)
    dispatch=dict(schema=1,arm='candidate',standalone=True,unit=launch['unit'],command=launch['command'],
        original_readiness_utc=ENTRY_UTC,original_readiness_monotonic=ENTRY_MONOTONIC,
        operator_deadline_monotonic=deadline,original_operator_seconds=1200,
        hard_user_cutoff_utc=grant['cutoff_utc'],direct_user_authorization=grant,
        unit_before=before,guard_before=guard,physical_conditions=observed,
        original_failed_control_arm_unchanged=True,automatic_retries=False)
    assert time.monotonic()-ENTRY_MONOTONIC<=20
    result=subprocess.run(launch['command'],capture_output=True,text=True,timeout=10)
    after=show(launch['unit']);dispatch.update(launch_returncode=result.returncode,launch_stdout=result.stdout,
        launch_stderr=result.stderr,unit_after_launch=after,original_owned_cgroup=after.get('ControlGroup',''))
    if int(after.get('MainPID','0')):
        pid=int(after['MainPID']);fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
        dispatch['owner_identity']=dict(pid=pid,start_ticks=int(fields[19]),group=int(fields[2]),session=int(fields[3]),ppid=int(fields[1]))
        dispatch['observed_owner_cpu_affinity']=sorted(os.sched_getaffinity(pid))
    save(directory/'root-unit-dispatch-01.json',dispatch)
    assert result.returncode==0 and after['ActiveState']=='active' and dispatch['observed_owner_cpu_affinity']==[0,1]
    print(json.dumps(dict(status='launched_once_standalone',unit=launch['unit'],affinity=dispatch['observed_owner_cpu_affinity'],cutoff=grant['cutoff_utc'])))


if __name__=='__main__':main()
