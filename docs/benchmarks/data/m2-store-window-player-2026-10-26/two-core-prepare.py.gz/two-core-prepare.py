"""Freeze a standalone two-core diagnostic after the control arm failed admission."""
import hashlib
import json
from pathlib import Path
import re
import shutil

BASE=Path(__file__).resolve().parent
OLD=BASE.parent/'m2-client-affinity-01'
PRIOR=OLD/'cases/candidate'
DEST=BASE/'cases/candidate'


def pin(path):
    raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def save(path,value):
    with path.open('x') as stream:stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def replace(raw):
    return raw.replace(str(OLD),str(BASE)).replace('m2-client-affinity-visible-120-01-candidate',
        'm2-two-core-single-visible-120-01-candidate').replace('conflux-m2-client-affinity-20261026-01-candidate.service',
        'conflux-m2-two-core-single-20261026-01.service')


def main():
    closed=json.loads((OLD/'cases/baseline/root-finished-01.json').read_text())
    assert closed['cleanup_complete'] and not closed['requested120s_complete'] and closed['candidate_not_started']
    for name in ('cache_window.py','test_window_cache.py','test_natural_guard.py',
        'root-build-receipt-01.json','root-source-build-attestation-01.json','source-readiness-01.json'):
        (BASE/name).write_text(replace((OLD/name).read_text()))
    shutil.copytree(OLD/'driver-cache',BASE/'driver-cache')
    DEST.mkdir(parents=True,mode=0o700)
    for name in ('run_host_player.py','run_player_owned.py','close_case.py','launch-command-01.txt',
        'test_host_player.py','test_admission_recovery.py','test_process_cpu.py','test_thread_cpu.py',
        'test_normal_proof.py','test_current_build.py'):
        (DEST/name).write_text(replace((PRIOR/name).read_text()))
    path=DEST/'run_host_player.py';raw=path.read_text()
    old="profile=='power-saver' and bool(re.search(r'(?:warning|critical): .*power-saver engaged',entry)))"
    new="profile=='power-saver' and bool(re.search(r'(?:warning: .*power-saver engaged|critical: CPU/ACPI temperature [0-9]+(?:\\.[0-9]+)?C$)',entry)))"
    assert old in raw;path.write_text(raw.replace(old,new))
    owner=DEST/'run_player_owned.py';owner.write_text(re.sub(r"LAUNCHER_SHA = '[0-9a-f]{64}'",'LAUNCHER_SHA = '+repr(pin(path)['sha256']),owner.read_text()));owner.chmod(0o700)
    t=BASE/'test_natural_guard.py';t.write_text(t.read_text().replace("BASE/'cases/baseline'","BASE/'cases/candidate'"))
    plan=json.loads((PRIOR/'plan.json').read_text());plan['mode']=replace(plan['mode'])
    plan['mesa_shader_cache']['path']=str(BASE/'driver-cache')
    plan['build_receipt']=pin(BASE/'root-build-receipt-01.json');plan['source_build_attestation']=pin(BASE/'root-source-build-attestation-01.json')
    plan['comparison_factor']='Standalone two-physical-core diagnostic; no paired comparison or qualification'
    for key,row in list(plan['sources'].items()):
        path=Path(row['path'])
        if path.is_relative_to(OLD):
            new=BASE/path.relative_to(OLD)
            if new.exists():plan['sources'][key]=pin(new)
    plan['sources']['standalone_preparer']=pin(Path(__file__).resolve())
    save(DEST/'plan.json',plan)
    launch=json.loads(replace((PRIOR/'root-launch-plan-01.json').read_text()))
    launch['plan']=pin(DEST/'plan.json');launch['prior_run_cleanup']=pin(OLD/'cases/baseline/root-finished-01.json')
    launch['standalone_after_failed_control_admission']=True;save(DEST/'root-launch-plan-01.json',launch)
    helper=replace((OLD/'launch_case.py').read_text());helper=helper[:helper.index('def main():')]
    (BASE/'launch_case.py').write_text(helper+(BASE/'single_main.txt').read_text())
    print('Prepared standalone two-core case; no player started.')


if __name__=='__main__':main()
