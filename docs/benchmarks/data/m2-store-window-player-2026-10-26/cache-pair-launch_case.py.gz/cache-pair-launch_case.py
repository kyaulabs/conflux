"""Single dispatch under direct user authorization; dry unless --run is given."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time
from cache_window import BASE, CACHE, GRANT, INHIBITION, MESSAGE, authorization, manifest, pin, save

ENTRY_MONOTONIC = time.monotonic()
ENTRY_UTC = datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(path.read_text())


def check_pin(row):
    assert pin(Path(row['path'])) == row


def show(unit):
    result = subprocess.run(['systemctl', '--user', 'show', unit,
        '--property=LoadState,ActiveState,SubState,InvocationID,MainPID,Result,ExecMainStatus,ControlGroup'],
        capture_output=True, text=True, timeout=5, check=True)
    return dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)


def conditions():
    ac = [p for p in Path('/sys/class/power_supply').glob('*/online')]
    lids = list(Path('/proc/acpi/button/lid').glob('*/state'))
    assert ac and any(p.read_text().strip() == '1' for p in ac)
    assert lids and all(p.read_text().strip().endswith('open') for p in lids)
    receipt = read(INHIBITION)
    state = show(receipt['unit'])
    assert state['ActiveState'] == 'active' and state['SubState'] == 'running'
    assert state['InvocationID'] == receipt['state']['InvocationID']
    result = subprocess.run(['busctl', '--user', '--timeout=2s', '--json=short', 'call',
        'org.kde.Solid.PowerManagement.PolicyAgent', '/org/kde/Solid/PowerManagement/PolicyAgent',
        'org.kde.Solid.PowerManagement.PolicyAgent', 'ListInhibitions'],
        capture_output=True, text=True, timeout=4, check=True)
    assert len(result.stdout) <= 65536
    rows = json.loads(result.stdout)
    assert rows['type'] == 'aas'
    reason = str(BASE.parent / 'm2-store-window-2026-10-26/hold_awake_exec.py')
    assert sum(row[1] == reason for row in rows['data'][0]) >= 2
    return dict(AC_connected_observed=True, lid_open_observed=True,
        original_awake_inhibitor=state, dimming_lock_sleep_inhibited=True,
        physical_conditions_observed_utc=datetime.now(timezone.utc).isoformat())


def pair_clock(original, grant, now):
    assert original['operator_seconds'] == 1200
    assert original['order'] == ['baseline', 'candidate'] and original['retries'] is False
    assert original['operator_deadline_monotonic'] == original['original_readiness_monotonic'] + 1200
    assert original['authorization_grant'] == grant['grant']
    assert original['operator_deadline_monotonic'] <= grant['cutoff_monotonic']
    assert original['operator_deadline_monotonic'] - now >= 600
    return original


def cache_gate(arm, before, retained=None):
    if arm == 'baseline':
        assert before['entries'] == 0 and before['files'] == [] and before['bytes'] == 0
    else:
        assert retained is not None and retained['files'] and retained['bytes'] > 0
        assert before == retained, 'Retained shader cache changed between completed arms'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--arm', required=True, choices=('baseline', 'candidate'))
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    directory = BASE / 'cases' / args.arm
    assert not any((directory / name).exists() for name in
        ('readiness.json', 'output-01', 'root-unit-dispatch-01.json', 'dispatch-01.json'))
    assert shutil.disk_usage(BASE).free >= 2 * 1024**3
    grant = authorization()
    observed = conditions()
    launch = read(directory / 'root-launch-plan-01.json')
    clearance = read(directory / 'root-launch-clearance-01.json')
    for row in clearance['pins']:
        check_pin(row)
    check_pin(launch['plan'])
    plan = read(directory / 'plan.json')
    assert plan['source_head'] == 'b512dd668973cb708121a70c7de9f34e5326f620'
    assert plan['assets']['binary']['sha256'] == 'c25ecbb051a77832d7fdcdbf573f42210e18b188a7c854c709dd0357de39e1d7'
    assert plan['mesa_shader_cache'] == dict(path=str(CACHE), maximum_size='128M')
    for value in ('--setenv=MESA_SHADER_CACHE_DIR=' + str(CACHE), '--setenv=MESA_SHADER_CACHE_MAX_SIZE=128M'):
        assert launch['command'].count(value) == 1
    work = Path(plan['source_root'])
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True, timeout=4).strip()
    assert head == plan['source_head']
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=work, text=True, timeout=4) == ''
    published = read(Path(clearance['source_readiness']['path']))
    assert published['prepared_source_signature_verified_and_checks_passed'] and published['source'] == head and published['release_qualification'] is False
    before_unit = show(launch['unit'])
    assert before_unit['LoadState'] == 'not-found' and before_unit['MainPID'] == '0'
    guard = show('thermal-guard.service')
    assert guard['ActiveState'] == 'active' and guard['SubState'] == 'running'
    assert time.monotonic() - ENTRY_MONOTONIC <= 20
    if not args.run:
        name = next('root-single-step-entry-check-%02d.json' % i for i in range(1, 100)
            if not (directory / ('root-single-step-entry-check-%02d.json' % i)).exists())
        save(directory / name, dict(passed=True, native_started=False,
            conditions=observed, authorization=grant, elapsed_seconds=time.monotonic()-ENTRY_MONOTONIC))
        print(json.dumps(dict(status='verified_unarmed', arm=args.arm)))
        return
    pair_path = BASE / 'pair-readiness-received-01.json'
    if args.arm == 'baseline':
        assert grant['cutoff_monotonic'] - ENTRY_MONOTONIC >= 1200
        original = dict(schema=1, original_readiness_utc=ENTRY_UTC,
            original_readiness_monotonic=ENTRY_MONOTONIC,
            operator_deadline_monotonic=ENTRY_MONOTONIC + 1200, operator_seconds=1200,
            authorization_kind='direct_user_time_window', authorization_grant=grant['grant'],
            original_user_authorization=grant, order=['baseline', 'candidate'], retries=False)
        save(pair_path, original)
    else:
        original = read(pair_path)
        first = BASE / 'cases/baseline'
        closed = read(first / 'root-finished-01.json')
        assert closed['cleanup_complete'] and closed['native_requested120s_complete']
        assert closed['operator_deadline_monotonic'] == original['operator_deadline_monotonic']
    pair_clock(original, grant, time.monotonic())
    cache_before = manifest()
    cache_gate(args.arm, cache_before,
        read(BASE / 'cases/baseline/cache-after-01.json') if args.arm == 'candidate' else None)
    save(directory / 'cache-before-01.json', cache_before)
    human = dict(schema=1, decision='ready', diagnostic_mode=plan['mode'], ready_for_run='output-01',
        plan_sha256=launch['plan']['sha256'], maximum_operator_seconds=1200, maximum_command_seconds=540,
        ui_mode='visible', AC_power=True, lid_open=True, visible_window=True, screen_awake=True,
        Codex_minimized=True, other_work_paused=True, no_suspend=True,
        recorded_at_utc=original['original_readiness_utc'],
        recorded_at_monotonic=original['original_readiness_monotonic'],
        human_reply=MESSAGE, authorization_kind='direct_user_time_window', authorization_grant=grant['grant'],
        original_direct_user_authorization=grant,
        condition_provenance='Automatic AC/lid/inhibitor observations; Codex minimization is the original user commitment; existing host preflight still requires quiet thermal readiness.',
        automatic_physical_conditions=observed, fresh_human_reply_claimed=False)
    save(directory / 'readiness.json', human)
    assert time.monotonic() - ENTRY_MONOTONIC <= 20
    dispatch = dict(schema=1, arm=args.arm, unit=launch['unit'], command=launch['command'],
        original_readiness_utc=original['original_readiness_utc'],
        original_readiness_monotonic=original['original_readiness_monotonic'],
        operator_deadline_monotonic=original['operator_deadline_monotonic'],
        original_operator_seconds=1200, direct_user_authorization=grant,
        launch_plan=pin(directory / 'root-launch-plan-01.json'),
        unit_before=before_unit, guard_before=guard, physical_conditions=observed,
        cache_before=pin(directory / 'cache-before-01.json'), automatic_retries=False)
    result = subprocess.run(launch['command'], capture_output=True, text=True, timeout=10)
    after = show(launch['unit'])
    dispatch.update(launch_returncode=result.returncode, launch_stdout=result.stdout,
        launch_stderr=result.stderr, unit_after_launch=after,
        original_owned_cgroup=after.get('ControlGroup', ''))
    if int(after.get('MainPID', '0')):
        pid = int(after['MainPID'])
        fields = Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()
        dispatch['owner_identity'] = dict(pid=pid, start_ticks=int(fields[19]),
            group=int(fields[2]), session=int(fields[3]), ppid=int(fields[1]))
    save(directory / 'root-unit-dispatch-01.json', dispatch)
    assert result.returncode == 0 and after['ActiveState'] == 'active' and dispatch.get('owner_identity')
    print(json.dumps(dict(status='launched_once', arm=args.arm, unit=launch['unit'],
        user_cutoff=grant['cutoff_utc'], owner=dispatch['owner_identity'])))


if __name__ == '__main__':
    main()
