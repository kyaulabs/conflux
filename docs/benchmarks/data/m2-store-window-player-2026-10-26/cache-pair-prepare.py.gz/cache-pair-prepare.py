"""Freeze the signed clock-fix candidate for an unqualified shader-cache diagnostic."""
import copy
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
OLD=BASE.parent/'m2-mesa-current-player-02'
CW=Path('/home/kyau/.codex/worktrees/deck-state-cache/conflux')
HEAD='b512dd668973cb708121a70c7de9f34e5326f620'
BINARY=ROOT/'build/dev/conflux-manual-playback-soak'


def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def save(path,value):
    with path.open('x') as stream:stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def replace(raw):
    return raw.replace(str(OLD),str(BASE)).replace('m2-mesa-cache-current-visible-120-02-',
        'm2-mesa-cache-current-visible-120-03-').replace('conflux-m2-mesa-current-20261026-02-',
        'conflux-m2-mesa-current-20261026-03-')


def main():
    prior=json.loads((OLD/'root-pair-ended-01.json').read_text())
    assert prior['cleanup_complete'] and prior['status']=='cold_native_run_incomplete'
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
    assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)==''
    commands=json.loads((ROOT/'build/dev/compile_commands.json').read_text())
    for row in commands:
        args=row.get('arguments') or shlex.split(row['command'])
        assert [x for x in args if re.fullmatch(r'-O[0-9sgz]|-Ofast',x)]==['-O2']
        assert not any(x in ('--coverage','-ffast-math','-funsafe-math-optimizations') or x.startswith(('-fprofile','-fcoverage')) for x in args)
    previous=json.loads((OLD/'cases/baseline/plan.json').read_text())
    source_pins=[pin(ROOT/Path(row['path']).relative_to(CW)) for row in previous['source_pins']]
    source_pins.append(pin(ROOT/'tools/experiments/PlaybackControlClock.hpp'))
    assert len({row['path'] for row in source_pins})==len(source_pins)
    for row in source_pins:
        relative=str(Path(row['path']).relative_to(ROOT))
        tracked=subprocess.check_output(['git','show',HEAD+':'+relative],cwd=ROOT)
        assert hashlib.sha256(tracked).hexdigest()==row['sha256']
    receipt=dict(refresh_exit=0,all_compiles_O2_without_coverage_or_fast_math=True,
        compile_commands_count=len(commands),source_head=HEAD,source_root=str(ROOT),
        binary=pin(BINARY),cache=pin(ROOT/'build/dev/CMakeCache.txt'),
        compile_commands=pin(ROOT/'build/dev/compile_commands.json'),
        build_command=['cmake','--build','build/dev','--parallel','2','--target',
            'conflux-manual-playback-soak','conflux-playback-control-clock-test'])
    save(BASE/'root-build-receipt-01.json',receipt)
    attestation=dict(source_root=str(ROOT),source_head=HEAD,binary=pin(BINARY),
        source_pins=source_pins,build_receipt_sha256=pin(BASE/'root-build-receipt-01.json')['sha256'],
        tracked_sources_match_head=True,build_completed_from_pinned_source=True,
        runtime_UI_matches_fixed_meter_snapshot=True,
        clock_assertion_is_only_native_workload_change=True,qualified=False)
    save(BASE/'root-source-build-attestation-01.json',attestation)
    save(BASE/'source-readiness-01.json',dict(schema=1,source=HEAD,
        prepared_source_signature_verified_and_checks_passed=True,
        signing_fingerprint='F621F658D66098CBE9E5C55D66788CCBB5E215AC',
        native_regression_red_then_green=True,targeted_ctest_entries_passed=2,
        existing_Python_evidence_checks_passed=33,optimized_native_build_passed=True,
        source_and_PR_CI_pending=True,merged=False,release_qualification=False,
        pull_request='https://github.com/kyaulabs/conflux/pull/113',
        scope='Local testing of a signed candidate before its required CI/approval/merge; no product or milestone promotion.'))
    for name in ('cache_window.py','launch_case.py','test_window_cache.py','test_natural_guard.py','close_preflight_failure.py'):
        (BASE/name).write_text(replace((OLD/name).read_text()))
    entry=BASE/'launch_case.py';raw=entry.read_text()
    raw=raw.replace("'4cc8d743e06412515a2fd765c39e3d8af1558881'",repr(HEAD))
    raw=raw.replace("'64da1b50048775192d7dea0aa01922a4d6c00fe5c5c7dd174e2a8e4c9984d46e'",repr(pin(BINARY)['sha256']))
    raw=raw.replace("clearance['publication_complete']","clearance['source_readiness']")
    raw=raw.replace("published['all9_push_PR_postmerge_jobs_passed'] and published['source'] == head",
        "published['prepared_source_signature_verified_and_checks_passed'] and published['source'] == head and published['release_qualification'] is False")
    entry.write_text(raw)
    (BASE/'driver-cache').mkdir(mode=0o700)
    for arm in ('baseline','candidate'):
        previous_dir=OLD/'cases'/arm;dest=BASE/'cases'/arm
        dest.mkdir(parents=True,mode=0o700)
        for name in ('run_host_player.py','run_player_owned.py','close_case.py','launch-command-01.txt',
            'test_host_player.py','test_admission_recovery.py','test_process_cpu.py','test_thread_cpu.py',
            'test_normal_proof.py','test_current_build.py'):
            (dest/name).write_text(replace((previous_dir/name).read_text()))
        driver=dest/'run_host_player.py';raw=driver.read_text()
        raw=raw.replace('W = Path('+repr(str(CW))+')','W = Path('+repr(str(ROOT))+')')
        raw=raw.replace("SOURCE_HEAD = '4cc8d743e06412515a2fd765c39e3d8af1558881'",'SOURCE_HEAD = '+repr(HEAD))
        raw=re.sub(r"BINARY = Path\('[^']+'\)",'BINARY = Path('+repr(str(BINARY))+')',raw,count=1)
        raw=re.sub(r"BINARY_SHA = '[0-9a-f]{64}'",'BINARY_SHA = '+repr(pin(BINARY)['sha256']),raw,count=1)
        raw=re.sub(r'COMPILE_COMMANDS_COUNT = [0-9]+','COMPILE_COMMANDS_COUNT = '+str(len(commands)),raw,count=1)
        driver.write_text(raw)
        owner=dest/'run_player_owned.py';owner.write_text(re.sub(r"LAUNCHER_SHA = '[0-9a-f]{64}'",
            'LAUNCHER_SHA = '+repr(pin(driver)['sha256']),owner.read_text()));owner.chmod(0o700)
        plan=copy.deepcopy(json.loads((previous_dir/'plan.json').read_text()))
        plan.update(mode=replace(plan['mode']),source_root=str(ROOT),source_head=HEAD,
            runtime_ui_source_root=str(ROOT),source_pins=source_pins,
            build_receipt=pin(BASE/'root-build-receipt-01.json'),
            source_build_attestation=pin(BASE/'root-source-build-attestation-01.json'))
        plan['mesa_shader_cache']['path']=str(BASE/'driver-cache')
        plan['actual_checkout_head_at_preparation']=HEAD
        for key,row in list(plan['assets'].items()):
            path=Path(row['path'])
            if path.is_relative_to(CW):plan['assets'][key]=pin(ROOT/path.relative_to(CW))
        plan['assets']['binary']=pin(BINARY)
        for key,row in list(plan['helpers'].items()):
            path=Path(row['path'])
            if path.is_relative_to(CW):plan['helpers'][key]=pin(ROOT/path.relative_to(CW))
        plan['helpers']['compile_commands']=receipt['compile_commands'];plan['helpers']['build_cache']=receipt['cache']
        sources={}
        for key,row in plan['sources'].items():
            path=Path(row['path'])
            if path.is_relative_to(OLD):
                new=BASE/path.relative_to(OLD)
                if new.exists():row=pin(new)
            elif path.is_relative_to(CW):
                new=ROOT/path.relative_to(CW);row=pin(new)
                if key==str(path):key=str(new)
            sources[key]=row
        for row in source_pins:sources[row['path']]=row
        sources['clock_fix_preparer']=pin(Path(__file__).resolve())
        plan['sources']=sources
        save(dest/'plan.json',plan)
        launch=json.loads(replace((previous_dir/'root-launch-plan-01.json').read_text()))
        launch.update(plan=pin(dest/'plan.json'),source_head=HEAD,
            prior_run_cleanup=pin(OLD/'cases/baseline/root-finished-01.json'),
            signed_candidate_CI_still_required_before_merge=True)
        save(dest/'root-launch-plan-01.json',launch)
    print(json.dumps(dict(status='prepared_unarmed_signed_candidate',source=HEAD,
        source_pins=len(source_pins),compiler_rows=len(commands),binary=pin(BINARY))))


if __name__=='__main__':main()
