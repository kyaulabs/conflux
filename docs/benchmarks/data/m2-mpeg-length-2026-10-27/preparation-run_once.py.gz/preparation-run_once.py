"""One bounded CPU-only source preparation; dry default, no automatic retry."""
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False)+'\n')


def query(unit):
    raw = subprocess.check_output(['/usr/bin/systemctl', '--user', 'show', unit,
        '--property=LoadState,ActiveState,SubState,MainPID,InvocationID,ControlGroup,Result,ExecMainStatus'],
        text=True, timeout=3)
    return dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)


def verify(plan):
    for row in plan['input_pins']:
        path = Path(row['path'])
        if not path.is_file() or path.stat().st_size != row['bytes']:
            raise ValueError('Frozen input extent differs: '+str(path))
        with path.open('rb') as stream:
            if hashlib.file_digest(stream, 'sha256').hexdigest() != row['sha256']:
                raise ValueError('Frozen input hash differs: '+str(path))


def environment(plan):
    guard = query('thermal-guard.service')
    assert guard['ActiveState'] == 'active' and guard['SubState'] == 'running'
    assert all(guard[k] == v for k, v in plan['guard_identity'].items())
    caps = {name:int(Path(name).read_text()) for name in plan['power_caps']}
    assert all((0 < caps[name] <= ceiling if name.endswith('power_limit_uw') else caps[name] == ceiling)
               for name, ceiling in plan['power_caps'].items())
    return dict(guard=guard, power_caps=caps)


def run():
    plan = json.loads((BASE/'music-plan-01.json').read_text())
    assert plan['status'] == 'frozen_offline_correctness_only' and plan['physical_readiness_required'] is False
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    assert not (BASE/'reservation-01.json').exists() and not (BASE/'output-01').exists()
    verify(plan)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == plan['source_head']
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
    assert query(plan['unit'])['LoadState'] == 'not-found'
    before = environment(plan)
    began = time.monotonic()
    save(BASE/'reservation-01.json', dict(began_monotonic=began, original_cleanup_deadline=began+450,
        plan_sha256=hashlib.sha256((BASE/'music-plan-01.json').read_bytes()).hexdigest(),
        environment_before=before, automatic_retries=False, physical_readiness_consumed=False))
    receipt = dict(unit=plan['unit'], began_monotonic=began, cleanup_complete=False,
                   automatic_retries=False, physical_readiness_consumed=False, errors=[])
    invocation = None
    original_group = None
    try:
        dispatch = subprocess.run(plan['command'], capture_output=True, text=True, timeout=10)
        receipt['dispatch'] = dict(returncode=dispatch.returncode, stdout=dispatch.stdout, stderr=dispatch.stderr)
        observed = query(plan['unit'])
        receipt['unit_after_dispatch'] = observed
        invocation = observed['InvocationID']
        original_group = observed['ControlGroup']
        assert dispatch.returncode == 0 and invocation
        if original_group:
            assert original_group.endswith('/'+plan['unit'])
        else:
            assert observed['MainPID'] == '0' and observed['SubState'] in ('exited', 'failed', 'dead')
        while observed['MainPID'] != '0':
            if time.monotonic()-began >= 420:
                raise TimeoutError('Original 420-second observation allowance exhausted')
            time.sleep(1)
            observed = query(plan['unit'])
            assert observed['InvocationID'] == invocation
        receipt['unit_finished'] = observed
        scores = BASE/'output-01/preparation.json'
        if scores.exists():
            result = json.loads(scores.read_text())
            receipt['operational_pass'] = result['operational_pass']
            receipt['prepared_cases'] = sum(row['status'] == 'PreparedMetadataMeasured' for row in result['cases'])
        else:
            receipt['operational_pass'] = False
    except BaseException as error:
        receipt['errors'].append(dict(type=type(error).__name__, message=str(error)[:1000]))
    finally:
        # Retire only this observed invocation, including a failed/timed-out workload.
        try:
            now = query(plan['unit'])
            assert invocation and now['InvocationID'] == invocation
            receipt['unit_before_stop'] = now
            subprocess.run(['/usr/bin/systemctl', '--user', 'stop', plan['unit']], check=True, timeout=8)
            after = query(plan['unit'])
            if after['LoadState'] != 'not-found':
                assert after['MainPID'] == '0'
                subprocess.run(['/usr/bin/systemctl', '--user', 'reset-failed', plan['unit']], check=True, timeout=3)
                after = query(plan['unit'])
            assert after['LoadState'] == 'not-found' and after['MainPID'] == '0'
            if original_group:
                group = Path('/sys/fs/cgroup')/original_group.lstrip('/')
                assert not group.exists() or all(not p.read_text().split() for p in group.rglob('cgroup.procs'))
            else:
                assert now['MainPID'] == '0' and now['ControlGroup'] == ''
            receipt.update(unit_after_stop=after, original_cgroup=original_group,
                           unit_cgroup_absent_or_empty=True, cleanup_complete=True)
            receipt['environment_after'] = environment(plan)
            verify(plan)
            receipt['frozen_inputs_unchanged'] = True
        except BaseException as error:
            receipt['errors'].append(dict(stage='cleanup_or_final_verification', type=type(error).__name__, message=str(error)[:1000]))
        receipt.update(finished_at_utc=datetime.now(timezone.utc).isoformat(),
                       elapsed_seconds=time.monotonic()-began,
                       within_original_450_seconds=time.monotonic()-began <= 450,
                       qualified=False, further_tests_authorized=False)
        save(BASE/'root-finished-01.json', receipt)
    print(json.dumps({key:receipt.get(key) for key in ('operational_pass', 'cleanup_complete',
        'frozen_inputs_unchanged', 'within_original_450_seconds', 'elapsed_seconds', 'errors', 'prepared_cases')}), flush=True)
    return 0 if (receipt.get('operational_pass') and receipt['cleanup_complete']
                 and receipt.get('frozen_inputs_unchanged') and receipt['within_original_450_seconds'] and not receipt['errors']) else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    if parser.parse_args().run:
        raise SystemExit(run())
    print(json.dumps(dict(status='unarmed_dry', source_opened=False, model_started=False, host_queried=False)))
