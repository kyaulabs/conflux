"""Two fixed admitted MP3s: inspect the installed decoder's EOF contract."""
import ctypes as c
import hashlib
import json
from pathlib import Path
import resource
import time

resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
base = Path(__file__).resolve().parent
plan = json.loads((base / 'music-plan-01.json').read_text())
lib = c.CDLL('/usr/lib/libsndfile.so.1')


class Info(c.Structure):
    _fields_ = [('frames', c.c_int64), ('samplerate', c.c_int), ('channels', c.c_int),
                ('format', c.c_int), ('sections', c.c_int), ('seekable', c.c_int)]


lib.sf_open.argtypes = [c.c_char_p, c.c_int, c.POINTER(Info)]
lib.sf_open.restype = c.c_void_p
lib.sf_readf_float.argtypes = [c.c_void_p, c.POINTER(c.c_float), c.c_int64]
lib.sf_readf_float.restype = c.c_int64
lib.sf_error.argtypes = [c.c_void_p]
lib.sf_error.restype = c.c_int
lib.sf_strerror.argtypes = [c.c_void_p]
lib.sf_strerror.restype = c.c_char_p
lib.sf_close.argtypes = [c.c_void_p]
lib.sf_close.restype = c.c_int
rows = []
for ident in ['013088', '047070']:
    case = next(row for row in plan['cases'] if row['id'] == ident)
    path = Path(case['source']['path'])
    assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == case['source']['sha256']
    info = Info()
    handle = lib.sf_open(str(path).encode(), 0x10, c.byref(info))
    assert handle and info.channels in (1, 2) and 0 < info.frames <= 192000 * 600
    began = time.monotonic()
    buffer = (c.c_float * (65536 * info.channels))()
    count = total = 0
    try:
        while True:
            count = lib.sf_readf_float(handle, buffer, 65536)
            assert 0 <= count <= 65536
            total += count
            assert total <= 192000 * 600
            if count < 65536:
                break
        row = dict(id=ident, declared_frames=info.frames, decoded_frames=total,
                   difference_frames=info.frames-total, samplerate=info.samplerate,
                   channels=info.channels, format=hex(info.format), final_read_frames=count,
                   next_read_frames=lib.sf_readf_float(handle, buffer, 1),
                   error=lib.sf_error(handle), message=lib.sf_strerror(handle).decode(),
                   elapsed_seconds=time.monotonic()-began)
    finally:
        assert lib.sf_close(handle) == 0
    rows.append(row)
result = dict(schema=1, cases=rows, raw_PCM_saved=False, audio_device_opened=False,
              model_started=False, GPU_started=False, latency_qualified=False)
with (base / 'decoder-extent-01.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
