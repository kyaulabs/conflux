"""Fixed-corpus PCM metadata, within one owned CPU-only unit; dry by default."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def run():
    plan = json.loads((BASE / 'music-plan-01.json').read_text())
    assert plan['status'] == 'frozen_offline_correctness_only'
    assert plan['physical_readiness_required'] is False
    assert any(line.endswith('/' + plan['unit']) for line in Path('/proc/self/cgroup').read_text().splitlines())
    output = BASE / 'output-01'
    output.mkdir(mode=0o700)
    began = time.monotonic()
    rows = []
    for case in plan['cases']:
        row = dict(id=case['id'], status='Failed', model_started=False)
        spool = output / ('spool-' + case['id'])
        try:
            if time.monotonic() - began > 345:
                raise TimeoutError('Insufficient time for another bounded native preparation')
            spool.mkdir(mode=0o700)
            first = time.monotonic()
            proc = subprocess.run([plan['binary'], case['id'], str(spool), '--metadata-only'],
                                  capture_output=True, timeout=44)
            row['elapsed_seconds'] = time.monotonic() - first
            assert len(proc.stdout) <= 16384 and len(proc.stderr) <= 16384
            (output / (case['id'] + '.stdout.json')).write_bytes(proc.stdout)
            (output / (case['id'] + '.stderr.log')).write_bytes(proc.stderr)
            assert proc.returncode == 0, 'Native preparation failed: ' + str(proc.returncode)
            value = json.loads(proc.stdout)
            assert value['schema'] == 1 and value['complete'] is True and value['case'] == case['id']
            assert value['source_bytes'] == case['source']['bytes']
            assert value['source_sha256'] == case['source']['sha256']
            assert type(value['prepared_frames']) is int and 0 < value['prepared_frames'] <= 33554432
            assert value['sample_rate'] == 48000 and value['channels'] == 2
            assert value['audio_device_opened'] is False
            digest = value['prepared_pcm_sha256']
            assert type(digest) is str and len(digest) == 64 and all(c in '0123456789abcdef' for c in digest)
            assert not list(spool.iterdir()), 'Anonymous spool was not retired'
            row.update(status='PreparedMetadataMeasured', prepared_frames=value['prepared_frames'],
                       pcm_sha256=digest, source=case['source'])
        except Exception as error:
            row['error'] = dict(type=type(error).__name__, message=str(error)[:1000])
        finally:
            if spool.exists() and not list(spool.iterdir()):
                spool.rmdir()
        rows.append(row)
        save(output / (case['id'] + '.receipt.json'), row)
        print(json.dumps({'id':case['id'], 'status':row['status']}), flush=True)
    result = dict(schema=1, fixed_denominator=24, operational_pass=all(
        row['status'] == 'PreparedMetadataMeasured' for row in rows), cases=rows,
        elapsed_seconds=time.monotonic() - began, audio_device_opened=False,
        model_started=False, GPU_started=False, PCM_persisted=False,
        physical_readiness_consumed=False, musical_or_latency_qualification=False,
        plan_sha256=hashlib.sha256((BASE / 'music-plan-01.json').read_bytes()).hexdigest())
    save(output / 'preparation.json', result)
    return 0 if result['operational_pass'] else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--owned', action='store_true')
    if parser.parse_args().owned:
        raise SystemExit(run())
    print(json.dumps(dict(status='unarmed_dry', source_opened=False, model_started=False, host_queried=False)))
