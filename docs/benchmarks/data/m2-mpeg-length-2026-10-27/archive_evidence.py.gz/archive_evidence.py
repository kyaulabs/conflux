"""Retain small text evidence, never corpus audio, PCM or compiled objects."""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
WORK = Path('/home/kyau/.codex/worktrees/release-tree-guard/conflux')
BASE = ROOT/'build/m2-mpeg-length-01'
FMAK = ROOT/'build/m2-fmak-assessment-01'
DEST = WORK/'docs/benchmarks/data/m2-mpeg-length-2026-10-27'
STAGE = BASE/'uncompressed-review-01'
items = [(BASE/name, name) for name in [
    'configure-01.log', 'build-red-01.log', 'build-green-01.log',
    'regression-red-01.json', 'regression-red-01.log',
    'focused-green-01.json', 'focused-green-01.log',
    'real-mp3-plan-01.json', 'real-mp3-result-01.json',
    'real-mp3-stdout-01.json', 'real-mp3-stderr-01.log',
    'probe-configure-01.log', 'probe-build-01.log']]
items += [(BASE/'native-probe/CMakeLists.txt', 'probe-CMakeLists.txt')]
items += [(FMAK/'preparation-01'/name, 'preparation-'+name) for name in [
    'music-plan-01.json', 'offline-verification-01.json', 'root-finished-01.json',
    'operator-stop-01.json', 'operator-close-verification-01.json',
    'decoder-extent-01.json', 'check_decoder_extent.py', 'prepare_source.cpp',
    'sources.hpp', 'prepare_cases.py', 'run_once.py']]
items += [(FMAK/'source-admission-01'/name, name) for name in [
    'selection-plan-02.json', 'selection-correction-01.json',
    'media-admission-01.json', 'source-verification-01.json']]
for file in sorted((FMAK/'preparation-01/output-01').glob('*')):
    if file.is_file() and file.suffix in ('.json', '.log'):
        items.append((file, 'case-'+file.name))
items.append((BASE/'archive_evidence.py', 'archive_evidence.py'))
DEST.mkdir(parents=True, exist_ok=False)
STAGE.mkdir(mode=0o700)
rows = []
for source, name in items:
    raw = source.read_bytes()
    raw.decode('utf-8')
    if name.endswith('.json') and raw.strip():
        json.loads(raw)
    packed = gzip.compress(raw, mtime=0)
    (STAGE/name).write_bytes(raw)
    (DEST/(name+'.gz')).write_bytes(packed)
    rows.append(dict(file=name+'.gz', bytes=len(packed), SHA256=hashlib.sha256(packed).hexdigest(),
                     expanded_bytes=len(raw), expanded_SHA256=hashlib.sha256(raw).hexdigest()))
product = []
for name in ['CMakeLists.txt', 'src/audio/AudioFile.cpp', 'tests/audio_file_mpeg_length_test.cpp']:
    content = (WORK/name).read_bytes()
    product.append(dict(path=name, bytes=len(content), SHA256=hashlib.sha256(content).hexdigest()))
manifest = dict(schema=1, scope='Offline MPEG clean-EOF regression and stopped FMAK preparation',
    source_files=product, artifacts=rows, audio_or_PCM_or_models_or_binaries_included=False,
    failed_first_attempt_preserved=True, musical_or_latency_qualified=False)
(DEST/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(artifacts=len(rows), compressed_bytes=sum(row['bytes'] for row in rows),
                     manifest=str(DEST/'manifest.json'))))
