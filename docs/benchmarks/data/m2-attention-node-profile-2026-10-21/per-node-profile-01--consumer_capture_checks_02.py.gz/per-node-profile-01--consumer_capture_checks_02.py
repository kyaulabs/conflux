"""Prepared CPU-only checks: saved JSON, synthetic streams/tempfiles; no native/host probes."""
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import subprocess
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

BASE=Path(__file__).resolve().parent
ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
sys.path.insert(0,str(ROOT))
sys.dont_write_bytecode=True

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module

driver=load('attention_driver_checks',BASE/'run_attention_pcm_retry02.py')
capture=load('attention_capture_checks',BASE/'native_capture.py')
cache=load('attention_cache_checks',BASE/'cache_support_retry02.py')


class ConsumerChecks(unittest.TestCase):
    def plan(self):
        return json.loads((BASE/'diagnostic-plan-DRAFT-02.json').read_text())
    def human(self,now=1000,age=10):
        return {'age_seconds':age,'sampled_monotonic':now,'record':{'recorded_at_utc':'2026-10-21T00:00:00+00:00'},
                'pin':{'path':'/tmp/human.json','bytes':10,'sha256':'1'*64}}
    def test_actual_saved_build_admission_schema(self):
        p=self.plan();b=driver.validate_build(p)
        self.assertTrue(b['current_dependency_closure']['complete'])
        self.assertEqual(b['historical_header_equivalence'],'unproved')
        self.assertNotEqual(p['runtimes']['baseline']['sha256'],p['runtimes']['packed']['sha256'])
    def test_build_rejects_mutated_closure_artifact_or_historical_claim(self):
        p=self.plan();b=driver.validate_build(p)
        for field in ('closure','artifact','historical','archive','command'):
            with self.subTest(field=field):
                bad=copy.deepcopy(b)
                if field=='closure':bad['current_dependency_closure']['after'][0]['sha256']='0'*64
                if field=='artifact':bad['artifacts']['packed_runtime']['sha256']='0'*64
                if field=='historical':bad['historical_header_equivalence']='proved'
                if field=='archive':bad['archive_payload_proof']['replaced_members'].append('shader.o')
                if field=='command':bad['commands'][0]['exit_code']=1
                with patch.object(driver,'read_json',return_value=(bad,{})),self.assertRaises(ValueError):driver.validate_build(p)
    def test_no_plan_and_no_human_fail_before_helper_import(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            with (patch.object(driver,'PLAN',root/'missing.json'),patch.object(driver,'load_player') as imported,
                  patch.object(sys,'argv',['driver','--run','--arm','baseline'])):
                with self.assertRaises(FileNotFoundError):driver.main()
                imported.assert_not_called()
            p=self.plan();p['status']='frozen_pending_fresh_attention_pair_readiness'
            p['review']={**p['source_pins']['source_receipt'],'status':'passed'}
            target=root/'plan.json';target.write_text(json.dumps(p))
            with (patch.object(driver,'PLAN',target),patch.object(driver,'HUMAN',root/'no-human.json'),
                  patch.object(driver,'load_player') as imported,patch.object(sys,'argv',['driver','--run','--arm','baseline'])):
                with self.assertRaises(FileNotFoundError):driver.main()
                imported.assert_not_called()
    def test_draft_refuses_to_load_and_dry_does_not_read(self):
        with patch.object(driver,'PLAN',BASE/'diagnostic-plan-DRAFT-02.json'),self.assertRaises(ValueError):
            driver.load_plan(BASE/'diagnostic-plan-DRAFT-02.json')
        with patch.object(driver,'load_plan',side_effect=AssertionError('dry read')),patch.object(sys,'argv',['driver']),patch('sys.stdout',io.StringIO()) as out:
            self.assertEqual(driver.main(),0)
            self.assertFalse(json.loads(out.getvalue())['host_queried'])
    def test_fixed_input_only_and_no_duplicate_case(self):
        row={'id':driver.CASE,'input_sha256':driver.INPUT_SHA,'shape':[343980,2],'dtype':'<f4','valid_frames':343980}
        self.assertEqual(list(driver.select_fixed_case([{'id':'other'},row])),[driver.CASE])
        for rows in ([row,row],[],[{**row,'input_sha256':'0'*64}],[{**row,'valid_frames':86000}]):
            with self.assertRaises(ValueError):driver.select_fixed_case(rows)
    def test_original_pair_budget_no_reset_or_partial_second_arm(self):
        h=self.human();planpin={'path':'/tmp/p','bytes':1,'sha256':'2'*64}
        b=driver.operator_budget(h,1000,1000,arm='baseline',boot_id='boot',plan_pin=planpin)
        self.assertEqual((b['operator_deadline_monotonic'],b['phase_deadline_monotonic']),(1590,1300))
        prior={'status':'passed','cleanup_complete':True,'pins_unchanged':True,'within_wall_budget':True,'errors':[],
            'arm':'baseline','boot_id':'boot','plan_pin':planpin,'human_pin':h['pin'],'operator_budget':b,
            'capture':{'complete':True},'attention':{'passed':True},'native_trace':{'passed':True},
            'native_shutdown':{'graceful_complete':True},'guard_before':{'pid':4},'guard_after':{'pid':4}}
        # Wall clock moved back: the original monotonic anchor still wins.
        with patch.object(driver,'read_json',return_value=(prior,{'sha256':'3'*64})):
            second=driver.operator_budget(self.human(1100,0),1100,1100,arm='packed',boot_id='boot',plan_pin=planpin)
            self.assertEqual(second['operator_deadline_monotonic'],1590)
            with self.assertRaises(ValueError):driver.operator_budget(self.human(1300,0),1300,1300,arm='packed',boot_id='boot',plan_pin=planpin)
            with self.assertRaises(ValueError):driver.operator_budget(self.human(1100,0),1100,1100,arm='packed',boot_id='different',plan_pin=planpin)
            prior['capture']['complete']=False
            with self.assertRaises(ValueError):driver.operator_budget(self.human(1100,0),1100,1100,arm='packed',boot_id='boot',plan_pin=planpin)
    def test_stdout_requires_exact_two_matching_events(self):
        ready={'event':'ready','pid':22,'process_environment':{'OMP_WAIT_POLICY':'PASSIVE'}}
        metric={'event':'result','id':1,'frames':343980}
        raw=(json.dumps({k:v for k,v in ready.items() if k!='process_environment'})+'\n'+json.dumps(metric)+'\n').encode()
        self.assertTrue(driver.validate_stdout(raw,ready,metric)['passed'])
        for bad in (raw[:-1],raw+b'{}\n',raw.replace(b'"id": 1',b'"id": 2')):
            with self.assertRaises(ValueError):driver.validate_stdout(bad,ready,metric)
    def test_new_cache_paths_and_inherited_environment_preserved(self):
        parent=cache.capture_cache_parent()
        self.assertEqual(parent['path'],str(BASE));self.assertEqual(parent['mode'],0o700)
        self.assertEqual(set(cache.PHASE_CACHES),{'baseline','packed'})
        self.assertEqual(cache.SEED_PARENT,ROOT/'benchmarks-local/background-player-01/request-trace-candidate/cache-pair')
        for arm in driver.ARMS:
            env=cache.cache_environment({'KEEP':'literal'},arm)
            self.assertEqual(env['KEEP'],'literal');self.assertEqual(env['MESA_SHADER_CACHE_DIR'],str(BASE/('driver-cache-'+arm+'-02')))
        self.assertNotEqual(cache.PHASE_CACHES['baseline'],cache.PHASE_CACHES['packed'])
        with self.assertRaises(ValueError):cache.cache_environment({},'pcm')
        with self.assertRaises(ValueError):cache.cache_environment({'MESA_SHADER_CACHE_DIR':'/tmp/old'},'baseline')
    def test_retention_failure_cannot_skip_original_owned_cleanup(self):
        previous=Mock()
        original=SimpleNamespace(save_stderr=previous,cleanup_native=Mock(return_value=({'native_reaped':True},None,[])))
        native=SimpleNamespace(process=SimpleNamespace(poll=lambda:0))
        with patch.object(driver,'retain_captures',side_effect=OSError('synthetic retention disk failure')):
            cleanup,_stderr,errors,_pins=driver.cleanup_captured(native,True,Path('/unused'),original,time.monotonic()+10,{})
        original.cleanup_native.assert_called_once_with(native,True,Path('/unused'))
        self.assertIs(original.save_stderr,previous);self.assertTrue(cleanup['native_reaped'])
        self.assertEqual(errors[0]['phase'],'capture_retention')


class Pipe:
    def __init__(self,fd):self.fd=fd
    def fileno(self):return self.fd
class Selector:
    def __init__(self,pipes):self.rows={p:SimpleNamespace(fileobj=p) for p in pipes}
    def unregister(self,p):del self.rows[p]
    def get_map(self):return self.rows
    def select(self,_timeout):return [(key,None) for key in list(self.rows.values())]
class FailedSink:
    closed=False
    def write(self,_):raise OSError('synthetic full disk')
    def flush(self):pass


class CaptureChecks(unittest.TestCase):
    def make(self):
        n=capture.CapturedNativeRuntime.__new__(capture.CapturedNativeRuntime)
        n.process=SimpleNamespace(stderr=Pipe(10),stdout=Pipe(11),poll=lambda:0)
        n.selector=Selector((n.process.stderr,n.process.stdout));n._stderr_tail=bytearray();n.buffer=bytearray();n.timeout=.001
        n.capture={k:0 for k in ('stderr_received','stderr_written','stdout_received','stdout_written','read_errors','write_errors')}
        n.capture.update(stderr_eof=False,stdout_eof=False,overflow=False,first_error='')
        n.stderr=io.BytesIO();n.stdout_capture=io.BytesIO();n.abort=Mock()
        return n
    def drain(self,n,stderr,stdout=b'{}\n'):
        data={10:bytearray(stderr),11:bytearray(stdout)}
        def read(fd,size):
            out=bytes(data[fd][:size]);del data[fd][:size];return out
        with patch.object(capture.os,'read',side_effect=read):return n.finish_capture(time.monotonic()+5)
    def test_exact_hard_stderr_limit_complete_and_tail_bounded(self):
        self.assertEqual(capture.STDERR_LIMIT,8388608)
        n=self.make();r=self.drain(n,b'x'*capture.STDERR_LIMIT)
        self.assertTrue(r['complete']);self.assertEqual(r['stderr_written'],capture.STDERR_LIMIT)
        self.assertEqual(len(n._stderr_tail),65536)
    def test_overflow_is_capped_but_every_byte_drained(self):
        n=self.make();r=self.drain(n,b'x'*(capture.STDERR_LIMIT+1))
        self.assertFalse(r['complete']);self.assertTrue(r['overflow']);self.assertTrue(r['stderr_eof'])
        self.assertEqual((r['stderr_received'],r['stderr_written']),(capture.STDERR_LIMIT+1,capture.STDERR_LIMIT))
    def test_write_failure_still_drains_both_streams(self):
        n=self.make();n.stderr=FailedSink();r=self.drain(n,b'bad disk'*1024)
        self.assertFalse(r['complete']);self.assertGreater(r['write_errors'],0)
        self.assertTrue(r['stderr_eof'] and r['stdout_eof']);self.assertEqual(r['stderr_written'],0)
    def test_late_flush_error_invalidates_previously_complete_capture(self):
        n=self.make();self.assertTrue(self.drain(n,b'complete')['complete'])
        n.stderr=FailedSink()
        with patch.object(n.stderr,'flush',side_effect=OSError('late flush')):n._flush_diagnostics()
        self.assertFalse(n.capture_status()['complete']);self.assertEqual(n.capture['write_errors'],1)
    def test_read_failure_and_unfinished_eof_cannot_pass(self):
        n=self.make()
        with patch.object(capture.os,'read',side_effect=OSError('synthetic read')):
            r=n.finish_capture(time.monotonic()+1)
        self.assertFalse(r['complete']);self.assertEqual(r['read_errors'],2)
        n=self.make();r=n.finish_capture(time.monotonic()-1)
        self.assertFalse(r['complete']);self.assertFalse(r['stderr_eof'])
    def test_stdout_overflow_fails_and_running_process_not_completed(self):
        n=self.make();r=self.drain(n,b'',b'x'*(capture.STDOUT_LIMIT+1))
        self.assertFalse(r['complete']);self.assertEqual(r['stdout_written'],capture.STDOUT_LIMIT)
        n=self.make();n.process.poll=lambda:None
        with self.assertRaises(RuntimeError):n.finish_capture(time.monotonic()+1)
    def test_request_timeout_aborts_without_renewing_deadline(self):
        n=self.make();n.selector.select=lambda _timeout:[]
        with self.assertRaises(TimeoutError):n._receive_bounded()
        n.abort.assert_called_once()
    def test_actual_capture_constructor_normal_tiny_CPU_child_reap_and_spool_cleanup(self):
        real_popen=subprocess.Popen
        expected_env={'MESA_SHADER_CACHE_DIR':str(BASE/'driver-cache-baseline-02'),'MESA_SHADER_CACHE_MAX_SIZE':'128M',
            'GGML_VK_PERF_LOGGER':'1','GGML_VK_PERF_LOGGER_FREQUENCY':'1','OMP_WAIT_POLICY':'PASSIVE','GOMP_SPINCOUNT':'0','KEEP':'literal'}
        script="import json,sys,os; print(json.dumps({'event':'ready','sample_rate':44100,'channels':2,'segment_frames':343980,'stems':['drums','bass','other','vocals'],'fixture_environment':{k:os.environ.get(k) for k in "+repr(list(expected_env))+"}}),flush=True);sys.stdin.readline();sys.stderr.buffer.write(b'x'*262144);sys.stderr.flush()"
        def launch(argv,**kwargs):
            self.assertEqual(argv,['/fixed/native','--model','/fixed/model','--backend','vulkan','--threads','2'])
            self.assertTrue(kwargs['start_new_session'])
            self.assertEqual({k:kwargs['env'].get(k) for k in expected_env},expected_env)
            return real_popen([sys.executable,'-I','-B','-c',script],**kwargs)
        environment=cache.cache_environment({'KEEP':'literal','GGML_VK_PERF_LOGGER':'1','GGML_VK_PERF_LOGGER_FREQUENCY':'1'},'baseline')
        with (tempfile.TemporaryDirectory() as temp,patch.object(capture.subprocess,'Popen',side_effect=launch),
              patch.dict(os.environ,environment,clear=True)):
            n=capture.CapturedNativeRuntime('/fixed/native','/fixed/model','vulkan',2,2,spool_directory=Path(temp)/'spool')
            try:
                ready=n.start();self.assertEqual(ready['event'],'ready')
                self.assertEqual(ready['fixture_environment'],expected_env)
                result=n.idle_quit(completed_idle=True,deadline=time.monotonic()+2)
                self.assertTrue(result['graceful_complete']);self.assertFalse(result['killed'])
                evidence=n.finish_capture(time.monotonic()+2)
                self.assertTrue(evidence['complete']);self.assertEqual(evidence['stderr_received'],262144)
            finally:n.close()
            self.assertFalse(n.root.exists())
    def test_idle_quit_timeout_is_failed_killed_and_reaped(self):
        real_popen=subprocess.Popen
        script="import json,time;print(json.dumps({'event':'ready','sample_rate':44100,'channels':2,'segment_frames':343980,'stems':['drums','bass','other','vocals']}),flush=True);time.sleep(10)"
        def launch(_argv,**kwargs):return real_popen([sys.executable,'-I','-B','-c',script],**kwargs)
        with tempfile.TemporaryDirectory() as temp,patch.object(capture.subprocess,'Popen',side_effect=launch):
            n=capture.CapturedNativeRuntime('/fixed/native','/fixed/model','vulkan',2,2,spool_directory=Path(temp)/'spool')
            try:
                n.start();deadline=time.monotonic()+.5
                result=n.idle_quit(completed_idle=True,deadline=deadline)
                self.assertFalse(result['graceful_complete']);self.assertTrue(result['killed'])
                self.assertTrue(result['process_reaped']);self.assertTrue(result['within_same_shutdown_budget'])
            finally:n.close()
            self.assertFalse(n.root.exists())
    def test_actual_capture_timeout_tiny_CPU_child_reaped_before_spool_cleanup(self):
        real_popen=subprocess.Popen
        def launch(_argv,**kwargs):return real_popen([sys.executable,'-I','-B','-c','import time;time.sleep(10)'],**kwargs)
        with tempfile.TemporaryDirectory() as temp,patch.object(capture.subprocess,'Popen',side_effect=launch):
            n=capture.CapturedNativeRuntime('/fixed/native','/fixed/model','vulkan',2,.01,spool_directory=Path(temp)/'spool')
            try:
                with self.assertRaises(TimeoutError):n.start()
                n.process.wait(timeout=2)
                self.assertTrue(n.finish_capture(time.monotonic()+2)['complete'])
            finally:n.close()
            self.assertFalse(n.root.exists())


if __name__=='__main__':unittest.main(verbosity=2)
