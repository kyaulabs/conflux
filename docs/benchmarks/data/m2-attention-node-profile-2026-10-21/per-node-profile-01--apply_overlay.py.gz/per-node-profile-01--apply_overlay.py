#!/usr/bin/env python3
"""Pure source transform; its optional CLI writes only a new exclusive output."""
from pathlib import Path
import hashlib
import sys

SOURCE_SHA256 = "e36ece6d9bd1219085c77e58e6f624da19c349fc1dd214469367d8824501f996"
FIELD = "    int32_t query_idx {};\n"
NEW_FIELD = FIELD + "    uint64_t attention_trace_sequence {}; // Private post-query metadata only.\n"
ANCHOR = """                ctx->perf_logger->log_timing(node, name, uint64_t((timestamps[i] - timestamps[i-1]) * ctx->device->properties.limits.timestampPeriod));
            }
        } else {
            // Log each group of nodes
"""


def apply(source, snippet):
    if hashlib.sha256(source).hexdigest() != SOURCE_SHA256:
        raise ValueError("frozen Vulkan source SHA256 mismatch")
    original = source.decode("utf-8")
    if original.count(FIELD) != 1 or original.count(ANCHOR) != 1:
        raise ValueError("expected exactly one field and post-query anchor")
    insertion = ANCHOR.replace("        } else {", snippet + "        } else {", 1)
    changed = original.replace(FIELD, NEW_FIELD, 1).replace(ANCHOR, insertion, 1)
    if changed.replace(insertion, ANCHOR, 1).replace(NEW_FIELD, FIELD, 1) != original:
        raise ValueError("source reverse check failed")
    return changed.encode("utf-8")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: apply_overlay.py FROZEN_CPP NEW_OUTPUT_CPP")
    changed = apply(Path(sys.argv[1]).read_bytes(), Path(__file__).with_name("attention_trace.inc").read_text())
    with Path(sys.argv[2]).open("xb") as output:
        output.write(changed)
    print(hashlib.sha256(changed).hexdigest())
