"""Prepared CPU-only tests of the actual private attention metadata parser."""
import hashlib
import importlib.util
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PARSER = HERE / "parse_attention.py"
PARSER_SHA = "e2f420e4da5c2edbbbc65edb8e14fd1b35d7a4a55e5b1b3ca0f456cb96b596fa"
PREFIX = "conflux_vk_attention_v1"
SIGNATURES = ((1344, 1344),) * 3 + ((2688, 2688),) * 3 + ((1344, 2688),) * 2 + ((2688, 1344),) * 2
QUERY_IDS = tuple(2 + 4 * n for n in range(40))
ROLES = ("q", "k", "v", "flash")
SELF_PACKED = {"q": (6144, 0), "k": (6144, 2048), "v": (6144, 4096)}
CROSS_PACKED = {"q": (2048, 0), "k": (4096, 0), "v": (4096, 2048)}
UINT64_MAX = (1 << 64) - 1


def full_graph(packed, seq=1, signatures=SIGNATURES):
    """Independent semantic fixture: ten declared groups and 128 slow rest queries.

    IDs, signatures and duration oracles are fixture inputs, not discoveries
    obtained by running/reimplementing the selector or parser.
    """
    rows = [("begin", dict(seq=str(seq), status="complete", reason="none", graph_nodes="512", queries="168",
        flash_count="10", selected="40", total_ns="128000004780", head_cont_ns="3570", flash_ns="1210", rest_ns="128000000000"))]
    for slot, (qlen, kvlen) in enumerate(signatures):
        for role_index, role in enumerate(ROLES):
            item = slot * 4 + role_index
            length = qlen if role == "q" else kvlen
            row = dict(seq=str(seq), item=str(item + 1), query=str(QUERY_IDS[item]), graph=str(400 + item),
                       flash=str(slot + 1), role=role, duration_ns=str(100 + item),
                       dst=f"64,8,{qlen},1" if role == "flash" else f"64,{length},8,1")
            if role != "flash":
                if not packed:
                    stride, offset, root = 2048, 0, 200 + slot * 3 + role_index
                else:
                    stride, offset = (SELF_PACKED if qlen == kvlen else CROSS_PACKED)[role]
                    root = 300 + slot * 2 + (1 if qlen != kvlen and role in ("k", "v") else 0)
                row.update(source_graph=str(80 + slot * 3 + role_index), root_graph=str(root),
                           source_nb=f"4,{stride},256,{stride * length}", source_view_offs=str(offset))
            rows.append(("target", row))
    rows.append(("end", dict(seq=str(seq), records="40", complete="1")))
    return rows


def startup(seq=1, timed=False):
    total = "12345" if timed else "0"
    return [("begin", dict(seq=str(seq), status="not_target_graph", reason="none", graph_nodes="4", queries="2" if timed else "0",
        flash_count="0", selected="0", total_ns=total, head_cont_ns="0", flash_ns="0", rest_ns=total)),
        ("end", dict(seq=str(seq), records="0", complete="1"))]


def wire(rows, *, prefix=PREFIX):
    return ("\n".join(prefix + " " + kind + " " + " ".join(key + "=" + str(value) for key, value in row.items())
                      for kind, row in rows) + "\n").encode("ascii")


def totals(rows):
    # Mutations may keep all accounting consistent to isolate a different gate.
    head = sum(int(row["duration_ns"]) for kind, row in rows if kind == "target" and row["role"] != "flash")
    flash = sum(int(row["duration_ns"]) for kind, row in rows if kind == "target" and row["role"] == "flash")
    begin = rows[0][1]
    begin.update(head_cont_ns=str(head), flash_ns=str(flash), total_ns=str(head + flash + int(begin["rest_ns"])))


class ParserChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw = PARSER.read_bytes()
        if not (0 < len(raw) <= 65536 and hashlib.sha256(raw).hexdigest() == PARSER_SHA):
            raise RuntimeError("Exact reviewed parser source differs")
        spec = importlib.util.spec_from_file_location("attention_parser_cpu_fixture", PARSER)
        module = importlib.util.module_from_spec(spec)
        exec(compile(raw, str(PARSER), "exec"), module.__dict__)
        cls.parse = staticmethod(module.parse_attention_output)

    def rejected(self, rows, packed, message=None):
        with self.assertRaisesRegex(ValueError, message or "."):
            self.parse(wire(rows), packed=packed)

    def test_exact_baseline_and_packed_semantic_rows_and_slow_rest(self):
        for packed in (False, True):
            with self.subTest(packed=packed):
                declared = full_graph(packed)
                data = b"ggml_vulkan: ordinary unrelated diagnostic\n" + wire(declared) + b"trailing unrelated diagnostic\n"
                result = self.parse(data, packed=packed)
                self.assertTrue(result["passed"])
                self.assertIs(result["qualified"], False)
                self.assertEqual(result["startup_graphs"], 0)
                full = result["full_model"]
                self.assertEqual((full["head_cont_ns"], full["flash_ns"], full["rest_ns"], full["total_ns"]),
                                 (3570, 1210, 128000000000, 128000004780))
                self.assertEqual((full["queries"], full["graph_nodes"], len(full["targets"])), (168, 512, 40))
                self.assertEqual(tuple(row["query"] for row in full["targets"]), QUERY_IDS)
                self.assertEqual([row["role"] for row in full["targets"]], list(ROLES) * 10)
                for parsed, (_, expected) in zip(full["targets"], declared[1:-1], strict=True):
                    self.assertEqual(set(parsed), set(expected))
                    for key, value in expected.items():
                        self.assertEqual(parsed[key], value if key == "role" else
                                         tuple(map(int, value.split(","))) if key in ("dst", "source_nb") else int(value))

    def test_startup_zero_and_timed_graphs_are_not_full_models(self):
        for packed in (False, True):
            rows = startup(1) + startup(2, timed=True) + full_graph(packed, 3)
            result = self.parse(wire(rows), packed=packed)
            self.assertEqual(result["startup_graphs"], 2)
            self.assertEqual([g["seq"] for g in result["graphs"]], [1, 2, 3])
            self.assertEqual(result["graphs"][0]["total_ns"], 0)
            self.assertEqual(result["graphs"][1]["rest_ns"], 12345)
            self.assertEqual(result["full_model"]["seq"], 3)
        self.rejected(startup(), False)

    def test_exact_uint64_totals_and_individual_zero_interval(self):
        for rest in ((1 << 53) + 12345, UINT64_MAX - 4780):
            rows = full_graph(True); rows[0][1]["rest_ns"] = str(rest); totals(rows)
            full = self.parse(wire(rows), packed=True)["full_model"]
            self.assertEqual(full["rest_ns"], rest)
            self.assertEqual(full["total_ns"], rest + 4780)
        rows = full_graph(False); rows[1][1]["duration_ns"] = "0"; totals(rows)
        self.assertEqual(self.parse(wire(rows), packed=False)["full_model"]["targets"][0]["duration_ns"], 0)

    def test_truncated_envelopes_missing_newline_and_unknown_versions_fail(self):
        data = wire(full_graph(False))
        for changed in (data[:-1], data[:len(data) // 2], wire(full_graph(False)[:-1]), b"", b"noise only\n"):
            with self.subTest(changed_bytes=len(changed)), self.assertRaises(ValueError):
                self.parse(changed, packed=False)
        for prefix in ("conflux_vk_attention_v2", "conflux_vk_attention_v10", "conflux_vk_attention_v1bad"):
            with self.subTest(prefix=prefix), self.assertRaises(ValueError):
                self.parse(wire(startup(), prefix=prefix) + data, packed=False)

    def test_duplicate_unknown_missing_fields_and_roles_fail(self):
        data = wire(full_graph(False))
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            self.parse(data.replace(b"item=1 ", b"item=1 item=1 ", 1), packed=False)
        mutations = [lambda rows: rows[1][1].update(extra="1"),
                     lambda rows: rows[1][1].pop("source_nb"),
                     lambda rows: rows[1][1].update(role="unknown"),
                     lambda rows: rows[3][1].update(role="k"),
                     lambda rows: rows[0][1].update(selected="39"),
                     lambda rows: rows[0][1].update(flash_count="9"),
                     lambda rows: rows[-1][1].update(records="39"),
                     lambda rows: rows[-1][1].update(complete="0")]
        for number, mutate in enumerate(mutations):
            rows = full_graph(False); mutate(rows)
            with self.subTest(mutation=number): self.rejected(rows, False)

    def test_query_graph_source_and_sequence_bindings_fail_closed(self):
        mutations = [lambda rows: rows[2][1].update(query=rows[1][1]["query"]),
                     lambda rows: rows[2][1].update(query="1"),
                     lambda rows: rows[1][1].update(query="169"),
                     lambda rows: rows[2][1].update(graph=rows[1][1]["graph"]),
                     lambda rows: rows[1][1].update(graph="512"),
                     lambda rows: rows[1][1].update(source_graph="512"),
                     lambda rows: rows[1][1].update(root_graph="512"),
                     lambda rows: rows[1][1].update(flash="11"),
                     lambda rows: rows[1][1].update(item="2"),
                     lambda rows: rows[1][1].update(seq="2"),
                     lambda rows: rows[-1][1].update(seq="2"),
                     lambda rows: rows[0][1].update(queries="513")]
        for number, mutate in enumerate(mutations):
            rows = full_graph(True); mutate(rows)
            with self.subTest(mutation=number): self.rejected(rows, True)

    def test_variant_layout_offsets_and_root_sharing_are_exact(self):
        for packed in (False, True):
            mutations = [lambda rows: rows[1][1].update(source_nb="4,2048,256,1"),
                         lambda rows: rows[1][1].update(source_view_offs="1"),
                         lambda rows: rows[1][1].update(dst="63,1344,8,1"),
                         lambda rows: rows[3][1].update(dst="64,2688,8,1")]
            for number, mutate in enumerate(mutations):
                rows = full_graph(packed); mutate(rows)
                with self.subTest(packed=packed, mutation=number): self.rejected(rows, packed)
            with self.subTest(wrong_variant=packed), self.assertRaises(ValueError):
                self.parse(wire(full_graph(packed)), packed=not packed)
        rows = full_graph(False); rows[2][1]["root_graph"] = rows[1][1]["root_graph"]; self.rejected(rows, False)
        rows = full_graph(True); rows[3][1]["root_graph"] = "399"; self.rejected(rows, True)
        # Group 7 is cross1344->2688: K/V share one root; Q must use another.
        rows = full_graph(True); rows[27][1]["root_graph"] = "399"; self.rejected(rows, True)
        rows = full_graph(True); rows[25][1]["root_graph"] = rows[26][1]["root_graph"]; self.rejected(rows, True)
        # This replacement is internally well-formed; only the fixed distribution
        # changes from3+3+2+2 to2+4+2+2, so it exercises that final signature gate.
        signatures = ((2688, 2688),) + SIGNATURES[1:]
        self.rejected(full_graph(True, signatures=signatures), True)

    def test_unsigned_range_zero_aggregates_and_accounting_failures(self):
        for field, value in (("duration_ns", "-1"), ("duration_ns", "01"),
                             ("duration_ns", str(UINT64_MAX + 1)), ("query", "0")):
            rows = full_graph(False); rows[1][1][field] = value
            with self.subTest(field=field, value=value): self.rejected(rows, False)
        for field in ("total_ns", "head_cont_ns", "flash_ns", "rest_ns"):
            rows = full_graph(True); rows[0][1][field] = str(UINT64_MAX + 1)
            with self.subTest(overflow=field): self.rejected(rows, True)
        for field in ("total_ns", "head_cont_ns", "flash_ns", "rest_ns"):
            rows = full_graph(False); rows[0][1][field] = str(int(rows[0][1][field]) + 1)
            with self.subTest(inconsistent=field): self.rejected(rows, False)
        rows = full_graph(False)
        rows[0][1]["head_cont_ns"] = str(UINT64_MAX)
        rows[0][1]["total_ns"] = str((UINT64_MAX + 1210 + 128000000000) & UINT64_MAX)
        self.rejected(rows, False, "Group/rest")  # Individually valid uint64 fields must not sum with wraparound.
        for category in ("all", "heads", "flashes"):
            rows = full_graph(True)
            for kind, row in rows:
                if kind == "target" and (category == "all" or (row["role"] == "flash") == (category == "flashes")):
                    row["duration_ns"] = "0"
            if category == "all": rows[0][1]["rest_ns"] = "0"
            totals(rows)
            with self.subTest(zero=category): self.rejected(rows, True)
        rows = full_graph(False); rows[1][1]["duration_ns"] = "101"  # Still internally unsigned, selected total now wrong.
        self.rejected(rows, False)

    def test_extra_full_graphs_startup_and_unsupported_status_are_not_repaired(self):
        self.rejected(full_graph(False) + full_graph(False, 2), False, "Exactly one")
        self.rejected(full_graph(True) + startup(3), True, "sequence")
        rows = full_graph(False); rows[0][1].update(status="unsupported", reason="missing_target_query")
        self.rejected(rows, False)
        rows = startup() + full_graph(False, 2); rows[0][1].update(head_cont_ns="1", total_ns="1")
        self.rejected(rows, False)
        with self.assertRaises(ValueError): self.parse(wire(full_graph(False)), packed=1)
        with self.assertRaises(ValueError): self.parse(bytearray(wire(full_graph(False))), packed=False)

    def test_byte_line_row_and_graph_caps_reject_early(self):
        data = wire(full_graph(False))
        with self.assertRaisesRegex(ValueError, "Bounded bytes"):
            self.parse(data + b"x" * (8 * 1024 * 1024 - len(data) + 1), packed=False)
        first, remainder = data.split(b"\n", 1)
        with self.assertRaisesRegex(ValueError, "line exceeds bound"):
            self.parse(first + b" filler=" + b"x" * 1024 + b"\n" + remainder, packed=False)
        # Each graph is individually valid; these trigger the resource gate
        # before the eventual exactly-one-full-graph verdict at EOF.
        with self.assertRaisesRegex(ValueError, "Too many metadata rows"):
            self.parse(b"".join(wire(full_graph(False, seq)) for seq in range(1, 99)), packed=False)
        with self.assertRaisesRegex(ValueError, "too many metadata graphs"):
            self.parse(b"".join(wire(startup(seq)) for seq in range(1, 257)) + wire(full_graph(False, 257)), packed=False)


if __name__ == "__main__":
    unittest.main()
