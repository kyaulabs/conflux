"""One private CPU build; never invoke a native runtime or model."""
import datetime
import hashlib
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import time

P = Path(__file__).resolve().parent
RECIPE_SHA = "6bff4af758310a023188bc3628a2c2386659556327f84e53de5954a33669632a"


def pin(path):
    path = Path(path)
    before = path.stat()
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return {"path": str(path), "canonical_path": str(path.resolve(strict=True)),
            "bytes": after.st_size, "sha256": digest.hexdigest()}


def verify(row):
    actual = pin(row["path"])
    assert all(actual[k] == row[k] for k in ("bytes", "sha256")), row["path"]
    return actual


def dependencies(path):
    text = path.read_text().replace("\\\n", "")
    return sorted({str(Path(s).resolve(strict=True)) for s in shlex.split(text.split(":", 1)[1])})


def members(path):
    data = path.read_bytes()
    assert data.startswith(b"!<arch>\n")
    position, names, result = 8, b"", []
    while position < len(data):
        header = data[position:position + 60]
        assert len(header) == 60 and header[58:] == b"`\n"
        name, size = header[:16].decode("ascii").strip(), int(header[48:58])
        payload = memoryview(data)[position + 60:position + 60 + size]
        assert len(payload) == size
        if name == "//":
            names = bytes(payload)
        elif name not in ("/", "/SYM64/"):
            if name.startswith("/"):
                offset = int(name[1:]); name = names[offset:names.index(b"/\n", offset)].decode()
            else:
                assert not name.startswith("#1/")
                name = name.removesuffix("/")
            result.append({"name": name, "bytes": size, "sha256": hashlib.sha256(payload).hexdigest()})
        position += 60 + size + size % 2
    assert position == len(data)
    return result


def main():
    recipe_pin = pin(P / "build_recipe.json")
    assert recipe_pin["sha256"] == RECIPE_SHA
    recipe = json.loads((P / "build_recipe.json").read_bytes())
    assert shutil.disk_usage(P).free > 512 * 1024 ** 2
    assert not (P / "root-build-receipt-01.json").exists()
    proof = {"schema": 1, "passed": False, "started_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
             "recipe_pin": recipe_pin, "physical_execution": False, "compiler_jobs_max": 1,
             "historical_transitive_header_equivalence_proven": False, "commands": []}
    began = time.monotonic()

    def run(label, argv, seconds):
        print("CPU build:", label, flush=True)
        started = time.monotonic()
        stdout, stderr = P / (label + ".stdout.log"), P / (label + ".stderr.log")
        executed = ["/usr/bin/timeout", "--signal=TERM", "--kill-after=10s", str(seconds) + "s", *argv]
        with stdout.open("xb") as out, stderr.open("xb") as err:
            value = subprocess.run(executed, cwd=recipe["working_directory"], stdout=out, stderr=err)
        proof["commands"].append({"label": label, "argv": argv, "executed_argv": executed, "exit_code": value.returncode,
                                  "elapsed_seconds": time.monotonic() - started, "stdout": pin(stdout), "stderr": pin(stderr)})
        assert value.returncode == 0, label

    try:
        impl = json.loads((P / "implementation-receipt.json").read_bytes())
        proof["source_pins"] = [verify(row) for row in impl["source_pins"]]
        proof["unchanged_inputs_before"] = [verify(row) for row in recipe["unchanged_input_pins"]]
        for row in recipe["frozen_input_recipes"]:
            verify(row)
        verify(recipe["base_source"])
        compile_argv = list(recipe["compile_backend_argv"])
        assert compile_argv.count("-MMD") == 1
        compile_argv[compile_argv.index("-MMD")] = "-MD"
        pre = []
        skip = False
        for arg in compile_argv:
            if skip:
                skip = False; continue
            if arg in ("-o", "-MF"):
                skip = True; continue
            if arg not in ("-c", "-MD"):
                pre.append(arg)
        pre += ["-M", "-MF", str(P / "dependencies-before.d"), "-MT", "private_dependency_probe"]
        proof["root_compile_delta"] = "MMD replaced by MD; pre-build M scan captures system and user headers. Historical header equivalence remains unproved."
        for name in ("ggml-vulkan.cpp.o", "ggml-vulkan.cpp.d", "dependencies-before.d", "libggml-vulkan.a", "baseline-stem-runtime", "packed-stem-runtime"):
            assert not (P / name).exists(), name
        run("dependencies-before", pre, 90)
        before_paths = dependencies(P / "dependencies-before.d")
        proof["current_dependencies_before"] = [pin(path) for path in before_paths]
        run("compile-backend", compile_argv, 900)
        after_paths = dependencies(P / "ggml-vulkan.cpp.d")
        assert before_paths == after_paths, "Compiler dependency set changed"
        proof["current_dependencies_after"] = [pin(path) for path in after_paths]
        assert proof["current_dependencies_before"] == proof["current_dependencies_after"], "Header bytes changed"
        original = Path(recipe["archive_copy"]["source"])
        verify(recipe["archive_copy"]["source_pin"])
        old = members(original)
        archive = Path(recipe["archive_copy"]["destination"])
        with original.open("rb") as src, archive.open("xb") as dst:
            shutil.copyfileobj(src, dst)
        run("replace-backend-member", recipe["archive_replace_argv"], 60)
        run("index-backend-archive", recipe["archive_index_argv"], 60)
        new = members(archive)
        assert [r["name"] for r in old] == [r["name"] for r in new]
        assert sum(r["name"] == recipe["archive_member"] for r in old) == 1
        assert all(a == b for a, b in zip(old, new) if a["name"] != recipe["archive_member"])
        object_pin = pin(P / "ggml-vulkan.cpp.o")
        assert next(r for r in new if r["name"] == recipe["archive_member"])["sha256"] == object_pin["sha256"]
        proof["archive_members_before"], proof["archive_members_after"] = old, new
        run("link-baseline", recipe["link_baseline_argv"], 180)
        run("link-packed", recipe["link_packed_argv"], 180)
        proof["unchanged_inputs_after"] = [verify(row) for row in recipe["unchanged_input_pins"]]
        assert proof["unchanged_inputs_before"] == proof["unchanged_inputs_after"]
        proof["artifacts"] = {key: pin(P / name) for key, name in (
            ("backend_object", "ggml-vulkan.cpp.o"), ("backend_archive", "libggml-vulkan.a"),
            ("baseline_runtime", "baseline-stem-runtime"), ("packed_runtime", "packed-stem-runtime"))}
        proof["passed"] = True
    except Exception as error:
        proof["error"] = repr(error)
        raise
    finally:
        proof["elapsed_seconds"] = time.monotonic() - began
        with (P / "root-build-receipt-01.json").open("x") as output:
            json.dump(proof, output, indent=2); output.write("\n")
        print(json.dumps({"passed": proof["passed"], "elapsed_seconds": proof["elapsed_seconds"], "error": proof.get("error")}), flush=True)


if __name__ == "__main__":
    main()
