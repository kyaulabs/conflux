"""Strict bounded reader for the private completed-query metadata, no host work."""
import re

PREFIX = b"conflux_vk_attention_v1 "
MAX_BYTES = 8 * 1024 * 1024
UINT64_MAX = (1 << 64) - 1


def require(ok, message):
    if not ok:
        raise ValueError(message)


def number(value, maximum=UINT64_MAX):
    require(type(value) is str and re.fullmatch(r"0|[1-9][0-9]{0,19}", value) is not None,
            "Noncanonical unsigned metadata integer")
    parsed = int(value)
    require(parsed <= maximum, "Metadata integer exceeds bound")
    return parsed


def fields(line):
    require(len(line) <= 1024, "Metadata line exceeds bound")
    words = line.decode("ascii").split(" ")
    require(len(words) >= 3 and words[0] == "conflux_vk_attention_v1", "Metadata prefix differs")
    result = {}
    for item in words[2:]:
        require(item.count("=") == 1, "Malformed metadata field")
        key, value = item.split("=", 1)
        require(key and value and key not in result, "Duplicate/empty metadata field")
        result[key] = value
    return words[1], result


def shape(value):
    parts = value.split(",")
    require(len(parts) == 4, "Four-dimensional metadata required")
    return tuple(number(x) for x in parts)


def parse_attention_output(data, *, packed):
    require(type(data) is bytes and len(data) <= MAX_BYTES and type(packed) is bool,
            "Bounded bytes and exact variant required")
    graphs, current, rows = [], None, 0
    for raw in data.splitlines(keepends=True):
        require(not raw.startswith(b"conflux_vk_attention_") or raw.startswith(PREFIX),
                "Unknown attention metadata version")
        if not raw.startswith(PREFIX):
            continue
        require(raw.endswith(b"\n"), "Unterminated attention metadata record")
        raw = raw[:-1]
        rows += 1
        require(rows <= 4096, "Too many metadata rows")
        kind, row = fields(raw)
        if kind == "begin":
            require(current is None and len(graphs) < 256, "Nested/too many metadata graphs")
            require(set(row) == {"seq", "status", "reason", "graph_nodes", "queries", "flash_count", "selected",
                                 "total_ns", "head_cont_ns", "flash_ns", "rest_ns"}, "Begin metadata fields differ")
            numeric = {k: number(v) for k, v in row.items() if k not in ("status", "reason")}
            require(numeric["seq"] == len(graphs) + 1 and 0 < numeric["graph_nodes"] <= 262144
                    and numeric["queries"] <= numeric["graph_nodes"], "Graph sequence/extent differs")
            require(row["status"] in ("complete", "not_target_graph") and row["reason"] == "none",
                    "Native query metadata unsupported: " + row["reason"])
            target = row["status"] == "complete"
            require(numeric["flash_count"] == (10 if target else 0)
                    and numeric["selected"] == (40 if target else 0), "Wrong full-model target counts")
            require(numeric["head_cont_ns"] + numeric["flash_ns"] + numeric["rest_ns"] == numeric["total_ns"],
                    "Group/rest duration totals differ")
            require(not target or all(numeric[k] > 0 for k in ("total_ns", "head_cont_ns", "flash_ns")),
                    "Full-model aggregate query timings are zero")
            current = {**numeric, "status": row["status"], "targets": []}
        elif kind == "target":
            require(current is not None and current["status"] == "complete", "Target outside full-model graph")
            role = row.get("role")
            common = {"seq", "item", "query", "graph", "flash", "role", "duration_ns", "dst"}
            require(role in ("q", "k", "v", "flash") and set(row) == (common if role == "flash" else
                    common | {"source_graph", "root_graph", "source_nb", "source_view_offs"}), "Target fields/role differ")
            parsed = {k: number(v) for k, v in row.items() if k not in ("role", "dst", "source_nb")}
            parsed.update(role=role, dst=shape(row["dst"]))
            previous = current["targets"]
            require(parsed["seq"] == current["seq"] and parsed["item"] == len(previous) + 1
                    and len(previous) < 40 and 1 <= parsed["query"] <= current["queries"]
                    and 0 <= parsed["graph"] < current["graph_nodes"] and 1 <= parsed["flash"] <= 10
                    and (not previous or parsed["query"] > previous[-1]["query"])
                    and all(parsed["graph"] != x["graph"] for x in previous), "Target sequence/query/graph differs")
            if role != "flash":
                parsed["source_nb"] = shape(row["source_nb"])
                require(parsed["source_graph"] < current["graph_nodes"] and parsed["root_graph"] < current["graph_nodes"],
                        "Copy source/root mapping out of range")
            previous.append(parsed)
        elif kind == "end":
            require(current is not None and set(row) == {"seq", "records", "complete"}
                    and number(row["seq"]) == current["seq"] and row["complete"] == "1"
                    and number(row["records"]) == len(current["targets"]) == current["selected"],
                    "Missing/incomplete target footer")
            targets = current["targets"]
            require(sum(x["duration_ns"] for x in targets if x["role"] == "flash") == current["flash_ns"]
                    and sum(x["duration_ns"] for x in targets if x["role"] != "flash") == current["head_cont_ns"],
                    "Selected target duration sums differ")
            signatures = {}
            for slot in range(1, 11) if current["status"] == "complete" else ():
                entries = [x for x in targets if x["flash"] == slot]
                require(len(entries) == 4 and {x["role"] for x in entries} == {"q", "k", "v", "flash"},
                        "Incomplete/duplicate attention roles")
                roles = {x["role"]: x for x in entries}
                q, k, v, flash = (roles[x] for x in ("q", "k", "v", "flash"))
                qlen, kvlen = q["dst"][1], k["dst"][1]
                require(qlen in (1344, 2688) and kvlen in (1344, 2688)
                        and q["dst"] == (64, qlen, 8, 1) and k["dst"] == v["dst"] == (64, kvlen, 8, 1)
                        and flash["dst"] == (64, 8, qlen, 1), "Attention tensor geometry differs")
                signature = (qlen, kvlen)
                signatures[signature] = signatures.get(signature, 0) + 1
                for label in ("q", "k", "v"):
                    target = roles[label]
                    factor = (3 if qlen == kvlen else (1 if label == "q" else 2)) if packed else 1
                    offset = ({"q": 0, "k": 2048, "v": 4096}[label] if qlen == kvlen else
                              (2048 if label == "v" else 0)) if packed else 0
                    length = target["dst"][1]
                    require(target["source_nb"] == (4, factor * 2048, 256, factor * 2048 * length)
                            and target["source_view_offs"] == offset, "Copy source layout/variant differs")
                if packed:
                    require((q["root_graph"] == k["root_graph"] == v["root_graph"]) if qlen == kvlen else
                            (k["root_graph"] == v["root_graph"] != q["root_graph"]), "Packed root sharing differs")
                else:
                    require(len({q["root_graph"], k["root_graph"], v["root_graph"]}) == 3, "Baseline copy roots differ")
            if current["status"] == "complete":
                require(signatures == {(1344, 1344): 3, (2688, 2688): 3, (1344, 2688): 2, (2688, 1344): 2},
                        "Fixed ten attention signatures differ")
            else:
                require(current["head_cont_ns"] == current["flash_ns"] == 0, "Startup graph selected timings differ")
            graphs.append(current)
            current = None
        else:
            raise ValueError("Unknown query metadata record")
    require(current is None and graphs, "Missing/truncated query metadata")
    full = [g for g in graphs if g["status"] == "complete"]
    require(len(full) == 1, "Exactly one complete full-model request graph required")
    return {"schema": 1, "passed": True, "qualified": False, "graphs": graphs,
            "full_model": full[0], "startup_graphs": len(graphs) - 1,
            "scope": "All40 selected query intervals plus rest; instrumented, not exclusive kernel or latency qualification"}
