// Private CPU-only metadata fixture. No ggml, Vulkan, device or model linkage.
#include <algorithm>
#include <array>
#include <charconv>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <vector>

namespace {
using std::size_t;
enum ggml_op { GGML_OP_OTHER, GGML_OP_CONT, GGML_OP_FLASH_ATTN_EXT };
struct ggml_tensor {
    ggml_op op = GGML_OP_OTHER;
    ggml_tensor* src[3]{};
    ggml_tensor* view_src = nullptr;
    int64_t ne[4]{1, 1, 1, 1};
    size_t nb[4]{4, 4, 4, 4};
    size_t view_offs = 0;
};
struct ggml_cgraph { int n_nodes; ggml_tensor** nodes; };
struct metadata_device { struct { struct { float timestampPeriod = 1.F; } limits; } properties; };
struct metadata_context {
    metadata_device* device = nullptr;
    int query_idx = 1;
    std::vector<ggml_tensor*> query_nodes{nullptr};
    std::vector<const char*> query_fusion_names{nullptr};
    uint64_t attention_trace_sequence = 0;
};
struct Expected {
    ggml_tensor* node;
    int graph, flash, role, source, root, query = -1;
    uint64_t duration = 0;
    std::array<int64_t, 4> dst;
    std::array<size_t, 4> source_nb;
    size_t source_offset;
};
struct Group { ggml_tensor* flash; std::array<ggml_tensor*, 3> cont; std::array<size_t, 3> expected_cont; size_t expected_flash; };
struct Scenario {
    metadata_device device;
    metadata_context context;
    std::vector<std::unique_ptr<ggml_tensor>> owners;
    std::vector<ggml_tensor*> graph;
    std::vector<uint64_t> timestamps{0};
    std::vector<Expected> expected;
    std::vector<Group> groups;
    uint64_t total = 0, rest = 0;

    ggml_tensor* add(ggml_op op = GGML_OP_OTHER) {
        auto node = std::make_unique<ggml_tensor>(); node->op = op;
        auto* result = node.get(); owners.push_back(std::move(node)); graph.push_back(result); return result;
    }
    void query(ggml_tensor* node, uint64_t ticks) {
        context.query_nodes.push_back(node); context.query_fusion_names.push_back(nullptr);
        timestamps.push_back(timestamps.back() + ticks); context.query_idx = int(timestamps.size()); total += ticks;
    }
};
uint64_t assertions = 0, cases = 0;
size_t largest_report = 0;
void require(bool value, const char* message) { ++assertions; if (!value) throw std::runtime_error(message); }

// These expected IDs are assigned when independently constructing semantic Q/K/V
// groups. They are never discovered by walking the fragment's selected nodes.
Scenario full_graph()
{
    Scenario s;
    std::array<ggml_tensor*, 128> slower{};
    for (auto& node : slower) node = s.add();
    for (int flash = 1; flash <= 10; ++flash) {
        const int root_index = int(s.graph.size()); auto* root = s.add();
        root->ne[0] = 1536; root->ne[1] = 1344;
        Group group{};
        for (int role = 0; role < 3; ++role) {
            const int source_index = int(s.graph.size()); auto* view = s.add();
            view->view_src = root; view->view_offs = size_t(role) * 2048;
            const std::array<size_t, 4> strides{4, 6144, 256, 6144 * 1344};
            std::copy(strides.begin(), strides.end(), view->nb);
            const int graph_index = int(s.graph.size()); auto* cont = s.add(GGML_OP_CONT); cont->src[0] = view;
            const std::array<int64_t, 4> dimensions{64, 1344, 8, 1};
            std::copy(dimensions.begin(), dimensions.end(), cont->ne);
            group.cont[size_t(role)] = cont; group.expected_cont[size_t(role)] = s.expected.size();
            s.expected.push_back({cont, graph_index, flash, role, source_index, root_index, -1, 0, dimensions, strides, size_t(role) * 2048});
        }
        const int graph_index = int(s.graph.size()); group.flash = s.add(GGML_OP_FLASH_ATTN_EXT);
        for (int role = 0; role < 3; ++role) group.flash->src[role] = group.cont[size_t(role)];
        const std::array<int64_t, 4> dimensions{64, 8, 1344, 1};
        std::copy(dimensions.begin(), dimensions.end(), group.flash->ne);
        group.expected_flash = s.expected.size();
        s.expected.push_back({group.flash, graph_index, flash, -1, -1, -1, -1, 0, dimensions, {}, 0});
        s.groups.push_back(group);
    }
    size_t slow = 0;
    for (size_t group = 10; group-- > 0;) {
        const auto& g = s.groups[group];
        const std::array<size_t, 4> order{g.expected_cont[2], g.expected_flash, g.expected_cont[0], g.expected_cont[1]};
        for (const auto index : order) {
            auto& expected = s.expected[index]; expected.query = s.context.query_idx;
            expected.duration = 100 + uint64_t(index) * 2;
            s.query(expected.node, expected.duration);
            for (int n = 0; n < 3; ++n) {
                const uint64_t duration = 1000000 + slow * 10;
                s.query(slower[slow++], duration); s.rest += duration;
            }
        }
    }
    while (slow < slower.size()) { const auto ticks = 1000000 + slow * 10; s.query(slower[slow++], ticks); s.rest += ticks; }
    return s;
}
Scenario startup_graph(bool timed = false)
{
    Scenario s;
    if (timed) { auto* first = s.add(); auto* second = s.add(); s.query(first, 17); s.query(second, 29); s.rest = 46; }
    else s.add();
    return s;
}
std::string actual_fragment(Scenario& s)
{
    struct Capture {
        std::ostringstream bytes;
        std::streambuf* previous = std::cerr.rdbuf(bytes.rdbuf());
        ~Capture() { std::cerr.rdbuf(previous); }
    } capture;
    s.context.device = &s.device;
    auto* ctx = &s.context;
    ggml_cgraph graph{int(s.graph.size()), s.graph.data()}; auto* cgraph = &graph;
    auto& timestamps = s.timestamps;
#include "attention_trace.inc"
    return capture.bytes.str();
}
struct Record { std::string event; std::map<std::string, std::string> fields; };
std::vector<Record> parse(const std::string& text)
{
    require(!text.empty() && text.size() <= 65536 && text.back() == '\n', "Unbounded or incomplete emitted report");
    largest_report = std::max(largest_report, text.size());
    std::vector<Record> result; std::istringstream input(text); std::string line;
    while (std::getline(input, line)) {
        std::istringstream row(line); std::string prefix, field; Record record;
        require(bool(row >> prefix >> record.event) && prefix == "conflux_vk_attention_v1", "Unknown emitted prefix/event");
        while (row >> field) {
            const auto equal = field.find('=');
            require(equal != std::string::npos && equal > 0 && equal + 1 < field.size(), "Malformed emitted field");
            require(record.fields.emplace(field.substr(0, equal), field.substr(equal + 1)).second, "Duplicate emitted key");
        }
        result.push_back(std::move(record));
    }
    require(result.size() >= 2 && result.front().event == "begin" && result.back().event == "end", "Missing emitted envelope");
    return result;
}
uint64_t number(const Record& row, const char* field)
{
    const auto& text = row.fields.at(field); uint64_t result = 0;
    const auto parsed = std::from_chars(text.data(), text.data() + text.size(), result);
    require(parsed.ec == std::errc{} && parsed.ptr == text.data() + text.size(), "Invalid unsigned emitted integer"); return result;
}
template<class T> std::string tuple(const std::array<T, 4>& values)
{
    std::ostringstream text; for (size_t n = 0; n < values.size(); ++n) { if (n) text << ','; text << values[n]; } return text.str();
}
void accepted(Scenario s)
{
    ++cases; const auto sequence = s.context.attention_trace_sequence + 1;
    const auto rows = parse(actual_fragment(s)); const auto& begin = rows.front(); const auto& end = rows.back();
    require(begin.fields.at("status") == (s.expected.empty() ? "not_target_graph" : "complete") && begin.fields.at("reason") == "none", "Valid graph was not accepted");
    require(number(begin, "seq") == sequence && number(end, "seq") == sequence && s.context.attention_trace_sequence == sequence, "Sequence identity changed");
    require(number(begin, "graph_nodes") == s.graph.size() && number(begin, "queries") == size_t(s.context.query_idx - 1), "Graph/query coverage changed");
    require(number(begin, "flash_count") == s.groups.size() && number(begin, "selected") == s.expected.size() && rows.size() == s.expected.size() + 2, "Flash/head selection count differs");
    require(number(begin, "total_ns") == s.total && number(begin, "rest_ns") == s.rest, "Full/rest accounting lost slow unrelated queries");
    require(number(end, "records") == s.expected.size() && number(end, "complete") == 1, "Valid footer is incomplete");
    std::sort(s.expected.begin(), s.expected.end(), [](const auto& a, const auto& b) { return a.query < b.query; });
    uint64_t heads = 0, flashes = 0;
    for (size_t n = 0; n < s.expected.size(); ++n) {
        const auto& e = s.expected[n]; const auto& row = rows[n + 1];
        const auto role = e.role < 0 ? "flash" : e.role == 0 ? "q" : e.role == 1 ? "k" : "v";
        require(row.event == "target" && number(row, "item") == n + 1 && number(row, "seq") == sequence && number(row, "query") == uint64_t(e.query), "Per-query target identity/order differs");
        require(number(row, "graph") == uint64_t(e.graph) && number(row, "flash") == uint64_t(e.flash) && row.fields.at("role") == role && number(row, "duration_ns") == e.duration && row.fields.at("dst") == tuple(e.dst), "Expected semantic ID/role/duration/shape differs");
        if (e.role >= 0) {
            require(number(row, "source_graph") == uint64_t(e.source) && number(row, "root_graph") == uint64_t(e.root) && row.fields.at("source_nb") == tuple(e.source_nb) && number(row, "source_view_offs") == e.source_offset, "Head view provenance differs");
            heads += e.duration;
        } else { require(!row.fields.contains("source_graph"), "Flash record fabricated copy provenance"); flashes += e.duration; }
    }
    require(number(begin, "head_cont_ns") == heads && number(begin, "flash_ns") == flashes && heads + flashes + s.rest == s.total, "Target partition/sum differs");
}
void rejected(Scenario s, std::string_view reason)
{
    ++cases; const auto old = s.context.attention_trace_sequence;
    const auto rows = parse(actual_fragment(s));
    require(rows.size() == 2 && rows[0].fields.at("status") == "unsupported" && rows[0].fields.at("reason") == reason, "Invalid metadata did not fail with the expected reason");
    require(number(rows.back(), "records") == 0 && number(rows.back(), "complete") == 0, "Invalid metadata emitted partial target success");
    const auto sequence = old == std::numeric_limits<uint64_t>::max() ? 0 : old + 1;
    require(number(rows.front(), "seq") == sequence && number(rows.back(), "seq") == sequence, "Failed envelope lost its sequence binding");
    require(s.context.attention_trace_sequence == (sequence ? sequence : old), "Sequence overflow wrapped its state");
}
} // namespace

int main()
{
    try {
        auto selected = full_graph(); require(selected.expected.size() == 40 && selected.rest > 128000000, "Insufficient independent slow-query distractors");
        selected.context.attention_trace_sequence = 11; accepted(std::move(selected));
        accepted(startup_graph()); accepted(startup_graph(true));
        auto precision = full_graph(); precision.device.properties.limits.timestampPeriod = 1.5F;
        precision.timestamps.assign(size_t(precision.context.query_idx), 0);
        for (size_t q = 1; q < precision.timestamps.size(); ++q) precision.timestamps[q] = precision.timestamps[q - 1] + (q == 1 ? 100000001 : 2);
        for (auto& e : precision.expected) e.duration = e.query == 1 ? 150000001 : 3;
        precision.total = 150000001 + uint64_t(precision.context.query_idx - 2) * 3; precision.rest = 128 * 3;
        accepted(std::move(precision)); // Float multiplication would round 150000001.5 before truncation.
        auto wide = full_graph();
        for (auto& e : wide.expected) {
            e.dst.fill(std::numeric_limits<int64_t>::max()); std::copy(e.dst.begin(), e.dst.end(), e.node->ne);
            if (e.role >= 0) {
                e.source_nb.fill(std::numeric_limits<size_t>::max()); e.source_offset = std::numeric_limits<size_t>::max();
                std::copy(e.source_nb.begin(), e.source_nb.end(), e.node->src[0]->nb); e.node->src[0]->view_offs = e.source_offset;
            }
        }
        accepted(std::move(wide));
        auto mutation = [](auto change, std::string_view reason) { auto s = full_graph(); change(s); rejected(std::move(s), reason); };
        mutation([](auto& s) { s.context.query_nodes[1] = nullptr; }, "missing_target_query");
        mutation([](auto& s) { s.query(s.context.query_nodes[1], 1); }, "duplicate_query");
        mutation([](auto& s) { s.context.query_fusion_names[1] = "fused"; }, "fused_target");
        mutation([](auto& s) { s.graph.push_back(s.groups[0].cont[0]); }, "target_graph_mapping");
        mutation([](auto& s) { s.graph.push_back(s.groups[0].cont[0]->src[0]); }, "source_graph_mapping");
        mutation([](auto& s) { s.groups[1].flash->src[0] = s.groups[0].cont[0]; }, "duplicate_target");
        mutation([](auto& s) { std::erase(s.graph, s.groups.back().flash); }, "attention_shape_count");
        mutation([](auto& s) { auto* flash = s.add(GGML_OP_FLASH_ATTN_EXT); for (int role = 0; role < 3; ++role) flash->src[role] = s.groups[0].cont[size_t(role)]; }, "target_count_or_null");
        mutation([](auto& s) { s.timestamps[2] = s.timestamps[1] - 1; }, "timestamp_regression");
        for (float period : {0.F, -1.F, std::numeric_limits<float>::quiet_NaN(), std::numeric_limits<float>::infinity()})
            mutation([=](auto& s) { s.device.properties.limits.timestampPeriod = period; }, "timestamp_period");
        auto range = startup_graph(true); range.device.properties.limits.timestampPeriod = std::ldexp(1.F, 64); rejected(std::move(range), "duration_range");
        auto sum = startup_graph(true); sum.device.properties.limits.timestampPeriod = 1.5F;
        sum.timestamps = {0, std::numeric_limits<uint64_t>::max() / 2, std::numeric_limits<uint64_t>::max() - 1}; rejected(std::move(sum), "duration_sum_overflow");
        mutation([](auto& s) { s.context.attention_trace_sequence = std::numeric_limits<uint64_t>::max(); }, "sequence_exhausted");
        mutation([](auto& s) { s.context.query_idx = 0; }, "query_extent");
        mutation([](auto& s) { s.timestamps.pop_back(); }, "query_extent");
        mutation([](auto& s) { s.context.query_nodes.pop_back(); }, "query_extent");
        mutation([](auto& s) { s.context.query_fusion_names.pop_back(); }, "query_extent");
        mutation([](auto& s) { s.groups[0].cont[0]->src[0] = nullptr; }, "missing_copy_source");
        mutation([](auto& s) { s.groups[0].cont[0]->op = GGML_OP_OTHER; }, "target_operation");
        mutation([](auto& s) { s.groups[0].flash->src[0] = nullptr; }, "target_count_or_null");
        mutation([](auto& s) { std::erase(s.graph, s.groups[0].cont[0]); }, "target_graph_mapping");
        mutation([](auto& s) { std::erase(s.graph, s.groups[0].cont[0]->src[0]->view_src); }, "source_graph_mapping");
        std::cout << "PASS selector_fixture cases=" << cases << " assertions=" << assertions << " largest_report_bytes=" << largest_report << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "FAIL selector_fixture case=" << cases << " error=" << std::string(error.what()).substr(0, 512) << '\n';
        return 1;
    }
}
