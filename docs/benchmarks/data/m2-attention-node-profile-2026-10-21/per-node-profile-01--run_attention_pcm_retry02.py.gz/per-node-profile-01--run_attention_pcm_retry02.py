#!/usr/bin/env python3
"""Private fixed one-request pair; dry default, manual baseline then packed, no audio/UI."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
A = BASE.parent
PLAN, HUMAN = BASE/'diagnostic-plan-02.json', BASE/'human-readiness-02.json'
PLAYER = A/'run_drm_player_retry02.py'
PLAYER_SHA = '05e35bfb723136d430e090c1515163c60bcce7a05f570fcbc6842b4c41e048fb'
MODE = 'attention-node-fixed-pair-02'
CASE = 'club_xl:515970'
INPUT_SHA = '688cd7af5ecd42efc3e20ba0e6e420a6acf824ce5c9f7d2d2980e1fd95ee983f'
OUTPUT_SHA = '31bd8ae4e8fcde10f385c51a669834345457e034826bd316cf1eb1f2b7d8d7ef'
MODEL_SHA = 'f8c54ba35df95aafea7881eac214b58ec18a73cbcb6ff5a90f4b762631a286b6'
REQUEST_SECONDS, PROFILE_SECONDS, READINESS_SECONDS, TOTAL_SECONDS, CLEANUP_SECONDS = 30, 60, 195, 300, 45
PAIR_SECONDS, STDERR_LIMIT = 600, 8*1024**2
ARMS = ('baseline','packed')
OUTPUTS = {arm:BASE/(arm+'-request-02') for arm in ARMS}
RUNTIMES = {arm:BASE/(arm+'-stem-runtime') for arm in ARMS}
ASSET_PATHS={'runtime':RUNTIMES['baseline'],'model':Path('/tmp/conflux-stem-m0/models/htdemucs-f16.gguf'),
    'python':Path('/usr/bin/python3.14'),'guard_script':Path('/home/kyau/.local/bin/thermal-guard'),
    'guard_unit':Path('/home/kyau/.config/systemd/user/thermal-guard.service')}
REQUIRED_SOURCES = {'driver':BASE/'run_attention_pcm_retry02.py', 'capture':BASE/'native_capture.py',
    'parser':BASE/'parse_attention.py', 'cache':BASE/'cache_support_retry02.py',
    'base_player':PLAYER, 'context_helper':A/'context_capture.py',
    'trace_validator':A/'drm_trace_validation.py', 'pcm_original':ROOT/'benchmarks-local/background-player-01/request-trace-candidate/pcm-only/run_pcm_comparison.py',
    'reference':ROOT/'benchmarks-local/m2-graph-phase-2026-10-18/flash-promoted-repro-01/result.json',
    'worker':ROOT/'tools/stems/worker.py'}


def require(ok, text):
    if not ok: raise ValueError(text)


def pin_shape(row):
    require(type(row) is dict and type(row.get('path')) is str and Path(row['path']).is_absolute()
        and type(row.get('bytes')) is int and 0 < row['bytes'] <= 1024**3
        and type(row.get('sha256')) is str and re.fullmatch('[0-9a-f]{64}',row['sha256']), 'Incomplete fixed byte pin')
    require('canonical_path' not in row or row['canonical_path']==row['path'], 'Canonical content identity differs')


def read_file(path, maximum=2*1024**2, expected=None):
    path=Path(path)
    require(path.is_absolute() and path.resolve(strict=True)==path, 'Canonical file required')
    fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_uid==os.getuid() and before.st_nlink==1
                and 0 < before.st_size <= maximum, 'Unsafe/oversized private input')
        data=bytearray()
        while len(data)<before.st_size:
            part=os.read(fd,min(1024**2,before.st_size-len(data)))
            require(part,'Truncated private input');data.extend(part)
        signature=lambda st:(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
        require(signature(before)==signature(os.fstat(fd))==signature(path.lstat()),'Private input changed')
        pin={'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        if expected is not None:
            pin_shape(expected);require(pin=={k:expected[k] for k in pin},'Private pin differs')
        return bytes(data),pin
    finally: os.close(fd)


def read_json(path,maximum=2*1024**2,expected=None):
    raw,pin=read_file(path,maximum,expected);return json.loads(raw),pin


def same_pin(a,b):
    return all(a.get(k)==b.get(k) for k in ('path','bytes','sha256'))


def validate_build(plan):
    build,_=read_json(BASE/'build-admission-01.json',expected=plan['build_result'])
    require(type(build.get('schema')) is int and build['schema']==1 and build.get('passed') is True and build.get('physical_execution') is False
        and build.get('historical_header_equivalence')=='unproved', 'Actual reviewed root build admission required')
    for field,name in (('source_receipt','implementation-receipt.json'),('recipe','build_recipe.json')):
        row=build.get(field,{});pin_shape(row)
        require(row['path']==str(BASE/name) and same_pin(row,plan['source_pins'][field]),'Build source/recipe identity differs')
    require(build.get('unchanged_inputs_before') and build['unchanged_inputs_before']==build.get('unchanged_inputs_after'),
        'Build immutable inputs changed')
    closure=build.get('current_dependency_closure',{})
    require(closure.get('complete') is True and closure.get('current_before_after_match') is True
        and type(closure.get('before')) is list and closure['before']
        and closure['before']==closure.get('after'), 'Complete current user/system dependency closure required')
    for row in closure['before']+build['unchanged_inputs_before']:
        pin_shape(row)
        require(any(same_pin(row,p) for p in plan['source_pins'].values()),'Current dependency missing from launch pins')
    proof=build.get('archive_payload_proof',{})
    require(proof.get('passed') is True and proof.get('replaced_members')==['ggml-vulkan.cpp.o']
        and proof.get('other_payload_hashes_unchanged') is True and proof.get('same_ordered_members') is True
        and type(proof.get('member_count')) is int and proof['member_count']==160, 'Exact shader/archive payload proof required')
    artifacts=build.get('artifacts',{})
    require(set(artifacts)=={'baseline_runtime','packed_runtime','backend_object','backend_archive'},'Actual four build artifacts required')
    for key,path in {'baseline_runtime':RUNTIMES['baseline'],'packed_runtime':RUNTIMES['packed'],
                     'backend_object':BASE/'ggml-vulkan.cpp.o','backend_archive':BASE/'libggml-vulkan.a'}.items():
        pin_shape(artifacts[key]);require(artifacts[key]['path']==str(path),'Wrong private build output')
        target=plan['runtimes'][key[:-8]] if key.endswith('_runtime') else plan['source_pins'][key]
        require(same_pin(artifacts[key],target),'Build/launch artifact differs')
    require(type(build.get('commands')) is list and build['commands']
        and all(type(c) is dict and type(c.get('exit_code')) is int and c['exit_code']==0
                and type(c.get('argv')) is list and c['argv'] for c in build['commands']), 'Actual successful command evidence required')
    for row in build['commands']:
        for key in ('stdout','stderr'):
            pin=row.get(key);require(type(pin) is dict,'Build command log absent')
            require(type(pin.get('bytes')) is int and pin['bytes']>=0 and type(pin.get('sha256')) is str
                    and re.fullmatch('[0-9a-f]{64}',pin['sha256']) is not None,'Build command log pin absent')
    return build


def load_plan(path=PLAN):
    require(path==PLAN,'Only the fixed diagnostic plan is allowed')
    plan,pinned=read_json(path,256*1024)
    require(type(plan.get('schema')) is int and plan['schema']==1 and plan.get('status')=='frozen_pending_fresh_attention_pair_readiness'
        and plan.get('mode')==MODE and plan.get('consent') is None and plan.get('physical_execution') is False
        and plan.get('qualified') is False and plan.get('source_root')==str(ROOT)
        and type(plan.get('source_head')) is str and re.fullmatch('[0-9a-f]{40}',plan['source_head'])
        and plan.get('case_id')==CASE and plan.get('input_sha256')==INPUT_SHA and plan.get('output_sha256')==OUTPUT_SHA
        and plan.get('order')==list(ARMS) and plan.get('operator_seconds')==600 and plan.get('arm_seconds')==300
        and plan.get('strict_service_target_ms')==4095 and plan.get('logger_environment')=={
            'GGML_VK_PERF_LOGGER':'1','GGML_VK_PERF_LOGGER_FREQUENCY':'1'}
        and plan.get('native_mode')=='passive_drm_owned_client_set_v1' and plan.get('native_schema')==2
        and plan.get('drm_device')=={'driver':'i915','pdev':'0000:00:02.0'}
        and plan.get('review',{}).get('status')=='passed', 'Plan unarmed/incomplete/out of fixed scope')
    for key,path in REQUIRED_SOURCES.items():
        require(plan.get('source_pins',{}).get(key,{}).get('path')==str(path),'Required executed source absent: '+key)
    require(set(plan.get('runtimes',{}))==set(ARMS) and all(plan['runtimes'][a].get('path')==str(RUNTIMES[a]) for a in ARMS), 'Wrong pair runtimes')
    require(set(plan.get('assets',{}))==set(ASSET_PATHS) and all(plan['assets'][k].get('path')==str(p) for k,p in ASSET_PATHS.items()),'Fixed PCM assets differ')
    require(plan.get('assets',{}).get('model',{}).get('sha256')==MODEL_SHA
        and plan.get('cache_helper',{}).get('path')==str(BASE/'cache_support_retry02.py')
        and plan.get('build_result',{}).get('path')==str(BASE/'build-admission-01.json'),'Wrong fixed model/helper/build')
    for row in [*plan['assets'].values(),*plan['runtimes'].values(),*plan['source_pins'].values(),
                plan['cache_helper'],plan['gpu_helper'],plan['package_helper'],plan['seed_proof'],plan['build_result'],plan['review']]: pin_shape(row)
    require(plan['source_pins']['base_player']['sha256']==PLAYER_SHA
        and plan['source_pins']['worker']['sha256']=='b38ab1dae456f9da69cbb30563595559f10e018246e86763dffffa89b9bacdff', 'Frozen helper parent changed')
    read_file(Path(__file__).resolve(),256*1024,plan['source_pins']['driver'])
    validate_build(plan)
    return plan,pinned


def readiness(path,plan_pin):
    require(path==HUMAN,'Only one original pair human record is permitted')
    value,pin=read_json(path,16384)
    now=time.monotonic();issued=datetime.fromisoformat(value.get('recorded_at_utc',''))
    age=(datetime.now(timezone.utc)-issued).total_seconds() if issued.tzinfo else -1
    require(value.get('schema')==1 and value.get('decision')=='ready' and value.get('diagnostic_mode')==MODE
        and value.get('plan_sha256')==plan_pin['sha256'] and value.get('order')==list(ARMS)
        and value.get('maximum_operator_seconds')==600 and 0<=age<600
        and all(value.get(k) is True for k in ('AC_power','lid_open','Codex_minimized','other_work_paused','no_suspend'))
        and all(type(value.get(k)) is str and 0<len(value[k])<=8192 for k in ('question_item_id','human_question','human_reply')),
        'Fresh actual pair readiness required; no prior-window reuse')
    return {'record':value,'pin':pin,'age_seconds':age,'sampled_monotonic':now}


def operator_budget(human,now,started,*,arm,boot_id,plan_pin):
    require(arm in ARMS and 0<=human['age_seconds']<600 and human['sampled_monotonic']<=now,'Invalid original clock anchor')
    original=human['sampled_monotonic']+600-human['age_seconds']
    prior_pin=None
    if arm=='baseline':
        require(human['age_seconds']<=120,'Initial dispatch must be fresh')
    else:
        prior,prior_pin=read_json(OUTPUTS['baseline']/'result.json',8*1024**2)
        require(prior.get('status')=='passed' and prior.get('cleanup_complete') is True and prior.get('pins_unchanged') is True
            and prior.get('within_wall_budget') is True and not prior.get('errors') and prior.get('arm')=='baseline'
            and prior.get('boot_id')==boot_id and same_pin(prior.get('plan_pin',{}),plan_pin)
            and same_pin(prior.get('human_pin',{}),human['pin'])
            and prior.get('capture',{}).get('complete') is True and prior.get('attention',{}).get('passed') is True
            and prior.get('native_trace',{}).get('passed') is True
            and prior.get('native_shutdown',{}).get('graceful_complete') is True
            and prior.get('guard_before')==prior.get('guard_after') and prior.get('guard_before') is not None,
            'Completed same-window baseline proof required')
        anchor=prior['operator_budget']
        require(anchor.get('boot_id')==boot_id and type(anchor.get('operator_deadline_monotonic')) in (int,float)
            and math.isfinite(anchor['operator_deadline_monotonic']), 'Original boot/monotonic anchor absent')
        original=min(original,anchor['operator_deadline_monotonic'])
    require(original-now>=300,'Insufficient original600s window for another complete300s arm; stop, no renewal')
    return {'phase':arm,'boot_id':boot_id,'age_seconds':human['age_seconds'],
        'approval_sample_monotonic':human['sampled_monotonic'],'human_recorded_at_utc':human['record']['recorded_at_utc'],
        'operator_deadline_monotonic':original,'phase_deadline_monotonic':min(started+300,original),
        'remaining_operator_seconds':original-now,'permitted_seconds':300,'prior_baseline_pin':prior_pin,
        'external_INT_after_seconds':270,'external_kill_grace_seconds':30,'scope':'One original600s pair; manual arms, no renewed clock'}


def load_player(plan,arm,plan_pin,human):
    raw,_=read_file(PLAYER,256*1024,plan['source_pins']['base_player'])
    spec=importlib.util.spec_from_file_location('private_attention_base',PLAYER)
    player=importlib.util.module_from_spec(spec);sys.modules[spec.name]=player
    exec(compile(raw,str(PLAYER),'exec'),player.__dict__)
    player.PLAN,player.HUMAN,player.MODE,player.PCM_OUTPUT=PLAN,HUMAN,MODE,OUTPUTS[arm]
    player.PCM_CASE_IDS=(CASE,)
    player.readiness=readiness
    player.validate_build_result=validate_build
    player.CACHE_HELPER=BASE/'cache_support_retry02.py';player.CACHE_HELPER_SHA256=plan['cache_helper']['sha256']
    return player


def select_fixed_case(prepared):
    rows=[row for row in prepared if row.get('id')==CASE]
    require(len(rows)==1 and rows[0].get('input_sha256')==INPUT_SHA
        and rows[0].get('shape')==[343980,2] and rows[0].get('dtype')=='<f4'
        and type(rows[0].get('valid_frames')) is int and rows[0]['valid_frames']==343980,
        'Exact single full fixed input required')
    return {CASE:rows[0]}


def validate_stdout(raw,ready,metrics):
    require(type(raw) is bytes and 0<len(raw)<=128*1024 and raw.endswith(b'\n'),'Incomplete bounded native stdout')
    rows=[json.loads(line) for line in raw.splitlines()]
    require(len(rows)==2 and all(type(row) is dict for row in rows)
        and rows[0]=={k:v for k,v in ready.items() if k!='process_environment'}
        and rows[1]==metrics and rows[0].get('event')=='ready' and rows[1].get('event')=='result'
        and type(rows[1].get('id')) is int and rows[1]['id']==1,'Extra/missing native protocol event')
    return {'passed':True,'events':2,'request_ids':[1]}


def retain_captures(native,output,deadline):
    evidence=native.finish_capture(deadline)
    pins={}
    for stream,limit in (('stderr',STDERR_LIMIT),('stdout',128*1024)):
        path=native.root/('runtime.'+stream)
        fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_CLOEXEC|os.O_NOFOLLOW)
        try:
            info=os.fstat(fd);require(stat.S_ISREG(info.st_mode) and info.st_size<=limit,'Capture exceeds hard bound')
            digest,count=hashlib.sha256(),0
            target=output/('native.'+stream)
            with target.open('xb') as sink:
                while count<info.st_size:
                    require(time.monotonic()<deadline,'Capture retention deadline exhausted')
                    data=os.read(fd,min(65536,info.st_size-count));require(data,'Capture truncated')
                    sink.write(data);digest.update(data);count+=len(data)
            require(os.fstat(fd).st_size==info.st_size==path.stat(follow_symlinks=False).st_size,'Capture changed')
            pins[stream]={'path':str(target),'bytes':count,'sha256':digest.hexdigest(),'truncated':False}
        finally: os.close(fd)
    return evidence,pins


def cleanup_captured(native,initialized,output,original,deadline,captures):
    """Capture retention failure must never bypass the existing owned-child cleanup."""
    errors=[]
    try:
        if getattr(native,'process',None) is not None and native.process.poll() is None:
            native.process.kill();native.process.wait(timeout=max(.001,min(3,deadline-time.monotonic())))
        if initialized and not captures:
            _evidence,captures=retain_captures(native,output,min(deadline-5,time.monotonic()+2))
    except Exception as error:
        errors.append({'phase':'capture_retention','message':str(error)[:8192]})
    finally:
        previous=original.save_stderr
        original.save_stderr=lambda _native,_output:captures.get('stderr')
        try:
            cleanup,stderr,close_errors=original.cleanup_native(native,initialized,output)
        finally:
            original.save_stderr=previous
    return cleanup,stderr,errors+close_errors,captures


def original_specs(plan, player, original, comparison, retained):
    specs = {"asset:" + k: (Path(v["path"]),v["sha256"],1024**3) for k,v in plan["assets"].items()}
    specs.update({"source:" + k:(Path(v["path"]),v["sha256"],256*1024**2) for k,v in plan["source_pins"].items()})
    for name in ("cache_helper","gpu_helper","package_helper","seed_proof","build_result","review"):
        row = plan[name]
        specs[name] = (Path(row["path"]),row["sha256"],2*1024**2)
    for name,(path,digest) in original.HELPERS.items():
        specs["original_helper:" + name] = (path,digest,128*1024)
    for name in ("admission_source","readiness_source","native_replay_source"):
        path,digest = retained.HELPERS[name]
        specs["admission_helper:" + name] = (path,digest,128*1024)
    declared = {v["path"]:v["sha256"] for v in plan["source_pins"].values()}
    player.require_trace(all(str(path) in declared for path in comparison.REQUIRED_SOURCES),
                         "Complete original PCM dependency source pins are required")
    for path in comparison.REQUIRED_SOURCES:
        specs["pcm_dependency:" + str(path)] = (path,declared[str(path)],32*1024**2)
    for label,digest in comparison.TRACKS:
        specs["input:" + label] = (comparison.ASSETS / f"{label}-30s-23p4s.wav",digest,comparison.ASSET_BYTES)
    for name,path in (("plan",player.PLAN),("human",player.HUMAN)):
        _,pinned = player.bounded_json(path)
        specs[name] = (path,pinned["sha256"],256*1024)
    return specs


def capture_plan_pins(plan, player, comparison, specs, deadline, *, verify=True):
    comparison.check_deadline(deadline)
    player.verify_canonical_aliases(plan)
    player.require_trace(all(path.resolve(strict=True) == path for path, _digest, _limit in specs.values()),
                         "PCM read pins must be canonical; NOFOLLOW remains required")
    captured = comparison.capture_pins(specs, deadline, verify=verify)
    player.verify_canonical_aliases(plan)
    comparison.check_deadline(deadline)
    return captured


def run(player, plan, plan_pin, human, arm):
    started = time.monotonic()
    boot_id = player.boot_identity()
    budget = operator_budget(human, started, started, arm=arm, boot_id=boot_id, plan_pin=plan_pin)
    deadline = min(started + TOTAL_SECONDS,budget["phase_deadline_monotonic"],budget["operator_deadline_monotonic"])
    before_native = min(started + READINESS_SECONDS,deadline - PROFILE_SECONDS - CLEANUP_SECONDS)
    output = player.PCM_OUTPUT
    output.mkdir(mode=0o700)
    admission = output / "admission"
    admission.mkdir(mode=0o700)
    trace_directory = output / player.TRACE_DIRECTORY_NAME
    trace_directory.mkdir(mode=0o700)
    report = {"schema":1,"status":"checking","mode":player.MODE,"qualified":False,"timing_qualification":False,
        "started_at_utc":datetime.now(timezone.utc).isoformat(),"started_monotonic":started,
        "boot_id":boot_id,"arm":arm,"plan_pin":plan_pin,"human_pin":human["pin"],
        "source_head":plan["source_head"],"candidate_runtime":plan["assets"]["runtime"],"model":plan["assets"]["model"],
        "reference_runtime_sha256":player.FLASH_RUNTIME_SHA256,"instrumentation":"nonconcurrent-existing-query-logger-all40-plus-rest","operator_budget":budget,
        "requests":[],"errors":[],"pins_before":{},"pins_after":{},"pins_unchanged":False,
        "cleanup_complete":False,"cleanup":{},"native_started":False,"UI_load":False,"audio_load":False,
        "request_timeout_seconds":REQUEST_SECONDS,"profile_seconds":PROFILE_SECONDS,
        "readiness_seconds":READINESS_SECONDS,"cleanup_reserve_seconds":CLEANUP_SECONDS,"maximum_seconds":TOTAL_SECONDS}
    native = readiness_child = lock = helper = original = comparison = pcm_admission = admission_helper = None
    initialized = False
    handlers = {}
    specs = {}
    watchdog_stop, watchdog = threading.Event(), None
    watchdog_started = False
    watchdog_errors = []
    constructing = False
    def checkpoint():
        player.save(output / "result.json",report)
    def interrupted(signum,_frame):
        report["interruption_signal"] = signum
        if not constructing:
            raise KeyboardInterrupt
    def ac_lid(label):
        state = admission_helper.ac_lid()
        report.setdefault("AC_lid",[]).append({"phase":label,**state})
        player.require_trace(state["ready"], "AC/lid readiness changed: " + label)
    try:
        handlers = {sig:signal.signal(sig,interrupted) for sig in (signal.SIGINT,signal.SIGTERM)}
        checkpoint()
        player.verify_plan_files(plan,before_native)
        player.validate_build_result(plan)
        player.require_trace(player.read_command(["git","-C",str(player.SOURCE_ROOT),"rev-parse","HEAD"]) == plan["source_head"],
                             "Diagnostic source HEAD differs")
        original = player.load_frozen_module("pcm_original",player.ORIGINAL_PCM,player.ORIGINAL_PCM_SHA256)
        for name,(path,digest) in original.HELPERS.items():
            player.require_trace(path.is_file() and path.stat().st_size <= 128*1024
                and hashlib.sha256(path.read_bytes()).hexdigest() == digest,"Original PCM helper changed: " + name)
        comparison = original.load("comparison",original.HELPERS["comparison"][0])
        comparison.DIAGNOSTIC = Path(plan["assets"]["runtime"]["path"])
        retained = original.load("retained",original.HELPERS["retained"][0])
        specs = original_specs(plan,player,original,comparison,retained)
        report["pins_before"] = capture_plan_pins(plan,player,comparison,specs,before_native)
        proof,reference_pin = player.bounded_json(player.REFERENCE)
        player.require_trace(reference_pin["sha256"] == player.REFERENCE_SHA256,"Immutable baseline proof changed")
        expected = original.validate_reference(proof,player.FLASH_MODEL_SHA256)
        np, _UnusedNativeRuntime, prepared = comparison.prepare_cases(comparison.load_track_plan(before_native),before_native)
        cases = select_fixed_case(prepared)
        player.require_trace(list(cases) == [CASE],"Fixed one-case preparation differs")
        capture_module = player.load_frozen_module("attention_capture",BASE/"native_capture.py",plan["source_pins"]["capture"]["sha256"])
        NativeRuntime = capture_module.CapturedNativeRuntime
        for case_id,case in cases.items():
            player.require_trace(all(case[k] == expected[case_id][k] for k in
                ("input_sha256","shape","dtype","valid_frames","normalization")),"Exact normalized input differs: " + case_id)
        report["cases"] = [{k:v for k,v in cases[key].items() if k != "samples"} for key in player.PCM_CASE_IDS]
        helper,_ = player.load_cache_support()
        lock = helper.acquire_cache_lock(helper.capture_cache_parent(),before_native)
        seed,seed_pin = player.bounded_json(Path(plan["seed_proof"]["path"]))
        player.require_trace(seed_pin["sha256"] == plan["seed_proof"]["sha256"] and seed.get("cleanup_proven") is True
            and seed.get("pins_unchanged") is True and seed.get("shader_cache",{}).get("inventory_complete") is True
            and seed["shader_cache"]["post"]["manifest_sha256"] == plan["seed_manifest_sha256"],"Immutable seed proof differs")
        report["shader_cache"] = helper.prepare_phase(arm,seed["shader_cache"]["post"],before_native)
        # All substantial CPU reads precede the unchanged sampled-cool admission.
        report["full_hashes_before_readiness"] = capture_plan_pins(plan,player,comparison,specs,before_native)
        player.require_trace(report["full_hashes_before_readiness"] == report["pins_before"],"PCM setup changed planned pins")
        admission_helper = original.load("admission",retained.HELPERS["admission_source"][0])
        admission_helper.readiness_module()
        pcm_admission = original.load("pcm_admission",original.HELPERS["pcm_admission"][0])
        ac_lid("before_readiness")
        report["guard_before"] = player.guard_identity(Path(plan["assets"]["guard_script"]["path"]),Path(plan["assets"]["guard_unit"]["path"]))
        command = [plan["assets"]["python"]["path"],"-B","-c",
            "import runpy,sys;from pathlib import Path;sys.exit(runpy.run_path(sys.argv[1])['run']('admission',Path(sys.argv[2])))",
            str(original.HELPERS["pcm_admission"][0]),str(admission)]
        report["readiness_command"] = command
        with (admission / "stdout").open("x") as out,(admission / "stderr").open("x") as err:
            constructing = True
            try:
                readiness_child = subprocess.Popen(command,cwd=player.SOURCE_ROOT,stdout=out,stderr=err,start_new_session=True)
                report["readiness_identity"] = original.process_identity(readiness_child.pid,command)
            finally:
                constructing = False
            if "interruption_signal" in report:
                raise KeyboardInterrupt
            next_ac = 0
            while readiness_child.poll() is None:
                comparison.check_deadline(before_native)
                if time.monotonic() >= next_ac:
                    ac_lid("readiness")
                    next_ac = time.monotonic() + 45
                time.sleep(.25)
            player.require_trace(readiness_child.wait() == 0,"Original guarded PCM readiness failed")
        original.verify_pinned_metadata(comparison,report["full_hashes_before_readiness"],before_native)
        current_human = player.readiness(player.HUMAN,plan_pin)
        player.require_trace(current_human["pin"] == human["pin"],"Original combined approval changed")
        pcm_admission.validate_proof(json.loads((admission / "admission-pcm-ready.json").read_text()))
        report["admission"] = pcm_admission.fresh_admission(admission,admission_helper.ac_lid,before_native)
        player.require_trace(report["admission"].get("qualified") is False
            and report["admission"].get("admission_mode") == original.ADMISSION_MODE,"PCM admission scope differs")
        player.require_trace(player.guard_identity(Path(plan["assets"]["guard_script"]["path"]),Path(plan["assets"]["guard_unit"]["path"])) == report["guard_before"],"Guard changed before candidate launch")
        profile_started = time.monotonic()
        profile_deadline = min(deadline-CLEANUP_SECONDS,profile_started+PROFILE_SECONDS)
        environment = player.logger_environment(helper.cache_environment(os.environ,arm))
        environment.update(plan["logger_environment"])
        environment.update({player.TRACE_ENV_KEYS[0]:str(trace_directory / player.NATIVE_TRACE_NAME),
                            player.TRACE_ENV_KEYS[1]:output.name})
        changed = {k:v for k,v in environment.items() if os.environ.get(k) != v}
        saved = {k:os.environ.get(k) for k in changed}
        constructing = True
        report["native_construction_attempted"] = True
        try:
            try:
                os.environ.update(changed)
                native = NativeRuntime.__new__(NativeRuntime)
                NativeRuntime.__init__(native,comparison.DIAGNOSTIC,comparison.MODEL,"vulkan",2,
                    min(REQUEST_SECONDS,comparison.check_deadline(profile_deadline)),passive_openmp=True,
                    spool_directory=output / "native-spool",max_stderr_bytes=STDERR_LIMIT)
                initialized = True
            finally:
                for key,value in saved.items():
                    if value is None: os.environ.pop(key,None)
                    else: os.environ[key] = value
        finally:
            constructing = False
            report["native_started"] = getattr(native,"process",None) is not None
            report["native_construction_completed"] = initialized
        if "interruption_signal" in report:
            raise KeyboardInterrupt
        report["native_identity"] = original.process_identity(native.process.pid,
            [str(comparison.DIAGNOSTIC),"--model",str(comparison.MODEL),"--backend","vulkan","--threads","2"])
        def watch_native():
            while not watchdog_stop.wait(.05):
                try:
                    comparison.check_deadline(profile_deadline)
                    player.require_trace(not native.capture["overflow"] and not native.capture["read_errors"]
                        and not native.capture["write_errors"],"Native full capture failed")
                except Exception as error:
                    watchdog_errors.append(str(error));native.abort();return
        watchdog = threading.Thread(target=watch_native,name="drm-pcm-deadline",daemon=True)
        watchdog.start()
        watchdog_started = True
        ready = native.start()
        report["ready"] = ready
        player.require_trace(ready.get("backend") == "vulkan" and ready.get("threads") == 2
            and ready.get("pid") == native.process.pid and ready.get("fence_wait_mode") == "blocking"
            and ready.get("weight_storage") == "native" and ready.get("revision") == comparison.REVISION
            and ready.get("model") == str(comparison.MODEL)
            and ready.get("process_environment") == {"OMP_WAIT_POLICY":"PASSIVE","GOMP_SPINCOUNT":"0"},"Candidate ready context differs")
        for request_id,case_id in enumerate(player.PCM_CASE_IDS,1):
            ac_lid("before_request_" + str(request_id))
            native.timeout = min(REQUEST_SECONDS,comparison.check_deadline(profile_deadline))
            row = {"request_id":request_id,"case_id":case_id,"completed":False}
            report["requests"].append(row);checkpoint()
            try:
                produced,metrics = native.infer(cases[case_id]["samples"],request_id)
                player.require_trace(not watchdog_errors,"Native watchdog failed")
                for key in comparison.COMMON_TIMINGS+comparison.PHASE_TIMINGS:
                    comparison.validate_number(metrics,key)
                for key in comparison.SWITCH_COUNTS:
                    comparison.validate_number(metrics,key,integral=True)
                player.require_trace(produced.shape == (4,343980,2) and produced.dtype.str == "<f4"
                    and produced.flags.c_contiguous and np.isfinite(produced).all(),"Candidate PCM geometry/finite contract differs")
                input_pin,_ = comparison.inspect_file(native.root / "input.f32",343980*8,profile_deadline,
                    expected=expected[case_id]["input_sha256"])
                digest = hashlib.sha256(memoryview(produced)).hexdigest()
                original.verify_output_digest(digest,expected[case_id],case_id)
                row.update(input_sha256=input_pin["sha256"],output_sha256=digest,output_shape=list(produced.shape),
                    output_dtype=produced.dtype.str,output_bytes=produced.nbytes,completed=True,exact_pcm_match=True,
                    native_metrics=metrics)
                produced = None
            finally:
                original.cleanup_request(native,row);checkpoint()
            ac_lid("after_request_" + str(request_id))
        player.require_trace(report["requests"][0]["input_sha256"] == INPUT_SHA and report["requests"][0]["output_sha256"] == OUTPUT_SHA,"Fixed input/full output SHA differs")
        watchdog_stop.set();watchdog.join(timeout=min(2,comparison.check_deadline(deadline)))
        report["native_shutdown"] = native.idle_quit(completed_idle=True,deadline=min(deadline-15,time.monotonic()+2))
        player.require_trace(report["native_shutdown"]["graceful_complete"] is True,"Candidate did not quit/reap within original2s")
        report["capture"],captured = retain_captures(native,output,min(deadline-10,time.monotonic()+2))
        report["native_stderr"],report["native_stdout"] = captured["stderr"],captured["stdout"]
        player.require_trace(report["capture"]["complete"],"Native full capture incomplete")
        raw_stdout,_=read_file(output/"native.stdout",128*1024,report["native_stdout"])
        report["stdout_protocol"]=validate_stdout(raw_stdout,report["ready"],report["requests"][0]["native_metrics"])
        parser = player.load_frozen_module("attention_parser",BASE/"parse_attention.py",plan["source_pins"]["parser"]["sha256"])
        raw,_ = read_file(output/"native.stderr",STDERR_LIMIT,report["native_stderr"])
        report["attention"] = parser.parse_attention_output(raw,packed=arm=="packed")
        report["status"] = "passed"
    except KeyboardInterrupt:
        report["status"] = "interrupted"
    except Exception as error:
        report["status"] = "failed";report["errors"].append({"type":type(error).__name__,"message":str(error)[:8192]})
    finally:
        for sig in handlers:
            signal.signal(sig,signal.SIG_IGN)
        watchdog_stop.set()
        if watchdog_started:
            watchdog.join(timeout=max(0,min(2,deadline-time.monotonic())))
        report["watchdog_errors"] = watchdog_errors
        if readiness_child is not None:
            try:
                if readiness_child.poll() is None:
                    try: os.killpg(readiness_child.pid,signal.SIGKILL)
                    except ProcessLookupError: pass
                readiness_child.wait(timeout=max(0,min(3,deadline-time.monotonic())))
                report["cleanup"]["readiness_reaped"] = True
                report["cleanup"]["readiness_original_identity_absent"] = original.original_identity_absent(report["readiness_identity"])
            except Exception as error:
                report["errors"].append({"phase":"readiness_cleanup","message":str(error)})
        if native is not None and original is not None:
            try:
                captured={k:report['native_'+k] for k in ('stderr','stdout') if 'native_'+k in report}
                cleanup,stderr,errors,captured = cleanup_captured(native,initialized,output,original,deadline,captured)
                if hasattr(native,'capture'): report['capture']=native.capture_status()
                for key,value in captured.items(): report['native_'+key]=value
                report["cleanup"].update(cleanup);report["errors"].extend(errors)
                if stderr is not None: report["native_stderr"] = stderr
                if "native_identity" in report:
                    report["cleanup"]["native_original_identity_absent"] = original.original_identity_absent(report["native_identity"])
                    identity=report["native_identity"]
                    player.require_trace(identity["pid"]==identity["group"]==identity["session"],"Owned native session identity differs")
                    try:
                        os.killpg(identity["pid"],0)
                        report["cleanup"]["native_owned_group_absent"]=False
                    except ProcessLookupError:
                        report["cleanup"]["native_owned_group_absent"]=True
            except Exception as error:
                report["errors"].append({"phase":"native_cleanup","message":str(error)})
        report["cleanup"]["watchdog_joined"] = watchdog is None or not watchdog.is_alive()
        try:
            if specs:
                report["pins_after"] = capture_plan_pins(plan,player,comparison,specs,deadline,verify=False)
                report["pins_unchanged"] = report["pins_before"] == report["pins_after"]
            if "guard_before" in report:
                report["guard_after"] = player.guard_identity(Path(plan["assets"]["guard_script"]["path"]),Path(plan["assets"]["guard_unit"]["path"]))
            player.require_trace(player.read_command(["git","-C",str(player.SOURCE_ROOT),"rev-parse","HEAD"]) == plan["source_head"],"PCM source HEAD changed")
            if helper is not None and "shader_cache" in report:
                prepared = report["shader_cache"]
                report["shader_cache"]["post"] = helper.inventory(Path(prepared["cache_path"]),prepared["parent"],deadline,prepared["cache_identity"])
                report["shader_cache"]["inventory_complete"] = True
            if initialized and report.get("native_shutdown",{}).get("graceful_complete"):
                row = plan["source_pins"]["trace_validator"]
                validator = player.load_frozen_module("trace_validation",Path(row["path"]),row["sha256"])
                identity = {k:report["native_identity"][k] for k in ("pid","start_ticks")}
                report["native_trace"] = validator.native_trace(trace_directory / player.NATIVE_TRACE_NAME,
                    run_id=output.name,native_identity=identity,exit_code=report["native_shutdown"]["exit_code"],
                    deadline=deadline,expected_device=plan["drm_device"])
                player.require_trace(report["native_trace"]["request_ids"] == [1],"Candidate trace does not cover the sole request")
        except Exception as error:
            report["errors"].append({"phase":"finalization","message":str(error)})
        finally:
            if lock is not None:
                try:
                    lock.close()
                except Exception as error:
                    report["errors"].append({"phase":"cache_lock_close","message":str(error)})
        cleanup = report["cleanup"]
        report["cleanup_complete"] = all(cleanup.get(k) is True for k in ("native_reaped","native_resources_closed",
            "temporary_directory_removed","native_original_identity_absent","readiness_reaped",
            "readiness_original_identity_absent","watchdog_joined","native_owned_group_absent"))
        report["finished_monotonic"] = time.monotonic()
        report["elapsed_seconds"] = report["finished_monotonic"]-started
        report["within_wall_budget"] = report["finished_monotonic"] <= deadline
        if not (report["status"] == "passed" and report["cleanup_complete"] and report["pins_unchanged"]
            and report.get("guard_after") == report.get("guard_before") and not report["errors"] and not watchdog_errors
            and len(report["requests"]) == 1 and all(row.get("completed") is True for row in report["requests"])
            and report.get("native_trace",{}).get("passed") is True and report["within_wall_budget"]
            and report.get("shader_cache",{}).get("inventory_complete") is True
            and report.get("capture",{}).get("complete") is True and report.get("attention",{}).get("passed") is True
            and report.get("stdout_protocol",{}).get("passed") is True
            and report.get("native_stderr",{}).get("truncated") is False):
            report["status"] = "failed" if report["status"] != "interrupted" else "interrupted"
        report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        checkpoint()
        for sig,handler in handlers.items():
            signal.signal(sig,handler)
    return 0 if report["status"] == "passed" else 1



def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true')
    parser.add_argument('--arm',choices=ARMS)
    args=parser.parse_args()
    if not args.run:
        print(json.dumps({'status':'unarmed_dry_plan','host_queried':False,'native_started':False,
            'order':list(ARMS),'case_id':CASE,'original_seconds':600,'per_arm_seconds':300,
            'external_INT_seconds':270,'external_KILL_grace_seconds':30,'automatic_next_arm':False}))
        return 0
    require(args.arm in ARMS,'Explicit one arm required; no automatic pair')
    # These gates use only stdlib and pinned files; no helper import/host action on unarmed/missing inputs.
    plan,pin=load_plan(PLAN)
    human=readiness(HUMAN,pin)
    selected=json.loads(json.dumps(plan))
    selected['assets']['runtime']=selected['runtimes'][args.arm]
    player=load_player(selected,args.arm,pin,human)
    return run(player,selected,pin,human,args.arm)


if __name__=='__main__':
    raise SystemExit(main())
