# CONFLUX tests on Apollo

The environment is under `/srv/conflux-tests` on `apollo.kyaulabs`. It uses a separate Docker daemon, image store, containerd service and runtime state. Host packages, the default Docker configuration, existing Kairos/Hexforged workloads and GPU power settings were left unchanged. GPU access works through NVIDIA CDI without privileged containers. The native fallback was unnecessary.

Apollo exposes a GTX 1660 SUPER with 6 GiB VRAM, eight virtual CPUs and about 16 GiB RAM. The test image is `conflux-apollo-tests:20261027-02`, pinned by image ID in `receipts/test-image-build-02.json`. Installed package versions are in `receipts/packages-02.txt`.

The source snapshot is signed CONFLUX commit `894bcda423b75debc2f3a07d761d63b5083e5729`. The runtime uses pinned audio.cpp revision `0097d365a00b52a6991ad7618f0a04e8d2935e47`, the unchanged HTDemucs F16 model, blocking waits and the accepted full-F32 Flash path. It was rebuilt for Apollo's exposed CPU rather than copying the laptop's native binary.

| Check | Result |
| --- | --- |
| Best-quality Vulkan request | Finite four-stem output; ten full-F32 Flash nodes verified |
| Deck controller | 59 passed |
| Headless UI | 232 passed |
| Playback runner | 33 passed |
| Private virtual audio | Functional preparation, cancellation and recording checks passed; graph and daemon cleaned up |
| Worker throughput | 17 contiguous chunks; 4,140,105 frames; one persistent backend; no telemetry loss |
| Inclusive short-run service p99 | **16.742505 seconds**, above the unchanged **4.095-second** target |
| Subsequent 16 throughput hops | 0.548457–0.746602 seconds; descriptive range, with the first hop retained in the primary p99 |
| First delivered chunk | 18.227298 seconds |
| Forward/backward seeks | 1.557121 / 1.487720 seconds; exact same-grid sample parity |
| Source replacement | 5.465216 seconds |
| Cancellation acknowledgements | 0.052547 ms during inference; 0.096182 ms under backpressure; no stale chunks delivered |
| Active-request shutdown | 221.323 ms; supervisor closed and backend retired |
| GPU observations | 60°C peak, 447 MiB peak used VRAM; existing 130 W limit unchanged |

The initial GPU delay dominates this short run. Its cause has not been isolated. These are worker-only timings and headless functional checks. M2's actual-player and sustained audio/UI gates remain open; this run provides no musical or laptop qualification.

The original `checks-01` failure records are retained. Its UI wrapper allowed 90 seconds instead of the repository's 180; the suite subsequently passed in 145.6 seconds. A post-run wrapper assertion also compared `4094.9999999999995` with `4095.0` using exact equality after the worker had saved its successful functional result. `receipts/worker-assessment-01.json` verifies that unchanged dataset and retains its failed latency verdict. GPU inference was not repeated to correct the annotation.

Use the private daemon explicitly:

```sh
sudo -n env DOCKER_CONFIG=/srv/conflux-tests/docker-client \
  docker --host unix:///srv/conflux-tests/daemon/docker.sock ps -a
```

The current-boot services are `conflux-tests-docker.service` and `conflux-tests-containerd.service`. Images, builds, configuration and results persist under `/srv/conflux-tests`; the transient services do not start automatically after reboot. Saved recipes use separate result directories to preserve prior evidence.
