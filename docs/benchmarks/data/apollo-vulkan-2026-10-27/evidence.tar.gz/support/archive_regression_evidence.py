from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import tarfile

assert os.geteuid() == 0
root = Path('/srv/conflux-tests')
private = ['docker', '--host', 'unix:///srv/conflux-tests/daemon/docker.sock']

def call(command):
    return subprocess.check_output(command, text=True, stderr=subprocess.PIPE, timeout=20)

protected = []
for ident in call(['docker', 'ps', '-aq']).split():
    fmt = '{{json .Id}}\n{{json .Name}}\n{{json .Config.Labels}}\n{{json .State.Status}}\n{{json .State.StartedAt}}\n{{json .State.Pid}}\n{{json .RestartCount}}'
    values = [json.loads(line) for line in call(['docker', 'inspect', '--format', fmt, ident]).splitlines()]
    if any(s in (values[1] + json.dumps(values[2])).lower() for s in ('kairos', 'hexforged')):
        protected.append(dict(zip(('id', 'name', 'labels', 'status', 'started_at', 'pid', 'restart_count'), values)))
config = Path('/etc/docker/daemon.json')
after = {'containers': sorted(protected, key=lambda x: x['id']),
         'daemon_id': call(['docker', 'info', '--format', '{{.ID}}']).strip(),
         'daemon_data_root': call(['docker', 'info', '--format', '{{.DockerRootDir}}']).strip(),
         'daemon_config_sha256': hashlib.sha256(config.read_bytes()).hexdigest() if config.exists() else None}
assert after == json.loads((root / 'receipts/protected-before-01.json').read_text())

assert call(private + ['ps', '-aq']).strip() == ''
assert call(['ctr', '--address', '/srv/conflux-tests/containerd/state/containerd.sock', '--namespace', 'conflux-tests', 'tasks', 'list', '--quiet']).strip() == ''
assert call(['nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader,nounits']).strip() == ''
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protected_workloads_and_default_docker_unchanged':True,'no_test_container_task_or_gpu_compute_job_remains':True,'host_packages_changed':False,'gpu_power_policy_changed':False,'private_services_retained':{name:call(['systemctl','show',name,'--property=ActiveState,MainPID,InvocationID']) for name in ['conflux-tests-docker.service','conflux-tests-containerd.service']}}
(root/'receipts/cache-player-final-verification-02.json').write_text(json.dumps(receipt,indent=2)+'\n')

selected=set()
for name in ['private-player-regression-01','private-player-regression-02','private-player-regression-03']:
    for p in (root/'work'/name).rglob('*'):
        if p.is_file() and not p.is_symlink() and p.suffix in {'.json','.jsonl','.log','.conf'} and 'cache' not in p.parts:
            raw=p.read_bytes();raw.decode('utf-8');assert len(raw)<=2*1024**2
            selected.add(p)
selected.add(root/'receipts/cache-player-final-verification-02.json')
manifest=root/'receipts/regression-evidence-manifest-03.json'
manifest.write_text(json.dumps({'files':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(selected)]},indent=2)+chr(10))
selected.add(manifest)
archive=root/'regression-evidence-20261027-03.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
    for p in sorted(selected):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
os.chown(archive,1000,1000);os.chmod(archive,0o640)
print(json.dumps({'path':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(selected)}),flush=True)
