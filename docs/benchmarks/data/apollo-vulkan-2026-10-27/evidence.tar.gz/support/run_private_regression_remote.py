
from pathlib import Path
import subprocess,json,hashlib,time,datetime
root=Path('/srv/conflux-tests'); work=root/'work'; output=work/'private-player-regression-01';output.mkdir(mode=0o750)
docker=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert subprocess.check_output(docker+['ps','-aq'],text=True).strip()==''
image=json.loads((root/'receipts/test-image-build-02.json').read_text())['image_id']
sha=hashlib.sha256((work/'native-private-player-01/player/conflux-manual-playback-soak').read_bytes()).hexdigest()
inside="""from pathlib import Path
import subprocess,os,json,time
Path('/tmp/conflux-regression-runtime').mkdir(mode=0o700)
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software',QT_QUICK_CONTROLS_STYLE='Basic',XDG_RUNTIME_DIR='/tmp/conflux-regression-runtime')
commands=[['python','-B','/src/tests/manual_playback_hour_test.py'],['python','-B','/src/tools/experiments/private_routing_check.py','/build/player/conflux-preparation-controller-check','/results/short-controls','--functional-only','--ui-controls-soak','/build/player/conflux-manual-playback-soak','BINARY_SHA']]
report=[]
for index,command in enumerate(commands):
    began=time.monotonic()
    with Path('/results/check-'+str(index)+'.log').open('x') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
    report.append({'command':command,'exit':r.returncode,'seconds':time.monotonic()-began})
    if r.returncode:break
Path('/results/result.json').write_text(json.dumps({'checks':report,'passed':len(report)==2 and all(x['exit']==0 for x in report),'real_model_started':False,'host_audio':False},indent=2)+'\n')
raise SystemExit(0 if len(report)==2 and all(x['exit']==0 for x in report) else 1)
""".replace('BINARY_SHA',sha)
name='conflux-private-player-regression-20261027-01'
command=docker+['run','--rm','--name',name,'--init','--label','org.kyaulabs.conflux.tests=1','--label','org.kyaulabs.conflux.run=private-player-regression-01','--network','none','--cap-drop','ALL','--security-opt','no-new-privileges:true','--memory','8g','--pids-limit','1024','--mount',f'type=bind,src={work/"source-private-player-01"},dst=/src,readonly','--mount',f'type=bind,src={work/"native-private-player-01"},dst=/build,readonly','--mount',f'type=bind,src={output},dst=/results',image,'timeout','--signal=TERM','--kill-after=5s','200','python','-c',inside]
try:
    with (output/'container.log').open('x') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=220)
    result=json.loads((output/'result.json').read_text());print(json.dumps(result),flush=True)
finally:
    found=subprocess.run(docker+['inspect','--format','{{json .Config.Labels}}',name],text=True,capture_output=True,timeout=10)
    if found.returncode==0:
        assert json.loads(found.stdout).get('org.kyaulabs.conflux.run')=='private-player-regression-01'
        subprocess.run(docker+['rm','--force',name],check=True,capture_output=True,timeout=15)
    assert subprocess.check_output(docker+['ps','-aq'],text=True).strip()==''
raise SystemExit(p.returncode)
