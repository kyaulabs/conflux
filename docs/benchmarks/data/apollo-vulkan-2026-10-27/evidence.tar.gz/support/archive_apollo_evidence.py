from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import tarfile

assert os.geteuid() == 0
root = Path('/srv/conflux-tests')
private = ['docker', '--host', 'unix:///srv/conflux-tests/daemon/docker.sock']

def call(command):
    return subprocess.check_output(command, text=True, stderr=subprocess.PIPE, timeout=20)

protected = []
for ident in call(['docker', 'ps', '-aq']).split():
    fmt = '{{json .Id}}\n{{json .Name}}\n{{json .Config.Labels}}\n{{json .State.Status}}\n{{json .State.StartedAt}}\n{{json .State.Pid}}\n{{json .RestartCount}}'
    values = [json.loads(line) for line in call(['docker', 'inspect', '--format', fmt, ident]).splitlines()]
    if any(s in (values[1] + json.dumps(values[2])).lower() for s in ('kairos', 'hexforged')):
        protected.append(dict(zip(('id', 'name', 'labels', 'status', 'started_at', 'pid', 'restart_count'), values)))
config = Path('/etc/docker/daemon.json')
after = {'containers': sorted(protected, key=lambda x: x['id']),
         'daemon_id': call(['docker', 'info', '--format', '{{.ID}}']).strip(),
         'daemon_data_root': call(['docker', 'info', '--format', '{{.DockerRootDir}}']).strip(),
         'daemon_config_sha256': hashlib.sha256(config.read_bytes()).hexdigest() if config.exists() else None}
assert after == json.loads((root / 'receipts/protected-before-01.json').read_text())

assert call(private + ['ps', '-aq']).strip() == ''
assert call(['ctr', '--address', '/srv/conflux-tests/containerd/state/containerd.sock', '--namespace', 'conflux-tests', 'tasks', 'list', '--quiet']).strip() == ''
assert call(['nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader,nounits']).strip() == ''
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protected_workloads_and_default_docker_unchanged':True,'no_test_container_task_or_gpu_compute_job_remains':True,'host_packages_changed':False,'gpu_power_policy_changed':False,'private_services_retained':{name:call(['systemctl','show',name,'--property=ActiveState,MainPID,InvocationID']) for name in ['conflux-tests-docker.service','conflux-tests-containerd.service']}}
(root/'receipts/cache-player-final-verification-02.json').write_text(json.dumps(receipt,indent=2)+'\n')
selected=set()
for name in ['cold-start-01','cold-start-explicit-01','cold-start-explicit-02','cached-worker-01','private-player-01','private-player-02','private-player-03']:
    directory=root/'work'/name
    assert directory.is_dir(),name
    for path in directory.rglob('*'):
        if path.is_file() and not path.is_symlink() and not any(part in ('driver-cache','.cache') for part in path.parts) and path.suffix in {'.json','.jsonl','.log','.csv','.conf','.py','.cpp'}:
            raw=path.read_bytes();raw.decode('utf-8');assert len(raw)<=4*1024**2,str(path)
            selected.add(path)
for name in ['source-private-player-01.json','private-player-build-01.json','private-player-build-02.json','private-player-build-01.log','private-player-build-02.log','build_private_player_remote.py','build_private_player_remote_02.py','actual_player_check.py','actual_player_controls_120.py','run_private_player_inside.py','run_private_player_remote.py','run_private_player_remote_02.py','run_private_player_remote_03.py','probe_cache_inside.py','worker_cache_inside.py']:
    p=root/'work'/name
    if p.is_file():selected.add(p)
selected.add(root/'receipts/cache-player-final-verification-02.json')
files=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(selected)]
assert sum(f['bytes'] for f in files)<16*1024**2
manifest=root/'receipts/evidence-manifest-02.json'
manifest.write_text(json.dumps({'files':files,'model_media_binaries_and_driver_cache_payloads_included':False},indent=2)+'\n')
selected.add(manifest)
archive=root/'evidence-20261027-02.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
    for p in sorted(selected):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
os.chown(archive,1000,1000);os.chmod(archive,0o640)
result={'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'text_files':len(selected)}
(root/'receipts/evidence-archive-02.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verification':receipt,'archive':result}),flush=True)
