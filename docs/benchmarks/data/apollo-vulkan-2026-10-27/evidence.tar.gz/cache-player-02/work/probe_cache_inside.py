from pathlib import Path
import datetime
import hashlib
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, '/src')
from tools.stems.worker import NativeRuntime, WINDOW

root = Path('/results')
report = {'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Two raw native requests per fresh process; diagnostic, not worker/player p99',
          'cache_environment': {key: os.environ.get(key) for key in
               ['HOME', 'XDG_CACHE_HOME', '__GL_SHADER_DISK_CACHE', '__GL_SHADER_DISK_CACHE_PATH']},
          'requests': [], 'latency_qualified': False}
runtime = None
code = 1
try:
    runtime = NativeRuntime(Path('/build/runtime/conflux-stem-runtime'), Path('/model/htdemucs-f16.gguf'),
                            'vulkan', 2, 30, max_stderr_bytes=65536)
    report['ready'] = runtime.start()
    assert report['ready']['backend'] == 'vulkan' and report['ready']['fence_wait_mode'] == 'blocking'
    samples = np.random.default_rng(0).standard_normal((WINDOW, 2), dtype=np.float32) * np.float32(0.1)
    report['input_sha256'] = hashlib.sha256(samples.tobytes()).hexdigest()
    assert report['input_sha256'] == '0e24d3f707cc96a3f7cc1d68a6dc84556c5d600f72f529acf4b10b59b1b3d1be'
    for request_id in [1, 2]:
        started = time.monotonic()
        output, native = runtime.infer(samples, request_id)
        elapsed = (time.monotonic() - started) * 1000
        output_sha = hashlib.sha256(output.tobytes()).hexdigest()
        row = {'request_id': request_id, 'round_trip_ms': elapsed, 'native': native,
               'output_sha256': output_sha, 'finite': bool(np.isfinite(output).all()),
               'shape': list(output.shape)}
        report['requests'].append(row)
        assert row['finite'] and row['shape'] == [4, WINDOW, 2]
        assert output_sha == '5f2763cfb306cd145c63077e9ee6daa5a874681db89eb9d995fb6617fd1dd18b'
        (root / 'progress.json').write_text(json.dumps(row, indent=2) + '\n')
    runtime._flush_diagnostics()
    diagnostic = Path(runtime.stderr.name).read_text()
    assert 'flash_nodes=10' in diagnostic and 'intermediate_bytes=4 accumulation_bytes=4' in diagnostic
    report.update(status='ok', full_f32_flash_verified=True)
    code = 0
except Exception as error:
    report.update(status='error', error=str(error))
finally:
    if runtime is not None:
        try:
            runtime._flush_diagnostics()
            (root / 'runtime.stderr').write_bytes(Path(runtime.stderr.name).read_bytes())
            runtime.close()  # Match the current product's kill/wait close policy.
            report['native_reaped'] = runtime.process.poll() is not None
            assert report['native_reaped']
        except Exception as error:
            report.update(status='error', cleanup_error=str(error))
            code = 1
    report['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (root / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
raise SystemExit(code)
