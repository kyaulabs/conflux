from pathlib import Path
from types import SimpleNamespace
import json
import sys

sys.path[:0] = ['/src', '/src/tools/benchmarks']
from stem_worker import Run
from worker_support import create_fixture
from tools.stems.worker import HOP, RATE

root = Path('/results/worker-cache-01')
root.mkdir(mode=0o750)
args = SimpleNamespace(runtime=Path('/build/runtime/conflux-stem-runtime'),
                       model=Path('/model/htdemucs-f16.gguf'), threads=2, request_timeout=30,
                       load_mode='none', renderer='software', trace_system=False,
                       ui=Path('/build/player/conflux'), audio_probe=Path('/build/player/conflux-audio-probe'),
                       quantum=256, hops=16)
fixture = create_fixture(root / 'source.wav', (args.hops * HOP + 12345) / RATE)
alternate = create_fixture(root / 'replacement.wav', (6 * HOP + 77) / RATE, seed=11)
try:
    result = Run(args, root, fixture, alternate).execute()
    result['apollo_scope'] = {
        'host': 'apollo.kyaulabs', 'gpu': 'NVIDIA GeForce GTX 1660 SUPER',
        'source_commit': '894bcda423b75debc2f3a07d761d63b5083e5729',
        'load_mode': 'worker only; no audio output or UI workload',
        'input': 'synthetic fixture, not a musical acceptance corpus',
        'latency_target_ms': 4095, 'laptop_or_actual_player_qualified': False,
        'gpu_power_limit_changed': False,
    }
    assert abs(result.get('throughput', {}).get('headroom_target_ms', 0) - 4095.0) < 1e-9
    (root / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
finally:
    for name in ('source.wav', 'replacement.wav'):
        (root / name).unlink(missing_ok=True)
print(json.dumps({k: result[k] for k in ('status', 'error', 'throughput', 'controls', 'worker_statistics',
                                       'stale_chunks_delivered', 'runtime_ready', 'apollo_scope') if k in result}), flush=True)
raise SystemExit(0 if result['status'] == 'ok' else 1)
