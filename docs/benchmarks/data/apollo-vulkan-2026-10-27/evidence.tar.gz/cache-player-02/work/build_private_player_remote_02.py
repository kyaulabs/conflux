from pathlib import Path
import datetime, hashlib, json, subprocess, tarfile, time

root = Path('/srv/conflux-tests')
work = root / 'work'
source = work / 'source-private-player-01'
build = work / 'native-private-player-01'
receipt_path = work / 'private-player-build-02.json'
assert not receipt_path.exists() and source.is_dir() and build.is_dir()
binding = json.loads((work / 'source-private-player-01.json').read_text())
archive = work / 'source-private-player-01.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == binding['sha256']
# Retain the first build; only touch the copied candidate's changed source.
(source / binding['dirty_overlay']['path']).touch()
assert hashlib.sha256((source / binding['dirty_overlay']['path']).read_bytes()).hexdigest() == binding['dirty_overlay']['sha256']
previous_binary_sha256 = hashlib.sha256((build / 'player/conflux-manual-playback-soak').read_bytes()).hexdigest()
docker = ['sudo', '-n', 'env', 'DOCKER_CONFIG=/srv/conflux-tests/docker-client', 'docker',
          '--host', 'unix:///srv/conflux-tests/daemon/docker.sock']
assert not subprocess.check_output(docker + ['ps', '-aq'], text=True).strip()
image = json.loads((root / 'receipts/test-image-build-02.json').read_text())['image_id']
inside = r'''
from pathlib import Path
import hashlib, json, os, subprocess, tempfile, time
receipt={'steps':[],'model_or_audio_started':False}
changed=Path('/src/tools/experiments/manual_playback_soak.cpp')
assert '--private-live-stems-controls' in changed.read_text()
for command in [
 ['cmake','-S','/src','-B','/build/player','-G','Ninja','-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCONFLUX_BUILD_UI=ON','-DBUILD_TESTING=ON','-DPython3_EXECUTABLE=/usr/bin/python3'],
 ['cmake','--build','/build/player','--parallel','2','--target','conflux-manual-playback-soak']]:
    began=time.monotonic()
    result=subprocess.run(command,timeout=360)
    receipt['steps'].append({'command':command,'exit':result.returncode,'seconds':time.monotonic()-began})
    result.check_returncode()
binary=Path('/build/player/conflux-manual-playback-soak')
assert b'--private-live-stems-controls' in binary.read_bytes(), 'Private mode absent from executable'
with tempfile.TemporaryDirectory(prefix='conflux-mode-proof-') as temporary:
    directory=Path(temporary); directory.chmod(0o700)
    output=directory/'output'; output.mkdir(mode=0o700); (output/'cache').mkdir(mode=0o700)
    environment=dict(os.environ,QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software',XDG_RUNTIME_DIR=str(directory),XDG_CACHE_HOME=str(output/'cache'))
    for key in ['CONFLUX_ALLOW_HOST_SOAK','CONFLUX_PRIVATE_ROUTING_CHECK']:
        environment.pop(key,None)
    scenarios=[
      ('private-mode-needs-private-context','--private-live-stems-controls','120',{}),
      ('host-opt-in-cannot-authorize-private-mode','--private-live-stems-controls','120',{'CONFLUX_ALLOW_HOST_SOAK':'1'}),
      ('private-mode-lower-bound','--private-live-stems-controls','119',{'CONFLUX_PRIVATE_ROUTING_CHECK':'1'}),
      ('private-mode-upper-bound','--private-live-stems-controls','121',{'CONFLUX_PRIVATE_ROUTING_CHECK':'1'}),
      ('private-mode-rejects-invalid-duration','--private-live-stems-controls','bad',{'CONFLUX_PRIVATE_ROUTING_CHECK':'1'}),
      ('old-fixture-limit-remains-ten-seconds','--live-stems-controls','120',{'CONFLUX_PRIVATE_ROUTING_CHECK':'1'}),
      ('private-mode-needs-owned-socket','--private-live-stems-controls','120',{'CONFLUX_PRIVATE_ROUTING_CHECK':'1','PIPEWIRE_RUNTIME_DIR':str(directory),'PIPEWIRE_REMOTE':'conflux-private-routing-missing'}),
      ('host-mode-still-rejects-offscreen','--live-stems-controls','120',{'CONFLUX_ALLOW_HOST_SOAK':'1'})]
    receipt['rejection_checks']=[]
    for label,mode,seconds,updates in scenarios:
        command=[str(binary),mode,'/missing-source','/missing-peer',str(output),seconds,str(output/'stop'),'/usr/bin/python','/missing-exporter','/missing-worker','/missing-service','/missing-runtime','/missing-model']
        result=subprocess.run(command,env=environment|updates,text=True,capture_output=True,timeout=8)
        receipt['rejection_checks'].append({'name':label,'exit':result.returncode,'stderr':result.stderr[:2048],'passed':result.returncode==2})
        assert result.returncode==2,label
        assert 'Usage:' not in result.stderr, 'Unrecognized mode is not a valid rejection proof: '+label
        if label=='private-mode-needs-owned-socket':
            assert 'Explicit owned private PipeWire runtime/socket required' in result.stderr, 'Private mode failed before socket guard'
    assert not list(output.iterdir()) or list(output.iterdir())==[output/'cache']
receipt['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
Path('/build/private-mode-build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
'''
name = 'conflux-private-player-build-20261027-02'
command = docker + ['run', '--rm', '--name', name, '--init', '--label', 'org.kyaulabs.conflux.tests=1',
    '--label', 'org.kyaulabs.conflux.run=private-player-build-02', '--network', 'none', '--cap-drop', 'ALL',
    '--security-opt', 'no-new-privileges:true', '--memory', '8g', '--pids-limit', '1024',
    '--mount', f'type=bind,src={source},dst=/src,readonly', '--mount', f'type=bind,src={build},dst=/build',
    image, 'timeout', '--signal=TERM', '--kill-after=5s', '540', 'python', '-c', inside]
receipt = {'source': binding, 'image_id': image, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'original_binaries_modified': False, 'stale_candidate_sha256': previous_binary_sha256}
try:
    with (work / 'private-player-build-02.log').open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=565)
    receipt['exit'] = result.returncode
    if result.returncode == 0:
        receipt['checks'] = json.loads((build / 'private-mode-build-receipt.json').read_text())
        assert receipt['checks']['binary_sha256'] != previous_binary_sha256
finally:
    found = subprocess.run(docker + ['inspect', '--format', '{{json .Config.Labels}}', name], text=True, capture_output=True, timeout=10)
    if found.returncode == 0:
        assert json.loads(found.stdout).get('org.kyaulabs.conflux.run') == 'private-player-build-02'
        subprocess.run(docker + ['rm', '--force', name], capture_output=True, check=True, timeout=20)
    receipt['remaining_containers'] = subprocess.check_output(docker + ['ps', '-aq'], text=True).split()
    assert receipt['remaining_containers'] == []
    receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(receipt.get('exit', 1))
