from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, time

root = Path('/srv/conflux-tests')
work = root / 'work'
case = work / 'private-player-03'
case.mkdir(mode=0o750)
seed = work / 'cold-start-explicit-02/home-a/driver-cache'
seed_result = json.loads((work / 'cold-start-explicit-02/result.json').read_text())
assert len(seed_result['cases']) == 2 and all(row['exit'] == 0 for row in seed_result['cases'])
for row in seed_result['cases'][-1]['home_after']:
    p = seed.parent / row['path']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256']
shutil.copytree(seed, case / 'driver-cache')
build = json.loads((work / 'native-03/build-receipt-01.json').read_text())
for row in build['artifacts']:
    p = work / 'native-03' / Path(row['path']).relative_to('/build')
    assert hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256']
candidate = json.loads((work / 'private-player-build-02.json').read_text())
assert candidate['exit'] == 0 and all(x['passed'] for x in candidate['checks']['rejection_checks'])
assert hashlib.sha256((work / 'native-private-player-01/player/conflux-manual-playback-soak').read_bytes()).hexdigest() == candidate['checks']['binary_sha256']
assert hashlib.sha256((work / 'source-private-player-01/tools/experiments/manual_playback_soak.cpp').read_bytes()).hexdigest() == candidate['source']['dirty_overlay']['sha256']
assert hashlib.sha256((work / 'htdemucs-f16.gguf').read_bytes()).hexdigest() == 'f8c54ba35df95aafea7881eac214b58ec18a73cbcb6ff5a90f4b762631a286b6'
docker = ['sudo', '-n', 'env', 'DOCKER_CONFIG=/srv/conflux-tests/docker-client', 'docker',
          '--host', 'unix:///srv/conflux-tests/daemon/docker.sock']
assert subprocess.check_output(docker + ['ps', '-aq'], text=True).strip() == ''
assert subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader,nounits'], text=True).strip() == ''
image = json.loads((root / 'receipts/test-image-build-02.json').read_text())['image_id']
container = 'conflux-private-player-20261027-03'
command = docker + ['run', '--rm', '--name', container, '--init',
    '--label', 'org.kyaulabs.conflux.tests=1', '--label', 'org.kyaulabs.conflux.run=private-player-03',
    '--network', 'none', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges:true',
    '--pids-limit', '1024', '--memory', '8g', '--device', 'nvidia.com/gpu=GPU-c58fa4ef-cda8-be9f-eb37-caeb7cf7d42b',
    '--env', '__GL_SHADER_DISK_CACHE=1', '--env', '__GL_SHADER_DISK_CACHE_PATH=/home/conflux/driver-cache',
    '--mount', f'type=bind,src={case / "driver-cache"},dst=/home/conflux/driver-cache',
    '--mount', f'type=bind,src={work / "source-private-player-01"},dst=/src,readonly',
    '--mount', f'type=bind,src={work / "native-private-player-01"},dst=/build,readonly',
    '--mount', f'type=bind,src={work / "htdemucs-f16.gguf"},dst=/model/htdemucs-f16.gguf,readonly',
    '--mount', f'type=bind,src={case},dst=/results',
    '--mount', f'type=bind,src={work / "run_private_player_inside.py"},dst=/operations/check.py,readonly',
    '--mount', f'type=bind,src={work / "actual_player_controls_120.py"},dst=/operations/actual_player_check.py,readonly',
    image, 'timeout', '--signal=TERM', '--kill-after=5s', '290', 'python', '/operations/check.py']
receipt = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': command,
           'source_binding': candidate['source'], 'scope': 'Two-minute private virtual audio/offscreen actual-model player controls diagnostic only',
           'qualified': False, 'gpu_power_policy_changed': False}
monitor = None
try:
    with (case / 'gpu-observations.csv').open('x') as log:
        monitor = subprocess.Popen(['nvidia-smi', '--query-gpu=timestamp,temperature.gpu,power.draw,power.limit,utilization.gpu,memory.used',
                                    '--format=csv,noheader,nounits', '--loop-ms=1000'], stdout=log, stderr=log)
        with (case / 'container.log').open('x') as output:
            process = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, timeout=315)
        receipt['exit'] = process.returncode
        p = case / 'private-player-01/recordings/actual-player/assessment.json'
        if p.exists():
            receipt['assessment'] = json.loads(p.read_text())
finally:
    found = subprocess.run(docker + ['inspect', '--format', '{{json .Config.Labels}}', container], text=True, capture_output=True, timeout=10)
    if found.returncode == 0:
        assert json.loads(found.stdout).get('org.kyaulabs.conflux.run') == 'private-player-03'
        subprocess.run(docker + ['rm', '--force', container], check=True, capture_output=True, timeout=20)
    if monitor is not None:
        monitor.terminate()
        try:
            monitor.wait(timeout=5)
        except subprocess.TimeoutExpired:
            monitor.kill()
            monitor.wait(timeout=5)
    receipt['remaining_containers'] = subprocess.check_output(docker + ['ps', '-aq'], text=True).split()
    assert receipt['remaining_containers'] == []
    receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (case / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(receipt.get('exit', 1))
