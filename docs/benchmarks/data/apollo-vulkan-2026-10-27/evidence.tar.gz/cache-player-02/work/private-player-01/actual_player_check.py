#!/usr/bin/python
from pathlib import Path
import json, os, signal, stat, subprocess, sys, time, wave
import numpy as np
sys.path[:0] = ['/src', '/src/tools/benchmarks']
from worker_support import create_fixture

if len(sys.argv) != 4 or sys.argv[3] != '--functional-only' or os.environ.get('CONFLUX_PRIVATE_ROUTING_CHECK') != '1':
    raise SystemExit('Private functional routing only')
runtime = Path(sys.argv[1])
output = Path(sys.argv[2]) / 'actual-player'
output.mkdir(mode=0o700)
(output / 'cache').mkdir(mode=0o700)
assert runtime.is_absolute() and runtime.stat().st_uid == os.getuid() and stat.S_IMODE(runtime.stat().st_mode) == 0o700
source = create_fixture(output / 'generated-source.wav', 3)
peer = output / 'generated-peer.wav'
with wave.open(str(peer), 'wb') as stream:
    stream.setparams((2, 2, 48000, 30 * 48000, 'NONE', 'not compressed'))
    for block in range(30):
        t = (np.arange(48000) + block * 48000) / 48000
        pcm = np.column_stack((.02 * np.sin(2 * np.pi * 220 * t), .015 * np.sin(2 * np.pi * 330 * t)))
        stream.writeframesraw(np.rint(pcm * 32767).astype('<i2').tobytes())
report = {'scope': 'Ten-second actual Best-quality model/controller check on private virtual audio and offscreen software UI; no sustained, physical or laptop qualification',
          'source': source, 'passed': False, 'qualified': False, 'host_audio': False}
child = sink = None
try:
    with (output / 'sink.stdout.log').open('x') as out, (output / 'sink.stderr.log').open('x') as err:
        sink = subprocess.Popen(['/results/private_sink'], stdin=subprocess.PIPE, stdout=out, stderr=err, text=True)
        until = time.monotonic() + 8
        while time.monotonic() < until:
            if sink.poll() is not None:
                raise RuntimeError('Private sink exited')
            graph = json.loads(subprocess.check_output(['pw-dump', '-r', os.environ['PIPEWIRE_REMOTE'], '-N'], text=True, timeout=3))
            nodes = [p for p in graph if p.get('type', '').endswith(':Node') and
                     p.get('info', {}).get('props', {}).get('node.name') == 'conflux-short-live-test-sink']
            if len(nodes) == 1:
                break
            time.sleep(.05)
        else:
            raise TimeoutError('Owned sink did not appear')
        assert str(nodes[0]['info']['props'].get('application.process.id')) == str(sink.pid)
        environment = dict(os.environ, QT_QPA_PLATFORM='offscreen', QT_QUICK_BACKEND='software',
                           QT_QUICK_CONTROLS_STYLE='Basic', XDG_CACHE_HOME=str(output / 'cache'))
        environment.pop('CONFLUX_ALLOW_HOST_SOAK', None)
        command = ['/build/player/conflux-manual-playback-soak', '--live-stems', source['path'], str(peer), str(output), '10',
                   str(output / 'stop'), '/usr/bin/python', '/src/tools/stems/export.py', '/src/tools/stems/worker.py',
                   '/src/tools/stems/service.py', '/build/runtime/conflux-stem-runtime', '/model/htdemucs-f16.gguf']
        report['command'] = command
        began = time.monotonic()
        with (output / 'player.stdout.log').open('x') as out, (output / 'player.stderr.log').open('x') as err:
            child = subprocess.Popen(command, env=environment, stdout=out, stderr=err, start_new_session=True)
            try:
                child.wait(timeout=150)
            except subprocess.TimeoutExpired:
                (output / 'stop').touch()
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        child.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait(timeout=3)
                raise TimeoutError('Native player exceeded fixed 150-second bound')
        report['native_exit'] = child.returncode
        report['elapsed_seconds'] = time.monotonic() - began
        native = json.loads((output / 'native-result.json').read_text())
        report['native_summary'] = {k: native[k] for k in ['mode', 'functional_only', 'host_audio', 'qualified', 'passed', 'error',
            'measurement_completion_error', 'setup', 'measured_wall_ms', 'frames_presented', 'maximum_gui_heartbeat_gap_ns',
            'steady_starved_frames', 'control_starved_frames', 'eof_count', 'replay_count', 'last_recovery_complete',
            'execution_deadline_misses', 'invalid_buffers', 'source_read_failures', 'shutdown_completed', 'diagnostic_tail',
            'configuration', 'observation_counters'] if k in native}
        report['passed'] = child.returncode == 0 and native.get('passed') is True and native.get('functional_only') is True and \
            native.get('host_audio') is False and native.get('qualified') is False and native.get('shutdown_completed') is True
except Exception as error:
    report['error'] = str(error)
finally:
    if child is not None and child.poll() is None:
        os.killpg(child.pid, signal.SIGKILL)
        child.wait(timeout=5)
    if sink is not None:
        if sink.poll() is None:
            sink.stdin.write('stop\n')
            sink.stdin.flush()
            sink.stdin.close()
            try:
                sink.wait(timeout=5)
            except subprocess.TimeoutExpired:
                sink.terminate()
                sink.wait(timeout=5)
        report['sink_reaped'] = sink.poll() is not None
    for path in [Path(source['path']), peer]:
        path.unlink(missing_ok=True)
    (output / 'assessment.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
raise SystemExit(0 if report['passed'] else 1)
