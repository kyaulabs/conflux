from pathlib import Path
import hashlib, json, os, shlex, subprocess, time

source = Path('/src/tools/experiments/preparation_controller_check.cpp').read_text()
sink = source.split('class Sink {', 1)[1].split('QJsonObject inspectStemRecording', 1)[0]
assert sink.rstrip().endswith('};')
prefix = '''#include <pipewire/filter.h>
#include <pipewire/pipewire.h>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>
#include <poll.h>
#include <sys/stat.h>
#include <unistd.h>
constexpr std::array<float, 2> expected{.125F, -.0625F};
class Sink {'''
main = r'''
int main() {
    const char* check = std::getenv("CONFLUX_PRIVATE_ROUTING_CHECK");
    const char* runtime = std::getenv("XDG_RUNTIME_DIR");
    const char* remote = std::getenv("PIPEWIRE_REMOTE");
    struct stat info{};
    if (!check || std::string(check) != "1" || !runtime || !remote ||
        std::string(remote).find("conflux-private-routing-") != 0 ||
        std::string(remote).find('/') != std::string::npos ||
        lstat(runtime, &info) || !S_ISDIR(info.st_mode) || info.st_uid != getuid() || (info.st_mode & 0777) != 0700) return 2;
    const auto socket = std::string(runtime) + "/" + remote;
    if (lstat(socket.c_str(), &info) || !S_ISSOCK(info.st_mode) || info.st_uid != getuid()) return 2;
    pw_init(nullptr, nullptr);
    {
        Sink sink("conflux-short-live-test-sink");
        const auto end = std::chrono::steady_clock::now() + std::chrono::seconds(200);
        pollfd input{STDIN_FILENO, POLLIN, 0};
        while (std::chrono::steady_clock::now() < end) {
            if (poll(&input, 1, 100) > 0 && (input.revents & (POLLIN | POLLHUP | POLLERR))) break;
        }
    }
    pw_deinit();
    return 0;
}
'''
cpp = Path('/results/private_sink.cpp')
cpp.write_text(prefix + sink + main)
flags = shlex.split(subprocess.check_output(['pkg-config', '--cflags', '--libs', 'libpipewire-0.3'], text=True))
command = ['c++', '-std=c++20', '-O2', '-Wall', '-Wextra', str(cpp), '-o', '/results/private_sink'] + flags
with Path('/results/sink-build.log').open('x') as log:
    subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=30)
environment = dict(os.environ, QT_QPA_PLATFORM='offscreen', QT_QUICK_BACKEND='software', QT_QUICK_CONTROLS_STYLE='Basic')
command = ['/usr/bin/python', '-B', '/src/tools/experiments/private_routing_check.py',
           '/operations/actual_player_check.py', '/results/private-player-01', '--functional-only']
began = time.monotonic()
with Path('/results/private-player-runner.log').open('x') as log:
    result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=260)
receipt = {'exit': result.returncode, 'command': command, 'seconds': time.monotonic() - began,
           'sink_source_sha256': hashlib.sha256(cpp.read_bytes()).hexdigest(),
           'sink_implementation': 'Unmodified Sink class extracted from pinned preparation_controller_check.cpp; constant-PCM oracle never armed',
           'qualification': False}
Path('/results/inside-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(result.returncode)
