"""Extract only the pinned DeepSpec numeric datasets with the installed h5dump."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import os
import re
import struct
import subprocess
import time

BASE = Path(__file__).resolve().parent
DATA = BASE.parent
MODEL_SHA = '0a99c26b7d8a4f7123b3cdade75c7986ef686d6805378c43cada874497f53f9a'
CONFIG_SHA = 'fba2f8e7b5ecc6c964a87376fc1cfaa86c2961d06bf6d9344f88fc08c8c04923'
TOOL_SHA = 'aaf1f979b7ccd0ba223dbe7e16d32bc00f8c8f17c404a34d8b68451b96f925ed'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    began = time.monotonic()
    model = DATA / 'deepspec_k16.h5'
    config_path = DATA / 'model-config-01.json'
    assert digest(model) == MODEL_SHA
    assert digest(config_path) == CONFIG_SHA
    assert digest(Path('/bin/h5dump')) == TOOL_SHA
    config = json.loads(config_path.read_text())
    assert config['class_name'] == 'Model'
    layers = config['config']['layers']
    assert len(layers) == 40
    expected = {}
    channels = 1
    for index, layer in enumerate(layers):
        name = layer['name']
        operation = layer['config']
        if index:
            assert layer['inbound_nodes'] == [[[layers[index-1]['name'], 0, 0, {}]]]
        kind = layer['class_name']
        if kind == 'InputLayer':
            assert index == 0 and operation['batch_input_shape'] == [None, 168, None, 1]
        elif kind == 'Conv2D':
            kh, kw = operation['kernel_size']
            assert name in ['Conv'+str(i) for i in range(12)] + ['1x1']
            assert (kh, kw) in ((5, 1), (3, 1), (1, 1))
            assert operation['strides'] == [1, 1] and operation['dilation_rate'] == [1, 1]
            assert operation['padding'] == 'same' and operation['data_format'] == 'channels_last'
            assert operation['activation'] == 'relu' and operation['use_bias'] is True
            outputs = operation['filters']
            expected[(name, 'kernel:0')] = [kh, kw, channels, outputs]
            expected[(name, 'bias:0')] = [outputs]
            channels = outputs
        elif kind == 'BatchNormalization':
            assert operation['axis'] == [3] and operation['epsilon'] == .001
            assert operation['scale'] is True and operation['center'] is True
            for field in ('beta:0', 'gamma:0', 'moving_mean:0', 'moving_variance:0'):
                expected[(name, field)] = [channels]
        elif kind == 'MaxPooling2D':
            assert operation['pool_size'] == ([2, 1] if name == 'MaxPool2D6' else [2, 2])
            assert operation['strides'] == operation['pool_size']
            assert operation['padding'] == 'valid' and operation['data_format'] == 'channels_last'
        elif kind == 'GlobalAveragePooling2D':
            assert operation['data_format'] == 'channels_last'
        elif kind == 'Activation':
            assert index == 39 and operation['activation'] == 'softmax'
        elif kind != 'Dropout':
            raise ValueError('Unrecognized fixed graph operation')
    assert len(expected) == 74 and channels == 24
    env = os.environ.copy()
    env['HDF5_PLUGIN_PATH'] = ''
    env.pop('HDF5_VOL_CONNECTOR', None)
    env.pop('HDF5_DRIVER', None)
    listing = subprocess.run(['/bin/h5dump', '-n', str(model)], env=env, capture_output=True,
                             text=True, timeout=3, check=True)
    (BASE / 'inventory-01.txt').write_text(listing.stdout)
    paths = re.findall(r'^\s*dataset\s+(/model_weights/\S+)\s*$', listing.stdout, re.M)
    assert len(paths) == 74 and len(set(paths)) == 74
    output = BASE / 'data-only-tensors'
    output.mkdir()
    tensors = []
    seen = set()
    for index, path in enumerate(sorted(paths)):
        assert time.monotonic() - began < 40
        match = re.fullmatch(r'/model_weights/(Conv[0-9]+|BN[0-9]+|1x1)/\1_142/([a-z_]+:0)', path)
        assert match is not None, path
        name = (match[1], match[2])
        assert name in expected and name not in seen
        seen.add(name)
        destination = output / ('tensor-%03d.f32' % index)
        command = ['/bin/h5dump', '-d', path, '-b', 'LE', '-o', str(destination), str(model)]
        result = subprocess.run(command, env=env, capture_output=True, text=True,
                                timeout=3, check=True)
        assert len(result.stdout) < 16384 and not result.stderr, result.stderr
        assert 'DATATYPE  H5T_IEEE_F32LE' in result.stdout
        extent = re.search(r'DATASPACE\s+SIMPLE\s*\{\s*\(([^)]+)\)', result.stdout)
        assert extent is not None
        shape = [int(value.strip()) for value in extent[1].split(',')]
        assert shape == expected[name], (name, shape, expected[name])
        raw = destination.read_bytes()
        assert len(raw) == math.prod(shape) * 4
        values = [v[0] for v in struct.iter_unpack('<f', raw)]
        assert all(math.isfinite(v) for v in values)
        if name[1] == 'moving_variance:0':
            assert min(values) >= 0
        tensors.append({'name':list(name), 'HDF5_path':path, 'shape':shape, 'dtype':'float32_le',
                        'file':{'path':str(destination), 'bytes':len(raw), 'sha256':digest(destination)},
                        'all_values_finite':True, 'minimum':min(values), 'maximum':max(values)})
    assert seen == set(expected)
    assert digest(model) == MODEL_SHA and digest(config_path) == CONFIG_SHA
    report = {'schema':1, 'utc':datetime.now(timezone.utc).isoformat(),
              'model_SHA256':MODEL_SHA, 'config_SHA256':CONFIG_SHA, 'h5dump_SHA256':TOOL_SHA,
              'tensor_count':len(tensors), 'parameters':sum(math.prod(t['shape']) for t in tensors),
              'raw_bytes':sum(t['file']['bytes'] for t in tensors), 'tensors':tensors,
              'elapsed_seconds':time.monotonic()-began, 'legacy_serialized_code_executed':False,
              'model_inference_executed':False, 'dependencies_installed':False,
              'product_configuration_changed':False, 'GPU_started':False,
              'script_SHA256':digest(Path(__file__))}
    with (BASE / 'tensor-audit-01.json').open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key:report[key] for key in ('tensor_count','parameters','raw_bytes','elapsed_seconds')}))


if __name__ == '__main__':
    main()
