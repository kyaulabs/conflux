"""Generated protocol fixtures only; no audio, model or device."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parent))
import protocol
import score_global

class GlobalKeyChecks(unittest.TestCase):
    def row(self, a, b, signal=True):
        return dict(probabilities=[float(a), float(b)]+[0.]*22, signal_nonzero=signal)
    def test_posterior_mean_instead_of_majority_vote_and_keep_quiet_rows(self):
        key, _ = score_global.global_class([self.row(.55,.45),self.row(.55,.45),self.row(0,1,False)])
        self.assertEqual(key,1)
    def test_all_zero_feature_population_is_unknown(self):
        self.assertEqual(score_global.global_class([self.row(1,0,False)]),(None,[]))
    def test_tie_uses_lowest_class(self):
        self.assertEqual(score_global.global_class([self.row(.5,.5)])[0],0)
    def fixture(self, base):
        frames=48000; cases=[]; captures=[]; references=[]
        for index in range(24):
            ident=f'{index:06d}'; ready=index<21
            case=dict(id=ident,preparation_status='PreparedMetadataMeasured' if ready else 'Failed',
                      prepared_frames=frames,pcm_sha256='b'*64,source=dict(bytes=8,sha256='a'*64))
            cases.append(case);references.append(dict(track_id=index,reference_class=index))
            if not ready:
                captures.append(dict(id=ident,complete=False,status='SourcePreparationFailed'));continue
            _,columns,count=protocol.clock.geometry(frames)
            probs=[0.]*24;probs[index]=1.
            raw=[dict(index=i,probabilities=probs,signal_nonzero=True) for i in range(count)]
            windows=protocol.projection(frames,raw)
            value=dict(schema=1,recipe=protocol.RECIPE,model_sha256=protocol.MODEL_SHA,
                       frames=frames,sample_rate=48000,channels=2,pcm_sha256='b'*64,
                       CQT_columns=columns,raw_predictions=raw,window_count=len(windows),windows=windows,
                       confidence='Unknown',qualified=False,audio_device_opened=False,GPU_started=False)
            path=base/(ident+'-prediction.json');path.write_text(json.dumps(value)+'\n')
            metadata=dict(complete=True,case=ident,source_bytes=8,prepared_frames=frames,
                          sample_rate=48000,channels=2,source_sha256='a'*64,prepared_pcm_sha256='b'*64,
                          audio_device_opened=False)
            captures.append(dict(id=ident,complete=True,prediction_path=str(path),
                                 prediction_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),source=metadata))
        reference=base/'reference.json';reference.write_text(json.dumps(dict(cases=references)))
        plan=dict(cases=cases,output=str(base),reference=dict(path=str(reference),
                  sha256=hashlib.sha256(reference.read_bytes()).hexdigest()),aggregation_rule=dict(sha256='c'*64))
        return plan,captures
    def test_full_selected_denominator_keeps_preparation_failures(self):
        with tempfile.TemporaryDirectory() as temp:
            plan,captures=self.fixture(Path(temp));result=score_global.score(plan,captures)
            self.assertEqual(result['global_exact'],dict(matches=21,denominator=24,percent=87.5))
            self.assertEqual(result['estimated_subset']['denominator'],21)
            self.assertEqual(result['estimated_subset']['percent'],100)
            self.assertEqual(result['source_preparation_failures'],3)
            self.assertFalse(result['operational_pass']);self.assertTrue(result['inference_pipeline_pass'])
            self.assertEqual(result['confidence'],'Unknown');self.assertFalse(result['qualified'])
    def test_changed_capture_and_wrong_case_order_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            plan,captures=self.fixture(Path(temp));bad=copy.deepcopy(captures);bad.reverse()
            with self.assertRaises(AssertionError):score_global.score(plan,bad)
            Path(captures[0]['prediction_path']).write_text('{}\n')
            with self.assertRaises(AssertionError):score_global.score(plan,captures)
    def test_invalid_model_probabilities_fail_even_with_matching_file_hash(self):
        with tempfile.TemporaryDirectory() as temp:
            plan,captures=self.fixture(Path(temp));path=Path(captures[0]['prediction_path']);value=json.loads(path.read_text());value['raw_predictions'][0]['probabilities'][0]=float('nan');path.write_text(json.dumps(value));captures[0]['prediction_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
            with self.assertRaises(ValueError):score_global.score(plan,captures)
    def test_maximum_native_clock_packet_fits_fixed_output_limit(self):
        frames=33554432;_,columns,count=protocol.clock.geometry(frames)
        self.assertEqual(count,471)
        raw=[dict(index=i,probabilities=[1/24]*24,signal_nonzero=True) for i in range(count)]
        windows=protocol.projection(frames,raw)
        value=dict(raw_predictions=raw,windows=windows,frames=frames,CQT_columns=columns)
        self.assertLess(len(json.dumps(value,separators=(',',':')).encode())+4096,524288)

    def test_old_model_identity_is_rejected_even_with_rehashed_capture(self):
        with tempfile.TemporaryDirectory() as temp:
            plan,captures=self.fixture(Path(temp))
            path=Path(captures[0]['prediction_path'])
            value=json.loads(path.read_text())
            value['model_sha256']='b425f2e8d5165415c8863b6666aa82d7573121ee675bd2fd8b59d7594f5f11e9'
            path.write_text(json.dumps(value)+'\n')
            captures[0]['prediction_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
            with self.assertRaisesRegex(ValueError,'Recipe/model identity differs'):
                score_global.score(plan,captures)

if __name__=='__main__':unittest.main()
