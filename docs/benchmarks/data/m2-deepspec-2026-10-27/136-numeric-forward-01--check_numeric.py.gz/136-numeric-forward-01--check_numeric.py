"""Generated DeepSpec checks against independent float64 SciPy operators."""
from pathlib import Path
import hashlib
import json
import sys
import time

import numpy as np
import scipy
from scipy.signal import correlate

BASE = Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
import keycnn_numeric as candidate


def oracle(features, tensors, configuration):
    # Interpret the fixed serialized graph as data. No candidate operations.
    value = features.astype(np.float64)
    deviation = value.std()
    if deviation:
        value = (value - value.mean()) / deviation
    value = value.astype(np.float16).astype(np.float64)
    trace = [('normalized_input', value.copy())]
    for layer in configuration['config']['layers'][1:]:
        name, operation, kind = layer['name'], layer['config'], layer['class_name']
        if kind == 'Dropout':
            continue
        if kind == 'Conv2D':
            kernel = tensors[(name, 'kernel:0')].astype(np.float64)
            bias = tensors[(name, 'bias:0')].astype(np.float64)
            kh, kw = operation['kernel_size']
            padded = np.pad(value, ((0,0),(kh//2,kh//2),(kw//2,kw//2),(0,0)))
            result = np.empty((*value.shape[:3], len(bias)), dtype=np.float64)
            for batch in range(len(value)):
                for channel in range(len(bias)):
                    result[batch,:,:,channel] = correlate(padded[batch], kernel[:,:,:,channel],
                        mode='valid', method='direct')[:,:,0] + bias[channel]
            value = np.maximum(result, 0.)
        elif kind == 'BatchNormalization':
            gamma, beta, mean, variance = (tensors[(name, field)].astype(np.float64)
                for field in ('gamma:0','beta:0','moving_mean:0','moving_variance:0'))
            value = ((value - mean) / np.sqrt(variance + operation['epsilon'])) * gamma + beta
        elif kind == 'MaxPooling2D':
            ph, pw = operation['pool_size']
            n, h, w, c = value.shape
            value = value[:,:h//ph*ph,:w//pw*pw,:].reshape(n,h//ph,ph,w//pw,pw,c).max(axis=(2,4))
        elif kind == 'GlobalAveragePooling2D':
            value = np.mean(value, axis=(1,2))
            name = 'global_average_pooling2d'
        elif kind == 'Activation':
            shifted = value - np.max(value, axis=1, keepdims=True)
            value = np.exp(shifted)
            value = value / np.sum(value, axis=1, keepdims=True)
            name = 'activation'
        else:
            raise ValueError('Unexpected fixed graph operation')
        trace.append((name,value.copy()))
    return value,trace


def main():
    began = time.monotonic()
    rng = np.random.default_rng(20261027)
    tensors = candidate.weights()
    configuration = json.loads((BASE.parent/'model-config-01.json').read_text())
    examples = {'zeros':np.zeros((1,168,60,1),dtype='f4'),
                'constant':np.full((1,168,60,1),3,dtype='f4'),
                'random_positive':rng.uniform(0,8,size=(2,168,60,1)).astype('f4')}
    comparisons = []
    for name, features in examples.items():
        actual, trace = candidate.forward(features,tensors)
        expected, reference = oracle(features,tensors,configuration)
        assert [n for n,_ in trace] == [n for n,_ in reference]
        layers = []
        for (layer,a),(_,b) in zip(trace,reference):
            assert a.shape == b.shape
            np.testing.assert_allclose(a,b,rtol=3e-4,atol=3e-4)
            layers.append({'name':layer,'shape':list(a.shape),
                           'maximum_absolute_error':float(np.max(np.abs(a-b)))})
        assert np.isfinite(actual).all() and (actual>=0).all()
        np.testing.assert_allclose(actual.sum(axis=1),1,rtol=1e-6,atol=1e-6)
        np.testing.assert_array_equal(actual.argmax(axis=1),expected.argmax(axis=1))
        comparisons.append({'case':name,'windows':len(features),'layers':layers,
                            'argmax_agrees':True,'all_layers_within_tolerance':True,
                            'probabilities_maximum_absolute_error':float(np.max(np.abs(actual-expected)))})
    mixed = np.stack([examples['zeros'][0],examples['constant'][0],examples['random_positive'][0]])
    normalized = candidate.normalize(mixed)
    expected = candidate.forward_normalized(normalized,tensors)[0]
    batching = []
    for size in (1,2,4):
        actual = candidate.predict(mixed,tensors,batch_size=size)
        np.testing.assert_allclose(actual,expected,rtol=1e-5,atol=1e-6)
        np.testing.assert_array_equal(actual.argmax(axis=1),expected.argmax(axis=1))
        batching.append({'batch_size':size,'maximum_absolute_error':float(np.max(np.abs(actual-expected)))})
    rejected = 0
    for bad in (mixed[:,:,:59],mixed[...,0],mixed[:0],np.full_like(mixed,np.nan),
                np.full_like(mixed,np.inf),mixed.astype('i4'),np.zeros((513,168,60,1),dtype='f4')):
        try:
            candidate.normalize(bad)
        except ValueError:
            rejected += 1
    assert rejected == 7
    for shape in ((2,1,1,2),(3,3,1,2),(5,1,2,2)):
        try:
            candidate.convolution(mixed[:1],np.zeros(shape,dtype='f4'),np.zeros(2,dtype='f4'))
        except ValueError:
            rejected += 1
        else:
            raise AssertionError('Unsupported model geometry accepted')
    try:
        candidate.batch_normalization(np.zeros((1,2,2,2),dtype='f4'),
            np.ones(2,dtype='f4'),np.zeros(2,dtype='f4'),np.zeros(2,dtype='f4'),-np.ones(2,dtype='f4'))
    except ValueError:
        rejected += 1
    else:
        raise AssertionError('Negative running variance accepted')
    report = {'schema':1,'status':'generated_numeric_checks_passed',
              'model_SHA256':candidate.MODEL_SHA,'parameters_verified':sum(v.size for v in tensors.values()),
              'numpy_version':np.__version__,'scipy_version':scipy.__version__,
              'reference':'Independent graph interpreter using float64 scipy.signal.correlate and reshape max pooling',
              'relative_tolerance':3e-4,'absolute_tolerance':3e-4,
              'comparisons':comparisons,'batching':batching,'invalid_inputs_rejected':rejected,
              'elapsed_seconds':time.monotonic()-began,'legacy_TensorFlow_equivalence_verified':False,
              'real_audio_inferred':False,'musical_accuracy_qualified':False,'GPU_started':False,
              'dependencies_installed':False,'product_configuration_changed':False,
              'files':{x.name:hashlib.sha256(x.read_bytes()).hexdigest()
                       for x in (Path(__file__),Path(candidate.__file__))}}
    with (BASE/'result-01.json').open('x') as stream:
        json.dump(report,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'status':report['status'],'windows':sum(x['windows'] for x in comparisons),
                      'maximum_probability_error':max(x['probabilities_maximum_absolute_error'] for x in comparisons),
                      'invalid_inputs_rejected':rejected,'elapsed_seconds':report['elapsed_seconds']}))


if __name__ == '__main__':
    main()
