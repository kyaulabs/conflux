"""Write the closed DeepSpec comparison as one scoped benchmark record."""
from pathlib import Path
import hashlib
import json

BASE=Path(__file__).resolve().parent
WORK=Path('/home/kyau/.codex/worktrees/release-tree-guard/conflux')


def key(index):
    if index is None:return '—'
    return ['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B'][index%12]+(' minor' if index>=12 else ' major')


def main():
    closed=json.loads((BASE/'fmak-01/root-finished-01.json').read_text())
    proof=json.loads((BASE/'fmak-01/post-close-verification-01.json').read_text())
    assert closed['cleanup_complete'] and closed['inference_pipeline_pass'] and not closed['errors']
    assert proof['all_owned_resources_closed'] and proof['frozen_inputs_unchanged']
    scores=json.loads((BASE/'fmak-01/output-01/scores.json').read_text())
    comparison=json.loads((BASE/'paired-comparison-01.json').read_text())
    numeric=json.loads((BASE/'numeric-forward-01/result-01.json').read_text())
    a=scores['global_exact'];b=scores['estimated_subset'];old=comparison['baseline_inferred']
    assert a['denominator']==24 and b['denominator']==old['denominator']==21
    table=['| Source ID | Reference | Winterreise | DeepSpec | DeepSpec result |',
           '| --- | --- | --- | --- | --- |']
    for row in comparison['cases']:
        result='Source rejected' if row['candidate_class'] is None else ('Match' if row['candidate_match'] else 'Mismatch')
        table.append('| '+ ' | '.join((row['id'],key(row['reference_class']),key(row['baseline_class']),key(row['candidate_class']),result))+' |')
    text=f'''# DeepSpec on the fixed FMAK sample

The publisher's default DeepSpec model matched **{b['matches']}/21 inferred tracks
({b['percent']:.2f}%)**, compared with **10/21 (47.62%)** for the earlier Winterreise
candidate. Keeping the three source rejections gives **{a['matches']}/24 selected
tracks ({a['percent']:.2f}%)**. The paired comparison improved {comparison['newly_correct']}
tracks and regressed {comparison['newly_incorrect']}. The production key backend
remains disabled; confidence remains `Unknown`.

This uses the same exposed sample as the [earlier FMAK diagnostic](key-cnn-fmak-2026-10-27.md).
Its 24 tonic/mode classes, distinct artists, source files and native preparations
are unchanged. Earlier predictions and reference classes had already been
examined before this candidate was selected. Training membership is unverified.
These results therefore describe a candidate comparison, not fresh held-out or
general-genre accuracy. FMAK supplies song-level labels, not local key changes.

The [pinned upstream classifier](https://github.com/hendriks73/key-cnn/blob/9715d6f443c0f01d9842e567a3f20c9b228c3c7f/keycnn/classifier.py)
maps its default `deepspec` alias to `deepspec_k16`. Its directional spectral
filters differ from the Winterreise model's square filters. The downloaded
container's Git blob and SHA-256 were checked. Only its 74 numeric F32 tensors
(290,376 parameters) were extracted; serialized Keras objects were not executed.
The model and its numeric weights remain local. The publisher's source/model
license record is retained with the evidence.

The private NumPy implementation passed three directional-filter scalar checks
and **102 layer comparisons over four generated windows** against an independent
float64 SciPy graph interpreter. Maximum posterior difference was
**{max(c['probabilities_maximum_absolute_error'] for c in numeric['comparisons']):.9g}**.
Batch sizes 1, 2 and 4 produced identical posteriors for the mixed-window fixture;
11 invalid-input/geometry/variance cases were rejected. Original TensorFlow
execution equivalence remains unverified. The previously used CPU Torch runtime
was unavailable, so this check used the already-installed SciPy reference.

The music comparison changes only the model. Native PCM identities, the legacy
CQT recipe, padded 60-frame windows at hop eight, whole-population whitening and
the frozen arithmetic-mean posterior rule remain unchanged. This window recipe
was chosen for the earlier local-key diagnostic; it does not reproduce the
publisher's default global-window selection. Eight generated protocol/scoring
checks passed, including rejection of an old-model packet even after rehashing.

All 21 inferable sources completed. Sources 003853, 005153 and 061480 retain the
earlier decoder failures; none was converted, replaced, trimmed or relabelled.
All captures closed before reference parsing and scoring. The complete pipeline
retains `operational_pass=false` for those three source failures, while
`inference_pipeline_pass=true` records the successful inference portion.

The CPU-only run closed in **{closed['elapsed_seconds']:.3f} seconds**. All 170
frozen inputs still matched, and the owned unit, process group and spool paths
were retired. It used one CPU core at low priority with the thermal guard and
15 W ceiling unchanged. No player, audio device or GPU worker started. Its
execution time is not a live-stem service-latency result.

{chr(10).join(table)}

The [evidence manifest](data/m2-deepspec-2026-10-27/manifest.json) retains source
provenance, numeric checks, frozen code/rules, raw posteriors, warnings, paired
scores and cleanup proofs. It excludes audio, prepared PCM, feature arrays,
weights, model containers and executables.

Local key-change accuracy, confidence calibration, production integration and
laptop performance remain unqualified. The actual-player latency baseline is
still **8.889-second p99** against **4.095 seconds**, with Best quality, the 15 W
ceiling and thermal protection unchanged. M2, M3 and release 0.1.0 remain open.
'''
    target=WORK/'docs/benchmarks/deepspec-fmak-2026-10-27.md'
    with target.open('x') as stream:stream.write(text)
    m2=WORK/'docs/M2.md';prefix=m2.read_bytes()
    addition=f'''\nThe [DeepSpec comparison](benchmarks/deepspec-fmak-2026-10-27.md) changed only the
key model on that exposed FMAK sample: {b['matches']}/21 inferred tracks
({b['percent']:.2f}%), or {a['matches']}/24 selections ({a['percent']:.2f}%) with the same three decoder
rejections retained. Independent generated numeric checks passed; local key
changes, confidence, training independence and production integration remain
unqualified. Harmony stays disabled, and all M2/M3/release gates remain open.\n'''
    with m2.open('ab') as stream:stream.write(addition.encode())
    receipt={'report':str(target),'report_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
             'M2_original_prefix_bytes':len(prefix),'M2_original_prefix_sha256':hashlib.sha256(prefix).hexdigest(),
             'M2_prefix_preserved':m2.read_bytes().startswith(prefix)}
    with (BASE/'documentation-01.json').open('x') as stream:
        json.dump(receipt,stream,indent=2);stream.write('\n')
    print(json.dumps(receipt))


if __name__=='__main__':main()
