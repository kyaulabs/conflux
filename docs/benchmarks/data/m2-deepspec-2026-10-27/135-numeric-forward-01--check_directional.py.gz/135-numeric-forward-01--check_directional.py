"""Generated directional-filter checks against an explicit scalar reference."""
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np


def main():
    path = Path(sys.argv[1]).resolve(strict=True)
    spec = importlib.util.spec_from_file_location('numeric_candidate', path)
    candidate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(candidate)
    rng = np.random.default_rng(20261027)
    records = []
    for kh, kw in ((5, 1), (3, 1), (1, 1)):
        value = rng.normal(size=(2, 4, 5, 2)).astype('f4')
        kernel = rng.normal(size=(kh, kw, 2, 3)).astype('f4')
        bias = np.array([-.2, .1, .4], dtype='f4')
        expected = np.zeros((2, 4, 5, 3), dtype='f4')
        for batch in range(2):
            for y in range(4):
                for x in range(5):
                    for out in range(3):
                        total = 0.
                        for ky in range(kh):
                            for kx in range(kw):
                                for channel in range(2):
                                    iy, ix = y+ky-kh//2, x+kx-kw//2
                                    if 0 <= iy < 4 and 0 <= ix < 5:
                                        total += float(value[batch,iy,ix,channel]) * float(kernel[ky,kx,channel,out])
                        expected[batch,y,x,out] = max(0., total + float(bias[out]))
        actual = candidate.convolution(value, kernel, bias)
        np.testing.assert_allclose(actual, expected, rtol=2e-6, atol=2e-6)
        records.append({'kernel':[kh,kw], 'maximum_absolute_error':float(np.max(np.abs(actual-expected)))})
    print(json.dumps({'directional_scalar_checks':len(records), 'records':records}))


if __name__ == '__main__':
    main()
