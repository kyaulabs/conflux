"""Losslessly reformat one published source-digest map; frozen inputs stay intact."""
from pathlib import Path
from datetime import datetime,timezone
import gzip
import hashlib
import json

BASE=Path(__file__).resolve().parent
DEST=Path('/home/kyau/.codex/worktrees/release-tree-guard/conflux/docs/benchmarks/data/m2-deepspec-2026-10-27')
PLAIN=BASE/'uncompressed-review-01'


def sha(raw):return hashlib.sha256(raw).hexdigest()


def main():
    manifest_path=DEST/'manifest.json'
    old_manifest=manifest_path.read_bytes()
    manifest=json.loads(old_manifest)
    row=next(r for r in manifest['files'] if r['relative_origin']=='numeric-forward-01/result-01.json')
    assert 'publication_transform' not in row
    original=Path(row['origin']).read_bytes()
    assert sha(original)==row['raw_sha256']
    assert gzip.decompress((DEST/row['file']).read_bytes())==original
    assert (PLAIN/row['file'][:-3]).read_bytes()==original
    value=json.loads(original)
    assert set(value['files'])=={'check_numeric.py','keycnn_numeric.py'}
    for name,expected in value['files'].items():
        assert sha((BASE/'numeric-forward-01'/name).read_bytes())==expected
    value['files']=[{'path':name,'sha256':digest} for name,digest in value['files'].items()]
    published=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
    restored=json.loads(published)
    restored['files']={record['path']:record['sha256'] for record in restored['files']}
    assert (json.dumps(restored,indent=2,allow_nan=False)+'\n').encode()==original
    row.update(origin_raw_bytes=len(original),origin_raw_sha256=sha(original),
               publication_transform='files_digest_map_to_path_sha256_records_v1')
    compressed=gzip.compress(published,compresslevel=9,mtime=0)
    (DEST/row['file']).write_bytes(compressed)
    (PLAIN/row['file'][:-3]).write_bytes(published)
    row.update(raw_bytes=len(published),raw_sha256=sha(published),
               gzip_bytes=len(compressed),gzip_sha256=sha(compressed))
    receipt={'utc':datetime.now(timezone.utc).isoformat(),
             'reason':'generic-api-key false positive on a computed implementation-file SHA256',
             'computed_source_digests_verified':True,'original_result_preserved':True,
             'publication_transformation_reversible_byte_for_byte':True,
             'original_result_sha256':sha(original),'published_payload_sha256':sha(published),
             'previous_manifest_sha256':sha(old_manifest),
             'scanner_rules_allowlists_or_hooks_changed':False}
    receipt_path=BASE/'publication-format-01.json'
    with receipt_path.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
    for path in (Path(__file__).resolve(),receipt_path):
        raw=path.read_bytes();encoded=gzip.compress(raw,compresslevel=9,mtime=0)
        label='%03d-%s'%(len(manifest['files']),path.name)
        destination=DEST/(label+'.gz')
        with destination.open('xb') as stream:stream.write(encoded)
        (PLAIN/label).write_bytes(raw)
        manifest['files'].append({'origin':str(path),'relative_origin':path.name,'file':destination.name,
                                  'raw_bytes':len(raw),'raw_sha256':sha(raw),
                                  'gzip_bytes':len(encoded),'gzip_sha256':sha(encoded)})
    manifest['archive_count']=len(manifest['files'])
    manifest['compressed_bytes']=sum(r['gzip_bytes'] for r in manifest['files'])
    manifest['publication_format_note']='One source-digest map is represented as path/SHA256 records; original bytes are recoverable and separately checksum-bound.'
    manifest_path.write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n')
    assert Path(row['origin']).read_bytes()==original
    print(json.dumps(receipt))


if __name__=='__main__':main()
