"""Verify the terminal owned run and compare its already-closed global scores."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import sys

BASE=Path(__file__).resolve().parent
PACKET=BASE/'fmak-01'
sys.path.insert(0,str(PACKET))
import protocol


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    spec=importlib.util.spec_from_file_location('fixed_deepspec_owner',PACKET/'run_once.py')
    owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)
    plan=json.loads((PACKET/'music-plan-01.json').read_text())
    root=json.loads((PACKET/'root-finished-01.json').read_text())
    assert root['cleanup_complete'] and root['frozen_inputs_unchanged'] and root['inference_pipeline_pass']
    assert root['within_original_2820_seconds'] and not root['errors']
    state=owner.query(plan['unit'])
    assert state['LoadState']=='not-found' and state['MainPID']=='0'
    group=Path('/sys/fs/cgroup')/root['original_cgroup'].lstrip('/')
    assert not group.exists() or all(not p.read_text().split() for p in group.rglob('cgroup.procs'))
    assert not list((PACKET/'output-01').glob('spool-*'))
    owner.verify(plan)
    captures_path=PACKET/'output-01/predictions-before-scoring.json'
    captures=json.loads(captures_path.read_text())
    score_path=PACKET/'output-01/scores.json'
    score=json.loads(score_path.read_text())
    assert digest(captures_path)==score['closed_capture_sha256']
    assert len(captures)==24 and [r['id'] for r in captures]==[c['id'] for c in plan['cases']]
    completed=0;failed=[]
    for case,row in zip(plan['cases'],captures,strict=True):
        if case['preparation_status']=='PreparedMetadataMeasured':
            assert row['complete'] and row['status']=='PredictionCaptured'
            path=Path(row['prediction_path'])
            assert path==PACKET/'output-01'/(case['id']+'-prediction.json')
            assert digest(path)==row['prediction_sha256']
            protocol.validate_prediction(json.loads(path.read_text()),row['source'],case)
            assert row['producer_reaped'] and row['consumer_reaped'] and row['spool_empty']
            completed+=1
        else:
            assert not row['complete'] and row['status']=='SourcePreparationFailed'
            failed.append(case['id'])
    assert completed==21 and set(failed)=={'003853','005153','061480'}
    assert score['source_preparation_failures']==3 and score['operational_pass'] is False
    baseline_path=Path(plan['baseline']['path'])
    assert digest(baseline_path)==plan['baseline']['sha256']
    baseline=json.loads(baseline_path.read_text())
    assert baseline['global_exact']['matches']==10 and baseline['estimated_subset']['denominator']==21
    rows=[]
    for before,after in zip(baseline['cases'],score['cases'],strict=True):
        assert before['id']==after['id'] and before['reference_class']==after['reference_class']
        rows.append({'id':after['id'],'reference_class':after['reference_class'],
                     'baseline_class':before['predicted_class'],'candidate_class':after['predicted_class'],
                     'baseline_match':before['match'],'candidate_match':after['match'],
                     'source_rejected':after['id'] in failed})
    paired={'schema':1,'utc':datetime.now(timezone.utc).isoformat(),'cases':rows,
            'baseline_selected':baseline['global_exact'],'baseline_inferred':baseline['estimated_subset'],
            'candidate_selected':score['global_exact'],'candidate_inferred':score['estimated_subset'],
            'newly_correct':sum(not r['baseline_match'] and r['candidate_match'] for r in rows),
            'newly_incorrect':sum(r['baseline_match'] and not r['candidate_match'] for r in rows),
            'both_correct':sum(r['baseline_match'] and r['candidate_match'] for r in rows),
            'both_incorrect_on_inferred':sum(not r['source_rejected'] and not r['baseline_match'] and not r['candidate_match'] for r in rows),
            'baseline_score_sha256':digest(baseline_path),'candidate_score_sha256':digest(score_path),
            'same_exposed_corpus':True,'training_independence_verified':False,
            'local_key_or_latency_qualified':False,'production_enabled':False}
    assert paired['newly_correct']-paired['newly_incorrect']==score['global_exact']['matches']-10
    with (BASE/'paired-comparison-01.json').open('x') as stream:
        json.dump(paired,stream,indent=2,allow_nan=False);stream.write('\n')
    proof={'utc':datetime.now(timezone.utc).isoformat(),'all_owned_resources_closed':True,
           'unit':state,'cgroup_absent_or_empty':True,'spool_paths_absent':True,
           'captured_cases_rehashed':completed,'preserved_source_failures':failed,
           'frozen_inputs_unchanged':True,'frozen_input_count':len(plan['input_pins']),
           'paired_score_sha256':digest(BASE/'paired-comparison-01.json')}
    with (PACKET/'post-close-verification-01.json').open('x') as stream:
        json.dump(proof,stream,indent=2);stream.write('\n')
    print(json.dumps({k:paired[k] for k in ('baseline_inferred','candidate_inferred','candidate_selected','newly_correct','newly_incorrect')}))
    print(json.dumps(proof))


if __name__=='__main__':main()
