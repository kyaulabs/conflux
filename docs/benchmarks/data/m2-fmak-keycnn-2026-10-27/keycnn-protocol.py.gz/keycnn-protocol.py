"""Private fixed-source key-CNN diagnostic protocol; no model or media imports."""
import hashlib
import importlib.util
import math
from pathlib import Path

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
DATA = ROOT/'build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/model-data-audit-01'
CLOCK_PATH = DATA/'feature-compatibility-01/source-clock-01/source_clock.py'
spec = importlib.util.spec_from_file_location('fixed_diagnostic_key_clock', CLOCK_PATH)
clock = importlib.util.module_from_spec(spec)
spec.loader.exec_module(clock)
RECIPE = 'private-keycnn-winterreise-nfold16-legacycqt-hop8-v1'
MODEL_SHA = 'b425f2e8d5165415c8863b6666aa82d7573121ee675bd2fd8b59d7594f5f11e9'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_pcm(stream, frames, expected_sha):
    clock.geometry(frames)
    require(isinstance(expected_sha, str) and len(expected_sha) == 64
            and all(c in '0123456789abcdef' for c in expected_sha), 'Invalid expected PCM digest')
    raw = stream.read(frames*8+1)
    require(len(raw) == frames*8, 'Prepared PCM extent differs')
    require(hashlib.sha256(raw).hexdigest() == expected_sha, 'Prepared PCM digest differs')
    return raw


def projection(frames, raw_predictions):
    _, columns, count = clock.geometry(frames)
    require(type(raw_predictions) is list and len(raw_predictions) == count, 'Prediction population differs')
    for index, row in enumerate(raw_predictions):
        require(type(row) is dict and set(row) == {'index', 'probabilities', 'signal_nonzero'}, 'Raw row schema differs')
        require(type(row['index']) is int and row['index'] == index
                and type(row['signal_nonzero']) is bool, 'Raw row identity/types differ')
        values = row['probabilities']
        require(type(values) is list and len(values) == 24, 'Expected 24 class probabilities')
        require(all(type(v) is float and math.isfinite(v) and 0 <= v <= 1 for v in values), 'Invalid class probability')
        require(abs(sum(values)-1.) <= 2e-6, 'Unnormalized class probabilities')
    result = []
    for cell in clock.partition(frames, columns, count)['intervals']:
        index = cell['posterior_index']
        row = dict(first_frame=cell['first_frame'], end_frame=cell['end_frame'],
                   confidence='Unknown', status='Unknown', candidates=[])
        if index is not None and raw_predictions[index]['signal_nonzero']:
            values = raw_predictions[index]['probabilities']
            key = values.index(max(values))
            row.update(status='Estimated', candidates=[dict(tonic=key % 12, mode='Minor' if key >= 12 else 'Major')])
        else:
            row['reason'] = cell['reason'] if index is None else 'zero feature magnitude'
        result.append(row)
    return result


def validate_prediction(value, metadata, case):
    frames = case['prepared_frames']
    require(type(value) is dict and value['schema'] == 1 and type(value['schema']) is int, 'Invalid result schema')
    require(value['recipe'] == RECIPE and value['model_sha256'] == MODEL_SHA, 'Recipe/model identity differs')
    for name, expected in [('frames', frames), ('sample_rate', 48000), ('channels', 2)]:
        require(type(value[name]) is int and value[name] == expected, 'Prediction source clock differs')
    require(value['pcm_sha256'] == case['pcm_sha256'], 'Prediction PCM identity differs')
    require(type(value['CQT_columns']) is int and value['CQT_columns'] == clock.geometry(frames)[1],
            'CQT header geometry differs')
    require(value['qualified'] is False and value['audio_device_opened'] is False
            and value['GPU_started'] is False and value['confidence'] == 'Unknown', 'Unqualified scope differs')
    require(type(value['windows']) is list, 'Source windows missing')
    for row in value['windows']:
        require(type(row) is dict and type(row['first_frame']) is int and type(row['end_frame']) is int,
                'Source window frame types differ')
        require(type(row['candidates']) is list, 'Candidate list differs')
        for candidate in row['candidates']:
            require(type(candidate) is dict and set(candidate) == {'tonic', 'mode'}
                    and type(candidate['tonic']) is int and 0 <= candidate['tonic'] < 12
                    and candidate['mode'] in ('Major', 'Minor'), 'Candidate schema differs')
    require(value['windows'] == projection(frames, value['raw_predictions']), 'Projected class/source cells differ')
    require(type(value['window_count']) is int and value['window_count'] == len(value['windows']), 'Projected count differs')
    if metadata is not None:
        require(metadata['complete'] is True and metadata['case'] == case['id'], 'Preparation did not complete')
        for name, expected in [('source_bytes', case['source']['bytes']), ('prepared_frames', frames),
                               ('sample_rate', 48000), ('channels', 2)]:
            require(type(metadata[name]) is int and metadata[name] == expected, 'Preparation metadata differs')
        require(metadata['source_sha256'] == case['source']['sha256']
                and metadata['prepared_pcm_sha256'] == case['pcm_sha256']
                and metadata['audio_device_opened'] is False, 'Prepared source identity differs')
    return [{name:row[name] for name in ('first_frame', 'end_frame', 'status', 'candidates')}
            for row in value['windows']]
