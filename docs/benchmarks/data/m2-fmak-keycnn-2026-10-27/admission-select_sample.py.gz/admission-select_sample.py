"""Deterministic key-class/artist matching before any media or predictions."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
SEED = 'conflux-fmak-key-screen-20261027-v1'


def select(pools):
    artists = {}
    def assign(index, seen):
        for row in pools[index]:
            artist = row['artist_id']
            if artist in seen:
                continue
            seen.add(artist)
            if artist not in artists or assign(artists[artist]['reference_class'], seen):
                artists[artist] = row
                return True
        return False
    for index in sorted(pools):
        assign(index, set())
    return {row['reference_class']:row for row in artists.values()}


def main():
    before = json.loads((BASE/'selection-plan-01.json').read_text())
    admission = json.loads((BASE/'metadata-admission-01.json').read_text())
    raw = (BASE/'catalogue-01.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != admission['catalogue_SHA256']:
        raise ValueError('Admitted catalogue hash differs')
    assert not (BASE/'selection-plan-02.json').exists()
    # This correction changes assignment only. Eligibility, seed and class
    # population remain the ones fixed before metadata selection.
    rows = json.loads(raw)['records']
    pools = {index:[] for index in range(24)}
    for row in rows:
        if row['eligible']:
            pools[row['reference_class']].append(row)
    for pool in pools.values():
        pool.sort(key=lambda row:hashlib.sha256((SEED+':'+str(row['track_id'])).encode()).digest())
    # Regression: a greedy first choice consumes the rare class's only artist.
    simple = {0:[dict(reference_class=0, artist_id=1), dict(reference_class=0, artist_id=2)],
              1:[dict(reference_class=1, artist_id=1)]}
    fixed = select(simple)
    assert len(fixed) == 2 and fixed[0]['artist_id'] == 2 and fixed[1]['artist_id'] == 1
    # A second reassignment must be able to traverse more than one earlier class.
    chain = {0:[dict(reference_class=0, artist_id=1), dict(reference_class=0, artist_id=2)],
             1:[dict(reference_class=1, artist_id=2), dict(reference_class=1, artist_id=3)],
             2:[dict(reference_class=2, artist_id=1)]}
    assert len(select(chain)) == 3
    assert len(select({0:[], 1:[dict(reference_class=1, artist_id=2)]})) == 1
    result = select(pools)
    assert set(result) == set(range(24))
    cases = [result[index] for index in range(24)]
    assert len({row['artist_id'] for row in cases}) == 24
    assert len({row['track_id'] for row in cases}) == 24
    assert all(row in pools[row['reference_class']] for row in cases)
    assert select(pools) == result
    assert {str(k):len(v) for k,v in pools.items()} == before['eligible_counts_by_class']
    plan = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                status='frozen_before_media_download_or_model_inference', seed=SEED,
                correction='Replace greedy assignment with deterministic augmenting-path matching to represent '
                           'all 24 eligible key classes using 24 distinct artists. No eligibility, audio, '
                           'model, annotation or acoustic parameter changes.',
                earlier_22_slot_plan_SHA256=hashlib.sha256((BASE/'selection-plan-01.json').read_bytes()).hexdigest(),
                catalogue_SHA256=admission['catalogue_SHA256'], eligible_tracks=before['eligible_tracks'],
                eligible_counts_by_class=before['eligible_counts_by_class'], denominator=24,
                selected_tracks=24, selected_unique_artists=24, cases=cases,
                selection_source_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                global_song_key_labels_only=True, local_key_changes_annotated=False,
                exact_released_model_training_membership_verified=False,
                model_or_media_used_for_selection=False, product_configuration_changed=False)
    with (BASE/'selection-plan-02.json').open('x') as stream:
        stream.write(json.dumps(plan, indent=2, allow_nan=False)+'\n')
    check = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                 status='fixed_24_class_24_artist_sample_verified',
                 earlier_greedy_22_slot_plan_preserved=True, deterministic_matching=True,
                 all_24_classes_distinct_artists_and_tracks=True, candidate_eligibility_and_seed_unchanged=True,
                 regression_checks=3, sample_construction_checks=6,
                 selected_track_ids=[row['track_id'] for row in cases],
                 selected_top_genres=dict(Counter(g for row in cases for g in row['top_genres'])),
                 selection_SHA256=hashlib.sha256((BASE/'selection-plan-02.json').read_bytes()).hexdigest(),
                 no_media_downloaded_or_model_started=True)
    with (BASE/'selection-correction-01.json').open('x') as stream:
        stream.write(json.dumps(check, indent=2)+'\n')
    print(json.dumps(check))


if __name__ == '__main__':
    main()
