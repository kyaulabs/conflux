"""Admit publisher-verified FMA metadata and select a fixed key screen.

Reads only CSV/JSON. No archive members are extracted or executed. Musical
labels are global song tags, never local harmonic-change annotations.
"""
import ast
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import re
import resource
import time
import urllib.parse
import zipfile
import zlib

BASE = Path(__file__).resolve().parent
SEED = 'conflux-fmak-key-screen-20261027-v1'
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
csv.field_size_limit(8*1024**2)


def key_class(label):
    match = re.fullmatch(r'([A-G])([#b]?)\s+(major|minor)', label, re.I)
    if not match:
        raise ValueError('Unsupported global key tag')
    letter, accidental, mode = match.groups()
    tonic = ({'C':0, 'D':2, 'E':4, 'F':5, 'G':7, 'A':9, 'B':11}[letter.upper()]
             + {'':0, '#':1, 'b':-1}[accidental.lower()]) % 12
    return tonic+(12 if mode.lower() == 'minor' else 0)


def permissive_license(url):
    value = urllib.parse.urlsplit(url)
    return (value.scheme in ('http', 'https')
            and value.hostname in ('creativecommons.org', 'www.creativecommons.org')
            and value.username is None and value.password is None and value.port is None
            and not value.query and not value.fragment
            and bool(re.fullmatch(r'/licenses/by/(?:1\.0|2\.0|2\.5|3\.0|4\.0)/?'
                                 r'|/publicdomain/zero/1\.0/?', value.path)))


def save(name, value):
    with (BASE/name).open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False)+'\n')


def main():
    start = time.monotonic()
    plan = json.loads((BASE/'metadata-admission-plan-01.json').read_text())
    for row in plan['input_pins']:
        path = Path(row['path'])
        assert not path.is_symlink() and path.stat().st_size == row['bytes']
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for chunk in iter(lambda:stream.read(1024**2), b''):
                digest.update(chunk)
        if digest.hexdigest() != row['sha256']:
            raise ValueError('Publisher/source input hash differs')
    if any((BASE/name).exists() for name in ('catalogue-01.json', 'selection-plan-01.json', 'metadata-admission-01.json')):
        raise FileExistsError('Never replace a prior metadata admission')
    labels_raw = (BASE/'fma_keys_metadata.csv').read_bytes()
    references = {int(row['track_id']):row for row in csv.DictReader(io.StringIO(labels_raw.decode('utf-8-sig')))}
    assert len(references) == 5489
    for row in references.values():
        key_class(row['key_and_mode'])
    archive_path = BASE/'fma_metadata.zip'
    before = archive_path.stat(follow_symlinks=False)
    assert archive_path.is_file() and not archive_path.is_symlink() and before.st_uid == os.getuid()
    members = []
    raw_rows = {}
    catalogue = []
    with zipfile.ZipFile(archive_path) as archive:
        for name, maximum in (('genres.csv', 65536), ('raw_tracks.csv', 128*1024**2), ('tracks.csv', 256*1024**2)):
            member = archive.getinfo('fma_metadata/'+name)
            if member.file_size > maximum or member.flag_bits & 1:
                raise ValueError('Metadata member extent or encryption differs')
            digest = hashlib.sha256()
            crc = 0
            size = 0
            with archive.open(member) as stream:
                for chunk in iter(lambda:stream.read(1024**2), b''):
                    if time.monotonic()-start > 120:
                        raise TimeoutError('Metadata admission deadline')
                    digest.update(chunk)
                    crc = zlib.crc32(chunk, crc)
                    size += len(chunk)
            assert size == member.file_size and crc == member.CRC
            members.append(dict(name=member.filename, bytes=size, SHA256=digest.hexdigest(), CRC32=f'{crc:08x}', CRC_verified=True))
        with archive.open('fma_metadata/genres.csv') as stream:
            genres = {int(row['genre_id']):row for row in csv.DictReader(io.TextIOWrapper(stream, encoding='utf-8', newline=''))}
        with archive.open('fma_metadata/raw_tracks.csv') as stream:
            for row in csv.DictReader(io.TextIOWrapper(stream, encoding='utf-8', newline='')):
                track = int(row['track_id'])
                if track in references:
                    if track in raw_rows:
                        raise ValueError('Duplicate raw track metadata')
                    raw_rows[track] = {key:row[key] for key in ('license_url', 'license_title', 'track_file', 'track_url')}
        with archive.open('fma_metadata/tracks.csv') as stream:
            reader = csv.reader(io.TextIOWrapper(stream, encoding='utf-8', newline=''))
            groups, columns, index = next(reader), next(reader), next(reader)
            assert index[0] == 'track_id' and len(groups) == len(columns) == len(index) == 53
            fields = {(group, column):offset for offset, (group, column) in enumerate(zip(groups, columns))}
            def get(row, group, column):
                return row[fields[(group, column)]]
            seen = set()
            metadata_count = 0
            for row in reader:
                if len(row) != len(columns):
                    raise ValueError('Malformed source metadata row')
                metadata_count += 1
                track = int(row[0])
                if track not in references:
                    continue
                if track in seen or track not in raw_rows:
                    raise ValueError('Missing or duplicate matching metadata')
                seen.add(track)
                raw = raw_rows[track]
                encoded = get(row, 'track', 'genres_all')
                assert len(encoded) < 2048
                ids = ast.literal_eval(encoded)
                if not isinstance(ids, list) or len(ids) > 163 or any(type(i) is not int or i not in genres for i in ids):
                    raise ValueError('Invalid genre identifiers')
                roots = sorted({genres[i]['title'] for i in ids if int(genres[i]['parent']) == 0})
                duration = int(get(row, 'track', 'duration'))
                artist = get(row, 'artist', 'id')
                record = dict(track_id=track, reference_label=references[track]['key_and_mode'],
                              reference_class=key_class(references[track]['key_and_mode']),
                              duration_metadata_seconds=duration, artist_id=int(artist) if artist else None,
                              artist=get(row, 'artist', 'name'), title=get(row, 'track', 'title'),
                              split=get(row, 'set', 'split'), subset=get(row, 'set', 'subset'),
                              genre_top=get(row, 'track', 'genre_top'), top_genres=roots,
                              license_title=raw['license_title'], license_url=raw['license_url'],
                              original_track_file=raw['track_file'], original_track_url=raw['track_url'])
                record['eligible'] = (permissive_license(record['license_url'])
                                      and 30 <= duration <= 600 and record['artist_id'] is not None
                                      and bool(roots))
                catalogue.append(record)
            if seen != set(references) or metadata_count != 106574:
                raise ValueError('FMAK-to-FMA metadata population differs')
    assert time.monotonic()-start < 120
    catalogue.sort(key=lambda row:row['track_id'])
    eligible = [row for row in catalogue if row['eligible']]
    selected = []
    used_artists = set()
    for index in range(24):
        pool = [row for row in eligible if row['reference_class'] == index and row['artist_id'] not in used_artists]
        pool.sort(key=lambda row:hashlib.sha256((SEED+':'+str(row['track_id'])).encode()).digest())
        if pool:
            selected.append(pool[0])
            used_artists.add(pool[0]['artist_id'])
        else:
            selected.append(dict(reference_class=index, status='Unavailable', reason='No eligible unused artist in this fixed class'))
    counts = Counter(row['reference_class'] for row in eligible)
    save('catalogue-01.json', dict(schema=1, metadata_sources=plan['metadata_sources'], records=catalogue,
                                  global_song_key_labels_only=True, candidate_predictions_seen=False))
    save('selection-plan-01.json', dict(schema=1, status='frozen_before_media_download_or_model_inference',
          seed=SEED, rule=plan['selection_rule'], denominator=24, cases=selected,
          eligible_counts_by_class={str(k):counts[k] for k in range(24)},
          eligible_tracks=len(eligible), selected_unique_artists=len(used_artists),
          global_song_key_labels_only=True, no_local_key_change_ground_truth=True,
          exact_released_model_training_membership_verified=False,
          musical_or_latency_qualification=False, physical_readiness_required_for_this_metadata_work=False))
    after = archive_path.stat(follow_symlinks=False)
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise ValueError('Owned temporary archive identity changed')
    result = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                  status='FMAK_metadata_admitted_and_fixed_sample_selected',
                  publisher_archive_SHA1_verified=True, metadata_members=members,
                  original_FMA_tracks=metadata_count, FMAK_references_matched=len(catalogue),
                  eligible_tracks=len(eligible), selected_tracks=sum('track_id' in row for row in selected),
                  selected_unique_artists=len(used_artists), fixed_denominator=24,
                  selected_top_genres=dict(Counter(g for row in selected for g in row.get('top_genres', []))),
                  catalogue_SHA256=hashlib.sha256((BASE/'catalogue-01.json').read_bytes()).hexdigest(),
                  selection_SHA256=hashlib.sha256((BASE/'selection-plan-01.json').read_bytes()).hexdigest(),
                  elapsed_seconds=time.monotonic()-start, audio_downloaded=False, model_started=False,
                  no_pickle_or_other_archive_code_executed=True, product_configuration_changed=False,
                  owned_temporary_archive_bytes=before.st_size, owned_temporary_archive_deleted=False)
    # Only the exact owned, verified download is removed. Other files are untouched.
    archive_path.unlink()
    result['owned_temporary_archive_deleted'] = not archive_path.exists()
    save('metadata-admission-01.json', result)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
