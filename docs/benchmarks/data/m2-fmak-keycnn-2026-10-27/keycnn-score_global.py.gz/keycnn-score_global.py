"""Predeclared global posterior mean; no local-key accuracy or calibration claim."""
import hashlib
import json
import math
from pathlib import Path
import protocol

def global_class(rows):
    if not rows or not any(row['signal_nonzero'] for row in rows):
        return None, []
    means = [math.fsum(row['probabilities'][key] for row in rows)/len(rows) for key in range(24)]
    return max(range(24), key=lambda key:(means[key], -key)), means

def score(plan, captures):
    assert len(captures) == len(plan['cases']) == 24
    assert [row['id'] for row in captures] == [case['id'] for case in plan['cases']]
    predictions = {}
    for case, row in zip(plan['cases'], captures, strict=True):
        if row['complete']:
            path = Path(row['prediction_path'])
            assert path == Path(plan['output'])/(case['id']+'-prediction.json')
            raw = path.read_bytes()
            assert len(raw) <= 524288 and hashlib.sha256(raw).hexdigest() == row['prediction_sha256']
            value = json.loads(raw)
            protocol.validate_prediction(value, row['source'], case)
            predictions[case['id']] = global_class(value['raw_predictions'])
    reference = plan['reference']
    raw = Path(reference['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == reference['sha256']
    selected = json.loads(raw)['cases']
    truth = {f"{row['track_id']:06d}":row['reference_class'] for row in selected}
    assert len(truth) == 24 and set(truth) == {row['id'] for row in captures}
    rows = []
    for row in captures:
        key, means = predictions.get(row['id'], (None, []))
        rows.append(dict(id=row['id'], reference_class=truth[row['id']], predicted_class=key,
                         match=key is not None and key == truth[row['id']],
                         status='Estimated' if key is not None else ('Unknown' if row['complete'] else row['status']),
                         mean_probabilities=means, confidence='Unknown'))
    correct = sum(row['match'] for row in rows)
    estimated = sum(row['predicted_class'] is not None for row in rows)
    ready = [case['id'] for case in plan['cases'] if case['preparation_status']=='PreparedMetadataMeasured']
    return dict(schema=1, fixed_denominator=24, cases=rows,
                global_exact=dict(matches=correct, denominator=24, percent=correct/24*100),
                estimated_subset=dict(matches=correct, denominator=estimated,
                                      percent=correct/estimated*100 if estimated else None),
                source_preparation_failures=24-len(ready),
                inference_pipeline_pass=all(row['complete'] for row in captures if row['id'] in ready),
                operational_pass=all(row['complete'] for row in captures), confidence='Unknown',
                original_training_environment_reproduced=False, legacy_TensorFlow_equivalence_verified=False,
                training_independence_verified=False, local_key_change_accuracy_qualified=False,
                audio_device_opened=False, GPU_started=False, qualified=False,
                aggregation_rule_sha256=plan['aggregation_rule']['sha256'])
