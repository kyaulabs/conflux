#!/home/kyau/projects/kyaulabs/conflux/build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/model-data-audit-01/feature-compatibility-01/venv/bin/python -I
"""Fixed private source PCM to legacy-CQT numeric key-CNN predictions, no labels."""
import sys
sys.dont_write_bytecode = True
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import time
import warnings

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import protocol


def warning_summary(recorded):
    counts = Counter((w.category.__name__, str(w.message), w.filename, w.lineno) for w in recorded)
    return dict(total=len(recorded), unique=len(counts), entries=[dict(category=k[0], message=k[1],
        filename=k[2], line=k[3], count=n) for k, n in counts.items()])


def main(recorded, context):
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', required=True)
    parser.add_argument('--frames', type=int, required=True)
    args = parser.parse_args()
    plan = json.loads((BASE/'music-plan-01.json').read_text())
    choices = [case for case in plan['cases'] if case['id'] == args.case and
               case.get('preparation_status') == 'PreparedMetadataMeasured' and case['prepared_frames'] == args.frames]
    if len(choices) != 1:
        raise ValueError('Only a fixed successfully prepared corpus source is allowed')
    case = choices[0]
    context['case'] = case['id']
    began = time.monotonic()
    def phase(name):
        print(json.dumps(dict(phase=name, elapsed_seconds=time.monotonic()-began,
                              warnings_captured=len(recorded))), file=sys.stderr, flush=True)
    raw = protocol.read_pcm(sys.stdin.buffer, args.frames, case['pcm_sha256'])
    phase('input_verified')
    for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMBA_NUM_THREADS'):
        os.environ[key] = '1'
    feature = protocol.DATA/'feature-compatibility-01'
    os.environ['NUMBA_CACHE_DIR'] = str(feature/'numba-cache')
    os.environ.pop('LIBROSA_CACHE_DIR', None)
    resource.setrlimit(resource.RLIMIT_AS, (3*1024**3, 3*1024**3))
    resource.setrlimit(resource.RLIMIT_CPU, (80, 80))
    manifest = json.loads((feature/'source-downloads-01.json').read_text())
    for package in manifest['source_packages']:
        for row in package['files']:
            content = Path(row['path']).read_bytes()
            if len(content) != row['bytes'] or hashlib.sha256(content).hexdigest() != row['sha256']:
                raise ValueError('Legacy feature source hash differs')
    import numba
    sys.modules['numba.decorators'] = numba
    sys.path[:0] = [str(feature/'legacy-source/librosa'), str(feature/'legacy-source/resampy')]
    import librosa
    import numpy as np
    import resampy
    import scipy
    phase('feature_imports_complete')
    if (sys.version_info[:3] != (3, 10, 22) or librosa.__version__ != '0.6.2'
            or resampy.__version__ != '0.2.2' or np.__version__ != '1.23.5'
            or scipy.__version__ != '1.10.1' or numba.__version__ != '0.57.1'):
        raise ValueError('Fixed numerical dependencies differ')
    pcm = np.frombuffer(raw, dtype='<f4').reshape(args.frames, 2)
    if not np.isfinite(pcm).all():
        raise ValueError('Nonfinite prepared PCM')
    samples, columns, count = protocol.clock.geometry(args.frames)
    mono = pcm.mean(axis=1, dtype=np.float32)
    y = librosa.resample(mono, 48000, 22050, res_type='kaiser_best')
    phase('source_resampled')
    if len(y) != samples:
        raise ValueError('Resampled source extent differs')
    cqt = np.abs(librosa.cqt(y, sr=22050, hop_length=4096,
                             fmin=librosa.note_to_hz('E1'), n_bins=168, bins_per_octave=24))
    phase('CQT_complete')
    if cqt.shape != (168, columns) or not np.isfinite(cqt).all():
        raise ValueError('CQT geometry differs')
    padded = np.pad(cqt, ((0, 0), (30, 30)))
    features = np.stack([padded[:, first:first+60, None] for first in range(0, columns+1, 8)])
    if features.shape != (count, 168, 60, 1):
        raise ValueError('Prediction windows differ')
    path = protocol.DATA/'numeric-forward-03/keycnn_numeric.py'
    spec = importlib.util.spec_from_file_location('fixed_numeric_keycnn_diagnostic', path)
    numeric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(numeric)
    posterior = numeric.predict(features, numeric.weights(), batch_size=4)
    phase('classifier_complete')
    raw_predictions = [dict(index=i, probabilities=posterior[i].tolist(),
                            signal_nonzero=bool(np.any(features[i]))) for i in range(count)]
    windows = protocol.projection(args.frames, raw_predictions)
    value = dict(schema=1, recipe=protocol.RECIPE, model_sha256=protocol.MODEL_SHA,
                 frames=args.frames, sample_rate=48000, channels=2, pcm_sha256=case['pcm_sha256'],
                 CQT_columns=columns, raw_predictions=raw_predictions,
                 window_count=len(windows), windows=windows, confidence='Unknown',
                 qualified=False, audio_device_opened=False, GPU_started=False,
                 original_training_environment_reproduced=False,
                 legacy_TensorFlow_equivalence_verified=False, training_independence_verified=False,
                 captured_warning_count=len(recorded))
    protocol.validate_prediction(value, None, case)
    encoded = (json.dumps(value, separators=(',', ':'), allow_nan=False)+'\n').encode()
    if len(encoded) > 524288:
        raise ValueError('Prediction output exceeds the frozen byte limit')
    sys.stdout.buffer.write(encoded)
    sys.stdout.buffer.flush()


if __name__ == '__main__':
    context = {}
    result = 0
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter('always')
        try:
            main(recorded, context)
        except Exception as error:
            print(type(error).__name__+': '+str(error)[:1000], file=sys.stderr)
            result = 1
        finally:
            if 'case' in context and (BASE/'output-01').is_dir():
                summary = warning_summary(recorded)
                encoded = (json.dumps(summary, indent=2)+'\n').encode()
                if len(encoded) > 65536:
                    print('Warning summary exceeds64KiB', file=sys.stderr)
                    result = 1
                else:
                    with (BASE/'output-01'/(context['case']+'-warnings.json')).open('xb') as stream:
                        stream.write(encoded)
                    print(json.dumps(dict(warnings_captured=summary['total'], unique=summary['unique'],
                                          full_warning_messages_saved=True)), file=sys.stderr, flush=True)
    raise SystemExit(result)
