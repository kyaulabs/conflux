"""Publish only checksum-bound UTF-8 evidence, excluding corpus/model/PCM binaries."""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
WORK=Path('/home/kyau/.codex/worktrees/release-tree-guard/conflux')
BASE=ROOT/'build/m2-preparation-revision-01'
FMAK=ROOT/'build/m2-fmak-assessment-01'
STAGE=BASE/'uncompressed-review-01'
STAGE.mkdir(mode=0o700)

def archive(folder, items, sources):
    destination=WORK/'docs/benchmarks/data'/folder
    destination.mkdir(parents=True,exist_ok=False)
    expanded=STAGE/folder
    expanded.mkdir(mode=0o700)
    records=[]
    assert len({name for _,name in items})==len(items)
    for path,name in items:
        raw=path.read_bytes()
        raw.decode('utf-8')
        if name.endswith('.json') and raw.strip():json.loads(raw)
        packed=gzip.compress(raw,mtime=0)
        (expanded/name).write_bytes(raw)
        (destination/(name+'.gz')).write_bytes(packed)
        records.append(dict(file=name+'.gz',bytes=len(packed),SHA256=hashlib.sha256(packed).hexdigest(),
                            expanded_bytes=len(raw),expanded_SHA256=hashlib.sha256(raw).hexdigest()))
    product=[]
    for name in sources:
        raw=(WORK/name).read_bytes()
        product.append(dict(path=name,bytes=len(raw),SHA256=hashlib.sha256(raw).hexdigest()))
    value=dict(schema=1,artifacts=records,source_files=product,
               audio_PCM_model_weights_features_or_binaries_included=False,
               musical_or_laptop_latency_qualified=False)
    (destination/'manifest.json').write_text(json.dumps(value,indent=2)+'\n')
    print(json.dumps(dict(folder=folder,artifacts=len(records),compressed_bytes=sum(x['bytes'] for x in records))))

cache=[(BASE/name,name) for name in ['build-red-01.log','build-green-01.log',
    'regression-red-01.log','regression-red-01.json','focused-green-01.log','focused-green-01.json',
    'full-green-01.log','full-green-01.json','archive_evidence.py']]
archive('m2-preparation-revision-2026-10-27',cache,
        ['src/library/StemEngineSupport.cpp','tests/prepared_track_store_test.cpp'])

items=[]
admission=FMAK/'source-admission-01'
for name in ['metadata-download-01.json','metadata-admission-01.json','metadata-admission-plan-01.json',
             'selection-plan-01.json','selection-plan-02.json','selection-correction-01.json',
             'select_sample.py','admit_metadata.py','source-verification-01.json',
             'media-admission-plan-01.json','media-admission-01.json','range_media.py','test_range_media.py']:
    items.append((admission/name,'admission-'+name))
prep=FMAK/'preparation-02'
for name in ['prepared-sources-01.json','root-finished-01.json','music-plan-01.json',
             'offline-verification-01.json','unsupported-inputs-01.json','prepare_source.cpp','sources.hpp',
             'prepare_cases.py','run_once.py','CMakeLists.txt','configure-01.log','build-01.log']:
    items.append((prep/name,'preparation-'+name))
items.append((prep/'output-01/preparation.json','preparation-result.json'))
for ident in ['003853','005153','061480']:
    for suffix in ['receipt.json','stderr.log']:
        items.append((prep/'output-01'/(ident+'.'+suffix),'preparation-'+ident+'-'+suffix))
model=FMAK/'keycnn-01'
for name in ['protocol.py','keycnn_worker.py','run_fmak.py','run_once.py','score_global.py','test_global.py',
             'global-key-rule-01.json','music-plan-01.json','offline-verification-01.json',
             'root-finished-01.json','post-close-verification-01.json','unit.stdout.log','unit.stderr.log']:
    items.append((model/name,'keycnn-'+name))
for path in sorted((model/'output-01').iterdir()):
    if path.is_file() and (path.name in ['predictions-before-scoring.json','scores.json'] or
        any(path.name.endswith(suffix) for suffix in ['-prediction.json','-source.json','-worker.stderr','-warnings.json'])):
        items.append((path,'keycnn-'+path.name))
items.append((BASE/'archive_evidence.py','archive_evidence.py'))
archive('m2-fmak-keycnn-2026-10-27',items,[])
