"""One fixed FMAK global-key diagnostic; CPU only, dry by default."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
BASE = Path(__file__).resolve().parent
OUTPUT = BASE/'output-01'
sys.path.insert(0, str(BASE))
import protocol
from score_global import score
validate_prediction = protocol.validate_prediction

def read(path):
    return json.loads(path.read_text())

def store(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False)+'\n')
        stream.flush()
        os.fsync(stream.fileno())

def verify(pin):
    path = Path(pin['path'])
    assert path.stat().st_size == pin['bytes']
    assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == pin['sha256']

def predict_case(plan, case):
    identifier = case['id']
    spool = OUTPUT / ('spool-' + identifier)
    spool.mkdir(mode=0o700)
    paths = {name: OUTPUT / (identifier + '-' + name) for name in ('prediction.json', 'source.json', 'worker.stderr')}
    producer = consumer = None
    began = time.monotonic()
    with paths['source.json'].open('xb') as metadata, paths['prediction.json'].open('xb') as output, paths['worker.stderr'].open('xb') as errors:
        try:
            producer = subprocess.Popen([plan['preparer']['path'], identifier, str(spool), '--pcm'],
                stdout=subprocess.PIPE, stderr=metadata, start_new_session=True)
            consumer = subprocess.Popen([plan['worker']['path'], '--case', identifier, '--frames', str(case['prepared_frames'])],
                stdin=producer.stdout, stdout=output, stderr=errors, start_new_session=True)
            producer.stdout.close()
            while consumer.poll() is None or producer.poll() is None:
                assert time.monotonic() - began < 160, 'Original160s case bound exhausted'
                assert os.fstat(output.fileno()).st_size <= 524288
                assert os.fstat(metadata.fileno()).st_size <= 4096
                assert os.fstat(errors.fileno()).st_size <= 4096
                time.sleep(.05)
            assert producer.wait() == consumer.wait() == 0, 'Preparation or reference worker failed'
        finally:
            for child in (producer, consumer):
                if child is not None and child.poll() is None:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.wait(timeout=2)
    assert not list(spool.iterdir()), 'Anonymous preparation left spool files'
    source, value = read(paths['source.json']), read(paths['prediction.json'])
    projected = validate_prediction(value, source, case)
    return {'id': identifier, 'complete': True, 'elapsed_seconds': time.monotonic() - began,
        'source': source, 'prediction_path': str(paths['prediction.json']), 'windows': projected,
        'producer_reaped': producer.poll() is not None, 'consumer_reaped': consumer.poll() is not None,
        'spool_empty': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--owned', action='store_true')
    if not parser.parse_args().owned:
        print(json.dumps(dict(status='unarmed_dry', source_opened=False, model_started=False)))
        return 0
    plan = read(BASE/'music-plan-01.json')
    assert plan['status'] == 'frozen_offline_correctness_only' and plan['physical_readiness_required'] is False
    assert any(row.endswith('/'+plan['unit']) for row in Path('/proc/self/cgroup').read_text().splitlines())
    began = time.monotonic()
    deadline = began+plan['limits']['inner_total_seconds']
    for pin in plan['input_pins']:
        verify(pin)
    assert len(plan['cases']) == 24 and len({row['id'] for row in plan['cases']}) == 24
    OUTPUT.mkdir(mode=0o700)
    predictions = []
    for case in plan['cases']:
        if case['preparation_status'] != 'PreparedMetadataMeasured':
            row = dict(id=case['id'], complete=False, model_started=False, error=case['error'],
                       status='SourcePreparationFailed')
        elif time.monotonic()+160 >= deadline:
            row = dict(id=case['id'], complete=False, model_started=False, status='NotRunBudget')
        else:
            try:
                row = predict_case(plan, case)
                path = Path(row['prediction_path'])
                row['prediction_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
                row['status'] = 'PredictionCaptured'
                row['model_started'] = True
            except Exception as error:
                row = dict(id=case['id'], complete=False, status='InferenceFailed',
                           error=dict(type=type(error).__name__, message=str(error)[:1024]))
        predictions.append(row)
        store(OUTPUT/(case['id']+'-capture.json'), row)
        print(json.dumps(dict(id=case['id'], status=row['status'])), flush=True)
    closed = OUTPUT/'predictions-before-scoring.json'
    store(closed, predictions)
    closed_sha = hashlib.sha256(closed.read_bytes()).hexdigest()
    # All per-case descriptors are closed and captures hash-bound before any
    # reference mapping is loaded by score().
    result = score(plan, read(closed))
    for pin in plan['input_pins']:
        verify(pin)
    assert time.monotonic() < deadline
    result.update(elapsed_seconds=time.monotonic()-began, input_pins_unchanged=True,
                  closed_capture_sha256=closed_sha, candidate_predictions_closed_before_scoring=True)
    store(OUTPUT/'scores.json', result)
    print(json.dumps(dict(operational_pass=result['operational_pass'],
                         primary=result['global_exact'], qualified=False)), flush=True)
    return 0 if result['operational_pass'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
