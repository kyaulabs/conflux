"""Read small owned status files only; never start or retry a workload."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
import json
import subprocess
import sys

BASE=Path(__file__).resolve().parent
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes',
 '-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']

def status(base,unit,local):
 def read(p):return json.loads(p.read_text())
 out={'unit':subprocess.check_output(['systemctl']+(['--user'] if local else [])+['show',unit,'--property=ActiveState,SubState,MainPID,Result,ExecMainStatus,InvocationID'],text=True,timeout=5)}
 result=base/('laptop-results-01/pair-result.json' if local else 'pair-result-01.json')
 if result.exists():out['pair']=read(result)
 if local and (base/'guarded-outcome.json').exists():out['guarded_outcome']=read(base/'guarded-outcome.json')
 for arm in ('baseline','candidate'):
  case=base/('laptop-results-01' if local else 'cases')/arm
  progress=case/('output-01/progress.json' if local else 'private-player-01/recordings/actual-player/progress.json')
  if progress.exists():out[arm+'_progress']=read(progress)
  if local:
   p=case/'settling.jsonl'
   if p.exists():
    lines=p.read_text().splitlines();v=json.loads(lines[-1]);out[arm+'_settling']=dict(samples=len(lines),settled_span=v.get('settled_span_seconds'),max_C=max(v['temperatures_millidegrees_C'].values())/1000,profile=v.get('profile_epp_read_only'))
  else:
   p=case/'receipt.json'
   if p.exists():out[arm+'_receipt']=read(p)
 return out

def local():return status(BASE,'conflux-m2-short-cap-laptop-20261029-02.service',True)
def apollo():
 import inspect
 code='from pathlib import Path\nimport json,subprocess\n'+inspect.getsource(status)+"\nprint(json.dumps(status(Path('/srv/conflux-tests/work/short-cap-player-20261029-02'),'conflux-m2-short-cap-apollo-20261029-02.service',False)))\n"
 r=subprocess.run(SSH+['python3 -'],input=code,text=True,capture_output=True,timeout=20)
 assert r.returncode==0,r.stderr;return json.loads(r.stdout)

with ThreadPoolExecutor(max_workers=2) as pool:
 a=pool.submit(local);b=pool.submit(apollo);report=dict(utc=datetime.now(timezone.utc).isoformat(),laptop=a.result(),apollo=b.result())
number=sum(1 for p in BASE.glob('observation-[0-9][0-9][0-9].json'))+1
with (BASE/f'observation-{number:03}.json').open('x') as f:f.write(json.dumps(report,indent=2)+'\n')
# Full progress is retained on disk; omit verbose histories from the chat output.
for host in ('laptop','apollo'):
 row=report[host]
 for arm in ('baseline','candidate'):
  key=arm+'_progress'
  if key in row:row[key]={k:row[key][k] for k in ('phase','measurement_elapsed_ms','elapsed_ms','state','error') if k in row[key]}
print(json.dumps(report))
