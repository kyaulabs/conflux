"""Copy only unarmed CONFLUX operations to a fresh Apollo attempt directory."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess

BASE = Path(__file__).resolve().parent
OLD = BASE.parent / 'm2-short-power-cap-player-01'
spec = importlib.util.spec_from_file_location('unarmed_launch_settings', BASE / 'launch_both.py')
launch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launch)
files = {remote: (BASE / local).read_text() for local, remote in (
    ('apollo_inside.py', 'inside.py'), ('apollo_player_check.py', 'player_check.py'),
    ('private_sink.cpp', 'private_sink.cpp'), ('run_apollo_pair.py', 'run_pair.py'))}
old_binding = json.loads((OLD / 'apollo-operations-binding-01.json').read_text())['binding']
header = ('FILES=' + repr(files) + '\nEXPECTED=' + repr(old_binding) + '\nNEW=' + repr(launch.REMOTE) + '\n')
code = r'''
from pathlib import Path
import hashlib,json,subprocess
old=Path('/srv/conflux-tests/work/short-cap-player-20261029-01');base=Path(NEW)
def pin(p):
 assert p.is_file() and not p.is_symlink()
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h)
assert pin(Path(EXPECTED['path']))==EXPECTED
binding=json.loads(Path(EXPECTED['path']).read_text())
for row in binding['files']:assert pin(Path(row['path']))==row,row['path']
assert not base.exists();base.mkdir(mode=0o700);ops=base/'operations';ops.mkdir(mode=0o700)
copied=[]
for row in binding['files']:
 p=Path(row['path'])
 if p.parent==old/'operations':
  target=ops/p.name
  if p.name in FILES:target.write_text(FILES[p.name])
  else:target.write_bytes(p.read_bytes())
  if p.name=='player_check.py':target.chmod(0o700)
  copied.append(pin(target))
 else:copied.append(row)
binding['files']=copied
for k,v in list(binding.items()):
 if isinstance(v,str):binding[k]=v.replace(str(old),str(base))
with (ops/'binding.json').open('x') as f:f.write(json.dumps(binding,indent=2)+'\n')
dry=subprocess.run(['python3','-B',str(ops/'run_pair.py')],capture_output=True,text=True,timeout=30)
assert dry.returncode==0,dry.stderr
value=json.loads(dry.stdout);assert value['GPU_started'] is False and value['host_audio_opened'] is False
missing=subprocess.run(['python3','-B',str(ops/'run_pair.py'),'--run'],capture_output=True,text=True,timeout=10)
assert missing.returncode!=0 and 'FileNotFoundError' in missing.stderr and str(base/'pair-readiness-01.json') in missing.stderr
assert not any((base/n).exists() for n in ('pair-readiness-01.json','pair-reservation-01.json','pair-result-01.json','cases'))
print(json.dumps(dict(schema=1,binding=pin(ops/'binding.json'),binding_data=binding,dry=value,
 missing_readiness_prevents_host_queries=True,missing_readiness_stderr=missing.stderr,hardware_started=False)))
'''
assert not (BASE / 'apollo-operations-binding-01.json').exists()
with (BASE / 'remote-preparation.stdout.log').open('x') as out, (BASE / 'remote-preparation.stderr.log').open('x') as err:
    result = subprocess.run(launch.SSH + ['python3 -'], input=header + code, text=True,
        stdout=out, stderr=err, timeout=60)
result.check_returncode()
remote = json.loads((BASE / 'remote-preparation.stdout.log').read_text())
with (BASE / 'apollo-operations-binding-01.json').open('x') as stream:
    json.dump(remote, stream, indent=2)
print(json.dumps(dict(unarmed=True, hardware_started=False, remote_files=len(remote['binding_data']['files']))))
