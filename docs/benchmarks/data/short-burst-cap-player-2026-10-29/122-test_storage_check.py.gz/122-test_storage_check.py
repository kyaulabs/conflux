"""Check storage refusal and the exact admission boundary without host actions."""
from pathlib import Path
from types import SimpleNamespace
import importlib.util
import json
import tempfile
import time
import unittest
from unittest.mock import Mock, patch

BASE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('storage_under_test',BASE/'storage_check.py')
storage=importlib.util.module_from_spec(s);s.loader.exec_module(storage)

class StorageTests(unittest.TestCase):
 def test_refuses_one_byte_below_the_reserve(self):
  with patch.object(storage.shutil,'disk_usage',return_value=SimpleNamespace(free=storage.MINIMUM_FREE_BYTES-1)):
   with self.assertRaises(OSError):storage.verify(BASE)
 def test_accepts_exact_reserve_and_returns_the_observed_capacity(self):
  with patch.object(storage.shutil,'disk_usage',return_value=SimpleNamespace(free=storage.MINIMUM_FREE_BYTES)):
   self.assertEqual(storage.verify(BASE),dict(free_bytes=storage.MINIMUM_FREE_BYTES,minimum_free_bytes=storage.MINIMUM_FREE_BYTES))
 def test_real_guarded_owner_refuses_before_loading_or_pausing_sync(self):
  s=importlib.util.spec_from_file_location('storage_real_guarded',BASE/'run_local_guarded.py')
  guarded=importlib.util.module_from_spec(s);s.loader.exec_module(guarded)
  with tempfile.TemporaryDirectory(dir=BASE) as directory:
   root=Path(directory);driver=root/'run_laptop_pair.py';driver.write_text('# fixture')
   import hashlib
   row=dict(path=str(driver),bytes=driver.stat().st_size,sha256=hashlib.sha256(driver.read_bytes()).hexdigest())
   (root/'laptop-plan.json').write_text(json.dumps(dict(pins=dict(driver=row))))
   (root/'readiness.json').write_text('{}')
   runner=SimpleNamespace(clock=Mock(),pin=Mock(return_value={'sha256':'fixture'}),verify=Mock(),load=Mock(),main=Mock())
   def imported(name,path):
    if name=='normal_player_owner':return runner
    if name=='pre_pause_storage':return storage
    self.fail('Unexpected helper load: '+name)
   with patch.object(guarded,'BASE',root),patch.object(guarded,'load',side_effect=imported),patch('sys.argv',['fixture','--run']),patch.object(storage.shutil,'disk_usage',return_value=SimpleNamespace(free=0)),self.assertRaises(OSError):
    guarded.main()
   runner.load.assert_not_called();runner.main.assert_not_called()
   self.assertFalse((root/'onedrive-pause-state.json').exists())
 def test_space_loss_during_settling_prevents_cap_and_native_launch(self):
  s=importlib.util.spec_from_file_location('storage_real_pair',BASE/'run_laptop_pair.py')
  pair=importlib.util.module_from_spec(s);s.loader.exec_module(pair)
  with tempfile.TemporaryDirectory(dir=BASE) as directory:
   root=Path(directory)
   plan=dict(state='frozen_pending_fresh_readiness',pins=dict(host_readings={},guard_script={'path':'/fixture/guard'},guard_unit={'path':'/fixture/unit'},storage_check={}))
   (root/'laptop-plan.json').write_text(json.dumps(plan))
   (root/'readiness.json').write_text(json.dumps(dict(recorded_at_utc='offline-fixture')))
   def imported(name,row):
    if name=='staging_host_readings':return SimpleNamespace(guard_identity=Mock(return_value={}))
    if name=='pre_cap_storage':return storage
    self.fail('A cap or native helper was loaded after storage refusal: '+name)
   with patch.object(pair,'BASE',root),patch.object(pair,'verify'),patch.object(pair,'clock',return_value=time.monotonic()+1200),patch.object(pair,'prepare_host'),patch.object(pair,'load',side_effect=imported),patch('sys.argv',['fixture','--run']),patch.object(storage.shutil,'disk_usage',return_value=SimpleNamespace(free=0)),patch('builtins.print'):
    self.assertEqual(pair.main(),1)
   result=json.loads((root/'laptop-results-01/pair-result.json').read_text())
   self.assertEqual(result['workload_attempted_arms'],[])
   self.assertEqual(result['errors'][0]['type'],'OSError')
   self.assertNotIn('cap_apply',result)

if __name__=='__main__':unittest.main(verbosity=2)
