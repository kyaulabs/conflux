"""Verify the real desktop wrapper remains unarmed and releases its idle blockers."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import time

BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('staging_launch_offline',BASE/'launch_both.py')
launch=importlib.util.module_from_spec(spec);spec.loader.exec_module(launch)

def show(unit):
 raw=subprocess.check_output(['systemctl','--user','show',unit,'--property=LoadState,ActiveState,SubState,MainPID,Result,ExecMainStatus'],text=True,timeout=5)
 return dict(s.split('=',1) for s in raw.splitlines() if '=' in s)
def inhibitors():
 command=['busctl','--user','--timeout=2s','--json=short','call','org.kde.Solid.PowerManagement.PolicyAgent',
  '/org/kde/Solid/PowerManagement/PolicyAgent','org.kde.Solid.PowerManagement.PolicyAgent','ListInhibitions']
 value=json.loads(subprocess.check_output(command,text=True,timeout=5));assert value['type']=='aas';return value['data'][0]

assert not any((BASE/n).exists() for n in ('readiness.json','laptop-results-01','launch-reservation.json'))
unit='conflux-m2-short-cap-offline-entry-20261029-02.service'
before=show(unit);assert before['LoadState']=='not-found' and before['MainPID']=='0'
initial=inhibitors()
command=launch.local_command(unit,live=False)
dispatch=subprocess.run(command,capture_output=True,text=True,timeout=10);assert dispatch.returncode==0,dispatch.stderr
try:
 until=time.monotonic()+30
 while True:
  state=show(unit)
  if state['MainPID']=='0':break
  assert time.monotonic()<until;time.sleep(.2)
 assert state['Result']=='success' and state['ExecMainStatus']=='0',state
 value=json.loads((BASE/'offline-unit.stdout.log').read_text());assert value['verified'] and value['hardware_started'] is False
 environment=value['ui_environment'];assert environment['requested_render_loop']=='basic' and environment['effective_environment']['QSG_RENDER_LOOP']=='basic' and environment['graphics_backend_setting_unchanged'] and environment['actual_render_loop_requires_native_log']
 assert not (BASE/'offline-unit.stderr.log').read_text()
 prefix=command[command.index('/usr/bin/kde-inhibit'):]
 missing=subprocess.run(prefix+['--run'],capture_output=True,text=True,timeout=10)
 # KDE's inhibitor returns zero even when its child fails; inspect the child's diagnostic boundary.
 assert 'FileNotFoundError' in missing.stderr and str(BASE/'readiness.json') in missing.stderr
 assert not missing.stdout
finally:
 subprocess.run(['systemctl','--user','stop',unit],check=True,capture_output=True,text=True,timeout=20)
assert show(unit)['MainPID']=='0'
after=inhibitors();assert sorted(after)==sorted(initial),(initial,after)
manager={k:v for k,v in (s.split('=',1) for s in subprocess.check_output(['systemctl','--user','show-environment'],text=True,timeout=5).splitlines() if '=' in s)
 if k in ('DISPLAY','WAYLAND_DISPLAY','XDG_RUNTIME_DIR','QT_QPA_PLATFORM','QT_QUICK_BACKEND','QT_QUICK_CONTROLS_STYLE')}
assert manager.get('WAYLAND_DISPLAY') and manager.get('XDG_RUNTIME_DIR')
assert manager.get('QT_QUICK_BACKEND','') not in ('software',),manager
assert not any((BASE/n).exists() for n in ('readiness.json','laptop-results-01','launch-reservation.json'))
receipt=dict(schema=1,passed=True,command=command,unit_before=before,unit_terminal=state,unit_after_stop=show(unit),
 real_desktop_dry_verified=True,missing_readiness_prevents_owner_import_and_workload=True,missing_stderr=missing.stderr,missing_wrapper_exit=missing.returncode,
 idle_inhibitions_released=True,manager_display_environment=manager,hardware_model_audio_started=False,
 verifier_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with (BASE/'actual-desktop-entry-check-01.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(passed=True,actual_unit_verified=True,missing_readiness_blocks_workload=True,idle_inhibitions_released=True,hardware_started=False)))
