"""Check original journal identities and both finalized WAVs without playback."""
from pathlib import Path
import ast,hashlib,json,struct,subprocess
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent
wrapper=json.loads((ROOT/'laptop-results-01/candidate/output-01/result.json').read_text())
native=wrapper['native'];bind=json.loads((ROOT/'owner-binding-01.json').read_text())['laptop']
rows=[json.loads(s) for s in (BASE/'native-unit-journal-01.jsonl').read_text().splitlines()]
expected={'_PID':str(native['pid']),'_UID':'1000','_EXE':wrapper['pins_before']['binary']['canonical_path'],'_SYSTEMD_USER_UNIT':bind['unit'],'_SYSTEMD_INVOCATION_ID':bind['InvocationID'],'QT_CATEGORY':'qt.scenegraph.general'}
owned=[r for r in rows if all(r.get(k)==v for k,v in expected.items())]
start=wrapper['host_before']['monotonic_ns'];end=wrapper['host_after']['monotonic_ns']
assert all(start<=int(r['__MONOTONIC_TIMESTAMP'])*1000<=end for r in owned)
loops=[r for r in owned if r.get('MESSAGE') in ('basic render loop','threaded render loop','windows render loop')]
assert len(loops)==1 and loops[0]['MESSAGE']=='basic render loop'
proof=dict(schema=1,confirmed=True,loop='basic',expected_identity=expected,clock_window_ns=[start,end],matching_original_messages=loops,original_empty_stream_assessment_preserved=True,workload_rerun=False)
(BASE/'render-loop-journal-proof-01.json').write_text(json.dumps(proof,indent=2)+'\n')
# Header/count audit reads at most 64 KiB; native finite-sample scan is retained separately.
code=r'''
from pathlib import Path
import json,struct
b=Path(BASE)
n=json.loads((b/'native-result.json').read_text());p=b/'master.wav';assert p.is_file() and not p.is_symlink()
size=p.stat().st_size
with p.open('rb') as f:head=f.read(65536)
assert head[:4]==b'RIFF' and head[8:12]==b'WAVE' and struct.unpack_from('<I',head,4)[0]+8==size
at=12;fmt=None;data=None
while at+8<=len(head):
 kind=head[at:at+4];length=struct.unpack_from('<I',head,at+4)[0]
 if kind==b'fmt ':fmt=struct.unpack_from('<HHIIHH',head,at+8)
 if kind==b'data':data={'offset':at+8,'bytes':length};break
 at+=8+length+(length%2)
assert fmt==(3,2,48000,384000,8,32),fmt
assert data and data['bytes']==n['recording']['writtenFrames']*8 and data['offset']+data['bytes']<=size
assert n['recording']['acceptedFrames']==n['recording']['writtenFrames']==n['recorded_audio']['frames']
assert p.stat().st_size==size
print(json.dumps({'header_counts_match':True,'format':'stereo 48 kHz float32 RIFF WAV','bytes':size,'frames':n['recording']['writtenFrames'],'data':data,'audio_played_by_audit':False}))
'''
m=ast.parse((ROOT/'observe_both.py').read_text());ssh=ast.literal_eval(next(n.value for n in m.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SSH' for t in n.targets)))
results={}
for host,path,cmd in [('laptop',str(ROOT/'laptop-results-01/candidate/output-01'),['python3','-']),('apollo','/srv/conflux-tests/work/short-cap-player-20261029-02/cases/candidate/private-player-01/recordings/actual-player',ssh+['python3 -'])]:
 r=subprocess.run(cmd,input='BASE='+repr(path)+'\n'+code,text=True,capture_output=True,timeout=20)
 assert r.returncode==0,(host,r.stderr);results[host]=json.loads(r.stdout)
(BASE/'WAV-audit-01.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'journal_loop_confirmed':True,'WAVs':results,'new_workload_started':False}))
