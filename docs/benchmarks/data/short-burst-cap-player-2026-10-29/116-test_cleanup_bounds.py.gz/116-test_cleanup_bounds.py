"""Original-window service restoration and private-sink budget regressions; no hosts."""
from datetime import datetime,timedelta,timezone
from pathlib import Path
import ast,hashlib,importlib.util,json,re,signal,sys,tempfile,time,unittest
from unittest.mock import patch
BASE=Path(__file__).resolve().parent

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
pair=load('cleanup_clock_pair',BASE/'run_laptop_pair.py')
launch=load('cleanup_clock_launch',BASE/'launch_both.py')

class CleanupBoundsTests(unittest.TestCase):
 def human(self,now,deadline,plan):
  h=dict(mode=pair.MODE,plan_sha256=plan,recorded_at_utc=now.isoformat(),operator_deadline_monotonic=deadline,
   operator_seconds=1200,human_reply='Generated fixture only',question_item_id='offline-only')
  h.update({k:True for k in ('AC_power','lid_open','visible_window','screen_awake','Codex_minimized','other_work_paused','no_suspend')});return h
 def test_bounded_service_stop_does_not_renew_original_clock(self):
  now=datetime.now(timezone.utc);h=self.human(now,3200,'fixture')
  self.assertEqual(pair.clock(h,'fixture',now+timedelta(seconds=150),2150),3200)
  self.assertEqual(pair.clock(h,'fixture',now+timedelta(seconds=180),2180),3200)
  for record,age in [(h,181),(dict(h,operator_deadline_monotonic=3230),150)]:
   with self.assertRaises(AssertionError):pair.clock(record,'fixture',now+timedelta(seconds=age),2000+age)
 def test_local_unit_reserves_restoration_before_original_deadline(self):
  command=launch.local_command('fixture.service',live=True,remaining=1200)
  runtime=int(next(s for s in command if s.startswith('--property=RuntimeMaxSec=')).split('=')[-1][:-1])
  stop=int(next(s for s in command if s.startswith('--property=TimeoutStopSec=')).split('=')[-1][:-1])
  self.assertLessEqual(runtime+stop,1200)
  self.assertGreaterEqual(stop,45+2+5)
  self.assertLessEqual(runtime,1200-90)
  self.assertTrue(any('ExecStopPost='in part and 'run_local_guarded.py'in part and '--restore-only'in part for part in command))
 def test_python_owner_leaves_restore_budget_without_starting_any_owner(self):
  with tempfile.TemporaryDirectory(dir=BASE)as temp:
   root=Path(temp);raw=json.dumps(dict(state='frozen_pending_fresh_readiness')).encode()
   (root/'laptop-plan.json').write_bytes(raw)
   h=self.human(datetime.now(timezone.utc),time.monotonic()+1200,hashlib.sha256(raw).hexdigest())
   (root/'readiness.json').write_text(json.dumps(h))
   with patch.object(pair,'BASE',root),patch.object(sys,'argv',['fixture','--run']),patch.object(pair,'verify',side_effect=RuntimeError('stop before owner import')), \
     patch.object(pair,'load')as owner,patch.object(pair.signal,'signal'),patch.object(pair.signal,'setitimer')as timer,patch('builtins.print'):
    self.assertEqual(pair.main(),1)
   owner.assert_not_called()
   self.assertGreater(timer.call_args_list[0].args[1],1048)
   self.assertLessEqual(timer.call_args_list[0].args[1],1050)
   self.assertEqual(timer.call_args_list[-1].args,(signal.ITIMER_REAL,0))
 def test_sink_lifetime_covers_the_native_wait_and_cleanup(self):
  text=(BASE/'private_sink.cpp').read_text()
  found=re.search(r'end\s*=\s*std::chrono::steady_clock::now\(\)\s*\+\s*std::chrono::seconds\((\d+)\)',text)
  self.assertIsNotNone(found)
  tree=ast.parse((BASE/'apollo_player_check.py').read_text())
  waits=[k.value.value for node in ast.walk(tree) if isinstance(node,ast.Call)
   and isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name)
   and node.func.value.id=='child' and node.func.attr=='wait'
   for k in node.keywords if k.arg=='timeout' and isinstance(k.value,ast.Constant)]
  self.assertTrue(waits)
  self.assertGreaterEqual(int(found.group(1)),max(waits)+30)

if __name__=='__main__':unittest.main(verbosity=2)
