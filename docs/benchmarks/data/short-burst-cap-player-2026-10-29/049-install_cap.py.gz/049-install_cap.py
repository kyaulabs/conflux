"""Install only the approved, bounded burst-cap lease; dry unless --install is given."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import time
from types import SimpleNamespace

SOURCE = Path('/home/kyau/projects/kyaulabs/conflux/build/m2-short-power-cap-player-02/burst_cap.py')
EXPECTED_SHA256 = '3ca7a709d6965b23841bc72fc940775b08cecec1d6f66a95acb074319f5f9f7e'
DIRECTORY = Path('/run/conflux-m2-short-cap-20261029-02')
UNIT = 'conflux-m2-short-cap-20261029-02.service'
PYTHON = '/usr/bin/python3.14'


def show():
    raw = subprocess.check_output(['/usr/bin/systemctl', 'show', UNIT,
        '--property=LoadState,ActiveState,SubState,MainPID,InvocationID,Result,ExecStart'], text=True, timeout=5)
    return dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)


def is_ours(service):
    expected = '{ path=' + PYTHON + ' ; argv[]=' + PYTHON + ' -I -B ' + str(DIRECTORY / 'policy.py') + ' --run ;'
    return expected in service.get('ExecStart', '')


def command(deadline, now):
    remaining = deadline - now
    if not 30 <= remaining <= 1200:
        raise TimeoutError('No bounded lease time remaining')
    payload = str(DIRECTORY / 'policy.py')
    return ['/usr/bin/systemd-run', '--unit=' + UNIT, '--collect',
        '--description=CONFLUX temporary MMIO short-term 15 W comparison',
        '--property=Type=exec', '--property=Restart=no',
        '--property=RuntimeMaxSec=' + str(math.ceil(remaining)) + 's',
        '--property=TimeoutStopSec=10s', '--property=KillMode=control-group',
        '--property=ExecStopPost=' + PYTHON + ' -I -B ' + payload + ' --restore',
        '--property=NoNewPrivileges=yes', '--property=ProtectSystem=strict',
        '--property=ProtectHome=read-only', '--property=PrivateTmp=yes', '--property=PrivateNetwork=yes',
        '--property=ProtectControlGroups=yes', '--property=ProtectKernelModules=yes',
        '--property=ProtectKernelLogs=yes', '--property=ReadOnlyPaths=/sys',
        '--property=ReadWritePaths=' + str(DIRECTORY) + ' ' + str(SOURCE_CAP),
        '--property=RestrictAddressFamilies=AF_UNIX', '--property=LockPersonality=yes',
        '--property=RestrictSUIDSGID=yes', '--property=SystemCallArchitectures=native',
        PYTHON, '-I', '-B', payload, '--run']


SOURCE_CAP = Path('/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_1_power_limit_uw')


def immutable(path, raw):
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fchmod(stream.fileno(), 0o444)
        os.fsync(stream.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--install', action='store_true')
    parser.add_argument('--deadline', type=float)
    parser.add_argument('--boot-id')
    args = parser.parse_args()
    if not args.install:
        print(json.dumps(dict(unarmed=True, host_queried=False, installed=False, policy_written=False)))
        return 0
    if os.geteuid() != 0:
        raise PermissionError('KDE administrator authentication is required for this one lease')
    raw = SOURCE.read_bytes()
    if SOURCE.is_symlink() or hashlib.sha256(raw).hexdigest() != EXPECTED_SHA256:
        raise ValueError('Reviewed immutable payload changed')
    scope = dict(__name__='reviewed_burst_payload', __file__=str(DIRECTORY / 'policy.py'))
    exec(compile(raw, str(SOURCE), 'exec'), scope)
    policy = SimpleNamespace(**scope)
    config = dict(schema=1, deadline_monotonic=args.deadline, boot_id=args.boot_id,
        payload_sha256=EXPECTED_SHA256, approved_short_term_ceiling_uw=15000000)
    policy.validate_host(config)
    if DIRECTORY.exists() or DIRECTORY.is_symlink() or show()['LoadState'] != 'not-found':
        raise FileExistsError('An existing lease must be inspected; do not install twice')
    dispatch = command(args.deadline, time.monotonic())
    DIRECTORY.mkdir(mode=0o700)
    # The user owner runs with UMask=0077. Receipts must remain readable after
    # pkexec inherits that mask, while every installed file stays root-owned.
    DIRECTORY.chmod(0o755)
    immutable(DIRECTORY / 'policy.py', raw)
    immutable(DIRECTORY / 'config.json', (json.dumps(config, indent=2) + '\n').encode())
    try:
        # A late administrator response must not apply after the owner has cancelled.
        policy.check_deadline(config)
        subprocess.run(dispatch, check=True, timeout=15, capture_output=True, text=True)
        until = min(time.monotonic() + 8, args.deadline)
        while time.monotonic() < until:
            if policy.STATE.exists():
                state = policy.trusted_json(policy.STATE)
                if state.get('phase') == 'applied':
                    service = show()
                    if service['ActiveState'] != 'active' or int(service['MainPID']) <= 0 or not is_ours(service):
                        raise RuntimeError('Cap owner did not remain active')
                    print(json.dumps(dict(installed=True, applied=True, root_state=str(policy.STATE),
                        payload_sha256=EXPECTED_SHA256, deadline_monotonic=args.deadline,
                        service=service, current_uw=policy.number(SOURCE_CAP))), flush=True)
                    return 0
                if state.get('finished'):
                    raise RuntimeError('Cap owner ended before confirmation')
            time.sleep(.1)
        raise TimeoutError('Root cap owner did not confirm apply')
    except BaseException:
        # Dispatch may have succeeded even if its transport failed. Stop only this
        # freshly-created fixed unit; its immutable ExecStopPost handles rollback.
        if is_ours(show()):
            subprocess.run(['/usr/bin/systemctl', 'stop', UNIT], capture_output=True, text=True, timeout=30)
        subprocess.run([PYTHON, '-I', '-B', str(DIRECTORY / 'policy.py'), '--restore'],
            check=True, capture_output=True, text=True, timeout=15)
        raise


if __name__ == '__main__':
    raise SystemExit(main())
