"""Package the closed burst-cap diagnostic as bounded text evidence."""
from pathlib import Path
import gzip,hashlib,json
BASE=Path(__file__).resolve().parent
summary=json.loads((BASE/'analysis-01/results-summary-01.json').read_text())
restored=json.loads((BASE/'final-host-restoration-01.json').read_text())
retired=json.loads((BASE/'owner-retirement-01.json').read_text())
assert restored['owned_setting_restored'] and retired['owned_units_retired']
assert summary['hosts']['laptop']['full_short_run_complete'] and summary['hosts']['apollo']['full_short_run_complete']
stage=BASE/'report-stage-01';stage.mkdir(mode=0o700);data=stage/'data';decoded=stage/'decoded';data.mkdir();decoded.mkdir()
choices=[]
text_suffixes={'.py','.json','.jsonl','.log','.cpp','.hpp'}
for p in sorted(BASE.iterdir()):
 if p.is_file() and not p.is_symlink() and p.suffix in text_suffixes:choices.append((p.name,p))
for area in ('analysis-01','laptop-results-01'):
 for p in sorted((BASE/area).rglob('*')):
  if p.is_file() and not p.is_symlink() and p.suffix in text_suffixes and not any(s in ('cache','tmp','__pycache__') for s in p.relative_to(BASE).parts):
   choices.append((p.relative_to(BASE).as_posix(),p))
previous=BASE.parent/'m2-short-power-cap-player-01'
for name in ('packet-pins.json','readiness.json','both-dispatch.json','guarded-outcome.json','burst-cap-install-result.json','burst-cap-release-result.json','onedrive-pause-state.json','owner-binding-01.json','owner-retirement-01.json','final-host-restoration-01.json','apollo-final-capture-01.json','hour-audio-move-intent-01.json','hour-audio-move-complete-01.json','analysis-01/results-summary-01.json','laptop-results-01/pair-result.json','laptop-results-01/candidate/output-01/result.json'):
 p=previous/name
 if p.is_file():choices.append(('prior-attempt-01/'+name,p))
members=[];aliases=[];seen={};total=0
for name,p in sorted(choices):
 if name=='test_cap_cleanup.py':continue  # Temporary Path fixture, pinned separately; see scan follow-up.
 raw=p.read_bytes();raw.decode('utf-8');assert len(raw)<=8*1024**2;total+=len(raw);assert total<40*1024**2
 digest=hashlib.sha256(raw).hexdigest();key=(len(raw),digest)
 if key in seen:
  aliases.append(dict(source=name,member=seen[key],bytes=len(raw),sha256=digest));continue
 member=f'{len(members):03d}-'+name.replace('/','--')+'.gz';encoded=gzip.compress(raw,compresslevel=9,mtime=0)
 assert gzip.decompress(encoded)==raw
 (data/member).write_bytes(encoded);(decoded/member[:-3]).write_bytes(raw);seen[key]=member
 members.append(dict(source=name,member=member,bytes=len(raw),sha256=digest,gzip_bytes=len(encoded),gzip_sha256=hashlib.sha256(encoded).hexdigest()))
manifest=dict(schema=1,members=members,aliases=aliases,unique_decoded_bytes=sum(r['bytes'] for r in members),gzip_bytes=sum(r['gzip_bytes'] for r in members),qualified=False,omitted_fixture_source={'test_cap_cleanup.py':'Temporary Path assignment produced generic-api-key false positive; immutable pin and test output retained'},audio_binaries_models_caches_included=False,prior_failed_attempt_preserved=True,source_head='48b82030fcf6ab768c4f7b89d65021485cbf9b40')
(data/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
report='''# Temporary burst-cap player diagnostic

The laptop still missed the strict 4.095-second Best-quality service target: **4.231-second p99**, with one late delivery among 21 completed hops. Both hosts completed their two-minute measurements without steady-playback stem starvation, and all scheduled seeks, replays and sixteen controls settled. Apollo reached 1.005-second p99 on private virtual audio. These short captures do not qualify the current-player hour, hard cancellation or M2/M3 and release gates. The temporary cap was restored; no host policy or runtime was promoted.

| Observation | Laptop | Apollo control |
| --- | ---: | ---: |
| Closed measured interval | 120.013 s | 120.010 s |
| Completed service hops | 21 | 22 |
| Nearest-rank service p99 / maximum | **4.231 s** | 1.005 s |
| Hops at or above 4.095 s | **1** | 0 |
| Steady starvation | 0 s | 0 s |
| Seek/replay starvation | 23.280 s | 14.293 s |
| Accessible controls acknowledged | 16/16 | 16/16 |
| Scheduled replays recovered | 4/4 | 4/4 |
| Callback execution deadline misses | 0 | 0 |
| Driver discontinuities / recovery flags | 0 / 0 | 1 / 0 |
| Recording overflow frames | 0 | 0 |
| Recorded stereo frames accepted and written | 6,142,720 | 6,274,048 |

These small populations make nearest-rank p99 equal the maximum. Every completed hop and every measured interval is retained. Logical seek invalidation while the previous generation remained unfinished and one stale-packet rejection were observed on each host. This does not exercise hard worker termination. Invalid buffers, rejected commands, source-read failures and scene errors were zero. Both diagnostic tails closed without added starvation. The finalized stereo 48 kHz float32 WAV headers, payload sizes and frame counts match the native recording scans. Recording integrity does not remove the seek/replay buffering or Apollo's virtual-driver discontinuity; no new listening verdict was obtained.

The laptop's sole late hop was the first request. Its 4,231.283 ms service duration included a 4,093.944 ms GPU graph interval, of which 4,031.613 ms was graph compute/wait. Native inference CPU time was 2,716.597 ms. The remaining twenty service deliveries ranged from 2,574.055 to 2,926.856 ms. Stage durations are nested and must not be added. They identify first-request work as the next profiling target without establishing compilation, scheduling or clocks as its cause. Cold startup remains counted: load to the first observed cursor advance was 7.962 seconds on the laptop and 10.654 seconds on Apollo. The initial seek required another 7.841 seconds from command to published reserve on the laptop.

The human-approved change lowered only the laptop's MMIO short-term allowance from 64 W to 15 W for the bounded test. The MMIO long-term ceiling remained 15 W, all MSR allowances and time windows were preserved, and the existing three-sample thermal guard with immediate 95°C response stayed active. The laptop first settled for sixty sampled seconds at or below 70°C. During the native capture all 71 host samples retained Balanced mode and 15 W for both MMIO allowances. The observed maximum was 69°C, with no sample at or above 85°C. Two-second samples cannot exclude shorter spikes. This is a single follow-up without a newly matched 64 W control, so it does not establish a causal improvement over the earlier failed runs.

Both hosts reused the frozen O2 player at source `48b82030fcf6ab768c4f7b89d65021485cbf9b40`, unchanged Best model/runtime, tracks, cache seed and 16 ms forced redraw. The exact laptop native PID, executable, UID, service invocation, logging category and clock window confirm Qt's basic render loop in the original journal. Its empty captured stream files and original unconfirmed stream-only assessment remain preserved. Apollo retained its offscreen software UI and private audio graph, without host audio output, profile changes or changes to unrelated services.

The first attempt stopped on the laptop before native playback because disk space was below the wrapper's bound. Its temporary cap was held for about one second and restored; no laptop latency or audio measurement exists for that attempt. Its complete Apollo control reached 1.040-second p99 and remains separate. A retained interrupted-hour recording was moved to the dedicated Apollo archive after byte-count and SHA-256 verification, freeing 1.12 GiB locally; the original recording's pointer and transfer receipts remain. The fresh retry passed 91 offline checks and the actual unarmed KDE/systemd entry before new human readiness. It checked at least 3 GiB free before dispatch, before pausing sync and again before applying the cap. Both hosts were then dispatched concurrently within the same twenty-minute operator budget, without an automatic retry.

The approved OneDrive pause held through native cleanup. The cap helper restored the exact 64 W short-term value before OneDrive returned to its original active state. The guard later recorded a 96°C critical reading, after native capture and cap restoration; its lower 7.5 W long-term allowance was preserved by final verification. An initial exact-snapshot verification rejected that lower value; the corrected read-only check verifies restoration of the owned setting while accepting lower external power limits. Both exact owner units are gone with empty original cgroups, the root cap helper is terminal, the private Apollo container is absent and KDE's temporary inhibitors are released. A root-owned Apollo unit log required a second read through sudo; no workload restarted. Cleanup success is separate from the retained laptop latency failure.

The [evidence manifest](data/short-burst-cap-player-2026-10-29/manifest.json) binds the frozen packets and checks, original two-host observations, completed audio/recording results, prior disk-space failure, journals, derived phase timings and restoration proofs. Audio, models, executable binaries and generated caches are excluded. The next experiment must isolate first-request overhead or supply a matched cap comparison before any permanent policy change or renewed hour qualification.
'''
(stage/'report.md').write_text(report)
(stage/'verification-01.json').write_text(json.dumps(dict(unique_members=len(members),aliases=len(aliases),decoded_bytes=manifest['unique_decoded_bytes'],gzip_bytes=manifest['gzip_bytes'],original_failed_result_retained=True),indent=2)+'\n')
print(json.dumps(dict(unique_members=len(members),aliases=len(aliases),decoded_bytes=manifest['unique_decoded_bytes'],gzip_bytes=manifest['gzip_bytes'])))
