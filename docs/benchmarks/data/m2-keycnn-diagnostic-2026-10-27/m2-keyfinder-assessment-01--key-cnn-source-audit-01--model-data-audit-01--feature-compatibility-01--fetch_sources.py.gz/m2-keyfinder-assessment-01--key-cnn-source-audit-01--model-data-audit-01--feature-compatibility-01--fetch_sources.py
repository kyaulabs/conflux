"""Retrieve hashed upstream feature sources as data; never execute setup.py."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import urllib.request

BASE = Path(__file__).resolve().parent
records = []
for package, version in [('librosa', '0.6.2'), ('resampy', '0.2.2')]:
    meta = json.loads((BASE/f'{package}-{version}-metadata.json').read_text())
    entry = next(v for v in meta['urls'] if v['packagetype'] == 'sdist')
    with urllib.request.urlopen(entry['url'], timeout=20) as response:
        raw = response.read(16*1024**2+1)
    assert len(raw) == entry['size'] and len(raw) <= 16*1024**2
    assert hashlib.sha256(raw).hexdigest() == entry['digests']['sha256']
    target = BASE/'legacy-source'/package
    target.mkdir(parents=True, exist_ok=False)
    files = []
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == f'{package}-{version}' and '..' not in parts
            if len(parts) == 1:
                assert member.isdir()
                continue
            relative = PurePosixPath(*parts[1:])
            wanted = ((parts[1] == package and relative.suffix in ('.py', '.npz'))
                      or (len(parts) == 2 and parts[1].lower().startswith('license')))
            if not wanted:
                continue
            assert member.isfile() and member.size <= 8*1024**2
            content = archive.extractfile(member).read()
            assert len(content) == member.size
            path = target.joinpath(*relative.parts)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream:
                stream.write(content)
            files.append(dict(path=str(path), bytes=len(content), sha256=hashlib.sha256(content).hexdigest()))
    records.append(dict(package=package, version=version, archive_url=entry['url'],
                        archive_sha256=entry['digests']['sha256'], archive_bytes=len(raw),
                        files=files, setup_executed=False))
report = dict(recorded_at_utc=datetime.now(timezone.utc).isoformat(), source_packages=records,
              feature_or_model_executed=False)
with (BASE/'source-downloads-01.json').open('x') as stream:
    stream.write(json.dumps(report, indent=2)+'\n')
print(json.dumps(dict(packages=len(records), source_files=sum(len(r['files']) for r in records), setup_executed=False)))
