"""Whole-source normalization and bounded-batch routing; generated data only.

The independent normalization oracle is the original audited source function,
compiled alone as an AST node. Its module, TensorFlow and HDF5 model are never
executed. Most routing checks use row markers; only seven windows run the real
previously audited numeric classifier. This is not a long-track inference test.
"""
from datetime import datetime, timezone
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
from unittest.mock import patch

for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_AS, (3*1024**3, 3*1024**3))
import numpy as np

BASE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def main():
    numeric = load('full_source_numeric_keycnn', BASE/'keycnn_numeric.py')
    upstream = BASE.parent.parent/'source/keycnn/classifier.py'
    audit = json.loads((BASE.parent.parent/'audit-01.json').read_text())
    pin = next(row for row in audit['files'] if row['path'].endswith('/keycnn/classifier.py'))
    raw = upstream.read_bytes()
    if hashlib.sha256(raw).hexdigest() != pin['sha256']:
        raise ValueError('Audited upstream classifier source hash differs')
    source_tree = ast.parse(raw)
    original_normalizer = next(node for node in source_tree.body
                               if isinstance(node, ast.FunctionDef) and node.name == 'std_normalizer')
    isolated = ast.Module(body=[original_normalizer], type_ignores=[])
    namespace = {'np':np}
    exec(compile(isolated, str(upstream)+'::std_normalizer-only', 'exec'), namespace)
    oracle = namespace['std_normalizer']
    before_tree = ast.parse((BASE.parent/'numeric-forward-02/keycnn_numeric.py').read_text())
    after_tree = ast.parse((BASE/'keycnn_numeric.py').read_text())
    before = {node.name:ast.dump(node) for node in before_tree.body if isinstance(node, ast.FunctionDef)}
    after = {node.name:ast.dump(node) for node in after_tree.body if isinstance(node, ast.FunctionDef)}
    if before.keys() != after.keys() or any(before[key] != after[key] for key in before if key != 'normalize'):
        raise ValueError('Unrelated audited numeric inference functions changed')
    clock = load('full_duration_key_clock', BASE.parent/'feature-compatibility-01/source-clock-01/source_clock.py')
    max_source_count = clock.geometry(clock.MAX_SOURCE_FRAMES)[2]
    if not 128 < max_source_count <= 512:
        raise ValueError('Full prepared-source window geometry differs')
    rng = np.random.default_rng(2279401)
    records = []
    real_inputs = None
    for count in (129, max_source_count, 512):
        # Unequal batch populations make per-batch normalization observably wrong.
        value = rng.lognormal(mean=-2., sigma=.8, size=(count, 168, 60, 1)).astype(np.float32)
        value[count//2:] *= np.float32(3.)
        expected = oracle(value).astype(np.float32)
        actual = numeric.normalize(value)
        if not np.array_equal(actual.view(np.uint32), expected.view(np.uint32)):
            raise ValueError('Whole-input upstream normalized bit patterns differ')
        batch_records = []
        for size in (1, 3, 4):
            offset = 0
            calls = 0
            def capture(batch, tensors):
                nonlocal offset, calls
                end = offset+len(batch)
                if not 1 <= len(batch) <= size or not np.array_equal(batch, expected[offset:end]):
                    raise ValueError('Batches changed global statistics, population or row order')
                marker = batch[:, 0, :24, 0].copy()
                offset = end
                calls += 1
                return marker, []
            with patch.object(numeric, 'forward_normalized', side_effect=capture):
                markers = numeric.predict(value, {}, batch_size=size)
            if offset != count or not np.array_equal(markers, expected[:, 0, :24, 0]):
                raise ValueError('Final batch or normalized rows were lost')
            batch_records.append(dict(batch_size=size, calls=calls, all_normalized_rows_exact=True))
        if count == max_source_count:
            real_inputs = np.concatenate([expected[:4], expected[-3:]])
        records.append(dict(windows=count, upstream_normalizer_bitwise_equal=True,
                            normalized_bytes=actual.nbytes, routing_spy_checks=batch_records))
    constants = []
    for value in (0., .25):
        data = np.full((129, 168, 60, 1), value, dtype=np.float32)
        actual = numeric.normalize(data)
        if not np.array_equal(actual, oracle(data).astype(np.float32)) or not np.all(actual == value):
            raise ValueError('Constant-input upstream normalization differs')
        constants.append(value)
    for invalid in (np.zeros((513, 168, 60, 1), dtype=np.float32),
                    np.full((1, 168, 60, 1), np.inf, dtype=np.float32),
                    np.zeros((1, 168, 59, 1), dtype=np.float32)):
        try:
            numeric.normalize(invalid)
        except ValueError:
            pass
        else:
            raise ValueError('Malformed or oversized normalization accepted')
    try:
        numeric.normalize(np.full((1, 168, 60, 1), 100000., dtype=np.float32))
    except (FloatingPointError, ValueError) as error:
        if 'overflow' not in str(error).lower():
            raise
    else:
        raise ValueError('Float16 conversion overflow accepted')
    tensors = numeric.weights()
    actual_posterior = []
    for value in (real_inputs[:4], real_inputs[-3:]):
        result, _ = numeric.forward_normalized(value, tensors)
        if (not np.isfinite(result).all() or np.any(result < 0) or np.any(result > 1)
                or not np.allclose(result.sum(axis=1), 1., rtol=1e-6, atol=1e-6)):
            raise ValueError('Normalized full-population edge batches fail real numeric inference')
        actual_posterior.extend(result.tolist())
    report = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                  status='full_source_normalization_and_routing_passed',
                  max_source_frames=clock.MAX_SOURCE_FRAMES,
                  max_source_seconds=clock.MAX_SOURCE_FRAMES/48000,
                  default_keygram_windows_for_max_source=max_source_count,
                  prototype_window_bound=512, records=records, constant_input_values=constants,
                  malformed_or_overflow_checks=4, actual_numeric_classifier_windows=7,
                  actual_edge_batch_probabilities=actual_posterior,
                  unchanged_other_numeric_functions=True, model_SHA256=numeric.MODEL_SHA,
                  isolated_upstream_normalizer_function_only=True,
                  TensorFlow_or_Keras_or_HDF5_executed=False,
                  entire_max_source_classifier_inference_executed=False,
                  real_audio_feature_population_executed=False,
                  generated_only=True, GPU_started=False, audio_output_opened=False,
                  musical_accuracy_qualified=False, latency_qualified=False,
                  product_configuration_changed=False)
    with (BASE/'full-duration-result-01.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(status=report['status'], max_source_windows=max_source_count,
                         tested_window_populations=[129, max_source_count, 512],
                         real_numeric_edge_windows=7)))


if __name__ == '__main__':
    main()
