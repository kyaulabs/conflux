"""Source-bound clock and duration regressions, without media/model/device work."""
from fractions import Fraction
import importlib.util
from pathlib import Path
import random
import unittest

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('private_key_clock', BASE/'source_clock.py')
clock = importlib.util.module_from_spec(spec)
spec.loader.exec_module(clock)


class SourceClockChecks(unittest.TestCase):
    def check_partition(self, frames):
        _, columns, count = clock.geometry(frames)
        result = clock.partition(frames, columns, count)
        rows = result['intervals']
        self.assertEqual(rows[0]['first_frame'], 0)
        self.assertEqual(rows[-1]['end_frame'], frames)
        self.assertEqual(sum(row['end_frame']-row['first_frame'] for row in rows), frames)
        self.assertTrue(all(0 <= row['first_frame'] < row['end_frame'] <= frames for row in rows))
        self.assertTrue(all(a['end_frame'] == b['first_frame'] for a, b in zip(rows, rows[1:])))
        self.assertEqual(result['confidence'], 'Unknown')
        for row in rows:
            if row['raw_posterior_index'] is not None:
                self.assertEqual(row['observed_feature_columns']+row['left_zero_feature_columns']+
                                 row['right_zero_feature_columns'], 60)
                anchor = Fraction(row['nominal_center_frame_numerator'], row['nominal_center_frame_denominator'])
                self.assertEqual(row['posterior_index'] is not None, 0 <= anchor < frames)
        return result

    def test_one_second_keeps_unsupported_tail_unknown(self):
        result = self.check_partition(48000)
        self.assertEqual([(r['first_frame'], r['end_frame'], r['posterior_index']) for r in result['intervals']],
                         [(0, 35665, 0), (35665, 48000, None)])
        self.assertEqual(result['intervals'][-1]['reason'], 'no source-bound prediction cell')

    def test_extra_padded_prediction_is_not_a_source_anchor(self):
        result = self.check_partition(62416)
        self.assertEqual(result['cqt_columns'], 8)
        self.assertEqual(result['raw_posterior_count'], 2)
        last = result['intervals'][-1]
        self.assertEqual((last['raw_posterior_index'], last['posterior_index'], last['status']), (1, None, 'Unknown'))
        self.assertEqual(last['end_frame'], 62416)

    def test_one_frame_remains_bounded(self):
        result = self.check_partition(1)
        self.assertEqual([(r['first_frame'], r['end_frame']) for r in result['intervals']], [(0, 1)])
        self.assertEqual(result['intervals'][0]['observed_feature_columns'], 1)
        # Geometry alone does not claim that a CQT or classifier accepts this input.

    def test_fractional_clock_does_not_accumulate_rounded_step_drift(self):
        result = self.check_partition(clock.MAX_SOURCE_FRAMES)
        rows = [r for r in result['intervals'] if r['posterior_index'] is not None]
        step = Fraction(8*4096*48000, 22050)
        for previous, current in zip(rows, rows[1:]):
            middle = (previous['posterior_index']+current['posterior_index'])*step/2
            self.assertEqual(current['first_frame'], middle.numerator//middle.denominator)
        self.assertGreater(len(rows), 128)
        self.assertLessEqual(result['raw_posterior_count'], 512)

    def test_full_source_coverage_across_rounding_and_padding_edges(self):
        cases = {1, 2, 47999, 48000, 48001, clock.MAX_SOURCE_FRAMES}
        for k in range(1, 65):
            edge = Fraction(k*8*4096*48000, 22050)
            nearest = edge.numerator//edge.denominator
            cases.update(nearest+offset for offset in (-2, -1, 0, 1, 2))
        rng = random.Random(820417)
        cases.update(rng.randint(1, clock.MAX_SOURCE_FRAMES) for _ in range(256))
        for frames in sorted(cases):
            with self.subTest(frames=frames):
                self.check_partition(frames)

    def test_malformed_extent_and_population_fail_closed(self):
        for value in (True, False, None, 0, -1, 1., '48000', clock.MAX_SOURCE_FRAMES+1):
            with self.subTest(value=value), self.assertRaises(ValueError):
                clock.geometry(value)
        _, columns, count = clock.geometry(48000)
        for bad_columns, bad_count in ((True, count), (columns, True), (columns+1, count),
                                       (columns, count+1), (columns, 0), (0, count)):
            with self.assertRaises(ValueError):
                clock.partition(48000, bad_columns, bad_count)


if __name__ == '__main__':
    unittest.main()
