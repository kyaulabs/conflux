"""Generated feature-to-posterior functional diagnostic; not musical validation."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource

for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
resource.setrlimit(resource.RLIMIT_AS, (3*1024**3, 3*1024**3))
import numpy as np

BASE = Path(__file__).resolve().parent
MODES = ['legacy', 'modern_default', 'modern_reflect', 'modern_reflect_fast', 'modern_reflect_legacy_resampy']
CASES = ['silence', 'E1_tone', 'A4_detuned', 'C_major_chord', 'impulses_edges_and_middle', 'seeded_noise']


def main():
    path = BASE.parent/'numeric-forward-02/keycnn_numeric.py'
    spec = importlib.util.spec_from_file_location('audited_numeric_keycnn', path)
    numeric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(numeric)
    tensors = numeric.weights()
    records = []
    arrays = {}
    for mode in MODES:
        features = BASE/f'{mode}-features-01.npz'
        receipt = json.loads(features.with_suffix('.json').read_text())
        if hashlib.sha256(features.read_bytes()).hexdigest() != receipt['feature_sha256']:
            raise ValueError('Generated feature hash differs')
        with np.load(features, allow_pickle=False) as data:
            for case in CASES:
                value = data[case+'_padded_1']
                if value.shape != (3, 168, 60, 1):
                    raise ValueError('Expected three generated padded windows')
                posterior = numeric.predict(value, tensors, batch_size=3)
                if (posterior.shape != (3, 24) or not np.isfinite(posterior).all()
                        or np.any(posterior < 0) or np.any(posterior > 1)
                        or not np.allclose(posterior.sum(axis=1), 1, rtol=1e-6, atol=1e-6)):
                    raise ValueError('Invalid generated class distribution')
                arrays[mode+'_'+case] = posterior
                records.append(dict(mode=mode, case=case, windows=3,
                                    argmax_indices=posterior.argmax(axis=1).tolist(),
                                    largest_probabilities=posterior.max(axis=1).tolist(),
                                    probabilities=posterior.tolist()))
    comparisons = {}
    for mode in MODES[1:]:
        error = np.concatenate([np.abs(arrays[mode+'_'+case]-arrays['legacy_'+case]) for case in CASES])
        comparisons[mode] = dict(max_probability_difference=float(error.max()),
                                 mean_probability_difference=float(error.mean()),
                                 different_argmax_windows=sum(int(np.count_nonzero(
                                     arrays[mode+'_'+case].argmax(axis=1) != arrays['legacy_'+case].argmax(axis=1)))
                                     for case in CASES), denominator_windows=18)
    report = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                  status='generated_audio_feature_to_posterior_complete',
                  mode_count=5, generated_signal_count=6, windows_per_mode=18,
                  numeric_prototype_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  audited_model_sha256=numeric.MODEL_SHA, weight_tensors=74, parameters=294160,
                  full_population=records, comparisons=comparisons,
                  model_loaded_as='Only hashed raw little-endian float arrays; no HDF5/Keras model execution',
                  generated_only=True, original_training_environment_verified=False,
                  real_music_accuracy_qualified=False, label_mapping_validated=False,
                  confidence_calibrated=False, local_time_alignment_validated=False,
                  GPU_started=False, audio_played=False, product_configuration_changed=False,
                  interpretation='This exercises the generated-audio CQT/window/normalization/classifier path. '
                                 'Posterior agreement or disagreement on these generated signals does not qualify real-music '
                                 'accuracy, model confidence, held-out evaluation or legacy-framework compatibility.')
    with (BASE/'generated-pipeline-01.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(status=report['status'], comparisons=comparisons)))


if __name__ == '__main__':
    main()
