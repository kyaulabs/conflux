"""Compare full generated feature populations; no musical labels or model runs."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path

for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import numpy as np

BASE = Path(__file__).resolve().parent
MODES = ['legacy', 'modern_default', 'modern_reflect', 'modern_reflect_fast', 'modern_reflect_legacy_resampy']
CASES = ['silence', 'E1_tone', 'A4_detuned', 'C_major_chord', 'impulses_edges_and_middle', 'seeded_noise']


def normalize(value):
    # Same whole-population normalization and conversion as the audited model.
    value = value.astype(np.float64)
    deviation = value.std()
    if deviation != 0:
        value = (value-value.mean())/deviation
    return value.astype(np.float16).astype(np.float32)


def difference(reference, candidate):
    if reference.shape != candidate.shape:
        raise ValueError('Feature populations have different geometry')
    ref = reference.astype(np.float64)
    cand = candidate.astype(np.float64)
    error = ref-cand
    norm = float(np.linalg.norm(ref))
    return dict(reference_dtype=str(reference.dtype), candidate_dtype=str(candidate.dtype),
                max_absolute_error=float(np.max(np.abs(error))),
                relative_L2_error=float(np.linalg.norm(error))/norm if norm else (0. if not np.any(error) else None),
                numeric_equality_fraction=float(np.mean(ref == cand)),
                close_rtol_1e_5_atol_1e_7=bool(np.allclose(ref, cand, rtol=1e-5, atol=1e-7)))


def main():
    helpers = {}
    loaded = {}
    for mode in MODES:
        path = BASE/f'{mode}-features-01.npz'
        receipt = json.loads(path.with_suffix('.json').read_text())
        if hashlib.sha256(path.read_bytes()).hexdigest() != receipt['feature_sha256']:
            raise ValueError('Generated comparison data hash differs')
        helpers[mode] = receipt
        with np.load(path, allow_pickle=False) as source:
            expected = {case+suffix for case in CASES for suffix in ('', '_padded_0', '_padded_1')}
            if set(source.files) != expected:
                raise ValueError('Generated comparison population differs')
            loaded[mode] = {key:source[key] for key in expected}
    records = []
    for mode in MODES[1:]:
        for case in CASES:
            reference = loaded['legacy'][case]
            candidate = loaded[mode][case]
            records.append(dict(mode=mode, case=case,
                                full_CQT=difference(reference, candidate),
                                model_input_unpadded=difference(normalize(loaded['legacy'][case+'_padded_0']),
                                                                normalize(loaded[mode][case+'_padded_0'])),
                                model_input_padded=difference(normalize(loaded['legacy'][case+'_padded_1']),
                                                              normalize(loaded[mode][case+'_padded_1']))))
    aggregates = {}
    for mode in MODES[1:]:
        rows = [row for row in records if row['mode'] == mode]
        aggregates[mode] = dict(
            full_CQT_close_cases=sum(row['full_CQT']['close_rtol_1e_5_atol_1e_7'] for row in rows),
            largest_full_CQT_relative_L2=max(row['full_CQT']['relative_L2_error'] for row in rows),
            largest_normalized_padded_max_absolute_error=max(row['model_input_padded']['max_absolute_error'] for row in rows),
            denominator=len(CASES))
    report = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                  status='generated_feature_comparison_complete',
                  generated_cases=CASES, configurations=MODES,
                  helper_boundary_checks_per_configuration=20, malformed_checks_per_configuration=5,
                  each_configuration_windows_bitwise_match_audited_upstream_helpers=True,
                  full_population_records=records, aggregates=aggregates,
                  legacy_runtime=dict(librosa='0.6.2 unmodified source', resampy='0.2.2 unmodified source',
                                      numba_import_alias='numba.decorators -> numba (same jit callable)',
                                      Python='3.10.22', NumPy='1.23.5', SciPy='1.10.1'),
                  original_training_dependencies_reproduced=False, model_inference_executed=False,
                  audio_played=False, GPU_started=False, product_configuration_changed=False,
                  musical_accuracy_qualified=False, latency_qualified=False,
                  conclusion='Current Librosa features cannot be assumed numerically interchangeable with the audited legacy feature path. '
                             'The generated comparison does not establish original training-environment compatibility, '
                             'model posterior equivalence, local-time alignment or real-music accuracy.')
    with (BASE/'assessment-01.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(status=report['status'], aggregates=aggregates)))


if __name__ == '__main__':
    main()
