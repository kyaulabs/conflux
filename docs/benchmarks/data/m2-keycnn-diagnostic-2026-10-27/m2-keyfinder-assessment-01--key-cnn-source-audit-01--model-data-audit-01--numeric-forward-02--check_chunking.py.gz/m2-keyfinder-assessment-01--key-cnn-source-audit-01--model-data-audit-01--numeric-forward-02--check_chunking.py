"""Verify whole-track statistics survive bounded inference batches."""
from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import time

import numpy as np
import torch

import check_numeric as reference
import keycnn_numeric as candidate

BASE = Path(__file__).resolve().parent


def main():
    started = time.monotonic()
    rng = np.random.default_rng(20261027)
    features = rng.uniform(.01, 1, (6, 168, 60, 1)).astype('f4')
    for index in range(6):
        features[index] = features[index] * (index + 1) + 3 * index
    original = features.copy()
    # Independent float64 Torch statistics and population standard deviation.
    # Upstream casts directly from NumPy float64 to float16. Torch .half() on
    # this fixture rounds like a float32 intermediate at six halfway values;
    # retain that failed check and use the upstream conversion boundary here.
    value = torch.from_numpy(features).double()
    normalized_double = (value-value.mean()) / value.std(correction=0)
    expected_features = normalized_double.numpy().astype(np.float16).astype(np.float32)
    whole = candidate.normalize(features)
    np.testing.assert_array_equal(whole, expected_features)
    independently_normalized = np.concatenate([candidate.normalize(features[i:i+4]) for i in (0,4)])
    normalization_difference = float(np.max(np.abs(whole-independently_normalized)))
    assert normalization_difference > .1, 'Fixture must detect incorrect per-batch statistics'
    weights = candidate.weights()
    expected, _ = reference.oracle(features, weights)
    comparisons = []
    forward = candidate.forward_normalized
    for size in (1,2,3,4):
        observed_inputs = []
        def recorded(value, tensors):
            observed_inputs.append(value.copy())
            return forward(value, tensors)
        with patch.object(candidate, 'forward_normalized', recorded):
            actual = candidate.predict(features, weights, size)
        assert max(len(v) for v in observed_inputs) <= size
        np.testing.assert_array_equal(np.concatenate(observed_inputs), whole)
        np.testing.assert_allclose(actual, expected, rtol=3e-4, atol=3e-4)
        np.testing.assert_allclose(actual.mean(axis=0), expected.mean(axis=0), rtol=3e-4, atol=3e-4)
        assert np.array_equal(actual.argmax(axis=1), expected.argmax(axis=1))
        comparisons.append(dict(batch_size=size, windows=len(actual), batches=len(observed_inputs),
            normalized_inputs_match_whole_track_exactly=True,
            maximum_probability_absolute_error=float(np.max(np.abs(actual-expected))),
            all_window_argmax_values_agree=True))
    np.testing.assert_array_equal(features, original)
    for invalid in (True,0,-1,5,1.5):
        try:
            candidate.predict(features, weights, invalid)
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid batching parameter accepted')
    try:
        candidate.forward_normalized(whole[:5], weights)
    except ValueError:
        pass
    else:
        raise AssertionError('Unbounded direct inference batch accepted')
    assert not torch.cuda.is_initialized()
    report = dict(schema=1,status='whole_track_normalization_and_bounded_batches_verified',
        generated_windows=6,independent_torch_float64_statistics_with_upstream_numpy_half_boundary_match_exactly=True,
        incorrect_per_batch_normalization_maximum_feature_difference=normalization_difference,
        comparisons=comparisons,input_unchanged=True,invalid_batch_sizes_rejected=5,
        maximum_full_input_windows=128,maximum_inference_batch_windows=4,
        real_audio_inferred=False,audio_features_verified=False,legacy_TensorFlow_compatibility_verified=False,
        held_out_accuracy_qualified=False,product_code_changed=False,new_dependencies_installed=False,GPU_started=False,
        elapsed_seconds=time.monotonic()-started,
        files={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in
            (Path(__file__).resolve(),Path(candidate.__file__).resolve(),Path(reference.__file__).resolve())})
    with (BASE/'chunking-result-01.json').open('x') as stream:
        stream.write(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(status=report['status'],seconds=report['elapsed_seconds'],
        maximum_probability_error=max(r['maximum_probability_absolute_error'] for r in comparisons),
        incorrect_batch_normalization_detected=True)))


if __name__ == '__main__':
    main()
