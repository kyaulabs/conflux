"""One fixed two-source key comparison; no production or latency qualification."""
from decimal import Decimal, localcontext
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parent
OUTPUT = BASE / 'music-01'
RECIPE = 'private-keyfinder-2.2.8-stereo-context16-v1'


def read(path):
    return json.loads(path.read_text())


def store(path, value):
    raw = (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
    assert len(raw) <= 1024 * 1024
    with path.open('xb') as stream:
        stream.write(raw)


def verify(pin):
    path = Path(pin['path'])
    assert path.is_file() and path.stat().st_size == pin['bytes']
    with path.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == pin['sha256']


def validate_prediction(value, metadata, case):
    frames = case['prepared_frames']
    for row, names in [(metadata, ('source_bytes', 'prepared_frames', 'sample_rate', 'channels')),
                       (value, ('schema', 'frames', 'sample_rate', 'channels', 'target_window_frames',
                                'maximum_support_frames', 'window_count'))]:
        assert all(type(row[name]) is int for name in names)
    assert metadata['complete'] is True and metadata['case'] == case['id']
    assert metadata['source_sha256'] == case['source']['sha256']
    assert metadata['source_bytes'] == case['source']['bytes']
    assert metadata['prepared_frames'] == value['frames'] == frames
    assert metadata['prepared_pcm_sha256'] == value['pcm_sha256'] == case['pcm_sha256']
    assert metadata['audio_device_opened'] is False
    assert value['schema'] == 1 and value['recipe'] == RECIPE and value['qualified'] is False
    assert value['sample_rate'] == metadata['sample_rate'] == 48000
    assert value['channels'] == metadata['channels'] == 2
    assert value['target_window_frames'] == 192000 and value['maximum_support_frames'] == 768000
    assert value['window_count'] == len(value['windows']) == (frames + 191999) // 192000
    projected = []
    for index, row in enumerate(value['windows']):
        first, end = index * 192000, min((index + 1) * 192000, frames)
        center = (first + end) // 2
        assert all(type(row[name]) is int for name in ('first_frame', 'end_frame',
            'support_first_frame', 'support_end_frame'))
        assert row['first_frame'] == first and row['end_frame'] == end
        assert row['support_first_frame'] == max(0, center - 384000)
        assert row['support_end_frame'] == min(frames, center + 384000)
        assert row['confidence'] == 'Unknown' and row['status'] in ('Estimated', 'Unknown')
        candidates = []
        if row['status'] == 'Estimated':
            key = row['keyfinder_key_enum']
            assert type(key) is int and 0 <= key < 24 and end - first >= 32768
            assert type(row['tonic']) is int and row['tonic'] == (9 + key // 2) % 12
            assert row['mode'] == ('Minor' if key % 2 else 'Major')
            candidates = [{'tonic': row['tonic'], 'mode': row['mode']}]
        else:
            assert 'tonic' not in row and 'mode' not in row
            assert row['reason'] == ('short' if end - first < 32768 else 'silence')
        projected.append({'first_frame': first, 'end_frame': end,
            'status': row['status'], 'candidates': candidates})
    return projected


def predict_case(plan, case):
    identifier = case['id']
    spool = OUTPUT / ('spool-' + identifier)
    spool.mkdir(mode=0o700)
    paths = {name: OUTPUT / (identifier + '-' + name) for name in ('prediction.json', 'source.json', 'worker.stderr')}
    producer = consumer = None
    began = time.monotonic()
    with paths['source.json'].open('xb') as metadata, paths['prediction.json'].open('xb') as output, paths['worker.stderr'].open('xb') as errors:
        try:
            producer = subprocess.Popen([plan['preparer']['path'], identifier, str(spool)],
                stdout=subprocess.PIPE, stderr=metadata, start_new_session=True)
            consumer = subprocess.Popen([plan['worker']['path'], '--frames', str(case['prepared_frames'])],
                stdin=producer.stdout, stdout=output, stderr=errors, start_new_session=True)
            producer.stdout.close()
            while consumer.poll() is None or producer.poll() is None:
                assert time.monotonic() - began < 45, 'Original45s case bound exhausted'
                assert os.fstat(output.fileno()).st_size <= 131072
                assert os.fstat(metadata.fileno()).st_size <= 4096
                assert os.fstat(errors.fileno()).st_size <= 4096
                time.sleep(.05)
            assert producer.wait() == consumer.wait() == 0, 'Preparation or reference worker failed'
        finally:
            for child in (producer, consumer):
                if child is not None and child.poll() is None:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.wait(timeout=2)
    assert not list(spool.iterdir()), 'Anonymous preparation left spool files'
    source, value = read(paths['source.json']), read(paths['prediction.json'])
    projected = validate_prediction(value, source, case)
    return {'id': identifier, 'complete': True, 'elapsed_seconds': time.monotonic() - began,
        'source': source, 'prediction_path': str(paths['prediction.json']), 'windows': projected,
        'producer_reaped': producer.poll() is not None, 'consumer_reaped': consumer.poll() is not None,
        'spool_empty': True}


def score(plan, predictions):
    # Predictions have already been persisted for every slot. This is the first
    # reference CSV parsing in this run; the two sources were exposed earlier.
    path = Path(plan['scorer']['path'])
    spec = importlib.util.spec_from_file_location('frozen_harmony_scorer', path)
    scorer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scorer)
    result = []
    pooled = {ann: {'known': Decimal(0), 'correct': Decimal(0), 'top_two': Decimal(0),
        'states': {s: Decimal(0) for s in ('Estimated', 'Unknown', 'Ambiguous', 'Failed')},
        'all_source_states': {s: Decimal(0) for s in ('Estimated', 'Unknown', 'Ambiguous', 'Failed')},
        'unlabelled_states': {s: Decimal(0) for s in ('Estimated', 'Unknown', 'Ambiguous', 'Failed')},
        'source_maps': 0} for ann in ('ann3', 'ann1', 'ann2')}
    for case, prediction in zip(plan['cases'], predictions, strict=True):
        item = {'id': case['id'], 'complete': prediction['complete'], 'references': {}}
        for ann in pooled:
            spans = scorer.reference(Path(case['annotations'][ann]['path']).read_bytes())
            if prediction['complete']:
                value = scorer.overlaps(prediction['windows'], spans)
            else:
                known = sum((end - first for first, end, _ in spans), Decimal(0))
                value = {'known': known, 'correct': Decimal(0), 'top_two': Decimal(0),
                    'states': {s: known if s == 'Failed' else Decimal(0) for s in pooled[ann]['states']},
                    'all_source_states': {s: Decimal(0) for s in pooled[ann]['states']},
                    'unlabelled_states': {s: Decimal(0) for s in pooled[ann]['states']}, 'source_maps': 0, 'windows': []}
            ratios = scorer.ratios(value)
            ratios.pop('top_two_full_denominator_secondary')  # Reference returns one key only.
            item['references'][ann] = {**ratios, 'window_overlaps': value['windows']}
            for name in ('known', 'correct', 'top_two', 'source_maps'): pooled[ann][name] += value[name]
            for name in ('states', 'all_source_states', 'unlabelled_states'):
                for state in pooled[ann][name]: pooled[ann][name][state] += value[name][state]
        result.append(item)
    totals = {ann: scorer.ratios(value) for ann, value in pooled.items()}
    for value in totals.values(): value.pop('top_two_full_denominator_secondary')
    return {'schema': 1, 'primary': 'ann3', 'candidate_rank_count': 1, 'cases': result, 'pooled': totals,
        'operational_pass': all(row['complete'] for row in predictions), 'case_denominator': 2,
        'qualified': False, 'M2_complete': False, 'production_changed': False,
        'scope': 'Fixed exposed SC06 local-key diagnostic, same exact48k PCM and cropped16s support/4s targets. No held-out/general-genre, calibrated confidence, production integration or latency qualification.'}


def main():
    began = time.monotonic()
    plan = read(BASE / 'music-plan-01.json')
    deadline = began + plan['limits']['inner_total_seconds']
    for pin in plan['input_pins']:
        assert time.monotonic() < deadline
        verify(pin)
    assert [case['id'] for case in plan['cases']] == ['02', '03']
    OUTPUT.mkdir(mode=0o700)
    predictions = []
    for case in plan['cases']:
        assert time.monotonic() < deadline
        try:
            predictions.append(predict_case(plan, case))
        except Exception as error:
            predictions.append({'id': case['id'], 'complete': False,
                'error': {'type': type(error).__name__, 'message': str(error)[:1024]}})
    store(OUTPUT / 'predictions-before-scoring.json', predictions)
    assert time.monotonic() < deadline
    with localcontext() as context:
        context.prec = 50
        result = score(plan, read(OUTPUT / 'predictions-before-scoring.json'))
    for pin in plan['input_pins']:
        assert time.monotonic() < deadline
        verify(pin)
    assert time.monotonic() < deadline
    result.update(elapsed_seconds=time.monotonic() - began, input_pins_unchanged=True)
    store(OUTPUT / 'scores.json', result)
    print(json.dumps({'operational_pass': result['operational_pass'], 'case_denominator': 2,
        'elapsed_seconds': result['elapsed_seconds'], 'primary': result['pooled']['ann3'], 'qualified': False}))
    return 0 if result['operational_pass'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
