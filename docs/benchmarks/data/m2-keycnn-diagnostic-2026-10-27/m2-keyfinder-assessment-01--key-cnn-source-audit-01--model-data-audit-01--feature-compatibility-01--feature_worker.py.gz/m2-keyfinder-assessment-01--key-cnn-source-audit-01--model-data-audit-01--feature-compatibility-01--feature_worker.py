"""Generated-only comparison of audited key-CNN CQT feature implementations.

No media, model, TensorFlow/Keras, audio device or product configuration is used.
Legacy sources stay unmodified; one removed Numba import name aliases its current
jit entry point. This is not the original NumPy/SciPy training environment.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import warnings

BASE = Path(__file__).resolve().parent
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMBA_NUM_THREADS'):
    os.environ[key] = '1'
os.environ['NUMBA_CACHE_DIR'] = str(BASE/'numba-cache')
os.environ.pop('LIBROSA_CACHE_DIR', None)
resource.setrlimit(resource.RLIMIT_AS, (2*1024**3, 2*1024**3))
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))


def audited_sources():
    manifest = json.loads((BASE/'source-downloads-01.json').read_text())
    for package in manifest['source_packages']:
        for row in package['files']:
            raw = Path(row['path']).read_bytes()
            if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
                raise ValueError('Legacy source hash differs')


def windows(data, zero_pad):
    import numpy as np
    value = np.asarray(data)
    if (value.ndim != 2 or value.shape[0] != 168 or not 1 <= value.shape[1] <= 4096
            or value.dtype.kind != 'f' or not np.isfinite(value).all()):
        raise ValueError('Expected bounded finite 168-bin CQT magnitudes')
    if zero_pad:
        value = np.pad(value, ((0, 0), (30, 30)))
    if value.shape[1] < 60:
        value = np.pad(value, ((0, 0), (0, 60-value.shape[1])))
    offsets = list(range(0, value.shape[1]-60+1, 30))
    if len(offsets) > 128:
        raise ValueError('Too many feature windows')
    return np.stack([value[:, start:start+60, None] for start in offsets])


def fixtures():
    import numpy as np
    rate = 22050
    t = np.arange(rate*12+37, dtype=np.float64)/rate
    rng = np.random.default_rng(380117)
    impulse = np.zeros(len(t), dtype=np.float32)
    impulse[0] = .25
    impulse[-1] = -.5
    impulse[len(t)//2] = .125
    return {
        'silence': np.zeros(len(t), dtype=np.float32),
        'E1_tone': (.2*np.sin(2*np.pi*41.20344461410875*t)).astype(np.float32),
        'A4_detuned': (.2*np.sin(2*np.pi*440*2**(.25/12)*t)).astype(np.float32),
        'C_major_chord': sum(.08*np.sin(2*np.pi*frequency*t) for frequency in
                             (130.8127826502993, 164.81377845643496, 195.99771799087463)).astype(np.float32),
        'impulses_edges_and_middle': impulse,
        'seeded_noise': (.03*rng.standard_normal(len(t))).astype(np.float32),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', required=True, choices=(
        'legacy', 'modern_default', 'modern_reflect', 'modern_reflect_fast', 'modern_reflect_legacy_resampy'))
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    audited_sources()
    if args.output.exists() or args.output.with_suffix('.json').exists():
        raise FileExistsError('Comparison output already exists')
    if args.mode == 'legacy':
        import numba
        sys.modules['numba.decorators'] = numba
        sys.path.insert(0, str(BASE/'legacy-source/librosa'))
    if args.mode in ('legacy', 'modern_reflect_legacy_resampy'):
        sys.path.insert(0, str(BASE/'legacy-source/resampy'))
    import librosa
    import numpy as np
    import resampy
    feature_path = BASE.parent.parent/'source/keycnn/feature.py'
    source_audit = json.loads((BASE.parent.parent/'audit-01.json').read_text())
    # Locate the originally audited upstream feature file and verify it again.
    expected = next(row for row in source_audit['files'] if row['path'].endswith('/keycnn/feature.py'))
    raw = feature_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected['sha256']:
        raise ValueError('Key-CNN feature source hash differs')
    spec = importlib.util.spec_from_file_location('audited_keycnn_feature', feature_path)
    upstream = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(upstream)
    arrays = {}
    records = []
    with warnings.catch_warnings(record=True) as emitted:
        warnings.simplefilter('always')
        for name, signal in fixtures().items():
            kwargs = dict(sr=22050, hop_length=4096, fmin=librosa.note_to_hz('E1'), n_bins=168, bins_per_octave=24)
            if args.mode.startswith('modern_reflect'):
                kwargs['pad_mode'] = 'reflect'
            if args.mode in ('modern_reflect_fast', 'modern_reflect_legacy_resampy'):
                kwargs['res_type'] = 'kaiser_fast'
            magnitudes = np.abs(librosa.cqt(signal, **kwargs))
            if magnitudes.shape != (168, 1+len(signal)//4096) or not np.isfinite(magnitudes).all():
                raise ValueError('CQT geometry or finite check differs')
            for padded in (False, True):
                candidate = windows(magnitudes, padded)
                original = magnitudes[None, :, :, None]
                if padded:
                    original = upstream._add_zeros(original, 60)
                if original.shape[2] < 60:
                    original = upstream._ensure_length(original, 60)
                original = upstream._to_sliding_window(original, 60, 30)
                if candidate.dtype != original.dtype or not np.array_equal(candidate, original):
                    raise ValueError('Upstream window/zero-padding bit patterns differ')
                arrays[f'{name}_padded_{int(padded)}'] = candidate
            arrays[name] = magnitudes
            records.append(dict(case=name, samples=len(signal), CQT_shape=list(magnitudes.shape),
                                CQT_dtype=str(magnitudes.dtype), window_geometry_matches=True))
        # Exercise short-window padding, off-by-one hops and the explicit bound.
        geometry = 0
        for columns in (1, 59, 60, 61, 89, 90, 91, 119, 120, 121):
            value = np.arange(168*columns, dtype=np.float64).reshape(168, columns)/10000
            for padded in (False, True):
                candidate = windows(value, padded)
                original = value[None, :, :, None]
                if padded:
                    original = upstream._add_zeros(original, 60)
                if original.shape[2] < 60:
                    original = upstream._ensure_length(original, 60)
                original = upstream._to_sliding_window(original, 60, 30)
                if not np.array_equal(original, candidate):
                    raise ValueError('Generated boundary windows differ')
                geometry += 1
        for invalid in (np.zeros((167, 60)), np.full((168, 60), np.nan), np.zeros((168, 4097)),
                        np.zeros((168, 0)), np.zeros((168, 4096))):
            try:
                windows(invalid, True)
            except ValueError:
                pass
            else:
                raise ValueError('Malformed or oversized feature input accepted')
    with args.output.open('xb') as stream:
        np.savez_compressed(stream, **arrays)
    report = dict(mode=args.mode, librosa_version=librosa.__version__, librosa_path=librosa.__file__,
                  resampy_version=resampy.__version__, resampy_path=resampy.__file__,
                  numpy_version=np.__version__, records=records, boundary_checks=geometry,
                  malformed_checks=5, feature_sha256=hashlib.sha256(args.output.read_bytes()).hexdigest(),
                  warning_count=len(emitted), warnings=[str(w.message)[:400] for w in emitted[:10]],
                  generated_only=True, classifier_started=False, product_configuration_changed=False,
                  original_training_dependencies_reproduced=False, musical_accuracy_qualified=False)
    with args.output.with_suffix('.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(mode=args.mode, generated_CQT_cases=len(records), boundary_checks=geometry,
                         malformed_checks=5, feature_bytes=args.output.stat().st_size)))


if __name__ == '__main__':
    main()
