"""Private source-clock adapter for the audited keygram geometry.

This maps contextual prediction cells, not the full CQT receptive fields or
per-sample musical truth. No classifier is called and no key confidence is added.
"""

SOURCE_RATE = 48000
FEATURE_RATE = 22050
CQT_HOP = 4096
WINDOW = 60
PREDICTION_HOP = 8
MAX_SOURCE_FRAMES = 256*1024**2//8
STEP_NUMERATOR = PREDICTION_HOP*CQT_HOP*SOURCE_RATE


def geometry(source_frames):
    if type(source_frames) is not int or not 1 <= source_frames <= MAX_SOURCE_FRAMES:
        raise ValueError('Expected bounded positive stereo 48 kHz source frames')
    samples = (source_frames*FEATURE_RATE+SOURCE_RATE-1)//SOURCE_RATE
    columns = 1+samples//CQT_HOP
    return samples, columns, columns//PREDICTION_HOP+1


def partition(source_frames, cqt_columns, posterior_count):
    samples, expected_columns, expected_count = geometry(source_frames)
    if (type(cqt_columns) is not int or cqt_columns != expected_columns
            or type(posterior_count) is not int or posterior_count != expected_count):
        raise ValueError('Feature/prediction population differs from the exact source clock')
    rows = []
    omitted = []
    for index in range(expected_count):
        first = max(0, (2*index-1)*STEP_NUMERATOR//(2*FEATURE_RATE))
        end = min(source_frames, (2*index+1)*STEP_NUMERATOR//(2*FEATURE_RATE))
        if first >= end:
            omitted.append(index)
            continue
        center_numerator = index*STEP_NUMERATOR
        in_source = center_numerator < source_frames*FEATURE_RATE
        first_column = index*PREDICTION_HOP-WINDOW//2
        end_column = first_column+WINDOW
        left_zeros = max(0, -first_column)
        right_zeros = max(0, end_column-cqt_columns)
        observed = WINDOW-left_zeros-right_zeros
        if observed <= 0:
            raise ValueError('A published cell has no observed feature columns')
        rows.append(dict(first_frame=first, end_frame=end,
                         posterior_index=index if in_source else None,
                         raw_posterior_index=index,
                         status='ContextualPredictionClockOnly' if in_source else 'Unknown',
                         reason='nominal center inside source' if in_source else 'nominal center outside source',
                         nominal_center_frame_numerator=center_numerator,
                         nominal_center_frame_denominator=FEATURE_RATE,
                         left_zero_feature_columns=left_zeros,
                         right_zero_feature_columns=right_zeros,
                         observed_feature_columns=observed))
    covered = rows[-1]['end_frame'] if rows else 0
    if covered < source_frames:
        rows.append(dict(first_frame=covered, end_frame=source_frames,
                         posterior_index=None, raw_posterior_index=None,
                         status='Unknown', reason='no source-bound prediction cell'))
    if (not rows or rows[0]['first_frame'] != 0 or rows[-1]['end_frame'] != source_frames
            or any(a['end_frame'] != b['first_frame'] for a, b in zip(rows, rows[1:]))):
        raise ValueError('Source partition has a gap, overlap or out-of-source edge')
    return dict(source_frames=source_frames, source_rate=SOURCE_RATE,
                expected_resampled_samples=samples, cqt_columns=cqt_columns,
                raw_posterior_count=posterior_count, omitted_empty_cell_indices=omitted,
                intervals=rows, confidence='Unknown',
                scope='Nominal source-clock cells only; no musical accuracy or full filter-support claim')
