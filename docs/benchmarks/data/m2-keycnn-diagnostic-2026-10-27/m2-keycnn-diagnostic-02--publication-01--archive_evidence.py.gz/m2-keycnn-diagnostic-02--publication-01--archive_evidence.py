"""Archive only UTF-8 experiment evidence, omitting media, weights and runtimes."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
DATA = ROOT/'build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/model-data-audit-01'
DEST = BASE/'stage-02/docs/benchmarks/data/m2-keycnn-diagnostic-2026-10-27'
RAW = BASE/'uncompressed-review-02'
DEST.mkdir(parents=True, exist_ok=False)
RAW.mkdir(mode=0o700)
omitted_directories = {'venv', 'python', 'uv-cache', 'legacy-source', 'numba-cache',
                       'source-scan-01', '__pycache__', 'publication-01', 'generated-clock-'}
extensions = {'.json', '.py', '.log', '.lock', '.in', '.txt'}
selected = set()
omissions = []
for start in [DATA/'numeric-forward-01', DATA/'numeric-forward-02', DATA/'numeric-forward-03',
              DATA/'feature-compatibility-01', ROOT/'build/m2-keycnn-diagnostic-01',
              ROOT/'build/m2-keycnn-diagnostic-02']:
    for path in start.rglob('*'):
        if not path.is_file() or any(part in omitted_directories or part.startswith('generated-clock-')
                                     for part in path.relative_to(start).parts):
            continue
        if path.suffix not in extensions or path.name.endswith('-metadata.json') or path.name == 'upstream-keygram.txt':
            continue
        selected.add(path)
for relative in ['build/m2-keyfinder-assessment-01/assessment-01.json',
                 'build/m2-keyfinder-assessment-01/music-plan-01.json',
                 'build/m2-keyfinder-assessment-01/compare_music.py',
                 'build/m2-keyfinder-assessment-01/test_music_binding.py',
                 'build/m2-keyfinder-assessment-01/preparation-02/prepare_key_source.cpp',
                 'build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/audit-01.json',
                 'build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/paper-review-01.json',
                 'build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/source-tree-01.json',
                 'build/m2-analysis-qualification-01/swd-harmony-assessment-draft-01/score_harmony.py',
                 'build/m2-analysis-qualification-01/swd-harmony-assessment-draft-01/root-assessment-summary-01.json']:
    selected.add(ROOT/relative)
for name in ['numeric-architecture-audit-01.json', 'model-config-01.json', 'download-01.json']:
    selected.add(DATA/name)
selected.add(Path(__file__).resolve())
selected.add(BASE/'gitleaks-findings-classification-01.json')
source_digests = {hashlib.sha256(path.read_bytes()).hexdigest():str(path.relative_to(ROOT)) for path in selected}
public_script = DATA/'feature-compatibility-01/upstream-keygram.txt'
source_digests[hashlib.sha256(public_script.read_bytes()).hexdigest()] = str(public_script.relative_to(ROOT))
records = []
for path in sorted(selected):
    assert not path.is_symlink()
    original = path.read_bytes()
    raw = original
    raw.decode('utf-8')
    relative = path.relative_to(ROOT)
    renames = []
    field = None
    if path.parent.name in ('numeric-forward-01', 'numeric-forward-02') and path.name in ('result-01.json', 'chunking-result-01.json'):
        field = ('keycnn_numeric.py', 'numeric_source_sha256')
    if path.parent.name == 'feature-compatibility-01' and path.name == 'pipeline-progress-01.json':
        field = ('upstream_keygram_sha256', 'upstream_script_sha256')
    if field:
        old, new = field
        values = []
        def collect(value):
            if isinstance(value, dict):
                if old in value:
                    values.append(value[old])
                for child in value.values():
                    collect(child)
            elif isinstance(value, list):
                for child in value:
                    collect(child)
        collect(json.loads(original))
        assert len(values) == 1 and values[0] in source_digests
        before = (json.dumps(old)+':').encode()
        after = (json.dumps(new)+':').encode()
        assert raw.count(before) == 1 and after not in raw
        raw = raw.replace(before, after, 1)
        assert raw.replace(after, before, 1) == original
        renames.append(dict(kind='reversible_JSON_source_digest_field_name', original=old, retained=new,
                            verified_digest_of=source_digests[values[0]], value_unchanged=True))
    name = '--'.join(relative.parts[1:])
    assert len((name+'.gz').encode()) <= 255
    with (RAW/name).open('xb') as stream:
        stream.write(raw)
    packed = gzip.compress(raw, mtime=0)
    with (DEST/(name+'.gz')).open('xb') as stream:
        stream.write(packed)
    record = dict(file=name+'.gz', private_source=str(relative), bytes=len(raw),
                  sha256=hashlib.sha256(raw).hexdigest(), gzip_bytes=len(packed),
                  gzip_sha256=hashlib.sha256(packed).hexdigest(), UTF8=True,
                  source_bytes=len(original), source_sha256=hashlib.sha256(original).hexdigest(),
                  source_reconstruction_verified=True)
    if renames:
        record['field_name_normalizations'] = renames
    if path.suffix == '.json':
        try:
            json.loads(raw)
            record['JSON_syntax_valid'] = True
        except (ValueError, UnicodeDecodeError):
            assert not raw and 'm2-keycnn-diagnostic-01' in relative.parts and path.name.endswith('-prediction.json')
            record['JSON_syntax_valid'] = False
            record['reason'] = 'Empty prediction stream retained from the warning-budget failure; no result was published'
    records.append(record)
manifest = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                scope='Text-only private diagnostic evidence; this is not a runtime installer or model distribution',
                records=records, compressed_file_count=len(records),
                compressed_bytes=sum(row['gzip_bytes'] for row in records),
                source_digest_field_normalizations=sum(len(row.get('field_name_normalizations', [])) for row in records),
                metadata_policy='Four non-secret source-file digests use canonical field labels to avoid generic API-key false positives. '
                                'Digest values and numeric results are unchanged. Exact inverse mappings and original byte hashes are retained; '
                                'no Gitleaks rule, hook or allowlist is changed.',
                omitted=['Original recordings and audio derivatives', 'Reference CSV contents',
                         'HDF5 checkpoint and raw model tensor arrays', 'Generated PCM/NPZ arrays',
                         'Installed Python, packages, caches and binary executables',
                         'Unmodified upstream source packages and package-index catalogs; provenance hashes/URLs retained'],
                rights='SC06 recordings remain private, noncommercial BY-NC-ND3.0 evaluation assets. '
                       'No source audio or audio derivatives are included. Key-CNN source/model provenance is '
                       'recorded with the upstream AGPL-3.0 licensing statement; no checkpoint is included.',
                qualified=False, M2_complete=False, M3_complete=False, release_authorized=False)
with (DEST/'manifest.json').open('x') as stream:
    stream.write(json.dumps(manifest, indent=2, allow_nan=False)+'\n')
print(json.dumps(dict(files=len(records), compressed_bytes=manifest['compressed_bytes'], stage=str(DEST))))
