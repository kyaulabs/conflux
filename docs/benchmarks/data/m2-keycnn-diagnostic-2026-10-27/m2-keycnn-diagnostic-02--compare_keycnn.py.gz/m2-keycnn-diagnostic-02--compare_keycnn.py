"""Reuse the fixed, bounded two-source preparation/scoring harness; dry default."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import protocol


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--owned', action='store_true')
    args = parser.parse_args()
    if not args.owned:
        print(json.dumps(dict(status='unarmed_dry', source_opened=False, model_started=False)))
        return 0
    plan = json.loads((BASE/'music-plan-01.json').read_text())
    if (plan['status'] != 'frozen_offline_correctness_only' or plan['physical_readiness_required'] is not False
            or plan['unit'] not in Path('/proc/self/cgroup').read_text()):
        raise ValueError('Expected the one fixed owned diagnostic unit')
    path = Path(plan['harness']['path'])
    spec = importlib.util.spec_from_file_location('existing_fixed_music_harness', path)
    harness = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(harness)
    harness.BASE = BASE
    harness.OUTPUT = BASE/'output-01'
    harness.RECIPE = protocol.RECIPE
    harness.validate_prediction = protocol.validate_prediction
    original_score = harness.score
    def score(frozen_plan, predictions):
        result = original_score(frozen_plan, predictions)
        result.update(scope=plan['scope'], confidence='Unknown',
                      recipe=protocol.RECIPE, fixed_prepared_PCM_matches_baseline=True,
                      original_training_environment_reproduced=False,
                      legacy_TensorFlow_equivalence_verified=False, training_independence_verified=False,
                      candidate_predictions_persisted_before_reference_parsing=True)
        return result
    harness.score = score
    return harness.main()


if __name__ == '__main__':
    raise SystemExit(main())
