"""Bounded generated numerical checks using an existing CPU-only Torch oracle."""
from pathlib import Path
import hashlib
import json
import time

import numpy as np
import torch
import torch.nn.functional as F

import keycnn_numeric as candidate

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.backends.mkldnn.enabled = False
BASE = Path(__file__).resolve().parent


def oracle(features, weights):
    # Independent library operators in NCHW. No Keras model or candidate ops.
    value = torch.from_numpy(candidate.normalize(features)).permute(0, 3, 1, 2).contiguous()
    trace = [('normalized_input', value.permute(0, 2, 3, 1).numpy().copy())]
    def remember(name):
        trace.append((name, value.permute(0, 2, 3, 1).numpy().copy() if value.ndim == 4 else value.numpy().copy()))
    with torch.inference_mode():
        for index in range(12):
            conv, bn = f'Conv{index}', f'BN{index}'
            kernel = torch.from_numpy(weights[(conv, 'kernel:0')]).permute(3, 2, 0, 1).contiguous()
            value = F.relu(F.conv2d(value, kernel, torch.from_numpy(weights[(conv, 'bias:0')]), padding=kernel.shape[-1] // 2))
            remember(conv)
            value = F.batch_norm(value, torch.from_numpy(weights[(bn, 'moving_mean:0')]),
                torch.from_numpy(weights[(bn, 'moving_variance:0')]), torch.from_numpy(weights[(bn, 'gamma:0')]),
                torch.from_numpy(weights[(bn, 'beta:0')]), training=False, eps=.001)
            remember(bn)
            if index % 2:
                size = (2, 1) if index == 11 else (2, 2)
                value = F.max_pool2d(value, size, size)
                remember(f'MaxPool2D{index // 2 + 1}')
        kernel = torch.from_numpy(weights[('1x1', 'kernel:0')]).permute(3, 2, 0, 1).contiguous()
        value = F.relu(F.conv2d(value, kernel, torch.from_numpy(weights[('1x1', 'bias:0')])))
        remember('1x1')
        value = value.mean(dim=(2, 3))
        remember('global_average_pooling2d')
        value = F.softmax(value, dim=1)
        remember('activation')
    return value.numpy(), trace


def main():
    began = time.monotonic()
    rng = np.random.default_rng(20261027)
    checks = []
    # Explicit small convolution: boundaries, channel order, bias and ReLU.
    x = rng.normal(size=(1, 4, 5, 2)).astype('f4')
    kernel = rng.normal(size=(3, 3, 2, 3)).astype('f4')
    bias = np.array([-.2, .1, .4], dtype='f4')
    expected = np.zeros((1, 4, 5, 3), dtype='f4')
    for y in range(4):
        for z in range(5):
            for out in range(3):
                value = np.float32(0)
                for ky in range(3):
                    for kx in range(3):
                        for channel in range(2):
                            iy, ix = y + ky - 1, z + kx - 1
                            if 0 <= iy < 4 and 0 <= ix < 5:
                                value += x[0, iy, ix, channel] * kernel[ky, kx, channel, out]
                expected[0, y, z, out] = max(np.float32(0), value + bias[out])
    np.testing.assert_allclose(candidate.convolution(x, kernel, bias), expected, rtol=2e-6, atol=2e-6)
    checks.append('NHWC cross-correlation SAME edges/channel order/bias/ReLU against scalar oracle')
    # Last pooling stage preserves the time axis; odd dimensions floor.
    negative = -np.arange(1, 1 + 5 * 7, dtype='f4').reshape(1, 5, 7, 1)
    for width in (1, 2):
        value = candidate.pool(negative, width)
        expect = np.empty((1, 2, 7 // width, 1), dtype='f4')
        for y in range(2):
            for z in range(7 // width):
                expect[0, y, z, 0] = negative[0, y * 2:y * 2 + 2, z * width:z * width + width, 0].max()
        np.testing.assert_array_equal(value, expect)
    checks.append('VALID 2x2 and 2x1 pooling floors odd dimensions and preserves negative maxima')
    features = np.zeros((2, 168, 60, 1), dtype='f4')
    features[1] = 2
    np.testing.assert_array_equal(candidate.normalize(features), np.where(features == 0, -1, 1).astype('f4'))
    np.testing.assert_array_equal(candidate.normalize(features[:1] + 3), features[:1] + 3)
    checks.append('Batch-wide float64 mean/std, float16 boundary and constant-input preservation')
    rejected = 0
    for bad in (features[:, :, :59], features[..., 0], features[:0], np.full_like(features, np.nan),
                np.full_like(features, np.inf), np.zeros((129, 168, 60, 1), dtype='f4')):
        try:
            candidate.normalize(bad)
        except ValueError:
            rejected += 1
    assert rejected == 6
    checks.append('Malformed, empty, nonfinite and over-budget feature batches rejected')
    weights = candidate.weights()
    cases = dict(zeros=np.zeros((1, 168, 60, 1), dtype='f4'),
        constant=np.full((1, 168, 60, 1), 3, dtype='f4'),
        random_positive=rng.uniform(0, 8, (2, 168, 60, 1)).astype('f4'))
    comparisons = []
    for name, data in cases.items():
        actual, trace = candidate.forward(data, weights)
        expected, other = oracle(data, weights)
        assert [n for n, _ in trace] == [n for n, _ in other]
        layers = []
        for (layer, a), (_, b) in zip(trace, other):
            assert a.shape == b.shape
            np.testing.assert_allclose(a, b, rtol=3e-4, atol=3e-4)
            layers.append(dict(name=layer, shape=list(a.shape), maximum_absolute_error=float(np.max(np.abs(a-b)))))
        np.testing.assert_allclose(actual.sum(axis=1), 1, rtol=1e-6, atol=1e-6)
        assert (actual >= 0).all() and np.array_equal(actual.argmax(axis=1), expected.argmax(axis=1))
        comparisons.append(dict(case=name, windows=len(data), all_layers_within_tolerance=True,
            absolute_tolerance=3e-4, relative_tolerance=3e-4, layers=layers,
            probabilities_maximum_absolute_error=float(np.max(np.abs(actual-expected))),
            argmax_agrees=True, all_probabilities_finite=True))
    assert not torch.cuda.is_initialized()
    report = dict(schema=1, status='generated_numeric_checks_passed', checks=checks,
        original_model_sha256=candidate.MODEL_SHA, parameters_verified=294160,
        checks_against_existing_CPU_Torch_only=True, torch_version=torch.__version__, numpy_version=np.__version__,
        framework_threads=1, comparisons=comparisons, elapsed_seconds=time.monotonic()-began,
        legacy_tensorflow_compatibility_verified=False, audio_features_verified=False,
        real_audio_inferred=False, musical_accuracy_qualified=False, held_out_training_independence_verified=False,
        pretrained_serialized_objects_executed=False, dependencies_installed=False,
        product_configuration_changed=False, GPU_started=False,
        files={f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in (Path(__file__).resolve(), Path(candidate.__file__).resolve())})
    with (BASE/'result-01.json').open('x') as f:
        f.write(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(status=report['status'], windows=sum(r['windows'] for r in comparisons),
        maximum_probability_error=max(r['probabilities_maximum_absolute_error'] for r in comparisons),
        seconds=report['elapsed_seconds'], musical_accuracy_qualified=False)))


if __name__ == '__main__':
    main()
