"""Private numerical prototype for the single already-audited key-CNN model.

Loads only hashed little-endian float arrays. Does not load Keras/HDF5 objects,
compute audio features, establish legacy-framework compatibility or classify audio.
"""
from pathlib import Path
import hashlib
import json

import numpy as np

DATA = Path(__file__).resolve().parent.parent
AUDIT_SHA = '2ef90acbaedb6812e1d36f068195365a3fc2878e3026befebcdc4877d8de6af3'
CONFIG_SHA = '2ca1429e2cd72e5d7318618822f7920fae90581b9d802701135a652551adcc6e'
MODEL_SHA = 'b425f2e8d5165415c8863b6666aa82d7573121ee675bd2fd8b59d7594f5f11e9'


def checked_json(path, expected):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('Audited model metadata hash differs')
    return json.loads(raw)


def weights():
    if hashlib.sha256((DATA / 'winterreise-n-fold16.h5').read_bytes()).hexdigest() != MODEL_SHA:
        raise ValueError('Audited original model hash differs')
    audit = checked_json(DATA / 'numeric-architecture-audit-01.json', AUDIT_SHA)
    checked_json(DATA / 'model-config-01.json', CONFIG_SHA)
    result = {}
    for tensor in audit['tensors']:
        path = Path(tensor['file']['path']).resolve(strict=True)
        path.relative_to((DATA / 'data-only-tensors').resolve(strict=True))
        raw = path.read_bytes()
        if len(raw) != tensor['file']['bytes'] or hashlib.sha256(raw).hexdigest() != tensor['file']['sha256']:
            raise ValueError('Numeric tensor bytes/hash differ')
        value = np.frombuffer(raw, dtype='<f4').reshape(tensor['shape']).copy()
        if not np.isfinite(value).all():
            raise ValueError('Nonfinite numeric model tensor')
        name = tuple(tensor['HDF5_path'].split('/')[2::2])
        if name in result:
            raise ValueError('Duplicate numeric tensor')
        result[name] = value
    if len(result) != 74 or sum(v.size for v in result.values()) != 294160:
        raise ValueError('Audited parameter population differs')
    return result


def normalize(features):
    value = np.asarray(features)
    if (value.ndim != 4 or value.shape[1:] != (168, 60, 1)
            or not 1 <= value.shape[0] <= 128 or value.dtype.kind != 'f' or not np.isfinite(value).all()):
        raise ValueError('Expected one to 128 finite floating-point 168x60x1 windows')
    value = value.astype(np.float64)
    standard_deviation = value.std()
    if standard_deviation != 0:
        value = (value - value.mean()) / standard_deviation
    with np.errstate(over='raise', invalid='raise'):
        value = value.astype(np.float16).astype(np.float32)
    if not np.isfinite(value).all():
        raise ValueError('Normalization overflow')
    return value


def convolution(value, kernel, bias):
    """NHWC, odd square kernel, stride one, zero SAME padding, ReLU."""
    kh, kw, channels, outputs = kernel.shape
    if kh != kw or kh not in (1, 3, 5) or channels != value.shape[-1] or bias.shape != (outputs,):
        raise ValueError('Unexpected audited convolution geometry')
    padded = np.pad(value, ((0, 0), (kh // 2, kh // 2), (kw // 2, kw // 2), (0, 0)))
    windows = np.lib.stride_tricks.sliding_window_view(padded, (kh, kw), axis=(1, 2))
    output = np.einsum('nhwcij,ijco->nhwo', windows, kernel, optimize=True)
    output += bias
    return np.maximum(output, np.float32(0))


def batch_normalization(value, gamma, beta, mean, variance):
    if (any(v.shape != (value.shape[-1],) for v in (gamma, beta, mean, variance))
            or np.any(variance < 0)):
        raise ValueError('Unexpected audited batch-normalization geometry/variance')
    scale = gamma / np.sqrt(variance + np.float32(.001))
    return (value - mean) * scale + beta


def pool(value, width):
    if value.ndim != 4 or width not in (1, 2):
        raise ValueError('Unexpected audited pooling geometry')
    windows = np.lib.stride_tricks.sliding_window_view(value, (2, width), axis=(1, 2))
    return windows[:, ::2, ::width].max(axis=(-2, -1))


def forward_normalized(value, tensors):
    if (value.dtype != np.dtype('float32') or value.ndim != 4 or value.shape[1:] != (168, 60, 1)
            or not 1 <= value.shape[0] <= 4 or not np.isfinite(value).all()):
        raise ValueError('Expected one to four already normalized float32 windows')
    batch_count = len(value)
    trace = [('normalized_input', value.copy())]
    for index in range(12):
        conv, bn = f'Conv{index}', f'BN{index}'
        value = convolution(value, tensors[(conv, 'kernel:0')], tensors[(conv, 'bias:0')])
        trace.append((conv, value.copy()))
        # The audited graph applies ReLU in Conv2D BEFORE normalization.
        value = batch_normalization(value, *(tensors[(bn, name)] for name in
            ('gamma:0', 'beta:0', 'moving_mean:0', 'moving_variance:0')))
        trace.append((bn, value.copy()))
        if index % 2:
            value = pool(value, 1 if index == 11 else 2)
            trace.append((f'MaxPool2D{index // 2 + 1}', value.copy()))
            # Inference dropout is the identity; no random mask is generated.
    value = convolution(value, tensors[('1x1', 'kernel:0')], tensors[('1x1', 'bias:0')])
    trace.append(('1x1', value.copy()))
    value = value.mean(axis=(1, 2), dtype=np.float32)
    trace.append(('global_average_pooling2d', value.copy()))
    shifted = value - value.max(axis=1, keepdims=True)
    value = np.exp(shifted)
    value /= value.sum(axis=1, keepdims=True)
    trace.append(('activation', value.copy()))
    if value.shape != (batch_count, 24) or any(not np.isfinite(v).all() for _, v in trace):
        raise ValueError('Unexpected or nonfinite numerical classifier output')
    return value, trace


def forward(features, tensors):
    return forward_normalized(normalize(features), tensors)


def predict(features, tensors, batch_size=4):
    if type(batch_size) is not int or not 1 <= batch_size <= 4:
        raise ValueError('Numeric prototype batch size must be one to four')
    # The upstream classifier normalizes BEFORE Keras divides inference into
    # batches. Preserve one whole-input population, including its float16
    # conversion, rather than changing statistics at each processing boundary.
    normalized = normalize(features)
    return np.concatenate([forward_normalized(normalized[first:first+batch_size], tensors)[0]
        for first in range(0, len(normalized), batch_size)], axis=0)
