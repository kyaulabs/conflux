"""Check the candidate/source boundary without opening music or annotations."""
import copy
import importlib.util
from pathlib import Path
import unittest

path = Path(__file__).resolve().parent / 'compare_music.py'
spec = importlib.util.spec_from_file_location('keyfinder_comparison', path)
comparison = importlib.util.module_from_spec(spec)
spec.loader.exec_module(comparison)


def fixture():
    case = {'id': '02', 'source': {'sha256': 'a' * 64, 'bytes': 100},
            'prepared_frames': 48000, 'pcm_sha256': 'b' * 64}
    source = {'case': '02', 'complete': True, 'source_sha256': 'a' * 64,
        'source_bytes': 100, 'prepared_frames': 48000, 'prepared_pcm_sha256': 'b' * 64,
        'sample_rate': 48000, 'channels': 2, 'audio_device_opened': False}
    value = {'schema': 1, 'recipe': comparison.RECIPE, 'qualified': False,
        'frames': 48000, 'pcm_sha256': 'b' * 64, 'sample_rate': 48000, 'channels': 2,
        'target_window_frames': 192000, 'maximum_support_frames': 768000, 'window_count': 1,
        'windows': [{'first_frame': 0, 'end_frame': 48000,
            'support_first_frame': 0, 'support_end_frame': 48000,
            'status': 'Unknown', 'reason': 'silence', 'confidence': 'Unknown'}]}
    return value, source, case


class MusicBindingTest(unittest.TestCase):
    def test_valid_unknown_keeps_its_full_source_window(self):
        value, source, case = fixture()
        projected = comparison.validate_prediction(value, source, case)
        self.assertEqual(projected, [{'first_frame': 0, 'end_frame': 48000,
            'status': 'Unknown', 'candidates': []}])

    def test_wrong_pcm_source_recipe_or_integer_type_is_rejected(self):
        for target, field, changed in [('value', 'pcm_sha256', 'c' * 64),
                ('source', 'source_sha256', 'c' * 64), ('source', 'complete', False),
                ('value', 'recipe', 'local-chroma-krumhansl-v1'),
                ('value', 'frames', 48000.), ('value', 'schema', True)]:
            with self.subTest(target=target, field=field):
                value, source, case = fixture()
                (value if target == 'value' else source)[field] = changed
                with self.assertRaises(AssertionError):
                    comparison.validate_prediction(value, source, case)

    def test_missing_target_or_changed_context_cannot_be_scored(self):
        for field, changed in [('first_frame', 1), ('end_frame', 47999),
                ('support_first_frame', 1), ('support_end_frame', 47999)]:
            with self.subTest(field=field):
                value, source, case = fixture(); value['windows'][0][field] = changed
                with self.assertRaises(AssertionError): comparison.validate_prediction(value, source, case)
        value, source, case = fixture(); value['windows'] = []
        with self.assertRaises(AssertionError): comparison.validate_prediction(value, source, case)


if __name__ == '__main__':
    unittest.main(verbosity=2)
