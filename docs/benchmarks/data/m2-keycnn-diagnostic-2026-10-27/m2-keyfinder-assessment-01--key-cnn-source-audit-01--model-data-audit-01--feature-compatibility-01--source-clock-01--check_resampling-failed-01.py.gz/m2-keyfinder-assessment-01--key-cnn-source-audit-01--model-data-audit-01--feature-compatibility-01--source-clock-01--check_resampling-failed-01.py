"""Generated PCM16 file oracle vs prepared-PCM key features and source clock.

The pinned upstream feature function is executed without its setup/classifier.
Only audioread's standard-library PCM WAV backend is permitted. No subprocess
decoder, user media, model, audio device or GPU can be used by this check.
"""
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import tempfile
from unittest.mock import patch
import warnings
import wave

BASE = Path(__file__).resolve().parent
FEATURE = BASE.parent
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMBA_NUM_THREADS'):
    os.environ[key] = '1'
os.environ['NUMBA_CACHE_DIR'] = str(FEATURE/'numba-cache')
os.environ.pop('LIBROSA_CACHE_DIR', None)
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_AS, (2*1024**3, 2*1024**3))


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def main():
    source = json.loads((FEATURE/'source-downloads-01.json').read_text())
    for package in source['source_packages']:
        for row in package['files']:
            raw = Path(row['path']).read_bytes()
            if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
                raise ValueError('Audited legacy feature source hash differs')
    import numba
    sys.modules['numba.decorators'] = numba
    sys.path[:0] = [str(FEATURE/'legacy-source/librosa'), str(FEATURE/'legacy-source/resampy')]
    import librosa
    import numpy as np
    import audioread
    from audioread.rawread import RawAudioFile
    clock = module('source_bound_key_clock', BASE/'source_clock.py')
    upstream_path = FEATURE.parent.parent/'source/keycnn/feature.py'
    upstream_audit = json.loads((FEATURE.parent.parent/'audit-01.json').read_text())
    upstream_pin = next(row for row in upstream_audit['files'] if row['path'].endswith('/keycnn/feature.py'))
    if hashlib.sha256(upstream_path.read_bytes()).hexdigest() != upstream_pin['sha256']:
        raise ValueError('Audited key-CNN feature source hash differs')
    upstream = module('upstream_key_feature_clock_reference', upstream_path)

    def candidate(pcm):
        if (pcm.ndim != 2 or pcm.shape[1] != 2 or pcm.dtype != np.dtype('float32')
                or not np.isfinite(pcm).all()):
            raise ValueError('Expected finite stereo float32 prepared PCM')
        expected_samples, columns, count = clock.geometry(len(pcm))
        mono = pcm.mean(axis=1, dtype=np.float32)
        resampled = librosa.resample(mono, 48000, 22050, res_type='kaiser_best')
        if len(resampled) != expected_samples:
            raise ValueError('Resampled count differs from the rational source clock')
        cqt = np.abs(librosa.cqt(resampled, sr=22050, hop_length=4096,
                                 fmin=librosa.note_to_hz('E1'), n_bins=168, bins_per_octave=24))
        if cqt.shape != (168, columns) or not np.isfinite(cqt).all():
            raise ValueError('CQT source geometry differs')
        padded = np.pad(cqt, ((0, 0), (30, 30)))
        windows = np.stack([padded[:, first:first+60, None] for first in range(0, columns+1, 8)])
        if windows.shape != (count, 168, 60, 1) or count > 512:
            raise ValueError('Window population differs')
        return resampled, cqt, windows, clock.partition(len(pcm), columns, count)

    def signal(name, frames):
        t = np.arange(frames, dtype=np.float64)/48000
        if name == 'phase_cancelled_stereo':
            left = .2*np.sin(2*np.pi*220*t)
            return np.stack([left, -left], axis=1)
        if name == 'impulse_clock':
            value = np.zeros((frames, 2), dtype=np.float64)
            for index, second in enumerate((.5, 1.25, 2.5, 4.75)):
                value[int(second*48000)] = .5 if index % 2 == 0 else -.5
            return value
        if name.startswith('burst_'):
            frequency = 440. if name == 'burst_A4' else 82.4068892282175
            value = .25*np.exp(-.5*((t-2.)/.06)**2)*np.cos(2*np.pi*frequency*t)
            return np.stack([value, value], axis=1)
        return np.stack([.2*np.sin(2*np.pi*130.8127826502993*t),
                         .15*np.sin(2*np.pi*164.81377845643496*t)], axis=1)

    specs = [('one_second_tail', 48001), ('padded_center_after_EOF', 62416),
             ('two_second_chord', 96013), ('phase_cancelled_stereo', 96013),
             ('impulse_clock', 288017), ('burst_A4', 288017), ('burst_E2', 288017)]
    records = []
    impulse_checks = []
    burst_checks = []
    with tempfile.TemporaryDirectory(prefix='generated-clock-', dir=BASE) as directory:
        root = Path(directory)
        for name, frames in specs:
            integers = np.rint(signal(name, frames)*32768).astype('<i2')
            prepared = integers.astype(np.float32)/np.float32(32768.)
            path = root/(name+'.wav')
            with wave.open(str(path), 'wb') as file:
                file.setnchannels(2)
                file.setsampwidth(2)
                file.setframerate(48000)
                file.writeframes(integers.tobytes())
            with patch.object(audioread, 'audio_open', side_effect=lambda file: RawAudioFile(file)), \
                    patch.object(subprocess, 'Popen', side_effect=AssertionError('External decoder forbidden')):
                original_y, rate = librosa.load(str(path), sr=22050)
                original_features = upstream.read_features(str(path), hop_length=8, zero_pad=True)
                resampled, cqt, windows, partition = candidate(prepared)
            if (rate != 22050 or not np.array_equal(original_y, resampled)
                    or original_y.dtype != resampled.dtype
                    or original_features.dtype != windows.dtype
                    or not np.array_equal(original_features, windows)):
                raise ValueError('Prepared-PCM and pinned upstream file feature bytes differ')
            if name == 'phase_cancelled_stereo' and (np.any(resampled) or np.any(cqt)):
                raise ValueError('Opposite stereo channels did not cancel at the mono boundary')
            if name == 'impulse_clock':
                for second in (.5, 1.25, 2.5, 4.75):
                    source_frame = int(second*48000)
                    anchor = Fraction(source_frame*22050, 48000)
                    middle = int(anchor)
                    first = max(0, middle-16)
                    observed = first+int(np.argmax(np.abs(resampled[first:middle+17])))
                    error = abs(Fraction(observed)-anchor)
                    if error > 1:
                        raise ValueError('Resampled impulse moved by more than one feature-rate sample')
                    impulse_checks.append(dict(source_frame=source_frame, observed_resampled_sample=observed,
                                               absolute_error_samples=float(error)))
            if name.startswith('burst_'):
                frequency_bin = 82 if name == 'burst_A4' else 24
                peak = int(np.argmax(cqt[frequency_bin]))
                observed_seconds = peak*4096/22050
                error = abs(observed_seconds-2.)
                if error > 4096/(2*22050)+.01:
                    raise ValueError('Generated CQT burst anchor exceeds the half-hop allowance')
                burst_checks.append(dict(case=name, CQT_bin=frequency_bin, CQT_peak_column=peak,
                                         nominal_peak_seconds=observed_seconds, source_center_seconds=2.,
                                         absolute_error_seconds=error))
            records.append(dict(case=name, source_frames=frames,
                                source_WAV_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                                resampled_samples=len(resampled), CQT_columns=cqt.shape[1],
                                prediction_count=len(windows), exact_resampled_values=True,
                                exact_upstream_window_values=True, partition=partition))
        # Feature construction failure must remain distinguishable from valid clock geometry.
        try:
            candidate(np.zeros((1, 2), dtype=np.float32))
        except librosa.util.exceptions.ParameterError as error:
            too_short = dict(source_frames=1, status='Unknown',
                             reason='CQT input too short', diagnostic=str(error)[:300], classifier_started=False)
        else:
            raise ValueError('One-frame input unexpectedly produced valid CQT features')
    if root.exists():
        raise ValueError('Generated PCM fixture directory was not removed')
    report = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                  status='generated_resampling_features_and_nominal_source_clock_passed',
                  cases=records, impulse_checks=impulse_checks, CQT_burst_checks=burst_checks,
                  too_short_source=too_short, generated_PCM_fixtures_removed=True,
                  reference='Pinned unmodified key-CNN feature.py with Librosa 0.6.2 and Resampy 0.2.2; '
                            'current compatible NumPy/SciPy/Numba dependencies and a same-jit import alias',
                  reference_decoder='Only standard-library audioread RawAudioFile PCM16 WAV backend',
                  model_inference_executed=False, original_training_environment_reproduced=False,
                  audio_output_opened=False, GPU_started=False, user_media_read=False,
                  real_music_accuracy_qualified=False, real_music_local_time_alignment_qualified=False,
                  full_CQT_receptive_field_verified=False, product_configuration_changed=False)
    with (BASE/'resampling-result-01.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(status=report['status'], generated_cases=len(records),
                         impulse_checks=len(impulse_checks), CQT_burst_checks=len(burst_checks),
                         fixtures_removed=True)))


if __name__ == '__main__':
    with warnings.catch_warnings(record=True):
        warnings.simplefilter('always')
        main()
