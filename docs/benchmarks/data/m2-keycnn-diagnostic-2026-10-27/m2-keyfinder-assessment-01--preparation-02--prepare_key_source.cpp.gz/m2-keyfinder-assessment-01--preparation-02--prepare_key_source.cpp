// SPDX-License-Identifier: AGPL-3.0-or-later
// Fixed private corpus -> unchanged current preparation -> F32 pipe. No device.
#include "audio/AudioFile.hpp"
#include <QCryptographicHash>
#include <QJsonDocument>
#include <QJsonObject>
#include <algorithm>
#include <array>
#include <atomic>
#include <bit>
#include <chrono>
#include <csignal>
#include <fcntl.h>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>

namespace {
std::atomic_flag interrupted = ATOMIC_FLAG_INIT;
void signalStop(int) { interrupted.test_and_set(std::memory_order_relaxed); }
void require(bool value, const char* message) {
    if (!value) throw std::runtime_error(message);
}
struct File {
    int descriptor;
    ~File() { if (descriptor >= 0) close(descriptor); }
};
bool same(const struct stat& a, const struct stat& b) {
    return a.st_dev == b.st_dev && a.st_ino == b.st_ino && a.st_size == b.st_size &&
        a.st_mtim.tv_sec == b.st_mtim.tv_sec && a.st_mtim.tv_nsec == b.st_mtim.tv_nsec &&
        a.st_ctim.tv_sec == b.st_ctim.tv_sec && a.st_ctim.tv_nsec == b.st_ctim.tv_nsec;
}
QByteArray scan(int descriptor, std::uint64_t size, std::stop_token stop, bool copyToPipe) {
    QCryptographicHash hash(QCryptographicHash::Sha256);
    std::array<char, 65536> block{};
    for (std::uint64_t first = 0; first < size;) {
        require(!stop.stop_requested(), "Preparation/pipe cancelled");
        const auto count = std::min<std::uint64_t>(block.size(), size - first);
        const auto read = pread(descriptor, block.data(), count, static_cast<off_t>(first));
        if (read < 0 && errno == EINTR) continue;
        require(read == static_cast<ssize_t>(count), "Short immutable input read");
        hash.addData(QByteArrayView(block.data(), count));
        if (copyToPipe) {
            std::cout.write(block.data(), static_cast<std::streamsize>(count));
            require(std::cout.good(), "PCM pipe write failed");
        }
        first += count;
    }
    return hash.result().toHex();
}
}

int main(int argc, char** argv) {
    static_assert(std::endian::native == std::endian::little && sizeof(float) == 4);
    if (argc != 3 || (std::string_view(argv[1]) != "02" && std::string_view(argv[1]) != "03")) {
        std::cerr << "Expected {02|03} EXISTING_PRIVATE_SPOOL\n";
        return 2;
    }
    const bool second = std::string_view(argv[1]) == "03";
    const auto expectedHash = second ? "40bfb7831f4260dc2340455addf2d9df15f5463cfcd729bad5e751419198418f" :
        "c6ed76aebbd7a6f2b6fe120ec4689a247a40b8aca61de209e9112d5cf6d1f3cc";
    const std::uint64_t expectedBytes = second ? 6049196 : 4218668;
    const auto source = std::string("/home/kyau/projects/kyaulabs/conflux/build/m2-analysis-qualification-01/") +
        "swd-metadata-admission-01/sources-original/Schubert_D911-" + argv[1] + "_SC06.wav";
    std::stop_source cancelled;
    std::signal(SIGINT, signalStop);
    std::signal(SIGTERM, signalStop);
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(40);
    std::jthread watchdog([&](std::stop_token done) {
        while (!done.stop_requested()) {
            if (interrupted.test(std::memory_order_relaxed) || std::chrono::steady_clock::now() >= deadline) {
                cancelled.request_stop();
                return;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    });
    int result = 1;
    try {
        const auto spool = std::filesystem::path(argv[2]);
        require(std::filesystem::is_directory(spool) && !std::filesystem::is_symlink(spool), "Spool is not an existing private directory");
        File original{open(source.c_str(), O_RDONLY | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW)};
        require(original.descriptor >= 0, "Cannot open fixed original source");
        struct stat before{}, after{};
        require(fstat(original.descriptor, &before) == 0 && S_ISREG(before.st_mode) &&
            before.st_size == static_cast<off_t>(expectedBytes), "Original type/extent differs");
        const auto stop = cancelled.get_token();
        require(scan(original.descriptor, expectedBytes, stop, false) == expectedHash, "Original source SHA differs");
        auto prepared = conflux::audio::prepareAudioFile(original.descriptor, 69120000, stop, spool);
        const auto pcm = scan(prepared.descriptor(), prepared.frames() * 8, stop, true);
        std::cout.flush();
        require(std::cout.good() && scan(original.descriptor, expectedBytes, stop, false) == expectedHash &&
            fstat(original.descriptor, &after) == 0 && same(before, after) && !stop.stop_requested(), "Source/PCM completion changed");
        const QJsonObject metadata{{"schema", 1}, {"case", QString::fromLatin1(argv[1])},
            {"complete", true}, {"source_sha256", QString::fromLatin1(expectedHash)},
            {"source_bytes", static_cast<qint64>(expectedBytes)}, {"prepared_frames", static_cast<qint64>(prepared.frames())},
            {"prepared_pcm_sha256", QString::fromLatin1(pcm)}, {"sample_rate", 48000}, {"channels", 2},
            {"audio_device_opened", false}};
        const auto raw = QJsonDocument(metadata).toJson(QJsonDocument::Compact) + '\n';
        std::cerr.write(raw.constData(), raw.size());
        result = 0;
    } catch (const std::exception& error) { std::cerr << error.what() << '\n'; }
    watchdog.request_stop();
    watchdog.join();
    return result;
}
