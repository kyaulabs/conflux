from pathlib import Path
import hashlib,json
ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
TARGET=ROOT/'build/m2-winterreise-publisher-global-01'
REMOTE='/srv/conflux-tests/work/winterreise-publisher-global-20261029-01'
ASSETS='/srv/conflux-tests/work/fmak-independent-keycnn-20261029-01/assets'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
 '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
 '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
def pin(path):
 path=Path(path);assert path.is_file()and not path.is_symlink()
 with path.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 return dict(path=str(path),bytes=path.stat().st_size,sha256=digest)
def save(path,value):
 with Path(path).open('x')as stream:stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')
