from pathlib import Path
import gzip,hashlib,json,shutil
from support import ROOT,TARGET,pin

closed=json.loads((TARGET/'corpus-closed-before-scoring-01.json').read_text())
assert closed['both_units_retired']and closed['apollo_container_absent']
scores=json.loads((TARGET/'corpus-scores-01.json').read_text())
comparison=json.loads((TARGET/'dense-comparison-01.json').read_text())
assert scores['full_23_case_capture_per_host']and scores['cross_host_same_global_class']==23
stage=TARGET/'report-stage-01';stage.mkdir(mode=0o700)
data=stage/'data';data.mkdir(mode=0o700)
decoded=stage/'decoded';decoded.mkdir(mode=0o700)
# Keep publisher sources external: retain their exact hashes and source commit.
originals={n:pin(TARGET/'sources'/n)for n in('feature.py','classifier.py')}
(TARGET/'publisher-source-provenance-01.json').write_text(json.dumps(dict(
 repository='https://github.com/hendriks73/key-cnn',commit='9715d6f443c0f01d9842e567a3f20c9b228c3c7f',
 files=originals,publisher_source_bytes_redistributed=False,weights_redistributed=False),indent=2)+'\n')
ref=json.loads((TARGET/'scoring-contract-01.json').read_text())['reference']
assert pin(Path(ref['path']))==ref
candidates=[]
for directory in [TARGET,TARGET/'laptop',TARGET/'laptop/output-01']:
 for p in directory.iterdir():
  if p.is_file()and not p.is_symlink()and p.suffix in('.py','.json','.log','.stderr'):
   candidates.append((p.relative_to(TARGET).as_posix(),p))
for p in (TARGET/'apollo-collected-01').rglob('*'):
 if p.is_file()and not p.is_symlink()and p.suffix in('.py','.json','.log','.stderr'):
  candidates.append((p.relative_to(TARGET).as_posix(),p))
candidates.append(('reference-selection-plan-02.json',Path(ref['path'])))
seen={};members=[];aliases=[];total=0
for name,p in sorted(candidates):
 assert '/sources/'not in '/'+name
 raw=p.read_bytes();raw.decode('utf-8');assert len(raw)<=8*1024**2
 total+=len(raw);assert total<48*1024**2
 digest=hashlib.sha256(raw).hexdigest()
 if digest in seen:
  aliases.append(dict(source=name,member=seen[digest],bytes=len(raw),sha256=digest));continue
 member=f'{len(members):03d}-'+name.replace('/','--')+'.gz';seen[digest]=member
 compressed=gzip.compress(raw,compresslevel=9,mtime=0)
 (data/member).write_bytes(compressed);(decoded/member[:-3]).write_bytes(raw)
 assert gzip.decompress(compressed)==raw
 members.append(dict(source=name,member=member,bytes=len(raw),sha256=digest,gzip_bytes=len(compressed),gzip_sha256=hashlib.sha256(compressed).hexdigest()))
manifest=dict(schema=1,members=members,aliases=aliases,source_audio_or_weights_or_binary_arrays_included=False,
 publisher_source_bytes_redistributed=False,unique_decoded_bytes=sum(r['bytes']for r in members),total_source_text_bytes=total)
(data/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
report='''# Publisher-default whole-track key screen

The publisher-default Winterreise Key-CNN method matched **11/24 selected tracks
(45.83%)** on each host, or **11/23 decoded tracks (47.83%)**. The unchanged MP3
rejection remains in the denominator. All 23 global decisions match the earlier
dense-window screen; switching to this whole-track recipe did not improve this
sample. The stock KeyFinder screen had matched 12/24 selections. These results
do not justify enabling automatic key detection.

| Check | Laptop | Apollo |
| --- | --- | --- |
| Complete model predictions | 23 | 23 |
| Source rejections retained | 1 | 1 |
| Inference failures | 0 | 0 |
| Global reference matches | 11/24 | 11/24 |
| CPU capture wall time | 1,128.177 s | 1,137.069 s |

This is the same fixed independent-artist selection used in the
[earlier screen](independent-keycnn-2026-10-29.md), with its reference labels and
results already exposed. It does not establish independence from upstream
training, local key-change accuracy or confidence calibration. The largest raw
mean assigned to an incorrect result was 0.784247. No threshold was fitted;
confidence remains Unknown and the production key backend remains disabled.

The frozen recipe uses the same checkpoint, legacy CQT and numeric forward path.
It follows the publisher's [60-frame, hop-30 global contexts without edge
padding](https://github.com/hendriks73/key-cnn/blob/9715d6f443c0f01d9842e567a3f20c9b228c3c7f/keycnn/feature.py)
and [float32 posterior average with first argmax](https://github.com/hendriks73/key-cnn/blob/9715d6f443c0f01d9842e567a3f20c9b228c3c7f/keycnn/classifier.py).
Short input receives the publisher's required right padding. Global normalization
precedes numerical batching. The separate float64 audit changed no decision.
No local key map is emitted.

Nineteen generated checks passed per host. They cover scalar window markers,
short-input padding, preservation of float64 features, whole-population
normalization, mean/argmax semantics, malformed results and owned pipeline
failure/timeout cleanup. Initial setup failures are retained: a resolved Python
path lost the virtual environment; supervisor hash checks needed Python 3.11+;
and one generated bytecode cache changed. The cache was restored from the pinned
read-only snapshot, and later children disabled bytecode writes. Runtime and
operation hashes matched at entry and exit of the actual music captures.

All 23 cross-host decisions agree. The largest raw posterior difference was
1.5497207642e-6, with zero elements outside the inherited 2e-6 absolute plus
2e-6 relative comparison bound. That bound is a descriptive numerical audit,
not a new qualification gate. The scoring contract was recorded after capture
started; inference settings were frozen before launch. Both units, their
original control groups and the private container were retired before scoring.

The [evidence manifest](data/publisher-key-2026-10-29/manifest.json) maps unique
gzip text members and byte-identical aliases to the plans, checks, failures,
captures, source metadata and scores. Publisher source files and weights remain
external, with their original commit and hashes recorded. No source audio,
model weights, arrays, runtime binaries or generated bytecode are redistributed.

These were CPU correctness captures. No player, hardware audio output or GPU
started, and no sync service, power policy, thermal rule, Best-quality stem
setting or milestone gate changed. M2's primary-laptop p99 target remains below
4.095 seconds; M2, M3 and the first release remain open.
'''
(stage/'publisher-key-2026-10-29.md').write_text(report)
(TARGET/'report-package-01.json').write_text(json.dumps(dict(members=len(members),aliases=len(aliases),unique_decoded_bytes=manifest['unique_decoded_bytes'],
 gzip_bytes=sum(r['gzip_bytes']for r in members),source_audio_or_weights_included=False,publisher_source_redistributed=False),indent=2)+'\n')
print((TARGET/'report-package-01.json').read_text())
