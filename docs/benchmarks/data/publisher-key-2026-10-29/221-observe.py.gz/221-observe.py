"""Observe fixed CPU music captures and collect text only after owned cleanup."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import base64
import hashlib
import inspect
import json
from pathlib import Path
import subprocess
import time
from support import TARGET,save
from support import REMOTE,SSH,ASSETS


def observe(base,local,expired):
    plan=json.loads((base/('music-plan-01.json'if local else'operations/music-plan-01.json')).read_text())
    unit=plan['unit'];prefix=['systemctl']+(['--user']if local else[])
    def state():
        raw=subprocess.check_output(prefix+['show',unit,
            '--property=LoadState,MainPID,InvocationID,ControlGroup,ActiveState,SubState,Result,ExecMainStatus'],text=True,timeout=5)
        return dict(line.split('=',1)for line in raw.splitlines()if'='in line)
    current=state();closed_path=base/'unit-closed-01.json'
    if closed_path.exists():
        closed=json.loads(closed_path.read_text())
        assert current['LoadState']=='not-found'and current['MainPID']=='0'
    elif current['MainPID']=='0'or expired:
        binding=json.loads((base/'entry-binding.json').read_text())
        assert current['LoadState']=='loaded'and current['InvocationID']==binding['invocation']
        command=prefix+['stop',unit]
        if not local:command=['sudo','-n']+command
        subprocess.run(command,check=True,capture_output=True,timeout=25)
        after=state()
        if after['LoadState']!='not-found':
            assert after['MainPID']=='0'
            command=prefix+['reset-failed',unit]
            if not local:command=['sudo','-n']+command
            subprocess.run(command,check=True,capture_output=True,timeout=5);after=state()
        assert after['LoadState']=='not-found'and after['MainPID']=='0'
        group=binding['cgroup'].split(':',2)[2];assert group.endswith('/'+unit)
        cgroup=Path('/sys/fs/cgroup'+group)
        assert not cgroup.exists()or not any(path.read_text().strip()for path in cgroup.rglob('cgroup.procs'))
        closed=dict(before_stop=current,after_stop=after,binding=binding,
            original_cgroup_absent_or_empty=True,expired=expired)
        if not local:
            D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
            name='conflux-winterreise-publisher-global-corpus-20261029-01'
            found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
            if found.returncode==0:
                value=json.loads(found.stdout)[0]
                assert value['Image']=='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
                assert value['Config']['Labels']['org.kyaulabs.conflux.run']=='winterreise-publisher-global-corpus-20261029-01'
                subprocess.run(D+['rm','--force',value['Id']],check=True,capture_output=True,timeout=10)
            assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
            closed['container_absent']=True
        closed_path.write_text(json.dumps(closed,indent=2)+chr(10))
    else:closed=None
    rows=[json.loads(path.read_text())for path in(base/'output-01').glob('*-capture.json')]
    result=dict(unit=current,closed=closed,captures=len(rows),statuses=dict(Counter(row['status']for row in rows)))
    receipt=base/'output-01/prediction-receipt.json'
    if receipt.exists():result['receipt']=json.loads(receipt.read_text())
    return result


def main():
    reservation=json.loads((TARGET/'corpus-reservation-01.json').read_text())
    expired=time.monotonic()>=reservation['deadline_monotonic']-40
    def local():return observe(TARGET/'laptop',True,expired)
    def apollo():
        code='from pathlib import Path\nfrom collections import Counter\nimport json,subprocess\n'+inspect.getsource(observe)
        code+='\nprint(json.dumps(observe(Path('+repr(REMOTE+'/corpus-01')+'),False,'+repr(expired)+')))\n'
        r=subprocess.run(SSH+['python3 -'],input=code,capture_output=True,text=True,timeout=50)
        (TARGET/'corpus-observe.stderr.log').write_text(r.stderr);r.check_returncode()
        return json.loads(r.stdout)
    with ThreadPoolExecutor(max_workers=2)as pool:
        left=pool.submit(local);right=pool.submit(apollo)
        results=dict(laptop=left.result(),apollo=right.result())
    number=len(list(TARGET.glob('corpus-observation-*.json')))+1
    save(TARGET/f'corpus-observation-{number:03}.json',dict(utc=datetime.now(timezone.utc).isoformat(),hosts=results,
        reference_labels_parsed_by_scorer=False))
    print(json.dumps({host:{key:value for key,value in row.items()if key!='receipt'}for host,row in results.items()}))
    if not all(row['closed']for row in results.values()):return
    if(TARGET/'corpus-closed-before-scoring-01.json').exists():return
    code='BASE='+repr(REMOTE+'/corpus-01')+'\n'+r'''
from pathlib import Path
import base64,hashlib,json
base=Path(BASE);plan=json.loads((base/'operations/music-plan-01.json').read_text())
assert json.loads((base/'unit-closed-01.json').read_text())['container_absent']
names=['operations/music-plan-01.json','entry-binding.json','unit-closed-01.json','container-closed.json',
 'dispatch.json','owner.py','unit.stdout.log','unit.stderr.log','output-01/predictions-before-scoring.json',
 'output-01/prediction-receipt.json']
for case in plan['cases']:
 names += ['output-01/'+case['id']+suffix for suffix in('-capture.json','-source.json','-prediction.json','-worker.stderr','-warnings.json')]
files=[];total=0
for name in names:
 path=base/name
 if not path.exists():continue
 assert path.is_file()and not path.is_symlink()and path.stat().st_size<=1048576
 raw=path.read_bytes();total+=len(raw);assert total<=32*1024**2
 files.append(dict(file=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),base64=base64.b64encode(raw).decode()))
print(json.dumps(dict(files=files,total_bytes=total)))
'''
    r=subprocess.run(SSH+['python3 -'],input=code,capture_output=True,text=True,timeout=30)
    (TARGET/'corpus-collect.stderr.log').write_text(r.stderr);r.check_returncode()
    value=json.loads(r.stdout);destination=TARGET/'apollo-collected-01';destination.mkdir(mode=0o700)
    manifest=[]
    for row in value['files']:
        path=destination/row['file'];assert path.is_relative_to(destination)
        raw=base64.b64decode(row['base64'],validate=True)
        assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
        manifest.append({key:row[key]for key in('file','bytes','sha256')})
    save(TARGET/'corpus-apollo-collected-manifest-01.json',manifest)
    hosts={}
    for host,output in(('laptop',TARGET/'laptop/output-01'),('apollo',destination/'output-01')):
        path=output/'predictions-before-scoring.json';raw=path.read_bytes()
        receipt=json.loads((output/'prediction-receipt.json').read_text())
        assert hashlib.sha256(raw).hexdigest()==receipt['closed_capture_sha256']
        assert receipt['fixed_denominator']==receipt['completed_captures']==24 and receipt['reference_labels_opened']is False
        hosts[host]=dict(capture_sha256=hashlib.sha256(raw).hexdigest(),receipt=receipt)
    save(TARGET/'corpus-closed-before-scoring-01.json',dict(hosts=hosts,both_units_retired=True,
        apollo_container_absent=True,reference_labels_opened=False,physical_readiness_consumed=False))
    print(json.dumps(dict(both_closed=True,inferred={host:row['receipt']['inferred']for host,row in hosts.items()},
        original_source_failure_retained=True,reference_labels_parsed_by_scorer=False)))


if __name__=='__main__':main()
