"""Score closed CPU captures without fitting thresholds or changing the recipe."""
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from support import TARGET,pin,save


def main():
    closed=json.loads((TARGET/'corpus-closed-before-scoring-01.json').read_text())
    prospective=json.loads((TARGET/'scoring-contract-01.json').read_text())
    assert closed['both_units_retired']and closed['apollo_container_absent']
    assert not(TARGET/'corpus-scores-01.json').exists()
    import sys
    sys.path.insert(0,str(TARGET))
    import protocol
    from aggregate import global_class
    from run_corpus import strict_json
    predictions={};raw_rows={};statuses={};plans={}
    for host,base,output in(('laptop',TARGET/'laptop',TARGET/'laptop/output-01'),
        ('apollo',TARGET/'apollo-collected-01',TARGET/'apollo-collected-01/output-01')):
        plan=strict_json((base/('music-plan-01.json'if host=='laptop'else'operations/music-plan-01.json')).read_bytes())
        plans[host]=plan
        raw=(output/'predictions-before-scoring.json').read_bytes()
        assert hashlib.sha256(raw).hexdigest()==closed['hosts'][host]['capture_sha256']
        captures=strict_json(raw)
        assert len(captures)==24 and [row['id']for row in captures]==[row['id']for row in plan['cases']]
        predictions[host]={};raw_rows[host]={};statuses[host]={}
        for case,row in zip(plan['cases'],captures,strict=True):
            identifier=case['id'];statuses[host][identifier]=row['status']
            if case['preparation_status']!='PreparedMetadataMeasured':
                assert identifier=='003956'and row['status']=='SourcePreparationFailed'and row['model_started']is False
                assert row['complete']is False and row['error']==case['error']
                predictions[host][identifier]=(None,[]);continue
            if row['complete']is not True:
                assert row['status']in('InferenceFailed','NotRunBudget')
                predictions[host][identifier]=(None,[]);continue
            assert row['status']=='PredictionCaptured'and row['producer_reaped']and row['consumer_reaped']and row['spool_empty']
            assert row['prediction_file']==identifier+'-prediction.json'
            raw=(output/row['prediction_file']).read_bytes()
            assert len(raw)<=524288 and hashlib.sha256(raw).hexdigest()==row['prediction_sha256']
            value=strict_json(raw);source=strict_json((output/(identifier+'-source.json')).read_bytes())
            assert source==row['source'];protocol.validate_prediction(value,source,case)
            double_key,double_means=global_class(value['raw_predictions'])
            assert row['float64_check']==dict(predicted_class=double_key,mean_probabilities=double_means)
            protocol.validate_global(value['publisher_global'],value['raw_predictions'])
            key=value['publisher_global']['predicted_class'];means=value['publisher_global']['mean_probabilities']
            assert key==row['predicted_class']and means==row['mean_probabilities']
            predictions[host][identifier]=(key,means);raw_rows[host][identifier]=value['raw_predictions']
    # Selection labels were exposed earlier. They were not mounted into the
    # classifier, and no recipe or threshold is fitted by this scorer.
    reference=prospective['reference'];assert pin(Path(reference['path']))==reference
    truth_rows=strict_json(Path(reference['path']).read_bytes())['cases']
    truth={f"{row['track_id']:06d}":row['reference_class']for row in truth_rows}
    assert len(truth)==24 and set(truth)==set(predictions['laptop'])==set(predictions['apollo'])
    assert all(type(value)is int and 0<=value<24 for value in truth.values())
    results={}
    for host,values in predictions.items():
        cases=[]
        bins=[dict(first=index/5,end=(index+1)/5,estimated=0,matches=0)for index in range(5)]
        for case in plans[host]['cases']:
            identifier=case['id'];key,means=values[identifier]
            match=key is not None and key==truth[identifier]
            maximum=max(means)if means else None
            cases.append(dict(id=identifier,reference_class=truth[identifier],predicted_class=key,
                match=match,status=statuses[host][identifier],mean_probabilities=means,
                maximum_mean_probability=maximum,confidence='Unknown'))
            if maximum is not None:
                cell=bins[min(4,int(maximum*5))];cell['estimated']+=1;cell['matches']+=int(match)
        correct=sum(row['match']for row in cases);estimated=sum(row['predicted_class']is not None for row in cases)
        results[host]=dict(cases=cases,global_exact=dict(matches=correct,denominator=24,percent=correct/24*100),
            estimated_subset=dict(matches=correct,denominator=estimated,percent=correct/estimated*100 if estimated else None),
            source_preparation_failures=sum(row['status']=='SourcePreparationFailed'for row in cases),
            inference_failures=sum(row['status']=='InferenceFailed'for row in cases),
            not_run_budget=sum(row['status']=='NotRunBudget'for row in cases),
            raw_probability_bins=bins,confidence='Unknown',qualified=False)
    both=set(raw_rows['laptop'])&set(raw_rows['apollo']);differences=[];maximum_error=0.;failed_elements=0
    same_class=0
    for identifier in sorted(both):
        left=raw_rows['laptop'][identifier];right=raw_rows['apollo'][identifier]
        assert len(left)==len(right)
        same_class+=predictions['laptop'][identifier][0]==predictions['apollo'][identifier][0]
        for a,b in zip(left,right,strict=True):
            assert a['index']==b['index']and a['signal_nonzero']==b['signal_nonzero']
            for x,y in zip(a['probabilities'],b['probabilities'],strict=True):
                error=abs(x-y);maximum_error=max(maximum_error,error)
                if error>prospective['cross_host_audit_atol']+prospective['cross_host_audit_rtol']*abs(x):
                    failed_elements+=1
                    if identifier not in differences:differences.append(identifier)
    report=dict(schema=1,scored_at_utc=datetime.now(timezone.utc).isoformat(),
        recipe=plans['laptop']['recipe'],model_sha256=plans['laptop']['model_sha256'],
        hosts=results,fixed_denominator=24,cross_host_comparable_predictions=len(both),
        cross_host_same_global_class=same_class,cross_host_maximum_posterior_difference=maximum_error,
        cross_host_elements_outside_inherited_audit_bound=failed_elements,cross_host_cases_outside_inherited_audit_bound=differences,
        full_23_case_capture_per_host=all(closed['hosts'][host]['receipt']['inferred']==23 and
            closed['hosts'][host]['receipt']['all_inferable_sources_completed']for host in results),
        source_failure_retained='003956',both_captures_closed_and_owned_resources_retired_before_scoring=True,
        reference_metadata_previously_exposed=True,KeyCNN_settings_tuned_using_this_sample=False,
        raw_probability_bins_descriptive_only=True,confidence_threshold_fitted=False,
        primary_aggregation='Publisher np.average float32 and first np.argmax',
        cross_host_bound_is_inherited_numerical_audit_not_qualification=True,
        scoring_contract_written_after_capture_started=True,
        confidence_calibration_qualified=False,local_key_changes_qualified=False,
        upstream_training_independence_established=False,production_key_backend_enabled=False,
        hardware_or_latency_qualified=False,milestone_or_release_gate_closed=False,qualified=False)
    save(TARGET/'corpus-scores-01.json',report)
    print(json.dumps(dict(hosts={host:{key:row[key]for key in('global_exact','estimated_subset','inference_failures')}for host,row in results.items()},
        same_global_class=same_class,comparable=len(both),maximum_posterior_difference=maximum_error,
        elements_outside_bound=failed_elements,qualified=False),indent=2))


if __name__=='__main__':main()
