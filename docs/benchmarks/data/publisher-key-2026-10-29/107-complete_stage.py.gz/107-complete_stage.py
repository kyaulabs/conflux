import json,os,subprocess,sys
from pathlib import Path
from support import TARGET,SSH,REMOTE,pin,save
local=TARGET/'laptop';plan=json.loads((local/'music-plan-01.json').read_text())
assert not(TARGET/'corpus-staged-01.json').exists()
previous=json.loads((TARGET/'frozen-checks-attempt2.json').read_text());remote=previous['apollo']
assert remote['exit']==0 and remote['container_absent']and remote['runtime_and_operation_pins_verified_before_after']
sys.path.insert(0,str(local));import run_corpus
for row in plan['input_pins']:run_corpus.verify(row)
run_corpus.verify_assets(plan)
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
code="import sys,unittest;sys.path.insert(0,"+repr(str(local))+");unittest.main(module=None,argv=['generated','-v','test_window_contract','test_average','test_pipeline','test_lifecycle'])"
r=subprocess.run([plan['python'],'-I','-B','-c',code],capture_output=True,text=True,env=env,timeout=30)
(TARGET/'frozen-local-final.stdout.log').write_text(r.stdout);(TARGET/'frozen-local-final.stderr.log').write_text(r.stderr)
run_corpus.verify_assets(plan)
assert r.returncode==0 and 'Ran 19 tests'in r.stderr and r.stderr.rstrip().endswith('OK'),r.stderr[-2000:]
save(TARGET/'corpus-staged-01.json',dict(local_protocol_exit=0,apollo=remote,tests_per_host=19,
 concurrent_attempt_recorded=True,local_completion_after_preserved_cache_repair=True,
 local_plan=pin(local/'music-plan-01.json'),prospective=pin(TARGET/'prospective-01.json'),asset_manifest=pin(TARGET/'asset-manifest-01.json'),
 unchanged_runtime_assets_verified_on_both_hosts=True,runtime_and_operation_pins_verified_before_after=True,
 apollo_native_inputs_checked_at_capture_entry=True,music_classifier_started=False,physical_readiness_consumed=False))
print(json.dumps(dict(passed=True,tests_per_host=19,original_runtime_hashes_match=True,setup_failures_retained=True,music_started=False)))
