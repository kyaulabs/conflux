import numpy as np

def scalar_windows(matrix,hop,zero_pad):
    """Independent scalar ownership oracle; no publisher padding/window helpers."""
    bins,columns=matrix.shape
    effective=max(60,columns+(60 if zero_pad else 0))
    starts=list(range(0,effective-59,hop))
    result=np.empty((len(starts),bins,60,1),dtype=np.float32)
    for window,first in enumerate(starts):
        for offset in range(60):
            source=first+offset-(30 if zero_pad else 0)
            result[window,:,offset,0]=matrix[:,source] if 0<=source<columns else 0
    return result,starts
