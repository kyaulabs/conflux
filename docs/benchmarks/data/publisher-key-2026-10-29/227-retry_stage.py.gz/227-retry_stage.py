from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json,os,subprocess,sys
from support import TARGET,REMOTE,ASSETS,SSH,pin,save

local=TARGET/'laptop';plan=json.loads((local/'music-plan-01.json').read_text())
assert not(TARGET/'corpus-staged-01.json').exists()
setup='BASE='+repr(REMOTE)+'\nASSETS='+repr(ASSETS)+'\n'+r'''
from pathlib import Path
import json,subprocess
base=Path(BASE);folder=base/'corpus-01';ops=folder/'operations'
prior=json.loads((folder/'protocol-receipt-01.json').read_text());assert prior['exit']!=0 and prior['container_absent']
(folder/'protocol-receipt-attempt1.json').write_text(json.dumps(prior,indent=2)+chr(10))
plan=json.loads((ops/'music-plan-01.json').read_text());root=json.loads((ops/'asset-manifest.json').read_text())['container_asset_root']
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
name='conflux-winterreise-publisher-global-checks-20261029-02';label='winterreise-publisher-global-checks-20261029-02'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
# The supervisor's hashlib.file_digest requires Python3.11+, while generated
# numerical checks use the unchanged Python3.10 virtual environment.
bootstrap="""from pathlib import Path
import json,os,subprocess,sys
sys.path.insert(0,'/operations')
import run_corpus
assert not any(Path(p).exists()for p in('/dev/nvidia0','/dev/dri','/dev/snd'))
plan=json.load(open('/operations/music-plan-01.json'))
run_corpus.verify_assets(plan)
for row in plan['input_pins']:
 if row['path'].startswith('/operations/'):run_corpus.verify(row)
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
check=\"import sys,unittest;sys.path.insert(0,'/operations');unittest.main(module=None,argv=['generated','-v','test_window_contract','test_average','test_pipeline','test_lifecycle'])\"
r=subprocess.run([plan['python'],'-I','-B','-c',check],capture_output=True,text=True,env=env,timeout=25)
print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr)
run_corpus.verify_assets(plan)
raise SystemExit(r.returncode)
"""
command=D+['run','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true',
 '--user=1000:1000','--cpus=1','--memory=1g','--pids-limit=128','--label','org.kyaulabs.conflux.run='+label,
 '--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--mount','type=bind,src='+str(ops)+',dst=/operations,readonly',
 '--mount','type=bind,src='+ASSETS+',dst='+root+',readonly',image,'python','-B','-c',bootstrap]
try:r=subprocess.run(command,capture_output=True,text=True,timeout=50)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  v=json.loads(found.stdout)[0];assert v['Image']==image and v['Config']['Labels']['org.kyaulabs.conflux.run']==label
  subprocess.run(D+['rm','--force',v['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
receipt=dict(exit=r.returncode,container_absent=True,stdout=r.stdout,stderr=r.stderr,plan=plan,music_or_model_started=False,
 setup_failure_retained=True,runtime_and_operation_pins_verified_before_after=r.returncode==0)
(folder/'protocol-receipt-01.json').write_text(json.dumps(receipt,indent=2)+chr(10));print(json.dumps(receipt));r.check_returncode()
assert 'Ran 19 tests'in r.stderr and r.stderr.rstrip().endswith('OK')
'''
def check_local():
 sys.path.insert(0,str(local));import run_corpus
 for row in plan['input_pins']:run_corpus.verify(row)
 run_corpus.verify_assets(plan)
 code="import sys,unittest;sys.path.insert(0,"+repr(str(local))+");unittest.main(module=None,argv=['generated','-v','test_window_contract','test_average','test_pipeline','test_lifecycle'])"
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
 r=subprocess.run([plan['python'],'-I','-B','-c',code],capture_output=True,text=True,env=env,timeout=30)
 (TARGET/'frozen-local-attempt2.stdout.log').write_text(r.stdout);(TARGET/'frozen-local-attempt2.stderr.log').write_text(r.stderr)
 run_corpus.verify_assets(plan)
 assert r.returncode==0 and'Ran 19 tests'in r.stderr and r.stderr.rstrip().endswith('OK'),r.stderr[-2000:]
 return dict(exit=r.returncode,tests=19)
def check_remote():
 r=subprocess.run(SSH+['python3 -'],input=setup,capture_output=True,text=True,timeout=80)
 (TARGET/'frozen-apollo-attempt2.stdout.log').write_text(r.stdout);(TARGET/'frozen-apollo-attempt2.stderr.log').write_text(r.stderr)
 r.check_returncode();return json.loads(r.stdout)
results={}
with ThreadPoolExecutor(max_workers=2)as pool:
 futures={h:pool.submit(f)for h,f in(('laptop',check_local),('apollo',check_remote))}
 for host,future in futures.items():
  try:results[host]=future.result()
  except Exception as error:results[host]=dict(exit=1,error=dict(type=type(error).__name__,message=str(error)))
save(TARGET/'frozen-checks-attempt2.json',results)
assert all(r['exit']==0 for r in results.values()),results
save(TARGET/'corpus-staged-01.json',dict(local_protocol_exit=0,apollo=results['apollo'],tests_per_host=19,concurrent=True,
 local_plan=pin(local/'music-plan-01.json'),prospective=pin(TARGET/'prospective-01.json'),asset_manifest=pin(TARGET/'asset-manifest-01.json'),
 unchanged_runtime_assets_verified_on_both_hosts=True,runtime_and_operation_pins_verified_before_after=True,
 apollo_native_inputs_checked_at_capture_entry=True,music_classifier_started=False,physical_readiness_consumed=False))
print(json.dumps(dict(passed=True,tests_per_host=19,concurrent=True,immutable_runtime_and_operations_verified=True,music_started=False)))
