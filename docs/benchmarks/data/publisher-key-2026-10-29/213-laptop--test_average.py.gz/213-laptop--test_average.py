"""Generated publisher aggregation and whole-population normalization checks."""
import ast
import copy
import hashlib
import importlib.util
from pathlib import Path
import unittest
import numpy as np
import protocol
from publisher_average import publisher_global,SOURCE,SOURCE_SHA

class PublisherAverageChecks(unittest.TestCase):
    def test_actual_publisher_mean_is_not_a_window_majority_vote(self):
        rows=np.zeros((3,24),dtype=np.float32)
        rows[0,:2]=rows[1,:2]=[.51,.49];rows[2,1]=1
        got=publisher_global(rows)
        self.assertEqual(got['predicted_class'],1)
        self.assertEqual(got['mean_dtype'],'float32')
        self.assertTrue(np.array_equal(np.asarray(got['mean_probabilities'],dtype=np.float32),np.average(rows,axis=0)))
        protocol.validate_global(got,[dict(probabilities=r.tolist())for r in rows])

    def test_equal_scores_keep_the_first_class_and_all_rows_contribute(self):
        rows=np.zeros((2,24),dtype=np.float32);rows[0,0]=rows[1,1]=1
        self.assertEqual(publisher_global(rows)['predicted_class'],0)
        rows=np.tile(np.asarray([1/24]*24,dtype=np.float32),(124,1))
        result=publisher_global(rows)
        protocol.validate_global(result,[dict(probabilities=r.tolist())for r in rows])
        self.assertEqual(result['predicted_class'],0)

    def test_malformed_posteriors_and_aggregate_fail_closed(self):
        for row in [np.zeros((0,24),dtype=np.float32),np.zeros((125,24),dtype=np.float32),
          np.full((1,24),np.nan,dtype=np.float32),np.full((1,24),1/24,dtype=np.float64),
          np.zeros((1,24),dtype=np.float32),np.ones((1,23),dtype=np.float32)]:
            with self.subTest(shape=row.shape,dtype=str(row.dtype)),self.assertRaises(ValueError):publisher_global(row)
        rows=np.zeros((1,24),dtype=np.float32);rows[0,3]=1
        good=publisher_global(rows);raw=[dict(probabilities=rows[0].tolist())]
        for mode in ['key','mean','dtype','nan','boolean']:
            value=copy.deepcopy(good)
            if mode=='key':value['predicted_class']=2
            elif mode=='mean':value['mean_probabilities']=[1/24]*24
            elif mode=='dtype':value['mean_dtype']='float64'
            elif mode=='nan':value['mean_probabilities'][3]=float('nan')
            else:value['predicted_class']=True
            with self.subTest(mode=mode),self.assertRaises(ValueError):protocol.validate_global(value,raw)

    def test_whole_context_population_is_normalized_before_batching(self):
        raw=SOURCE.read_bytes();self.assertEqual(hashlib.sha256(raw).hexdigest(),SOURCE_SHA)
        nodes=[n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)and n.name=='std_normalizer']
        self.assertEqual(len(nodes),1)
        namespace={'np':np};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SOURCE),'exec'),namespace)
        path=protocol.DATA/'numeric-forward-03/keycnn_numeric.py'
        spec=importlib.util.spec_from_file_location('audited_numeric_normalization_only',path)
        numeric=importlib.util.module_from_spec(spec);spec.loader.exec_module(numeric)
        for count in [1,4,7,13]:
            values=np.arange(count*168*60,dtype=np.float64).reshape(count,168,60,1)/97+.00000123
            values[-1]*=17
            for features in [values,np.zeros_like(values),np.full_like(values,3.2)]:
                expected=namespace['std_normalizer'](features).astype(np.float32)
                self.assertTrue(np.array_equal(numeric.normalize(features).view(np.uint32),expected.view(np.uint32)))
            if count>4:
                whole=numeric.normalize(values)
                separately=np.concatenate([numeric.normalize(values[i:i+4])for i in range(0,count,4)])
                self.assertFalse(np.array_equal(whole,separately))

if __name__=='__main__':unittest.main(verbosity=2)
