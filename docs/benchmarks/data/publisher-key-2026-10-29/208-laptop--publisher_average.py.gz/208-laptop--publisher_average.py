"""Pinned publisher whole-track average/argmax, without importing TensorFlow."""
import ast
import hashlib
from pathlib import Path
from types import SimpleNamespace
import numpy as np
SOURCE=Path(__file__).resolve().parent/'sources/classifier.py'
SOURCE_SHA='b7e5aac2b6c10799f4da13d99167f79d34b0bfbb9584284b5686e0b49fde5827'

def publisher_global(posterior):
    if type(posterior)is not np.ndarray or posterior.dtype!=np.dtype('float32') or posterior.ndim!=2 or not 1<=len(posterior)<=124 or posterior.shape[1]!=24 or not np.isfinite(posterior).all() or np.any(posterior<0) or np.any(posterior>1):
        raise ValueError('Expected bounded finite float32 posterior rows')
    if not np.all(np.abs(np.sum(posterior.astype(np.float64),axis=1)-1)<=2e-6):
        raise ValueError('Unnormalized posterior rows')
    raw=SOURCE.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=SOURCE_SHA:raise ValueError('Publisher classifier source changed')
    classes=[node for node in ast.parse(raw).body if isinstance(node,ast.ClassDef)and node.name=='KeyClassifier']
    if len(classes)!=1:raise ValueError('Publisher classifier class differs')
    nodes=[node for node in classes[0].body if isinstance(node,ast.FunctionDef)and node.name=='estimate_key']
    if len(nodes)!=1:raise ValueError('Publisher global method differs')
    namespace={'np':np};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SOURCE),'exec'),namespace)
    key=namespace['estimate_key'](SimpleNamespace(estimate=lambda unused:posterior,to_key=int),None)
    means=np.average(posterior,axis=0)
    if means.dtype!=np.dtype('float32'):raise ValueError('Publisher mean dtype differs')
    return dict(predicted_class=key,mean_probabilities=means.tolist(),mean_dtype=str(means.dtype))
