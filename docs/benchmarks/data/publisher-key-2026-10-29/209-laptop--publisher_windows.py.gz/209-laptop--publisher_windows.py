"""Pinned publisher global-window defaults over an already computed CQT."""
import ast
import hashlib
from pathlib import Path
import numpy as np

SOURCE=Path(__file__).resolve().parent/'sources/feature.py'
SOURCE_SHA='3b6c72840fb6680b0f171ae9f6e2fda09a839615903c7768828e49e174f72ffc'


def global_windows(cqt):
    if (type(cqt) is not np.ndarray or cqt.dtype not in (np.dtype('float32'),np.dtype('float64')) or cqt.ndim!=2
            or cqt.shape[0]!=168 or not 1<=cqt.shape[1]<=3764
            or not np.isfinite(cqt).all() or np.any(cqt<0)):
        raise ValueError('Expected finite nonnegative floating-point 168-bin bounded CQT')
    raw=SOURCE.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=SOURCE_SHA:
        raise ValueError('Publisher feature source changed')
    names={'_ensure_length','_to_sliding_window'}
    nodes=[node for node in ast.parse(raw).body if isinstance(node,ast.FunctionDef) and node.name in names]
    if {node.name for node in nodes}!=names:
        raise ValueError('Publisher window helper population differs')
    namespace={'np':np}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SOURCE),'exec'),namespace)
    data=cqt.reshape(1,168,cqt.shape[1],1)
    if data.shape[2]<60:
        data=namespace['_ensure_length'](data,60)
    result=namespace['_to_sliding_window'](data,60,30)
    expected=max(1,(cqt.shape[1]-60)//30+1)
    if result.shape!=(expected,168,60,1):
        raise ValueError('Publisher default global geometry differs')
    return result
