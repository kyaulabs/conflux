from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json,subprocess
from support import ROOT,TARGET,REMOTE,ASSETS,SSH,pin,save

prior=ROOT/'build/m2-fmak-independent-01/keycnn-01'
assert not(TARGET/'corpus-staged-01.json').exists()
manifest=json.loads((prior/'asset-manifest-01.json').read_text())
manifest.pop('model_or_recipe_changed',None);manifest.update(asset_bytes_changed=False,context_recipe_changed=True)
(TARGET/'asset-manifest-01.json').write_text(json.dumps(manifest,indent=2)+'\n')
names=['run_corpus.py','protocol.py','aggregate.py','score_global.py','keycnn_worker.py',
 'publisher_windows.py','publisher_average.py','scalar_oracle.py','test_window_contract.py','test_average.py',
 'test_lifecycle.py','test_pipeline.py','sources/feature.py','sources/classifier.py']
files={n:(TARGET/n).read_text()for n in names};files['asset-manifest.json']=(TARGET/'asset-manifest-01.json').read_text()
local=TARGET/'laptop';local.mkdir(mode=0o700)
for name,text in files.items():
 p=local/name;p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.write_text(text)
plan=json.loads((prior/'laptop/music-plan-01.json').read_text());prospective=json.loads((TARGET/'prospective-01.json').read_text())
plan.update(recipe=prospective['recipe'],worker=str(local/'keycnn_worker.py'),unit='conflux-winterreise-publisher-global-laptop-20261029-01.service',
 asset_manifest=str(local/'asset-manifest.json'),publisher_global_mean_dtype='float32')
plan['input_pins']=[plan['preparer']]+[row['source']for row in plan['cases']]+[pin(local/n)for n in files]
(local/'music-plan-01.json').write_text(json.dumps(plan,indent=2)+'\n')
remote_plan=json.loads((prior/'apollo/music-plan-01.json').read_text())
remote_plan.update(recipe=prospective['recipe'],worker='/operations/keycnn_worker.py',unit='conflux-winterreise-publisher-global-apollo-20261029-01.service',
 asset_manifest='/operations/asset-manifest.json',publisher_global_mean_dtype='float32')
setup='BASE='+repr(REMOTE)+'\nASSETS='+repr(ASSETS)+'\nFILES='+repr(files)+'\nPLAN='+repr(remote_plan)+'\n'+r'''
from pathlib import Path
import hashlib,json,subprocess
base=Path(BASE);assert not base.exists();base.mkdir(mode=0o700)
folder=base/'corpus-01';folder.mkdir(mode=0o700);ops=folder/'operations';ops.mkdir(mode=0o700)
for name,text in FILES.items():
 p=ops/name;p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.write_text(text)
def pin(path,target):
 with path.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 return dict(path=target,bytes=path.stat().st_size,sha256=digest)
PLAN['input_pins']=[PLAN['preparer']]+[r['source']for r in PLAN['cases']]+[pin(ops/n,'/operations/'+n)for n in FILES]
(ops/'music-plan-01.json').write_text(json.dumps(PLAN,indent=2)+chr(10))
(folder/'output-01').mkdir(mode=0o700);(ops/'output-01').mkdir(mode=0o700)
for name in('unit.stdout.log','unit.stderr.log'):(folder/name).touch(mode=0o600,exist_ok=False)
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
name='conflux-winterreise-publisher-global-checks-20261029-01';label='winterreise-publisher-global-checks-20261029-01'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
inside="import sys,unittest,json;sys.path.insert(0,'/operations');import run_corpus;plan=json.load(open('/operations/music-plan-01.json'));run_corpus.verify_assets(plan);unittest.main(module=None,argv=['generated','-v','test_window_contract','test_average','test_pipeline','test_lifecycle'])"
root=json.loads(FILES['asset-manifest.json'])['container_asset_root']
python=root+'/feature-compatibility-01/venv/bin/python'
command=D+['run','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true',
 '--user=1000:1000','--cpus=1','--memory=1g','--pids-limit=128','--label','org.kyaulabs.conflux.run='+label,
 '--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--mount','type=bind,src='+str(ops)+',dst=/operations,readonly',
 '--mount','type=bind,src='+ASSETS+',dst='+root+',readonly',image,python,'-I','-B','-c',inside]
try:r=subprocess.run(command,capture_output=True,text=True,timeout=45)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  v=json.loads(found.stdout)[0];assert v['Image']==image and v['Config']['Labels']['org.kyaulabs.conflux.run']==label
  subprocess.run(D+['rm','--force',v['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
receipt=dict(exit=r.returncode,container_absent=True,stdout=r.stdout,stderr=r.stderr,plan=PLAN,music_or_model_started=False)
(folder/'protocol-receipt-01.json').write_text(json.dumps(receipt,indent=2)+chr(10));print(json.dumps(receipt));r.check_returncode()
assert 'Ran 19 tests'in r.stderr and r.stderr.rstrip().endswith('OK')
'''
def check_local():
 code="import sys,unittest,json;sys.path.insert(0,"+repr(str(local))+");import run_corpus;plan=json.load(open("+repr(str(local/'music-plan-01.json'))+"));[run_corpus.verify(row)for row in plan['input_pins']];run_corpus.verify_assets(plan);unittest.main(module=None,argv=['generated','-v','test_window_contract','test_average','test_pipeline','test_lifecycle'])"
 r=subprocess.run([plan['python'],'-I','-B','-c',code],capture_output=True,text=True,timeout=45)
 (TARGET/'frozen-local.stdout.log').write_text(r.stdout);(TARGET/'frozen-local.stderr.log').write_text(r.stderr)
 assert r.returncode==0 and'Ran 19 tests'in r.stderr and r.stderr.rstrip().endswith('OK'),r.stderr[-2000:]
 return dict(exit=r.returncode,tests=19)
def check_remote():
 r=subprocess.run(SSH+['python3 -'],input=setup,capture_output=True,text=True,timeout=80)
 (TARGET/'frozen-apollo.stdout.log').write_text(r.stdout);(TARGET/'frozen-apollo.stderr.log').write_text(r.stderr)
 r.check_returncode();return json.loads(r.stdout)
with ThreadPoolExecutor(max_workers=2)as pool:
 left=pool.submit(check_local);right=pool.submit(check_remote)
 local_result=left.result();remote=right.result()
save(TARGET/'corpus-staged-01.json',dict(local_protocol_exit=local_result['exit'],apollo=remote,tests_per_host=19,concurrent=True,
 local_plan=pin(local/'music-plan-01.json'),prospective=pin(TARGET/'prospective-01.json'),asset_manifest=pin(TARGET/'asset-manifest-01.json'),
 unchanged_runtime_assets_verified_on_both_hosts=True,music_classifier_started=False,physical_readiness_consumed=False))
print(json.dumps(dict(passed=True,tests_per_host=19,concurrent=True,source_and_runtime_hashes_checked=True,music_started=False)))
