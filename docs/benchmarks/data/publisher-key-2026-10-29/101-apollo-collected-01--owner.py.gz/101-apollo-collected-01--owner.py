BASE='/srv/conflux-tests/work/winterreise-publisher-global-20261029-01'

from pathlib import Path
import json,os,signal,subprocess,time
base=Path(BASE);folder=base/'corpus-01'
(folder/'entry-binding.json').write_text(json.dumps(dict(pid=os.getpid(),invocation=os.environ['INVOCATION_ID'],cgroup=Path('/proc/self/cgroup').read_text().strip()),indent=2)+chr(10))
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
name='conflux-winterreise-publisher-global-corpus-20261029-01';label='winterreise-publisher-global-corpus-20261029-01'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
def interrupted(number,frame):raise InterruptedError('Owned CPU music capture stopped')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
decode=Path('/srv/conflux-tests/work/fmak-independent-preparation-20261029-02')
assets=json.loads((folder/'operations/asset-manifest.json').read_text())['container_asset_root']
command=D+['run','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL',
 '--security-opt=no-new-privileges:true','--user=1000:1000','--memory=3g','--cpus=1','--pids-limit=128',
 '--env','CONFLUX_PRIVATE_KEYCNN=1','--env','PYTHONDONTWRITEBYTECODE=1',
 '--label','org.kyaulabs.conflux.run='+label,'--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777',
 '--mount','type=bind,src='+'/srv/conflux-tests/work/fmak-independent-keycnn-20261029-01/assets'+',dst='+assets+',readonly',
 '--mount','type=bind,src='+str(folder/'operations')+',dst=/operations,readonly',
 '--mount','type=bind,src='+str(folder/'output-01')+',dst=/operations/output-01',
 '--mount','type=bind,src='+str(decode/'media')+',dst=/media,readonly',
 '--mount','type=bind,src='+str(decode/'native/prepare-independent-source')+',dst=/prepare/prepare-independent-source,readonly',
 image,'python','-B','/operations/run_corpus.py','--owned','--plan','/operations/music-plan-01.json','--output','/operations/output-01']
first=time.monotonic();result=None;error=None
try:result=subprocess.run(command,timeout=3920)
except BaseException as exception:error=dict(type=type(exception).__name__,message=str(exception)[:1000])
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  value=json.loads(found.stdout)[0]
  assert value['Image']==image and value['Config']['Labels']['org.kyaulabs.conflux.run']==label
  subprocess.run(D+['rm','--force',value['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
 (folder/'container-closed.json').write_text(json.dumps(dict(container_absent=True,exit=None if result is None else result.returncode,error=error,elapsed_seconds=time.monotonic()-first),indent=2)+chr(10))
raise SystemExit(0 if result is not None and result.returncode==0 and error is None else 1)
