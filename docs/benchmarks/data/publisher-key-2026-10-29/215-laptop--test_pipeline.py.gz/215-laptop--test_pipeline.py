"""Generated streaming/ownership regressions; no music or learned model."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import aggregate
import protocol
import run_corpus as runner


class PipelineChecks(unittest.TestCase):
    def fixture(self):
        frames=48000;raw=bytes(frames*8);digest=hashlib.sha256(raw).hexdigest()
        case=dict(id='000001',prepared_frames=frames,pcm_sha256=digest,source=dict(bytes=128,sha256='a'*64))
        source=dict(schema=1,case=case['id'],complete=True,audio_device_opened=False,
            source_bytes=128,source_sha256='a'*64,prepared_frames=frames,prepared_pcm_sha256=digest,sample_rate=48000,channels=2)
        _,columns,count=protocol.geometry(frames)
        rows=[dict(index=index,probabilities=[1/24]*24,signal_nonzero=True)for index in range(count)]
        windows=protocol.contexts(frames,rows)
        value=dict(schema=1,recipe=protocol.RECIPE,model_sha256=protocol.MODEL_SHA,
            frames=frames,sample_rate=48000,channels=2,pcm_sha256=digest,CQT_columns=columns,
            raw_predictions=rows,contexts=windows,global_only=True,local_key_map_emitted=False,publisher_global=dict(predicted_class=0,mean_probabilities=[1/24]*24,mean_dtype='float32'),window_count=len(windows),confidence='Unknown',
            qualified=False,audio_device_opened=False,GPU_started=False)
        return case,source,value,raw

    def actual_pipe(self,failure=False,timeout=False):
        case,metadata,prediction,raw=self.fixture()
        with tempfile.TemporaryDirectory()as temporary:
            root=Path(temporary);output=root/'output';output.mkdir()
            producer=root/'producer.py';consumer=root/'consumer.py'
            producer.write_text('import sys,time\n'+('time.sleep(30)\n'if timeout else'')+
                'sys.stderr.write('+repr(json.dumps(metadata))+')\n'+
                'sys.stdout.buffer.write(bytes('+str(len(raw))+'))\n'+('raise SystemExit(1)\n'if failure else''))
            consumer.write_text('import sys,hashlib\nraw=sys.stdin.buffer.read()\nassert len(raw)=='+str(len(raw))+
                '\nassert hashlib.sha256(raw).hexdigest()=='+repr(case['pcm_sha256'])+
                '\nprint('+repr(json.dumps(prediction))+')\n')
            plan=dict(preparer=dict(path=str(producer)),python=sys.executable,worker=str(consumer))
            children=[];original=runner.subprocess.Popen
            def start(command,**kwargs):
                if command[0]==str(producer):command=[sys.executable,*command]
                child=original(command,**kwargs);children.append(child);return child
            with patch.object(runner.subprocess,'Popen',side_effect=start):
                if timeout:
                    with patch.object(runner.time,'monotonic',side_effect=[0,161]),self.assertRaises(TimeoutError):
                        runner.predict(plan,case,output)
                elif failure:
                    with self.assertRaisesRegex(ValueError,'Preparation or model worker failed'):
                        runner.predict(plan,case,output)
                else:
                    result=runner.predict(plan,case,output)
                    self.assertEqual(result['predicted_class'],0)
                    self.assertTrue(result['producer_reaped']and result['consumer_reaped']and result['spool_empty'])
            self.assertEqual(len(children),2)
            self.assertTrue(all(child.poll()is not None for child in children))

    def test_complete_stream_is_bound_and_both_children_reaped(self):self.actual_pipe()
    def test_failed_producer_cannot_become_an_estimate(self):self.actual_pipe(failure=True)
    def test_timeout_reaps_the_owned_pipeline(self):self.actual_pipe(timeout=True)

    def test_aggregate_function_matches_the_frozen_scorer(self):
        import inspect
        import score_global
        self.assertEqual(ast.dump(ast.parse(inspect.getsource(aggregate.global_class))),
            ast.dump(ast.parse(inspect.getsource(score_global.global_class))))

    def test_duplicate_or_nonfinite_json_is_not_a_capture(self):
        for raw in('{"frames":1,"frames":2}','{"value":NaN}','{"value":Infinity}'):
            with self.assertRaises(ValueError):runner.strict_json(raw)


if __name__=='__main__':unittest.main(verbosity=2)
