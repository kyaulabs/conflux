"""Stop the real corpus function with generated child objects; no processes launched."""
import io
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import run_fmak


class StopChecks(unittest.TestCase):
    def test_preexisting_stop_prevents_opening_source_or_starting_children(self):
        with patch.object(run_fmak,'STOP',SimpleNamespace(exists=lambda:True)), \
                patch.object(run_fmak.subprocess,'Popen') as launch:
            with self.assertRaises(InterruptedError):
                run_fmak.predict_case({},dict(id='generated'))
            launch.assert_not_called()

    def test_mid_case_stop_reaps_both_children_and_removes_empty_private_spool(self):
        children=[]
        class Child:
            def __init__(self):
                self.pid=990000+len(children);self.stdout=io.BytesIO();self.reaped=False
                children.append(self)
            def poll(self):return -9 if self.reaped else None
            def wait(self,timeout=None):self.reaped=True;return -9
        states=iter([False,True])
        with tempfile.TemporaryDirectory() as directory:
            output=Path(directory)
            with patch.object(run_fmak,'OUTPUT',output), \
                    patch.object(run_fmak,'STOP',SimpleNamespace(exists=lambda:next(states))), \
                    patch.object(run_fmak.subprocess,'Popen',side_effect=lambda *a,**k:Child()) as launch, \
                    patch.object(run_fmak.os,'killpg') as signal:
                with self.assertRaises(InterruptedError):
                    run_fmak.predict_case(dict(preparer=dict(path='/offline/native'),worker=dict(path='/offline/model')),
                        dict(id='generated',prepared_frames=48000))
            self.assertEqual(launch.call_count,2)
            self.assertEqual(signal.call_count,2)
            self.assertTrue(all(child.reaped for child in children))
            self.assertFalse((output/'spool-generated').exists())
            self.assertEqual({p.name for p in output.iterdir()},
                {'generated-source.json','generated-prediction.json','generated-worker.stderr'})


if __name__=='__main__':unittest.main()
