"""Archive this fixed diagnostic's text evidence; omit media, weights and binaries."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import gzip
import hashlib
import json
import math

BASE = Path(__file__).resolve().parent
WORK = Path('/home/kyau/.codex/worktrees/release-tree-guard/conflux')
DEST = WORK/'docs/benchmarks/data/m2-key-global-window-2026-10-27'
PLAIN = BASE/'uncompressed-review-01'


def digest(value):
    return hashlib.sha256(value).hexdigest()


def finite(value):
    if isinstance(value,float):
        assert math.isfinite(value)
    elif isinstance(value,list):
        for item in value:finite(item)
    elif isinstance(value,dict):
        for item in value.values():finite(item)


def main():
    completed=json.loads((BASE/'root-finished-01.json').read_text())
    assert completed['cleanup_complete'] and completed['frozen_inputs_unchanged']
    assert completed['within_original_2820_seconds'] and not completed['errors']
    assert completed['inference_pipeline_pass']
    assert (BASE/'post-close-verification-01.json').is_file()
    paths=[p for p in BASE.iterdir() if p.is_file() and p.suffix in ('.py','.json','.log')]
    paths += [p for p in (BASE/'output-01').iterdir()
              if p.is_file() and p.suffix in ('.json','.stderr')]
    external={
        Path('/home/kyau/projects/kyaulabs/conflux/build/m2-key-global-window-audit-01/audit_windows.py'):'window-audit/audit_windows.py',
        Path('/home/kyau/projects/kyaulabs/conflux/build/m2-key-global-window-audit-01/result-01.json'):'window-audit/result-01.json',
        Path('/home/kyau/projects/kyaulabs/conflux/build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/source/keycnn/feature.py'):'publisher/feature.py',
        Path('/home/kyau/projects/kyaulabs/conflux/build/m2-deepspec-assessment-01/LICENSE'):'publisher/LICENSE',
        Path('/home/kyau/projects/kyaulabs/conflux/build/m2-deepspec-assessment-01/fmak-01/output-01/scores.json'):'baseline-deepspec-local-scores.json',
        Path('/home/kyau/projects/kyaulabs/conflux/build/m2-fmak-assessment-01/source-admission-01/selection-plan-02.json'):'reference/selection-plan-02.json',
    }
    paths += list(external)
    paths=sorted(set(paths))
    DEST.mkdir()
    PLAIN.mkdir(mode=0o700)
    rows=[]
    for index,path in enumerate(paths):
        raw=path.read_bytes()
        assert len(raw)<=5242880
        text=raw.decode('utf-8')
        if path.suffix=='.json':finite(json.loads(text))
        if path.suffix=='.py':ast.parse(text)
        relative=str(path.relative_to(BASE)) if BASE in path.parents else external[path]
        label='%03d-%s'%(index,relative.replace('/','--'))
        (PLAIN/label).write_bytes(raw)
        encoded=gzip.compress(raw,compresslevel=9,mtime=0)
        assert gzip.decompress(encoded)==raw
        destination=DEST/(label+'.gz')
        with destination.open('xb') as stream:stream.write(encoded)
        rows.append({'origin':str(path),'relative_origin':relative,'file':destination.name,
                     'raw_bytes':len(raw),'raw_sha256':digest(raw),
                     'gzip_bytes':len(encoded),'gzip_sha256':digest(encoded)})
    manifest={'schema':1,'utc':datetime.now(timezone.utc).isoformat(),'files':rows,
              'archive_count':len(rows),'compressed_bytes':sum(r['gzip_bytes'] for r in rows),
              'scope':'UTF-8 text evidence only; no audio, PCM, CQT tensors, numeric weights, model containers or executables',
              'candidate_enabled':False,'latency_qualified':False,'training_independence_verified':False}
    with (DEST/'manifest.json').open('x') as stream:
        json.dump(manifest,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'archives':len(rows),'compressed_bytes':manifest['compressed_bytes'],
                      'plaintext_review':str(PLAIN),'destination':str(DEST)}))


if __name__=='__main__':main()
