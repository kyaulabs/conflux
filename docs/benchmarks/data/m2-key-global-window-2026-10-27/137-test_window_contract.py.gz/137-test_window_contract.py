"""Generated marker and invalid packet checks; no source media or model execution."""
import copy
import importlib.util
from pathlib import Path
import unittest
import numpy as np

import protocol
from publisher_windows import global_windows

ROOT=Path('/home/kyau/projects/kyaulabs/conflux')


class WindowContractChecks(unittest.TestCase):
    def test_published_source_helpers_match_independent_scalar_markers(self):
        path=ROOT/'build/m2-key-global-window-audit-01/audit_windows.py'
        spec=importlib.util.spec_from_file_location('independent_global_window_oracle',path)
        audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
        for columns in [1,29,59,60,61,89,90,91,119,120,121,200,3764]:
            data=(np.arange(168,dtype=np.float32)[:,None]*10000+
                np.arange(columns,dtype=np.float32)[None,:]+1)
            with self.subTest(columns=columns):
                expected,_=audit.scalar_windows(data,30,False)
                self.assertTrue(np.array_equal(global_windows(data),expected))

    def test_cqt_geometry_dtype_nonfinite_and_negative_data_fail_closed(self):
        cases=[np.zeros((168,0),dtype=np.float32),np.zeros((168,3765),dtype=np.float32),
            np.zeros((167,60),dtype=np.float32),np.zeros((168,60),dtype=np.float16),
            np.full((168,60),np.nan,dtype=np.float32),np.full((168,60),-1,dtype=np.float32)]
        for data in cases:
            with self.subTest(shape=data.shape,dtype=str(data.dtype)),self.assertRaises(ValueError):
                global_windows(data)

    def test_legacy_float64_values_are_preserved_without_narrowing(self):
        data=np.arange(168*121,dtype=np.float64).reshape(168,121)/10+.000000123
        actual=global_windows(data)
        starts=range(0,121-59,30)
        expected=np.asarray([[[[float(data[row,first+offset])] for offset in range(60)]
            for row in range(168)] for first in starts],dtype=np.float64)
        self.assertEqual(actual.dtype,np.dtype('float64'))
        self.assertTrue(np.array_equal(actual,expected))

    def fixture(self):
        frames=48000*30;_,columns,count=protocol.geometry(frames)
        case=dict(id='generated',prepared_frames=frames,pcm_sha256='b'*64,
            source=dict(bytes=8,sha256='a'*64))
        rows=[dict(index=i,probabilities=[1.]+[0.]*23,signal_nonzero=True) for i in range(count)]
        value=dict(schema=1,recipe=protocol.RECIPE,model_sha256=protocol.MODEL_SHA,
            frames=frames,sample_rate=48000,channels=2,pcm_sha256='b'*64,CQT_columns=columns,
            raw_predictions=rows,window_count=count,contexts=protocol.contexts(frames,rows),
            global_only=True,local_key_map_emitted=False,confidence='Unknown',qualified=False,
            audio_device_opened=False,GPU_started=False)
        return value,case

    def test_complete_hop8_population_is_rejected_by_global_contract(self):
        value,case=self.fixture()
        count=protocol.clock.geometry(case['prepared_frames'])[2]
        self.assertNotEqual(count,value['window_count'])
        row=value['raw_predictions'][0]
        value['raw_predictions']=[{**row,'index':i} for i in range(count)]
        with self.assertRaisesRegex(ValueError,'Global prediction population differs'):
            protocol.validate_prediction(value,None,case)

    def test_wrong_context_bounds_missing_rows_and_local_map_claim_are_rejected(self):
        good,case=self.fixture()
        for label in ['bounds','missing','local','recipe']:
            value=copy.deepcopy(good)
            if label=='bounds':value['contexts'][-1]['end_CQT_column']+=1
            elif label=='missing':value['raw_predictions'].pop()
            elif label=='local':value['windows']=[]
            else:value['recipe']='private-keycnn-deepspec-k16-legacycqt-hop8-v1'
            with self.subTest(label=label),self.assertRaises(ValueError):
                protocol.validate_prediction(value,None,case)

    def test_short_context_padding_is_explicit_and_long_track_tail_is_not_fabricated(self):
        for frames in [48000,48000*30,33554432]:
            _,columns,count=protocol.geometry(frames)
            rows=[dict(index=i,probabilities=[1.]+[0.]*23,signal_nonzero=True) for i in range(count)]
            contexts=protocol.contexts(frames,rows)
            self.assertEqual(contexts[-1]['end_CQT_column'],(count-1)*30+60)
            self.assertEqual(contexts[0]['right_zero_padding_columns'],max(0,60-columns))
            if columns>=60:self.assertLessEqual(contexts[-1]['end_CQT_column'],columns)


if __name__=='__main__':unittest.main()
