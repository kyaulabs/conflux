"""Write measured comparison prose only after independent closure verification."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json

BASE=Path(__file__).resolve().parent
WORK=Path('/home/kyau/.codex/worktrees/release-tree-guard/conflux')


def main():
    paired=json.loads((BASE/'paired-comparison-01.json').read_text())
    proof=json.loads((BASE/'post-close-verification-01.json').read_text())
    root=json.loads((BASE/'root-finished-01.json').read_text())
    assert proof['all_owned_resources_closed'] and root['inference_pipeline_pass']
    before=paired['baseline_inferred'];after=paired['candidate_inferred']
    selected=paired['candidate_selected']
    assert before['denominator']==after['denominator']==21
    same=after['matches']==before['matches']
    result=('did not improve the exact-match count' if same else
        ('improved' if after['matches']>before['matches'] else 'reduced')+' the exact-match count')
    text=f'''# Global-key window comparison

Using the publisher's global-window defaults **{result}** on the retained
FMAK sample: **{after['matches']}/21 ({after['percent']:.2f}%)** inferred tracks,
compared with **{before['matches']}/21 ({before['percent']:.2f}%)** using local-keygram sampling.
Including the three retained decoder failures gives **{selected['matches']}/24
({selected['percent']:.2f}%)**. This is the same previously exposed sample;
it does not establish fresh held-out accuracy or calibrated confidence.
The production key backend remains disabled.

| Setting | Retained baseline | Candidate |
| --- | --- | --- |
| Numeric model | DeepSpec k16 | Same pinned model and weights |
| Context length | 60 CQT columns | 60 CQT columns |
| Context hop | 8 columns | 30 columns |
| Boundary padding | 30 columns at each end | Right padding only for inputs shorter than 60 columns |
| Total classified contexts | {paired['baseline_contexts']:,} | {paired['candidate_contexts']:,} |
| Exact matches on inferred tracks | {before['matches']}/21 | {after['matches']}/21 |

The native prepared PCM, source identities, legacy CQT, whole-population
float64 whitening, float16 conversion, numeric forward path and arithmetic-mean
posterior rule are unchanged. Window selection is the sole experimental
change; its altered population also changes the normalization statistics.
Legacy float64 CQT values are retained without narrowing. No hop, padding,
class mapping or reference label was tuned after viewing candidate predictions.

All 21 inferable tracks completed. The original failures `003853`, `005153`
and `061480` were neither converted nor replaced. All 24 captures closed
before the reference mapping was read for scoring. The paired comparison
repaired **{paired['newly_correct']}** tracks and regressed **{paired['newly_incorrect']}**;
**{paired['both_correct']}** were correct in both runs.

Fourteen generated CQT geometries matched the pinned publisher helpers and
an independent marker oracle. Sixteen functional checks cover complete score
denominators, capture and model identity, malformed probabilities, source
context bounds, legacy precision and stop/reap behavior. This global-only
packet rejects the local-keygram population and does not emit a local key map.
The earlier [numeric-model checks](deepspec-fmak-2026-10-27.md) remain the
operator reference; the original TensorFlow execution environment was not reproduced.

The [2019 paper](https://www.audiolabs-erlangen.de/content/05_fau/professor/00_mueller/03_publications/2019_SchreiberM_TempoKeyCNN_SMC.pdf)
evaluates whole spectrograms. This run tests the separate packaged API's
window defaults on CONFLUX-prepared PCM. Exact training membership of the released weights
remains unverified. Song-level FMAK references do not qualify local key changes.

The CPU-only run closed after **{root['elapsed_seconds']:.3f} seconds** within
its original 2,820-second bound. All **{proof['frozen_input_count']} frozen inputs**
still matched. The owned unit/cgroup, both children per inferred case and
private preparation spools are closed. The existing thermal guard and 15 W
ceiling remained in force. The diagnostic made no profile, cap or guard writes. This was an accuracy
diagnostic without player, GPU inference or audio output, and it consumed no
physical-test readiness.

The [text-evidence manifest](data/m2-key-global-window-2026-10-27/manifest.json)
retains the frozen recipe, generated checks, every capture, source failures,
paired scores and closure proofs. It omits audio, PCM, CQT tensors, weights,
model containers and executables. M2/M3, live-stem cancellation, the actual-player
soak and the unchanged **4.095-second p99** target remain open.
'''
    path=WORK/'docs/benchmarks/key-global-windows-2026-10-27.md'
    with path.open('x') as stream:stream.write(text)
    journal=WORK/'docs/M2.md';prefix=journal.read_bytes()
    appendix=f'''

The [fixed-model global-window comparison](benchmarks/key-global-windows-2026-10-27.md)
{result}: {after['matches']}/21 inferred FMAK tracks versus {before['matches']}/21,
or {selected['matches']}/24 with the original decoder failures retained. Only
window selection changed from padded hop-eight contexts to the publisher API's
global defaults. All 21 inferable sources completed; all 24 captures closed
before scoring, and all {proof['frozen_input_count']} frozen inputs matched after cleanup.
This reused exposed sample does not establish held-out, calibrated or local-key
accuracy. The production key backend stays disabled; M2/M3 and release gates
remain unchanged.
'''
    journal.write_bytes(prefix+appendix.encode())
    assert journal.read_bytes().startswith(prefix)
    receipt=dict(utc=datetime.now(timezone.utc).isoformat(),report=str(path),
        report_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        M2_prefix_sha256=hashlib.sha256(prefix).hexdigest(),M2_prefix_bytes=len(prefix),
        M2_prefix_preserved=True,production_changed=False,key_backend_enabled=False,
        M2_M3_or_release_qualified=False)
    with (BASE/'documentation-01.json').open('x') as stream:
        stream.write(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))


if __name__=='__main__':main()
