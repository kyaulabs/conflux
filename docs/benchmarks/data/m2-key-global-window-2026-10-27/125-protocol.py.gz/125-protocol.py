"""Fixed global-window correctness diagnostic; no local key map or hardware API."""
import hashlib
import importlib.util
import math
from pathlib import Path

ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
DATA=ROOT/'build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/model-data-audit-01'
CLOCK_PATH=DATA/'feature-compatibility-01/source-clock-01/source_clock.py'
spec=importlib.util.spec_from_file_location('fixed_global_diagnostic_clock',CLOCK_PATH)
clock=importlib.util.module_from_spec(spec);spec.loader.exec_module(clock)
RECIPE='private-keycnn-deepspec-k16-legacycqt-publisher-global-hop30-v1'
MODEL_SHA='0a99c26b7d8a4f7123b3cdade75c7986ef686d6805378c43cada874497f53f9a'


def require(condition,message):
    if not condition:raise ValueError(message)


def geometry(frames):
    samples,columns,_=clock.geometry(frames)
    count=max(1,(columns-60)//30+1)
    require(1<=count<=124,'Global window count exceeds frozen native source limit')
    return samples,columns,count


def read_pcm(stream,frames,expected_sha):
    geometry(frames)
    require(type(expected_sha) is str and len(expected_sha)==64 and
        all(c in '0123456789abcdef' for c in expected_sha),'Invalid PCM digest')
    raw=stream.read(frames*8+1)
    require(len(raw)==frames*8,'Prepared PCM extent differs')
    require(hashlib.sha256(raw).hexdigest()==expected_sha,'Prepared PCM digest differs')
    return raw


def contexts(frames,rows):
    _,columns,count=geometry(frames)
    require(type(rows) is list and len(rows)==count,'Global prediction population differs')
    result=[]
    for index,row in enumerate(rows):
        require(type(row) is dict and set(row)=={'index','probabilities','signal_nonzero'},'Raw row schema differs')
        require(type(row['index']) is int and row['index']==index and type(row['signal_nonzero']) is bool,
            'Raw row identity/types differ')
        values=row['probabilities']
        require(type(values) is list and len(values)==24,'Expected 24 class probabilities')
        require(all(type(v) is float and math.isfinite(v) and 0<=v<=1 for v in values),'Invalid class probability')
        require(abs(sum(values)-1.)<=2e-6,'Unnormalized class probabilities')
        result.append(dict(index=index,first_CQT_column=index*30,end_CQT_column=index*30+60,
            right_zero_padding_columns=max(0,index*30+60-columns)))
    return result


def validate_prediction(value,metadata,case):
    frames=case['prepared_frames']
    require(type(value) is dict and type(value['schema']) is int and value['schema']==1,'Invalid result schema')
    require(value['recipe']==RECIPE and value['model_sha256']==MODEL_SHA,'Recipe/model identity differs')
    for name,expected in [('frames',frames),('sample_rate',48000),('channels',2)]:
        require(type(value[name]) is int and value[name]==expected,'Prediction source clock differs')
    require(value['pcm_sha256']==case['pcm_sha256'],'Prediction PCM identity differs')
    require(type(value['CQT_columns']) is int and value['CQT_columns']==geometry(frames)[1],'CQT header geometry differs')
    require(value['qualified'] is False and value['audio_device_opened'] is False
        and value['GPU_started'] is False and value['confidence']=='Unknown','Unqualified scope differs')
    require(value['global_only'] is True and 'windows' not in value and
        value['local_key_map_emitted'] is False,'Global diagnostic cannot emit a local key map')
    expected=contexts(frames,value['raw_predictions'])
    require(value['contexts']==expected,'Global context geometry differs')
    require(type(value['window_count']) is int and value['window_count']==len(expected),'Global count differs')
    if metadata is not None:
        require(metadata['complete'] is True and metadata['case']==case['id'],'Preparation did not complete')
        for name,expected_value in [('source_bytes',case['source']['bytes']),('prepared_frames',frames),
                ('sample_rate',48000),('channels',2)]:
            require(type(metadata[name]) is int and metadata[name]==expected_value,'Preparation metadata differs')
        require(metadata['source_sha256']==case['source']['sha256'] and
            metadata['prepared_pcm_sha256']==case['pcm_sha256'] and metadata['audio_device_opened'] is False,
            'Prepared source identity differs')
    return expected
