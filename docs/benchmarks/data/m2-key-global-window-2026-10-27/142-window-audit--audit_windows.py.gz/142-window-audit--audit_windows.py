"""Execute only pinned publisher window helpers on generated CQT markers; no audio/model."""
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import inspect
import json
import math
import os
from pathlib import Path
import time
from types import SimpleNamespace

for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[name]='1'
import numpy as np

ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
BASE=Path(__file__).resolve().parent
AUDIT=ROOT/'build/m2-keyfinder-assessment-01/key-cnn-source-audit-01'
FEATURE=AUDIT/'source/keycnn/feature.py'
FEATURE_SHA='3b6c72840fb6680b0f171ae9f6e2fda09a839615903c7768828e49e174f72ffc'
PRIOR=ROOT/'build/m2-deepspec-assessment-01/fmak-01/music-plan-01.json'
CLOCK=AUDIT/'model-data-audit-01/feature-compatibility-01/source-clock-01/source_clock.py'


def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def scalar_windows(matrix,hop,zero_pad):
    """Independent scalar ownership oracle; no publisher padding/window helpers."""
    bins,columns=matrix.shape
    effective=max(60,columns+(60 if zero_pad else 0))
    starts=list(range(0,effective-59,hop))
    result=np.empty((len(starts),bins,60,1),dtype=np.float32)
    for window,first in enumerate(starts):
        for offset in range(60):
            source=first+offset-(30 if zero_pad else 0)
            result[window,:,offset,0]=matrix[:,source] if 0<=source<columns else 0
    return result,starts


def main():
    began=time.monotonic()
    assert pin(FEATURE)['sha256']==FEATURE_SHA
    source_audit=json.loads((AUDIT/'audit-01.json').read_text())
    assert source_audit['source_commit']=='9715d6f443c0f01d9842e567a3f20c9b228c3c7f'
    original=ast.parse(FEATURE.read_text())
    names={'read_features','_ensure_length','_add_zeros','_to_sliding_window'}
    selected=[node for node in original.body if isinstance(node,ast.FunctionDef) and node.name in names]
    assert {node.name for node in selected}==names
    state={}
    def load(file,sr):
        assert file=='generated-marker-fixture' and sr==22050
        return np.zeros(128,dtype=np.float32),22050
    def cqt(y,**kwargs):
        assert len(y)==128 and kwargs==dict(sr=22050,hop_length=4096,
            fmin=41.20344461410875,n_bins=168,bins_per_octave=24)
        state['calls']+=1
        return state['matrix'].astype(np.complex64)
    def note(note):
        assert note=='E1'
        return 41.20344461410875
    namespace={'np':np,'librosa':SimpleNamespace(load=load,cqt=cqt,note_to_hz=note)}
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(FEATURE),'exec'),namespace)
    reader=namespace['read_features']
    signature=inspect.signature(reader)
    assert signature.parameters['frames'].default==60
    assert signature.parameters['hop_length'].default==30
    assert signature.parameters['zero_pad'].default is False
    before=[pin(p) for p in (FEATURE,PRIOR,CLOCK,Path(__file__))]
    generated=[]
    for columns in [0,1,29,59,60,61,89,90,91,119,120,121,200,3764]:
        matrix=(np.arange(168,dtype=np.float32)[:,None]*10000+
            np.arange(columns,dtype=np.float32)[None,:]+1)
        state.update(matrix=matrix,calls=0)
        publisher=reader('generated-marker-fixture')
        expected,starts=scalar_windows(matrix,30,False)
        assert np.array_equal(publisher,expected)
        local=reader('generated-marker-fixture',hop_length=8,zero_pad=True)
        local_expected,local_starts=scalar_windows(matrix,8,True)
        assert np.array_equal(local,local_expected)
        padded=np.pad(matrix,((0,0),(30,30)))
        worker_layout=np.stack([padded[:,first:first+60,None]
            for first in range(0,columns+1,8)])
        assert np.array_equal(local,worker_layout)
        assert state['calls']==2
        generated.append(dict(columns=columns,publisher_window_count=len(publisher),
            local_window_count=len(local),publisher_first_source_column=0,
            publisher_last_start_column=starts[-1],publisher_uncovered_tail_columns=max(0,columns-(starts[-1]+60)),
            padded_local_first_center_column=local_starts[0],
            padded_local_last_center_column=local_starts[-1],all_marker_samples_equal=True))
    spec=importlib.util.spec_from_file_location('fixed_source_clock_window_audit',CLOCK)
    clock=importlib.util.module_from_spec(spec);spec.loader.exec_module(clock)
    plan=json.loads(PRIOR.read_text())
    corpus=[]
    for case in plan['cases']:
        if case['preparation_status']!='PreparedMetadataMeasured':
            corpus.append(dict(id=case['id'],status=case['preparation_status'],window_comparison_applicable=False))
            continue
        samples,columns,local_count=clock.geometry(case['prepared_frames'])
        global_count=max(1,(columns-60)//30+1)
        last_start=(global_count-1)*30
        corpus.append(dict(id=case['id'],window_comparison_applicable=True,prepared_frames=case['prepared_frames'],
            CQT_columns=columns,current_padded_hop8_windows=local_count,publisher_global_hop30_windows=global_count,
            publisher_uncovered_tail_columns=max(0,columns-(last_start+60))))
    assert len(corpus)==24 and sum(c['window_comparison_applicable'] for c in corpus)==21
    assert before==[pin(Path(p['path'])) for p in before]
    result=dict(schema=1,utc=datetime.now(timezone.utc).isoformat(),
        source_commit=source_audit['source_commit'],source_pins=before,
        generated_geometries=len(generated),generated=generated,corpus_geometry=corpus,
        publisher_windowing_reproduced_exactly_on_generated_markers=True,
        existing_local_worker_matches_padded_publisher_mode=True,
        existing_local_context_and_global_default_are_different_populations=True,
        previous_scores_invalidated=False,
        scope='Window-helper fidelity and source-frame geometry only. Legacy audio features, classifier inference, accuracy and production configuration are unchanged. Neither recipe is promoted by this audit.',
        next_controlled_question='With the same DeepSpec model and retained 24-source sample, does the fixed publisher global-window recipe change the global score? Keep all source failures and freeze every prediction before scoring; do not tune hops, padding or labels.',
        input_pins_unchanged=True,model_started=False,audio_opened=False,GPU_started=False,
        production_changed=False,latency_or_musical_quality_qualified=False,
        elapsed_seconds=time.monotonic()-began)
    with (BASE/'result-01.json').open('x') as stream:
        stream.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:result[key] for key in ('generated_geometries',
        'publisher_windowing_reproduced_exactly_on_generated_markers',
        'existing_local_worker_matches_padded_publisher_mode','model_started','elapsed_seconds')}))


if __name__=='__main__':main()
