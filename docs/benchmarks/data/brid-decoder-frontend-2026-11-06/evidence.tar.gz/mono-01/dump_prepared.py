"""Private native-preparation transport only; returns Unknown and never loads a model."""
from pathlib import Path
import sys,os,json,hashlib,argparse,importlib.util,stat
B=Path(__file__).resolve().parent
PRODUCTION_SHA='e76b8ab903aebc76a592ac262b1dd3c7602cdea0606610e866cca31156d753b5'

def main():
 p=argparse.ArgumentParser();p.add_argument('--source-dir',required=True);p.add_argument('--model',required=True);p.add_argument('--frames',required=True,type=int);args=p.parse_args()
 if not 0<args.frames<=60*48000+4096:raise ValueError('Export extent exceeds fixed corpus bound')
 case=int(os.environ['CONFLUX_CAPTURE_CASE_ID']);root=Path(os.environ['CONFLUX_PCM_EXPORT_ROOT'])
 if not 1<=case<=93 or not root.is_absolute()or root.resolve()!=root or not root.is_dir()or root.is_symlink():raise ValueError('Invalid private export path')
 info=root.stat()
 if info.st_uid!=os.geteuid()or stat.S_IMODE(info.st_mode)&0o077:raise ValueError('Export directory is not owned/private')
 path=B/'production_worker.py';raw=path.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=PRODUCTION_SHA:raise ValueError('Pinned transport helper differs')
 spec=importlib.util.spec_from_file_location('pinned_export_helper',path);worker=importlib.util.module_from_spec(spec);spec.loader.exec_module(worker)
 pcm=worker.read_pcm(sys.stdin.buffer,args.frames);sha=hashlib.sha256(pcm).hexdigest();created=[]
 try:
  output=root/f'{case:04d}.f32'
  with output.open('xb')as f:created.append(output);f.write(pcm);f.flush();os.fsync(f.fileno())
  metadata={'schema':1,'kind':'native_prepared_PCM_export_only','case_id':case,'frames':args.frames,'bytes':len(pcm),'pcm_sha256':sha,'model_loaded':False,'analysis_performed':False,'transport_response':'Unknown; no inferred beats'}
  output=root/f'{case:04d}.json'
  with output.open('x')as f:created.append(output);json.dump(metadata,f,indent=2);f.write('\n')
  result=worker.encode_result(args.frames,sha,None,[],[]);sys.stdout.buffer.write(result);sys.stdout.buffer.flush()
 except BaseException:
  for path in created:path.unlink()
  raise
if __name__=='__main__':main()
