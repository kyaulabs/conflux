"""Private observational logits capture; invokes the pinned production worker unchanged."""
from pathlib import Path
import argparse,hashlib,json,importlib.util,sys,os
B=Path(__file__).resolve().parent
WORKER_SHA='7ba774aa27521ddcf9b0c11bfd7292d2ace6d6d823b28245d01e4f55b9fbcae8'

def load_production():
 path=B/'candidate_worker.py';raw=path.read_bytes()
 assert hashlib.sha256(raw).hexdigest()==WORKER_SHA
 spec=importlib.util.spec_from_file_location('pinned_production_bpm',path)
 worker=importlib.util.module_from_spec(spec);spec.loader.exec_module(worker);return worker

def capture_class(original,context,output):
 class Observed(original):
  def __call__(self,beat,downbeat,padding_mask=None):
   import numpy as np,torch
   assert self.type=='minimal' and self.fps==50 and context.get('calls',0)==0
   assert context['frames']>0 and len(context['pcm_sha256'])==64
   assert all(x.ndim==1 and x.dtype==torch.float32 and x.device.type=='cpu' and torch.isfinite(x).all().item() for x in (beat,downbeat))
   assert beat.shape==downbeat.shape and 0<len(beat)<=3002
   assert padding_mask is not None and padding_mask.dtype==torch.bool and padding_mask.shape==beat.shape
   arrays={'beat':beat.detach().numpy().copy(),'downbeat':downbeat.detach().numpy().copy(),'mask':padding_mask.numpy().copy()}
   expected=np.array([k*48000<context['frames']*50 for k in range(len(beat))],dtype=np.bool_)
   assert np.array_equal(arrays['mask'],expected)
   assert all(x.dtype==np.dtype('<f4') for x in (arrays['beat'],arrays['downbeat']))
   result=super().__call__(beat,downbeat,padding_mask)
   assert np.array_equal(arrays['beat'],beat.numpy()) and np.array_equal(arrays['downbeat'],downbeat.numpy()) and np.array_equal(arrays['mask'],padding_mask.numpy())
   with output.open('xb') as f:np.savez(f,**arrays)
   assert output.stat().st_size<65536
   context.update(calls=1,logit_frames=len(beat),mask_true_count=int(expected.sum()),array_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),array_bytes=output.stat().st_size)
   return result
 return Observed

def main():
 p=argparse.ArgumentParser();p.add_argument('--source-dir',required=True);p.add_argument('--model',required=True);p.add_argument('--frames',required=True,type=int);args=p.parse_args()
 case=int(os.environ['CONFLUX_CAPTURE_CASE_ID']);assert 1<=case<=93
 root=Path(os.environ['CONFLUX_LOGIT_CAPTURE_ROOT']);assert root.is_absolute()and root.resolve()==root and root.is_dir()and not root.is_symlink()and root.stat().st_uid==os.geteuid()and(root.stat().st_mode&0o077)==0
 output=root/f'{case:04d}.npz'
 assert output.parent.is_dir() and not output.exists()
 worker=load_production();context={'case_id':case,'frames':args.frames,'calls':0}
 original_read=worker.read_pcm
 def read(stream,frames):
  data=original_read(stream,frames);context['pcm_sha256']=hashlib.sha256(data).hexdigest();return data
 worker.read_pcm=read
 original_load=worker.load_upstream
 def load(source,buffers):
  upstream=original_load(source,buffers);upstream.Postprocessor=capture_class(upstream.Postprocessor,context,output);return upstream
 worker.load_upstream=load
 from contextlib import redirect_stdout
 with redirect_stdout(sys.stderr):result=worker.run(args.source_dir,args.model,args.frames,sys.stdin.buffer)
 assert context['calls']==1
 context.update(analysis_worker_sha256=WORKER_SHA,recipe=worker.RECIPE,variant="upstream_mono_diagnostic",result_sha256=hashlib.sha256(result).hexdigest(),schema=1,qualified=False)
 with output.with_suffix('.json').open('x') as f:json.dump(context,f,indent=2);f.write('\n')
 sys.stdout.buffer.write(result);sys.stdout.buffer.flush()

if __name__=='__main__':main()
