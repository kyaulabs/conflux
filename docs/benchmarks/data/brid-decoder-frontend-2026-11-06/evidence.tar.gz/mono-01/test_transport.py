"""Bounded PCM transport behavior/security checks; no model dependencies."""
from pathlib import Path
import os,sys,subprocess,json,struct,hashlib,shutil
B=Path(__file__).resolve().parent;T=B/'transport-fixture';assert not T.exists();T.mkdir(mode=0o700)
try:
 pcm=b''.join(struct.pack('<ff',i/128,-i/256)for i in range(64));checks=[]
 def run(root,data,identifier=1):
  env=dict(os.environ,CONFLUX_PCM_EXPORT_ROOT=str(root),CONFLUX_CAPTURE_CASE_ID=str(identifier))
  return subprocess.run([sys.executable,'-I','-B',str(B/'dump_prepared.py'),'--source-dir','/unused','--model','/unused','--frames','64'],input=data,capture_output=True,env=env,timeout=5)
 root=T/'ok';root.mkdir(mode=0o700);r=run(root,pcm);assert r.returncode==0,r.stderr
 row=json.loads(r.stdout);meta=json.loads((root/'0001.json').read_text());assert(root/'0001.f32').read_bytes()==pcm and row['bpm']is None and row['beat_count']==0 and row['pcm_sha256']==hashlib.sha256(pcm).hexdigest()and meta['kind']=='native_prepared_PCM_export_only'and not meta['model_loaded']and not meta['analysis_performed'];checks.append('byte_exact_export_with_explicit_Unknown_transport')
 marker=(root/'0001.f32').read_bytes();r=run(root,pcm);assert r.returncode!=0 and not r.stdout and(root/'0001.f32').read_bytes()==marker;checks.append('existing_export_never_overwritten')
 for name,data,identifier in [('short',pcm[:-1],1),('long',pcm+b'x',1),('nonfinite',pcm[:-4]+struct.pack('<f',float('nan')),1),('bad_case',pcm,94)]:
  root=T/name;root.mkdir(mode=0o700);r=run(root,data,identifier);assert r.returncode!=0 and not r.stdout and not list(root.iterdir())
 checks.append('short_extra_nonfinite_and_invalid_case_rejected_without_files')
 root=T/'public';root.mkdir(mode=0o700);root.chmod(0o755);r=run(root,pcm);assert r.returncode!=0 and not list(root.iterdir());checks.append('nonprivate_export_directory_rejected')
 target=T/'private';target.mkdir(mode=0o700);link=T/'link';link.symlink_to(target,target_is_directory=True);r=run(link,pcm);assert r.returncode!=0 and not list(target.iterdir());checks.append('symlink_directory_rejected')
 result={'passed':True,'checks':checks,'model_or_GPU':False};(B/'transport-test-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:shutil.rmtree(T)
