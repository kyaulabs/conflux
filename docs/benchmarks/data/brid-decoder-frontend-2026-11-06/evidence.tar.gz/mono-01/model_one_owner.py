"""Own one short CPU model validation in the dedicated CONFLUX daemon."""
from pathlib import Path
import json,sys,subprocess,hashlib,time,os,signal
B=Path('/srv/conflux-tests/work/mono-frontend-20261106-01');A=Path('/srv/conflux-tests/work/brid-analysis-20261029-01');P=B/'packet';D=['env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock'];NAME='conflux-mono-model-one-20261106-01';LABEL='mono-model-one-20261106-01';IMAGE='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
def main():
 assert sys.argv[1:]==['--run'];checks=json.loads((B/'check-receipt.json').read_text());assert checks['exit']==0 and checks['daemon_healthy']and checks['all_dedicated_containers_absent']
 plan=json.loads((P/'model-one-plan.json').read_text());runtime=json.loads((P/'capture-plan.json').read_text());manifest=json.loads((A/'corpus-02/runtime-manifest-01.json').read_text())
 for pin in plan['program_pins']+plan['model_validation_program_pins']:
  p=P/pin['name'];raw=p.read_bytes();assert len(raw)==pin['bytes']and hashlib.sha256(raw).hexdigest()==pin['sha256']
 q=subprocess.run(D+['ps','-aq'],capture_output=True,text=True,timeout=15);assert q.returncode==0 and not q.stdout.strip();assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}'],timeout=15))=='/srv/conflux-tests/docker-data'
 probe=A/'probe-build-01/output/build/native/brid-production-probe'
 with probe.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==runtime['probe_pin']['sha256']
 W=B/'one-work';assert not W.exists();W.mkdir(mode=0o700);os.chown(W,1000,1000)
 for n in ['tmp','cache','data','state']:
  p=W/n;p.mkdir(mode=0o700);os.chown(p,1000,1000)
 R=A/'runtime-01/assets';cmd=D+['run','--rm','--name',NAME,'--runtime=runc','--init','--network=none','--read-only','--user=1000:1000','--cpus=2','--memory=4g','--memory-swap=4g','--pids-limit=256','--cap-drop=ALL','--security-opt=no-new-privileges:true','--label','org.kyaulabs.conflux.run='+LABEL,'--ulimit','core=0:0','--ulimit','fsize=67108864:67108864','--tmpfs=/tmp:rw,nosuid,nodev,size=32m,mode=1777']
 for src,dst,ro in [(P,'/operations',True),(W,'/work',False),(R,'/assets',True),(R/'venv',manifest['source_venv'],True),(R/'base',manifest['source_base_python'],True),(A/'acquisition-01/media-01','/media',True),(probe.parent,'/probe',True)]:cmd+=['--mount','type=bind,src='+str(src)+',dst='+dst+(',readonly'if ro else'')]
 for k,v in {'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','TMPDIR':'/work/tmp','XDG_CACHE_HOME':'/work/cache','XDG_DATA_HOME':'/work/data','XDG_STATE_HOME':'/work/state'}.items():cmd+=['-e',k+'='+v]
 cmd+=[IMAGE,'timeout','--signal=TERM','--kill-after=8s','145s','python','-B','/operations/run_one.py'];report={'command':cmd,'qualified':False,'model_inference_requested':True,'CPU_only':True};child=None;start=time.monotonic()
 def interrupted(*args):raise InterruptedError('Owned mono model validation interrupted')
 for sig in(signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,interrupted)
 try:
  with(B/'model-one.log').open('x')as log:child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT);report['exit']=child.wait(timeout=165)
 except BaseException as error:report['error']={'type':type(error).__name__,'message':str(error)[:2000]}
 finally:
  q=subprocess.run(D+['inspect',NAME],capture_output=True,text=True,timeout=15)
  if q.returncode==0:
   c=json.loads(q.stdout)[0];assert c['Image']==IMAGE and c['Config']['Labels'].get('org.kyaulabs.conflux.run')==LABEL;subprocess.run(D+['rm','-f',c['Id']],capture_output=True,check=True,timeout=15)
  if child is not None and child.poll()is None:
   child.terminate()
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
  q=subprocess.run(D+['ps','-aq'],capture_output=True,text=True,timeout=15);report.update(daemon_healthy=q.returncode==0,all_dedicated_containers_absent=q.returncode==0 and not q.stdout.strip(),client_reaped=child is None or child.poll()is not None,elapsed_seconds=time.monotonic()-start)
  (B/'model-one-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items()if k!='command'}));sys.exit(0 if report.get('exit')==0 and report['all_dedicated_containers_absent']and report['client_reaped']else 1)
if __name__=='__main__':main()
