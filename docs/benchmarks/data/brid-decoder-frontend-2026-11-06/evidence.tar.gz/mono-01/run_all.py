"""Complete all93 fixed mono predictions; reuse the validated first case, never labels."""
from pathlib import Path
import os,sys,subprocess,signal,time,json,hashlib,shutil
B=Path('/operations');W=Path('/work');P=Path('/pilot');plan=json.loads((B/'capture-plan.json').read_text());assert [c['id']for c in plan['cases']]==list(range(1,94));R=W/'cases';R.mkdir(mode=0o700)
start=time.monotonic();deadline=start+4500;child=None;rows=[];report={'schema':1,'complete':False,'qualified':False,'fixed_denominator':93,'cases':rows,'pilot_case_reused':1,'new_cases_expected':92,'model':'unchanged_Final0_CPU_float32','recipe':'beat-this-final0-upstream-mono-diagnostic-v1','GPU_started':False,'audio_output_started':False,'references_mounted':False}
def interrupted(*args):raise InterruptedError('Owned full mono comparison interrupted')
for sig in(signal.SIGTERM,signal.SIGINT):signal.signal(sig,interrupted)
def verified_case(case,root):
 r=json.loads((root/'case-result.json').read_text());assert r['complete']and r['child_reaped']and r['spool_empty']and r['temporary_pcm_retired']and r['case_id']==case['id']and r['model_inference_completed']
 assert r['recipe']==report['recipe']and r['frames']==case['prepared_frames']and r['input_pcm_sha256']==case['pcm_sha256']
 raw=(root/'candidate.stdout').read_bytes();assert hashlib.sha256(raw).hexdigest()==r['response_sha256'];parts=[json.loads(l)for l in raw.splitlines()];h=parts[0];assert h['recipe']==report['recipe']and h['frames']==case['prepared_frames']and h['pcm_sha256']==case['pcm_sha256']and h['beat_count']==len(parts)-1
 meta=json.loads((root/'captures'/f"{case['id']:04d}.json").read_text());a=(root/'captures'/f"{case['id']:04d}.npz").read_bytes();assert len(a)==meta['array_bytes']and hashlib.sha256(a).hexdigest()==meta['array_sha256']==r['raw_logits_sha256'];assert meta['analysis_worker_sha256']==hashlib.sha256((B/'candidate_worker.py').read_bytes()).hexdigest()
 return {'id':case['id'],'passed':True,'input_pcm_sha256':case['pcm_sha256'],'frames':case['prepared_frames'],'response_sha256':r['response_sha256'],'raw_logits_sha256':r['raw_logits_sha256'],'returned_events':r['returned_events']}
try:
 pilot=json.loads((P/'one-result.json').read_text());assert pilot['complete']and pilot['child_reaped']and pilot['model_inference_completed'];root=R/'0001';root.mkdir(mode=0o700);(root/'captures').mkdir(mode=0o700)
 for name in ['native.stdout','native.stderr','candidate.stdout','candidate.stderr']:
  raw=(P/name).read_bytes();assert len(raw)<4<<20;(root/name).write_bytes(raw)
 for name in ['0001.npz','0001.json']:(root/'captures'/name).write_bytes((P/'captures'/name).read_bytes())
 (root/'case-result.json').write_bytes((P/'one-result.json').read_bytes());rows.append(verified_case(plan['cases'][0],root))
 for case in plan['cases'][1:]:
  assert time.monotonic()<deadline-135;root=R/f"{case['id']:04d}";root.mkdir(mode=0o700);env=dict(os.environ,CONFLUX_CASE_WORK=str(root))
  with(root/'driver.stdout').open('x')as out,(root/'driver.stderr').open('x')as err:
   child=subprocess.Popen(['python','-B',str(B/'run_case.py'),str(case['id'])],stdin=subprocess.DEVNULL,stdout=out,stderr=err,env=env,start_new_session=True);code=child.wait(timeout=min(140,max(1,deadline-time.monotonic()-10)))
  assert code==0,'Candidate case failed';rows.append(verified_case(case,root));(W/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
 report['complete']=len(rows)==93
except BaseException as error:report['error']={'type':type(error).__name__,'message':str(error)[:2000]}
finally:
 if child is not None and child.poll()is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
 report.update(child_reaped=child is None or child.poll()is not None,elapsed_seconds=time.monotonic()-start,new_cases_completed=max(0,len(rows)-1),uncompleted_case_ids=list(range(len(rows)+1,94)))
 (W/'full-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='cases'}));sys.exit(0 if report['complete']else 1)
