"""One fixed CPU-only mono-frontend validation; native export is preparation only."""
from pathlib import Path
import os,sys,subprocess,signal,time,json,hashlib
B=Path('/operations');W=Path('/work');plan=json.loads((B/'capture-plan.json').read_text());case=plan['cases'][0];start=time.monotonic();deadline=start+120;child=None
for n in ['pcm','spool','captures']:(W/n).mkdir(mode=0o700)
report={'schema':1,'complete':False,'qualified':False,'case_id':1,'kind':'single_mono_frontend_pipeline_validation','CPU_only':True,'model_process_started':False,'model_inference_completed':False,'native_transport_status':None}

def interrupted(*args):raise InterruptedError('Owned mono validation interrupted')
for sig in(signal.SIGTERM,signal.SIGINT):signal.signal(sig,interrupted)
def run(command,stem,input_path=None,seconds=30):
 global child
 with(W/(stem+'.stdout')).open('xb')as out,(W/(stem+'.stderr')).open('xb')as err:
  stream=open(input_path,'rb')if input_path is not None else subprocess.DEVNULL
  try:
   child=subprocess.Popen(command,stdin=stream,stdout=out,stderr=err,env=env,start_new_session=True)
   if stem=='candidate':report['model_process_started']=True
   code=child.wait(timeout=min(seconds,max(1,deadline-time.monotonic()-10)))
  finally:
   if input_path is not None:stream.close()
 assert code==0,stem+' child failed'
 assert(W/(stem+'.stdout')).stat().st_size<=4<<20 and(W/(stem+'.stderr')).stat().st_size<=65536
 return(W/(stem+'.stdout')).read_bytes()
env=dict(os.environ,CONFLUX_CAPTURE_CASE_ID='1',CONFLUX_PCM_EXPORT_ROOT=str(W/'pcm'))
try:
 output=run(['/probe/brid-production-probe','--bpm-analysis',str(W/'spool'),plan['python'],'/assets/source','/assets/model/final0.ckpt',str(B/'dump_prepared.py'),'/media/0001.wav'],'native',seconds=25)
 rows=[json.loads(x)for x in output.splitlines()];assert len(rows)==2 and rows[1]['complete']and rows[1]['passed'];native=rows[0]
 assert native['passed']and native['analysis_status']=='Unknown'and native['analysis_error']==''and native['beats']==[]and native['summary_bpm']is None
 assert native['source_sha256']==case['source_sha256']and native['source_bytes']==case['source_bytes']and native['prepared_frames']==native['analysis_frames']==case['prepared_frames']and native['pcm_sha256']==native['analysis_pcm_sha256']==case['pcm_sha256']
 pcm=W/'pcm/0001.f32';assert pcm.stat().st_size==case['prepared_frames']*8
 with pcm.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==case['pcm_sha256']
 assert not list((W/'spool').iterdir());report['native_transport_status']='Unknown; no beats inferred';report['model_inference_requested']=True
 output=run([plan['python'],'-I','-B',str(B/'capture_candidate.py'),'--source-dir','/assets/source','--model','/assets/model/final0.ckpt','--frames',str(case['prepared_frames'])],'candidate',input_path=pcm,seconds=75)
 values=[json.loads(x)for x in output.splitlines()];header=values[0];events=values[1:];meta=json.loads((W/'captures/0001.json').read_text())
 assert header['schema']==2 and header['recipe']=='beat-this-final0-upstream-mono-diagnostic-v1'and header['frames']==case['prepared_frames']and header['pcm_sha256']==case['pcm_sha256']and header['beat_count']==len(events)
 assert all(type(e['frame'])is int and 0<=e['frame']<case['prepared_frames']and type(e['downbeat'])is bool for e in events)and all(a['frame']<b['frame']for a,b in zip(events,events[1:]))
 assert meta['frames']==case['prepared_frames']and meta['pcm_sha256']==case['pcm_sha256']and meta['calls']==1 and meta['recipe']==header['recipe']and meta['result_sha256']==hashlib.sha256(output).hexdigest()
 assert meta['analysis_worker_sha256']==hashlib.sha256((B/'candidate_worker.py').read_bytes()).hexdigest()
 report.update(complete=True,model_inference_completed=True,input_pcm_sha256=case['pcm_sha256'],frames=case['prepared_frames'],recipe=header['recipe'],observed_logit_frames=meta['logit_frames'],source_mask_frames=meta['mask_true_count'],returned_events=len(events),raw_logits_sha256=meta['array_sha256'],response_sha256=meta['result_sha256'])
except BaseException as error:report['error']={'type':type(error).__name__,'message':str(error)[:2000]}
finally:
 if child is not None and child.poll()is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
 for name in ['0001.f32','0001.json']:
  p=W/'pcm'/name
  if p.is_file()and not p.is_symlink():p.unlink()
 report.update(child_reaped=child is None or child.poll()is not None,elapsed_seconds=time.monotonic()-start,spool_empty=not list((W/'spool').iterdir()),temporary_pcm_retired=not list((W/'pcm').iterdir()))
 (W/'one-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report));sys.exit(0 if report['complete']else 1)
