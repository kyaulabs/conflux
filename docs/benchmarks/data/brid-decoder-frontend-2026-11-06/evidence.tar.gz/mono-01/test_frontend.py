"""Exact comparison to the pinned official frontend, without model weights."""
from pathlib import Path
import importlib.util,json,sys
import numpy as np,torch,soxr
B=Path('/operations');O=Path('/work');torch.set_num_threads(1);torch.set_num_interop_threads(1)
def forbidden(*args,**kwargs):raise AssertionError('Checkpoint loading forbidden in frontend-only test')
torch.load=forbidden;torch.hub.load_state_dict_from_url=forbidden
spec=importlib.util.spec_from_file_location('mono_candidate',B/'candidate_worker.py');worker=importlib.util.module_from_spec(spec);spec.loader.exec_module(worker)
up=worker.load_upstream('/assets/source',worker.verified_sources('/assets/source'))
class Frontend:
 def __init__(self):self.device='cpu';self.spect=up.LogMelSpect(device='cpu')
 def signal2spect(self,signal,sr):return up.Audio2Frames.signal2spect(self,signal,sr)
frontend=Frontend();frames=4801;t=np.arange(frames,dtype=np.float32);left=(.2*np.sin(t*.07)).astype(np.float32);rows=[]
for name,right in [('equal',left),('unequal',np.roll(left,3)*np.float32(.7)),('opposite',-left)]:
 stereo=np.stack([left,right],axis=1);original=soxr.resample;expected=frontend.signal2spect(stereo,48000);actual,lengths=worker.diagnostic_mono_spect(frontend,stereo)
 assert soxr.resample is original and torch.equal(expected,actual);mask=worker.source_mask(frames,lengths,len(actual));assert len(mask)==len(actual)and all(mask)
 if name=='opposite':assert torch.count_nonzero(actual).item()==0
 rows.append({'fixture':name,'exact_upstream_spectrogram':True,'observed_resampled_frames':lengths[0],'logit_input_frames':len(actual),'source_mask_valid':True})
class Failure:
 def signal2spect(self,*args):raise RuntimeError('generated')
original=soxr.resample
try:worker.diagnostic_mono_spect(Failure(),np.zeros((frames,2),dtype=np.float32))
except RuntimeError:pass
else:raise AssertionError('Expected frontend failure')
assert soxr.resample is original
assert worker.RECIPE=='beat-this-final0-upstream-mono-diagnostic-v1'
result={'passed':True,'fixtures':rows,'resampler_restored_on_success_and_failure':True,'distinct_diagnostic_recipe':True,'model_loaded':False,'GPU_started':False};(O/'frontend-test-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
