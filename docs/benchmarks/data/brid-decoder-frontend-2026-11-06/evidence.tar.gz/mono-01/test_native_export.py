"""Check existing native preparation exports exact PCM; the transport returns Unknown."""
from pathlib import Path
import os,sys,json,subprocess,hashlib,shutil
B=Path('/operations');O=Path('/work');plan=json.loads((B/'capture-plan.json').read_text());case=plan['cases'][0];T=O/'native-check';T.mkdir(mode=0o700)
for n in ['spool','pcm']:(T/n).mkdir(mode=0o700)
env=dict(os.environ,CONFLUX_CAPTURE_CASE_ID='1',CONFLUX_PCM_EXPORT_ROOT=str(T/'pcm'))
cmd=['/probe/brid-production-probe','--bpm-analysis',str(T/'spool'),plan['python'],'/assets/source','/assets/model/final0.ckpt',str(B/'dump_prepared.py'),'/media/0001.wav']
r=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=35);(O/'native-transport.stdout.jsonl').write_text(r.stdout);(O/'native-transport.stderr.log').write_text(r.stderr);assert r.returncode==0,r.stderr
rows=[json.loads(x)for x in r.stdout.splitlines()];assert len(rows)==2 and rows[1]['complete']and rows[1]['passed'];row=rows[0]
assert row['passed']and row['analysis_status']=='Unknown'and row['analysis_error']==''and row['beats']==[]and row['summary_bpm']is None and not row['cache_hit']
assert row['source_sha256']==case['source_sha256']and row['source_bytes']==case['source_bytes']and row['prepared_frames']==row['analysis_frames']==case['prepared_frames']and row['pcm_sha256']==row['analysis_pcm_sha256']==case['pcm_sha256']
p=T/'pcm/0001.f32';raw=p.read_bytes();meta=json.loads((T/'pcm/0001.json').read_text());assert len(raw)==case['prepared_frames']*8 and hashlib.sha256(raw).hexdigest()==case['pcm_sha256']and meta['kind']=='native_prepared_PCM_export_only'and not meta['model_loaded']and not meta['analysis_performed'];assert not list((T/'spool').iterdir())
result={'passed':True,'native_prepared_pcm_matches_frozen_baseline':True,'frames':case['prepared_frames'],'pcm_sha256':case['pcm_sha256'],'native_transport_status':'Unknown','no_beats_inferred':True,'model_or_GPU_started':False,'spool_empty':True};(O/'native-transport-result.json').write_text(json.dumps(result,indent=2)+'\n');shutil.rmtree(T);print(json.dumps(result))
