"""Sequential private CPU observation; no labels, audio output, GUI or GPU."""
from pathlib import Path
import os,sys,json,hashlib,subprocess,time,signal
B=Path('/operations');O=Path('/work');PLAN=json.loads((B/'capture-plan.json').read_text())
ASSET=Path('/assets');PYTHON=PLAN['python'];PROBE='/probe/brid-production-probe'

def pin(path):
 p=Path(path);assert p.is_file()and not p.is_symlink();before=p.stat()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 after=p.stat();assert(before.st_ino,before.st_dev,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_dev,after.st_size,after.st_mtime_ns)
 return {'bytes':before.st_size,'sha256':h}

def main():
 assert sys.argv[1:] in [['--check'],['--one'],['--all']]
 for item in PLAN['packet_pins']:
  assert pin(B/item['name'])=={k:item[k]for k in('bytes','sha256')}
 assert pin(PROBE)==PLAN['probe_pin']
 if sys.argv[1]=='--check':
  subprocess.run([PYTHON,'-I','-B',str(B/'test_capture.py')],check=True,timeout=45);return
 assert pin(ASSET/'model/final0.ckpt')=={'bytes':PLAN['model_bytes'],'sha256':PLAN['model_sha256']}
 for name in ('captures','spool','cases'): (O/name).mkdir(mode=0o700)
 selected=PLAN['cases'][:1]if sys.argv[1]=='--one'else PLAN['cases']
 start=time.monotonic();deadline=start+(90 if len(selected)==1 else 4500);rows=[];child=None
 def interrupted(*args):raise InterruptedError('Owned CPU capture interrupted')
 for sig in(signal.SIGTERM,signal.SIGINT):signal.signal(sig,interrupted)
 report={'schema':1,'complete':False,'qualified':False,'fixed_corpus_denominator':93,'attempt_scope':len(selected),'cases':rows,'GPU_started':False,'audio_output_started':False,'same_production_worker':True,'plan_sha256':hashlib.sha256((B/'capture-plan.json').read_bytes()).hexdigest()}
 try:
  for case in selected:
   assert time.monotonic()<deadline-10
   source=Path('/media')/f"{case['id']:04d}.wav";assert pin(source)=={'bytes':case['source_bytes'],'sha256':case['source_sha256']}
   env=dict(os.environ,CONFLUX_CAPTURE_CASE_ID=str(case['id']))
   command=[PROBE,'--bpm-analysis',str(O/'spool'),PYTHON,'/assets/source','/assets/model/final0.ckpt',str(B/'capture_worker.py'),str(source)]
   row={'id':case['id'],'passed':False};rows.append(row)
   with(O/'cases'/f"{case['id']:04d}.stdout.jsonl").open('x')as out,(O/'cases'/f"{case['id']:04d}.stderr.log").open('x')as err:
    child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,env=env,start_new_session=True)
    row['native_exit']=child.wait(timeout=min(75,max(1,deadline-time.monotonic()-10)))
   assert not list((O/'spool').iterdir())
   stdout=O/'cases'/f"{case['id']:04d}.stdout.jsonl";assert stdout.stat().st_size<1048576
   values=[json.loads(x)for x in stdout.read_text().splitlines()]
   assert len(values)==2 and values[0]['ordinal']==0 and values[1]['kind']=='production-bpm-complete'
   native=values[0];terminal=values[1]
   assert row['native_exit']==0 and native['passed']and terminal['complete']and terminal['passed']and terminal['expected']==terminal['completed']==1
   assert native['analysis_status']=='Estimated'and native['analysis_error']==''and not native['cache_hit']
   assert native['source_sha256']==case['source_sha256']and native['source_bytes']==case['source_bytes']
   assert native['prepared_rate_hz']==48000 and native['prepared_frames']==native['analysis_frames']==case['prepared_frames']
   assert native['pcm_sha256']==native['analysis_pcm_sha256']==case['pcm_sha256']
   meta=json.loads((O/'captures'/f"{case['id']:04d}.json").read_text())
   assert meta['case_id']==case['id']and meta['frames']==case['prepared_frames']and meta['pcm_sha256']==case['pcm_sha256']and meta['calls']==1
   assert pin(O/'captures'/f"{case['id']:04d}.npz")=={'bytes':meta['array_bytes'],'sha256':meta['array_sha256']}
   assert pin(source)=={'bytes':case['source_bytes'],'sha256':case['source_sha256']}
   row.update(passed=True,prepared_frames=case['prepared_frames'],pcm_sha256=case['pcm_sha256'],logit_frames=meta['logit_frames'])
   (O/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
  report['complete']=len(rows)==len(selected)and all(r['passed']for r in rows)
 except BaseException as e:report['error']={'type':type(e).__name__,'message':str(e)[:2000]}
 finally:
  if child is not None and child.poll()is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
  report.update(native_reaped=child is None or child.poll()is not None,elapsed_seconds=time.monotonic()-start,spool_empty=not list((O/'spool').iterdir()))
  (O/'result.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report));sys.exit(0 if report['complete']else 1)
if __name__=='__main__':main()
