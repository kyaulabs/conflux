"""Own one bounded CPU-only observational capture container in the dedicated daemon."""
from pathlib import Path
import sys,json,subprocess,signal,time,hashlib,os
B=Path('/srv/conflux-tests/work/brid-logits-full-20261106-01');R=Path('/srv/conflux-tests/work/brid-analysis-20261029-01')
D=['env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock'];IMAGE='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'

def main():
 assert sys.argv[1:]in[['--check'],['--one'],['--all']]
 mode=sys.argv[1][2:];name='conflux-brid-logits-full-'+mode+'-20261106-01';label='brid-logits-full-'+mode+'-20261106-01'
 active=subprocess.run(D+['ps','-q'],capture_output=True,text=True,timeout=15);assert active.returncode==0 and not active.stdout.strip()
 assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}'],timeout=15))=='/srv/conflux-tests/docker-data'
 packet=B/'packet';plan=json.loads((packet/'capture-plan.json').read_text());manifest=json.loads((R/'corpus-02/runtime-manifest-01.json').read_text())
 probe=R/'probe-build-01/output/build/native/brid-production-probe';assert probe.is_file()
 with probe.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==plan['probe_pin']['sha256']
 for pin in plan['packet_pins']:
  p=packet/pin['name'];raw=p.read_bytes();assert len(raw)==pin['bytes']and hashlib.sha256(raw).hexdigest()==pin['sha256']
 out=B/(mode+'-output');assert not out.exists();out.mkdir(mode=0o700);os.chown(out,1000,1000)
 for n in ('tmp','cache','data','state'):
  p=out/n;p.mkdir(mode=0o700);os.chown(p,1000,1000)
 assets=R/'runtime-01/assets';cmd=D+['run','--rm','--name',name,'--runtime=runc','--init','--network=none','--read-only','--user=1000:1000','--cap-drop=ALL','--security-opt=no-new-privileges:true','--memory=4g','--memory-swap=4g','--cpus=2','--pids-limit=256','--label','org.kyaulabs.conflux.run='+label,'--tmpfs=/tmp:rw,nosuid,nodev,size=32m,mode=1777','--ulimit','fsize=67108864:67108864','--ulimit','core=0:0']
 for src,dst,readonly in [(packet,'/operations',True),(out,'/work',False),(assets,'/assets',True),(assets/'venv',manifest['source_venv'],True),(assets/'base',manifest['source_base_python'],True),(R/'acquisition-01/media-01','/media',True),(probe.parent,'/probe',True)]:cmd+=['--mount','type=bind,src='+str(src)+',dst='+str(dst)+(',readonly'if readonly else'')]
 for k,v in {'TMPDIR':'/work/tmp','XDG_CACHE_HOME':'/work/cache','XDG_DATA_HOME':'/work/data','XDG_STATE_HOME':'/work/state','PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','MKL_NUM_THREADS':'2'}.items():cmd+=['-e',k+'='+v]
 limit=60 if mode=='check'else 110 if mode=='one'else 4530
 cmd+=[IMAGE,'timeout','--signal=TERM','--kill-after=8s',str(limit)+'s','python','-B','/operations/capture_driver.py','--'+mode]
 child=None;report={'scope':mode,'qualified':False,'CPU_only':True,'command':cmd};start=time.monotonic()
 def interrupted(*args):raise InterruptedError('Owned CPU observation interrupted')
 for sig in(signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,interrupted)
 try:
  with(B/(mode+'.log')).open('x')as log:
   child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT);report['exit']=child.wait(timeout=limit+15)
 except BaseException as e:report['error']={'type':type(e).__name__,'message':str(e)[:1500]}
 finally:
  q=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=15)
  if q.returncode==0:
   c=json.loads(q.stdout)[0];assert c['Image']==IMAGE and c['Config']['Labels'].get('org.kyaulabs.conflux.run')==label
   subprocess.run(D+['rm','-f',c['Id']],capture_output=True,check=True,timeout=15)
  if child is not None and child.poll()is None:
   child.terminate()
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
  q=subprocess.run(D+['inspect',name],capture_output=True,timeout=15)
  report.update(container_absent=q.returncode!=0,client_reaped=child is None or child.poll()is not None,elapsed_seconds=time.monotonic()-start)
  (B/(mode+'-receipt.json')).write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items()if k!='command'}))
 sys.exit(0 if report.get('exit')==0 and report['container_absent']and report['client_reaped']else 1)
if __name__=='__main__':main()
