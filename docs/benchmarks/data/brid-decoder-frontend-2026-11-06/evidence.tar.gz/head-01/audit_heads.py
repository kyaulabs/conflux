"""Descriptive fixed-window logits; no decoder, new predictions or fitting."""
from pathlib import Path
from decimal import Decimal,ROUND_CEILING,ROUND_FLOOR
import json,hashlib,statistics,collections
import numpy as np
B=Path(__file__).resolve().parent;TOL=Decimal('0.070');FPS=50

def windows(t,mask):
 if not t.is_finite()or t<0 or mask.ndim!=1 or mask.dtype!=np.bool_:raise ValueError('Invalid descriptive window')
 lo=max(0,int(((t-TOL)*FPS).to_integral_value(rounding=ROUND_CEILING)));hi=min(len(mask)-1,int(((t+TOL)*FPS).to_integral_value(rounding=ROUND_FLOOR)))
 out=[i for i in range(lo,hi+1)if mask[i]]
 if not out:raise ValueError('No source-eligible logits in window')
 return out

def check_generated():
 mask=np.ones(20,dtype=np.bool_);assert windows(Decimal('.13'),mask)==list(range(3,11))
 mask[10:]=False;assert windows(Decimal('.13'),mask)==list(range(3,10))
 for t in [Decimal('NaN'),Decimal('-1')]:
  try:windows(t,mask)
  except ValueError:pass
  else:raise AssertionError('Invalid reference accepted')
 try:windows(Decimal('1'),mask)
 except ValueError:pass
 else:raise AssertionError('Empty source window accepted')

def read_pin(pin):
 raw=Path(pin['path']).read_bytes();assert len(raw)==pin['bytes']and hashlib.sha256(raw).hexdigest()==pin['sha256'];return json.loads(raw)

def stats(rows):
 n=len(rows);assert n
 categories=collections.Counter(('down_positive'if r['down']>0 else'down_nonpositive')+'_'+('beat_positive'if r['beat']>0 else'beat_nonpositive')for r in rows)
 return {'references':n,'down_positive':sum(r['down']>0 for r in rows),'beat_positive':sum(r['beat']>0 for r in rows),'down_positive_fraction':sum(r['down']>0 for r in rows)/n,'beat_positive_fraction':sum(r['beat']>0 for r in rows)/n,'median_window_max_downbeat_logit':statistics.median(r['down']for r in rows),'median_window_max_beat_logit':statistics.median(r['beat']for r in rows),'joint_sign_categories':dict(categories)}

def main():
 check_generated();plan=json.loads((B/'plan.json').read_text());assert plan['reference_window_seconds']=='0.070'and plan['existing_positive_logit_boundary']==0 and plan['fixed_denominator']==93
 protocol=read_pin(plan['reference_protocol']);capture=read_pin(plan['capture_plan']);assert len(protocol['cases'])==len(capture['cases'])==93
 for p in plan['capture_pins']:
  raw=(B/'captures'/p['name']).read_bytes();assert len(raw)==p['bytes']and hashlib.sha256(raw).hexdigest()==p['sha256']
 all_rows={1:[],2:[]};cases=[]
 for case,c in zip(protocol['cases'],capture['cases'],strict=True):
  identifier=case['id'];assert identifier==c['id'];meta=json.loads((B/'captures'/f'{identifier:04d}.json').read_text());assert meta['frames']==c['prepared_frames']and meta['pcm_sha256']==c['pcm_sha256']
  with np.load(B/'captures'/f'{identifier:04d}.npz',allow_pickle=False)as z:
   assert z.files==['beat','downbeat','mask'];beat=z['beat'];down=z['downbeat'];mask=z['mask']
  assert beat.dtype==down.dtype==np.dtype('<f4')and beat.shape==down.shape==mask.shape and len(beat)==meta['logit_frames']and np.isfinite(beat).all()and np.isfinite(down).all()
  assert np.array_equal(mask,np.array([i*48000<c['prepared_frames']*50 for i in range(len(beat))],dtype=np.bool_))
  refs=[Decimal(t)for t in case['reference_seconds_text']];positions=case['bar_positions'];assert len(refs)==len(positions)and all(b-a>2*TOL for a,b in zip(refs,refs[1:]))
  local={1:[],2:[]}
  for t,pos in zip(refs,positions,strict=True):
   assert pos in(1,2)and t*48000<c['prepared_frames'];indices=windows(t,mask);item={'down':max(float(down[k])for k in indices),'beat':max(float(beat[k])for k in indices)};local[pos].append(item);all_rows[pos].append(item)
  by_pos={str(pos):stats(v)for pos,v in local.items()};cases.append({'id':identifier,'name':case['name'],'phase':by_pos,'position2_downbeat_median_higher':by_pos['2']['median_window_max_downbeat_logit']>by_pos['1']['median_window_max_downbeat_logit']})
 result={'schema':1,'kind':'descriptive_logit_window_audit','denominator':93,'reference_window_seconds':'0.070','positive_logit_boundary':0,'phase':{str(pos):stats(v)for pos,v in all_rows.items()},'position2_downbeat_median_higher_cases':sum(c['position2_downbeat_median_higher']for c in cases),'cases':cases,'source_mask_unchanged':True,'parameters_fitted':False,'prediction_or_threshold_change':False,'new_model_or_GPU_or_audio_output':False,'qualified':False,'confidence':'Unknown','held_out':False,'important_limit':'A window maximum is descriptive head evidence, not a decoded event, per-reference match, calibrated confidence, or causal miss classification.'}
 (B/'head-result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='cases'},indent=2))
if __name__=='__main__':main()
