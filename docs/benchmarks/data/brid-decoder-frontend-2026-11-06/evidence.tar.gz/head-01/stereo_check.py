from pathlib import Path
import numpy as np,json,hashlib,wave,io,math,time
B=Path('/operations');O=Path('/work');began=time.monotonic()

def geometry(a):
 assert a.dtype==np.dtype('<i2')and a.ndim==2 and a.shape[1]==2
 equal=bool(np.array_equal(a[:,0],a[:,1]));x=a.astype(np.float64);energy=float(np.square(x).sum()/2);mid_energy=float(np.square((x[:,0]+x[:,1])*.5).sum())
 z=x-x.mean(axis=0);p=float(np.square(z[:,0]).sum());q=float(np.square(z[:,1]).sum());corr=float((z[:,0]*z[:,1]).sum()/math.sqrt(p*q))if p*q>0 else None
 return {'channels_bit_identical':equal,'mean_channel_energy':energy,'mono_mean_energy_ratio':mid_energy/energy if energy>0 else None,'centered_correlation':corr}

def check_generated():
 for a,ratio,corr in [(np.array([[30000,30000],[-30000,-30000]],dtype='<i2'),1.,1.),(np.array([[1000,-1000],[2000,-2000],[-3000,3000]],dtype='<i2'),0.,-1.),(np.array([[1,1],[-1,1],[1,-1],[-1,-1]],dtype='<i2'),.5,0.)]:
  r=geometry(a);assert abs(r['mono_mean_energy_ratio']-ratio)<1e-12 and abs(r['centered_correlation']-corr)<1e-12
 assert geometry(np.array([[30000,30000],[-30000,-30000]],dtype='<i2'))['mean_channel_energy']==1800000000.

def main():
 assert np.__version__=='2.5.4';check_generated();plan=json.loads((B/'capture-plan.json').read_text());assert plan['fixed_denominator']==93 and [c['id']for c in plan['cases']]==list(range(1,94));rows=[]
 for case in plan['cases']:
  assert time.monotonic()-began<45
  p=Path('/media')/f"{case['id']:04d}.wav";assert p.is_file()and not p.is_symlink();before=p.stat();assert before.st_size==case['source_bytes']and before.st_size<9<<20;raw=p.read_bytes();after=p.stat();assert(before.st_ino,before.st_dev,before.st_mtime_ns,before.st_ctime_ns,before.st_size)==(after.st_ino,after.st_dev,after.st_mtime_ns,after.st_ctime_ns,after.st_size);assert hashlib.sha256(raw).hexdigest()==case['source_sha256']
  with wave.open(io.BytesIO(raw),'rb')as w:
   assert w.getnchannels()==2 and w.getsampwidth()==2 and w.getframerate()==44100 and 0<w.getnframes()<=60*44100;frames=w.getnframes();pcm=w.readframes(frames);assert len(pcm)==frames*4
  a=np.frombuffer(pcm,dtype='<i2').reshape(frames,2);rows.append({'id':case['id'],'source_sha256':case['source_sha256'],'source_frames_44100':frames,**geometry(a)})
 result={'schema':1,'complete':True,'denominator':93,'cases':rows,'channels_bit_identical_cases':sum(c['channels_bit_identical']for c in rows),'minimum_correlation':min(c['centered_correlation']for c in rows if c['centered_correlation']is not None),'minimum_mono_energy_ratio':min(c['mono_mean_energy_ratio']for c in rows if c['mono_mean_energy_ratio']is not None),'elapsed_seconds':time.monotonic()-began,'generated_numeric_checks_passed':True,'model_or_GPU_or_audio_output':False,'source_inputs_changed':False,'qualified':False}
 (O/'stereo-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='cases'}))
if __name__=='__main__':main()
