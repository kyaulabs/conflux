from pathlib import Path
import importlib.util,json,sys,hashlib
import numpy as np,torch
B=Path('/operations');O=Path('/work');torch.set_num_threads(1);torch.set_num_interop_threads(1)
spec=importlib.util.spec_from_file_location('capture',B/'capture_worker.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
w=m.load_production();up=w.load_upstream('/assets/source',w.verified_sources('/assets/source'));original=up.Postprocessor
beat=torch.full((51,),-10.);down=beat.clone();beat[10]=beat[30]=8.;down[10]=8.;beat[50]=down[50]=12.;mask=torch.arange(51)<50
expected=original('minimal',50)(beat,down,mask)
context={'frames':48000,'pcm_sha256':'0'*64,'calls':0};path=O/'fixture.npz';observed=m.capture_class(original,context,path)('minimal',50)
actual=observed(beat,down,mask)
assert all(np.array_equal(a,b) for a,b in zip(expected,actual))
with np.load(path,allow_pickle=False)as data:
 assert data.files==['beat','downbeat','mask']
 assert np.array_equal(data['beat'],beat.numpy())and np.array_equal(data['downbeat'],down.numpy())and np.array_equal(data['mask'],mask.numpy())
assert max(actual[0])<1 and context['calls']==1
try:observed(beat,down,mask)
except AssertionError:pass
else:raise AssertionError('Duplicate capture was accepted')
for mode in ['wrong_dtype','wrong_mask']:
 out=O/(mode+'.npz');c={'frames':48000,'pcm_sha256':'0'*64,'calls':0};proc=m.capture_class(original,c,out)('minimal',50)
 try:proc(beat.double()if mode=='wrong_dtype'else beat,down,torch.ones_like(mask)if mode=='wrong_mask'else mask)
 except AssertionError:pass
 else:raise AssertionError('Invalid capture was accepted')
 assert not out.exists()
result={'passed':True,'checks':['unchanged_minimal_result','lossless_F32_and_mask_roundtrip','duplicate_capture_rejected','wrong_dtype_and_source_mask_rejected'],'model_loaded':False,'GPU_started':False,'fixture_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(O/'capture-test-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
