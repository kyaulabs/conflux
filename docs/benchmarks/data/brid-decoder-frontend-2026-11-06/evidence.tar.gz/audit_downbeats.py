from pathlib import Path
from decimal import Decimal
from collections import Counter
from bisect import bisect_left
import json,gzip,hashlib
ROOT=Path('/srv/conflux-tests/laptop/worktrees/vulkan-submission-sync/docs/benchmarks/data/brid-beat-2026-10-29')
OUT=Path(__file__).resolve().parent
TOLERANCE=Decimal('0.070')
def count_ceiling(p,r):
 if type(p)is not int or type(r)is not int or min(p,r)<0 or p+r==0:raise ValueError('Invalid event counts')
 return 2*min(p,r)/(p+r)
def phase(refs,labels,frame):
 t=Decimal(frame)/48000;i=bisect_left(refs,t);choices=[j for j in [i-1,i]if 0<=j<len(refs)]
 j=min(choices,key=lambda k:(abs(refs[k]-t),k))
 return str(labels[j])if abs(refs[j]-t)<=TOLERANCE else 'unaligned'
def check_generated():
 assert count_ceiling(9,11)==.9 and count_ceiling(8,10)<.9 and count_ceiling(0,10)==0
 refs=list(map(Decimal,['0','0.5','1','1.5']));labels=[1,2,1,2]
 assert [phase(refs,labels,f)for f in [0,24000,48000,72000]]==['1','2','1','2']
 assert phase(refs,labels,3360)=='1'and phase(refs,labels,3361)=='unaligned'
 assert [phase(refs,labels,0),phase(refs,labels,0)]==['1','1'] # no prediction deduplication
 for p,r in [(True,1),(-1,2),(0,0)]:
  try:count_ceiling(p,r)
  except ValueError:pass
  else:raise AssertionError('Invalid counts admitted')
def pairs(items):
 out={}
 for k,v in items:
  if k in out:raise ValueError('Duplicate key')
  out[k]=v
 return out
def parse(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in()).throw(ValueError(x)))
def main():
 check_generated();manifest=parse((ROOT/'manifest.json').read_bytes());inputs=[]
 def read(name):
  row=next(r for r in manifest['members']if r['source']==name);packed=(ROOT/row['member']).read_bytes();assert hashlib.sha256(packed).hexdigest()==row['gzip_sha256'];raw=gzip.decompress(packed);assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256'];inputs.append(dict(source=name,sha256=row['sha256'],bytes=len(raw)));return raw
 protocol=parse(read('corpus-02/protocol.json'));scores=parse(read('corpus-02/scores.json'));raw=read('corpus-02/laptop-output/native.stdout.jsonl');assert raw.endswith(b'\n');native=[parse(line)for line in raw.splitlines()]
 assert protocol['fixed_denominator']==scores['fixed_denominator']==93 and len(native)==94 and native[-1]['kind']=='production-bpm-complete'and native[-1]['complete']is True and native[-1]['completed']==93
 score=scores['hosts']['laptop'];assert score['complete']is True and score['native_rows']==93
 rows=[];hist=Counter();phases=Counter();tp=fp=fn=0
 for index,(case,captured,scored)in enumerate(zip(protocol['cases'],native[:-1],score['cases'],strict=True)):
  assert case['id']==scored['id']==index+1 and captured['ordinal']==index and captured['kind']=='production-bpm-case'and captured['schema']==1
  assert captured['passed']is True and captured['analysis_status']=='Estimated'and captured['cache_hit']is False and captured['analysis_error']==''
  assert captured['source_sha256']==case['source']['sha256'] and captured['source_bytes']==case['source']['bytes']
  frames=captured['prepared_frames'];assert captured['prepared_rate_hz']==48000 and captured['prepared_bytes']==frames*8 and captured['analysis_frames']==frames and captured['analysis_pcm_sha256']==captured['pcm_sha256']==scored['pcm_sha256']
  refs=[Decimal(t)for t in case['reference_seconds_text']];labels=case['bar_positions'];assert len(refs)==len(labels)and all(x in(1,2)for x in labels)
  assert all(t.is_finite()and 0<=t and t*48000<frames and t*44100<case['source']['source_geometry']['frames']for t in refs)
  assert all(b-a>2*TOLERANCE for a,b in zip(refs,refs[1:])), 'Ambiguous nearest reference phase'
  events=captured['beats'];previous=-1;indices=[];counts=Counter()
  for i,event in enumerate(events):
   assert set(event)=={'frame','downbeat'}and type(event['frame'])is int and previous<event['frame']<frames and type(event['downbeat'])is bool;previous=event['frame']
   if event['downbeat']:indices.append(i);counts[phase(refs,labels,event['frame'])]+=1
  pred=len(indices);truth=sum(v==1 for v in labels);metric=scored['downbeat'];assert metric['estimated_beats']==pred and metric['reference_beats']==truth
  tp+=metric['matched_beats'];fp+=metric['false_positives'];fn+=metric['false_negatives'];gaps=Counter(b-a for a,b in zip(indices,indices[1:]));hist.update(gaps);phases.update(counts)
  ceiling=count_ceiling(pred,truth);possible=20*min(pred,truth)>=9*(pred+truth)
  rows.append(dict(id=case['id'],estimated_downbeats=pred,reference_downbeats=truth,count_only_F1_ceiling=ceiling,can_reach_F1_point90_without_changing_count=possible,nearest_reference_phase=dict(counts),estimated_beat_gap_histogram=dict(gaps)))
 micro=score['downbeat_micro'];assert (tp,fp,fn)==(micro['matched_events'],micro['extras'],micro['misses'])
 P=tp+fp;R=tp+fn;assert P==sum(v['estimated_downbeats']for v in rows)and R==sum(v['reference_downbeats']for v in rows)and sum(phases.values())==P
 x=dict(schema=1,all_93_cases_retained=True,source_inputs=inputs,recorded_downbeat_screen_passes=score['downbeat_cases_passing'],reference_downbeats=R,estimated_downbeats=P,matched=tp,extras=fp,misses=fn,unchanged_recorded_micro_F1=micro['F1'],optimistic_count_only_micro_F1_ceiling=count_ceiling(P,R),cases_count_incompatible_with_point90=sum(not c['can_reach_F1_point90_without_changing_count']for c in rows),nearest_reference_phase=dict(phases),estimated_beat_gap_histogram=dict(hist),phase_audit_is_not_a_one_to_one_rescore=True,no_prediction_shift_filter_or_relabel=True,no_model_inference_or_GPU=True,production_changed=False,qualified=False,confidence='Unknown',cases=rows)
 x['per_case_count_micro_F1_ceiling']=2*sum(min(c['estimated_downbeats'],c['reference_downbeats'])for c in rows)/(R+P)
 (OUT/'downbeat-density-audit.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({k:v for k,v in x.items()if k not in('cases','source_inputs')}))
if __name__=='__main__':main()
