"""Run fixed label-free postprocessing only after the complete owned CPU capture retires."""
from pathlib import Path
import json,hashlib,subprocess,os,signal,time,sys
B=Path('/srv/conflux-tests/work/brid-decode-20261106-01');R=Path('/srv/conflux-tests/work/brid-logits-full-20261106-01');ASSET=Path('/srv/conflux-tests/work/brid-analysis-20261029-01/runtime-01/assets')
D=['env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock'];IMAGE='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919';NAME='conflux-brid-decode-20261106-01';LABEL='brid-decode-20261106-01'

def pin(path):
 p=Path(path);assert p.is_file()and not p.is_symlink()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'bytes':p.stat().st_size,'sha256':h}

def main():
 assert sys.argv[1:]==['--run']
 active=subprocess.run(D+['ps','-q'],capture_output=True,text=True,timeout=15);assert active.returncode==0 and not active.stdout.strip()
 assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}'],timeout=15))=='/srv/conflux-tests/docker-data'
 owner=json.loads((R/'all-receipt.json').read_text());capture=json.loads((R/'all-output/result.json').read_text());source_plan=json.loads((R/'packet/capture-plan.json').read_text());recipe=json.loads((B/'recipe.json').read_text())
 assert owner['exit']==0 and owner['container_absent']and owner['client_reaped']
 assert capture['complete']and capture['native_reaped']and capture['spool_empty']and capture['fixed_corpus_denominator']==capture['attempt_scope']==93
 assert [c['id']for c in capture['cases']]==list(range(1,94))and all(c['passed']for c in capture['cases'])
 assert capture['plan_sha256']==pin(R/'packet/capture-plan.json')['sha256']
 packet=B/'packet';plan={'schema':1,'fixed_denominator':93,'cases':source_plan['cases'],'DBN_parameters':recipe['DBN_parameters'],'files':recipe['files'],'capture_result_pin':pin(R/'all-output/result.json'),'capture_plan_pin':pin(R/'packet/capture-plan.json'),'capture_pins':[],'reference_annotations_mounted':False,'qualified':False,'confidence':'Unknown'}
 for c in plan['cases']:
  for kind,root,name in [('capture',R/'all-output/captures',f"{c['id']:04d}.npz"),('capture',R/'all-output/captures',f"{c['id']:04d}.json"),('native',R/'all-output/cases',f"{c['id']:04d}.stdout.jsonl")]:
   p=pin(root/name);assert p['bytes']<1048576;plan['capture_pins'].append({'kind':kind,'name':name,**p})
 for item in plan['files']:assert pin(packet/item['name'])=={k:item[k]for k in('bytes','sha256')}
 path=packet/'prediction-plan.json';assert not path.exists();path.write_text(json.dumps(plan,indent=2)+'\n');path.chmod(0o644)
 out=B/'work';assert not out.exists();out.mkdir(mode=0o700);os.chown(out,1000,1000)
 for n in ['tmp','cache','data','state']:
  p=out/n;p.mkdir(mode=0o700);os.chown(p,1000,1000)
 cmd=D+['run','--rm','--name',NAME,'--runtime=runc','--init','--network=none','--read-only','--user=1000:1000','--memory=1536m','--memory-swap=1536m','--cpus=1','--pids-limit=64','--cap-drop=ALL','--security-opt=no-new-privileges:true','--label','org.kyaulabs.conflux.run='+LABEL,'--ulimit','core=0:0','--ulimit','fsize=67108864:67108864','--tmpfs=/tmp:rw,nosuid,nodev,size=32m,mode=1777']
 for src,dst,readonly in [(packet,'/operations',True),(out,'/work',False),(R/'all-output/captures','/captures',True),(R/'all-output/cases','/native-cases',True),(ASSET/'base','/runtime/base',True),(ASSET/'venv','/runtime/venv',True)]:cmd+=['--mount','type=bind,src='+str(src)+',dst='+dst+(',readonly'if readonly else'')]
 for k,v in {'PYTHONHOME':'/runtime/base','PYTHONPATH':'/runtime/venv/lib/python3.12/site-packages','PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','TMPDIR':'/work/tmp','XDG_CACHE_HOME':'/work/cache','XDG_DATA_HOME':'/work/data','XDG_STATE_HOME':'/work/state'}.items():cmd+=['-e',k+'='+v]
 cmd+=[IMAGE,'timeout','--signal=TERM','--kill-after=8s','650s','/runtime/venv/bin/python','-B','/operations/predict_decoders.py']
 child=None;report={'qualified':False,'model_loaded':False,'GPU_started':False,'plan_pin':pin(path),'command':cmd};began=time.monotonic()
 def interrupt(*args):raise InterruptedError('Owned fixed decoder interrupted')
 for sig in(signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(sig,interrupt)
 try:
  with(B/'decoder.log').open('x')as log:
   child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT);report['exit']=child.wait(timeout=675)
 except BaseException as error:report['error']={'type':type(error).__name__,'message':str(error)[:1500]}
 finally:
  q=subprocess.run(D+['inspect',NAME],capture_output=True,text=True,timeout=15)
  if q.returncode==0:
   c=json.loads(q.stdout)[0];assert c['Image']==IMAGE and c['Config']['Labels'].get('org.kyaulabs.conflux.run')==LABEL
   subprocess.run(D+['rm','-f',c['Id']],check=True,capture_output=True,timeout=15)
  if child is not None and child.poll()is None:
   child.terminate()
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
  report.update(container_absent=subprocess.run(D+['inspect',NAME],capture_output=True,timeout=15).returncode!=0,client_reaped=child is None or child.poll()is not None,elapsed_seconds=time.monotonic()-began)
  (B/'decoder-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items()if k!='command'}));sys.exit(0 if report.get('exit')==0 and report['container_absent']and report['client_reaped']else 1)
if __name__=='__main__':main()
