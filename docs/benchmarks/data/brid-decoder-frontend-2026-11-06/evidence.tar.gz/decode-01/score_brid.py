"""Reuse the frozen BRID scorer; bootstrap only relocated pinned helper buffers."""
from pathlib import Path
from decimal import Decimal
from types import SimpleNamespace
import hashlib,json,math,re,statistics
B=Path(__file__).resolve().parent
PLAN=json.loads((B/'decoder-plan.json').read_text())
helpers={}
for name,pin in PLAN['scoring_helpers'].items():
 raw=(B/pin['name']).read_bytes();assert len(raw)==pin['bytes']and hashlib.sha256(raw).hexdigest()==pin['sha256']
 scope={'__name__':'fixed_brid_'+name,'__file__':str(B/pin['name'])};exec(compile(raw,str(B/pin['name']),'exec'),scope);helpers[name]=scope

def score(case,row,source_path):
 result=dict(id=case['id'],name=case['name'],beat_numeric_pass=False,downbeat_numeric_pass=False,both_numeric_pass=False,qualified=False)
 try:
  if row is None:raise ValueError('Native case missing')
  source=case['source'];frames=row['prepared_frames']
  if not(row['source']==source_path and row['source_sha256']==source['sha256'] and row['source_bytes']==source['bytes']):raise ValueError('Native source identity differs')
  if not(row['passed']is True and row['analysis_status']in('Estimated','Unknown') and row['analysis_error']=='' and row['cache_hit']is False):raise ValueError('Native analysis failed or reused cache')
  if not(type(frames)is int and 0<frames<=60*48000+4096 and row['prepared_bytes']==frames*8 and row['prepared_rate_hz']==48000 and row['analysis_frames']==frames and re.fullmatch('[0-9a-f]{64}',row['pcm_sha256']) and row['analysis_pcm_sha256']==row['pcm_sha256']):raise ValueError('Native prepared clock/identity differs')
  events=row['beats'];previous=-1
  if not(type(events)is list and len(events)<=4096):raise ValueError('Native event bound differs')
  for event in events:
   if not(type(event)is dict and set(event)=={'frame','downbeat'} and type(event['frame'])is int and previous<event['frame']<frames and type(event['downbeat'])is bool):raise ValueError('Invalid native event')
   previous=event['frame']
  seconds=[v['frame']/48000 for v in events]
  bpm=statistics.median(60*48000/(b['frame']-a['frame'])for a,b in zip(events,events[1:]))if len(events)>=2 else None
  summary=round(bpm,1)if bpm is not None and 20<=bpm<=400 else None
  if row.get('summary_bpm')!=summary or row['analysis_status']!=('Estimated'if summary is not None else'Unknown'):raise ValueError('Native summary differs from its beat map')
  intervals=helpers['admission']['source_intervals'](seconds,frames,48000)
  truth=case['reference_seconds_text'];refs=[Decimal(t)for t in truth]
  if not refs or any(not t.is_finite()or t<0 or t*44100>=source['source_geometry']['frames'] or t*48000>=frames for t in refs)or any(a>=b for a,b in zip(refs,refs[1:])):raise ValueError('Reference clock differs')
  if type(case['bar_positions'])is not list or len(case['bar_positions'])!=len(refs)or any(type(v)is not int or v not in(1,2)for v in case['bar_positions']):raise ValueError('Bar-position reference differs')
  metrics=helpers['challenge']['item_metrics'](SimpleNamespace(metrics=helpers['common']['metrics']),dict(reference_seconds=refs,reference_seconds_text=truth),seconds,intervals,[])
  downbeat_ref=[float(t)for t,pos in zip(refs,case['bar_positions'])if pos==1]
  downbeat_events=[dict(seconds=v['frame']/48000)for v in events if v['downbeat']]
  downbeat,_=helpers['common']['metrics'](downbeat_ref,downbeat_events,.070)
  result.update(operational_status=row['analysis_status'],beat=metrics,downbeat=downbeat,beat_numeric_pass=metrics['per_item_accuracy_screen'],downbeat_numeric_pass=downbeat['f1']>=.90,
   prepared_frames=frames,pcm_sha256=row['pcm_sha256'],estimated_events=len(events),reference_events=len(refs),downbeat_reference_events=len(downbeat_ref))
  result['both_numeric_pass']=result['beat_numeric_pass']and result['downbeat_numeric_pass']
 except(KeyError,ValueError,TypeError,ZeroDivisionError,OverflowError)as error:
  result.update(operational_status='Failed',error=dict(type=type(error).__name__,message=str(error)))
 return result

def rows(raw):
 def pairs(items):
  out={}
  for key,value in items:
   if key in out:raise ValueError('Duplicate JSON key')
   out[key]=value
  return out
 if type(raw)is not bytes or not raw.endswith(b'\n')or len(raw)>16*1024**2:raise ValueError('Native stream incomplete/oversized')
 values=[json.loads(line,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in()).throw(ValueError(x)))for line in raw.splitlines()]
 if not values or values[-1].get('kind')!='production-bpm-complete' or len(values)>94:raise ValueError('Native terminal missing')
 for index,row in enumerate(values[:-1]):
  if row.get('ordinal')!=index or type(row.get('ordinal'))is not int or row.get('kind')!='production-bpm-case' or row.get('schema')!=1:raise ValueError('Native order/schema differs')
 return values[:-1],values[-1]
