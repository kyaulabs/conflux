"""Score a complete fixed decoder stream with the unchanged BRID reference scorer."""
from pathlib import Path
import argparse,json,hashlib,importlib.util
B=Path(__file__).resolve().parent

def read(path,limit=16777216):
 raw=Path(path).read_bytes();assert len(raw)<=limit;return raw

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--protocol',type=Path,required=True);parser.add_argument('--native-directory',type=Path,required=True);parser.add_argument('--predictions',type=Path,required=True);parser.add_argument('--prediction-result',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);a=parser.parse_args()
 assert all(p.is_absolute()for p in [a.protocol,a.native_directory,a.predictions,a.prediction_result,a.output]);assert not a.output.exists()
 frozen=json.loads((B/'decoder-plan.json').read_text());protocol_raw=read(a.protocol);assert hashlib.sha256(protocol_raw).hexdigest()==frozen['reference_protocol_sha256'];protocol=json.loads(protocol_raw)
 assert protocol['fixed_denominator']==93 and protocol['gates']==frozen['gates']and [c['id']for c in protocol['cases']]==list(range(1,94))
 receipt=json.loads(read(a.prediction_result));raw=read(a.predictions);assert receipt['complete']and receipt['denominator']==93 and receipt['all_minimal_roundtrips_exact']and receipt['no_reference_annotations_read']
 assert hashlib.sha256(raw).hexdigest()==receipt['predictions_sha256']and raw.endswith(b'\n')
 predictions=[json.loads(l)for l in raw.splitlines()];assert len(predictions)==93 and [p['id']for p in predictions]==list(range(1,94))
 spec=importlib.util.spec_from_file_location('fixed_bdec_score',B/'score_brid.py');score=importlib.util.module_from_spec(spec);spec.loader.exec_module(score)
 variants={name:[]for name in ['minimal','official_3_4','candidate_2_3_4']}
 for case,pred in zip(protocol['cases'],predictions,strict=True):
  native_raw=read(a.native_directory/f"{case['id']:04d}.stdout.jsonl",1048576);native,terminal=score.rows(native_raw);assert len(native)==1 and terminal['complete']and terminal['passed']and terminal['expected']==terminal['completed']==1
  native=native[0];assert native['pcm_sha256']==pred['source_pcm_sha256']and set(pred['outcomes'])==set(variants)
  for name,rows in variants.items():
   outcome=pred['outcomes'][name]
   if outcome['state']=='Returned':
    row=dict(native,beats=outcome['beats'],summary_bpm=outcome['summary_bpm'],analysis_status='Estimated'if outcome['summary_bpm']is not None else'Unknown')
    assert outcome['prepared_frames']==native['prepared_frames']
    if name=='minimal':assert outcome['roundtrip_exact']and row['beats']==native['beats']and row['summary_bpm']==native['summary_bpm']
   else:row=None
   result=score.score(case,row,native['source']);result['decoder_outcome']=outcome['state']
   if outcome['state']!='Returned':result['decoder_error']=outcome['error']
   rows.append(result)
 report={'schema':1,'kind':'BRID93_fixed_in_sample_decoder_comparison','denominator':93,'gates':frozen['gates'],'qualified':False,'confidence':'Unknown','held_out':False,'production_change':False,'model':'unchanged_Final0','source_clock_hz':48000,'references_read_after_all_predictions_persisted':True,'prediction_sha256':receipt['predictions_sha256'],'prediction_plan_sha256':receipt['plan_sha256'],'variants':{}}
 for name,rows in variants.items():
  failures=sum(r['operational_status']=='Failed'for r in rows);micro=None
  if failures==0:
   tp=sum(r['downbeat']['matched_beats']for r in rows);fp=sum(r['downbeat']['false_positives']for r in rows);fn=sum(r['downbeat']['false_negatives']for r in rows)
   micro={'matched':tp,'extras':fp,'misses':fn,'F1':2*tp/(2*tp+fp+fn)if 2*tp+fp+fn else 0.}
  report['variants'][name]={'cases':rows,'denominator':93,'failures':failures,'beat_passes':sum(r['beat_numeric_pass']for r in rows),'downbeat_passes':sum(r['downbeat_numeric_pass']for r in rows),'both_passes':sum(r['both_numeric_pass']for r in rows),'downbeat_micro':micro,'qualified':False}
 a.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
 print(json.dumps({k:{kk:vv for kk,vv in v.items()if kk!='cases'}for k,v in report['variants'].items()},indent=2))
if __name__=='__main__':main()
