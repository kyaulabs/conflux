"""Fixed postprocessing of complete, source-validated BRID logits; no model or labels."""
from pathlib import Path
import os,sys,json,hashlib,zipfile,importlib.util,time
from importlib.machinery import SourceFileLoader
B=Path('/operations');O=Path('/work');C=Path('/captures');N=Path('/native-cases')

def read_json(path,maximum=1048576):
 raw=path.read_bytes();assert len(raw)<=maximum;return json.loads(raw)

def load_module(name,path):
 spec=importlib.util.spec_from_loader(name,SourceFileLoader(name,str(path)));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def verify_capture_pins(plan):
 for pin in plan['capture_pins']:
  root=C if pin['kind']=='capture'else N
  assert pin['kind']in('capture','native')and Path(pin['name']).name==pin['name']
  raw=(root/pin['name']).read_bytes();assert len(raw)==pin['bytes']and hashlib.sha256(raw).hexdigest()==pin['sha256']

def main():
 start=time.monotonic();plan=read_json(B/'prediction-plan.json');assert plan['fixed_denominator']==93 and [c['id']for c in plan['cases']]==list(range(1,94))
 assert not (O/'predictions.jsonl').exists()and not(O/'prediction-result.json').exists()
 verify_capture_pins(plan)
 for pin in plan['files']:
  raw=(B/pin['name']).read_bytes();assert len(raw)==pin['bytes']and hashlib.sha256(raw).hexdigest()==pin['sha256']
 overlay=O/'overlay';overlay.mkdir(mode=0o700);expanded=0
 for pin in plan['files']:
  if not pin['name'].endswith('.whl'):continue
  with zipfile.ZipFile(B/pin['name'])as z:
   for info in z.infolist():
    assert not Path(info.filename).is_absolute()and '..'not in Path(info.filename).parts and ((info.external_attr>>16)&0o170000)!=0o120000
    expanded+=info.file_size;assert expanded<200<<20
   z.extractall(overlay)
 sys.path.insert(0,str(overlay))
 import numpy as np,torch,madmom,scipy
 assert torch.__version__=='2.11.0+cpu'and torch.version.cuda is None and np.__version__=='2.5.4'and scipy.__version__=='1.17.1'and madmom.__version__=='0.17.dev0'
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 post=load_module('frozen_beat_post',B/'pinned-postprocessor.py.txt');prod=load_module('frozen_production_worker',B/'production_worker.py')
 from madmom.features.downbeats import DBNDownBeatTrackingProcessor
 processors={'minimal':post.Postprocessor('minimal',50),'official_3_4':post.Postprocessor('dbn',50),'candidate_2_3_4':post.Postprocessor('dbn',50)}
 processors['candidate_2_3_4'].dbn=DBNDownBeatTrackingProcessor(**plan['DBN_parameters'])
 for name in ['official_3_4','candidate_2_3_4']:
  dbn=processors[name].dbn;assert dbn.map is map and dbn.fps==50 and dbn.threshold==.05 and dbn.correct
  assert dbn.beats_per_bar.tolist()==([3,4]if name=='official_3_4'else[2,3,4])
  assert all(h.observation_model.observation_lambda==16 for h in dbn.hmms)
 rows=[];all_exact=True
 for case in plan['cases']:
  assert time.monotonic()-start<600
  identifier=case['id'];meta=read_json(C/f'{identifier:04d}.json');raw=(C/f'{identifier:04d}.npz').read_bytes()
  assert len(raw)==meta['array_bytes']and hashlib.sha256(raw).hexdigest()==meta['array_sha256']
  assert meta['case_id']==identifier and meta['frames']==case['prepared_frames']and meta['pcm_sha256']==case['pcm_sha256']and meta['calls']==1
  assert meta['production_worker_sha256']==hashlib.sha256((B/'production_worker.py').read_bytes()).hexdigest()
  native=[json.loads(x)for x in(N/f'{identifier:04d}.stdout.jsonl').read_text().splitlines()]
  assert len(native)==2 and native[0]['passed']and native[1]['complete']and native[1]['passed']and native[1]['expected']==native[1]['completed']==1
  native=native[0];assert native['pcm_sha256']==native['analysis_pcm_sha256']==case['pcm_sha256']and native['prepared_frames']==native['analysis_frames']==case['prepared_frames']
  assert native['source_sha256']==case['source_sha256']and native['source_bytes']==case['source_bytes']and native['prepared_rate_hz']==48000 and native['prepared_bytes']==case['prepared_frames']*8
  with np.load(C/f'{identifier:04d}.npz',allow_pickle=False)as a:
   assert a.files==['beat','downbeat','mask'];beat=a['beat'].copy();down=a['downbeat'].copy();mask=a['mask'].copy()
  assert beat.dtype==down.dtype==np.dtype('<f4')and mask.dtype==np.bool_ and beat.shape==down.shape==mask.shape and beat.ndim==1 and len(beat)==meta['logit_frames']
  assert np.isfinite(beat).all()and np.isfinite(down).all()
  expected=np.array([k*48000<case['prepared_frames']*50 for k in range(len(beat))]);assert np.array_equal(mask,expected)
  row={'id':identifier,'logits_sha256':meta['array_sha256'],'source_pcm_sha256':case['pcm_sha256'],'outcomes':{}}
  for name,proc in processors.items():
   try:
    a,d=proc(torch.from_numpy(beat.copy()),torch.from_numpy(down.copy()),torch.from_numpy(mask.copy()));a=[float(v)for v in a];d=[float(v)for v in d]
    bpm,_=prod.summarize_beats(a,case['prepared_frames']);encoded=prod.encode_result(case['prepared_frames'],case['pcm_sha256'],bpm,a,d)
    encoded_rows=[json.loads(x)for x in encoded.splitlines()];header=encoded_rows[0];events=encoded_rows[1:]
    outcome={'state':'Returned','summary_bpm':bpm,'beats':events,'encoded_sha256':hashlib.sha256(encoded).hexdigest(),'prepared_frames':case['prepared_frames'],'confidence':'Unknown','qualified':False}
    if name=='minimal':
     exact=outcome['encoded_sha256']==meta['result_sha256']and events==native['beats']and bpm==native['summary_bpm'];outcome['roundtrip_exact']=exact;all_exact=all_exact and exact
   except Exception as error:
    outcome={'state':'Failed','error':{'type':type(error).__name__,'message':str(error)[:1000]},'confidence':'Unknown','qualified':False}
    if name=='minimal':all_exact=False
   row['outcomes'][name]=outcome
  rows.append(row)
  with(O/'predictions.jsonl').open('a')as f:f.write(json.dumps(row,separators=(',',':'),allow_nan=False)+'\n')
 verify_capture_pins(plan)
 result={'schema':1,'complete':len(rows)==93 and all_exact,'denominator':93,'all_minimal_roundtrips_exact':all_exact,'outcome_failures':{name:sum(r['outcomes'][name]['state']!='Returned'for r in rows)for name in processors},'elapsed_seconds':time.monotonic()-start,'no_reference_annotations_read':True,'model_loaded':False,'GPU_started':False,'qualified':False,'confidence':'Unknown','plan_sha256':hashlib.sha256((B/'prediction-plan.json').read_bytes()).hexdigest(),'predictions_sha256':hashlib.sha256((O/'predictions.jsonl').read_bytes()).hexdigest()}
 (O/'prediction-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));sys.exit(0 if result['complete']else 1)
if __name__=='__main__':main()
