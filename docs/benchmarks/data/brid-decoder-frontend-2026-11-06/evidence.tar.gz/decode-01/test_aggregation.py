"""Temporary evidence-pipeline checks: full denominator, failed outcomes and incomplete-input rejection."""
from pathlib import Path
import json,copy,hashlib,importlib.util,subprocess,sys,os,shutil
B=Path(__file__).resolve().parent;T=B/'aggregation-fixture';assert not T.exists();T.mkdir(mode=0o700)
try:
 spec=importlib.util.spec_from_file_location('original_fixture',B/'original_test_score_brid.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
 for name in ['score_predictions.py','score_brid.py','admission.py','challenge.py','common.py']:(T/name).write_bytes((B/name).read_bytes())
 (T/'native').mkdir();cases=[];predictions=[]
 for i in range(1,94):
  case,row=f.fixture();case.update(id=i,name='generated_denominator_fixture_'+str(i));row.update(kind='production-bpm-case',schema=1,ordinal=0);cases.append(case)
  (T/'native'/f'{i:04d}.stdout.jsonl').write_text(json.dumps(row)+'\n'+json.dumps({'schema':1,'kind':'production-bpm-complete','complete':True,'passed':True,'expected':1,'completed':1})+'\n')
  good={'state':'Returned','roundtrip_exact':True,'summary_bpm':120.,'prepared_frames':row['prepared_frames'],'beats':copy.deepcopy(row['beats'])};wrong=copy.deepcopy(good)
  for event in wrong['beats']:event['downbeat']=not event['downbeat']
  predictions.append({'id':i,'source_pcm_sha256':row['pcm_sha256'],'outcomes':{'minimal':good,'official_3_4':wrong,'candidate_2_3_4':{'state':'Failed','error':{'type':'GeneratedFailure','message':'retained failure'}}if i==1 else copy.deepcopy(good)}})
 frozen=json.loads((B/'decoder-plan.json').read_text());protocol={'fixed_denominator':93,'gates':frozen['gates'],'cases':cases};raw=(json.dumps(protocol)+'\n').encode();(T/'protocol.json').write_bytes(raw);frozen['reference_protocol_sha256']=hashlib.sha256(raw).hexdigest();(T/'decoder-plan.json').write_text(json.dumps(frozen)+'\n')
 def write_predictions(rows,complete=True):
  raw=(''.join(json.dumps(r)+'\n'for r in rows)).encode();(T/'predictions.jsonl').write_bytes(raw);(T/'receipt.json').write_text(json.dumps({'complete':complete,'denominator':93,'all_minimal_roundtrips_exact':True,'no_reference_annotations_read':True,'predictions_sha256':hashlib.sha256(raw).hexdigest(),'plan_sha256':'0'*64})+'\n')
 command=[sys.executable,'-B',str(T/'score_predictions.py'),'--protocol',str(T/'protocol.json'),'--native-directory',str(T/'native'),'--predictions',str(T/'predictions.jsonl'),'--prediction-result',str(T/'receipt.json')]
 write_predictions(predictions);r=subprocess.run(command+['--output',str(T/'good.json')],capture_output=True,text=True,timeout=15);assert r.returncode==0,r.stderr
 report=json.loads((T/'good.json').read_text());v=report['variants'];assert v['minimal']['both_passes']==93 and v['official_3_4']['beat_passes']==93 and v['official_3_4']['downbeat_passes']==0
 assert v['candidate_2_3_4']['denominator']==93 and v['candidate_2_3_4']['both_passes']==92 and v['candidate_2_3_4']['failures']==1 and v['candidate_2_3_4']['downbeat_micro']is None and not report['qualified']
 checks=['all93_cases_counted_including_failed_candidate','wrong_bar_phase_remains_failure','micro_withheld_for_invalid_case']
 for name,rows,complete in [('missing',predictions[:-1],True),('incomplete',predictions,False)]:
  write_predictions(rows,complete);out=T/(name+'.json');r=subprocess.run(command+['--output',str(out)],capture_output=True,text=True,timeout=15);assert r.returncode!=0 and not out.exists();checks.append(name+'_prediction_stream_rejected')
 result={'passed':True,'checks':checks,'synthetic_only':True,'model_or_GPU':False};(B/'aggregation-test-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

finally:shutil.rmtree(T)
