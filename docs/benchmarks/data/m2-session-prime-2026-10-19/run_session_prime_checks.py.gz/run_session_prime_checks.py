import hashlib,json,os,signal,subprocess,time
from pathlib import Path

b=Path('benchmarks-local/m2-live-delivery-2026-10-19')
names=['CMakeLists.txt',str(b/'run_session_prime_checks.py'),'tools/coverage/requirements.txt','.github/workflows/build.yml','tools/experiments/preparation_controller_check.cpp','tools/experiments/private_routing_check.py','tools/coverage/run.py','tools/experiments/manual_routing_check.cpp']
for folder in ['src','qml','tests','tools/stems']:
    names += [str(p) for p in Path(folder).rglob('*') if p.is_file() and p.suffix in {'.cpp','.hpp','.qml','.py'}]
def pins():
    return {n:dict(bytes=Path(n).stat().st_size,sha256=hashlib.sha256(Path(n).read_bytes()).hexdigest()) for n in sorted(set(names))}
initial=pins(); (b/'session-prime-source-pins.json').write_text(json.dumps(initial,indent=2)+'\n')
rows=[]
artifacts={}
def artifact_pins(folder):
    binaries=['conflux','conflux-live-stem-bridge-test','conflux-prepared-track-store-test','conflux-manual-routing-check','conflux-preparation-controller-check'] if folder!='build/owner-tsan' else ['conflux-audio-live-owner-test','conflux-audio-live-recovery-test']
    return {str(Path(folder)/n):dict(bytes=(Path(folder)/n).stat().st_size,sha256=hashlib.sha256((Path(folder)/n).read_bytes()).hexdigest()) for n in binaries}
env=os.environ|{'QT_QPA_PLATFORM':'offscreen','QT_QUICK_BACKEND':'software','QT_QUICK_CONTROLS_STYLE':'Basic'}
launcher="import runpy, signal, sys\ndef stop(*_):\n    signal.signal(signal.SIGTERM, signal.SIG_IGN)\n    raise InterruptedError('Controller validation stage timed out')\nsignal.signal(signal.SIGTERM, stop)\nsys.argv = sys.argv[1:]\nrunpy.run_path(sys.argv[0], run_name='__main__')\n"
private=lambda kind:['python3','-c',launcher,'tools/experiments/private_routing_check.py','build/dev/conflux-'+('preparation-controller-check' if kind=='preparation' else 'manual-routing-check'),str(b/('session-prime-normal-'+kind+'-01'))]
commands=[
    ('session-prime-full-build',['cmake','--build','build/dev','--parallel','2'],600),
    ('session-prime-ctest',['ctest','--test-dir','build/dev','--output-on-failure','--timeout','120'],900),
    ('session-prime-smoke',['build/dev/conflux','--smoke-test'],30),
    ('session-prime-normal-routing',private('routing'),180),
    ('session-prime-normal-preparation',private('preparation'),180),
    ('session-prime-tsan-configure',['cmake','-S','.','-B','build/owner-tsan','-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DBUILD_TESTING=ON','-DCMAKE_CXX_FLAGS=-fsanitize=thread -fno-omit-frame-pointer -fno-pie -O1 -g','-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=thread -no-pie'],90),
    ('session-prime-tsan-build',['cmake','--build','build/owner-tsan','--target','conflux-audio-live-owner-test','conflux-audio-live-recovery-test','--parallel','2'],600),
    ('session-prime-tsan-test',['ctest','--test-dir','build/owner-tsan','-R','^(audio-live-owner|audio-live-recovery)$','--output-on-failure'],90),
    ('session-prime-coverage',['benchmarks-local/coverage-venv/bin/python','tools/coverage/run.py','--private-routing','--jobs','2'],1500)
]
for name,cmd,limit in commands:
    assert pins()==initial
    start=time.monotonic(); timed=False
    with (b/(name+'.log')).open('w') as log:
        c=subprocess.Popen(cmd,env=env|({'TSAN_OPTIONS':'halt_on_error=1'} if name=='session-prime-tsan-test' else {}),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try: code=c.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            timed=True; os.killpg(c.pid,signal.SIGTERM)
            try: code=c.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(c.pid,signal.SIGKILL); code=c.wait(timeout=5)
    row=dict(stage=name,command=cmd,exit=code,timed_out=timed,elapsed_seconds=time.monotonic()-start)
    rows.append(row); (b/'session-prime-functional-result.json').write_text(json.dumps(rows,indent=2)+'\n'); print(json.dumps(row),flush=True)
    if code==0 and name in {'session-prime-full-build','session-prime-tsan-build','session-prime-coverage'}:
        folder={'session-prime-full-build':'build/dev','session-prime-tsan-build':'build/owner-tsan','session-prime-coverage':'build/coverage'}[name]
        artifacts[folder]=artifact_pins(folder)
        (b/'session-prime-artifact-pins.json').write_text(json.dumps(artifacts,indent=2)+'\n')
    if code:
        print((b/(name+'.log')).read_text()[-6000:],flush=True)
        raise SystemExit(code)
assert pins()==initial
for folder,expected in artifacts.items(): assert artifact_pins(folder)==expected,folder
(b/'session-prime-source-stable.json').write_text(json.dumps(dict(status='all_pins_unchanged',files=len(initial)),indent=2)+'\n')
