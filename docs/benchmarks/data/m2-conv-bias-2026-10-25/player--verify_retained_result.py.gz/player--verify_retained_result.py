#!/usr/bin/env python3
"""Parse the saved failed run; never start a process or query the live host."""
from collections import Counter
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics
import sys

BASE = Path(__file__).resolve().parent
FIX = BASE.parent/'parser-mode-fix-01'
sys.dont_write_bytecode = True


def audit(event, args):
    if event.startswith(('subprocess.', 'socket.', 'os.exec', 'os.spawn', 'os.fork')) or event in ('os.system', 'os.kill', 'os.killpg'):
        raise RuntimeError('Retained-file verification forbids ' + event)
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)) and os.fsdecode(args[0]).startswith(('/proc/', '/sys/', '/dev/')):
        raise RuntimeError('Live host reads forbidden')


sys.addaudithook(audit)


def pin(path):
    raw = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    return json.loads(Path(path).read_bytes())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def stats(values):
    values = sorted(values)
    assert values and all(math.isfinite(x) and x >= 0 for x in values)
    return {'count': len(values), 'minimum': values[0], 'median': statistics.median(values),
            'p99_nearest_rank': values[math.ceil(.99*len(values))-1], 'maximum': values[-1]}


def main():
    plan = read(BASE/'plan.json')
    for row in read(BASE/'root-packet-manifest-01.json')['files'].values():
        assert pin(row['path']) == row
    original = load('saved_original_driver', BASE/'run_host_player.py')
    original.validate_plan(plan)
    original.verify_files(plan)
    regression = read(FIX/'root-regression-verification-01.json')
    for row in regression['results']:
        assert pin(row['driver']['path']) == row['driver']
        assert pin(row['log']['path']) == row['log']
    assert regression['status'] == 'red_then_green'
    fixed = load('saved_run_binding_fixed_driver', FIX/'run_host_player.py')
    before, after = (BASE/'run_host_player.py').read_text(), (FIX/'run_host_player.py').read_text()
    line = '    consumer.MODE=MODE  # Bind the private reader to this exact packet, never another run.\n'
    assert after.count(line) == 1 and after.replace(line, '') == before
    result, report, owner = (read(BASE/name) for name in ('output-01/result.json', 'diagnostic-assessment.json', 'dispatch-01.json'))
    native = result['native']
    observations = [original.decode(line) for line in (BASE/'output-01/observations.jsonl').read_bytes().splitlines()]
    hops = [row for row in observations if row.get('type') == 'record' and row.get('hop_service_present') is True]
    try:
        original.parse_capture(BASE/'host-capture-01', hops, native)
    except ValueError as error:
        assert str(error) == 'Native capture identity/parent/errors differ'
    else:
        raise AssertionError('Original run-binding failure was not reproduced')
    parsed = fixed.parse_capture(BASE/'host-capture-01', hops, native)
    assert parsed['complete'] and parsed['mode'] == plan['mode']
    assert parsed['native_completed_request_count'] == len(parsed['requests']) == 18
    assert parsed['published_hops'] == len(hops) == 17
    assert parsed['intentionally_aborted_final_request'] is None
    assert all(x['input_identity_match'] and x['gpu_interval']['complete'] for x in parsed['requests'])
    runtime = {(x['pid'], x['start_ticks']) for x in result['cleanup']['runtime_processes']}
    service = {(x['pid'], x['start_ticks']) for x in result['cleanup']['service_processes']}
    assert runtime == {(parsed['native']['pid'], parsed['native']['start_ticks'])}
    assert service == {(parsed['service']['pid'], parsed['service']['start_ticks'])}
    for name, row in result['capture'].items():
        original.verify_capture(BASE/('output-01/native.'+name+'.log'), row, math.inf)
    measurement = original.validate_measurement(native)
    latency = stats([row['hop_service_ms'] for row in hops])
    assert latency['p99_nearest_rank'] == result['observations']['service_hops']['nearest_rank_p99_ms']
    misses = sum(row['hop_service_ms'] >= 4095 for row in hops)
    assert misses == result['observations']['service_hops']['at_or_above_target'] == 8
    assert result['passed'] is False and report['status'] == 'failed' and owner['passed'] is False
    assert 'finished_monotonic' not in owner and 'exit_code' not in owner
    cleanup, guard = (read(BASE/name) for name in ('root-post-host-cleanup-01.json', 'root-post-host-guard-01.json'))
    assert cleanup['passed'] and guard['passed'] and cleanup['owner_terminal_exit'] == 143
    assert result['cleanup_proven'] and result['owned_cache_removed'] and not result['cache_preserved']
    assert result['cleanup']['remaining_known_processes'] == [] and all(result['cleanup']['owned_group_absent'].values())
    assert report['post_run_frozen_inputs_unchanged'] and report['within_command_budget']
    recording = native['recording']
    assert recording['acceptedFrames'] == recording['writtenFrames'] == native['recorded_audio']['frames'] == 6064384
    assert recording['overflowFrames'] == 0 and recording['status'] == 'Complete'
    steady = sum(x['starved_frames'] for x in native['intervals'] if x['kind'] == 'steady')
    controls = sum(x['starved_frames'] for x in native['intervals'] if x['kind'] != 'steady')
    assert steady == native['steady_starved_frames'] == 94720
    assert controls == native['control_starved_frames'] == 1285888
    assert all(x['starved_b'] == 0 for x in native['intervals'])
    assert len(native['manual_controls']) == 16 and all(x['acknowledged'] for x in native['manual_controls'])
    assert native['shutdown_completed'] and parsed['capture_summary']['native_shutdown']['graceful_complete']
    assert native['observation_counters']['dropped'] == 0
    hosts = [json.loads(line) for line in (BASE/'output-01/host-observations.jsonl').read_bytes().splitlines()]
    assert hosts and all(not x['read_errors'] and x['power']['ac_online'] and x['power']['lid_open'] for x in hosts)
    requests = []
    for row in parsed['requests']:
        host = row['host']
        inside = [x for x in hosts if host['begin_ns'] < x['monotonic_ns'] < host['end_ns']]
        requests.append({'request_id': row['request_id'], 'generation': row['generation'], 'classification': row['classification'],
            'input_sha256': row['producer_input_identity']['sha256'],
            'service_ms': None if row['published_hop'] is None else row['published_hop']['hop_service_ms'],
            'native_elapsed_ms': row['native_metrics']['elapsed_ms'], 'graph_compute_ms': row['native_metrics']['graph_compute_ms'],
            'host_record_ms': host['record_ns']/1e6, 'coarse_GPU_ms': host['gpu_interval_ns']/1e6,
            'GPU_fraction_of_graph_percent': 100*host['gpu_interval_ns']/host['wall_ns'],
            'interior_profile_sample_counts': dict(Counter(x['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'] for x in inside)),
            'interior_package_C': [x['temperatures_millidegrees_C']['/sys/class/thermal/thermal_zone7/temp']/1000 for x in inside]})
    worst = max((x for x in requests if x['service_ms'] is not None), key=lambda x: x['service_ms'])
    late = [x for x in requests if x['service_ms'] is not None and x['service_ms'] >= 4095]
    assert len(late) == 8 and worst['request_id'] == 12
    summary = {'schema': 1, 'status': 'failed_workload_reparsed_with_run_binding_fix', 'qualified': False, 'timing_qualification': False,
        'scope': 'Saved120s instrumented visible Best-quality run. Original workload, launcher and interrupted owner remain failed; no hardware rerun or deadline renewal.',
        'evidence': {name: pin(BASE/name) for name in ('plan.json', 'readiness.json', 'dispatch-01.json', 'diagnostic-assessment.json',
            'output-01/result.json', 'output-01/observations.jsonl', 'output-01/host-observations.jsonl', 'output-01/master.wav',
            'root-post-host-cleanup-01.json', 'root-post-host-guard-01.json', 'root-guard-journal-01.json',
            'root-owner-interruption-investigation-01.json', 'verify_retained_result.py')},
        'run_binding_fix': pin(FIX/'root-regression-verification-01.json'), 'measurement': measurement,
        'service_ms': latency, 'strict_target_ms': 4095, 'misses': misses, 'service_target_met': False,
        'native_completed_requests': 18, 'published_hops': 17, 'matching_input_identities': 18, 'valid_coarse_GPU_intervals': 18,
        'requests': requests, 'worst_published_request': worst,
        'slow_hop_GPU_fraction_of_graph_percent': stats([x['GPU_fraction_of_graph_percent'] for x in late]),
        'UI': {'reported_control_acknowledgements': 16, 'coverage': native['ui_coverage'], 'qualified': False},
        'audio': {'steady_starved_frames': steady, 'steady_starved_seconds': steady/48000,
            'control_interval_starved_frames': controls, 'control_interval_starved_seconds': controls/48000,
            'peer_starved_frames': 0, 'invalid_buffers': native['invalid_buffers'], 'source_read_failures': native['source_read_failures'],
            'callback_execution_deadline_misses': native['execution_deadline_misses'], 'recording': recording,
            'recorded_audio': native['recorded_audio'], 'availability_passed': False, 'physical_output_or_listening_qualified': False},
        'cancellation_and_seeks': {'incomplete_generation_seek_exercised': result['observations']['incomplete_generation_seek']['exercised'],
            'replay_count': native['replay_count'], 'obsolete_request': {'id': 2, 'classification': parsed['requests'][1]['classification']},
            'packet_discards': result['observations']['kind_counts'].get('PacketDiscarded', 0),
            'source_cursor_recovery': [{'kind': x['kind'], 'issued_to_observed_cursor_ms': (x['recovered_cursor_observed_ns']-x['issued_ns'])/1e6} for x in native['controls']],
            'native_shutdown': parsed['capture_summary']['native_shutdown'], 'native_in_flight_preemption_proved': False,
            'scope': 'Supersession, discard and recovery, not executing GPU cancellation or a cancellation-latency bound.'},
        'thermal': {'profile_sample_counts': dict(Counter(x['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'] for x in hosts)),
            'maximum_sampled_package_C': max(x['temperatures_millidegrees_C']['/sys/class/thermal/thermal_zone7/temp'] for x in hosts)/1000,
            'guard_entries': read(BASE/'root-guard-journal-01.json')['entries'], 'guard_unchanged': True, 'limits_modified': False,
            'scope': 'Discrete temperature/profile observations and guard events, not continuous temperatures or causal clock/power proof.'},
        'cleanup_verified_separately': True, 'frozen_files_unchanged': True, 'complete_original_owner_receipt': False,
        'owner_failure': {'terminal_exit': 143, 'known_cause': False, 'restored_or_restarted': False},
        'original_parser_failure': 'Stale consumer MODE rejected the current run; original capture and failed receipts are unchanged.',
        'interpretation': 'All8 misses remain almost entirely inside inclusive GPU graph intervals. No isolated speedup or current performance-profile comparison is proved.',
        'remaining_gates': 'M2/M3 and0.1.0 remain open; Best quality and strict4095ms target unchanged.'}
    for name, value in (('root-capture-reparse-01.json', parsed), ('root-result-verification-01.json', summary)):
        with (BASE/name).open('x') as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write('\n')
    print(json.dumps({'status': summary['status'], 'service_ms': latency, 'misses': misses,
        'steady_starved_seconds': steady/48000, 'coarse_GPU_worst_ms': worst['coarse_GPU_ms'],
        'known_processes_absent': True, 'complete_original_owner_receipt': False, 'qualified': False}))


if __name__ == '__main__':
    main()
