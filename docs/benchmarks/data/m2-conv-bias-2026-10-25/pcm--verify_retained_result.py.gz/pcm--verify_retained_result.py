#!/usr/bin/env python3
"""Parse retained files only; never launch a workload or observe the live host."""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent


def audit(event, args):
    if event.startswith(('subprocess.', 'socket.', 'os.exec', 'os.spawn', 'os.fork')) or event in ('os.kill', 'os.killpg', 'signal.pthread_kill'):
        raise RuntimeError('Retained-file verification forbids execution/network/signals: ' + event)
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        name = os.fsdecode(args[0])
        if name == '/proc' or name.startswith(('/proc/', '/sys/', '/dev/')):
            raise RuntimeError('Retained-file verification forbids live host reads: ' + name)


sys.addaudithook(audit)


def read(path, expected=None):
    path = Path(path)
    raw = path.read_bytes()
    pin = {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    if expected is not None:
        assert all(pin[k] == expected[k] for k in ('bytes', 'sha256')), str(path)
    return raw, pin


def stats(values):
    values = sorted(values)
    assert values and all(math.isfinite(v) and v >= 0 for v in values)
    return {'count': len(values), 'minimum': values[0], 'median': statistics.median(values),
            'p99_nearest_rank': values[math.ceil(.99 * len(values)) - 1], 'maximum': values[-1]}


def main():
    plan_raw, plan_pin = read(BASE/'execution-plan-01.json')
    plan = json.loads(plan_raw)
    driver_pin = plan['sources']['launcher']
    raw, _ = read(driver_pin['path'], driver_pin)
    spec = importlib.util.spec_from_file_location('retained_pcm_driver', driver_pin['path'])
    driver = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = driver
    exec(compile(raw, driver_pin['path'], 'exec'), driver.__dict__)
    driver.validate_plan(plan)
    report_raw, report_pin = read(BASE/'output-01/result.json')
    report = driver.decode(report_raw)
    _, dispatch_pin = read(BASE/'dispatch-01.json')
    dispatch = driver.decode((BASE/'dispatch-01.json').read_bytes())
    _, cleanup_pin = read(BASE/'root-post-host-cleanup-01.json')
    cleanup = driver.decode((BASE/'root-post-host-cleanup-01.json').read_bytes())
    assert dispatch['passed'] and dispatch['exit_code'] == 0 and not dispatch['errors'] and not dispatch['external_signals']
    assert dispatch['complete_capture'] and not dispatch['remaining_known_processes']
    assert dispatch['owned_groups_absent'] and all(dispatch['owned_groups_absent'].values())
    assert cleanup['cleanup_verified'] and not cleanup['remaining_known_lifetimes'] and not cleanup['errors']
    assert cleanup['groups_absent'] and all(cleanup['groups_absent'].values())
    assert cleanup['same_guard_lifetime_and_files'] and cleanup['settings_changed'] is False
    assert report['qualified'] is False and report['timing_qualification'] is False and report['service_timing_qualification'] is False
    driver.final_gates(report)
    consumer = driver.load_helper('retained_interval', plan['helpers']['consumer'])
    validator = driver.load_helper('retained_host_validator', plan['helpers']['host_validator'])
    streams = {name: read(row['path'], row) for name, row in report['retained_streams'].items()}
    parsed = driver.parse_capture(streams['stderr'][0], streams['stdout'][0], report['ready'], report['requests'], consumer, validator)
    assert parsed == report['host_boundaries']
    assert driver.validate_candidate_graph(streams['stderr'][0]) == report['candidate_graph']
    proof_raw, proof_pin = read(plan['assets']['reference']['path'], plan['assets']['reference'])
    proof = driver.decode(proof_raw)
    assert proof['status'] == 'reproduction_complete' and proof['runtime_sha256'] == driver.FIXED['normal_runtime']
    assert proof['model_sha256'] == driver.FIXED['model'] and proof['completed_requests'] == 16
    assert all(proof[k] is True for k in ('cleanup_complete', 'private_spool_removed', 'pins_unchanged', 'all_outputs_match_closed_B', 'input_sha_match', 'phase_fields_valid'))
    reference = {row['id']: row for row in proof['runtimes'][0]['requests']}
    assert len(reference) == 16 and set(reference) == set(driver.CASE_IDS)
    requests = report['requests']
    for row in requests:
        old = reference[row['case_id']]
        assert old['completed'] and old['input_sha_match'] and old['output_matches_closed_B']
        assert row['output_sha256'] == old['output_sha256'] and row['input_sha256'] == old['input_sha256']
        assert row['producer_identity']['sha256'] == row['written_identity']['sha256'] == old['input_sha256']
    hosts = parsed['records']
    first_ns, last_ns = requests[0]['started_ns'], requests[-1]['finished_ns']
    runtime_samples = [row for row in report['host_observations'] if first_ns <= row['monotonic_ns'] <= last_ns]
    assert runtime_samples and all(not row['read_errors'] and row['power']['ac_online'] and row['power']['lid_open'] for row in runtime_samples)
    profiles = sorted({row['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'] for row in runtime_samples})
    output = {
        'schema': 1, 'status': 'retained_result_verified', 'qualified': False,
        'verification_scope': 'Parse-only under audit denying child processes, network, signals and live /proc, /sys, /dev reads.',
        'evidence': {'plan': plan_pin, 'result': report_pin, 'dispatch': dispatch_pin, 'actual_host_cleanup': cleanup_pin,
                     'reference': proof_pin, 'streams': {k:v[1] for k,v in streams.items()}},
        'completed_requests': 16, 'exact_reference_pcm_matches': 16,
        'candidate_graph': report['candidate_graph'],
        'input_producer_and_written_identity_matches': 16, 'valid_coarse_gpu_intervals': 16,
        'native_elapsed_ms': stats([row['native_metrics']['elapsed_ms'] for row in requests]),
        'native_cpu_ms': stats([row['native_metrics']['inference_cpu_ms'] for row in requests]),
        'graph_compute_ms': stats([row['native_metrics']['graph_compute_ms'] for row in requests]),
        'coarse_gpu_interval_ms': stats([row['gpu_interval_ns']/1e6 for row in hosts]),
        'inclusive_host_record_ms': stats([row['record_ns']/1e6 for row in hosts]),
        'post_first_host_record_ms': stats([row['record_ns']/1e6 for row in hosts[1:]]),
        'host_graph_minus_gpu_interval_ms': stats([(row['wall_ns']-row['gpu_interval_ns'])/1e6 for row in hosts]),
        'gpu_fraction_of_host_graph_percent': stats([100*row['gpu_interval_ns']/row['wall_ns'] for row in hosts]),
        'request_rpc_ms': stats([(row['finished_ns']-row['started_ns'])/1e6 for row in requests]),
        'runtime_host_samples': len(runtime_samples), 'runtime_observed_profiles': profiles,
        'runtime_maximum_selected_temperature_C': max(v for row in runtime_samples for v in row['temperatures_millidegrees_C'].values())/1000,
        'all_observations_maximum_selected_temperature_C': max(v for row in report['host_observations'] for v in row['temperatures_millidegrees_C'].values())/1000,
        'cool_readiness_final_C': report['cool_readiness'][-1]['package_millidegrees_C']/1000,
        'cool_readiness_consecutive_seconds': report['cool_readiness'][-1]['consecutive_span_seconds'],
        'outer_elapsed_seconds': dispatch['finished_monotonic']-dispatch['started_monotonic'],
        'original_operator_age_at_dispatch_seconds': dispatch['operator_clock']['age_seconds'],
        'audio_exercised': False, 'UI_exercised': False, 'cancellation_exercised': False,
        'cleanup_verified': True, 'guard_unchanged': report['guard_before'] == report['guard_after'],
        'latency_gate': {'target_ms': 4095, 'qualified': False, 'reason': 'Native-only quiet requests omit source/read, service, overlap, audio and UI load.'},
        'interpretation': 'The candidate removed48 graph nodes while retaining all16 exact normal-reference outputs and ten full-F32 Flash signatures. This is quiet native-only evidence, not service/audio/UI performance, a paired speedup comparison or runtime promotion. Inclusive GPU intervals are not exclusive kernel timings.'
    }
    path = BASE/'root-result-verification-01.json'
    with path.open('x') as stream:
        json.dump(output, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'status': output['status'], 'receipt': str(path), 'native_elapsed_ms': output['native_elapsed_ms'],
                      'runtime_host_samples': len(runtime_samples), 'profiles': profiles, 'qualified': False}))


if __name__ == '__main__':
    main()
