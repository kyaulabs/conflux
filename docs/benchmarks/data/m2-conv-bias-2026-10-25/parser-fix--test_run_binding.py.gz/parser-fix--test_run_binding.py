"""Generated run-binding regressions; saved files only, no native execution."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
args = argparse.ArgumentParser()
args.add_argument('--driver', type=Path, required=True)
chosen, remaining = args.parse_known_args()
sys.argv = [sys.argv[0], *remaining]
sys.dont_write_bytecode = True


def audit(event, values):
    if event.startswith(('subprocess.', 'socket.', 'os.exec', 'os.spawn', 'os.fork')) or event in ('os.system', 'os.kill', 'os.killpg'):
        raise RuntimeError('Offline regression forbids ' + event)
    if event == 'open' and isinstance(values[0], (str, bytes)) and str(values[0]).startswith(('/proc/', '/sys/', '/dev/')):
        raise RuntimeError('Offline regression forbids live host reads')


sys.addaudithook(audit)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


driver = load('run_binding_driver', chosen.driver)
wire = load('run_binding_wire', ROOT/'build/m2-graph-interval-01/player-consumer-draft-02/test_player_capture_consumer.py')


def bind(value, run_id):
    if isinstance(value, dict):
        for key, child in value.items():
            if key == 'run_id':
                value[key] = run_id
            else:
                bind(child, run_id)
    elif isinstance(value, list):
        for child in value:
            bind(child, run_id)


class RunBindingTests(unittest.TestCase):
    def fixture(self, root, *, abort=False, run_id=None):
        summary, trace, hops, native, hosts = wire.CaptureTests().fixture(root, abort=abort, extra_host=abort)
        for value in (summary, trace):
            bind(value, run_id or driver.MODE)
        wire.CaptureTests().write_trace(root, trace)
        wire.CaptureTests().write_hosts(root, summary, hosts, partial=abort)
        return summary, trace, hops, native, hosts

    def test_current_run_parses_completed_and_aborted_wire(self):
        for abort in (False, True):
            with self.subTest(abort=abort), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                _, _, hops, native, _ = self.fixture(root, abort=abort)
                result = driver.parse_capture(root, hops, native)
                self.assertEqual(result['mode'], driver.MODE)
                self.assertTrue(result['complete'])
                self.assertTrue(result['requests'][0]['input_identity_match'])
                self.assertTrue(result['requests'][0]['gpu_interval']['complete'])
                self.assertFalse(result['qualified'])
                self.assertEqual(result['intentionally_aborted_final_request'] is not None, abort)

    def test_previous_run_rejected_even_when_entire_capture_agrees(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.assertNotEqual(driver.MODE, wire.consumer.MODE)
            _, _, hops, native, _ = self.fixture(root, run_id=wire.consumer.MODE)
            with self.assertRaisesRegex(ValueError, 'Native capture identity/parent/errors differ'):
                driver.parse_capture(root, hops, native)

    def test_each_foreign_run_binding_is_rejected(self):
        for location in ('summary', 'begin', 'complete'):
            with self.subTest(location=location), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                summary, trace, hops, native, hosts = self.fixture(root)
                if location == 'summary':
                    summary['run_id'] = 'foreign'
                else:
                    event = 'run_begin' if location == 'begin' else 'request_complete'
                    row = next(row for row in trace if row['event'] == event)
                    if location == 'begin':
                        row['run_id'] = 'foreign'
                    else:
                        row['gpu_trace']['run_id'] = 'foreign'
                wire.CaptureTests().write_trace(root, trace)
                wire.CaptureTests().write_hosts(root, summary, hosts)
                with self.assertRaises(ValueError):
                    driver.parse_capture(root, hops, native)

    def test_current_run_keeps_input_and_gpu_validation(self):
        for location in ('input', 'gpu'):
            with self.subTest(location=location), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                summary, trace, hops, native, hosts = self.fixture(root)
                if location == 'input':
                    next(row for row in trace if row['event'] == 'request_complete')['gpu_trace']['written_input_identity']['sha256'] = 'f'*64
                else:
                    hosts[0]['gpu_end_available'] = 0
                wire.CaptureTests().write_trace(root, trace)
                wire.CaptureTests().write_hosts(root, summary, hosts)
                with self.assertRaises(ValueError):
                    driver.parse_capture(root, hops, native)


if __name__ == '__main__':
    unittest.main(verbosity=2)
