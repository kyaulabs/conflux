import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

P = Path(__file__).resolve().parent
ROOT = P.parent.parent
base = json.loads((ROOT / 'build/m2-graph-interval-01/build-reuse/argv-plan.json').read_text())
cwd = Path(base['original_compile_cwd'])
original = cwd / 'runtime/audiocpp/libengine_runtime.a'
new_object = P / 'conv_modules.cpp.o'
output = P / 'output-01'


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def members(path):
    raw = path.read_bytes()
    assert raw[:8] == b'!<arch>\n'
    offset, table, result = 8, b'', []
    while offset < len(raw):
        h = raw[offset:offset + 60]
        assert len(h) == 60 and h[58:] == b'`\n'
        size = int(h[48:58])
        data = raw[offset + 60:offset + 60 + size]
        assert len(data) == size
        name = h[:16].decode('ascii').rstrip()
        if name == '//':
            table = data
        elif name not in ('/', '/SYM64/'):
            if name.startswith('/') and name[1:].isdigit():
                i = int(name[1:]); end = table.index(b'\n', i)
                name = table[i:end].decode().removesuffix('/')
            else:
                assert not name.startswith('#1/'), 'Unexpected BSD archive format'
                name = name.removesuffix('/')
            result.append({'name': name, 'bytes': size, 'sha256': hashlib.sha256(data).hexdigest()})
        offset += 60 + size + size % 2
    assert offset == len(raw)
    return result


assert not output.exists()
assert json.loads((P / 'cpu-result-01.json').read_text())['exact_original_candidate_output_match']
source_review = json.loads((P / 'source-review-01.json').read_text())
assert pin(P / 'conv_modules.cpp') == source_review['candidate']
assert pin(Path(source_review['source']['path'])) == source_review['source']
assert pin(P / 'tensor_layout_utils.h')['sha256'] == json.loads((P / 'sibling-header-01.json').read_text())['sha256']
before = pin(original)
old_members = members(original)
assert len(old_members) == 187 and sum(x['name'] == new_object.name for x in old_members) == 1
assert shutil.disk_usage(P).free > 2 * 1024 ** 3
output.mkdir(mode=0o700)
archive = output / original.name
shutil.copyfile(original, archive)
assert pin(archive)['sha256'] == before['sha256']
steps = []
for name, argv, step_cwd in [
    ('replace-only-conv-member', ['/bin/ar', 'r', str(archive), str(new_object)], output),
    ('refresh-index', ['/bin/ranlib', str(archive)], output),
]:
    start = time.monotonic()
    r = subprocess.run(argv, cwd=step_cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    steps.append({'name': name, 'argv': argv, 'cwd': str(step_cwd), 'exit_code': r.returncode,
                  'elapsed_seconds': time.monotonic() - start})
    (P / (name + '.stdout')).write_bytes(r.stdout)
    (P / (name + '.stderr')).write_bytes(r.stderr)
    assert r.returncode == 0, r.stderr
new_members = members(archive)
assert [x['name'] for x in old_members] == [x['name'] for x in new_members]
changed = [i for i, (a, b) in enumerate(zip(old_members, new_members)) if a != b]
assert len(changed) == 1
assert new_members[changed[0]]['name'] == new_object.name
assert new_members[changed[0]]['sha256'] == pin(new_object)['sha256']
argv = base['steps'][-1]['argv'].copy()
argv = [('-Wl,--dependency-file=' + str(output / 'link.d'))
        if x.startswith('-Wl,--dependency-file=') else x for x in argv]
argv[argv.index('-o') + 1] = str(output / 'conflux-stem-runtime')
index = argv.index('runtime/audiocpp/libengine_runtime.a')
argv[index] = str(archive)
link_inputs = []
for arg in argv[1:]:
    if arg.startswith('-') or not arg.endswith(('.o', '.a', '.so')):
        continue
    file = Path(arg)
    file = file if file.is_absolute() else cwd / file
    link_inputs.append(pin(file))
start = time.monotonic()
r = subprocess.run(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
(P / 'runtime-link.stdout').write_bytes(r.stdout)
(P / 'runtime-link.stderr').write_bytes(r.stderr)
steps.append({'name': 'relink-retained-adapter', 'argv': argv, 'cwd': str(cwd),
              'exit_code': r.returncode, 'elapsed_seconds': time.monotonic() - start})
assert r.returncode == 0, r.stderr
assert [pin(Path(x['path'])) for x in link_inputs] == link_inputs
assert pin(original) == before
receipt = {'schema': 1, 'status': 'unpromoted_private_runtime_built',
           'source': source_review, 'original_archive': before, 'new_archive': pin(archive),
           'object': pin(new_object), 'archive_members': len(old_members),
           'unchanged_archive_members': len(old_members) - len(changed),
           'changed_member': new_members[changed[0]], 'link_inputs': link_inputs, 'steps': steps,
           'executable': pin(output / 'conflux-stem-runtime'),
           'model_GPU_audio_UI_started': False,
           'limits': 'Build proof and CPU fixtures only. Exact real-model PCM, candidate activation, GPU behavior and service/audio performance remain untested.'}
(P / 'runtime-build-receipt-01.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'unchanged_archive_members': receipt['unchanged_archive_members'],
                  'candidate': receipt['executable'], 'model_GPU_audio_UI_started': False}))
