import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

P = Path(__file__).resolve().parent
ROOT = P.parent.parent
plan = json.loads((P / 'cpu-build-plan.json').read_text())
base = json.loads((ROOT / 'build/m2-graph-interval-01/build-reuse/argv-plan.json').read_text())
cwd = plan['cwd']
steps = []


def run(name, argv, seconds=120):
    start = time.monotonic()
    result = subprocess.run(argv, cwd=cwd, env={**os.environ, 'OMP_NUM_THREADS': '1'},
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=seconds)
    (P / (name + '.stdout')).write_bytes(result.stdout)
    (P / (name + '.stderr')).write_bytes(result.stderr)
    steps.append({'name': name, 'argv': argv, 'cwd': cwd,
                  'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - start})
    (P / 'cpu-check-steps.json').write_text(json.dumps(steps, indent=2) + '\n')
    if result.returncode:
        raise RuntimeError(name + ': ' + result.stderr.decode(errors='replace')[-3000:])
    return result


include = plan['test_include']
run('compile-check', ['/bin/c++', '-std=c++17', '-O2', '-I' + include,
    '-I' + str(Path(include).parent / 'external/ggml/include'), '-MD', '-MF',
    str(P / 'conv_bias_check.o.d'), '-c', str(P / 'conv_bias_check.cpp'), '-o', str(P / 'conv_bias_check.o')])
for case in ('original', 'candidate'):
    argv = base['steps'][-1]['argv'].copy()
    argv = [('-Wl,--dependency-file=' + str(P / (case + '-cpu-link.d')))
            if x.startswith('-Wl,--dependency-file=') else x for x in argv]
    adapter = next(i for i, x in enumerate(argv) if x.endswith('/htdemucs_segment.cpp.o'))
    argv[adapter] = str(P / 'conv_bias_check.o')
    if case == 'candidate':
        argv.insert(adapter + 1, str(P / 'conv_modules.cpp.o'))
    argv[argv.index('-o') + 1] = str(P / (case + '-cpu-check'))
    run(case + '-link', argv)
    result = run(case + '-check', [str(P / (case + '-cpu-check')), case,
                 str(P / (case + '-synthetic.f32'))], seconds=60)
    print(case, result.stdout.decode().strip(), flush=True)

original = (P / 'original-synthetic.f32').read_bytes()
candidate = (P / 'candidate-synthetic.f32').read_bytes()
assert original == candidate
stats = {case: json.loads((P / (case + '-check.stdout')).read_text())
         for case in ('original', 'candidate')}
assert stats['original']['CPU_graph_cases'] == stats['candidate']['CPU_graph_cases'] == 64
assert stats['original']['bad_bias_shapes_rejected'] == stats['candidate']['bad_bias_shapes_rejected'] == 32
assert stats['original']['removed_bias_repeats'] == 0
assert stats['candidate']['removed_bias_repeats'] == 16
receipt = {'schema': 1, 'status': 'CPU_graph_regression_passed', 'cases_per_library': 64,
           'stats': stats, 'exact_original_candidate_output_match': True,
           'synthetic_bytes': len(candidate), 'synthetic_sha256': hashlib.sha256(candidate).hexdigest(),
           'model_GPU_audio_UI_started': False,
           'scope': 'Actual Conv1dModule graphs, constructed with CPU/Vulkan selectors and executed only by ggml CPU. Not Vulkan execution, real model PCM, performance or qualification proof.'}
(P / 'cpu-result-01.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
