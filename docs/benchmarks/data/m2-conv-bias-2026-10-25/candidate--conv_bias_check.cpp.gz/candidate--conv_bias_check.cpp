#include "engine/framework/modules/conv_modules.h"
#include "ggml-cpu.h"

#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <vector>

namespace core = engine::core;
namespace modules = engine::modules;

static void require(bool value, const char *message) {
    if (!value) throw std::runtime_error(message);
}

struct Shape {
    int channels, outputs, frames, kernel, stride, dilation, padding;
};

int main(int argc, char **argv) {
    try {
        require(argc == 3, "Expected original/candidate flag and synthetic output path");
        const bool candidate = std::strcmp(argv[1], "candidate") == 0;
        require(candidate || std::strcmp(argv[1], "original") == 0, "Unknown candidate flag");
        std::unique_ptr<FILE, decltype(&std::fclose)> output(std::fopen(argv[2], "wb"), &std::fclose);
        require(output != nullptr, "Cannot open synthetic output file");
        constexpr std::array<Shape, 8> shapes{{
            {1, 1, 9, 1, 1, 1, 0}, {3, 5, 17, 3, 1, 1, 1},
            {5, 3, 33, 7, 2, 1, 3}, {3, 7, 513, 3, 1, 2, 2},
            {7, 5, 37, 1, 2, 1, 0}, {5, 96, 65, 3, 1, 1, 1},
            {4, 12, 37, 4, 4, 1, 1}, {6, 48, 65, 8, 4, 1, 2},
        }};
        size_t cases = 0, values = 0, rejected = 0, removed_repeats = 0;
        for (const auto &s : shapes) {
            for (const int batch : {1, 2}) {
                for (const bool bias_enabled : {false, true}) {
                    std::vector<float> cpu_reference;
                    for (const auto backend : {core::BackendType::Cpu, core::BackendType::Vulkan}) {
                        // Vulkan is a graph-construction selector only. Every graph below
                        // executes through ggml's CPU entry point, without a backend init.
                        std::unique_ptr<ggml_context, decltype(&ggml_free)> context(
                            ggml_init({32 * 1024 * 1024, nullptr, false}), &ggml_free);
                        require(context != nullptr, "Context allocation failed");
                        core::ModuleBuildContext build{context.get(), "bias-fixture", backend};
                        auto input = core::make_tensor(build, GGML_TYPE_F32,
                            core::TensorShape::from_dims({batch, s.channels, s.frames}));
                        auto weight = core::make_tensor(build, GGML_TYPE_F16,
                            core::TensorShape::from_dims({s.outputs, s.channels, s.kernel}));
                        auto bias = core::make_tensor(build, GGML_TYPE_F32,
                            core::TensorShape::from_dims({s.outputs}));
                        for (int64_t i = 0; i < ggml_nelements(input.tensor); ++i)
                            ggml_get_data_f32(input.tensor)[i] = static_cast<float>((i * 17) % 113 - 56) / 64.0f;
                        auto *half = static_cast<ggml_fp16_t *>(weight.tensor->data);
                        for (int64_t i = 0; i < ggml_nelements(weight.tensor); ++i)
                            half[i] = ggml_fp32_to_fp16(static_cast<float>((i * 13) % 47 - 23) / 128.0f);
                        for (int i = 0; i < s.outputs; ++i)
                            ggml_get_data_f32(bias.tensor)[i] = static_cast<float>(i % 11 - 5) / 32.0f;
                        modules::Conv1dConfig config;
                        config.in_channels = s.channels;
                        config.out_channels = s.outputs;
                        config.kernel_size = s.kernel;
                        config.stride = s.stride;
                        config.dilation = s.dilation;
                        config.padding = s.padding;
                        config.use_bias = bias_enabled;
                        modules::Conv1dWeights weights{weight, bias};
                        auto result = modules::Conv1dModule(config).build(build, input, weights);
                        auto *graph = ggml_new_graph_custom(context.get(), 4096, false);
                        ggml_build_forward_expand(graph, result.tensor);
                        size_t repeats = 0;
                        for (int i = 0; i < ggml_graph_n_nodes(graph); ++i)
                            repeats += ggml_graph_node(graph, i)->op == GGML_OP_REPEAT;
                        const bool broadcast = candidate && backend == core::BackendType::Vulkan && bias_enabled;
                        require(repeats == (bias_enabled && !broadcast ? 1u : 0u), "Unexpected materialized bias repeat count");
                        removed_repeats += broadcast;
                        require(ggml_graph_compute_with_ctx(context.get(), graph, 1) == GGML_STATUS_SUCCESS,
                                "CPU graph execution failed");
                        const int out_frames = (s.frames + 2 * s.padding - s.dilation * (s.kernel - 1) - 1) / s.stride + 1;
                        const size_t count = static_cast<size_t>(batch * s.outputs * out_frames);
                        require(result.shape.dims[0] == batch && result.shape.dims[1] == s.outputs &&
                                result.shape.dims[2] == out_frames && static_cast<size_t>(ggml_nelements(result.tensor)) == count,
                                "Convolution output shape changed");
                        require(ggml_is_contiguous(result.tensor), "Expected contiguous result");
                        const auto *data = ggml_get_data_f32(result.tensor);
                        for (size_t i = 0; i < count; ++i) require(std::isfinite(data[i]), "Nonfinite generated result");
                        if (backend == core::BackendType::Cpu) cpu_reference.assign(data, data + count);
                        else require(cpu_reference.size() == count && std::memcmp(cpu_reference.data(), data, count * sizeof(float)) == 0,
                                     "CPU and Vulkan-selector construction differ in CPU-executed samples");
                        require(std::fwrite(data, sizeof(float), count, output.get()) == count, "Synthetic result write failed");
                        values += count;
                        ++cases;
                        if (bias_enabled) {
                            weights.bias = core::make_tensor(build, GGML_TYPE_F32,
                                core::TensorShape::from_dims({s.outputs + 1}));
                            bool bad_shape = false;
                            try { modules::Conv1dModule(config).build(build, input, weights); }
                            catch (const std::runtime_error &) { bad_shape = true; }
                            require(bad_shape, "Invalid channel-bias shape was accepted");
                            ++rejected;
                        }
                    }
                }
            }
        }
        require(std::fflush(output.get()) == 0, "Synthetic result flush failed");
        std::printf("{\"CPU_graph_cases\":%zu,\"finite_output_values\":%zu,\"bad_bias_shapes_rejected\":%zu,\"removed_bias_repeats\":%zu,\"GPU_initialized\":false}\n",
                    cases, values, rejected, removed_repeats);
    } catch (const std::exception &error) {
        std::fprintf(stderr, "%s\n", error.what());
        return 1;
    }
}
