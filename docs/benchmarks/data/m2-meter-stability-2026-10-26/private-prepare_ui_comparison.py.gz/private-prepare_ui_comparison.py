#!/usr/bin/env python3
"""Prepare two dry, unarmed player cases using the established guarded owner."""
import copy
import hashlib
import json
from pathlib import Path
import re
import shutil

ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
BASE=Path(__file__).resolve().parent
OLD=ROOT/'build/m2-player-thread-cpu-trace-01'
DEST=BASE/'ui-comparison-01'
BUILD=BASE/'ui-comparison-build-01'


def pin(path):
    path=Path(path).resolve(strict=True);raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def once(text,old,new):
    assert text.count(old)==1,old[:100]
    return text.replace(old,new)


def main():
    assert not DEST.exists()
    receipt=json.loads((BUILD/'root-build-01.json').read_text())
    assert receipt['status']=='complete' and receipt['base_inputs_unchanged']
    original_plan=json.loads((OLD/'plan.json').read_text())
    DEST.mkdir(mode=0o700)
    for ui_arm in ('baseline','candidate'):
        directory=DEST/'cases'/ui_arm;directory.mkdir(parents=True,mode=0o700)
        variant=receipt['arms'][ui_arm];ui_root=Path(variant['ui_source_root'])
        text=(OLD/'run_host_player.py').read_text()
        text=once(text,'import contextlib\n','import contextlib\nimport copy\n')
        text=once(text,"WRAPPER = W/'tools/experiments/run_manual_playback_soak.py'",
                  'UI_ARM = '+repr(ui_arm)+'\nUI_ROOT = Path('+repr(str(ui_root))+')\nHISTORICAL_UI_ROOT = Path('+repr(receipt['arms']['baseline']['ui_source_root'])+")\nWRAPPER = UI_ROOT/'tools/experiments/run_manual_playback_soak.py'")
        text=once(text,"BINARY = Path('/home/kyau/projects/kyaulabs/conflux/build/m2-flash-rows8-player-2026-10-25/build-01/conflux-manual-playback-soak')",'BINARY = Path('+repr(variant['binary']['path'])+')')
        text=once(text,"BINARY_SHA = '3e8c252fd8534dddc458e63f6d99dc373ce05b9d8de40b451b321ac6a756a7dc'",'BINARY_SHA = '+repr(variant['binary']['sha256']))
        mode='m2-meter-stability-visible-pair-120-01-'+ui_arm
        text=once(text,"MODE = 'm2-player-native-thread-cpu-120-01'",'MODE = '+repr(mode))
        text=re.sub(r'\b600\b','1200',text)
        text=text.replace('original600s','original1200s')
        text=once(text,"WRAPPER==W/'tools/experiments/run_manual_playback_soak.py'", "WRAPPER==UI_ROOT/'tools/experiments/run_manual_playback_soak.py'")
        text=once(text,"n.get('source_root') == str(W)","n.get('source_root') == str(UI_ROOT)")
        text=text.replace("'current_source_pins'","'historical_base_source_pins'")
        text=once(text,'def verify_files(plan,deadline=math.inf):','def verify_base_files(plan,deadline=math.inf):')
        text=once(text,"        pin_read(row['path'],row,maximum=1024**3 if row['path']==plan['assets']['track_b']['path'] else 256*1024**2,deadline=deadline)",
                  "        verify_historical_build_file(row,plan,deadline)")
        addition='''def verify_historical_build_file(row,plan,deadline):
    # The old attestation describes the original build, not today's checkout.
    # Only its changed meter file is read from the explicitly named Git snapshot.
    path=Path(row['path'])
    if path==W/'qml/StereoMeter.qml':
        require(row['sha256']=='4682b5f604cf932e248584668e1f2bb3502dc484253b98048784c3a16b9fc9d8',
            'Historical meter pin must remain the original build content')
        path=HISTORICAL_UI_ROOT/'qml/StereoMeter.qml'
    return pin_read(path,row,maximum=1024**3 if row['path']==plan['assets']['track_b']['path'] else 256*1024**2,deadline=deadline)


def verify_ui_build(plan,receipt,deadline):
    require(receipt.get('status')=='complete' and receipt.get('base_inputs_unchanged') is True and
        receipt.get('original_source_ref')==SOURCE_HEAD and
        receipt.get('candidate_source_ref')=='40b3a50d96672b7fd35c859ffcac33058d875198' and
        receipt.get('sole_runtime_UI_change')==['qml/StereoMeter.qml'] and
        plan.get('ui_arm')==UI_ARM and plan.get('runtime_ui_source_root')==str(UI_ROOT),
        'Fixed original/fixed UI build identity differs')
    require(set(receipt['arms'])=={'baseline','candidate'},'Exactly two UI variants required')
    source_tokens=decode(pin_read(plan['helpers']['compile_commands']['path'],plan['helpers']['compile_commands'],
        maximum=1024**2,deadline=deadline,keep=True)[1])
    rows=[r for r in source_tokens if r['file']==str(W/'tools/experiments/manual_playback_soak.cpp')]
    require(len(rows)==1,'One original native compilation row required')
    original=rows[0].get('arguments') or shlex.split(rows[0]['command'])
    macro=[x for x in original if x.startswith('-DCONFLUX_SOURCE_DIR=')]
    require(len(macro)==1 and str(W) in macro[0],'Original native UI macro differs')
    mappings={}
    for arm,value in receipt['arms'].items():
        root=Path(value['ui_source_root'])
        require(value.get('compile_exit')==value.get('link_exit')==0,'Private native build failed')
        expected=[value['object']['path'] if x=='CMakeFiles/conflux-manual-playback-soak.dir/tools/experiments/manual_playback_soak.cpp.o'
            else x.replace(str(W),str(root)) if x==macro[0] else x for x in original]
        require(value['compile_argv']==expected,'Only UI macro/object destination may differ from original compile')
        mapping={}
        for row in value['ui_and_wrapper_files']:
            path=Path(row['path']);require(path.is_relative_to(root),'UI file escaped its snapshot')
            name=str(path.relative_to(root));require(name not in mapping,'Duplicate UI snapshot path')
            mapping[name]=row['sha256'];pin_read(path,row,deadline=deadline)
        mappings[arm]=mapping
        for row in (value['binary'],value['object'],value['source_cpp']):pin_read(row['path'],row,deadline=deadline)
    require(set(mappings['baseline'])==set(mappings['candidate']) and
        [k for k in sorted(mappings['baseline']) if mappings['baseline'][k]!=mappings['candidate'][k]]==['qml/StereoMeter.qml'] and
        mappings['baseline']['qml/StereoMeter.qml']=='4682b5f604cf932e248584668e1f2bb3502dc484253b98048784c3a16b9fc9d8' and
        mappings['candidate']['qml/StereoMeter.qml']=='cb37a92886292c76e54c24bea7e1cf4002ca334d006955a8a246a044cafe897d',
        'The meter must be the sole UI content difference')
    require(receipt['arms'][UI_ARM]['binary']==plan['assets']['binary'] and
        receipt['arms'][UI_ARM]['ui_source_root']==str(UI_ROOT),'Actual native/UI arm differs')
    for row in receipt['base_inputs']:pin_read(row['path'],row,deadline=deadline)


def verify_files(plan,deadline=math.inf):
    record=decode(pin_read(plan['helpers']['ui_build']['path'],plan['helpers']['ui_build'],
        maximum=256*1024,deadline=deadline,keep=True)[1])
    verify_ui_build(plan,record,deadline)
    base=copy.deepcopy(plan);base['assets']['binary']=plan['original_native_binary']
    verify_base_files(base,deadline)


'''
        text=once(text,'def decode_lines(path,maximum,deadline=math.inf):',addition+'def decode_lines(path,maximum,deadline=math.inf):')
        text=once(text,"        'scope':'Process and native per-thread CPU observation at existing host-poll cadence; same baseline visible16-controls actual-player diagnostic; no sustained/M2/M3, physical latency, pointer/touch or assistive-technology qualification.'}",
                  "        'scope':'Original/fixed meter UI comparison; same original C++/audio, Best runtime, visible16-controls workload and read-only CPU/thread observer. Isolated UI snapshots; no profiler, sustained, physical-latency or milestone qualification.'}")
        (directory/'run_host_player.py').write_text(text)
        owner=(OLD/'run_player_owned.py').read_text()
        owner=re.sub(r"LAUNCHER_SHA = '[0-9a-f]{64}'",'LAUNCHER_SHA = '+repr(pin(directory/'run_host_player.py')['sha256']),owner,count=1)
        (directory/'run_player_owned.py').write_text(owner);(directory/'run_player_owned.py').chmod(0o755)
        command='/usr/bin/kde-inhibit --power --screenSaver '+str(directory/'run_player_owned.py')+' --run\n'
        (directory/'launch-command-01.txt').write_text(command)
        for name in ('test_host_player.py','test_process_cpu.py','test_thread_cpu.py'):shutil.copy2(OLD/name,directory/name)
        plan=copy.deepcopy(original_plan)
        plan.update(mode=mode,status='draft_unarmed_pending_root_review',operator_seconds=1200,
                    ui_arm=ui_arm,runtime_ui_source_root=str(ui_root),original_native_binary=copy.deepcopy(plan['assets']['binary']),
                    actual_checkout_head_at_preparation='40b3a50d96672b7fd35c859ffcac33058d875198',
                    workload_scope='Two-minute original/fixed meter case in a shared original1200s human window. Same Best runtime, audio/C++, controls, CPU/thread observer, 15W ceiling and guard. Only stereo-meter QML differs; no profiler or power-profile selection.')
        plan['historical_base_source_pins']=plan.pop('current_source_pins')
        plan['assets']['binary']=copy.deepcopy(variant['binary'])
        plan['helpers']['wrapper']=pin(ui_root/'tools/experiments/run_manual_playback_soak.py')
        plan['helpers']['ui_build']=pin(BUILD/'root-build-01.json')
        plan['helpers']['ui_builder']=pin(BASE/'build_ui_comparison.py')
        plan['helpers']['ui_preparer']=pin(Path(__file__))
        plan['sources']['launcher']=pin(directory/'run_host_player.py')
        plan['sources']['outer_owner']=pin(directory/'run_player_owned.py')
        plan['sources']['operator_launch']=pin(directory/'launch-command-01.txt')
        with (directory/'plan.json').open('x') as stream:json.dump(plan,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(status='prepared_unarmed',path=str(DEST),native_started=False)))


if __name__=='__main__':main()
