"""Archive closed meter comparison evidence without publishing media or binaries."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
PAIR = BASE/'ui-comparison-01'
WORK = BASE.parent/'m2-profile-reporting-worktree'
DEST = WORK/'docs/benchmarks/data/m2-meter-stability-2026-10-26'
RAW = BASE/'comparison-archive-raw-01'


def sha(raw): return hashlib.sha256(raw).hexdigest()


def main():
    assert not DEST.exists() and not RAW.exists()
    closed = json.loads((PAIR/'root-finished-01.json').read_text())
    analysis = json.loads((PAIR/'root-comparison-results-01.json').read_text())
    assert closed['cleanup_complete'] and closed['within_original_1200_seconds']
    assert closed['status'] == 'both_runs_completed_failed_gates'
    assert analysis['arms']['baseline']['nearest_rank_p99_ms'] > 4095
    assert analysis['arms']['candidate']['nearest_rank_p99_ms'] > 4095
    sources = [(PAIR/name, 'pair-'+name) for name in ('pair-plan-01.json','root-packet-review-01.json',
        'root-launch-clearance-01.json','root-shared-readiness-01.json','root-finished-01.json','root-comparison-results-01.json')]
    sources += [(BASE/name, 'private-'+name) for name in ('build_ui_comparison.py','prepare_ui_comparison.py',
        'analyze_ui_comparison.py','archive_ui_comparison.py')]
    sources.append((BASE/'ui-comparison-build-01/root-build-01.json','private-root-build-01.json'))
    for arm in ('baseline','candidate'):
        case = PAIR/'cases'/arm
        sources += [(case/name, arm+'-'+name) for name in ('plan.json','readiness.json','run_host_player.py',
            'run_player_owned.py','root-offline-checks-01.json','offline-checks-final-01.log',
            'root-file-preflight-final-01.json','root-file-preflight-final-01.log','root-unit-dispatch-01.json',
            'dispatch-01.json','admission-01.json','diagnostic-assessment.json','root-finished-01.json',
            'root-guard-journal-01.json','root-audio-results-01.json','root-thread-cpu-analysis-01.json')]
        sources += [(case/'output-01'/name,arm+'-output-'+name) for name in ('result.json','observations.jsonl',
            'host-observations.jsonl','native.stderr.log','native.stdout.log','progress.json')]
        sources.append((BASE/'ui-comparison-build-01'/arm/'ui-source/qml/StereoMeter.qml',arm+'-StereoMeter.qml'))
    assert len({name for _,name in sources}) == len(sources)
    RAW.mkdir(mode=0o700)
    rows = []
    for source,name in sorted(sources,key=lambda row:row[1]):
        assert source.resolve(strict=True) == source and source.stat().st_size < 32*1024**2
        raw = source.read_bytes(); raw.decode('utf-8')
        if source.suffix == '.json': json.loads(raw)
        if source.suffix == '.jsonl':
            assert raw.endswith(b'\n')
            for line in raw.splitlines(): json.loads(line)
        (RAW/name).write_bytes(raw)
        rows.append(dict(original_path=str(source),raw_file=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
    scanner = shutil.which('gitleaks'); assert scanner
    command = [scanner,'dir','--no-banner','--redact','--max-target-megabytes','32',str(RAW)]
    with (BASE/'comparison-archive-gitleaks-01.log').open('xb') as stream:
        result = subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=120)
    log = (BASE/'comparison-archive-gitleaks-01.log').read_bytes()
    assert result.returncode == 0, 'Raw secret scan failed'
    total = sum(row['raw_bytes'] for row in rows)
    scanned = re.search(rb'scanned ~(\d+) bytes',log)
    assert scanned and int(scanned[1]) == total, 'Raw scan did not cover all evidence'
    DEST.mkdir()
    for row in rows:
        raw = (RAW/row['raw_file']).read_bytes()
        archive = gzip.compress(raw,compresslevel=9,mtime=0)
        assert gzip.decompress(archive) == raw and sha(raw) == row['raw_sha256']
        name = row['raw_file']+'.gz'; (DEST/name).write_bytes(archive)
        row.update(archive_file=name,archive_bytes=len(archive),archive_sha256=sha(archive))
    arms = {}
    for arm,value in analysis['arms'].items():
        arms[arm] = {key:value[key] for key in ('hop_count','median_ms','nearest_rank_p99_ms','at_or_above_4095_ms',
            'steady_starved_seconds','control_starved_seconds','peer_starved_frames','control_recoveries',
            'manual_acknowledgements','UI','WAV','main_thread','guard_messages','thermal_summary')}
    verification = dict(schema=1,qualified=False,strict_service_target_ms=4095,
        scope=analysis['scope'],order=analysis['order'],UI_profiler_enabled=False,
        runtime_promoted=False,milestone_or_release_gate_changed=False,
        arms=arms,root_cleanup=closed,files=rows,total_raw_bytes=total,
        total_archive_bytes=sum(row['archive_bytes'] for row in rows),
        gzip_roundtrip_and_original_hashes_verified=True,
        no_audio_models_executables_PCM_or_driver_cache_published=True,
        raw_secret_scan=dict(command=command,exit_code=0,scanned_bytes=int(scanned[1]),log_sha256=sha(log)),
        created_at_utc=datetime.now(timezone.utc).isoformat())
    with (DEST/'verification.json').open('x') as stream:
        json.dump(verification,stream,indent=2,allow_nan=False);stream.write('\n')
    for row in rows:
        archive = (DEST/row['archive_file']).read_bytes()
        assert sha(archive) == row['archive_sha256']
        raw = gzip.decompress(archive)
        assert len(raw) == row['raw_bytes'] and sha(raw) == row['raw_sha256']
    print(json.dumps(dict(files=len(rows),raw_bytes=total,gzip_bytes=verification['total_archive_bytes'],
        raw_secret_scan_complete=True,all_gzip_roundtrips_verified=True,verification=str(DEST/'verification.json'))))


if __name__ == '__main__': main()
