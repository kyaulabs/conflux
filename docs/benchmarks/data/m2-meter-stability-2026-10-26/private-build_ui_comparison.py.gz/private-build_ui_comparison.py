#!/usr/bin/env python3
"""Build two isolated native diagnostics; only the stereo-meter QML differs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import time

ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
BASE=Path(__file__).resolve().parent
WORK=ROOT/'build/m2-profile-reporting-worktree'
OLD_BUILD=ROOT/'build/m2-flash-rows8-player-2026-10-25/build-01'
DEST=BASE/'ui-comparison-build-01'
ORIGINAL='119a579e4ca717a1d59d7a7a6f9752534d68dcaf'
CANDIDATE='40b3a50d96672b7fd35c859ffcac33058d875198'


def pin(path):
    path=Path(path).resolve(strict=True);raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def git_bytes(ref,name):
    return subprocess.check_output(['git','show',ref+':'+name],cwd=WORK)


def main():
    assert Path('/proc/1/comm').read_text().strip()=='systemd'
    assert not DEST.exists()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==CANDIDATE
    assert subprocess.check_output(['git','status','--porcelain'],cwd=WORK)==b''
    original_plan=json.loads((ROOT/'build/m2-player-thread-cpu-trace-01/plan.json').read_text())
    ui_paths=sorted(str(Path(row['path']).relative_to(WORK)) for row in original_plan['current_source_pins']
                    if Path(row['path']).is_relative_to(WORK) and
                    (Path(row['path']).relative_to(WORK).parts[0] in ('qml','brand')))
    assert 'qml/WindowActions.qml' in ui_paths and 'qml/StereoMeter.qml' in ui_paths
    changed=[name for name in ui_paths if git_bytes(ORIGINAL,name)!=git_bytes(CANDIDATE,name)]
    assert changed==['qml/StereoMeter.qml'],changed
    source=WORK/'tools/experiments/manual_playback_soak.cpp'
    assert source.read_bytes()==git_bytes(ORIGINAL,'tools/experiments/manual_playback_soak.cpp')==git_bytes(CANDIDATE,'tools/experiments/manual_playback_soak.cpp')
    wrapper='tools/experiments/run_manual_playback_soak.py'
    assert git_bytes(ORIGINAL,wrapper)==git_bytes(CANDIDATE,wrapper)==(WORK/wrapper).read_bytes()
    commands=json.loads((OLD_BUILD/'compile_commands.json').read_text())
    compile_rows=[row for row in commands if row['file']==str(source)];assert len(compile_rows)==1
    original_compile=shlex.split(compile_rows[0]['command'])
    macro=[x for x in original_compile if x.startswith('-DCONFLUX_SOURCE_DIR=')]
    assert len(macro)==1 and str(WORK) in macro[0]
    native_object='CMakeFiles/conflux-manual-playback-soak.dir/tools/experiments/manual_playback_soak.cpp.o'
    link_text=subprocess.check_output(['ninja','-t','commands','conflux-manual-playback-soak'],cwd=OLD_BUILD,text=True).splitlines()[-1]
    assert link_text.startswith(': && ') and link_text.endswith(' && :')
    original_link=shlex.split(link_text[5:-5]);assert original_link.count(native_object)==1
    inputs=[source,OLD_BUILD/'compile_commands.json',OLD_BUILD/'CMakeCache.txt',OLD_BUILD/'conflux-manual-playback-soak']
    for token in original_link[1:]:
        if token.startswith('-') or token=='conflux-manual-playback-soak':continue
        path=Path(token) if Path(token).is_absolute() else OLD_BUILD/token
        if path.is_file():inputs.append(path)
    original_inputs=[pin(path) for path in dict.fromkeys(inputs)]
    DEST.mkdir(mode=0o700)
    record=dict(schema=1,status='started',created_at_utc=datetime.now(timezone.utc).isoformat(),
                original_source_ref=ORIGINAL,candidate_source_ref=CANDIDATE,
                sole_runtime_UI_change=changed,source_cpp=pin(source),base_inputs=original_inputs,
                qualified=False,native_model_audio_or_host_workload_started=False,
                scope='Identical original native C++/libraries and O2 flags. Only CONFLUX_SOURCE_DIR selects immutable UI copies; the meter QML is the sole UI content difference. No QML profiler or audio/model/runtime/power changes.',arms={})
    started=time.monotonic()
    try:
        for arm,ref in [('baseline',ORIGINAL),('candidate',CANDIDATE)]:
            directory=DEST/arm;directory.mkdir(mode=0o700)
            ui=directory/'ui-source'
            ui.mkdir(mode=0o700)
            snapshots=[]
            for name in [*ui_paths,wrapper]:
                path=ui/name;path.parent.mkdir(parents=True,exist_ok=True)
                with path.open('xb') as stream:stream.write(git_bytes(ref,name))
                snapshots.append(pin(path))
            obj=directory/'manual-soak.o';binary=directory/'conflux-manual-playback-soak'
            compile_argv=[str(obj) if x==native_object else x.replace(str(WORK),str(ui)) if x==macro[0] else x
                          for x in original_compile]
            link_argv=[str(obj) if x==native_object else str(binary) if x=='conflux-manual-playback-soak' else
                       '-Wl,--dependency-file='+str(directory/'link.d') if x.startswith('-Wl,--dependency-file=') else x
                       for x in original_link]
            arm_record=dict(ui_source_root=str(ui),ui_and_wrapper_files=snapshots,source_cpp=record['source_cpp'],
                            compile_argv=compile_argv,link_argv=link_argv,started_monotonic=time.monotonic())
            record['arms'][arm]=arm_record
            for phase,argv,limit in [('compile',compile_argv,90),('link',link_argv,45)]:
                with (directory/(phase+'.stdout')).open('xb') as out,(directory/(phase+'.stderr')).open('xb') as err:
                    done=subprocess.run(argv,cwd=OLD_BUILD,stdout=out,stderr=err,timeout=limit,check=False)
                arm_record[phase+'_exit']=done.returncode
                assert done.returncode==0,(arm,phase,done.returncode)
            arm_record.update(binary=pin(binary),object=pin(obj),finished_monotonic=time.monotonic())
            assert [pin(row['path']) for row in original_inputs]==original_inputs,'Original build inputs changed'
            print(json.dumps({'arm':arm,'status':'built_only','binary':arm_record['binary']}),flush=True)
        assert len(record['arms'])==2
        record.update(status='complete',base_inputs_unchanged=True)
    except Exception as error:
        record.update(status='failed',error=dict(type=type(error).__name__,message=str(error)))
        raise
    finally:
        record['elapsed_seconds']=time.monotonic()-started
        with (DEST/'root-build-01.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
    print(json.dumps({'status':record['status'],'sole_runtime_UI_change':changed,'elapsed_seconds':record['elapsed_seconds']}))


if __name__=='__main__':main()
