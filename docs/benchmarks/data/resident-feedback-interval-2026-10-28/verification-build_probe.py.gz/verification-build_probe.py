"""Compile only extra failure context; leave every predicate and product object unchanged."""
from pathlib import Path
import hashlib,json,shlex,subprocess
BASE=Path(__file__).resolve().parent;WORK=Path('/home/kyau/.codex/worktrees/player-startup-clock/conflux')
r=json.loads((BASE/'baseline-build-commands-01.json').read_text());source=WORK/'tools/experiments/preparation_controller_check.cpp';text=source.read_text()
old='        throw std::runtime_error("Prepared bass peer/output atomic clocks or health changed");'
assert text.count(old)==1
text=text.replace(old,'''        throw std::runtime_error("Prepared bass peer/output atomic clocks or health changed: " +
            QJsonDocument(QJsonObject{{"before", snapshot(before)}, {"after", snapshot(after)}})
                .toJson(QJsonDocument::Compact).toStdString());''')
marker='''    } catch (const std::exception& error) {
        if (locked) gate.unlock();
        controller.shutdown(); evidence.inspectResources = true; evidence.lastOutput = UINT64_MAX;'''
assert text.count(marker)==1
text=text.replace(marker,'''    } catch (const std::exception& error) {
        report["failure_context"] = QJsonObject{{"audio", snapshot(controller.audioState())},
            {"recording", QJsonObject::fromVariantMap(controller.recording())}, {"actions", evidence.actions}};
        if (locked) gate.unlock();
        controller.shutdown(); evidence.inspectResources = true; evidence.lastOutput = UINT64_MAX;''')
for name in ('StemExportFixture.hpp','StemServiceFixture.hpp'):text=text.replace('"../../tests/'+name+'"','"'+str(WORK/'tests'/name)+'"')
p=BASE/'preparation_controller_check.cpp';p.write_text(text)
compile=shlex.split(r['compile'])
old_object=compile[compile.index('-o')+1]
compile[compile.index('-o')+1]=str(BASE/'probe.o');compile[compile.index('-MF')+1]=str(BASE/'probe.d');compile[compile.index('-MT')+1]=str(BASE/'probe.o');compile[compile.index('-c')+1]=str(p)
link=shlex.split(r['link']);assert link[:2]==[':','&&']and link[-2:]==['&&',':'];link=link[2:-2]
link[link.index(old_object)]=str(BASE/'probe.o');link[link.index('-o')+1]=str(BASE/'conflux-preparation-controller-probe')
link=[('-Wl,--dependency-file='+str(BASE/'probe-link.d'))if s.startswith('-Wl,--dependency-file=')else s for s in link]
with(BASE/'build-probe-01.log').open('x')as out:
 subprocess.run(compile,cwd=r['build'],stdout=out,stderr=subprocess.STDOUT,check=True)
 subprocess.run(link,cwd=r['build'],stdout=out,stderr=subprocess.STDOUT,check=True)
binary=BASE/'conflux-preparation-controller-probe';receipt=dict(diagnostics_only=True,predicates_unchanged=True,product_objects_reused=True,original_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),diagnostic_source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),compile=compile,link=link)
(BASE/'build-receipt-01.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in('diagnostics_only','predicates_unchanged','binary_sha256')}))
