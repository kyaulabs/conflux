from pathlib import Path
import json,os,subprocess
BASE=Path(__file__).resolve().parent;OWNER=Path('/home/kyau/.codex/worktrees/player-startup-clock/conflux/tools/experiments/private_routing_check.py')
results={}
for label,flag,expected in [('setup-fixed-01','CONFLUX_PROBE_SETUP_PAUSE',True),('active-fixed-01','CONFLUX_PROBE_ACTIVE_PAUSE',False)]:
 case=BASE/label;env=dict(os.environ,**{flag:'1'})
 owner_exit=None
 reused=(case/'result.json').exists()
 if not reused:
  with(BASE/(label+'.stdout.log')).open('x')as out,(BASE/(label+'.stderr.log')).open('x')as err:
   p=subprocess.run(['/usr/bin/python3.14','-B',str(OWNER),str(BASE/'conflux-preparation-controller-fixed'),str(case),'--continuation-case','resident-takeover'],env=env,stdout=out,stderr=err,timeout=105)
  owner_exit=p.returncode
 r=json.loads((case/'result.json').read_text());s=r['check']['scenarios'][0]
 row=dict(owner_exit=owner_exit,native_check_exit=r['check_exit'],existing_complete_capture_reused=reused,passed=r['passed'],daemon_reaped=r['daemon_reaped'],only_dummy_driver_remains=r['cleanup']['only_dummy_driver_remains'],execution_deadline_gate=r['execution_deadline_gate'],error=s.get('error'),settled=s.get('settled'),wav=s.get('wav'))
 results[label]=row
 assert row['daemon_reaped']and row['only_dummy_driver_remains']and row['execution_deadline_gate']
 assert row['passed']is expected
 if expected:
  assert row['settled']['snapshot_drops']>0 and row['settled']['b_starved']==0
  assert row['wav']['checked_prefix_or_tail_frames']==row['wav']['frames'] and row['wav']['transient_middle_frames_excluded']==0 and row['wav']['maximum_prefix_or_tail_error']<=1e-6
 else:
  assert 'Prepared bass peer/output atomic clocks or health changed:'in row['error']
  pair=json.loads(row['error'].split(': ',1)[1]);assert pair['after']['snapshot_drops']>pair['before']['snapshot_drops']
  row['new_snapshot_drops']=pair['after']['snapshot_drops']-pair['before']['snapshot_drops']
 print(json.dumps(dict(case=label,expected_result_observed=True,passed=row['passed'],new_snapshot_drops=row.get('new_snapshot_drops'),past_drops=(row.get('settled')or{}).get('snapshot_drops'),WAV=row.get('wav'))),flush=True)
with(BASE/'fixed-interval-regressions-01.json').open('x')as f:f.write(json.dumps(results,indent=2)+'\n')
