"""Run every existing shared-continuity scenario once on the fixed tracked helper."""
from pathlib import Path
import hashlib,json,subprocess
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent.parent;WORK=Path('/home/kyau/.codex/worktrees/player-startup-clock/conflux')
binary=ROOT/'build/m2-prepared-miss-01/native/conflux-preparation-controller-check';rows=[]
for name,args in [('stall-exit',['--live-failure-only'])]+[(n,['--continuation-case',n])for n in ('takeover','miss','cancel','stop','foreground','resident-hold','resident-takeover','resident-cancel')]:
 output=BASE/('tracked-'+name+'-01')
 with(BASE/('tracked-'+name+'-01.stdout.log')).open('x')as out,(BASE/('tracked-'+name+'-01.stderr.log')).open('x')as err:
  p=subprocess.run(['/usr/bin/python3.14','-B',str(WORK/'tools/experiments/private_routing_check.py'),str(binary),str(output),*args],stdout=out,stderr=err,timeout=105)
 result=json.loads((output/'result.json').read_text())
 row=dict(case=name,exit=p.returncode,passed=result['passed'],daemon_reaped=result['daemon_reaped'],only_dummy_driver_remains=result['cleanup']['only_dummy_driver_remains'],scenarios=[dict(name=s['scenario'],passed=s['passed'],error=s.get('error'))for s in result['check']['scenarios']]);rows.append(row)
 (BASE/'tracked-scenarios-progress-01.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert row['exit']==0 and row['passed']and row['daemon_reaped']and row['only_dummy_driver_remains'],row
receipt=dict(source_sha256=hashlib.sha256((WORK/'tools/experiments/preparation_controller_check.cpp').read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),all_nine_commands_passed=True,all_ten_scenarios_passed=True,commands=rows,no_GPU_or_hardware_output=True,latency_qualified=False)
with(BASE/'tracked-scenarios-complete-01.json').open('x')as f:f.write(json.dumps(receipt,indent=2)+'\n')
