from pathlib import Path
import hashlib,json,shlex,subprocess
BASE=Path(__file__).resolve().parent;WORK=Path('/home/kyau/.codex/worktrees/player-startup-clock/conflux')
r=json.loads((BASE/'baseline-build-commands-01.json').read_text());source=WORK/'tools/experiments/preparation_controller_check.cpp';text=source.read_text()
assert 'after.snapshotDrops != before.snapshotDrops'in text
marker='        const auto originalMetadata = controller.decks()[0].toMap();';assert text.count(marker)==1
text=text.replace(marker,'        if (qEnvironmentVariableIsSet("CONFLUX_PROBE_SETUP_PAUSE")) QThread::msleep(350);\n'+marker)
marker='        const auto beforeHold = controller.audioState();';assert text.count(marker)==1
text=text.replace(marker,marker+'\n        if (qEnvironmentVariableIsSet("CONFLUX_PROBE_ACTIVE_PAUSE")) QThread::msleep(350);')
for name in('StemExportFixture.hpp','StemServiceFixture.hpp'):text=text.replace('"../../tests/'+name+'"','"'+str(WORK/'tests'/name)+'"')
p=BASE/'fixed_controller_check.cpp';p.write_text(text)
compile=shlex.split(r['compile']);obj=compile[compile.index('-o')+1]
for flag,value in [('-o',str(BASE/'fixed.o')),('-MF',str(BASE/'fixed.d')),('-MT',str(BASE/'fixed.o')),('-c',str(p))]:compile[compile.index(flag)+1]=value
link=shlex.split(r['link'])[2:-2];link[link.index(obj)]=str(BASE/'fixed.o');link[link.index('-o')+1]=str(BASE/'conflux-preparation-controller-fixed')
link=[('-Wl,--dependency-file='+str(BASE/'fixed-link.d'))if s.startswith('-Wl,--dependency-file=')else s for s in link]
with(BASE/'build-fixed-01.log').open('x')as out:
 subprocess.run(compile,cwd=r['build'],stdout=out,stderr=subprocess.STDOUT,check=True);subprocess.run(link,cwd=r['build'],stdout=out,stderr=subprocess.STDOUT,check=True)
p=BASE/'conflux-preparation-controller-fixed';receipt=dict(tracked_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),private_source_sha256=hashlib.sha256(text.encode()).hexdigest(),binary_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),temporary_GUI_pause_hooks_only=True,product_objects_unchanged=True,compile=compile,link=link)
(BASE/'build-fixed-receipt-01.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in ('binary_sha256','temporary_GUI_pause_hooks_only','product_objects_unchanged')}))
