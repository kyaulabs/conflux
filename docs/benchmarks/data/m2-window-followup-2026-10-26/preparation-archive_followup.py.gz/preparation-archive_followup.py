"""Retain the admission failure and completed diagnostic as scanned text evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
DEST = ROOT / 'build/m2-profile-reporting-worktree/docs/benchmarks/data/m2-window-followup-2026-10-26'
RAW = BASE / 'archive-raw-01'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    assert not DEST.exists() and not RAW.exists()
    first = json.loads((BASE / 'player-01/root-finished-01.json').read_text())
    audio = json.loads((BASE / 'player-02/root-audio-results-01.json').read_text())
    assert first['cleanup_complete'] and not first['native_player_model_audio_started']
    assert audio['service_hops'] == 21 and audio['at_or_above_target'] == 0
    assert audio['cleanup']['cleanup_complete'] and audio['cleanup']['root_verification_within_original_600_seconds']
    assert audio['UI']['unexposed_checks'] == 0 and not audio['post_failure_observation_exercised']
    sources = []
    for name in ('player-01', 'player-02'):
        folder = BASE / name
        sources += [(p, name + '-' + p.name) for p in folder.iterdir() if p.is_file() and
            (p.suffix in ('.json', '.py', '.patch', '.txt') or p.name in
             ('offline-checks-01.log', 'file-preflight-01.log', 'unit.stderr.log', 'adapter.stderr.log'))]
    run = BASE / 'player-02/output-01'
    sources += [(run / name, 'output-' + name) for name in ('result.json', 'native-result.json',
        'progress.json', 'observations.jsonl', 'host-observations.jsonl', 'owned-pipewire-cleanup.json',
        'native.stdout.log', 'native.stderr.log')]
    sources += [(p, 'preparation-' + p.name) for p in BASE.iterdir() if p.is_file() and p.suffix == '.py']
    sources += [(ROOT / 'build/m2-meter-stability-01/analyze_ui_comparison.py', 'shared-audio-thread-analysis.py')]
    assert len(sources) == len({name for _, name in sources})
    RAW.mkdir(mode=0o700)
    rows = []
    for path, name in sorted(sources, key=lambda row: row[1]):
        assert path.resolve(strict=True) == path and path.is_file() and path.stat().st_size < 32 * 1024**2
        raw = path.read_bytes()
        raw.decode('utf-8')
        if path.suffix == '.json':
            json.loads(raw)
        if path.suffix == '.jsonl':
            assert raw.endswith(b'\n')
            for line in raw.splitlines():
                json.loads(line)
        (RAW / name).write_bytes(raw)
        rows.append({'original_path': str(path), 'raw_file': name, 'raw_bytes': len(raw), 'raw_sha256': sha(raw)})
    scanner = shutil.which('gitleaks')
    assert scanner
    command = [scanner, 'dir', '--no-banner', '--redact', '--max-target-megabytes', '32', str(RAW)]
    log_path = BASE / 'archive-gitleaks-01.log'
    with log_path.open('xb') as stream:
        done = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
    log = log_path.read_bytes()
    total = sum(row['raw_bytes'] for row in rows)
    count = re.search(rb'scanned ~(\d+) bytes', log)
    assert done.returncode == 0 and count and int(count[1]) == total
    DEST.mkdir()
    for row in rows:
        raw = (RAW / row['raw_file']).read_bytes()
        compressed = gzip.compress(raw, compresslevel=9, mtime=0)
        assert gzip.decompress(compressed) == raw
        name = row['raw_file'] + '.gz'
        (DEST / name).write_bytes(compressed)
        row.update(archive_file=name, archive_bytes=len(compressed), archive_sha256=sha(compressed))
    manifest = {'schema': 1, 'qualified': False, 'normal_runtime_used': True,
        'requested120s_complete': True, 'measured_seconds': audio['measured_seconds'],
        'hop_count': 21, 'nearest_rank_p99_ms': audio['nearest_rank_p99_ms'],
        'strict_service_target_ms': 4095, 'at_or_above_target': 0,
        'admission_only_failure_retained': True, 'original_window_failure_not_reproduced': True,
        'post_failure_observation_exercised': False, 'guard_and15W_ceiling_preserved': True,
        'both_root_cleanups_within_separate_original600s': True,
        'no_sustained_or_milestone_or_release_qualification': True,
        'files': rows, 'total_raw_bytes': total,
        'total_archive_bytes': sum(row['archive_bytes'] for row in rows),
        'gzip_roundtrip_and_original_hashes_verified': True,
        'no_audio_models_executables_PCM_or_full_third_party_source_published': True,
        'raw_secret_scan': {'command': command, 'exit': 0, 'scanned_bytes': total, 'log_sha256': sha(log)}}
    with (DEST / 'verification.json').open('x') as stream:
        json.dump(manifest, stream, indent=2, allow_nan=False)
        stream.write('\n')
    for row in rows:
        data = (DEST / row['archive_file']).read_bytes()
        assert sha(data) == row['archive_sha256'] and sha(gzip.decompress(data)) == row['raw_sha256']
        (RAW / row['raw_file']).unlink()
    RAW.rmdir()
    print(json.dumps({'files': len(rows), 'raw_bytes': total,
        'gzip_bytes': manifest['total_archive_bytes'], 'all_raw_bytes_secret_scanned': True,
        'all_round_trips_verified': True}))


if __name__ == '__main__':
    main()
