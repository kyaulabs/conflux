"""Bind one unarmed diagnostic to the newly signed, fully rebuilt native source."""
import copy
import hashlib
import json
from pathlib import Path
import shutil

ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
BASE=Path(__file__).resolve().parent
OLD=ROOT/'build/m2-normal-runtime-confirmation-01/player-01'
BUILD=OLD.parent
NEW=BASE/'player-01'
WORK=ROOT/'build/m2-profile-reporting-worktree'
MODE='m2-window-failure-followup-normal-120-01'


def pin(path):
    raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def replace(text,before,after):
    assert text.count(before)==1,before[:100]
    return text.replace(before,after,1)


prior=json.loads((OLD/'plan.json').read_text())
closed=json.loads((OLD/'root-finished-01.json').read_text())
receipt=json.loads((BUILD/'root-current-build-receipt-01.json').read_text())
attestation=json.loads((BUILD/'root-current-source-build-attestation-01.json').read_text())
assert closed['cleanup_complete'] and closed['root_verification_within_original_600_seconds']
assert receipt['source_head']=='3a02b58dc9ac1cbc6dd7b2a0423b5220b5f6ea01' and receipt['test_exit']==0
assert attestation['runtime_UI_matches_fixed_meter_snapshot'] and receipt['inputs_before_and_after_unchanged']
NEW.mkdir()
for name in ('test_host_player.py','test_process_cpu.py','test_thread_cpu.py','test_normal_proof.py'):
    shutil.copyfile(OLD/name,NEW/name)
driver=(OLD/'run_host_player.py').read_text()
driver=replace(driver,"SOURCE_HEAD = '119a579e4ca717a1d59d7a7a6f9752534d68dcaf'",'SOURCE_HEAD = '+repr(receipt['source_head']))
driver=replace(driver,"UI_ARM = 'candidate'\n",'')
for line in driver.splitlines(keepends=True):
    if line.startswith('HISTORICAL_UI_ROOT = '):driver=replace(driver,line,'')
    elif line.startswith('UI_ROOT = '):driver=replace(driver,line,'UI_ROOT = W\n')
driver=replace(driver,'BINARY = Path('+repr(prior['assets']['binary']['path'])+')','BINARY = Path('+repr(receipt['binary']['path'])+')')
driver=replace(driver,'BINARY_SHA = '+repr(prior['assets']['binary']['sha256']),'BINARY_SHA = '+repr(receipt['binary']['sha256']))
driver=replace(driver,'MODE = '+repr(prior['mode']),'MODE = '+repr(MODE))
driver=replace(driver,'def verify_base_files(plan,deadline=math.inf):','def verify_files(plan,deadline=math.inf):')
driver=replace(driver,'        verify_historical_build_file(row,plan,deadline)',"        pin_read(row['path'],row,maximum=256*1024**2,deadline=deadline)")
driver=driver.replace("plan['historical_base_source_pins']","plan['source_pins']")
start=driver.index('\ndef verify_historical_build_file(')
end=driver.index('\ndef decode_lines(',start)
driver=driver[:start]+'\n'+driver[end:]
driver=replace(driver,"        'Root source-to-optimized-build attestation absent/different')",
    "        'Root source-to-optimized-build attestation absent/different')\n    require(attestation.get('runtime_UI_matches_fixed_meter_snapshot') is True and\n        plan.get('runtime_ui_source_root')==str(W) and plan.get('ui_arm')=='fixed_meter',\n        'Current fixed-meter UI/source binding differs')")
(NEW/'run_host_player.py').write_text(driver)
owner=replace((OLD/'run_player_owned.py').read_text(),
    'LAUNCHER_SHA = '+repr(prior['sources']['launcher']['sha256']),
    'LAUNCHER_SHA = '+repr(pin(NEW/'run_host_player.py')['sha256']))
(NEW/'run_player_owned.py').write_text(owner);(NEW/'run_player_owned.py').chmod(0o700)
(NEW/'launch-command-01.txt').write_text(f'/usr/bin/kde-inhibit --power --screenSaver {NEW}/run_player_owned.py --run\n')
tests='''"""Current-source provenance checks only; no native process/model/host queries."""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch
from test_host_player import driver


class CurrentBuildTests(unittest.TestCase):
    def fixture(self):
        plan=json.loads(driver.PLAN.read_text())
        rows=[plan['build_receipt'],plan['source_build_attestation'],plan['helpers']['compile_commands'],
              plan['helpers']['build_cache'],plan['helpers']['exact_pcm_prerequisite'],
              plan['helpers']['normal_runtime_build_receipt']]
        data={row['path']:Path(row['path']).read_bytes() for row in rows}
        def read(path,*args,**kwargs):
            return {'sha256':'a'*64},data[str(path)] if kwargs.get('keep') else None
        return plan,data,read

    def test_current_build_and_actual_sources_pass_without_snapshot_aliases(self):
        plan,data,read=self.fixture()
        with patch.object(driver,'pin_read',side_effect=read) as reader:
            driver.verify_files(plan)
        paths={str(call.args[0]) for call in reader.call_args_list}
        self.assertTrue(all(row['path'] in paths for row in plan['source_pins']))
        self.assertIn(str(driver.W/'tools/experiments/WindowEventHistory.hpp'),paths)

    def test_stale_source_wrong_binary_or_changed_attestation_is_rejected(self):
        for label in ('source','binary','attestation'):
            plan,data,read=self.fixture()
            if label=='attestation':
                path=plan['source_build_attestation']['path'];value=json.loads(data[path]);value['source_pins'][0]['sha256']='a'*64
            else:
                path=plan['build_receipt']['path'];value=json.loads(data[path])
                if label=='source':value['source_head']='119a579e4ca717a1d59d7a7a6f9752534d68dcaf'
                else:value['binary']['sha256']='a'*64
            data[path]=json.dumps(value).encode()
            with self.subTest(label=label),patch.object(driver,'pin_read',side_effect=read),self.assertRaises(ValueError):
                driver.verify_files(plan)

    def test_optimization_or_instrumentation_flag_drift_is_rejected(self):
        for flag in ('-O3','--coverage','-ffast-math'):
            plan,data,read=self.fixture();path=plan['helpers']['compile_commands']['path'];value=json.loads(data[path])
            value[0]['command']+=' '+flag;data[path]=json.dumps(value).encode()
            with self.subTest(flag=flag),patch.object(driver,'pin_read',side_effect=read),self.assertRaises(ValueError):
                driver.verify_files(plan)

    def test_attested_source_cannot_escape_the_current_worktree(self):
        plan,data,read=self.fixture();old=plan['source_pins'][0]['path'];row=copy.deepcopy(plan['source_pins'][0]);row['path']='/outside/source.cpp'
        plan['source_pins'][0]=row;del plan['sources'][old];plan['sources'][row['path']]=row
        path=plan['source_build_attestation']['path'];value=json.loads(data[path]);value['source_pins']=plan['source_pins'];data[path]=json.dumps(value).encode()
        with patch.object(driver,'pin_read',side_effect=read),self.assertRaises(ValueError):driver.verify_files(plan)


if __name__=='__main__':unittest.main()
'''
(NEW/'test_current_build.py').write_text(tests)
plan=copy.deepcopy(prior)
plan.update(mode=MODE,source_head=receipt['source_head'],source_pins=attestation['source_pins'],ui_arm='fixed_meter',
    runtime_ui_source_root=str(WORK),actual_checkout_head_at_preparation=receipt['source_head'],
    workload_scope='One120s visible Best-quality normal-runtime diagnostic. Same fixed-meter UI, audio, controls, caps, guard and pass criteria; new native code only observes250ms after an existing window failure outside the measured interval. No sustained qualification.')
plan.pop('historical_base_source_pins');plan.pop('original_native_binary')
plan['assets']['binary']=receipt['binary']
plan['helpers']['wrapper']=pin(WORK/'tools/experiments/run_manual_playback_soak.py')
plan['helpers']['build_cache']=receipt['cache'];plan['helpers']['compile_commands']=receipt['compile_commands']
for key in ('ui_build','ui_builder','ui_preparer','offline_checks'):plan['helpers'].pop(key,None)
plan['build_receipt']=pin(BUILD/'root-current-build-receipt-01.json')
plan['source_build_attestation']=pin(BUILD/'root-current-source-build-attestation-01.json')
plan['sources']={key:value for key,value in plan['sources'].items() if not key.startswith(str(WORK)+'/')}
for key in ('ui_provenance_tests','pair_offline_checks','player_reuse_attestation','recovery_fix_evidence'):plan['sources'].pop(key,None)
for row in plan['source_pins']:plan['sources'][row['path']]=row
for key,name in [('launcher','run_host_player.py'),('outer_owner','run_player_owned.py'),('operator_launch','launch-command-01.txt'),
                 ('normal_proof_tests','test_normal_proof.py'),('current_build_tests','test_current_build.py')]:
    plan['sources'][key]=pin(NEW/name)
save(NEW/'plan.json',plan)
save(NEW/'root-preparation-01.json',{'schema':1,'status':'prepared_unarmed_pending_verification','plan':pin(NEW/'plan.json'),
    'prior_cleanup':pin(OLD/'root-finished-01.json'),'prior_user_observation':pin(OLD/'root-user-window-observation-01.json'),
    'native_build':plan['build_receipt'],'source_build_attestation':plan['source_build_attestation'],
    'native_change':'Failure-only250ms event-loop observation; original failure and all pass criteria retained',
    'same_runtime_model_audio_controls_fixed_meter_UI_guard_caps_and_service_target':True,
    'legacy_private_UI_build_verification_replaced_by_current_signed_source_and_full_build':True,
    'no_player_model_audio_or_host_policy_started':True,'readiness_absent':not (NEW/'readiness.json').exists(),
    'preparer':pin(Path(__file__).resolve())})
print(json.dumps({'status':'prepared_unarmed','packet':str(NEW),'plan':pin(NEW/'plan.json'),'source':receipt['source_head']}))
