"""One prepared launch; dry by default, with time reserved for KDE registration."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import subprocess
import time

ENTRY_MONOTONIC = time.monotonic()
ENTRY_UTC = datetime.datetime.now(datetime.timezone.utc).isoformat()
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent / 'player-02'
WORK = ROOT / 'build/m2-profile-reporting-worktree'
PLAN_SHA = '5889f4bf76bfd02ccfc32a97368671099fcd2b8e9370a12b934731a4a3534202'
REPLY = 'Ready—start the single-step diagnostic retry'


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    with (BASE / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def pin(row):
    path = Path(row['path'])
    assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], str(path)


def show(unit):
    result = subprocess.run(['systemctl', '--user', 'show', unit,
        '--property=LoadState,ActiveState,SubState,InvocationID,MainPID,Result,ExecMainStatus,ControlGroup'],
        capture_output=True, text=True, timeout=5)
    return dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--question-item-id')
    parser.add_argument('--human-reply')
    args = parser.parse_args()
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    assert not (BASE / 'readiness.json').exists() and not (BASE / 'output-01').exists()
    assert not (BASE / 'root-unit-dispatch-01.json').exists()
    if args.run:
        assert args.human_reply == REPLY
        item = json.loads(args.question_item_id)
        assert len(item) == 3 and item[0] == 'request_user_input_async' and item[2] == 0
        save('root-readiness-received-01.json', {'received_utc': ENTRY_UTC,
            'received_monotonic': ENTRY_MONOTONIC, 'human_readiness_item': item,
            'human_answer': args.human_reply})
    launch_path = BASE / 'root-launch-plan-01.json'
    clearance_path = BASE / 'root-launch-clearance-01.json'
    launch, clearance = read(launch_path), read(clearance_path)
    for row in (clearance['launch_plan'], clearance['packet_review'], clearance['case_plan'],
                clearance['root_dispatch_script'], clearance['human_readiness_template'],
                launch['prior_run_cleanup']):
        pin(row)
    assert digest(BASE / 'plan.json') == PLAN_SHA
    assert read(Path(launch['prior_run_cleanup']['path']))['cleanup_complete']
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
    assert head == launch['source_head']
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK, text=True) == ''
    before, guard = show(launch['unit']), show('thermal-guard.service')
    assert before['LoadState'] == 'not-found' and before['MainPID'] == '0'
    assert guard['ActiveState'] == 'active' and guard['SubState'] == 'running'
    elapsed = time.monotonic() - ENTRY_MONOTONIC
    # The owner still needs >=570s after its <=8s idle-blocker verification.
    # Reserve that time by dispatching within20s, without extending either clock.
    assert elapsed <= 20, 'Entry exceeded20s; original clock must not be renewed'
    if not args.run:
        save('root-single-step-entry-check-01.json', {'schema': 1, 'passed': True,
            'elapsed_seconds': elapsed, 'maximum_pre_dispatch_seconds': 20,
            'native_started': False, 'readiness_created': False, 'unit_before': before})
        print(json.dumps({'status': 'verified_unarmed', 'entry_seconds': elapsed}))
        return
    human = read(BASE / 'root-human-readiness-template-01.json')
    human.update(recorded_at_utc=ENTRY_UTC, recorded_at_monotonic=ENTRY_MONOTONIC,
        human_reply=args.human_reply, question_item_id=args.question_item_id)
    save('readiness.json', human)
    dispatch = {'schema': 1, 'original_readiness_utc': ENTRY_UTC,
        'original_readiness_monotonic': ENTRY_MONOTONIC,
        'operator_deadline_monotonic': ENTRY_MONOTONIC + 600,
        'launch_plan_sha256': digest(launch_path), 'launch_clearance_sha256': digest(clearance_path),
        'case_plan_sha256': PLAN_SHA, 'unit': launch['unit'], 'command': launch['command'],
        'unit_before': before, 'guard_before': guard, 'worktree_head_at_dispatch': head,
        'original_operator_seconds': 600, 'automatic_retries': False,
        'prior_run_cleanup': launch['prior_run_cleanup'], 'pre_dispatch_elapsed_seconds': elapsed,
        'idle_registration_reserve_seconds': 8, 'entry_maximum_seconds': 20}
    result = subprocess.run(launch['command'], text=True, capture_output=True, timeout=10)
    after = show(launch['unit'])
    dispatch.update(launch_returncode=result.returncode, launch_stdout=result.stdout,
        launch_stderr=result.stderr, unit_after_launch=after,
        original_owned_cgroup=after.get('ControlGroup', ''))
    if int(after.get('MainPID', '0')):
        pid = int(after['MainPID'])
        fields = Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()
        dispatch['owner_identity'] = {'pid': pid, 'start_ticks': int(fields[19]),
            'group': int(fields[2]), 'session': int(fields[3]), 'ppid': int(fields[1])}
    save('root-unit-dispatch-01.json', dispatch)
    assert result.returncode == 0 and after['ActiveState'] == 'active'
    assert dispatch['original_owned_cgroup'] and dispatch.get('owner_identity')
    print(json.dumps({'status': 'launched_once', 'unit': launch['unit'],
        'elapsed_original_seconds': time.monotonic() - ENTRY_MONOTONIC,
        'owner': dispatch['owner_identity']}))


if __name__ == '__main__':
    main()
