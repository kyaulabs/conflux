"""Analyze closed, retained evidence; no player, model or audio device starts."""
from pathlib import Path
import hashlib
import json
import math
import statistics

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
RUN = Path(__file__).resolve().parent / 'player-02'
HELPER = ROOT / 'build/m2-meter-stability-01/analyze_ui_comparison.py'
source = HELPER.read_text()
marker = "assert read(BASE/'root-finished-01.json')"
assert source.count(marker) == 1
namespace = {'__file__': str(HELPER)}
exec(compile(source.split(marker, 1)[0], str(HELPER), 'exec'), namespace)
result = json.loads((RUN / 'output-01/result.json').read_text())
native, observed = result['native'], result['observations']
closed = json.loads((RUN / 'root-finished-01.json').read_text())
assessment = json.loads((RUN / 'diagnostic-assessment.json').read_text())
assert closed['cleanup_complete'] and closed['root_verification_within_original_600_seconds']
assert assessment['diagnostic_complete'] and assessment['passed'] and native['passed']
assert native['measurement_intervals_closed'] and native['manual_controls_complete']
hops = observed['chunk_phases']['hops']
values = [row['hop_service_ms'] for row in hops]
assert len(values) == assessment['ordinary_assessment']['hop_count'] == 21
phases = ('source_read_ms', 'request_ms', 'overlap_ms', 'native_elapsed_ms',
    'native_inference_wall_ms', 'native_inference_cpu_ms', 'native_frontend_ms',
    'native_graph_ms', 'native_graph_upload_ms', 'native_graph_compute_ms',
    'native_graph_readback_ms', 'native_postprocess_ms', 'native_graph_rebuild_ms')
assert all(type(row.get(key)) in (int, float) and math.isfinite(row[key]) and row[key] >= 0
    for row in hops for key in phases)
p99 = sorted(values)[math.ceil(.99 * len(values)) - 1]
assert p99 == assessment['ordinary_assessment']['nearest_rank_p99_ms']
wave = namespace['scan_wave'](RUN / 'output-01/master.wav', native)
host = [json.loads(line) for line in (RUN / 'output-01/host-observations.jsonl').read_bytes().splitlines()]
threads = namespace['summarize_threads'](host)
controls = [{'kind': row['kind'], 'previous_generation': row['previous_generation'],
    'recovery_poll_upper_seconds': (row['recovered_cursor_observed_ns'] - row['issued_ns']) / 1e9,
    'recovered': True} for row in native['controls']]
analysis = {'schema': 1, 'status': 'complete_short_normal_runtime_diagnostic', 'qualified': False,
    'requested_seconds': 120, 'measured_seconds': native['measured_wall_ms'] / 1000,
    'runtime': native['setup']['runtime_sha256'], 'normal_runtime_used': True,
    'coarse_GPU_interval_instrumentation_enabled': False, 'getter_counters_enabled': False,
    'service_hops': len(hops), 'service_median_ms': statistics.median(values),
    'nearest_rank_p99_ms': p99, 'maximum_service_ms': max(values),
    'at_or_above_target': sum(value >= 4095 for value in values), 'strict_target_ms': 4095,
    'all13_service_phase_fields_finite': True,
    'service_phase_maxima_ms': {key: max(row[key] for row in hops) for key in phases},
    'service_telemetry_loss': observed['service_telemetry_loss'],
    'native_observation_counters': native['observation_counters'],
    'service_kind_counts': observed['kind_counts'],
    'ordinary_assessment': assessment['ordinary_assessment'],
    'steady_starved_seconds': native['steady_starved_frames'] / 48000,
    'seek_replay_starved_seconds': native['control_starved_frames'] / 48000,
    'controls_acknowledged': sum(row.get('acknowledged') is True for row in native['manual_controls']),
    'scheduled_controls': 16, 'manual_controls_complete': native['manual_controls_complete'],
    'completed_control_recoveries': controls,
    'incomplete_generation_seek_submitted': native['incomplete_generation_seek_submitted'],
    'cancellation_scope': 'Generation invalidation and recovery exercised; no hard GPU preemption or physical output-latency claim.',
    'callback_execution_deadline_misses': native['execution_deadline_misses'],
    'invalid_buffers': native['invalid_buffers'], 'rejected_commands': native['rejected_commands'],
    'source_read_failures': native['source_read_failures'], 'driver_timing': native['timing'],
    'UI': native['ui_coverage'], 'scene_errors': native['scene_errors'],
    'maximum_frame_presentation_gap_ns': native['maximum_frame_presentation_gap_ns'],
    'maximum_gui_heartbeat_gap_ns': native['maximum_gui_heartbeat_gap_ns'],
    'window_failure': native.get('window_failure'),
    'post_failure_observation_exercised': 'window_failure_followup' in native,
    'WAV': wave, 'thermal_summary': result['thermal_summary'], 'cleanup': closed,
    'analysis_source': {'path': str(HELPER), 'sha256': hashlib.sha256(HELPER.read_bytes()).hexdigest()},
    'scope': 'Short120s current-source actual-player diagnostic. Exposure failure did not recur, so no recovery duration or callback-timeout cause is established. No sustained, musical, physical-latency or M2 qualification.'}
for name, value in [('root-audio-results-01.json', analysis), ('root-thread-cpu-analysis-01.json', threads)]:
    with (RUN / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
print(json.dumps({key: analysis[key] for key in ('status', 'measured_seconds', 'service_hops',
    'nearest_rank_p99_ms', 'at_or_above_target', 'steady_starved_seconds',
    'seek_replay_starved_seconds', 'controls_acknowledged', 'completed_control_recoveries',
    'post_failure_observation_exercised', 'WAV', 'thermal_summary')}))
