"""Check the music candidate's exact graph and batching on frozen generated data."""
from pathlib import Path
import hashlib
import importlib.util
import json
import resource
import time

BASE=Path(__file__).resolve().parent
DATA=BASE/'input'
OUT=BASE/'local-output-01'
OUT.mkdir(mode=0o700)
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
began=time.monotonic()
report=dict(schema=1,passed=False,qualified=False,host='laptop',audio_device_opened=False,GPU_used=False,
    musical_accuracy_qualified=False,physical_readiness_consumed=False,comparisons=[])

def main():
    import numpy as np
    assert np.__version__=='1.23.5'
    plan=json.loads((BASE/'plan-01.json').read_text())
    for row in plan['inputs']:
        raw=Path(row['path']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    manifest=json.loads((BASE/'input-manifest-01.json').read_text())
    for row in manifest['files']:
        raw=(DATA/row['file']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    fixtures=json.loads((DATA/'fixtures.json').read_text())
    def array(row,dtype):return np.frombuffer((DATA/row['file']).read_bytes(),dtype=dtype).reshape(row['shape']).copy()
    features=array(fixtures['features'],'<f8');expected=[(r['name'],array(r,'<f4')) for r in fixtures['expected']]
    path=Path(plan['inputs'][1]['path'])
    spec=importlib.util.spec_from_file_location('exact_music_numeric',path);numeric=importlib.util.module_from_spec(spec);spec.loader.exec_module(numeric)
    weights=numeric.weights();normalized=numeric.normalize(features)
    report['normalization_bit_exact']=bool(np.array_equal(normalized.view('u4'),expected[0][1].view('u4')))
    assert report['normalization_bit_exact']
    report.update(model_sha256=plan['model_sha256'],config_sha256=plan['config_sha256'],numpy=np.__version__,
        parameter_count=sum(v.size for v in weights.values()),numeric_tensors=len(weights),batch_sizes=plan['batch_sizes'])
    assert report['parameter_count']==plan['parameters'] and len(weights)==74
    top=[]
    for batch in plan['batch_sizes']:
        chunks=[numeric.forward_normalized(normalized[first:first+batch],weights)[1] for first in range(0,len(features),batch)]
        observed=[(name,np.concatenate([c[i][1] for c in chunks],axis=0)) for i,(name,_) in enumerate(expected)]
        for (name,wanted),(actual_name,value) in zip(expected[1:],observed[1:]):
            assert name==actual_name and value.shape==wanted.shape and np.isfinite(value).all()
            tolerance=plan['posterior_tolerance'] if name=='activation' else plan['layer_tolerance']
            delta=np.abs(value.astype(np.float64)-wanted.astype(np.float64))
            report['comparisons'].append(dict(batch=batch,layer=name,passed=bool(np.allclose(value,wanted,**tolerance)),
                maximum_absolute_error=float(delta.max()),elements=int(delta.size),tolerance=tolerance))
        probabilities=observed[-1][1];top.append(bool(np.array_equal(probabilities.argmax(axis=1),fixtures['top_one'])))
        (OUT/('posterior-%d.f32'%batch)).write_bytes(probabilities.astype('<f4').tobytes())
    report['posterior_top_one_matches']=all(top)
    report['passed']=all(row['passed'] for row in report['comparisons']) and all(top)

try:main()
except Exception as error:report['error']=dict(type=type(error).__name__,message=str(error)[:2000])
finally:
    report['seconds']=time.monotonic()-began
    (OUT/'result.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='comparisons'},allow_nan=False))
raise SystemExit(0 if report['passed'] else 1)
