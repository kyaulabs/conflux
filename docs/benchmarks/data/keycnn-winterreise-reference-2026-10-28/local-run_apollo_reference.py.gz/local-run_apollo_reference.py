"""Run one bounded CPU-only reference through Apollo's private Docker daemon."""
from pathlib import Path
import subprocess

BASE=Path(__file__).resolve().parent
CODE=r'''
from pathlib import Path
import hashlib,json,subprocess,time
p=Path('/srv/conflux-tests/work/keycnn-winterreise-tf115-20261028-01')
prepared=json.loads((p/'preparation-01.json').read_text())
docker=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(docker+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
image=json.loads(subprocess.check_output(docker+['image','inspect',prepared['image_id']]))[0]
assert image['Id']==prepared['image_id'] and image['Config']['Labels']['io.kyaulabs.conflux.test']=='keycnn-tf115-reference-20261028-01'
assert hashlib.sha256((p/'reference.py').read_bytes()).hexdigest()==prepared['reference_sha256']
manifest=json.loads((p/'input-manifest-01.json').read_text())
assert hashlib.sha256((p/'input-manifest-01.json').read_bytes()).hexdigest()==prepared['input_manifest_sha256']
def verify():
 for row in manifest['files']:
  raw=(p/'input'/row['file']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
verify();out=p/'output-01';out.mkdir(mode=0o755)
name='conflux-keycnn-winterreise-tf115-20261028-01';label='keycnn-winterreise-tf115-20261028-01'
assert subprocess.run(docker+['inspect',name],capture_output=True).returncode!=0
command=docker+['run','--name',name,'--label','io.kyaulabs.conflux.test='+label,'--runtime=runc','--network=none','--read-only',
 '--cpus=1','--memory=2g','--pids-limit=128','--cap-drop=ALL','--security-opt=no-new-privileges',
 '--user=1000:1000','--tmpfs=/tmp:rw,noexec,nosuid,nodev,size=64m,mode=1777',
 '--env=CUDA_VISIBLE_DEVICES=-1','--env=HOME=/tmp','--env=TF_CPP_MIN_LOG_LEVEL=2',
 '--env=OPENBLAS_NUM_THREADS=1','--env=OMP_NUM_THREADS=1','--env=MKL_NUM_THREADS=1','--env=PYTHONHASHSEED=0',
 '--mount','type=bind,src='+str(p/'input')+',dst=/input,readonly',
 '--mount','type=bind,src='+str(p/'reference.py')+',dst=/reference.py,readonly',
 '--mount','type=bind,src='+str(out)+',dst=/out','--entrypoint=/usr/bin/timeout',
 image['Id'],'--signal=TERM','--kill-after=5s','110','/usr/local/bin/python','-B','/reference.py']
receipt=dict(schema=1,command=command,CPU_cores=1,execution_seconds=120,GPU_requested=False,host_audio_opened=False,
 musical_accuracy_qualified=False,protected_resources_changed=False,physical_readiness_consumed=False)
start=time.monotonic()
try:
 with (p/'stdout-01.log').open('x') as stdout,(p/'stderr-01.log').open('x') as stderr:
  r=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=120)
 receipt['exit']=r.returncode
except BaseException as error:receipt.update(exit=124,error=dict(type=type(error).__name__,message=str(error)[:2000]))
finally:
 found=subprocess.run(docker+['inspect',name],capture_output=True,text=True,timeout=10)
 if found.returncode==0:
  container=json.loads(found.stdout)[0]
  assert container['Image']==image['Id'] and container['Config']['Labels'].get('io.kyaulabs.conflux.test')==label
  if container['State']['Running']:subprocess.run(docker+['stop','--time','5',container['Id']],capture_output=True,check=True,timeout=10)
  state=json.loads(subprocess.check_output(docker+['inspect',container['Id']]))[0]['State']
  assert state['Running'] is False and state['Pid']==0
  subprocess.run(docker+['rm',container['Id']],capture_output=True,check=True,timeout=10)
  receipt['container_state']=state
 assert subprocess.run(docker+['inspect',name],capture_output=True,timeout=5).returncode!=0
 verify();receipt.update(container_removed=True,input_hashes_unchanged=True,seconds=time.monotonic()-start)
 if (out/'result.json').exists():
  result=json.loads((out/'result.json').read_text())
  receipt.update(numerical_passed=result.get('passed'),comparisons=len(result.get('comparisons',[])),
   model_sha256=result.get('model_sha256'),failed_layers=[dict(batch=x['batch'],layer=x['layer'],maximum_absolute_error=x['maximum_absolute_error']) for x in result.get('comparisons',[]) if not x['passed']])
 (p/'execution-result-01.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
print(json.dumps(receipt,allow_nan=False),flush=True)
if receipt['exit']:print((p/'stderr-01.log').read_text()[-3000:])
raise SystemExit(receipt['exit'])
'''
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
    '-o','ClearAllForwardings=yes','-p','4222','kyau@apollo.kyaulabs','python3 -']
with (BASE/'apollo-run-01.log').open('x') as log:r=subprocess.run(ssh,input=CODE,text=True,stdout=log,stderr=subprocess.STDOUT,timeout=150)
print((BASE/'apollo-run-01.log').read_text()[-5000:]);raise SystemExit(r.returncode)
