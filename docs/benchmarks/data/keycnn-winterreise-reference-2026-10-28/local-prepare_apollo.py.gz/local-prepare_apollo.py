"""Copy only the frozen generated reference into CONFLUX's private Apollo area."""
from pathlib import Path
import hashlib
import json
import subprocess

BASE=Path(__file__).resolve().parent
HOST='kyau@apollo.kyaulabs'
REMOTE='/srv/conflux-tests/work/keycnn-winterreise-tf115-20261028-01'
OPTIONS=['-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes']
def ssh(code):return subprocess.run(['ssh']+OPTIONS+['-p','4222',HOST,'python3 -'],input=code,text=True,capture_output=True,check=True,timeout=45)
ssh("from pathlib import Path;p=Path("+repr(REMOTE)+");assert not p.exists();p.mkdir(mode=0o750)\n")
archive=BASE/'input-package-01.tar.gz'
subprocess.run(['scp']+OPTIONS+['-P','4222',str(archive),HOST+':'+REMOTE+'/'],check=True,timeout=60)
code=r'''
from pathlib import Path
import hashlib,json,subprocess,tarfile
p=Path('/srv/conflux-tests/work/keycnn-winterreise-tf115-20261028-01')
archive=p/'input-package-01.tar.gz';assert hashlib.sha256(archive.read_bytes()).hexdigest()==ARCHIVE_SHA
with tarfile.open(archive,'r:gz') as t:
 for member in t.getmembers():
  leaf=p/member.name
  assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  assert member.isdir() or member.isfile()
  if member.isdir():leaf.mkdir(mode=0o750,parents=True,exist_ok=True)
  else:
   assert member.size<=16*1024*1024
   leaf.parent.mkdir(mode=0o750,parents=True,exist_ok=True)
   with t.extractfile(member) as src,leaf.open('xb') as out:
    while raw:=src.read(1024*1024):out.write(raw)
manifest=json.loads((p/'input-manifest-01.json').read_text())
for row in manifest['files']:
 raw=(p/'input'/row['file']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
assert hashlib.sha256((p/'reference.py').read_bytes()).hexdigest()==(p/'reference.sha256').read_text().strip()
docker=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(docker+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
image=json.loads(subprocess.check_output(docker+['image','inspect','conflux-keycnn-tf115-reference:20261028-01']))[0]
assert image['Config']['Labels']['io.kyaulabs.conflux.test']=='keycnn-tf115-reference-20261028-01'
assert image['Id']==json.loads(Path('/srv/conflux-tests/keycnn-tf115-reference-20261028-01/execution-plan-01.json').read_text())['image_id']
receipt=dict(image_id=image['Id'],input_file_count=len(manifest['files']),input_manifest_sha256=hashlib.sha256((p/'input-manifest-01.json').read_bytes()).hexdigest(),
 reference_sha256=hashlib.sha256((p/'reference.py').read_bytes()).hexdigest(),GPU_requested=False,audio_device_opened=False,model_executed=False,protected_resources_changed=False)
(p/'preparation-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
'''.replace('ARCHIVE_SHA',repr(hashlib.sha256(archive.read_bytes()).hexdigest()))
result=ssh(code)
(BASE/'apollo-preparation-01.json').write_text(result.stdout)
print(result.stdout)
