#!/usr/bin/env python3
"""Root-only named-text archive of closed timing checks; default is a dry plan."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
DEST = ROOT / 'docs/benchmarks/data/m2-live-bridge-timing-2026-10-19'
RUNNER_SHA = '5a53a04188c5044949e318c0d2303b7a2a749fb9ccd00a0fe66941edbb26ea09'
STAGES = ['full-build', 'ctest', 'smoke', 'normal-routing', 'normal-preparation', 'coverage']
TOP = ['live-bridge-timing-api.hpp', 'live-bridge-timing-api.md', 'live-bridge-timing-api-freeze.json',
       'live-bridge-timing-request-clarification.json', 'live-bridge-timing-completion-clarification.json',
       'live-bridge-timing-tests-freeze.json', 'live-bridge-timing-tests-inputs.json',
       'live-bridge-timing-product-inputs.json', 'live-bridge-timing-implementation-freeze.json',
       'live-bridge-timing-test-application.json', 'live-bridge-timing-product-application.json',
       'live-bridge-timing-develop-base.json', 'live-bridge-timing-red-result.json',
       'live-bridge-timing-green-result.json', 'live-bridge-timing-green-artifact-pins.json',
       'live-bridge-timing-check-runner-freeze.json']
PATCHES = ['live-bridge-timing-tests.patch', 'controller-live-timing-tests.patch',
           'live-bridge-timing-fixture.patch', 'live-bridge-timing-implementation.patch']
COVERAGE_LOGS = ['configure', 'build', 'ctest', 'smoke', 'private-routing', 'private-preparation',
                 'gcovr', 'python-combine', 'python-json', 'python-html', 'python-xml']
PRIVATE_TEXT = ['result.json', 'check.stdout.json', 'check.stderr.log', 'daemon.log',
                'preflight-pw-dump.json', 'preflight-pw-dump.stderr.log',
                'cleanup-pw-dump.json', 'cleanup-pw-dump.stderr.log']
OPTIONAL_PRIVATE = ['cue-removal.json', 'source-handoff.json', 'source-handoff-receiver.json',
                    'live-owner-installed.json', 'live-owner-installed-receiver.json',
                    'live-owner-immediate.json', 'live-owner-immediate-receiver.json',
                    'controller-preparation-phase.json', 'live-failure.json', 'failure-pw-dump.json']


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def meta(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read(path):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= 64 * 1024 * 1024,
            'Unsafe/oversized named text artifact: ' + str(path))
    data = path.read_bytes()
    after = path.lstat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) and len(data) == before.st_size,
            'Named text artifact changed: ' + str(path))
    require(b'\0' not in data, 'Binary payload is not permitted: ' + str(path))
    data.decode('utf-8')
    return data


def load(path):
    return json.loads(read(path))


def file_pin(path):
    before = path.stat()
    require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= 512 * 1024 * 1024, 'Invalid pinned file')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), 'Pinned bytes changed')
    return {'bytes': before.st_size, 'sha256': digest.hexdigest()}


def command(argv, timeout=20):
    result = subprocess.run(argv, cwd=ROOT, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    require(result.returncode == 0, 'Metadata command failed: ' + repr(argv))
    return result.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--head', help='final signed timing source commit; not the later evidence commit')
    parser.add_argument('--checks', type=Path, default=BASE / 'live-bridge-timing-checks-01')
    parser.add_argument('--root-report', type=Path, default=BASE / 'live-bridge-timing-root-report.json',
                        help='root metadata JSON with source_head matching --head; retained without inventing CI claims')
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({'status': 'dry_plan_only', 'destination': str(DEST), 'head': args.head,
                          'checks': str(args.checks), 'scope': 'No artifact, Git, binary, model or host reads in dry mode'}))
        return 0
    require(bool(re.fullmatch('[0-9a-f]{40}', args.head or '')), 'Exact final signed --head is required')
    checks = args.checks.resolve()
    require(checks.is_relative_to(BASE) and checks != BASE, 'Check receipt must be within BASE')
    result = load(checks / 'result.json')  # Closure check precedes any run logs/report reads.
    require(result.get('status') == 'timing_checks_passed' and result.get('finished_at_utc') and
            result.get('source_and_binaries_stable') and result.get('source_pins_unchanged_at_close') and
            result.get('binary_reuse') is False and result.get('cli_rerun') is False and not result.get('errors'),
            'Timing pipeline is not closed and successful')
    rows = result['stages']
    require([r['stage'] for r in rows] == STAGES and all(r['exit'] == 0 and not r['timed_out'] and
            not r['interrupted'] and r['reused'] is False and r['executed_in_this_pipeline'] is True and
            r['cleanup']['group_gone'] and r['cleanup']['leader_reaped'] and
            not r['cleanup']['unexpected_group_after_exit'] for r in rows), 'Six stage results are incomplete')
    require(rows[0]['command'] == ['cmake', '--build', 'build/dev', '--parallel', '2'] and
            rows[2]['command'] == ['build/dev/conflux', '--smoke-test'] and
            rows[-1]['command'][-4:] == ['tools/coverage/run.py', '--private-routing', '--jobs', '2'],
            'Build/smoke/coverage command differs')
    sources = load(checks / 'source-pins.json')
    require(sources[str((BASE / 'run_live_bridge_timing_checks.py').relative_to(ROOT))]['sha256'] == RUNNER_SHA,
            'Executed runner pin differs from reviewed source')
    artifacts = load(checks / 'built-artifact-pins.json')
    require(set(artifacts) == {'build/dev', 'build/coverage'} and all(artifacts.values()), 'Built-artifact groups absent')
    for row, binary in zip(rows[3:5], ['conflux-manual-routing-check', 'conflux-preparation-controller-check']):
        require('--functional-only' not in row['command'] and row['command'][-2] == 'build/dev/' + binary,
                'Normal private helper/mode differs')
    suite = ET.fromstring(read(checks / 'normal-ctest.xml'))
    require(int(suite.attrib['tests']) == 36 and int(suite.attrib.get('failures', 0)) == 0 and
            not any(t.find('skipped') is not None for t in suite.iter('testcase')), 'Normal CTest is incomplete')
    coverage = load(checks / 'coverage-reports/summary.json')
    require(coverage['execution_passed'] and not coverage['errors'] and coverage['private_routing_requested'] and
            not coverage['private_routing_execution_deadline_gate'] and
            all(s['exit'] == 0 for s in coverage['stages'].values()), 'Coverage execution/reporting failed')
    require(command(['git', 'rev-parse', 'HEAD']).decode().strip() == args.head, 'HEAD differs from final source')
    signature = command(['git', 'show', '-s', '--format=%H %G? %GF %ae', args.head]).decode().strip()
    require(signature.split()[0:2] == [args.head, 'G'] and signature.split()[-1] == 'kyau@kyau.net', 'Source signature is not valid')
    tracked = set(command(['git', 'ls-files', '-z', '--', *sources]).decode().rstrip('\0').split('\0'))
    runner_name = str((BASE / 'run_live_bridge_timing_checks.py').relative_to(ROOT))
    require(tracked == set(sources) - {runner_name}, 'Pinned product/support input is not tracked in source')
    require(command(['git', 'diff', args.head, '--', *sources]) == b'', 'Worktree source differs from signed commit')
    root_report_path = args.root_report.resolve()
    require(root_report_path.is_relative_to(BASE), 'Root metadata receipt must be below BASE')
    root_report = load(root_report_path)
    require(root_report.get('source_head') == args.head, 'Root report source head differs')

    def verify_pins():
        for name, expected in sources.items():
            require(file_pin(ROOT / name) == expected, 'Source pin changed: ' + name)
        for group in artifacts.values():
            for name, expected in group.items():
                require(file_pin(ROOT / name) == expected, 'Built artifact pin changed: ' + name)
    verify_pins()
    product_freeze_path = BASE / 'live-bridge-timing-implementation-freeze.json'
    test_freeze_path = BASE / 'live-bridge-timing-tests-freeze.json'
    require(meta(read(product_freeze_path)) == {'bytes': 7985, 'sha256': '3b37cc45c2eec1fa72879d14a807a99a57a9d25840d08cc435890816a0cd94de'},
            'Reviewed product freeze changed')
    require(meta(read(test_freeze_path)) == {'bytes': 9160, 'sha256': '5cd5996db142dd79c3f78a26c8579a653ee270755aa725d384cfae283c40ec2e'},
            'Reviewed independent test freeze changed')
    product_freeze = load(product_freeze_path)
    test_freeze = load(test_freeze_path)

    def check_receipt_pin(entry):
        require(meta(read(ROOT / entry['path'])) == {k: entry[k] for k in ('bytes', 'sha256')},
                'Frozen provenance bytes changed: ' + entry['path'])
    for entry in [product_freeze['patch'], product_freeze['actual_red'], *product_freeze['contract_inputs'],
                  test_freeze['api_freeze'], test_freeze['api_header'], test_freeze['api_document'], *test_freeze['patches']]:
        check_receipt_pin(entry)
    red = load(BASE / 'live-bridge-timing-red-result.json')
    frozen_tests = {item['path']: item['output'] for item in test_freeze['files']}
    require(red['status'] == 'actual_missing_API_RED' and red['product_or_declaration_applied'] is False and
            len(red['stages']) == 1 and red['stages'][0]['exit'] == 1 and
            'LiveStemObservations.hpp' in red['diagnostic'] and red['applied_test_sources'] == frozen_tests,
            'Actual RED is not the frozen missing-API failure before product')
    check_receipt_pin(red['test_freeze'])
    applied_tests = load(BASE / 'live-bridge-timing-test-application.json')
    applied_product = load(BASE / 'live-bridge-timing-product-application.json')
    check_receipt_pin(applied_tests['test_freeze'])
    require(applied_tests['status'] == 'independent_frozen_tests_applied_before_product' and
            applied_tests['api_or_product_applied'] is False and applied_tests['signed_base'] == red['signed_base'] and
            applied_tests['files'] == frozen_tests and applied_product['product_applied_exact'] is True and
            applied_product['frozen_tests_unchanged'] is True and
            applied_product['patch'] == {k: product_freeze['patch'][k] for k in ('bytes', 'sha256')} and
            applied_product['actual_red_receipt'] == meta(read(BASE / 'live-bridge-timing-red-result.json')),
            'Frozen TDD application history differs')
    expected_outputs = {name: {key: item[key] for key in ('bytes', 'sha256')}
                        for name, item in product_freeze['product_snapshots'].items()}
    expected_outputs.update({item['path']: item['output'] for item in test_freeze['files']})
    require(all(sources.get(name) == expected for name, expected in expected_outputs.items()),
            'Executed source differs from one of nine frozen product/test outputs')
    green = load(BASE / 'live-bridge-timing-green-result.json')
    require(green['source_stable'] and all(r['exit'] == 0 and not r['timed_out'] for r in green['stages']), 'Focused GREEN failed')
    require(green['source_pins'] == {name: item['sha256'] for name, item in expected_outputs.items()},
            'Focused GREEN does not bind all nine frozen outputs')
    for name, sha in green['source_pins'].items():
        require(file_pin(ROOT / name)['sha256'] == sha, 'Focused source differs: ' + name)
    private = {}
    for mode, directory, gate in [('normal-routing', checks / 'normal-routing', True),
                                  ('normal-preparation', checks / 'normal-preparation', True),
                                  ('coverage-routing', checks / 'coverage-reports/private-routing', False),
                                  ('coverage-preparation', checks / 'coverage-reports/private-preparation', False)]:
        value = load(directory / 'result.json')
        require(value['passed'] and value['check_exit'] == 0 and value['check']['passed'] and not value['check'].get('error') and
                value['daemon_reaped'] and not value['cleanup']['remaining_nodes_or_links'] and
                value['execution_deadline_gate'] is gate, 'Private result/mode/cleanup failed: ' + mode)
        private[mode] = {'checks': len(value['check']['checks']), 'wrapper_execution_deadline_gate': gate,
                         'inner_execution_deadline_gate': value['check'].get('execution_deadline_gate'),
                         'daemon_reaped': True, 'remaining_nodes_or_links': []}

    stage = DEST.with_name('.' + DEST.name + '.stage')
    raw = checks / 'archive-raw'
    require(not any(os.path.lexists(p) for p in (DEST, stage, raw)), 'Fresh canonical/staging/raw paths required')
    stage.mkdir(mode=0o700); raw.mkdir(mode=0o700)
    files, origins, uncompressed = {}, {}, {}
    total = 0

    def add(path, name, compress=False):
        nonlocal total
        require('/' not in name and name not in files, 'Unsafe/duplicate archive name')
        data = read(path); total += len(data)
        require(total <= 128 * 1024 * 1024, 'Named text archive exceeds 128 MiB')
        raw_name = name.removesuffix('.gz')
        require(not (raw / raw_name).exists(), 'Raw file name collision')
        (raw / raw_name).write_bytes(data)
        origins[name] = {'path': str(path.relative_to(ROOT)), **meta(data)}
        if path.suffix == '.jsonl':
            require(not data or data.endswith(b'\n'), 'Truncated JSONL archive input')
            origins[name]['rows'] = len(data.splitlines())
        if compress:
            uncompressed[name] = meta(data); data = gzip.compress(data, mtime=0)
        (stage / name).write_bytes(data); files[name] = meta(data)

    for name in TOP:
        add(BASE / name, name)
    for name in PATCHES:
        add(BASE / name, name + '.gz', True)
    for name in ['live-bridge-timing-red-build.log', 'live-bridge-timing-green-build.log',
                 'live-bridge-timing-green-bridge.log', 'live-bridge-timing-green-controller.log']:
        add(BASE / name, name + '.gz', True)
    for name in ['result.json', 'source-pins.json', 'built-artifact-pins.json', 'normal-ctest.xml']:
        add(checks / name, name)
    for name in STAGES:
        add(checks / (name + '.log'), name + '.log.gz', True)
    for name in ['summary.json', 'cpp.json', 'cpp-summary.json', 'cpp.xml', 'python.json', 'python.xml']:
        add(checks / 'coverage-reports' / name, 'coverage-' + name + '.gz', True)
    for name in COVERAGE_LOGS:
        add(checks / 'coverage-reports' / (name + '.log'), 'coverage-' + name + '.log.gz', True)
    for mode, directory in [('normal-routing', checks / 'normal-routing'), ('normal-preparation', checks / 'normal-preparation'),
                             ('coverage-routing', checks / 'coverage-reports/private-routing'),
                             ('coverage-preparation', checks / 'coverage-reports/private-preparation')]:
        for name in PRIVATE_TEXT:
            add(directory / name, mode + '-' + name + '.gz', True)
        for name in OPTIONAL_PRIVATE:
            if os.path.lexists(directory / name):
                add(directory / name, mode + '-' + name + '.gz', True)
    add(BASE / 'run_live_bridge_timing_checks.py', 'run_live_bridge_timing_checks.py.gz', True)
    add(Path(__file__).resolve(), 'archive_live_bridge_timing.py.gz', True)
    add(root_report_path, 'root-report.json')
    scan_log, scan_report = checks / 'archive-gitleaks.log', checks / 'archive-gitleaks-findings.json'
    require(not os.path.lexists(scan_log) and not os.path.lexists(scan_report), 'Fresh scan outputs required')
    scanned_bytes = total
    with scan_log.open('xb') as output:
        scan = subprocess.run(['gitleaks', 'dir', str(raw), '--redact', '--no-color', '--report-format', 'json',
                               '--report-path', str(scan_report)], cwd=ROOT, stdin=subprocess.DEVNULL,
                              stdout=output, stderr=subprocess.STDOUT, timeout=90)
    require(scan.returncode == 0 and load(scan_report) == [], 'Raw scan failed; no canonical publication')
    add(scan_log, 'raw-gitleaks.log.gz', True); add(scan_report, 'raw-redacted-gitleaks-findings.json')
    verification = {'schema': 'conflux.m2-live-bridge-timing.v1', 'status': 'synthetic_timing_checks_passed',
        'source_head': args.head, 'source_signature': signature, 'actual_red': red, 'frozen_TDD_provenance_verified': True,
        'focused_green': green, 'full_stages': rows, 'normal_ctest': suite.attrib,
        'built_artifact_scope': result['artifact_pin_scope'], 'private': private,
        'coverage': coverage, 'source_and_built_artifact_pins_verified': True,
        'future_harness_included': False, 'cli_rerun': False, 'raw_secret_scan_exit': 0,
        'raw_scanned_input_bytes': scanned_bytes,
        'scan_scope': 'Named uncompressed inputs before generated manifest/scanner-output packaging; no suppressions',
        'deterministic_gzip_roundtrip_verified': True, 'files': files, 'origins': origins, 'uncompressed': uncompressed,
        'limits': ['Synthetic observations tests, no actual-model or physical playback workload.',
                   'Service-hop timing, whole-lease validation and publication are separate; no cross-clock subtraction.',
                   'Packet acceptance does not prove recovery grant/open gate or callback consumption.',
                   'Queue loss, service telemetry loss and session snapshot drops remain distinct.',
                   'No new sustained p99, fallback or integrated/physical latency qualification; strict 4,095 ms target unchanged.',
                   'Coverage is instrumented functionality with its existing disabled deadline gates and measured-scope exclusions.',
                   'Normal preparation retains its intentionally false inner deadline gate even though its outer wrapper gate is true; it does not qualify callback latency.',
                   'Built-artifact pins include unexecuted experiments; only stage records prove execution.',
                   'CI and remote state are reported only by the separately retained root report; no new CI inferred.']}
    for name, expected in files.items():
        require(meta((stage / name).read_bytes()) == expected, 'Archived bytes changed')
    for name, expected in uncompressed.items():
        require(meta(gzip.decompress((stage / name).read_bytes())) == expected, 'Gzip roundtrip failed')
    for origin in origins.values():
        require(meta(read(ROOT / origin['path'])) == {k: origin[k] for k in ('bytes', 'sha256')}, 'Input changed during archive')
    verify_pins()
    require(command(['git', 'rev-parse', 'HEAD']).decode().strip() == args.head and
            command(['git', 'diff', args.head, '--', *sources]) == b'', 'Signed source changed during archive')
    (stage / 'verification.json').write_text(json.dumps(verification, indent=2, allow_nan=False) + '\n')
    stage.rename(DEST)
    print(json.dumps({'status': verification['status'], 'destination': str(DEST), 'files': len(files) + 1}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
