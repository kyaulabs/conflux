#!/usr/bin/env python3
"""Run the timing-only normal/private/coverage checks in a fresh evidence directory."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'benchmarks-local/m2-live-delivery-2026-10-19'
SELF = Path(__file__).resolve()
# These unchanged private wrappers retain their own daemon cleanup finally.
LAUNCHER = (
    "import runpy, signal, sys\n"
    "def stop(*_):\n"
    "    signal.signal(signal.SIGTERM, signal.SIG_IGN)\n"
    "    raise InterruptedError('Timing validation stage stopped')\n"
    "signal.signal(signal.SIGTERM, stop)\n"
    "signal.signal(signal.SIGINT, stop)\n"
    "sys.argv = sys.argv[1:]\n"
    "runpy.run_path(sys.argv[0], run_name='__main__')\n")


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def source_pins():
    names = {SELF, ROOT / 'CMakeLists.txt', ROOT / '.github/workflows/build.yml',
             ROOT / 'tools/coverage/run.py', ROOT / 'tools/coverage/requirements.txt',
             ROOT / 'brand/integration/qtquick/qmldir'}
    for folder in ('src', 'qml', 'tests', 'tools/stems', 'tools/runtime',
                   'tools/benchmarks', 'tools/experiments', 'brand/integration/qtquick'):
        names.update(p for p in (ROOT / folder).rglob('*') if p.is_file() and
                     (p.suffix in {'.cpp', '.hpp', '.h', '.qml', '.py', '.cmake'} or p.name == 'CMakeLists.txt'))
    # No ignored future harness draft or other BASE helper enters this pin set.
    return {str(p.relative_to(ROOT)): pin(p) for p in sorted(names)}


def binary_pins(folder):
    paths = sorted(p for p in folder.glob('conflux*') if p.is_file() and os.access(p, os.X_OK))
    required = {'conflux', 'conflux-live-stem-bridge-test', 'conflux-deck-controller-test',
                'conflux-manual-ui-test', 'conflux-manual-routing-check', 'conflux-preparation-controller-check'}
    if not required <= {p.name for p in paths}:
        raise RuntimeError('Fresh full build is missing required binaries')
    return {str(p.relative_to(ROOT)): pin(p) for p in paths}


def save(path, value):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')
    os.replace(temporary, path)


def group_alive(group):
    try:
        os.killpg(group, 0)
        return True
    except ProcessLookupError:
        return False


def finish_group(child, terminate):
    """Only this stage's published new-session group; no process discovery."""
    group = child.pid
    unexpected = not terminate and group_alive(group)
    if terminate or unexpected:
        try:
            os.killpg(group, signal.SIGTERM)
        except ProcessLookupError:
            pass
    deadline = time.monotonic() + (20 if terminate or unexpected else 0)
    while group_alive(group) and time.monotonic() < deadline:
        child.poll()
        time.sleep(.05)
    killed = False
    if group_alive(group):
        killed = True
        try:
            os.killpg(group, signal.SIGKILL)
        except ProcessLookupError:
            pass
    try:
        child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        return {'group_gone': False, 'leader_reaped': False, 'kill_fallback': killed,
                'unexpected_group_after_exit': unexpected}
    deadline = time.monotonic() + 5
    while group_alive(group) and time.monotonic() < deadline:
        time.sleep(.05)
    return {'group_gone': not group_alive(group), 'leader_reaped': child.returncode is not None,
            'kill_fallback': killed, 'unexpected_group_after_exit': unexpected}


def private_result(path):
    value = json.loads(path.read_text())
    if not (value.get('passed') and value.get('check_exit') == 0 and value.get('check', {}).get('passed')
            and not value.get('check', {}).get('error') and value.get('daemon_reaped')
            and not value.get('cleanup', {}).get('remaining_nodes_or_links')
            and value.get('execution_deadline_gate') is True):
        raise RuntimeError('Normal private check or owned-daemon cleanup failed: ' + str(path))
    return {'path': str(path.relative_to(ROOT)), 'pin': pin(path),
            'scope': value.get('scope'), 'execution_deadline_gate': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', help='execute the six-stage check pipeline')
    parser.add_argument('--output', type=Path, default=BASE / 'live-bridge-timing-checks-01')
    args = parser.parse_args()
    output = args.output.resolve()
    commands = [
        ('full-build', ['cmake', '--build', 'build/dev', '--parallel', '2'], 600),
        ('ctest', ['ctest', '--test-dir', 'build/dev', '--output-on-failure', '--timeout', '120',
                   '--output-junit', str(output / 'normal-ctest.xml')], 900),
        ('smoke', ['build/dev/conflux', '--smoke-test'], 30),
        ('normal-routing', ['python3', '-B', '-c', LAUNCHER, 'tools/experiments/private_routing_check.py',
                            'build/dev/conflux-manual-routing-check', str(output / 'normal-routing')], 180),
        ('normal-preparation', ['python3', '-B', '-c', LAUNCHER, 'tools/experiments/private_routing_check.py',
                                'build/dev/conflux-preparation-controller-check', str(output / 'normal-preparation')], 180),
        ('coverage', ['benchmarks-local/coverage-venv/bin/python', '-B', '-c', LAUNCHER,
                      'tools/coverage/run.py', '--private-routing', '--jobs', '2'], 1800),
    ]
    if not args.run:
        print(json.dumps({'status': 'dry_plan_only', 'output': str(output), 'stages': commands,
                          'no_reuse': True, 'cli_rerun': False}, indent=2))
        return 0
    if not output.is_relative_to(BASE) or output == BASE:
        parser.error('Evidence must use a fresh child directory below this timing BASE')
    output.mkdir(mode=0o700, exist_ok=False)  # Never replace failed or completed evidence.
    state = {'schema': 1, 'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
             'scope': 'Timing-only product validation; no real model, host audio, physical latency or future harness execution',
             'stages': [], 'binary_reuse': False, 'cli_rerun': False, 'errors': [],
             'artifact_pin_scope': 'Built-artifact pins include unexecuted experiment binaries; only named stage binaries have execution evidence',
             'cleanup_scope': 'Published outer stage groups are cleaned/probed; successful private daemon cleanup is established by each private result'}
    initial, artifacts = None, {}
    stopping = False
    previous = {}

    def stop(*_):
        nonlocal stopping
        stopping = True  # No raising handler between Popen and owner publication.

    for sig in (signal.SIGINT, signal.SIGTERM):
        previous[sig] = signal.signal(sig, stop)
    environment = os.environ | {'QT_QPA_PLATFORM': 'offscreen', 'QT_QUICK_BACKEND': 'software',
                                'QT_QUICK_CONTROLS_STYLE': 'Basic'}
    try:
        initial = source_pins()
        save(output / 'source-pins.json', initial)
        save(output / 'result.json', state)
        for name, command, limit in commands:
            if stopping:
                raise InterruptedError('Timing checks stopped before next stage')
            if source_pins() != initial:
                raise RuntimeError('Timing source inputs changed before stage ' + name)
            row = {'stage': name, 'command': command, 'timeout_seconds': limit,
                   'executed_in_this_pipeline': True, 'reused': False, 'exit': None,
                   'timed_out': False, 'interrupted': False}
            state['stages'].append(row)
            child = None
            started = time.monotonic()
            try:
                with (output / (name + '.log')).open('x') as log:
                    child = subprocess.Popen(command, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                                             stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                    row['owned_process_group'] = child.pid
                    while child.poll() is None:
                        if stopping or time.monotonic() - started >= limit:
                            row['interrupted'] = stopping
                            row['timed_out'] = not stopping
                            break
                        time.sleep(.1)
            finally:
                if child is not None:
                    row['cleanup'] = finish_group(child, row['timed_out'] or row['interrupted'] or child.poll() is None)
                    row['exit'] = child.returncode
                row['elapsed_seconds'] = time.monotonic() - started
                if name == 'coverage' and (ROOT / 'build/coverage/reports').exists():
                    shutil.copytree(ROOT / 'build/coverage/reports', output / 'coverage-reports',
                                    ignore=shutil.ignore_patterns('*.wav', '*.f32', '*.gguf'))
                save(output / 'result.json', state)
            print(json.dumps(row), flush=True)
            if row['exit'] != 0 or row['timed_out'] or row['interrupted'] or not row['cleanup']['group_gone'] or not row['cleanup']['leader_reaped'] or row['cleanup']['unexpected_group_after_exit']:
                raise RuntimeError('Timing check stage failed: ' + name)
            if name == 'full-build':
                artifacts['build/dev'] = binary_pins(ROOT / 'build/dev')
            elif name == 'ctest':
                suite = ET.parse(output / 'normal-ctest.xml').getroot()
                state['normal_ctest'] = dict(suite.attrib)
                if int(suite.attrib.get('tests', 0)) != 36 or int(suite.attrib.get('failures', 0)) or int(suite.attrib.get('disabled', 0)) or any(t.find('skipped') is not None for t in suite.iter('testcase')):
                    raise RuntimeError('Normal CTest did not complete all 36 tests without failures/skips')
            elif name.startswith('normal-'):
                row['evidence'] = private_result(output / name / 'result.json')
            elif name == 'coverage':
                artifacts['build/coverage'] = binary_pins(ROOT / 'build/coverage')
                summary = json.loads((output / 'coverage-reports/summary.json').read_text())
                state['coverage'] = summary
                if not summary.get('execution_passed') or summary.get('errors') or not summary.get('private_routing_requested'):
                    raise RuntimeError('Coverage execution/reporting was incomplete or failed')
            save(output / 'built-artifact-pins.json', artifacts)
            save(output / 'result.json', state)
        if source_pins() != initial:
            raise RuntimeError('Timing source inputs changed during checks')
        for folder, expected in artifacts.items():
            if binary_pins(ROOT / folder) != expected:
                raise RuntimeError('Built artifacts changed after their build stage: ' + folder)
        if stopping:
            raise InterruptedError('Timing checks stopped before final commit')
        state.update(status='timing_checks_passed', source_and_binaries_stable=True)
    except BaseException as error:
        state['status'] = 'failed_or_incomplete'
        state['errors'].append(type(error).__name__ + ': ' + str(error))
    finally:
        state['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
        if initial is not None:
            try:
                state['source_pins_unchanged_at_close'] = source_pins() == initial
            except Exception as error:
                state['source_pins_unchanged_at_close'] = False
                state['errors'].append('Final source pin read failed: ' + str(error))
            if not state['source_pins_unchanged_at_close']:
                state['status'] = 'failed_or_incomplete'
                state['errors'].append('Source pin set changed at final close')
        save(output / 'result.json', state)
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    return 0 if state['status'] == 'timing_checks_passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
