"""Exercise the actual guard decision loop with generated temperatures and a fake profile CLI."""
from pathlib import Path
import hashlib,json,os,subprocess,tempfile,unittest
BASE=Path(__file__).resolve().parent
RESULTS=[]

def exercise(source,temps,initial='balanced'):
 text=(BASE/source).read_text()
 marker='while sleep 2; do\n    temp=$(max_cpu_temp)'
 assert text.count(marker)==1
 # Only the sensor/sleep boundary is replaced. The decision loop remains exact.
 driver=text.replace(marker,'while IFS= read -r temp; do')
 with tempfile.TemporaryDirectory(prefix='isolated-guard-',dir=BASE) as tmp:
  p=Path(tmp);(p/'state').write_text(initial+'\n');(p/'actions').write_text('')
  (p/'guard').write_text(driver)
  mock=p/'powerprofilesctl'
  mock.write_text("""#!/bin/sh
case "$1" in
 get) cat "$GUARD_TEST_STATE" ;;
 set) case "$2" in balanced|power-saver) printf '%s\n' "$2" > "$GUARD_TEST_STATE"; printf '%s\n' "$2" >> "$GUARD_TEST_ACTIONS" ;; *) exit 2;; esac ;;
 *) exit 2 ;;
esac
""")
  mock.chmod(0o700)
  env=os.environ.copy();env['PATH']=str(p)+os.pathsep+os.defpath
  env['GUARD_TEST_STATE']=str(p/'state');env['GUARD_TEST_ACTIONS']=str(p/'actions')
  run=subprocess.run(['/bin/bash',str(p/'guard')],input=''.join(str(t)+'\n' for t in temps),text=True,capture_output=True,env=env,timeout=5)
  assert run.returncode==0,run.stderr
  out=dict(source=source,temperature_samples=len(temps),initial=initial,actions=(p/'actions').read_text().splitlines(),final=(p/'state').read_text().strip(),no_host_profile_or_sensors_used=True)
  RESULTS.append(out);return out

class Policy(unittest.TestCase):
 def test_original_single_spike_reproduces_two_minute_hold(self):
  self.assertEqual(exercise('thermal-guard.original',[86000]+[69000]*59)['actions'],['power-saver'])
  self.assertEqual(exercise('thermal-guard.original',[86000]+[69000]*60)['actions'],['power-saver','balanced'])
 def test_two_brief_warning_samples_do_not_limit_candidate(self):
  self.assertEqual(exercise('thermal-guard.candidate',[85000,86000]+[69000]*60)['actions'],[])
 def test_cooler_sample_resets_consecutive_warning_count(self):
  self.assertEqual(exercise('thermal-guard.candidate',[85000,86000,84000,85000,86000])['actions'],[])
 def test_three_consecutive_warning_samples_still_limit(self):
  self.assertEqual(exercise('thermal-guard.candidate',[85000]*3)['actions'],['power-saver'])
 def test_critical_first_sample_limits_immediately(self):
  self.assertEqual(exercise('thermal-guard.candidate',[95000])['actions'],['power-saver'])
 def test_original_full_recovery_interval_retained(self):
  self.assertEqual(exercise('thermal-guard.candidate',[85000]*3+[69000]*59)['actions'],['power-saver'])
  self.assertEqual(exercise('thermal-guard.candidate',[85000]*3+[69000]*60)['actions'],['power-saver','balanced'])
 def test_recovery_counter_resets_when_above_seventy(self):
  self.assertEqual(exercise('thermal-guard.candidate',[95000]+[69000]*59+[71000]+[69000]*59)['actions'],['power-saver'])
 def test_manual_power_saver_is_never_restored_to_balanced(self):
  result=exercise('thermal-guard.candidate',[95000]+[69000]*60,'power-saver')
  self.assertEqual(result['actions'],[]);self.assertEqual(result['final'],'power-saver')

if __name__=='__main__':
 for name in ('thermal-guard.original','thermal-guard.candidate'):
  subprocess.run(['/bin/bash','-n',str(BASE/name)],check=True)
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Policy)
 with (BASE/'tests-01.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 assert hashlib.sha256(Path('/home/kyau/.local/bin/thermal-guard').read_bytes()).hexdigest()==json.loads((BASE/'proposal.json').read_text())['original_sha256']
 receipt=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),host_guard_unchanged=True,only_generated_inputs_and_fake_profile_CLI=True,cases=RESULTS)
 (BASE/'test-results-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items() if k!='cases'}))
 raise SystemExit(0 if result.wasSuccessful() else 1)
