"""One scoped PPD selection with guarded, repeatable restoration.

Only ActiveProfile may be written. Import and the default CLI are inert.
The player driver calls select after its unchanged balanced cooldown.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
MODE = 'm2-current-guarded-profile-inhibited-budget-pair-120-01'
OBSERVER = Path('/home/kyau/projects/kyaulabs/conflux/build/m2-host-boundaries-01/native-profile-read-01/normal_ready_native.py')
OBSERVER_SHA = '0498ae5e42b21ef36526dc2cd62d3dcd09e59c67a219d2224d48dd2650dee1a4'
BUS = '/usr/bin/busctl'
BUS_NAME = 'org.freedesktop.UPower.PowerProfiles'
BUS_PATH = '/org/freedesktop/UPower/PowerProfiles'
_native = None
sys.dont_write_bytecode = True


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read_regular(path, maximum=256*1024):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path, 'Canonical regular path required')
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= maximum, 'Bounded regular file required')
        raw = bytearray()
        while len(raw) < before.st_size:
            block = os.read(fd, min(65536, before.st_size-len(raw)))
            require(bool(block), 'State file shortened')
            raw.extend(block)
        identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        require(identity(before) == identity(os.fstat(fd)) == identity(path.lstat()), 'State file changed')
        return bytes(raw)
    finally:
        os.close(fd)


def pin(path):
    data = read_regular(path)
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def checked_json(row):
    raw = read_regular(row['path'])
    require(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], 'Pinned state differs')
    return json.loads(raw)


def save(path, value):
    raw = (json.dumps(value, indent=2, allow_nan=False)+'\n').encode()
    require(len(raw) <= 65536, 'Policy receipt exceeds bound')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        require(stream.write(raw) == len(raw), 'Short policy receipt write')
        stream.flush()
        os.fsync(stream.fileno())


def case_path(case):
    require(case in ('balanced', 'performance'), 'Unknown fixed profile arm')
    path = BASE/'cases'/case
    require(path.resolve(strict=True) == path and path.is_dir(), 'Canonical fixed case required')
    return path


def observer():
    global _native
    if _native is None:
        raw = read_regular(OBSERVER)
        require(hashlib.sha256(raw).hexdigest() == OBSERVER_SHA, 'Native policy observer differs')
        spec = importlib.util.spec_from_file_location('scoped_profile_observer', OBSERVER)
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        exec(compile(raw, str(OBSERVER), 'exec'), module.__dict__)
        _native = module
    return _native


def snapshot(expected, deadline):
    zones = [p for p in Path('/sys/class/thermal').glob('thermal_zone*')
             if (p/'type').read_text().strip() == 'x86_pkg_temp']
    require(len(zones) == 1, 'Exactly one package sensor required')
    module = observer()
    row = module.capture(zones[0], deadline)
    module.ready(row, expected)
    return row


def write_profile(profile, deadline):
    require(profile in ('balanced', 'performance', 'power-saver'), 'Unknown fixed profile')
    remaining = deadline-time.monotonic()
    require(remaining > 0, 'Policy command deadline exhausted')
    observer().verify_native_binary(deadline)
    command = [BUS, '--system', '--timeout=2s', 'set-property', BUS_NAME, BUS_PATH,
               BUS_NAME, 'ActiveProfile', 's', profile]
    result = subprocess.run(command, capture_output=True, check=True, timeout=min(2, remaining))
    require(len(result.stdout) <= 16384 and len(result.stderr) <= 16384, 'Policy command output exceeds bound')


def power_limits():
    """Read the laptop's already-audited MMIO/MSR caps; never write them."""
    result = {}
    for domain in ('intel-rapl-mmio', 'intel-rapl'):
        root = Path('/sys/devices/virtual/powercap')/domain/(domain+':0')
        for name in ('enabled', 'constraint_0_power_limit_uw', 'constraint_0_time_window_us',
                     'constraint_1_power_limit_uw', 'constraint_1_time_window_us'):
            with (root/name).open() as stream:
                raw = stream.read(65)
            require(0 < len(raw) <= 64 and raw.strip().isdigit(), 'Power limit observation invalid')
            value = int(raw)
            require(name != 'enabled' or value in (0, 1), 'Power limit enabled flag invalid')
            result[str(root/name)] = value
    return result


def caps_within_observed_ceiling(value, ceiling):
    # The actual laptop lowered its MMIO PL1 from 15W to 7.5W while idle.
    # Preserve reductions instead of treating them as permission to raise caps.
    return (value.keys() == ceiling.keys() and all(type(v) is int and v >= 0 and
            (v <= ceiling[k] if k.endswith('_power_limit_uw') else v == ceiling[k])
            for k, v in value.items()))


def guard_ok(row, expected):
    identity = row.get('service_identity', {})
    return (not row.get('errors') and identity.get('ActiveState') == 'active'
            and identity.get('SubState') == 'running'
            and all(identity.get(k) == expected[k] for k in ('MainPID', 'InvocationID'))
            and row.get('latest_message_claims_recovered') is True
            and row.get('journal_identity_matches_service') is True)


def fresh(row, expected, profile):
    temperature = row.get('package_millidegrees_C')
    return (guard_ok(row, expected) and row.get('holds') == '' and row.get('profile') == profile
            and type(temperature) is int and 0 <= temperature <= 70000)


def select(case, plan_pin, human_pin, guard, deadline):
    directory = case_path(case)
    require(not (directory/'profile-selection.json').exists() and not (directory/'profile-intent.json').exists(),
            'Single policy selection; no retries')
    require(plan_pin['path'] == str(directory/'plan.json')
            and human_pin['path'] == str(directory/'readiness.json'), 'Selection belongs to another case')
    plan, human = checked_json(plan_pin), checked_json(human_pin)
    issued = datetime.fromisoformat(human.get('recorded_at_utc', ''))
    require(issued.tzinfo is not None, 'Timezone-aware original readiness required')
    age = (datetime.now(timezone.utc)-issued).total_seconds()
    require(plan.get('mode') == MODE and plan.get('requested_power_profile') == case
            and plan.get('operator_seconds') == 1200 and plan.get('command_seconds') == 540
            and human.get('decision') == 'ready' and human.get('diagnostic_mode') == MODE
            and human.get('maximum_operator_seconds') == 1200 and 0 <= age < 1200
            and human.get('plan_sha256') == plan_pin['sha256'], 'Original scoped profile authorization differs')
    expected = {k: guard['service'][k] for k in ('MainPID', 'InvocationID')}
    before = snapshot(expected, deadline)
    require(fresh(before, expected, 'balanced'), 'Fresh balanced/recovered/same-guard policy required')
    limits_before = power_limits()
    require(caps_within_observed_ceiling(limits_before, plan['power_limits']),
            'Audited power caps increased or changed before selection')
    if case == 'balanced':
        result = {'schema': 1, 'case': case, 'requested_profile': case, 'before': before,
                  'setting_changed': False, 'holds_created': False, 'power_limits': limits_before}
        save(directory/'profile-selection.json', result)
        return result
    intent = {'schema': 1, 'mode': MODE, 'case': case, 'previous': 'balanced', 'requested': 'performance',
              'plan_pin': plan_pin, 'human_pin': human_pin, 'guard_before': guard,
              'before': before, 'power_limits_before': limits_before, 'power_cap_ceiling': plan['power_limits'],
              'created_monotonic': time.monotonic(), 'holds_created': False}
    # Commit recoverable intent before even attempting the D-Bus write.
    save(directory/'profile-intent.json', intent)
    write_profile('performance', deadline)
    after = snapshot(expected, deadline)
    require(fresh(after, expected, 'performance'), 'Performance selection lost freshness or met a guard intervention')
    limits_after = power_limits()
    require(caps_within_observed_ceiling(limits_after, plan['power_limits']),
            'Performance selection increased or changed power caps; player must not start')
    result = {'schema': 1, 'case': case, 'requested_profile': case, 'before': before, 'after': after,
              'setting_changed': True, 'holds_created': False, 'intent_pin': pin(directory/'profile-intent.json'),
              'power_limits_before': limits_before, 'power_limits_after': limits_after}
    save(directory/'profile-selection.json', result)
    return result


def validate_intent(directory):
    intent_path = directory/'profile-intent.json'
    intent_pin = pin(intent_path)
    value = checked_json(intent_pin)
    require(type(value.get('schema')) is int and value['schema'] == 1
            and value.get('mode') == MODE and value.get('case') == 'performance'
            and value.get('previous') == 'balanced' and value.get('requested') == 'performance'
            and value.get('holds_created') is False, 'Scoped policy intent differs')
    require(value['plan_pin']['path'] == str(directory/'plan.json')
            and value['human_pin']['path'] == str(directory/'readiness.json'), 'Intent belongs to another case')
    plan, human = checked_json(value['plan_pin']), checked_json(value['human_pin'])
    require(plan.get('mode') == MODE and plan.get('requested_power_profile') == 'performance'
            and human.get('plan_sha256') == value['plan_pin']['sha256'], 'Intent authorization binding differs')
    return value, intent_pin


def restore(case, deadline):
    directory = case_path(case)
    if not (directory/'profile-intent.json').exists():
        return {'case': case, 'attempted_selection': False, 'setting_changed': False}
    intent, intent_pin = validate_intent(directory)
    done = directory/'profile-restored.json'
    if done.exists():
        result = json.loads(read_regular(done))
        require(result.get('intent_pin') == intent_pin and result.get('complete') is True, 'Prior restoration receipt differs')
        return result  # Never overwrite a later independent policy selection.
    expected = {k: intent['guard_before']['service'][k] for k in ('MainPID', 'InvocationID')}
    before = snapshot(expected, deadline)
    current = before.get('profile')
    require(current in ('balanced', 'power-saver', 'performance'), 'Cannot observe active policy for restoration')
    target = None
    if current == 'performance':
        require(before.get('holds') == '', 'Intervening profile hold; refusing to overwrite it')
        # Preserve a new guard reduction even if it raced our earlier write.
        target = 'balanced' if guard_ok(before, expected) else 'power-saver'
        write_profile(target, deadline)
        after = snapshot(expected, deadline)
        require(after.get('profile') == target, 'Policy restoration not observed')
    else:
        after = before  # An intervening guard/manual selection is authoritative.
    result = {'schema': 1, 'case': case, 'intent_pin': intent_pin, 'before': before, 'after': after,
              'written_profile': target, 'intervening_profile_preserved': target is None,
              'prior_profile_observed': after.get('profile') == intent['previous'],
              'guard_reduction_preserved': after.get('profile') == 'power-saver',
              'complete': True, 'holds_created': False, 'power_limits_after': power_limits()}
    result['power_limits_unchanged'] = result['power_limits_after'] == intent['power_limits_before']
    result['power_caps_within_observed_ceiling'] = caps_within_observed_ceiling(
        result['power_limits_after'], intent['power_cap_ceiling'])
    save(done, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--restore', choices=('balanced', 'performance'))
    args = parser.parse_args()
    if args.restore is None:
        print(json.dumps({'status': 'dry', 'host_queried': False, 'setting_changed': False}))
        return
    require(Path('/proc/1/comm').read_text().strip() == 'systemd', 'Actual host namespace required')
    print(json.dumps(restore(args.restore, time.monotonic()+10)))


if __name__ == '__main__':
    main()
