"""Offline replay of the interrupted run's late guard recovery."""
import importlib.util
from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    'profile_budget_regression_fixtures', BASE/'cases/balanced/test_host_player.py')
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)


class BudgetRegressionTests(unittest.TestCase):
    def test_brief_spike_and_late_recovery_leave_full_native_working_room(self):
        saved, events, clock, pins, output = fixtures.ReportingAndOrderingTests().exercise(
            guard_spike_after=60, guard_recovered_after=192)
        admission = saved['admission-01.json']
        self.assertEqual(admission['cool_readiness'][-1]['consecutive_span_seconds'], 60)
        self.assertTrue(admission['cooldown_complete'])
        self.assertTrue(output, 'Completed allowed cooldown must leave room to enter the public wrapper')
        self.assertIn('final_admission_returned', events)
        self.assertTrue(all(row['accepted'] and row['working_seconds_remaining'] >= 210
                            for row in admission['native_budget_samples']))
        self.assertEqual(events.count('single_cooldown'), 1)
        self.assertIsNot(saved['diagnostic-assessment.json'].get('passed'), True)


if __name__ == '__main__':
    unittest.main(verbosity=2)
