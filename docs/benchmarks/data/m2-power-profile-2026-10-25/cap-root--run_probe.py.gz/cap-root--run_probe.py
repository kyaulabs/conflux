#!/usr/bin/python3.14 -I
"""Dry by default; observe one profile selection, then restore. No player/model."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
MODE = 'm2-profile-power-cap-observation-01'
CASE = BASE/'cases/performance'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path, expected=None):
    require(path.resolve(strict=True) == path and path.is_file()
            and 0 < path.stat().st_size <= 256*1024, 'Canonical bounded input required')
    before = path.stat()
    raw = path.read_bytes()
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(identity(before) == identity(path.stat()) and len(raw) == before.st_size,
            'Input changed')
    row = {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    require(expected is None or row == expected, 'Pinned file differs: '+str(path))
    return row, raw


def load(row, name):
    raw = read(Path(row['path']), row)[1]
    spec = importlib.util.spec_from_file_location(name, row['path'])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    exec(compile(raw, row['path'], 'exec'), module.__dict__)
    return module


def verify_files(plan):
    require(plan['mode'] == MODE and plan['requested_power_profile'] == 'performance'
            and plan['operator_seconds'] == 120 and plan['command_seconds'] == 60
            and plan['profile_only'] is True and plan['inference_allowed'] is False,
            'Fixed profile-only scope differs')
    for row in plan['files'].values():
        read(Path(row['path']), row)


def readiness_budget(human, plan_pin, now, monotonic):
    issued = datetime.fromisoformat(human['recorded_at_utc'])
    require(issued.tzinfo is not None, 'Timezone-aware readiness required')
    age = (now-issued).total_seconds()
    require(type(human.get('schema')) is int and human['schema'] == 1
            and human.get('decision') == 'ready'
            and human.get('diagnostic_mode') == MODE
            and human.get('plan_sha256') == plan_pin['sha256']
            and human.get('maximum_operator_seconds') == 120
            # 60s unit +12s TERM +10s restore +30s close leaves8s to launch.
            and human.get('maximum_command_seconds') == 60 and 0 <= age <= 8
            and all(human.get(k) is True for k in ('AC_power', 'lid_open',
                'Codex_minimized', 'other_work_paused', 'no_suspend',
                'permit_brief_automatic_profile_cap_changes'))
            and all(type(human.get(k)) is str and 0 < len(human[k]) <= 8192
                for k in ('human_question', 'human_reply', 'question_item_id')),
            'Fresh conditions and explicit profile-observation scope required')
    return {'original_age_seconds': age, 'operator_deadline': monotonic+120-age,
            'command_deadline': monotonic+60}


def run():
    started = time.monotonic()
    plan_pin, raw = read(CASE/'plan.json')
    plan = json.loads(raw)
    human_pin, raw = read(CASE/'readiness.json')
    human = json.loads(raw)
    clocks = readiness_budget(human, plan_pin, datetime.now(timezone.utc), started)
    require(Path('/proc/1/comm').read_text().strip() == 'systemd', 'Actual host required')
    verify_files(plan)
    policy = load(plan['files']['policy'], 'scoped_cap_observation_policy')
    require(policy.MODE == MODE, 'Fixed policy mode differs')
    deadline = min(clocks['command_deadline'], clocks['operator_deadline']-30)
    report = {'schema': 1, 'mode': MODE, 'started_monotonic': started,
              'clocks': clocks, 'plan_pin': plan_pin, 'human_pin': human_pin,
              'profile_only': True, 'native_started': False, 'probe_complete': False}
    policy.save(CASE/'probe-dispatch.json', report)
    try:
        observer = load(plan['files']['admission_owner'], 'cap_observation_guard_reader')
        power = observer.power_state()
        require(power['ac_online'] and power['lid_open'], 'AC/open lid changed')
        guard = observer.guard_identity(Path(plan['files']['guard_script']['path']),
                                        Path(plan['files']['guard_unit']['path']))
        report['selection'] = policy.select('performance', plan_pin, human_pin, guard, deadline)
    except Exception as error:
        report['selection_error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if (CASE/'profile-intent.json').exists():
            try:
                report['restoration'] = policy.restore('performance', deadline)
            except Exception as error:
                report['restoration_error'] = {'type': type(error).__name__, 'message': str(error)}
        snapshot = CASE/'profile-power-limits-after-selection.json'
        if snapshot.exists():
            row, raw = read(snapshot)
            observed = json.loads(raw)
            require(observed['plan_pin'] == plan_pin and observed['human_pin'] == human_pin,
                    'Power-limit observation binding differs')
            report['power_limit_observation_pin'] = row
            before, after = observed['power_limits_before'], observed['power_limits_after']
            report['changed_fields'] = [dict(path=k, before=before[k], after=after[k],
                original_ceiling=observed['power_cap_ceiling'][k])
                for k in before if before[k] != after[k]]
        verify_files(plan)
        require(read(CASE/'plan.json')[0] == plan_pin and read(CASE/'readiness.json')[0] == human_pin,
                'Plan/readiness changed')
        report['finished_monotonic'] = time.monotonic()
        restored = report.get('restoration', {})
        report['probe_complete'] = bool(report.get('power_limit_observation_pin')
            and restored.get('complete') is True
            and restored.get('power_caps_within_observed_ceiling') is True
            and report['finished_monotonic'] <= deadline)
        policy.save(CASE/'probe-result.json', report)
    print(json.dumps(report))
    return 0 if report['probe_complete'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--run', action='store_true')
    modes.add_argument('--verify-files', action='store_true')
    args = parser.parse_args()
    if args.run:
        return run()
    if args.verify_files:
        verify_files(json.loads(read(CASE/'plan.json')[1]))
    print(json.dumps({'status': 'files_verified' if args.verify_files else 'dry',
        'host_queried': False, 'profile_changed': False, 'native_started': False}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
