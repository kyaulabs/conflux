"""Dry by default; dispatch/close two fixed, independently owned systemd arms.

The one original readiness timestamp and monotonic deadline cover both arms.
The existing player owner retains its 525/537/540-second limits.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
MODE = 'm2-current-guarded-profile-inhibited-budget-pair-120-01'
PROPERTIES = ('LoadState','ActiveState','SubState','InvocationID','MainPID','ExecMainPID',
              'ExecMainCode','ExecMainStatus','ControlGroup','Restart','KillMode',
              'RuntimeMaxUSec','TimeoutStopUSec','RemainAfterExit','Result')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    require(path.resolve(strict=True) == path and path.is_file() and 0 < path.stat().st_size <= 256*1024,
            'Canonical bounded input required')
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}, raw


def write(path, value, exclusive=False):
    raw = json.dumps(value, indent=2, allow_nan=False)+'\n'
    with path.open('x' if exclusive else 'w') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())


def driver(case):
    directory = BASE/'cases'/case
    plan_pin, raw = pin(directory/'plan.json')
    plan = json.loads(raw)
    row, code = pin(directory/'run_host_player.py')
    require(row == plan['sources']['launcher'], 'Fixed arm driver differs')
    spec = importlib.util.spec_from_file_location('guarded_arm_driver_'+case, Path(row['path']))
    module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module
    exec(compile(code, row['path'], 'exec'), module.__dict__)
    module.validate_plan(plan)
    require(plan['requested_power_profile'] == case and plan['status'] == 'frozen_pending_fresh_readiness',
            'Reviewed fixed profile arm required')
    require(pin(Path(__file__).resolve())[0] == plan['sources']['unit_launcher'], 'Unit dispatcher differs')
    return module, plan, plan_pin


def unit_name(case):
    return 'conflux-m2-power-pair-20261025-03-'+case+'.service'


def power_limits(module, plan):
    row = plan['sources']['profile_policy']
    policy = module.load_source('guarded_unit_power_caps',Path(row['path']),row['sha256'])
    value = policy.power_limits()
    require(policy.caps_within_observed_ceiling(value, plan['power_limits']),
            'Power caps exceed the original ceiling or changed outside the comparison')
    return value


def command(case):
    argv = ['/usr/bin/systemd-run','--user','--unit='+unit_name(case),
            '--property=Type=exec','--property=RemainAfterExit=yes',
            '--property=RuntimeMaxSec=525s','--property=TimeoutStopSec=12s',
            '--property=KillMode=control-group','--property=Restart=no',
            '--property=WorkingDirectory='+str(ROOT)]
    if case == 'performance':
        argv.append('--property=ExecStopPost=/usr/bin/python3.14 -I -B '+str(BASE/'profile_policy.py')+' --restore performance')
    return argv+['/usr/bin/kde-inhibit','--power','--screenSaver',
                 str(BASE/'cases'/case/'run_player_owned.py'),'--run']


def run_command(argv, deadline):
    remaining = deadline-time.monotonic()
    require(remaining > 0, 'Original dispatch/cleanup deadline exhausted')
    value = subprocess.run(argv, capture_output=True, text=True, timeout=min(30, remaining))
    require(len(value.stdout.encode()) <= 65536 and len(value.stderr.encode()) <= 65536, 'Unit output exceeds bound')
    return {'argv': argv, 'exit': value.returncode, 'stdout': value.stdout, 'stderr': value.stderr}


def state(case, deadline):
    row = run_command(['/usr/bin/systemctl','--user','show',unit_name(case),
                       '--no-pager','--property='+','.join(PROPERTIES)], deadline)
    value = dict(line.split('=',1) for line in row['stdout'].splitlines() if '=' in line)
    require(set(value) == set(PROPERTIES), 'Unit observation incomplete')
    return value


def common_window(case, plans, humans, clocks):
    path = BASE/'root-human-first-observed-01.json'
    if not path.exists():
        require(case == 'balanced', 'Balanced must establish the original shared window')
        write(path, {'schema':1,'mode':MODE,'plan_pins':plans,'human_pins':humans,
              'first_observed_monotonic':time.monotonic(),
              'operator_deadline_monotonic':clocks['operator_deadline'],
              'maximum_operator_seconds':1200}, exclusive=True)
    shared = json.loads(pin(path)[1])
    require(shared.get('schema') == 1 and shared.get('mode') == MODE and
            shared.get('plan_pins') == plans and shared.get('human_pins') == humans and
            shared.get('maximum_operator_seconds') == 1200 and
            type(shared.get('operator_deadline_monotonic')) in (int,float), 'Original shared window differs')
    return shared


def inputs(case):
    modules = {}; plans = {}; humans = {}; records = {}; current = None
    for arm in ('balanced','performance'):
        module, plan, plan_pin = driver(arm)
        human_pin, raw = pin(BASE/'cases'/arm/'readiness.json')
        human = json.loads(raw)
        clocks = module.budget(human, plan_pin['sha256'], datetime.now(timezone.utc), time.monotonic())
        modules[arm] = (module, plan); plans[arm] = plan_pin; humans[arm] = human_pin; records[arm] = human
        if arm == case:
            current = clocks
    fields = ('recorded_at_utc','human_question','human_reply','question_item_id')
    require(all(records['balanced'][key] == records['performance'][key] for key in fields),
            'Both arms require the same original human conditions')
    return modules, common_window(case, plans, humans, current)


def launch(case):
    modules, shared = inputs(case)
    deadline = shared['operator_deadline_monotonic']
    require(deadline-time.monotonic() >= 570, 'Original pair window lacks 540s owner plus 30s cleanup')
    if case == 'performance':
        prior = json.loads(pin(BASE/'cases/balanced/unit-finished-01.json')[1])
        require(prior.get('unit_absent') is True and prior.get('owned_processes_absent') is True
                and prior.get('diagnostic_complete') is True and prior.get('outer_receipt_complete') is True
                and prior.get('stop',{}).get('exit') == 0, 'Balanced workload/cleanup must complete first')
    module, plan = modules[case]
    module.verify_files(plan, min(deadline, time.monotonic()+30))
    limits = power_limits(module,plan)
    require(state(case, deadline)['LoadState'] == 'not-found', 'Fixed unit already exists; no retry')
    path = BASE/'cases'/case/'unit-dispatch-01.json'
    row = {'schema':1,'mode':MODE,'case':case,'command':command(case),
           'shared_window_pin':pin(BASE/'root-human-first-observed-01.json')[0],
           'automatic_retries':False,'started_monotonic':time.monotonic(),'power_limits_before':limits}
    write(path, row, exclusive=True)
    try:
        row['launch'] = run_command(row['command'], min(deadline,time.monotonic()+10))
        require(row['launch']['exit'] == 0, 'Transient unit launch failed; no retry')
        row['unit_after_dispatch'] = state(case, min(deadline,time.monotonic()+5))
        require(row['unit_after_dispatch'].get('InvocationID'), 'Launched unit invocation absent')
    finally:
        row['finished_monotonic'] = time.monotonic(); write(path,row)
    return row


def finish(case):
    directory = BASE/'cases'/case
    launch_row = json.loads(pin(directory/'unit-dispatch-01.json')[1])
    shared = json.loads(pin(BASE/'root-human-first-observed-01.json')[1])
    deadline = min(shared['operator_deadline_monotonic'], time.monotonic()+30)
    before = state(case, deadline)
    require(before['InvocationID'] == launch_row['unit_after_dispatch']['InvocationID'] and
            before['MainPID'] == '0' and before['SubState'] in ('exited','failed','dead'),
            'Owned unit is still executing or changed; do not stop a live workload')
    row = {'schema':1,'mode':MODE,'case':case,'before_stop':before,
           'stop':run_command(['/usr/bin/systemctl','--user','stop',unit_name(case)],deadline)}
    after = state(case,deadline)
    if after['LoadState']=='loaded' and after['ActiveState']=='failed':
        require(after['InvocationID']==before['InvocationID'] and after['MainPID']=='0'
                and after['ControlGroup']=='', 'Refusing to reset a changed or populated unit')
        row['reset_only_owned_failed_unit']=run_command(
            ['/usr/bin/systemctl','--user','reset-failed',unit_name(case)],deadline)
        require(row['reset_only_owned_failed_unit']['exit']==0,'Owned failed-unit metadata reset failed')
        after=state(case,deadline)
    row['after_stop'] = after; row['unit_absent'] = after['LoadState'] == 'not-found' and after['MainPID'] == '0'
    module, plan, _ = driver(case)
    row['power_limits_after'] = power_limits(module,plan)
    owner_row = plan['sources']['outer_owner']; owner_pin, code = pin(Path(owner_row['path']))
    require(owner_pin == owner_row, 'Original owner differs before absence verification')
    spec = importlib.util.spec_from_file_location('guarded_arm_cleanup_owner', Path(owner_row['path']))
    owner = importlib.util.module_from_spec(spec); exec(compile(code,owner_row['path'],'exec'), owner.__dict__)
    dispatched = json.loads(pin(directory/'dispatch-01.json')[1])
    known = {(v['pid'],v['start_ticks']):v for v in dispatched.get('known_processes',[])}
    require(known, 'Recorded owner lifetimes absent')
    errors = []; row['remaining_known_processes'] = list(owner.live_owned(known,errors).values())
    row['owned_groups_absent'] = owner.absent_groups({v['group'] for v in known.values()})
    row['ownership_observation_errors'] = errors
    row['owned_processes_absent'] = not errors and not row['remaining_known_processes'] and all(row['owned_groups_absent'].values())
    assessment = json.loads(pin(directory/'diagnostic-assessment.json')[1])
    row['diagnostic_complete'] = assessment.get('diagnostic_complete') is True
    row['workload_passed'] = assessment.get('passed') is True
    row['outer_exit_code'] = dispatched.get('exit_code')
    row['outer_receipt_complete'] = (all(k in dispatched for k in ('exit_code','finished_monotonic'))
        and dispatched.get('launcher_reaped') is True and dispatched.get('complete_capture') is True
        and dispatched.get('within_external_command_budget') is True and dispatched.get('errors') == []
        and not dispatched.get('external_signals') and set(dispatched.get('captures',{})) == {'stdout','stderr'}
        and all(value.get('overflow') is False and value.get('received') == value.get('written')
                for value in dispatched['captures'].values()))
    row['finished_monotonic'] = time.monotonic()
    write(directory/'unit-finished-01.json',row,exclusive=True)
    require(row['stop']['exit'] == 0 and row['unit_absent'] and row['owned_processes_absent']
            and row['outer_receipt_complete'] and time.monotonic() <= deadline, 'Unit/owned cleanup incomplete')
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--arm', choices=('balanced','performance'), default='balanced')
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--run', action='store_true'); modes.add_argument('--finish', action='store_true')
    args = parser.parse_args()
    if not args.run and not args.finish:
        print(json.dumps({'status':'dry','host_queried':False,'settings_changed':False,
                          'command':command(args.arm),'operator_seconds':1200}))
        return
    require(Path('/proc/1/comm').read_text().strip() == 'systemd', 'Actual host namespace required')
    row = launch(args.arm) if args.run else finish(args.arm)
    print(json.dumps(row))


if __name__ == '__main__':
    main()
