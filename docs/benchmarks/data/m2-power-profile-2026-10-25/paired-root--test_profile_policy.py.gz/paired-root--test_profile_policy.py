"""Generated policy lifecycle checks; fake PPD, no host/settings/model calls."""
import copy
from datetime import datetime, timedelta, timezone
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('guarded_policy_test', BASE/'profile_policy.py')
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)


def audit(event, args):
    if event.startswith(('subprocess.', 'socket.', 'os.exec', 'os.spawn', 'os.fork')) or event in ('os.system', 'os.kill', 'os.killpg'):
        raise RuntimeError('Offline policy test forbids ' + event)
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)) and os.fsdecode(args[0]).startswith(('/proc/', '/sys/', '/dev/')):
        raise RuntimeError('Offline policy test forbids live host reads')


sys.addaudithook(audit)


class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.addCleanup(patch.stopall)
        patch.object(policy, 'BASE', self.base).start()
        self.guard = {'service': {'MainPID': '42', 'InvocationID': '1'*32}}
        self.state = {'profile': 'balanced', 'holds': '', 'errors': [], 'package_millidegrees_C': 35000,
                      'service_identity': {**self.guard['service'], 'ActiveState': 'active', 'SubState': 'running'},
                      'latest_message_claims_recovered': True, 'journal_identity_matches_service': True}
        self.writes = []
        self.limits = {'/offline/constraint_0_power_limit_uw': 15000000}
        self.pins = {}
        for case in ('balanced', 'performance'):
            directory = self.base/'cases'/case
            directory.mkdir(parents=True)
            plan = {'mode': policy.MODE, 'requested_power_profile': case, 'operator_seconds': 1200,
                    'command_seconds': 540, 'power_limits': copy.deepcopy(self.limits)}
            (directory/'plan.json').write_text(json.dumps(plan))
            plan_pin = policy.pin(directory/'plan.json')
            human = {'decision': 'ready', 'diagnostic_mode': policy.MODE, 'maximum_operator_seconds': 1200,
                     'plan_sha256': plan_pin['sha256'], 'recorded_at_utc': datetime.now(timezone.utc).isoformat()}
            (directory/'readiness.json').write_text(json.dumps(human))
            self.pins[case] = (plan_pin, policy.pin(directory/'readiness.json'))
        patch.object(policy, 'snapshot', side_effect=lambda *_: copy.deepcopy(self.state)).start()
        patch.object(policy, 'write_profile', side_effect=self.write).start()
        patch.object(policy, 'power_limits', side_effect=lambda: copy.deepcopy(self.limits)).start()

    def write(self, target, _deadline):
        self.assertTrue((self.base/'cases/performance/profile-intent.json').is_file())
        self.writes.append(target)
        self.state['profile'] = target

    def select(self, case='performance'):
        return policy.select(case, *self.pins[case], self.guard, 1000)

    def test_balanced_arm_never_changes_policy_or_creates_intent(self):
        result = self.select('balanced')
        self.assertFalse(result['setting_changed'])
        self.assertEqual(self.writes, [])
        self.assertFalse((self.base/'cases/balanced/profile-intent.json').exists())

    def test_performance_intent_precedes_write_and_restoration_is_repeatable(self):
        self.select()
        result = policy.restore('performance', 1000)
        self.assertEqual(self.writes, ['performance', 'balanced'])
        self.assertTrue(result['prior_profile_observed'])
        self.assertTrue(result['complete'])
        # A unit's later cleanup must not undo an independent later selection.
        self.state['profile'] = 'performance'
        self.assertEqual(policy.restore('performance', 1000), result)
        self.assertEqual(self.writes, ['performance', 'balanced'])

    def test_bad_freshness_or_guard_or_hold_prevents_any_selection(self):
        for key, value in [('profile', 'power-saver'), ('holds', 'nonempty'),
                           ('package_millidegrees_C', 70001), ('package_millidegrees_C', True),
                           ('errors', [{'error': 'query failed'}]), ('latest_message_claims_recovered', False),
                           ('journal_identity_matches_service', False),
                           ('service_identity', {**self.state['service_identity'], 'InvocationID': '2'*32})]:
            with self.subTest(key=key, value=value):
                old = copy.deepcopy(self.state)
                self.state[key] = value
                with self.assertRaisesRegex(ValueError, 'Fresh balanced'):
                    self.select()
                self.assertEqual(self.writes, [])
                self.assertFalse((self.base/'cases/performance/profile-intent.json').exists())
                self.state = old

    def test_failed_write_that_changed_profile_can_still_be_restored(self):
        def failure(target, deadline):
            self.write(target, deadline)
            if target == 'performance':
                raise RuntimeError('D-Bus completion failed after selection')
        with patch.object(policy, 'write_profile', side_effect=failure):
            with self.assertRaisesRegex(RuntimeError, 'completion failed'):
                self.select()
            self.assertTrue(policy.restore('performance', 1000)['prior_profile_observed'])
        self.assertEqual(self.writes, ['performance', 'balanced'])

    def test_guard_intervention_during_selection_is_preserved(self):
        def intervention(target, deadline):
            self.write(target, deadline)
            self.state.update(profile='power-saver', latest_message_claims_recovered=False)
        with patch.object(policy, 'write_profile', side_effect=intervention):
            with self.assertRaisesRegex(ValueError, 'guard intervention'):
                self.select()
        result = policy.restore('performance', 1000)
        self.assertTrue(result['guard_reduction_preserved'])
        self.assertTrue(result['intervening_profile_preserved'])
        self.assertEqual(self.writes, ['performance'])

    def test_new_warning_while_our_profile_is_active_selects_power_saver(self):
        self.select()
        self.state['latest_message_claims_recovered'] = False
        result = policy.restore('performance', 1000)
        self.assertEqual(self.writes, ['performance', 'power-saver'])
        self.assertTrue(result['guard_reduction_preserved'])

    def test_intervening_balanced_selection_is_preserved(self):
        self.select()
        self.state['profile'] = 'balanced'
        result = policy.restore('performance', 1000)
        self.assertTrue(result['intervening_profile_preserved'])
        self.assertEqual(self.writes, ['performance'])

    def test_intervening_hold_is_not_overwritten(self):
        self.select()
        self.state['holds'] = 'new hold'
        with self.assertRaisesRegex(ValueError, 'Intervening profile hold'):
            policy.restore('performance', 1000)
        self.assertEqual(self.writes, ['performance'])
        self.assertFalse((self.base/'cases/performance/profile-restored.json').exists())

    def test_no_retry_after_initial_selection(self):
        self.select()
        with self.assertRaisesRegex(ValueError, 'Single policy selection'):
            self.select()
        self.assertEqual(self.writes, ['performance'])

    def test_changed_power_caps_prevent_selection_without_touching_them(self):
        self.limits['/offline/constraint_0_power_limit_uw'] = 20000000
        with self.assertRaisesRegex(ValueError, 'caps increased or changed before selection'):
            self.select()
        self.assertEqual(self.writes, [])

    def test_cap_change_from_profile_selection_aborts_and_restores_profile(self):
        def change(target, deadline):
            self.write(target, deadline)
            self.limits['/offline/constraint_0_power_limit_uw'] = 20000000 if target == 'performance' else 15000000
        with patch.object(policy, 'write_profile', side_effect=change):
            with self.assertRaisesRegex(ValueError, 'selection increased or changed power caps'):
                self.select()
            restored = policy.restore('performance', 1000)
        self.assertEqual(self.writes, ['performance', 'balanced'])
        self.assertTrue(restored['power_limits_unchanged'])

    def test_independent_cap_change_is_reported_without_writing_caps(self):
        self.select()
        self.limits['/offline/constraint_0_power_limit_uw'] = 20000000
        restored = policy.restore('performance', 1000)
        self.assertTrue(restored['prior_profile_observed'])
        self.assertFalse(restored['power_limits_unchanged'])
        self.assertFalse(restored['power_caps_within_observed_ceiling'])
        self.assertEqual(self.limits['/offline/constraint_0_power_limit_uw'], 20000000)
        self.assertEqual(self.writes, ['performance', 'balanced'])

    def test_natural_power_cap_reduction_is_preserved_and_not_rewritten(self):
        self.select()
        self.limits['/offline/constraint_0_power_limit_uw'] = 7500000
        restored = policy.restore('performance', 1000)
        self.assertTrue(restored['power_caps_within_observed_ceiling'])
        self.assertFalse(restored['power_limits_unchanged'])
        self.assertEqual(self.limits['/offline/constraint_0_power_limit_uw'], 7500000)
        self.assertEqual(self.writes, ['performance', 'balanced'])

    def test_foreign_or_expired_authorization_is_rejected_before_write(self):
        plan_pin, human_pin = self.pins['performance']
        path = Path(human_pin['path'])
        original = json.loads(path.read_text())
        for key, value in [('plan_sha256', 'f'*64), ('diagnostic_mode', 'foreign'),
                           ('recorded_at_utc', (datetime.now(timezone.utc)-timedelta(seconds=1201)).isoformat())]:
            with self.subTest(key=key):
                path.write_text(json.dumps({**original, key: value}))
                self.pins['performance'] = (plan_pin, policy.pin(path))
                with self.assertRaisesRegex(ValueError, 'authorization differs'):
                    self.select()
                self.assertEqual(self.writes, [])

    def test_foreign_restore_intent_is_rejected(self):
        self.select()
        path = self.base/'cases/performance/profile-intent.json'
        original = json.loads(path.read_text())
        for key, value in [('schema', True), ('mode', 'foreign'), ('previous', 'performance'),
                           ('human_pin', self.pins['balanced'][1])]:
            with self.subTest(key=key):
                path.write_text(json.dumps({**original, key: value}))
                with self.assertRaises(ValueError):
                    policy.restore('performance', 1000)
                self.assertEqual(self.writes, ['performance'])

    def test_state_symlink_and_fifo_fail_without_opening_other_content(self):
        target = self.base/'target.json'
        target.write_text('{}')
        alias = self.base/'alias.json'
        alias.symlink_to(target)
        with self.assertRaisesRegex(ValueError, 'Canonical regular'):
            policy.read_regular(alias)
        fifo = self.base/'fifo'
        os.mkfifo(fifo)
        with self.assertRaisesRegex(ValueError, 'Bounded regular'):
            policy.read_regular(fifo)


if __name__ == '__main__':
    unittest.main(verbosity=2)
