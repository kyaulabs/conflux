"""Offline authorization and immutable-file failures; no host operations."""
from datetime import datetime, timedelta, timezone
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cap_probe_tests', BASE/'run_probe.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


class ProbeTests(unittest.TestCase):
    def fixture(self):
        now = datetime(2026, 10, 25, tzinfo=timezone.utc)
        human = dict(schema=1, decision='ready', diagnostic_mode=probe.MODE,
            plan_sha256='a'*64, maximum_operator_seconds=120, maximum_command_seconds=60,
            recorded_at_utc=now.isoformat(), AC_power=True, lid_open=True,
            Codex_minimized=True, other_work_paused=True, no_suspend=True,
            permit_brief_automatic_profile_cap_changes=True, human_question='scope',
            human_reply='ready', question_item_id='offline-fixture')
        return now, human

    def test_fresh_start_reserves_whole_command_and_cleanup_inside_original_window(self):
        now, human = self.fixture()
        for age in (0, 8):
            result = probe.readiness_budget(human, {'sha256': 'a'*64},
                now+timedelta(seconds=age), 100+age)
            self.assertEqual(result['operator_deadline'], 220)
            self.assertEqual(result['command_deadline'], 160+age)
            self.assertGreaterEqual(result['operator_deadline']-result['command_deadline'], 52)
        for age in (-.001, 8.001, 120):
            with self.assertRaises(ValueError):
                probe.readiness_budget(human, {'sha256': 'a'*64},
                    now+timedelta(seconds=age), 100)

    def test_missing_cap_observation_consent_or_changed_scope_cannot_authorize_selection(self):
        now, original = self.fixture()
        for key, value in (('permit_brief_automatic_profile_cap_changes', False),
                ('AC_power', 1), ('lid_open', False), ('maximum_command_seconds', 540),
                ('maximum_operator_seconds', 1200), ('plan_sha256', 'b'*64),
                ('human_question', ''), ('question_item_id', '')):
            with self.subTest(field=key), self.assertRaises(ValueError):
                probe.readiness_budget({**original, key: value}, {'sha256': 'a'*64}, now, 100)

    def test_absent_readiness_stops_before_any_host_access(self):
        with tempfile.TemporaryDirectory() as temp:
            case = Path(temp)
            (case/'plan.json').write_text('{}\n')
            with patch.object(probe, 'CASE', case), self.assertRaises(FileNotFoundError):
                probe.run()
            self.assertEqual(sorted(p.name for p in case.iterdir()), ['plan.json'])

    def test_changed_regular_input_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp)/'input.json'
            path.write_text('{}\n')
            row, _ = probe.read(path)
            path.write_text('{"changed":true}\n')
            with self.assertRaisesRegex(ValueError, 'Pinned file differs'):
                probe.read(path, row)


if __name__ == '__main__':
    unittest.main(verbosity=2)
