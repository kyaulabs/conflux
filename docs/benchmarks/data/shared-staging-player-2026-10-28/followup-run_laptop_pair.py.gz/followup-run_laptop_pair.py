"""Run only the remaining candidate with the unchanged, pinned comparison owner."""
from pathlib import Path
import hashlib,importlib.util
p=Path('/home/kyau/projects/kyaulabs/conflux/build/m2-shared-staging-player-01/run_laptop_pair.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='32697cf34b81377e9c70a2dc85687a98a76a7cbe2086d67a7670e0a0e0d7bdee'
spec=importlib.util.spec_from_file_location('frozen_remaining_owner',p)
owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)
owner.BASE=Path('/home/kyau/projects/kyaulabs/conflux/build/m2-shared-staging-player-followup-02')
owner.ARMS=('candidate',)
owner.MODE='m2-shared-staging-player-followup-20261028-02'
if __name__=='__main__':raise SystemExit(owner.main())
