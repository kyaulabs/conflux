"""Run only the remaining candidate with the unchanged, pinned comparison owner."""
from pathlib import Path
import hashlib,importlib.util
p=Path('/srv/conflux-tests/work/shared-staging-player-20261028-01/operations/run_pair.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='cdf9c12dad032f31ad52d98d66427a7ce818aac2470d6df971092761be81f2ba'
spec=importlib.util.spec_from_file_location('frozen_remaining_owner',p)
owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)
owner.BASE=Path('/srv/conflux-tests/work/shared-staging-player-followup-20261028-02')
owner.ARMS=('candidate',)
owner.OPS=owner.BASE/'operations'
owner.RUN='shared-staging-player-followup-20261028-02'
if __name__=='__main__':raise SystemExit(owner.main())
