from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
root=Path.cwd();base=root/'benchmarks-local/phase-timing-01';out=base/'normal';old=root/'benchmarks-local/m2-live-delivery-2026-10-19/best-packed-product-coverage-02/plan.json'
paths=set(json.loads(old.read_text())['pins']);paths.add('tests/StemServiceFixture.hpp')
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
before={n:pin(root/n) for n in sorted(paths)}
for s in json.loads((base/'result.json').read_text())['sources']:assert before[s['path']]=={k:s[k] for k in ('bytes','sha256')}
smoke={'QT_QPA_PLATFORM':'offscreen','QT_QUICK_BACKEND':'software','QT_QUICK_CONTROLS_STYLE':'Basic'}
launcher="import runpy,signal,sys\ndef stop(*_):\n signal.signal(signal.SIGTERM,signal.SIG_IGN)\n raise InterruptedError('Normal verification timed out')\nsignal.signal(signal.SIGTERM,stop)\nsys.argv=sys.argv[1:]\nrunpy.run_path(sys.argv[0],run_name='__main__')\n"
steps=[('build',['cmake','--build','build/dev','--parallel','2'],{},900),('ctest',['ctest','--test-dir','build/dev','--output-on-failure','--timeout','120'],{},900),('smoke',['build/dev/conflux','--smoke-test'],smoke,30)]
for name,binary in [('routing','conflux-manual-routing-check'),('preparation','conflux-preparation-controller-check')]:
 steps.append((name,['/bin/python3','-B','-c',launcher,str(root/'tools/experiments/private_routing_check.py'),str(root/'build/dev'/binary),str(out/name)],{},180))
plan={'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pins':before,'steps':[{'name':n,'command':c,'environment_overrides':e,'timeout_seconds':t} for n,c,e,t in steps],'scope':'Normal build/all CTests/offscreen smoke and strict private virtual routing/preparation only; no model/host service qualification.'}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');rows=[]
for name,command,extra,timeout in steps:
 print('Starting '+name,flush=True);began=time.monotonic();timed=False
 with (out/(name+'.log')).open('wb') as stream:
  child=subprocess.Popen(command,cwd=root,env=os.environ|extra,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
   code=1
 rows.append({'name':name,'exit_code':code,'timed_out':timed,'seconds':time.monotonic()-began,'log':pin(out/(name+'.log'))});print(name+' exit '+str(code),flush=True)
 if code:break
after={n:pin(root/n) for n in sorted(paths)};artifacts={n:pin(root/n) for n in ('build/dev/conflux','build/dev/conflux-manual-playback-soak','build/dev/conflux-manual-routing-check','build/dev/conflux-preparation-controller-check','build/dev/libconflux-audio.a')}
passed=len(rows)==len(steps) and all(r['exit_code']==0 and not r['timed_out'] for r in rows) and before==after
receipt={'closed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':passed,'qualified':False,'pins_before':before,'pins_after':after,'pins_unchanged':before==after,'rows':rows,'artifacts':artifacts,'scope':plan['scope']};(out/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n');raise SystemExit(0 if passed else 1)
