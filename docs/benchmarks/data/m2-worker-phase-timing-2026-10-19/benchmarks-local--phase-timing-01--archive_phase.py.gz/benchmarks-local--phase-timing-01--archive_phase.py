from pathlib import Path
import datetime,gzip,hashlib,json,os,stat,subprocess
root=Path.cwd();phase=root/'benchmarks-local/phase-timing-01';base=root/'benchmarks-local/m2-live-delivery-2026-10-19';run='short-live-actual-model-04';head='45130aa127382bd1af243f7a357e82ad6ff1c001'
dest=root/'docs/benchmarks/data/m2-worker-phase-timing-2026-10-19';stage=phase/'archive-stage';rawdir=phase/'archive-raw'
assert not any(os.path.lexists(p) for p in (dest,stage,rawdir))
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size<=64*1024*1024
 b=p.read_bytes();a=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)
 assert len(b)==s.st_size and b'\0' not in b;b.decode('utf-8');return b
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
sig=subprocess.check_output(['git','show','-s','--format=%H %G? %GF %ae',head],text=True).strip();assert sig==head+' G F621F658D66098CBE9E5C55D66788CCBB5E215AC kyau@kyau.net'
normal=json.loads(read(phase/'normal/execution.json'));coverage=json.loads(read(phase/'coverage-01/execution.json'));assert normal['passed'] and coverage['passed']
assert normal['pins_after']==coverage['pins_after']
for n,p in normal['pins_after'].items():assert pin((root/n).read_bytes())==p
actual=json.loads(read(base/run/'result.json'));report=json.loads(read(base/(run+'-report.json')));assert actual['passed'] and actual['cleanup_proven'] and actual['pins_unchanged'] and not actual['qualified'];assert report['service_hops']['nearest_rank_p99_ms']<4095 and report['steady_starvation_frames']==0
patch=phase/'source.patch';assert not patch.exists();patch.write_bytes(subprocess.check_output(['git','diff',head+'^',head,'--']))
summary={'schema':1,'source_head':head,'source_signature':sig,'m2_open':True,'short_actual_player_passed':True,'sustained_actual_player_qualified':False,'service_target_ms':4095,'product_change':'Retain thirteen optional existing phase durations on validated chunks; ten native fields use a fixed nested native_timings object. Best conversion, native runtime/model, clocks, service target and host policy unchanged.','verification':{'focused_python_tests':23,'focused_cpp_passes':95,'normal_ctest':36,'instrumented_ctest':36,'normal_routing':130,'strict_preparation':78,'coverage_cpp':coverage['cpp'],'coverage_python':coverage['python'],'coverage_unmeasured':coverage['unmeasured_product_sources'],'source_pins':len(normal['pins_after'])},'actual_player':report,'limits':['Single120-second repeated-excerpt diagnostic, not sustained qualification.','Run03 spent most sampled time in low-power; run04 samples stayed balanced. No causal speedup attributed to telemetry. Prior slow hops lack phase detail.','Native intervals are nested; all thirteen fields are present for21 validated chunks. Preroll/canceled/discarded work is not fully covered.','Callback counters and finite WAV do not establish physical audio continuity or musical acceptance.','Coverage setup metadata lookup failed before its independent command started; the shell continued. Late plan and corrected107-pin provenance are retained without claiming a test-stage failure.']}
summarypath=phase/'summary.json';assert not summarypath.exists();summarypath.write_text(json.dumps(summary,indent=2)+'\n')
paths=set(phase/n for n in ('result.json','code-review.json','source.sha256','source.patch','summary.json','source-commit.log','source-commit-message.txt','run_normal.py','archive_phase.py'))
paths.update(phase.glob('*.log'))
paths.update(phase/'normal'/n for n in ('plan.json','execution.json','independent-crosscheck.json','runner.log','build.log','ctest.log','smoke.log','routing.log','preparation.log'))
for name in ('routing','preparation'):
 paths.update(p for p in (phase/'normal'/name).iterdir() if p.is_file() and p.suffix in ('.json','.log','.conf'))
paths.update(phase/'coverage-01'/n for n in ('plan.json','execution.json','independent-crosscheck.json','setup-observation-error.json','runner.log'))
paths.update(p for p in (phase/'coverage-01/reports').rglob('*') if p.is_file())
paths.update(base/run/n for n in ('result.json','native-result.json','observations.jsonl','host-observations.jsonl','progress.json','native.stdout.log','native.stderr.log','owned-pipewire-cleanup.json'))
paths.update(base/(run+n) for n in ('-readiness.json','-launch.json','-recipe.json','-cool-start.json','-source-freeze.json','-thermal-guard.log','-thermal-guard.json','-report.json','-independent-crosscheck.json','-wait-launch.py','.stdout.json'))
assert all(p.suffix in ('.json','.jsonl','.log','.conf','.py','.patch','.txt','.sha256') for p in paths)
inputs={str(p.relative_to(root)):pin(read(p)) for p in sorted(paths)};assert sum(v['bytes'] for v in inputs.values())<=128*1024*1024
stage.mkdir(mode=0o700);rawdir.mkdir(mode=0o700);files={};uncompressed={};origins={}
def add(p):
 b=read(p);origin={'path':str(p.relative_to(root)),**pin(b)};name=origin['path'].replace('/','--');packedname=name+'.gz';assert packedname not in files
 if origin['path'] in inputs:assert pin(b)==inputs[origin['path']]
 (rawdir/name).write_bytes(b);packed=gzip.compress(b,mtime=0);(stage/packedname).write_bytes(packed)
 files[packedname]=pin(packed);uncompressed[packedname]=pin(b);origins[packedname]=origin
for p in sorted(paths):add(p)
scanlog=phase/'archive-gitleaks.log';scanreport=phase/'archive-gitleaks-findings.json';assert not scanlog.exists() and not scanreport.exists()
with scanlog.open('xb') as stream:
 scan=subprocess.run(['gitleaks','dir',str(rawdir),'--redact','--no-color','--report-format','json','--report-path',str(scanreport)],stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
assert scan.returncode==0 and json.loads(read(scanreport))==[]
for p in (scanlog,scanreport):add(p)
for name,expected in files.items():
 packed=(stage/name).read_bytes();b=gzip.decompress(packed);o=origins[name];assert pin(packed)==expected and pin(b)==uncompressed[name]=={k:o[k] for k in ('bytes','sha256')};assert b==read(root/o['path'])
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
for n,p in normal['pins_after'].items():assert pin((root/n).read_bytes())==p
v={'schema':'conflux.m2-worker-phase-timing.v1','source_head':head,'source_signature':sig,'status':'phase_retention_verified_and_short_actual_player_passed','m2_open':True,'sustained_actual_player_qualified':False,'summary':summary,'raw_secret_scan_exit':0,'raw_scanned_input_bytes':sum(p['bytes'] for p in inputs.values()),'files':files,'uncompressed':uncompressed,'origins':origins,'scope':'Named closed UTF-8 evidence, fixed source patch and metadata only. No audio, binaries, model, cache, HTML or XML. Scan covers selected raw inputs before scanner outputs and generated verification packaging.'}
(stage/'verification.json').write_text(json.dumps(v,indent=2,allow_nan=False)+'\n');assert not dest.exists();stage.rename(dest);print(json.dumps({'destination':str(dest),'files':len(files)+1,'source_head':head,'short_passed':True,'sustained_qualified':False}))
