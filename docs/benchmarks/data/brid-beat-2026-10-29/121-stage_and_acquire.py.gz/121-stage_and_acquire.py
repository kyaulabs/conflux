"""Stage fixed files, then own a bounded data-only acquisition on Apollo."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
B=Path(__file__).resolve().parent;P=B/'acquisition-01'
REMOTE='/srv/conflux-tests/work/brid-analysis-20261029-01/acquisition-01'
UNIT='conflux-brid-media-apollo-20261029-01.service'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
 '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
 '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
def pin(p):
 raw=p.read_bytes();return dict(file=p.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
entry='''from pathlib import Path
import hashlib,json,os,subprocess
b=Path(__file__).resolve().parent
for row in json.loads((b/'input-pins.json').read_text())['files']:
 p=b/row['file'];raw=p.read_bytes();assert not p.is_symlink() and len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
r=subprocess.run(['/usr/bin/python3','-E','-s','-B','-m','unittest','discover','-s',str(b),'-p','test_*.py','-v'],capture_output=True,text=True,timeout=20)
(b/'offline-checks.stdout.log').write_text(r.stdout);(b/'offline-checks.stderr.log').write_text(r.stderr)
assert r.returncode==0 and 'Ran 10 tests'in r.stderr and r.stderr.rstrip().endswith('OK')
os.execv('/usr/bin/python3',['python3','-E','-s','-B',str(b/'acquire.py'),'--run'])
'''
(P/'entry.py').write_text(entry)
files=[p for p in sorted(P.iterdir()) if p.is_file() and p.name in ('range_media.py','test_range_media.py','test_admission.py','plan.json','acquire.py','entry.py')]
assert len(files)==6
pins=dict(schema=1,files=[pin(p)for p in files],local_offline_checks=10,hardware_started=False)
(P/'input-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
contents={p.name:p.read_text()for p in files+[P/'input-pins.json']}
header='FILES='+repr(contents)+'\nBASE='+repr(REMOTE)+'\nUNIT='+repr(UNIT)+'\n'
program=r'''
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time
b=Path(BASE)
assert not b.parent.exists(),'Do not reuse a prior admission directory'
s=subprocess.check_output(['systemctl','show',UNIT,'--property=LoadState,MainPID'],text=True,timeout=5)
assert 'LoadState=not-found'in s and 'MainPID=0'in s
b.mkdir(mode=0o700,parents=True)
for name,text in FILES.items():
 assert '/'not in name and name not in ('.','..')
 with(b/name).open('x')as f:f.write(text)
for row in json.loads((b/'input-pins.json').read_text())['files']:
 p=b/row['file'];raw=p.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
dry=subprocess.run(['/usr/bin/python3','-E','-s','-B',str(b/'acquire.py')],capture_output=True,text=True,timeout=5)
assert dry.returncode==0 and json.loads(dry.stdout)['network_started'] is False
command=['sudo','-n','systemd-run','--unit='+UNIT,'--uid=1000','--gid=1000',
 '--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no','--property=RuntimeMaxSec=1260s',
 '--property=TimeoutStopSec=15s','--property=KillMode=control-group','--property=OOMPolicy=kill',
 '--property=MemoryMax=1G','--property=CPUQuota=100%','--property=TasksMax=64','--property=Nice=19','--property=UMask=0077',
 '--property=NoNewPrivileges=yes','--property=ProtectSystem=strict','--property=ProtectHome=yes',
 '--property=PrivateTmp=yes','--property=PrivateDevices=yes','--property=ReadWritePaths='+str(b),
 '--property=WorkingDirectory='+str(b),'--property=StandardOutput=append:'+str(b/'unit.stdout.log'),
 '--property=StandardError=append:'+str(b/'unit.stderr.log'),'/usr/bin/python3','-E','-s','-B',str(b/'entry.py')]
started=time.monotonic();r=subprocess.run(command,capture_output=True,text=True,timeout=15)
record=dict(schema=1,unit=UNIT,command=command,exit=r.returncode,stdout=r.stdout,stderr=r.stderr,
 started_monotonic=started,utc=datetime.now(timezone.utc).isoformat(),model_GPU_audio_output_started=False,
 physical_readiness_consumed=False,power_or_protected_services_changed=False)
with(b/'dispatch-01.json').open('x')as f:json.dump(record,f,indent=2)
r.check_returncode()
state=subprocess.check_output(['systemctl','show',UNIT,'--property=LoadState,MainPID,InvocationID,ControlGroup,ActiveState,SubState'],text=True,timeout=5)
record['owner'] = dict(x.split('=',1)for x in state.splitlines()if '='in x)
assert record['owner']['InvocationID']
print(json.dumps(record))
'''
assert not(B/'data-owner-01.json').exists()
with(B/'dispatch.stdout.log').open('x')as out,(B/'dispatch.stderr.log').open('x')as err:
 r=subprocess.run(SSH+['python3 -'],input=header+program,text=True,stdout=out,stderr=err,timeout=30)
r.check_returncode()
remote=json.loads((B/'dispatch.stdout.log').read_text())
with(B/'data-owner-01.json').open('x')as f:json.dump(remote,f,indent=2)
print(json.dumps(dict(unit=UNIT,owner=remote['owner'],data_only=True,model_GPU_audio_output_started=False)))
