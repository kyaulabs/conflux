"""Keep reverified Apollo sources; remove only this run's hashed local copies."""
from pathlib import Path
import hashlib,json,shutil,subprocess
B=Path(__file__).resolve().parent;C=B/'corpus-02'
assert json.loads((C/'closed-pair.json').read_text())['all_owners_retired']
sources=json.loads((B/'closed-acquisition-01.json').read_text())['result']['sources']
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','python3 -']
code='SOURCES='+repr(sources)+'\n'+r'''
from pathlib import Path
import hashlib,json
base=Path('/srv/conflux-tests/work/brid-analysis-20261029-01/acquisition-01/media-01')
for row in SOURCES:
 p=base/f"{row['id']:04}.wav";assert str(p)==row['source']['path']and not p.is_symlink()and p.stat().st_size==row['source']['bytes']
 with p.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['source']['sha256']
print(json.dumps(dict(reverified_sources=93,bytes=sum(r['source']['bytes']for r in SOURCES),retained_path=str(base),model_started=False)))
'''
r=subprocess.run(SSH,input=code,text=True,capture_output=True,timeout=25)
if r.returncode:print(r.stderr[-3000:]);r.check_returncode()
remote=json.loads(r.stdout);assert remote['reverified_sources']==93
before=shutil.disk_usage(B).free;media=B/'media-01';assert set(media.iterdir())=={media/f'{i:04}.wav'for i in range(1,94)}
for row in sources:
 p=media/f"{row['id']:04}.wav";assert not p.is_symlink()and p.stat().st_size==row['source']['bytes']
 with p.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['source']['sha256']
for row in sources:(media/f"{row['id']:04}.wav").unlink()
media.rmdir();removed=sum(r['source']['bytes']for r in sources)
fixture=B/'probe-build-01/laptop/thirty-seconds-44100.wav'
assert fixture.stat().st_size==5292044 and hashlib.sha256(fixture.read_bytes()).hexdigest()=='fd5e50da1574b17d1634c32e2789995a1ca33ca2136289e7d26b2434dbf25eda'
removed+=fixture.stat().st_size;fixture.unlink()
receipt=dict(schema=1,removed_only_owned_source_and_zero_fixture_copies=True,removed_payload_bytes=removed,free_before=before,free_after=shutil.disk_usage(B).free,retained_remote=remote,source_pins=sources,all_owners_previously_retired=True)
(B/'local-media-retirement.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k]for k in('removed_payload_bytes','free_before','free_after')}))
