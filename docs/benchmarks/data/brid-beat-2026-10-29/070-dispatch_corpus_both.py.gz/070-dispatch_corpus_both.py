"""Stage, pin and concurrently dispatch the fixed CPU correctness corpus."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,subprocess
B=Path(__file__).resolve().parent;C=B/'corpus-02'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
REMOTE='/srv/conflux-tests/work/brid-analysis-20261029-01/corpus-02'
LU='conflux-brid-cpu-laptop-20261029-02.service';RU='conflux-brid-cpu-apollo-20261029-02.service'
assert not(C/'dispatch.json').exists() and not(C/'laptop-output').exists()
files=[C/'apollo-plan.json',C/'protocol.json',B/'corpus_driver.py',B/'remote_corpus_owner.py',B/'runtime-manifest-01.json']
pins={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in files}
def remote(code,timeout=25):
 r=subprocess.run(SSH+['python3 -'],input=code,text=True,capture_output=True,timeout=timeout)
 if r.returncode:print(r.stderr[-6000:]);r.check_returncode()
 return r.stdout
remote('from pathlib import Path\np=Path('+repr(REMOTE)+');assert not p.exists();p.mkdir(mode=0o700)\n')
scp=['scp','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-P','4222']
subprocess.run(scp+[str(p)for p in files]+['kyau@apollo.kyaulabs:'+REMOTE+'/'],check=True,timeout=60)
remote('BASE='+repr(REMOTE)+'\nPINS='+repr(pins)+'\n'+r'''
from pathlib import Path
import hashlib,json,subprocess
b=Path(BASE)
for name,row in PINS.items():
 p=b/name;assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
(b/'stage-pins.json').write_text(json.dumps(PINS,indent=2)+'\n')
dry=subprocess.run(['/usr/bin/python3','-B',str(b/'remote_corpus_owner.py')],capture_output=True,text=True,timeout=5)
assert dry.returncode==0 and json.loads(dry.stdout)['model_started']is False
print(json.dumps(dict(staged=True,unarmed_entry_verified=True)))
''')
def check_inputs(host):
 if host=='laptop':
  r=subprocess.run(['/usr/bin/python3','-B',str(B/'corpus_driver.py'),'--plan',str(C/'laptop-plan.json'),'--check-inputs'],cwd='/',capture_output=True,text=True,timeout=75)
  assert r.returncode==0,r.stderr
  value=json.loads(r.stdout);assert value['passed']and value['model_started']is False
  return host,value
 code='BASE='+repr(REMOTE)+'\n'+r'''
from pathlib import Path
import json,subprocess
b=Path(BASE)
r=subprocess.run(['/usr/bin/python3','-B',str(b/'remote_corpus_owner.py'),'--check-inputs'],capture_output=True,text=True,timeout=100)
assert r.returncode==0,(r.stdout,r.stderr)
value=json.loads((b/'checked-result.json').read_text())
assert value['complete']and value['container_absent']and value['client_reaped']and value['analysis']['model_started']is False
print(json.dumps(value))
'''
 return host,json.loads(remote(code,timeout=110))
with ThreadPoolExecutor(max_workers=2)as pool:checked=dict(pool.map(check_inputs,('laptop','apollo')))
(C/'input-context-checks.json').write_text(json.dumps(checked,indent=2)+'\n')
state=subprocess.check_output(['systemctl','--user','show',LU,'--property=LoadState,MainPID'],text=True,timeout=5)
assert 'LoadState=not-found'in state and 'MainPID=0'in state
remote('UNIT='+repr(RU)+'\n'+"import subprocess\ns=subprocess.check_output(['systemctl','show',UNIT,'--property=LoadState,MainPID'],text=True,timeout=5);assert 'LoadState=not-found'in s and 'MainPID=0'in s\n")
local=['systemd-run','--user','--unit='+LU,'--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no','--property=RuntimeMaxSec=1260s','--property=TimeoutStopSec=20s','--property=KillMode=control-group','--property=Nice=19','--property=CPUQuota=200%','--property=MemoryMax=4G','--property=TasksMax=512','--property=UMask=0077','--property=StandardOutput=append:'+str(C/'laptop-unit.stdout.log'),'--property=StandardError=append:'+str(C/'laptop-unit.stderr.log'),'/usr/bin/python3','-B',str(B/'corpus_driver.py'),'--plan',str(C/'laptop-plan.json'),'--run']
remote_code='BASE='+repr(REMOTE)+'\nUNIT='+repr(RU)+'\n'+r'''
from pathlib import Path
import json,subprocess
b=Path(BASE)
command=['sudo','-n','systemd-run','--unit='+UNIT,'--uid=1000','--gid=1000','--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no','--property=RuntimeMaxSec=1320s','--property=TimeoutStopSec=30s','--property=KillMode=control-group','--property=MemoryMax=5G','--property=TasksMax=512','--property=UMask=0077','--property=ExecStopPost=/usr/bin/python3 -B '+str(b/'remote_corpus_owner.py')+' --cleanup-only','--property=StandardOutput=append:'+str(b/'unit.stdout.log'),'--property=StandardError=append:'+str(b/'unit.stderr.log'),'/usr/bin/python3','-B',str(b/'remote_corpus_owner.py'),'--run']
r=subprocess.run(command,capture_output=True,text=True,timeout=20)
assert r.returncode==0,r.stderr
state=dict(x.split('=',1)for x in subprocess.check_output(['systemctl','show',UNIT,'--property=MainPID,InvocationID,ControlGroup,ActiveState,SubState'],text=True,timeout=5).splitlines()if '='in x)
print(json.dumps(dict(unit=UNIT,owner=state,command=command,exit=r.returncode)))
'''
def launch(host):
 if host=='laptop':
  r=subprocess.run(local,capture_output=True,text=True,timeout=20);assert r.returncode==0,r.stderr
  state=dict(x.split('=',1)for x in subprocess.check_output(['systemctl','--user','show',LU,'--property=MainPID,InvocationID,ControlGroup,ActiveState,SubState'],text=True,timeout=5).splitlines()if '='in x)
  return host,dict(unit=LU,owner=state,command=local,exit=r.returncode)
 return host,json.loads(remote(remote_code))
with ThreadPoolExecutor(max_workers=2)as pool:result=dict(pool.map(launch,('laptop','apollo')))
result.update(schema=1,concurrent=True,scope='CPU-only musical timing correctness, no client, GPU, audio output, host policy change or latency qualification',protocol_sha256=hashlib.sha256((C/'protocol.json').read_bytes()).hexdigest(),stage_pins=pins)
(C/'dispatch.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({h:dict(unit=result[h]['unit'],owner=result[h]['owner'])for h in('laptop','apollo')}))
