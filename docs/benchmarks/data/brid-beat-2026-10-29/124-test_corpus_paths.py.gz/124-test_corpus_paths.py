"""The actual relative-path regression must fail before model launch."""
from pathlib import Path
import hashlib,os,tempfile,unittest
import corpus_driver
class Paths(unittest.TestCase):
 def test_existing_relative_asset_is_rejected_independent_of_working_directory(self):
  previous=Path.cwd()
  with tempfile.TemporaryDirectory()as folder:
   p=Path(folder)/'existing.bin';p.write_bytes(b'exact-content')
   try:
    os.chdir(folder)
    with self.assertRaisesRegex(AssertionError,'absolute'):corpus_driver.pin('existing.bin')
    self.assertEqual(corpus_driver.pin(p),dict(bytes=13,sha256=hashlib.sha256(b'exact-content').hexdigest()))
   finally:os.chdir(previous)
if __name__=='__main__':unittest.main()
