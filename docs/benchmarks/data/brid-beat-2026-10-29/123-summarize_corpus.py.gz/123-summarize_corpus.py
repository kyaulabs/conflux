"""Score all93 frozen cases only after both exact owners are retired."""
from pathlib import Path
import hashlib,json,statistics
import score_brid as scoring
B=Path(__file__).resolve().parent;C=B/'corpus-02'
closed=json.loads((C/'closed-pair.json').read_text());assert closed['all_owners_retired'] and closed['all_containers_retired']
protocol=json.loads((C/'protocol.json').read_text());raw=scoring.Path(protocol['scorer']['path']).read_bytes()
assert len(raw)==protocol['scorer']['bytes'] and hashlib.sha256(raw).hexdigest()==protocol['scorer']['sha256']
first=json.loads((B/'corpus-01/protocol.json').read_text())
assert protocol['gates']==first['gates'] and protocol['scorer']==first['scorer'] and protocol['cases']==first['cases']
cases=protocol['cases'];assert len(cases)==93 and [c['id']for c in cases]==list(range(1,94))
hosts={};raw_rows={}
for host,base in(('laptop',C/'laptop-output'),('apollo',C/'apollo-collected/work/output')):
 plan=json.loads((C/(host+'-plan.json')).read_text());result=json.loads((base/'result.json').read_text())
 assert result['source_plan_sha256']==hashlib.sha256((C/(host+'-plan.json')).read_bytes()).hexdigest()
 assert result['native_reaped'] and result['spool_empty_after_child_exit'] and result['inputs_reverified']
 rows,terminal=scoring.rows((base/'native.stdout.jsonl').read_bytes());assert terminal['mode']=='analysis' and terminal['expected']==93 and terminal['completed']==len(rows)
 assert type(terminal['complete'])is bool and type(terminal['passed'])is bool
 assert not terminal['complete']or len(rows)==93
 assert not terminal['passed']or terminal['complete']and all(r.get('passed')is True for r in rows)
 scores=[scoring.score(case,rows[index]if index<len(rows)else None,plan['cases'][index]['source_path'])for index,case in enumerate(cases)]
 total_refs=sum(len(c['reference_seconds_text'])for c in cases);total_downrefs=sum(sum(p==1 for p in c['bar_positions'])for c in cases)
 def micro(which,refs):
  metrics=[s['beat']['full']if which=='beat'else s['downbeat']for s in scores if s['operational_status']in('Estimated','Unknown')]
  matches=sum(m['matched_beats']for m in metrics);estimates=sum(m['estimated_beats']for m in metrics)
  return dict(reference_events=refs,accepted_estimated_events=estimates,matched_events=matches,misses=refs-matches,extras=estimates-matches,F1=2*matches/(refs+estimates)if refs+estimates else 0,failed_or_missing_cases_treated_as_no_accepted_events=True)
 hosts[host]=dict(fixed_denominator=93,complete=result['complete'],native_rows=len(rows),terminal=terminal,
  beat_cases_passing=sum(s['beat_numeric_pass']for s in scores),downbeat_cases_passing=sum(s['downbeat_numeric_pass']for s in scores),both_cases_passing=sum(s['both_numeric_pass']for s in scores),
  operational_statuses={status:sum(s['operational_status']==status for s in scores)for status in('Estimated','Unknown','Failed')},
  beat_micro=micro('beat',total_refs),downbeat_micro=micro('downbeat',total_downrefs),cases=scores,qualified=False)
 raw_rows[host]=rows
comparisons=[]
for index,case in enumerate(cases):
 left=raw_rows['laptop'][index]if index<len(raw_rows['laptop'])else None
 right=raw_rows['apollo'][index]if index<len(raw_rows['apollo'])else None
 comparable=bool(left and right and left.get('passed')is True and right.get('passed')is True)
 comparisons.append(dict(id=case['id'],comparable=comparable,exact_prepared_PCM=bool(comparable and(left['prepared_frames'],left['pcm_sha256'])==(right['prepared_frames'],right['pcm_sha256'])),exact_beat_map=bool(comparable and left['beats']==right['beats'])))
summary=dict(schema=1,protocol_sha256=hashlib.sha256((C/'protocol.json').read_bytes()).hexdigest(),fixed_denominator=93,hosts=hosts,host_comparisons=comparisons,
 exact_prepared_PCM_cases=sum(c['exact_prepared_PCM']for c in comparisons),exact_beat_map_cases=sum(c['exact_beat_map']for c in comparisons),
 qualified=False,latency_qualified=False,whole_M2_gate_pass=False,automatic_use=False,confidence='Unknown',phrases_or_local_harmony_qualified=False,
 training_independence='Unknown at recording level',retained_ARTBeaT_passes=9,retained_ARTBeaT_denominator=24,
 prior_abandoned_attempt_retained=str(B/'corpus-01/closed-pair.json'))
(C/'scores.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(hosts={host:{key:row[key]for key in('complete','native_rows','beat_cases_passing','downbeat_cases_passing','both_cases_passing','operational_statuses','beat_micro','downbeat_micro')}for host,row in hosts.items()},exact_prepared_PCM_cases=summary['exact_prepared_PCM_cases'],exact_beat_map_cases=summary['exact_beat_map_cases'],qualified=False)))
