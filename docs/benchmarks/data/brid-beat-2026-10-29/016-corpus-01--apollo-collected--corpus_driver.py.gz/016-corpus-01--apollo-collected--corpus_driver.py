"""One fixed CPU-only production analysis; labels never enter the worker."""
from pathlib import Path
import argparse,hashlib,json,os,signal,subprocess,time

def pin(path):
 p=Path(path);before=p.stat();assert p.is_file()and not p.is_symlink()
 with p.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 after=p.stat();assert(before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
 return dict(bytes=before.st_size,sha256=digest)

def main():
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--run',action='store_true');args=p.parse_args()
 plan=json.loads(args.plan.read_text());assert plan['schema']==1 and plan['fixed_denominator']==93 and len(plan['cases'])==93
 if not args.run:print(json.dumps(dict(unarmed=True,model_started=False)));return
 output=Path(plan['output']);assert not output.exists();output.mkdir(mode=0o700)
 spool=output/'spool';spool.mkdir(mode=0o700)
 start=time.monotonic();deadline=start+1215;child=None;stages={};result=dict(schema=1,complete=False,qualified=False,physical_readiness_consumed=False,GPU_used=False,audio_output_started=False,model_started=False,source_plan_sha256=hashlib.sha256(args.plan.read_bytes()).hexdigest())
 def interrupted(number,frame):raise InterruptedError('Owned CPU corpus interrupted')
 for number in(signal.SIGINT,signal.SIGTERM):signal.signal(number,interrupted)
 def verify():
  for row in plan['input_pins']:
   assert time.monotonic()<deadline and pin(row['path'])=={k:row[k]for k in('bytes','sha256')},row['path']
 try:
  verify();assert[case['id']for case in plan['cases']]==list(range(1,94))
  command=[plan['probe']['path'],'--bpm-analysis',str(spool),plan['python'],plan['source_directory'],plan['model'],plan['worker']]+[case['source_path']for case in plan['cases']]
  with(output/'native.stdout.jsonl').open('x')as out,(output/'native.stderr.log').open('x')as err:
   child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
   result.update(model_started=True,command=command,native_pid=child.pid)
   (output/'dispatch.json').write_text(json.dumps(result,indent=2)+'\n')
   code=child.wait(timeout=max(1,deadline-time.monotonic()-15))
  result['native_exit']=code
  assert(output/'native.stdout.jsonl').stat().st_size<=16*1024**2 and(output/'native.stderr.log').stat().st_size<=1024**2
  rows=[json.loads(line)for line in(output/'native.stdout.jsonl').read_text().splitlines()]
  assert rows and rows[-1]['kind']=='production-bpm-complete'
  result['terminal']=rows[-1];result['native_cases']=len(rows)-1
  verify();result['inputs_reverified']=True
  assert not list(spool.iterdir()),'Native spool leaked'
  result['spool_retired']=True
  result['complete']=code==0 and rows[-1]['complete'] and rows[-1]['passed'] and len(rows)==94 and rows[-1]['completed']==rows[-1]['expected']==93
 except BaseException as error:result['error']=dict(type=type(error).__name__,message=str(error)[:3000])
 finally:
  if child is not None and child.poll()is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=8)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
  result.update(native_reaped=child is None or child.poll()is not None,seconds=time.monotonic()-start)
  result['spool_empty_after_child_exit']=not list(spool.iterdir())
  (output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:result.get(k)for k in('complete','native_cases','seconds','error','qualified')}),flush=True)
 raise SystemExit(0 if result['complete']else 1)

if __name__=='__main__':main()
