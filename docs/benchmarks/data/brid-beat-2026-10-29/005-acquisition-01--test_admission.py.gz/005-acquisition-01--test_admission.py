"""Generated WAVs and archive faults only; no network, music, model or audio output."""
from pathlib import Path
import io,math,tempfile,unittest,wave,zipfile,zlib
from acquire import admit,wave_geometry

class AdmissionTests(unittest.TestCase):
 def audio(self):
  stream=io.BytesIO()
  with wave.open(stream,'wb')as output:
   output.setparams((2,2,44100,44100,'NONE','not compressed'));output.writeframes(b'\0'*176400)
  return stream.getvalue()
 def beats(self):return [dict(seconds=.1,bar_position=1),dict(seconds=.6,bar_position=2)]
 def test_exact_wav_clock_and_reference_extent_are_required(self):
  self.assertEqual(wave_geometry(self.audio(),self.beats())['frames'],44100)
  for bad in ([dict(seconds=1.,bar_position=1)],[dict(seconds=float('nan'),bar_position=1)],
    [dict(seconds=.2,bar_position=1),dict(seconds=.1,bar_position=2)],
    [dict(seconds=.1,bar_position=1),dict(seconds=.2,bar_position=1)]):
   with self.subTest(beats=bad),self.assertRaises(AssertionError):wave_geometry(self.audio(),bad)
 def test_only_the_pinned_member_is_written_without_archive_paths(self):
  raw=self.audio();archive=io.BytesIO()
  with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:z.writestr('Audio/[0001] M4-01-SA.wav',raw)
  with zipfile.ZipFile(archive)as z,tempfile.TemporaryDirectory()as t:
   info=z.infolist()[0];case=dict(id=1,beats=self.beats(),source=dict(name=info.filename,bytes=info.file_size,compressed_bytes=info.compress_size,CRC32=f'{info.CRC:08x}'))
   result=admit(z,case,Path(t));self.assertEqual(Path(result['path']).read_bytes(),raw)
   self.assertEqual([p.name for p in Path(t).iterdir()],['0001.wav'])
   with self.assertRaises(FileExistsError):admit(z,case,Path(t))
   case['source']['CRC32']='00000000'
   with self.assertRaises(AssertionError):admit(z,case,Path(t))

if __name__=='__main__':unittest.main(verbosity=2)
