"""Regress the new reference adapter's failure and metrical boundaries."""
import copy,json,unittest
import score_brid as s

def fixture():
 refs=[f'{.25+i*.5:.3f}'for i in range(20)];positions=[1 if i%2==0 else 2 for i in range(20)]
 case=dict(id=1,name='generated',reference_seconds_text=refs,bar_positions=positions,source=dict(sha256='a'*64,bytes=2116844,source_geometry=dict(frames=529200)))
 row=dict(source='/fixed.wav',source_sha256='a'*64,source_bytes=2116844,passed=True,analysis_status='Estimated',analysis_error='',cache_hit=False,prepared_frames=576000,prepared_bytes=576000*8,prepared_rate_hz=48000,analysis_frames=576000,pcm_sha256='b'*64,analysis_pcm_sha256='b'*64,summary_bpm=120.0,beats=[dict(frame=12000+i*24000,downbeat=pos==1)for i,pos in enumerate(positions)])
 return case,row

class Adapter(unittest.TestCase):
 def test_exact_beats_and_two_position_downbeats(self):
  case,row=fixture();r=s.score(case,row,'/fixed.wav');self.assertTrue(r['both_numeric_pass']);self.assertEqual(r['downbeat']['matched_beats'],10);self.assertFalse(r['qualified'])
 def test_wrong_bar_phase_cannot_pass_downbeat_screen(self):
  case,row=fixture()
  for event in row['beats']:event['downbeat']=not event['downbeat']
  r=s.score(case,row,'/fixed.wav');self.assertTrue(r['beat_numeric_pass']);self.assertFalse(r['downbeat_numeric_pass']);self.assertEqual(r['downbeat']['f1'],0)
 def test_no_fitted_shift(self):
  case,row=fixture()
  for event in row['beats']:event['frame']+=4320
  r=s.score(case,row,'/fixed.wav');self.assertFalse(r['both_numeric_pass']);self.assertEqual(r['beat']['full']['matched_beats'],0)
 def test_changed_source_and_malformed_raw_events_fail(self):
  for mutation in ('source','duplicate','nonboolean','positions','summary'):
   case,row=fixture()
   if mutation=='source':row['source_sha256']='c'*64
   elif mutation=='duplicate':row['beats'][1]['frame']=row['beats'][0]['frame']
   elif mutation=='nonboolean':row['beats'][0]['downbeat']=1
   elif mutation=='positions':case['bar_positions'].pop()
   else:row['summary_bpm']=100
   with self.subTest(mutation=mutation):
    r=s.score(case,row,'/fixed.wav');self.assertEqual(r['operational_status'],'Failed');self.assertFalse(r['both_numeric_pass'])
 def test_missing_case_remains_failure(self):
  case,row=fixture();r=s.score(case,None,'/fixed.wav');self.assertEqual(r['id'],1);self.assertFalse(r['both_numeric_pass'])
 def test_abstention_is_not_accuracy_acceptance(self):
  case,row=fixture();row.update(analysis_status='Unknown',summary_bpm=None,beats=[])
  r=s.score(case,row,'/fixed.wav');self.assertEqual(r['operational_status'],'Unknown');self.assertEqual(r['beat']['full']['false_negatives'],20);self.assertFalse(r['both_numeric_pass'])
 def test_duplicate_json_and_missing_terminal_are_rejected(self):
  for raw in(b'{"kind":"production-bpm-complete","kind":"production-bpm-complete"}\n',b'{"ordinal":0}\n',b'{}'):
   with self.assertRaises(ValueError):s.rows(raw)

if __name__=='__main__':unittest.main()
