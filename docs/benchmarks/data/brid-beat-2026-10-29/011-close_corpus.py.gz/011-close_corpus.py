"""Collect and retire an exact existing paired corpus; never relaunch it."""
from pathlib import Path
import argparse,hashlib,json,subprocess
P=argparse.ArgumentParser();P.add_argument('attempt',choices=('01','02'));a=P.parse_args()
B=Path(__file__).resolve().parent;C=B/('corpus-'+a.attempt);d=json.loads((C/'dispatch.json').read_text())
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','python3 -']
COMMON=r'''
from pathlib import Path
import json,subprocess
def retire(unit,expected,original_group,user):
 cmd=['systemctl']+(['--user']if user else[])
 state=dict(x.split('=',1)for x in subprocess.check_output(cmd+['show',unit,'--property=MainPID,InvocationID,ControlGroup,ActiveState,SubState,Result,ExecMainStatus'],text=True,timeout=5).splitlines()if '='in x)
 assert state['InvocationID']==expected and state['MainPID']=='0','Observation is not terminal'
 subprocess.run(([]if user else['sudo','-n'])+cmd+['stop',unit],check=True,capture_output=True,timeout=40)
 after=dict(x.split('=',1)for x in subprocess.check_output(cmd+['show',unit,'--property=MainPID,ControlGroup,ActiveState,SubState'],text=True,timeout=5).splitlines()if '='in x)
 assert after['MainPID']=='0'and not after['ControlGroup']and after['ActiveState']in('inactive','failed')
 cg=Path('/sys/fs/cgroup'+original_group);assert not cg.exists()or not(cg/'cgroup.procs').read_text().strip()
 if after['ActiveState']=='failed':subprocess.run(([]if user else['sudo','-n'])+cmd+['reset-failed',unit],check=True,capture_output=True,timeout=10)
 return dict(terminal=state,retired=after,original_cgroup_absent_or_empty=True)
'''
ns={};exec(COMMON,ns)
local=ns['retire'](d['laptop']['unit'],d['laptop']['owner']['InvocationID'],d['laptop']['owner']['ControlGroup'],True)
code=COMMON+'\nD='+repr(d['apollo'])+'\nATTEMPT='+repr(a.attempt)+'\n'+r'''
b=Path('/srv/conflux-tests/work/brid-analysis-20261029-01')/('corpus-'+ATTEMPT)
result=retire(D['unit'],D['owner']['InvocationID'],D['owner']['ControlGroup'],False)
closed=json.loads((b/'closed-result.json').read_text());assert closed['container_absent']and closed['client_reaped']
result['closed_result']=closed
captures={}
for name in('closed-result.json','container.log','corpus_driver.py','work/output/result.json','work/output/native.stdout.jsonl','work/output/native.stderr.log'):
 p=b/name
 if p.exists():
  assert p.stat().st_size<=16*1024**2;captures[name]=p.read_text()
result['captures']=captures
print(json.dumps(result))
'''
r=subprocess.run(SSH,input=code,text=True,capture_output=True,timeout=60)
if r.returncode:print(r.stderr[-4000:]);r.check_returncode()
remote=json.loads(r.stdout);target=C/'apollo-collected';target.mkdir(mode=0o700)
for name,text in remote.pop('captures').items():
 p=target/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
receipt=dict(schema=1,laptop=local,apollo=remote,all_owners_retired=True,all_containers_retired=True,no_relaunch=True,qualified=False)
(C/'closed-pair.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(retired=True,attempt=a.attempt,laptop=local['terminal'],apollo=remote['terminal'],apollo_complete=remote['closed_result']['complete'])))
