"""Private fixed ARTBeaT metadata/source-time arithmetic; no media/model imports."""
from decimal import Decimal, localcontext
import math
from pathlib import PurePosixPath
import re

FPS = 50
RESAMPLED_RATE = 22050
HOP = 441
ART_IDS = tuple(i for i in range(1, 26) if i != 21)
MAX_SECONDS = 48
MAX_EVENTS = 4096


def _source(source_frames, sample_rate):
    if (type(sample_rate) is not int or sample_rate not in (44100, 48000) or
            type(source_frames) is not int or not 0 < source_frames <= MAX_SECONDS * sample_rate):
        raise ValueError("Invalid bounded source geometry")


def _references(csv_text, frames):
    if type(csv_text) is not str or not 0 < len(csv_text.encode("utf-8")) <= 16384:
        raise ValueError("Invalid bounded annotation text")
    lines = csv_text.splitlines()
    if not 0 < len(lines) <= MAX_EVENTS:
        raise ValueError("Invalid annotation count")
    result = []
    with localcontext() as context:
        # Each admitted decimal has at most64 characters; multiplication by44100
        # is exact at this precision. No float-duration rounding admits EOF.
        context.prec = 80
        for line in lines:
            if not 0 < len(line) <= 64 or re.fullmatch(r"(?:0|[1-9][0-9]*)(?:\.[0-9]+)?", line) is None:
                raise ValueError("Invalid one-column decimal annotation")
            value = Decimal(line)
            if value * 44100 >= frames or (result and value <= result[-1]):
                raise ValueError("Annotation is outside source or not strictly ordered")
            result.append(value)
    return lines, tuple(result)


def admit_artbeat_track(track, csv_text):
    if type(track) is not dict or type(track.get("id")) is not int or track["id"] not in ART_IDS:
        raise ValueError("Unknown or prospectively excluded ARTBeaT item")
    frames = track.get("frames")
    _source(frames, 44100)
    if frames > 24 * 44100:
        raise ValueError("ART source exceeds24 seconds")
    fmt, data = track.get("fmt"), track.get("data")
    expected = {"format_tag": 1, "actual_format_tag": 1, "channels": 2,
                "sample_rate": 44100, "byte_rate": 176400,
                "block_align": 4, "bits_per_sample": 16}
    if (type(fmt) is not dict or any(type(fmt.get(k)) is not int or fmt[k] != v for k, v in expected.items()) or
            type(data) is not dict or type(data.get("bytes")) is not int or data["bytes"] != frames * 4 or
            type(data.get("offset")) is not int or not 44 <= data["offset"] <= 65536 or
            type(track.get("ZIP_uncompressed_bytes")) is not int or
            track["ZIP_uncompressed_bytes"] != data["offset"] + data["bytes"] or
            track.get("container") != "RIFF" or track.get("data_ends_at_member_boundary") is not True):
        raise ValueError("ART PCM16 source metadata differs")
    member = PurePosixPath(track.get("member", ""))
    csv_name = track.get("CSV_reference_file")
    if (member.parent.as_posix() != "ARTBeaT_Dataset/Audio" or member.suffix != ".wav" or
            not member.name.startswith(f"{track['id']:02d}_ARTBeaT_") or
            csv_name != member.stem + "_gt.csv"):
        raise ValueError("ART source/reference identity differs")
    lines, seconds = _references(csv_text, frames)
    return {"id": track["id"], "frames": frames, "sample_rate": 44100,
            "channels": 2, "reference_seconds_text": lines,
            "reference_seconds": seconds}


def source_duration_mask(source_frames, sample_rate, channel_resampled_frames, logit_frames):
    _source(source_frames, sample_rate)
    if (type(channel_resampled_frames) not in (tuple, list) or len(channel_resampled_frames) != 2 or
            any(type(n) is not int or n <= 0 for n in channel_resampled_frames) or
            channel_resampled_frames[0] != channel_resampled_frames[1]):
        raise ValueError("Channel resampled geometry differs")
    resampled = channel_resampled_frames[0]
    numerator = source_frames * RESAMPLED_RATE
    # This bounds the observed integer output to floor/ceil of the exact rate
    # ratio, without claiming which rounding rule a resampler implements.
    permitted = {numerator // sample_rate, (numerator + sample_rate - 1) // sample_rate}
    if (resampled not in permitted or type(logit_frames) is not int or
            logit_frames != resampled // HOP + 1 or logit_frames > MAX_SECONDS * FPS + 1):
        raise ValueError("Resampled/centered frontend geometry differs")
    return tuple(k * sample_rate < source_frames * FPS for k in range(logit_frames))


def source_intervals(seconds, source_frames, sample_rate):
    _source(source_frames, sample_rate)
    if type(seconds) not in (list, tuple) or len(seconds) > MAX_EVENTS:
        raise ValueError("Invalid bounded returned stream")
    frames = []
    previous = None
    for value in seconds:
        if type(value) not in (int, float):
            raise ValueError("Invalid returned source event")
        try:
            valid = math.isfinite(value) and 0 <= value < source_frames / sample_rate
        except OverflowError:
            valid = False
        if not valid:
            raise ValueError("Invalid returned source event")
        frame = round(value * sample_rate)
        if (not 0 <= frame < source_frames or
                (previous is not None and (value <= previous or frame <= frames[-1]))):
            raise ValueError("Invalid returned source order/frame")
        frames.append(frame)
        previous = value
    return [{"from_source_frame": before, "at_source_frame": later,
             "delta_frames": later - before, "bpm": 60 * sample_rate / (later - before),
             "available_after_source_frame": source_frames}
            for before, later in zip(frames, frames[1:])]
