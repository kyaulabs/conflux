"""Freeze all references and run inputs before viewing any new predictions."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
B=Path(__file__).resolve().parent;C=B/'corpus-02';C.mkdir(mode=0o700)
ROOT=B.parent.parent;runtime=json.loads((B/'runtime-manifest-01.json').read_text())
admission=json.loads((B/'closed-acquisition-01.json').read_text())['result']
fixed=json.loads((B/'acquisition-01/plan.json').read_text())
annotations=json.loads((ROOT/'build/m2-brid-reference-01/annotation-members-01.json').read_text())['members']
assert json.loads((B/'runtime-paired-check-01.json').read_text())['passed']
assert json.loads((B/'source-copy-result-01.json').read_text())['complete']
verification=json.loads((B/'probe-build-01/paired-verification-01.json').read_text());assert verification['passed']
def pin(p):
 p=Path(p)
 with p.open('rb')as f:d=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=d)
cases=[]
for reference,admitted in zip(fixed['cases'],admission['sources']):
 assert reference['id']==admitted['id']
 match=[row for row in annotations if row['sha256']==reference['beat_reference_sha256']];assert len(match)==1
 row=match[0];assert hashlib.sha256(row['text'].encode()).hexdigest()==row['sha256']
 lines=[line.split()for line in row['text'].splitlines()]
 assert [dict(seconds=float(t),bar_position=int(pos))for t,pos in lines]==reference['beats']
 cases.append(dict(id=reference['id'],name=reference['name'],source=admitted['source'],reference_seconds_text=[t for t,pos in lines],bar_positions=[int(pos)for t,pos in lines],annotation_sha256=row['sha256']))
assert len(cases)==93 and sum(len(c['reference_seconds_text'])for c in cases)==4342 and sum(sum(p==1 for p in c['bar_positions'])for c in cases)==2205
protocol=dict(schema=1,utc=datetime.now(timezone.utc).isoformat(),fixed_denominator=93,cases=cases,
 selection='All released ensembleGID0001..0093; no post-output exclusion, shift, octave or threshold fitting',
 gates=json.loads((ROOT/'build/m2-brid-reference-01/prospective-admission-01.json').read_text())['proposed_score'],
 scorer=pin(B/'score_brid.py'),scorer_tests=pin(B/'test_score_brid.py'),scorer_tests_passed=7,
 scorer_helpers=json.loads((ROOT/'build/m2-analysis-qualification-01/beat-this-final1-01/evaluation-01/plan.json').read_text())['helpers'],
 native_adapter=pin(B/'probe-build-01/probe.cpp'),driver=pin(B/'corpus_driver.py'),runtime_manifest=pin(B/'runtime-manifest-01.json'),
 no_new_attempt_outputs_seen=True,qualified=False,training_independence='Unknown at recording level; BRID absent from disclosedv1 roots',
 earlier_attempt=pin(B/'corpus-01/closed-pair.json'),original_prescoring_protocol=pin(B/'corpus-01/protocol.json'),
 correction='Resolve local manifest paths, reject relative assets, and verify inputs in the real execution context before dispatch. Original abandoned attempt retained; model, scoring rules and source selection unchanged.',
 path_regression=pin(B/'test_corpus_paths.py'),path_regression_passed=1,
 retained_ARTBeaT_passes=9,retained_ARTBeaT_denominator=24,latency_qualified=False)
(C/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
original_venv=runtime['source_venv'];setup=Path(original_venv).parent.parent
localprobe=B/'probe-build-01/laptop/native/brid-production-probe'
assert pin(localprobe)['sha256']=='ea21916ff6af9d23156c1cd85beef760be24958d9883354aaca2287f6236caeb'
remote_root='/srv/conflux-tests/work/brid-analysis-20261029-01'
for host in('laptop','apollo'):
 local=host=='laptop';probe=pin(localprobe);probe['path']=str(localprobe)if local else'/probe/brid-production-probe'
 inputs=[dict(path=str(Path(r['path']).resolve())if local else'/assets/'+r['file'],bytes=r['bytes'],sha256=r['sha256'])for r in runtime['files']]
 inputs.append(probe)
 inputs.append(dict(pin(B/'corpus_driver.py'),path=str(B/'corpus_driver.py')if local else'/operations/corpus_driver.py'))
 inputs.append(dict(pin(C/'protocol.json'),path=str(C/'protocol.json')if local else'/operations/protocol.json'))
 rows=[]
 for case in cases:
  sourcepath=str(B/'media-01'/f"{case['id']:04}.wav")if local else f"/media/{case['id']:04}.wav"
  inputs.append(dict(path=sourcepath,bytes=case['source']['bytes'],sha256=case['source']['sha256']))
  rows.append(dict(id=case['id'],source_path=sourcepath))
 plan=dict(schema=1,host=host,fixed_denominator=93,probe=probe,python=original_venv+'/bin/python',
  source_directory=str(setup/'source')if local else'/assets/source',model=str(setup/'private-setup-03/downloads/final0.ckpt')if local else'/assets/model/final0.ckpt',
  worker=str(ROOT/'build/m2-current-player-hour-01/source-build-01/laptop/source/tools/timing/analyze_bpm.py')if local else'/assets/worker/analyze_bpm.py',
  output=str(C/'laptop-output')if local else'/work/output',cases=rows,input_pins=inputs,protocol=pin(C/'protocol.json'),
  native_global_seconds=1170,parent_seconds=1215,qualified=False,physical_readiness_consumed=False)
 (C/(host+'-plan.json')).write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(frozen=True,cases=93,reference_events=4342,downbeat_reference_events=2205,protocol_sha256=pin(C/'protocol.json')['sha256'],model_started=False)))
