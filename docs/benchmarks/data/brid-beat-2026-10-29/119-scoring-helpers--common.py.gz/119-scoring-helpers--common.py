"""Score frozen generated references without fitting a time shift or threshold."""
from pathlib import Path
import hashlib
import json
import math
import statistics
import sys


def matches(reference, events, tolerance):
    """Ordered maximum cardinality, then minimum absolute-error matching."""
    rows, cols = len(reference), len(events)
    score = [[(0, 0.0)] * (cols + 1) for _ in range(rows + 1)]
    choice = [bytearray(cols + 1) for _ in range(rows + 1)]
    for i in range(1, rows + 1):
        for j in range(1, cols + 1):
            best = score[i - 1][j]
            direction = 1
            if score[i][j - 1] > best:
                best, direction = score[i][j - 1], 2
            error = abs(reference[i - 1] - events[j - 1]["seconds"])
            if error <= tolerance:
                before = score[i - 1][j - 1]
                candidate = (before[0] + 1, before[1] - error)
                if candidate >= best:
                    best, direction = candidate, 3
            score[i][j], choice[i][j] = best, direction
    result = []
    i, j = rows, cols
    while i and j:
        direction = choice[i][j]
        if direction == 3:
            result.append((i - 1, j - 1))
            i -= 1
            j -= 1
        elif direction == 1:
            i -= 1
        else:
            j -= 1
    return list(reversed(result))


def quantile(values, p):
    if not values:
        return None
    values = sorted(values)
    return values[max(0, math.ceil(len(values) * p) - 1)]


def metrics(reference, events, tolerance):
    pairs = matches(reference, events, tolerance)
    errors = [abs(reference[i] - events[j]["seconds"]) for i, j in pairs]
    precision = len(pairs) / len(events) if events else 0.0
    recall = len(pairs) / len(reference) if reference else 0.0
    return {
        "reference_beats": len(reference), "estimated_beats": len(events),
        "matched_beats": len(pairs), "false_positives": len(events) - len(pairs),
        "false_negatives": len(reference) - len(pairs), "precision": precision,
        "recall": recall, "f1": 2 * precision * recall / (precision + recall) if precision + recall else 0.0,
        "matched_error_median_seconds": statistics.median(errors) if errors else None,
        "matched_error_p95_seconds": quantile(errors, 0.95),
        "matched_error_max_seconds": max(errors) if errors else None,
    }, pairs


def tempo_at(fixture, t):
    b0 = fixture.get("tempo_bpm", 0)
    if "change_seconds" in fixture:
        return fixture["new_tempo_bpm"] if t >= fixture["change_seconds"] else b0
    if "ramp_start_seconds" in fixture:
        fraction = min(1, max(0, (t - fixture["ramp_start_seconds"]) /
                              (fixture["ramp_end_seconds"] - fixture["ramp_start_seconds"])))
        return b0 + fraction * (fixture["new_tempo_bpm"] - b0)
    return b0


def tempo_errors(fixture, events):
    return [abs(e["bpm"] - tempo_at(fixture, e["seconds"])) / tempo_at(fixture, e["seconds"])
            for e in events if e["bpm"] is not None and tempo_at(fixture, e["seconds"]) > 0]


def source_alignment(fixture, reference, events, pairs, start=0.0):
    paired, streak = dict(pairs), []
    for i, t in enumerate(reference):
        if t < start:
            streak = []
            continue
        j = paired.get(i)
        expected = tempo_at(fixture, t)
        bpm = None if j is None else events[j]["bpm"]
        if bpm is not None and expected > 0 and abs(bpm - expected) / expected <= 0.03:
            streak.append((i,j))
            if len(streak) == 4:
                first_i, _ = streak[0]
                return {
                    "retrospective_first_source_seconds": reference[first_i],
                    "retrospective_fourth_source_seconds": t,
                    "fourth_source_seconds_after_interval_start": t - start,
                    "adjacent_reference_indices": [a for a, _ in streak],
                    "available_after_source_seconds": events[j]["available_after_source_seconds"],
                    "semantics": "Whole-source offline alignment; not online causal warmup/recovery",
                }
        else:
            streak = []
    return None


def finite(value):
    if isinstance(value, bool) or not isinstance(value, (int,float)) or not math.isfinite(value):
        raise ValueError("nonfinite or nonnumeric evidence")


def main(base):
    recipe_bytes = (base / "evaluation-recipe-02.json").read_bytes()
    recipe = json.loads(recipe_bytes)
    recipe_hash = hashlib.sha256(recipe_bytes).hexdigest()
    fixtures = {f["id"]: f for f in recipe["fixtures"]}
    tolerance = recipe["scoring"]["tolerance_seconds"]
    paths = sorted((base / "raw-02").glob("*.json"))
    if len(paths) != 78:
        raise ValueError("incomplete arm set")
    results, pins, seen = [], [], set()
    for path in paths:
        raw_bytes = path.read_bytes()
        raw = json.loads(raw_bytes)
        key = (raw["fixture"],raw["sample_rate_hz"],raw["projection"])
        if key in seen or key[0] not in fixtures or key[1] not in (44100,48000) or key[2] not in recipe["projections"]:
            raise ValueError("unexpected or duplicate case")
        seen.add(key)
        if raw["recipe_sha256"] != recipe_hash or len(raw_bytes) > 1048576 or len(raw["raw_beats"]) > 4096:
            raise ValueError("unbound or oversized evidence")
        fixture, events, reference = fixtures[key[0]], raw["events"], raw["reference_seconds"]
        old_name = "channel" if key[2] == "higher-energy-channel" else "mean"
        old = json.loads((base.parent / "raw-01" / f"{key[0]}-{key[1]}-{old_name}.json").read_text())
        if any(raw[n] != old[n] for n in ("stereo_pcm_sha256","frames","reference_seconds","reference_bpm")):
            raise ValueError("generated source/reference no longer matches sealed baseline")
        if key[2] != "independent-channel-df-mean" and raw["projected_pcm_sha256"] != old["projected_pcm_sha256"]:
            raise ValueError("projection PCM no longer matches sealed baseline")
        expected_step = 557 if key[1] == 48000 else 512
        if raw["step_frames"] != expected_step or raw["window_frames"] != 1024:
            raise ValueError("native geometry changed")
        for e in events:
            for n in ("frame","seconds","available_after_source_frame","available_after_source_seconds"):
                finite(e[n])
            if not 0 <= e["frame"] < raw["frames"] or e["seconds"] != e["frame"]/key[1]:
                raise ValueError("invalid source event accepted")
            if e["available_after_source_frame"] != raw["frames"] or e["available_after_source_seconds"] != raw["frames"]/key[1]:
                raise ValueError("offline EOF availability changed")
            if e["raw_confidence"] is not None:
                raise ValueError("invented confidence")
            index = e["raw_index"]
            if isinstance(index,bool) or int(index) != index or not 0 <= index < len(raw["raw_beats"]):
                raise ValueError("unbound raw beat index")
            index = int(index)
            if raw["raw_beats"][index]["frame"] != e["frame"] or not raw["raw_beats"][index]["valid"]:
                raise ValueError("event differs from native raw beat")
            if index == 0 or not raw["raw_beats"][index-1]["valid"]:
                if e["bpm"] is not None or e["period_samples"] is not None:
                    raise ValueError("invented tempo without an immediately preceding valid raw beat")
            else:
                finite(e["bpm"]); finite(e["period_samples"])
                delta = e["frame"] - raw["raw_beats"][index-1]["frame"]
                if delta <= 0 or e["period_samples"] != delta or abs(e["bpm"] - 60*key[1]/delta) > 1e-10:
                    raise ValueError("derived tempo is not the preceding raw-beat interval")
        if any(a["frame"] >= b["frame"] for a,b in zip(events,events[1:])):
            raise ValueError("nonincreasing accepted events")
        full, pairs = metrics(reference,events,tolerance)
        late_events = [e for e in events if e["seconds"] >= 12]
        late, _ = metrics([t for t in reference if t >= 12],late_events,tolerance)
        bpm_errors = tempo_errors(fixture,late_events)
        median_bpm = statistics.median(bpm_errors) if bpm_errors else None
        clean = (not raw["invalid_events"] and late["f1"] >= 0.90 and
                 late["matched_error_median_seconds"] is not None and late["matched_error_median_seconds"] <= 0.035 and
                 late["matched_error_p95_seconds"] is not None and late["matched_error_p95_seconds"] <= 0.070 and
                 median_bpm is not None and median_bpm <= 0.03)
        signed = [events[j]["seconds"] - reference[i] for i,j in pairs]
        result = {
            "fixture":key[0],"sample_rate_hz":key[1],"projection":key[2],
            "input_identity_matches_sealed_aubio_source":True,
            "selected_channel":raw["selected_channel"],"channel_energy":raw["channel_energy"],
            "raw_returned_beat_count":len(raw["raw_beats"]),"invalid_events":raw["invalid_events"],
            "full":full,"post_12_seconds":late,
            "matched_signed_error_median_seconds":statistics.median(signed) if signed else None,
            "matched_signed_error_range_seconds":[min(signed),max(signed)] if signed else None,
            "post_12_known_interval_bpm_count":len(bpm_errors),
            "post_12_unknown_interval_bpm_count":sum(e["bpm"] is None for e in late_events),
            "post_12_local_bpm_median_relative_error":median_bpm,
            "post_12_local_bpm_p95_relative_error":quantile(bpm_errors,0.95),
            "confidence":"Unknown",
            "first_source_alignment":source_alignment(fixture,reference,events,pairs),
            "available_after_source_seconds":raw["frames"]/key[1],
            "clean_fixed_screen_pass":clean if key[0] in recipe["scoring"]["clean_fixed_candidate_screen"]["fixtures"] else None,
            "numeric_metric_scope":"Valid source events only; any invalid native output independently fails the arm",
        }
        if key[0] in ("silence","steady-tone"):
            result["nonbeat_screen_pass"] = not raw["raw_beats"] and not raw["invalid_events"]
        if "change_seconds" in fixture:
            aligned = source_alignment(fixture,reference,events,pairs,fixture["change_seconds"])
            result["abrupt_source_alignment"] = aligned
            result["abrupt_screen_pass"] = bool(not raw["invalid_events"] and aligned and aligned["fourth_source_seconds_after_interval_start"] <= 12)
        if "ramp_start_seconds" in fixture:
            fraction = sum(e <= 0.05 for e in bpm_errors)/len(bpm_errors) if bpm_errors else 0.0
            result["ramp_fraction_local_bpm_within_5_percent"] = fraction
            result["ramp_screen_pass"] = bool(not raw["invalid_events"] and bpm_errors and fraction >= 0.7)
        if key[0] == "quiet-percussion-louder-tone":
            result["projection_stress_screen_pass"] = clean
        if key[0] == "half-double-ambiguity":
            result["half_grid"], _ = metrics(raw["half_grid_seconds"],events,tolerance)
            result["double_grid"], _ = metrics(raw["double_grid_seconds"],events,tolerance)
        results.append(result)
        pins.append({"path":str(path.relative_to(base)),"bytes":len(raw_bytes),"sha256":hashlib.sha256(raw_bytes).hexdigest()})
    output = {"status":"generated_only_offline_QM_feasibility_results","qualified":False,
              "recipe_sha256":recipe_hash,"scoring_source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "arms":len(results),"cases":results,"raw_source_pins":pins,
              "limits":["Whole-track offline source alignment; no causal online recovery comparison.",
                        "No native confidence, downbeat, phrase, key or real-music acceptance.",
                        "No hardware, audio output, latency, cancellation deadline or M2 qualification."]}
    target = base / "scores-02.json"
    if target.exists():
        raise ValueError("preserve prior score results")
    target.write_text(json.dumps(output,indent=2,allow_nan=False)+"\n")
    print(json.dumps({"path":str(target),"bytes":target.stat().st_size,"sha256":hashlib.sha256(target.read_bytes()).hexdigest(),"arms":len(results)}))


if __name__ == "__main__":
    main(Path(sys.argv[1]))


