"""Fixed ARTBeaT24 preparation/evaluation/scoring. Dry unless an explicit stage is given."""
import argparse
from decimal import Decimal, localcontext
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import resource
import stat
import statistics
import sys
import time
import wave
import zipfile

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
E = BASE.parent
IDS = tuple(i for i in range(1, 26) if i != 21)
CAP = 268435456
CHECKPOINT_SHA = "8c328b45f59d8dd3dff219253ff6a8d6482be57d0133a29140e2febbf8eb8331"
SETUP = E / "beat-this-assessment-03/private-setup-03"


def require(value, message):
    if not value:
        raise ValueError(message)


def file_pin(path, limit=1048576):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= limit, "Unsafe pinned file")
        digest = hashlib.sha256()
        count = 0
        while count < before.st_size:
            block = os.read(fd, min(1048576, before.st_size - count))
            require(bool(block), "Truncated pinned file")
            digest.update(block)
            count += len(block)
        signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        require(signature(before) == signature(os.fstat(fd)) == signature(path.lstat()), "Pinned file changed")
        return {"path": str(path), "bytes": count, "sha256": digest.hexdigest()}
    finally:
        os.close(fd)


def read_pin(pin):
    path = Path(pin["path"])
    require(type(pin.get("bytes")) is int and 0 < pin["bytes"] <= 83886080, "Pinned byte bound")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_size == pin["bytes"], "Frozen file geometry differs")
        data = bytearray()
        while len(data) < before.st_size:
            block = os.read(fd, min(1048576, before.st_size - len(data)))
            require(bool(block), "Pinned read truncated")
            data.extend(block)
        signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        require(signature(before) == signature(os.fstat(fd)) == signature(path.lstat()) and
                hashlib.sha256(data).hexdigest() == pin["sha256"], "Frozen content changed")
        return bytes(data)
    finally:
        os.close(fd)


def load_json(path, limit=1048576):
    pin = file_pin(path, limit)
    return json.loads(read_pin(pin), parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s))), pin


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def directory_bytes():
    total = count = directories = 0
    for parent, dirs, files in os.walk(BASE, followlinks=False):
        info = Path(parent).lstat()
        require(stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) == 0o700,
                "Unsafe private directory")
        directories += 1
        require(directories <= 32, "Directory count exceeded")
        for name in dirs:
            require(not (Path(parent) / name).is_symlink(), "Directory symlink")
        for name in files:
            info = (Path(parent) / name).lstat()
            require(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and info.st_nlink == 1,
                    "Unsafe private file")
            total += info.st_size
            count += 1
            require(total <= CAP and count <= 256, "Inclusive directory bound exceeded")
    return total


def write_json(path, value):
    data = (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()
    require(len(data) <= 1048576 and directory_bytes() + len(data) <= CAP, "Output bound exceeded")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(data)


def recipe():
    value, pin = load_json(BASE / "evaluation-recipe-15.json", 131072)
    require(value["status"] == "frozen_pending_separate_stage_authorizations" and value["ids"] == list(IDS)
            and value["qualified"] is False and value["checkpoint_sha256"] == CHECKPOINT_SHA,
            "Unfrozen challenge")
    for row in value["source_pins"]:
        require(file_pin(Path(row["path"]), max(1048576, row["bytes"])) == row, "Source pin changed")
    directory_bytes()
    return value, pin


def authorize(stage, recipe_pin):
    value, pin = load_json(BASE / ("root-" + stage + "-authorization-15.json"), 65536)
    require(value.get("status") == "authorized_once_artbeat_" + stage and
            value.get("recipe_sha256") == recipe_pin["sha256"] and
            value.get("challenge_sha256") == file_pin(Path(__file__))["sha256"], "No exact stage authorization")
    if stage == "model":
        require(value.get("model_forward") is True, "Model forward not authorized")
    return value, pin


def input_metadata(value):
    helper = module(Path(value["admission_helper"]), "artbeat_admission15")
    headers = json.loads(read_pin(value["header_pin"]))["tracks"]
    by_id = {row["id"]: row for row in headers}
    rows = []
    require(len(headers) == 25 and set(by_id) == set(range(1, 26)), "Original header set differs")
    for source in value["tracks"]:
        require(source["id"] in IDS, "Excluded/unexpected source")
        header = by_id[source["id"]]
        admitted = helper.admit_artbeat_track(header, read_pin(source["CSV_pin"]).decode("utf-8"))
        require(header["member"] == source["member"] and admitted["frames"] == source["frames"], "Source lineage differs")
        rows.append((source, header, admitted))
    require([row[0]["id"] for row in rows] == list(IDS), "Fixed24 source order differs")
    return helper, rows


def pcm16_float_bytes(pcm, frames):
    import numpy as np

    require(type(frames) is int and 0 < frames <= 24 * 44100 and len(pcm) == frames * 4, "PCM16 extent differs")
    stereo = np.frombuffer(pcm, dtype="<i2").reshape(frames, 2).astype("<f4") / np.float32(32768)
    require(np.isfinite(stereo).all(), "Nonfinite converted PCM")
    return np.asarray(stereo, dtype="<f4").tobytes()


def returned_state(helper, streams, frames):
    errors = []
    require(type(streams) is dict and set(streams) == {"beats", "downbeats"}, "Raw streams differ")
    for name, times in streams.items():
        require(type(times) is list and len(times) <= 4096 and all(type(t) in (int, float) and math.isfinite(t) for t in times),
                "Nonfinite/oversized raw output")
        try:
            helper.source_intervals(times, frames, 44100)
        except ValueError as error:
            errors.append(name + ":" + str(error))
    subset = [t for t in streams["downbeats"] if t not in set(streams["beats"])]
    if subset:
        errors.append("downbeat_not_in_beats")
    intervals = helper.source_intervals(streams["beats"], frames, 44100) if not errors else []
    status = "Failed" if errors else "Unknown" if len(streams["beats"]) < 2 else "EstimatedIntervalMap"
    return errors, subset, intervals, status


def verified_archive(pin):
    # Decode the verified bytes, rather than reopening a mutable archive pathname.
    return zipfile.ZipFile(io.BytesIO(read_pin(pin)))


def prepare(value, recipe_pin):
    authorize("prepare", recipe_pin)

    began = time.monotonic()
    deadline = began + 80
    helper, rows = input_metadata(value)
    archive = Path(value["archive_pin"]["path"])
    require(file_pin(archive, 83886080) == value["archive_pin"], "Archive changed")
    prepared = BASE / "prepared-15"
    prepared.mkdir(mode=0o700)
    outputs = []
    with verified_archive(value["archive_pin"]) as z:
        infos = {info.filename: info for info in z.infolist()}
        require(len(infos) == 91, "Archive central directory changed")
        for source, header, admitted in rows:
            require(time.monotonic() < deadline, "Original preparation deadline exhausted")
            info = infos[source["member"]]
            require(info.file_size == header["ZIP_uncompressed_bytes"] and info.file_size <= 5 * 1024**2,
                    "WAV member bound differs")
            raw = z.read(info)  # Full bounded read verifies this member's CRC.
            require(len(raw) == info.file_size and
                    hashlib.sha256(raw[:header["header_bytes_read"]]).hexdigest() == header["header_sha256"],
                    "WAV header identity differs")
            with wave.open(io.BytesIO(raw), "rb") as wavefile:
                require((wavefile.getnchannels(), wavefile.getsampwidth(), wavefile.getframerate(), wavefile.getnframes()) ==
                        (2, 2, 44100, admitted["frames"]) and wavefile.getcomptype() == "NONE", "WAV geometry differs")
                pcm = wavefile.readframes(admitted["frames"] + 1)
            data = pcm16_float_bytes(pcm, admitted["frames"])
            require(len(data) == admitted["frames"] * 8 and directory_bytes() + len(data) <= CAP, "Prepared byte cap")
            path = prepared / f"{source['id']:02d}.f32"
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(fd, "wb") as stream:
                stream.write(data)
            outputs.append({"id": source["id"], "frames": admitted["frames"], "sample_rate_hz": 44100, "channels": 2,
                            "source_WAV_sha256": hashlib.sha256(raw).hexdigest(), "CSV_pin": source["CSV_pin"],
                            "reference_seconds_text": admitted["reference_seconds_text"], "pcm": file_pin(path, 9 * 1024**2)})
    require(time.monotonic() < deadline and file_pin(archive, 83886080) == value["archive_pin"], "Source/deadline changed")
    write_json(BASE / "prepared-manifest-15.json", {"status": "complete24_no_model", "qualified": False,
               "recipe_sha256": recipe_pin["sha256"], "archive_pin": value["archive_pin"], "tracks": outputs,
               "elapsed_seconds": time.monotonic() - began, "all_member_CRCs_verified": True})


def evaluate(value, recipe_pin):
    authorization, _ = authorize("model", recipe_pin)
    manifest, manifest_pin = load_json(BASE / "prepared-manifest-15.json")
    require(authorization.get("prepared_manifest_sha256") == manifest_pin["sha256"] and
            manifest.get("status") == "complete24_no_model" and manifest.get("recipe_sha256") == recipe_pin["sha256"] and
            manifest.get("archive_pin") == value["archive_pin"] and manifest.get("all_member_CRCs_verified") is True,
            "Prepared inputs not separately authorized")
    import importlib.metadata
    import numpy as np
    import torch

    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    require(torch.__version__ == "2.11.0+cpu" and torch.version.cuda is None, "Pinned CPU runtime differs")
    lock = json.loads((SETUP / "wheel-lock-03.json").read_text())
    require(all(importlib.metadata.version(row["name"]) == row["version"] for row in lock["wheels"]), "Wheel versions differ")
    helper, metadata = input_metadata(value)
    frontend04 = module(E / "beat-this-linear-mel-04/evaluate-04.py", "artbeat_frontend04")
    sys.path.insert(0, str(E / "beat-this-assessment-03/source"))
    import beat_this.inference as upstream
    from beat_this.model.postprocessor import Postprocessor

    checkpoint = SETUP / "downloads/final0.ckpt"
    def forbidden(*_args, **_kwargs):
        raise ValueError("Network checkpoint loading forbidden")
    torch.hub.load_state_dict_from_url = forbidden
    def safe_checkpoint(path, device="cpu"):
        require(str(path) == str(checkpoint) and str(device) == "cpu", "Unexpected checkpoint")
        fd = os.open(checkpoint, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, "rb") as stream:
            before = os.fstat(stream.fileno())
            require(stat.S_ISREG(before.st_mode) and before.st_size == 81058141 and
                    hashlib.file_digest(stream, "sha256").hexdigest() == CHECKPOINT_SHA, "Checkpoint content differs")
            stream.seek(0)
            result = torch.load(stream, map_location="cpu", weights_only=True)
            require(frontend04.identity(before) == frontend04.identity(os.fstat(stream.fileno())) ==
                    frontend04.identity(checkpoint.lstat()), "Checkpoint changed")
        require(isinstance(result, dict) and isinstance(result.get("hyper_parameters"), dict) and
                isinstance(result.get("state_dict"), dict), "Checkpoint structure differs")
        require(all(isinstance(t, torch.Tensor) and t.device.type == "cpu" and torch.isfinite(t).all().item()
                    for t in result["state_dict"].values()), "Checkpoint tensor differs")
        return result
    upstream.load_checkpoint = safe_checkpoint
    frontend = upstream.Audio2Frames(str(checkpoint), device="cpu", float16=False)
    postprocessor = Postprocessor(type="minimal", fps=50)
    require(not frontend.model.training and next(frontend.model.parameters()).dtype == torch.float32, "Model state differs")
    require([t["id"] for t in manifest["tracks"]] == list(IDS), "Prepared24 order differs")
    output = BASE / "raw-15"
    output.mkdir(mode=0o700)
    for prepared, (source, _header, admitted) in zip(manifest["tracks"], metadata):
        began = time.monotonic()
        require(prepared["id"] == source["id"] and prepared["frames"] == source["frames"] and
                prepared["sample_rate_hz"] == 44100 and prepared["channels"] == 2 and
                prepared["reference_seconds_text"] == admitted["reference_seconds_text"] and
                prepared["CSV_pin"] == source["CSV_pin"] and prepared["pcm"]["bytes"] == source["frames"] * 8,
                "Prepared source/reference differs")
        stereo = np.frombuffer(read_pin(prepared["pcm"]), dtype="<f4").reshape(prepared["frames"], 2)
        require(np.isfinite(stereo).all(), "Nonfinite source")
        spect, context = frontend04.linear_mel_channel_mean(stereo, 44100, frontend)
        require(spect.ndim == 2 and spect.shape[1] == 128 and torch.isfinite(spect).all().item(), "Invalid spectrogram")
        mask = helper.source_duration_mask(source["frames"], 44100, context["channel_resampled_frames"], len(spect))
        _chunks, starts = upstream.split_piece(spect, 1500, border_size=6, avoid_short_end=True)
        beat, downbeat = frontend.spect2frames(spect)
        require(all(x.ndim == 1 and len(x) == len(mask) and torch.isfinite(x).all().item() for x in (beat, downbeat)),
                "Nonfinite/invalid logits")
        beats, downbeats = postprocessor(beat, downbeat, padding_mask=torch.tensor(mask, dtype=torch.bool))
        streams = {"beats": [float(x) for x in beats], "downbeats": [float(x) for x in downbeats]}
        require(all(len(x) <= 4096 and all(math.isfinite(t) for t in x) for x in streams.values()), "Invalid raw output")
        errors, subset, intervals, status = returned_state(helper, streams, source["frames"])
        raw = {"id": source["id"], "frames": source["frames"], "sample_rate_hz": 44100, "qualified": False,
               "recipe_sha256": recipe_pin["sha256"], "prepared_manifest_sha256": manifest_pin["sha256"],
               "checkpoint_sha256": CHECKPOINT_SHA, "pcm": prepared["pcm"], "CSV_pin": source["CSV_pin"],
               "reference_seconds_text": admitted["reference_seconds_text"], "raw_beats": streams["beats"],
               "raw_downbeats": streams["downbeats"], "invalid_or_subset_errors": errors, "downbeats_not_in_beats": subset,
               "status": status, "intervals": intervals, "beat_logits": beat.tolist(), "downbeat_logits": downbeat.tolist(),
               "source_mask": list(mask), "frontend_context": context, "spectrogram_shape": list(spect.shape),
               "spectrogram_sha256": hashlib.sha256(spect.numpy().tobytes()).hexdigest(), "chunk_starts": starts.tolist(),
               "confidence": None, "downbeat_correctness": "Unknown", "phrase_status": "Unknown", "key_status": "Unknown",
               "available_after_source_seconds": source["frames"] / 44100, "inference_seconds": time.monotonic() - began,
               "logits_semantics": "Uncalibrated raw logits; no acoustic beat-presence confidence"}
        write_json(output / f"{source['id']:02d}.json", raw)
        print(json.dumps({"id": source["id"], "status": status, "beats": len(beats), "seconds": raw["inference_seconds"]}), flush=True)


def item_metrics(common, admitted, beats, intervals, errors):
    valid = not errors
    known, signed, matched = [], [], []
    if valid:
        reference = [float(t) for t in admitted["reference_seconds"]]
        events = [{"seconds": t} for t in beats]
        full, pairs = common.metrics(reference, events, 0.070)
        for i, j in pairs:
            error = beats[j] - reference[i]
            signed.append(error)
            matched.append({"reference_index": i, "returned_index": j,
                            "reference_seconds_text": admitted["reference_seconds_text"][i],
                            "returned_seconds": beats[j], "signed_error_seconds": error})
            # Later matched events use the immediately prior returned beat, not an oracle replacement.
            if i and j:
                with localcontext() as context:
                    context.prec = 80
                    expected = Decimal(60) / (admitted["reference_seconds"][i] - admitted["reference_seconds"][i - 1])
                    known.append(abs(intervals[j - 1]["bpm"] - float(expected)) / float(expected))
    else:
        # Ordered matching has no defined interpretation for invalid raw streams.
        full = {"status": "Unavailable", "reason": "invalid_or_subset_returned_stream"}
    median = statistics.median(known) if known else None
    accurate = bool(valid and len(beats) >= 2 and full["f1"] >= .90 and
                    full["matched_error_median_seconds"] is not None and full["matched_error_median_seconds"] <= .035 and
                    full["matched_error_p95_seconds"] is not None and full["matched_error_p95_seconds"] <= .070 and
                    median is not None and median <= .03)
    return {"full": full, "matched_timing_status": "Available" if valid else "Unavailable",
            "matched_signed_error_median_seconds": statistics.median(signed) if signed else None,
            "matched_signed_error_range_seconds": [min(signed), max(signed)] if signed else None,
            "matched_timing_rows": matched, "known_adjacent_interval_count": len(known),
            "unknown_or_unmatched_interval_count": max(0, len(beats) - 1 - len(known)),
            "median_relative_adjacent_BPM_error": median, "per_item_accuracy_screen": accurate,
            "raw_failure_retained": not valid}


def score(value, recipe_pin):
    common = module(E / "qm-evaluation-02/score.py", "artbeat_metrics15")
    helper, metadata = input_metadata(value)
    manifest, manifest_pin = load_json(BASE / "prepared-manifest-15.json")
    execution, execution_pin = load_json(BASE / "execution-15.json")
    require(execution.get("recipe_sha256") == recipe_pin["sha256"] and
            execution.get("prepared_manifest_sha256") == manifest_pin["sha256"], "Execution input lineage differs")
    prepared_by_id = {row["id"]: row for row in manifest["tracks"]}
    require(len(manifest["tracks"]) == len(prepared_by_id) == 24 and list(prepared_by_id) == list(IDS), "Prepared source set differs")
    operational = (execution.get("status") == "completed_artbeat24_challenge_unqualified" and execution.get("returncode") == 0
                   and execution.get("completed_case_files") == 24 and execution.get("samples", 0) > 0
                   and execution.get("owned_child_reaped") is True and execution.get("owned_process_group_gone") is True
                   and "stop_reason" not in execution and "error" not in execution)
    require({x.name for x in (BASE / "raw-15").glob("*.json")} == {f"{i:02d}.json" for i in IDS}, "Raw case set incomplete")
    results = []
    for source, _header, admitted in metadata:
        raw, raw_pin = load_json(BASE / "raw-15" / f"{source['id']:02d}.json")
        require(raw["id"] == source["id"] and raw["frames"] == source["frames"] and raw["sample_rate_hz"] == 44100
                and raw["qualified"] is False and raw["recipe_sha256"] == recipe_pin["sha256"] and
                raw["prepared_manifest_sha256"] == manifest_pin["sha256"] and raw["checkpoint_sha256"] == CHECKPOINT_SHA and
                raw["CSV_pin"] == source["CSV_pin"] and raw["reference_seconds_text"] == admitted["reference_seconds_text"],
                "Raw identity differs")
        require(raw["pcm"] == prepared_by_id[source["id"]]["pcm"], "Raw PCM source differs")
        # Raw failures remain intact and never enter the ordered matcher.
        errors, subset, intervals, status = returned_state(helper,
            {"beats": raw["raw_beats"], "downbeats": raw["raw_downbeats"]}, source["frames"])
        require(raw["invalid_or_subset_errors"] == errors and raw["downbeats_not_in_beats"] == subset and
                raw["intervals"] == intervals and raw["status"] == status, "Raw validity/intervals differ")
        mask = helper.source_duration_mask(source["frames"], 44100,
            raw["frontend_context"]["channel_resampled_frames"], raw["spectrogram_shape"][0])
        require(raw["source_mask"] == list(mask) and raw["spectrogram_shape"][1] == 128 and
                all(type(x) is list and len(x) == len(mask) and all(type(t) in (int, float) and math.isfinite(t) for t in x)
                    for x in (raw["beat_logits"], raw["downbeat_logits"])), "Raw frontend/logit geometry differs")
        metrics = item_metrics(common, admitted, raw["raw_beats"], intervals, errors)
        results.append({"id": source["id"], "raw_pin": raw_pin, "status": raw["status"], **metrics,
                        "confidence": "Unknown", "downbeat_accuracy": "Not available"})
    write_json(BASE / "scores-15.json", {"status": "scored24_untuned_challenge_unqualified", "qualified": False,
               "recipe_sha256": recipe_pin["sha256"], "execution_pin": execution_pin, "operational_pass": operational,
               "cases": results, "items_passing_numeric_screen": sum(x["per_item_accuracy_screen"] for x in results),
               "whole_beat_gate_pass": False, "negative_or_calibration_screen": "Unavailable",
               "scope": "No tuned parameters,proven training independence,negative/downbeat truth or musical acceptance."})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("prepare", "evaluate", "score"))
    args = parser.parse_args()
    if args.stage is None:
        print("Unarmed design: no audio read,checkpoint/model import or forward without a separately authorized stage.")
        return
    value, recipe_pin = recipe()
    {"prepare": prepare, "evaluate": evaluate, "score": score}[args.stage](value, recipe_pin)


if __name__ == "__main__":
    main()
