"""Import/identity check of the frozen CPU runtime on both hosts; no model."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,time,os
B=Path(__file__).resolve().parent
m=json.loads((B/'runtime-manifest-01.json').read_text())
setup=Path(m['source_venv']).parent.parent
localworker=B.parent/'m2-current-player-hour-01/source-build-01/laptop/source/tools/timing/analyze_bpm.py'
CHECK=r'''
from pathlib import Path
import ast,hashlib,importlib.metadata as meta,json,sys
source,model,worker=map(Path,sys.argv[1:]);raw=worker.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='e76b8ab903aebc76a592ac262b1dd3c7602cdea0606610e866cca31156d753b5'
values={}
for node in ast.parse(raw).body:
 if isinstance(node,ast.Assign)and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in('SOURCE_PINS','DEPENDENCIES','MODEL_BYTES','MODEL_SHA256'):
  values[node.targets[0].id]=ast.literal_eval(node.value)
for name,(size,digest)in values['SOURCE_PINS'].items():
 p=source/name;assert p.stat().st_size==size and hashlib.sha256(p.read_bytes()).hexdigest()==digest
assert(source/'LICENSE').is_file() and model.stat().st_size==values['MODEL_BYTES']
with model.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==values['MODEL_SHA256']
versions={name:meta.version(name)for name in values['DEPENDENCIES']}
assert versions==values['DEPENDENCIES']
import torch,torchaudio,soxr,numpy,einops
assert torch.__version__=='2.11.0+cpu' and torch.version.cuda is None
print(json.dumps(dict(passed=True,python=sys.version,versions=versions,cpu_only=True,model_loaded=False,inference_started=False,source_pins_verified=6,model_hash_verified=True)))
'''
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','python3 -']
REMOTE='CHECK='+repr(CHECK)+'\nVENV='+repr(m['source_venv'])+'\nBASEPY='+repr(m['source_base_python'])+'\n'+r'''
from pathlib import Path
import json,subprocess
b=Path('/srv/conflux-tests/work/brid-analysis-20261029-01/runtime-01')
assets=b/'assets';name='conflux-brid-runtime-import-20261029-01';label='brid-runtime-import-20261029-01'
docker=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
assert json.loads(subprocess.check_output(docker+['info','--format','{{json .DockerRootDir}}'],timeout=10))=='/srv/conflux-tests/docker-data'
assert subprocess.run(docker+['inspect',name],capture_output=True,timeout=10).returncode!=0
cmd=docker+['run','--rm','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--memory=2g','--cpus=2','--pids-limit=256','--label','org.kyaulabs.conflux.run='+label,'--tmpfs=/tmp:rw,nosuid,nodev,size=128m,mode=1777','--mount','type=bind,src='+str(assets)+',dst=/assets,readonly','--mount','type=bind,src='+str(assets/'venv')+',dst='+VENV+',readonly','--mount','type=bind,src='+str(assets/'base')+',dst='+BASEPY+',readonly',image,'timeout','--signal=TERM','--kill-after=5s','40s',VENV+'/bin/python','-I','-B','-c',CHECK,'/assets/source','/assets/model/final0.ckpt','/assets/worker/analyze_bpm.py']
result={}
try:
 r=subprocess.run(cmd,stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=55)
 result=dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr[-4000:])
 if r.returncode==0:result['check']=json.loads(r.stdout)
finally:
 found=subprocess.run(docker+['inspect',name],capture_output=True,text=True,timeout=10)
 if found.returncode==0:
  row=json.loads(found.stdout)[0];assert row['Image']==image and row['Config']['Labels'].get('org.kyaulabs.conflux.run')==label
  subprocess.run(docker+['rm','-f',row['Id']],check=True,capture_output=True,timeout=15)
 result['container_absent']=subprocess.run(docker+['inspect',name],capture_output=True,timeout=10).returncode!=0
 with(b/'runtime-import-01.json').open('x')as f:json.dump(result,f,indent=2)
print(json.dumps(result))
'''
def run(host):
 start=time.monotonic()
 env=os.environ.copy();env.update(OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
 if host=='laptop':
  cmd=[m['source_venv']+'/bin/python','-I','-B','-c',CHECK,str(setup/'source'),str(setup/'private-setup-03/downloads/final0.ckpt'),str(localworker)];text=None
 else:cmd=SSH;text=REMOTE
 r=subprocess.run(cmd,input=text,capture_output=True,text=True,env=env,timeout=90)
 out=dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr[-5000:],seconds=time.monotonic()-start)
 if r.returncode==0:out['result']=json.loads(r.stdout)
 (B/(host+'-runtime-check-01.json')).write_text(json.dumps(out,indent=2)+'\n')
 return host,out
with ThreadPoolExecutor(max_workers=2)as pool:result=dict(pool.map(run,('laptop','apollo')))
print(json.dumps({h:dict(exit=r['exit'],seconds=r['seconds'],result=r.get('result'),stderr=r['stderr'])for h,r in result.items()}))
assert result['laptop']['exit']==0 and result['laptop']['result']['passed']
assert result['apollo']['exit']==0 and result['apollo']['result']['exit']==0 and result['apollo']['result']['check']['passed'] and result['apollo']['result']['container_absent']
assert result['laptop']['result']['versions']==result['apollo']['result']['check']['versions']
(B/'runtime-paired-check-01.json').write_text(json.dumps(dict(passed=True,hosts=result,inference_started=False),indent=2)+'\n')
