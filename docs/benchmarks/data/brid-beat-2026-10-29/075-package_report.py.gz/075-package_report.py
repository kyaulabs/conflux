"""Package closed CPU correctness evidence; no audio, weights or binaries."""
from pathlib import Path
import gzip,hashlib,json
B=Path(__file__).resolve().parent;C=B/'corpus-02';ROOT=B.parent.parent
s=json.loads((C/'scores.json').read_text());closed=json.loads((C/'closed-pair.json').read_text())
assert closed['all_owners_retired']and closed['all_containers_retired']and s['qualified']is False
stage=B/'report-stage-01';stage.mkdir(mode=0o700);data=stage/'data';data.mkdir();decoded=stage/'decoded';decoded.mkdir()
choices=[];suffixes={'.py','.json','.jsonl','.log','.cpp','.txt'}
def add_tree(prefix,root):
 for p in sorted(root.rglob('*')):
  if p.is_file()and not p.is_symlink()and(p.suffix in suffixes or p.name=='CMakeLists.txt')and not{'__pycache__','native','media-01','cache','tmp'}.intersection(p.relative_to(root).parts):choices.append((prefix+'/'+p.relative_to(root).as_posix(),p))
for p in sorted(B.iterdir()):
 if p.is_file()and not p.is_symlink()and p.suffix in suffixes and p.name!='receive_assets.py':choices.append((p.name,p))
for name in('acquisition-01','probe-build-01','corpus-01','corpus-02'):add_tree(name,B/name)
ref=ROOT/'build/m2-brid-reference-01'
for name in('record-14051323.json','annotation-members-01.json','metadata-acquisition-01.json','annotation-shape-01.json','prospective-admission-01.json','audio-index-01.json'):
 choices.append(('references/'+name,ref/name))
old=json.loads((ROOT/'build/m2-analysis-qualification-01/beat-this-final1-01/evaluation-01/plan.json').read_text())
for role,pin in old['helpers'].items():choices.append(('scoring-helpers/'+role+'.py',Path(pin['path'])))
members=[];aliases=[];seen={};total=0
for name,p in sorted(choices):
 raw=p.read_bytes();raw.decode('utf8');assert len(raw)<=16*1024**2;total+=len(raw);assert total<96*1024**2
 digest=hashlib.sha256(raw).hexdigest();key=(len(raw),digest)
 if key in seen:aliases.append(dict(source=name,member=seen[key],bytes=len(raw),sha256=digest));continue
 member=f'{len(members):03}-'+name.replace('/','--')+'.gz';encoded=gzip.compress(raw,compresslevel=9,mtime=0);assert gzip.decompress(encoded)==raw
 (data/member).write_bytes(encoded);(decoded/member[:-3]).write_bytes(raw);seen[key]=member
 members.append(dict(source=name,member=member,bytes=len(raw),sha256=digest,gzip_bytes=len(encoded),gzip_sha256=hashlib.sha256(encoded).hexdigest()))
manifest=dict(schema=1,members=members,aliases=aliases,unique_decoded_bytes=sum(r['bytes']for r in members),gzip_bytes=sum(r['gzip_bytes']for r in members),
 qualified=False,audio_models_binaries_and_caches_included=False,source_head='6e1623ff0261d3cc5200380cd8f1b15260bc57f4',
 omitted_generated_receiver=dict(path=str(B/'receive_assets.py'),bytes=(B/'receive_assets.py').stat().st_size,sha256=hashlib.sha256((B/'receive_assets.py').read_bytes()).hexdigest(),reason='Generated literal copy of the included runtime manifest and included stage_runtime.py receiver template.'))
(data/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
l=s['hosts']['laptop'];a=s['hosts']['apollo'];assert l['complete']and l['native_rows']==93 and a['operational_statuses']['Estimated']==55
report=f'''# BRID beat and downbeat diagnostic

The unchanged production Final0 analyzer passed the beat screen on **{l['beat_cases_passing']}/93** laptop recordings and the downbeat screen on **{l['downbeat_cases_passing']}/93**. Only **{l['both_cases_passing']}/93** passed both. This complementary percussion corpus does not qualify the musical-analysis gate. The retained ARTBeaT result remains **9/24**; no model, output, threshold, clock or automatic alignment policy changed.

| Observation | Laptop | Apollo CPU control |
| --- | ---: | ---: |
| Complete analyses | 93/93 | 55/93 |
| Beat numeric screens passed | {l['beat_cases_passing']}/93 | {a['beat_cases_passing']}/93 |
| Downbeat F1 screens passed | {l['downbeat_cases_passing']}/93 | {a['downbeat_cases_passing']}/93 |
| Both screens passed | {l['both_cases_passing']}/93 | {a['both_cases_passing']}/93 |
| Full-denominator beat micro F1 | {l['beat_micro']['F1']:.4f} | {a['beat_micro']['F1']:.4f} |
| Full-denominator downbeat micro F1 | {l['downbeat_micro']['F1']:.4f} | {a['downbeat_micro']['F1']:.4f} |

Both hosts started together. Apollo reached the unchanged 1,170-second native corpus limit: 55 analyses completed, the next source preparation was cancelled, and 37 sources remained unattempted. All 93 remain in its denominator; the micro scores treat failed or missing cases as having no accepted events. They do not establish worse accuracy on Apollo. All **55** shared prepared frame counts, PCM hashes and complete beat/downbeat maps match exactly across hosts. The laptop completed in 580.819 seconds. These CPU-only captures have no client, GPU, audio output or latency qualification.

The fixed selection contains every released ensemble recording GID0001–0093: 4,342 beat references and 2,205 position-1 references. [BRID's publisher record](https://zenodo.org/records/14051323) credits Lucas S. Maia, Pedro D. de Tomaz Júnior, Magdalena Fuentes, Martín Rocamora, Luiz W. P. Biscainho, Maurício V. M. da Costa and Sara Cohen under CC-BY-4.0. The maintained [BRID loader](https://github.com/mir-dataset-loaders/mirdata/blob/master/mirdata/datasets/brid.py) identifies the second annotation column as bar position. Its alternating labels 1/2 are retained; position 1 supplies the downbeat reference. They supply neither four-beat bars nor phrase truth. BRID is absent from the disclosed Beat This v1 training roots, but per-recording training independence remains Unknown.

Publisher HTTPS ranges admitted 469,990,540 bytes of complete WAVs after exact archive-directory, member-extent, CRC, source-geometry and reference-extent checks. New full-file SHA-256 identities were recorded and rechecked. The full audio archive's MD5 was not computed. The small annotation archive's published checksum was verified before selection. Ten range/admission checks passed locally and on Apollo. Every selected source remained in the denominator; no output-based exclusion or phase/octave fitting was allowed.

The private adapter calls the existing native AudioFile preparer and BpmAnalyzer against the frozen O2 libraries. It retains the actual stereo 48 kHz float32 extent and hash, then invokes the unchanged CPU float32 Final0 worker, source closure and fifteen dependency versions. No analysis-cache hit is allowed. Beat scoring reuses the retained ordered maximum-cardinality/minimum-error matcher: F1 ≥0.90 at 70 ms, matched median ≤35 ms, nearest-rank p95 ≤70 ms, and median known adjacent-tempo relative error ≤3%. Downbeat F1 ≥0.90 is checked separately at 70 ms. Seven scorer checks cover malformed output, wrong bar phase, missing cases, abstention and prohibited shift fitting. Confidence remains Unknown.

All 93 laptop cases met the matched-event median and p95 bounds. Eleven failed beat F1 and eight failed adjacent-tempo accuracy, with overlap. That does not establish the timing of unmatched beats. A separate post-output audit counted 649 four-event and 440 two-event gaps between estimated downbeats, against references with alternating two-position labels. This describes the failure; it does not justify repairing labels, imposing a meter or promoting automatic downbeat/phrase alignment.

The existing 113 analyzer regressions passed on each host before inference. An initial temporary checker then failed because it assumed 1,440,000 resampled frames for a 30-second input. Native preparation correctly reported 1,440,001; later verification checked every zero-PCM byte through its complete hash, with no repeated native tests. That failed checker is retained. The first paired corpus attempt stopped locally before inference on a relative manifest path; its Apollo peer was stopped and partial outputs retained. The correction resolves and rejects relative inputs, adds a regression for that failure, and verifies all 17,206 inputs in each actual execution context before the fresh pair. Selection, model and scoring rules stayed unchanged.

Both corpus owners, their original cgroups and the dedicated Apollo containers are retired. All inputs were reverified, temporary spools are empty and no protected service, thermal setting, power cap or installed environment changed. Verified reference WAVs remain in CONFLUX's private Apollo area; the local copies and generated zero-audio fixture were removed after hash checks, recovering 475,282,584 payload bytes. The [evidence manifest](data/brid-beat-2026-10-29/manifest.json) binds protocols, source identities, captures, scores, failed attempts and cleanup proofs. Audio, weights, executables and caches are excluded. The current-player hour, real GPU cancellation and the remaining M2/M3 acceptance gates remain open; the user deferred the prepared hour test.
'''
(stage/'report.md').write_text(report)
(stage/'verification.json').write_text(json.dumps(dict(passed=True,unique_members=len(members),aliases=len(aliases),decoded_bytes=manifest['unique_decoded_bytes'],gzip_bytes=manifest['gzip_bytes']),indent=2)+'\n')
print(json.dumps(dict(unique_members=len(members),aliases=len(aliases),decoded_bytes=manifest['unique_decoded_bytes'],gzip_bytes=manifest['gzip_bytes'])))
