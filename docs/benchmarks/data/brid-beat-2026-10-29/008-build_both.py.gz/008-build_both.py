"""Run the same small, CPU-only native probe build/checks on both hosts."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,signal,subprocess,time
B=Path(__file__).resolve().parent;P=B/'probe-build-01'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','python3 -']
REMOTE='/srv/conflux-tests/work/brid-analysis-20261029-01/probe-build-01'
files={n:(P/n).read_text()for n in('probe.cpp','CMakeLists.txt','build_probe.py')}
remote='FILES='+repr(files)+'\nBASE='+repr(REMOTE)+'\n'+r'''
from pathlib import Path
import hashlib,json,subprocess,time
b=Path(BASE);assert not b.exists();b.mkdir(mode=0o700)
for n,s in FILES.items():
 assert '/'not in n
 with(b/n).open('x')as f:f.write(s)
docker=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919';name='conflux-brid-cpu-probe-build-20261029-01';label='brid-cpu-probe-build-20261029-01'
assert json.loads(subprocess.check_output(docker+['info','--format','{{json .DockerRootDir}}'],timeout=10))=='/srv/conflux-tests/docker-data'
assert subprocess.run(docker+['inspect',name],capture_output=True,timeout=10).returncode!=0
frozen='/srv/conflux-tests/work/current-player-hour-20261029-01/source-build-01/output'
output=b/'output';output.mkdir(mode=0o700);inside='/work/build'
cmd=docker+['run','--rm','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--memory=2g','--cpus=2','--pids-limit=256','--label','org.kyaulabs.conflux.run='+label,'--tmpfs=/tmp:rw,nosuid,nodev,size=256m,mode=1777','--mount','type=bind,src='+str(b)+',dst=/inputs,readonly','--mount','type=bind,src='+str(output)+',dst=/work','--mount','type=bind,src='+frozen+'/source,dst=/frozen/source,readonly','--mount','type=bind,src='+frozen+'/native,dst=/frozen/lib,readonly',image,'timeout','--signal=TERM','--kill-after=10s','280s','python','-B','/inputs/build_probe.py','--base',inside,'--inputs','/inputs','--source','/frozen/source','--libdir','/frozen/lib']
record=dict(command=cmd,model_GPU_audio_output_started=False,physical_readiness_consumed=False);child=None
try:
 with(b/'container.log').open('x')as log:
  child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  child.wait(timeout=300)
 record.update(exit=child.returncode,result=json.loads((output/'build/result.json').read_text()))
finally:
 found=subprocess.run(docker+['inspect',name],capture_output=True,text=True,timeout=10)
 if found.returncode==0:
  row=json.loads(found.stdout)[0];assert row['Image']==image and row['Config']['Labels'].get('org.kyaulabs.conflux.run')==label
  subprocess.run(docker+['rm','-f',row['Id']],check=True,capture_output=True,timeout=15)
 if child is not None and child.poll()is None:
  child.terminate()
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
 record['container_absent']=subprocess.run(docker+['inspect',name],capture_output=True,timeout=10).returncode!=0
 record['client_reaped']=child is None or child.poll()is not None
 with(b/'closed-result.json').open('x')as f:json.dump(record,f,indent=2)
print(json.dumps(record))
assert record['exit']==0 and record['result']['passed'] and record['container_absent'] and record['client_reaped']
'''
def run(host):
    start=time.monotonic()
    if host=='laptop':
        root=B.parent/'m2-current-player-hour-01/source-build-01/laptop'
        command=['python3','-B',str(P/'build_probe.py'),'--base',str(P/'laptop'),'--inputs',str(P),'--source',str(root/'source'),'--libdir',str(root/'native')];data=None
    else:command=SSH;data=remote
    with(P/(host+'.stdout.log')).open('x')as out,(P/(host+'.stderr.log')).open('x')as err:
        child=subprocess.Popen(command,stdin=subprocess.PIPE if data else subprocess.DEVNULL,stdout=out,stderr=err,text=True,start_new_session=True)
        try:child.communicate(input=data,timeout=330)
        except BaseException:
            if child.poll()is None:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
            raise
    rec=dict(exit=child.returncode,reaped=child.poll()is not None,seconds=time.monotonic()-start)
    (P/(host+'-dispatch.json')).write_text(json.dumps(rec,indent=2)+'\n')
    if host=='apollo'and child.returncode==0:
        (P/'apollo-closed-result.json').write_text(json.dumps(json.loads((P/'apollo.stdout.log').read_text()),indent=2)+'\n')
    return host,rec
assert not(P/'laptop').exists() and not(P/'laptop.stdout.log').exists()
with ThreadPoolExecutor(max_workers=2)as pool:results=dict(pool.map(run,('laptop','apollo')))
print(json.dumps(results),flush=True)
assert all(row['exit']==0 and row['reaped']for row in results.values())
