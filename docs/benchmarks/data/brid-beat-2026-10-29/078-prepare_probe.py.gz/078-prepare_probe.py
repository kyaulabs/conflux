"""Derive the existing offline production probe and link unchanged frozen libraries."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent;P=B/'probe-build-01';P.mkdir(mode=0o700)
ROOT=B.parent.parent
source=ROOT/'build/m2-analysis-qualification-01/production-artbeat-draft-04/draft-files/tools/experiments/prepare_audio_check.cpp'
text=source.read_text();start=text.index('// Uncached production analysis');end=text.index('\n} // namespace',start)
body=text[start:end]
changes={'source.before.st_size <= 5 * 1024 * 1024':'source.before.st_size <= 9 * 1024 * 1024',
 'source exceeds5MiB':'source exceeds9MiB','prepared.frames() <= 24 * 48000 + 4096':'prepared.frames() <= 60 * 48000 + 4096',
 'firstFile + 24':'firstFile + 93','(1..24)':'(1..93)','std::chrono::seconds(580)':'std::chrono::seconds(1170)'}
for old,new in changes.items():assert body.count(old)==1,old;body=body.replace(old,new)
header='''// SPDX-License-Identifier: AGPL-3.0-or-later
// Private CPU correctness corpus; no audio device, model change or latency gate.
#include "audio/AudioFile.hpp"
#include "library/BpmAnalyzer.hpp"
#include "library/StemEngineSupport.hpp"
#include <QCoreApplication>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QString>
#include <atomic>
#include <chrono>
#include <csignal>
#include <filesystem>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <stop_token>
#include <string_view>
#include <thread>
namespace {
using conflux::audio::PreparedAudio;
using Clock=std::chrono::steady_clock;
double elapsedMs(Clock::time_point began) { return std::chrono::duration<double,std::milli>(Clock::now()-began).count(); }
void require(bool value,const char* message) { if(!value)throw std::runtime_error(message); }
'''
footer='''
} // namespace
int main(int argc,char**argv) {
 if(argc>=2 && (std::string_view(argv[1])=="--bpm-prepare" || std::string_view(argv[1])=="--bpm-analysis"))return bpmCorpus(argc,argv);
 std::cerr<<"Unarmed: select explicit --bpm-prepare or --bpm-analysis mode\\n";return 2;
}
'''
(P/'probe.cpp').write_text(header+body+footer)
cmake='''cmake_minimum_required(VERSION 3.22)
project(conflux_brid_probe LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)
find_package(Qt6 REQUIRED COMPONENTS Core Gui Test)
find_package(Threads REQUIRED)
find_package(PkgConfig REQUIRED)
pkg_check_modules(Deps REQUIRED IMPORTED_TARGET sndfile samplerate rubberband taglib)
foreach(name conflux-library conflux-audio)
 if(NOT EXISTS "${CONFLUX_EXISTING_LIBDIR}/lib${name}.a")
  message(FATAL_ERROR "Frozen existing library missing")
 endif()
endforeach()
add_library(frozen-library INTERFACE)
target_include_directories(frozen-library INTERFACE "${CONFLUX_EXISTING_SOURCE}/src")
target_link_libraries(frozen-library INTERFACE "${CONFLUX_EXISTING_LIBDIR}/libconflux-library.a" "${CONFLUX_EXISTING_LIBDIR}/libconflux-audio.a" Qt6::Core Qt6::Gui PkgConfig::Deps Threads::Threads)
add_executable(brid-production-probe probe.cpp)
target_link_libraries(brid-production-probe PRIVATE frozen-library)
add_executable(bpm-analyzer-test "${CONFLUX_EXISTING_SOURCE}/tests/bpm_analyzer_test.cpp")
target_link_libraries(bpm-analyzer-test PRIVATE frozen-library Qt6::Test)
'''
(P/'CMakeLists.txt').write_text(cmake)
def pin(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
S=ROOT/'build/m2-current-player-hour-01/source-build-01/laptop'
plan=dict(schema=1,scope='Compile only the private93-case probe and existing BPM regression using already verified O2 production libraries; no model run',
 source_head='6e1623ff0261d3cc5200380cd8f1b15260bc57f4',production_source_changed=False,
 old_probe=pin(source),bounds_and_count_changes=changes,
 local_source_root=str(S/'source'),local_library_root=str(S/'native'),
 source_files=[pin(P/n)for n in('probe.cpp','CMakeLists.txt')],
 frozen_libraries=[pin(S/'native'/n)for n in('libconflux-library.a','libconflux-audio.a')],
 product_test=pin(S/'source/tests/bpm_analyzer_test.cpp'),model_started=False,latency_qualified=False)
(P/'build-inputs-01.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(prepared=True,unchanged_production_libraries=True,model_started=False)))
