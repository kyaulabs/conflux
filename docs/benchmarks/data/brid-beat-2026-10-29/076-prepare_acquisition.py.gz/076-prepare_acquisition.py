"""Bind the existing range reader and fixed93 references for Apollo-only acquisition."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent;P=B/'acquisition-01';R=B.parent/'m2-brid-reference-01'
def pin(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
old=B.parent/'m2-fmak-independent-01/resume-last-01/range_media.py'
text=old.read_text().split('\ndef main():',1)[0]
assert text.count('MAX_HTTP_RANGE = 1024**2')==1 and text.count('len(self.requests) >= 256')==1
text=text.replace('MAX_HTTP_RANGE = 1024**2','MAX_HTTP_RANGE = 8*1024**2').replace('len(self.requests) >= 256','len(self.requests) >= 512')
(P/'range_media.py').write_text(text)
test=(old.parent/'test_range_media.py').read_text().replace('budget.requests = [{}]*256','budget.requests = [{}]*512')
(P/'test_range_media.py').write_text(test)
index=json.loads((R/'audio-index-01.json').read_text())
annotations=json.loads((R/'annotation-members-01.json').read_text())['members'];by_name={Path(r['name']).stem:r for r in annotations if r['name'].endswith('.beats')}
cases=[]
for c in index['cases']:
 row=by_name[c['name']];assert row['sha256']==c['beat_reference_sha256']
 beats=[dict(seconds=float(v.split()[0]),bar_position=int(v.split()[1])) for v in row['text'].splitlines() if v.strip()]
 cases.append(dict(c,beats=beats))
assert [r['id']for r in cases]==list(range(1,94))
plan=dict(schema=1,state='frozen_media_admission_only',fixed_denominator=93,source_url=index['source_url'],
 archive_published_bytes=index['archive_published_bytes'],archive_published_MD5=index['archive_published_MD5'],
 index=index['index'],cases=cases,limits=dict(seconds=1200,network_bytes=384*1024**2,source_bytes=512*1024**2,minimum_free_bytes=2*1024**3),
 range_derivation=dict(original=pin(old),only_changes=['HTTP range maximum1MiB→8MiB for the selected <=6.85MB compressed files','Request ceiling256→512 for all93 files','Remove unrelated old FMAK command-line main; reader behavior and validation retained']),
 original_selection=pin(R/'prospective-admission-01.json'),index_pin=pin(R/'audio-index-01.json'),
 audio_played=False,models_run=False,physical_readiness_required=False,latency_qualified=False)
(P/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(prepared=True,denominator=93,expected_compressed_bytes=index['selected_compressed_bytes'],audio_read=False)))
