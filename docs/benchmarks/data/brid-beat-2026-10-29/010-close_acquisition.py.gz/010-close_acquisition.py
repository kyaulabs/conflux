"""Retain source identities, then retire only the exact completed data owner."""
from pathlib import Path
import json,subprocess
B=Path(__file__).resolve().parent
owner=json.loads((B/'data-owner-01.json').read_text())
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','python3 -']
code='OWNER='+repr(owner['owner'])+'\nUNIT='+repr(owner['unit'])+'\n'+r'''
from pathlib import Path
import hashlib,json,subprocess
b=Path('/srv/conflux-tests/work/brid-analysis-20261029-01/acquisition-01')
state=dict(x.split('=',1)for x in subprocess.check_output(['systemctl','show',UNIT,'--property=MainPID,InvocationID,ControlGroup,ActiveState,SubState,ExecMainStatus,Result'],text=True,timeout=5).splitlines()if '='in x)
assert state['InvocationID']==OWNER['InvocationID'] and state['MainPID']=='0'
result=json.loads((b/'source-admission-01.json').read_text());plan=json.loads((b/'plan.json').read_text())
assert result['complete'] and result['error']is None and result['fixed_denominator']==93 and len(result['sources'])==93
assert result['plan_sha256']==hashlib.sha256((b/'plan.json').read_bytes()).hexdigest()
assert [r['id']for r in result['sources']]==list(range(1,94))
assert set((b/'media-01').iterdir())=={b/'media-01'/f'{i:04}.wav'for i in range(1,94)}
for row,case in zip(result['sources'],plan['cases']):
 assert row['status']=='SourceBytesAdmitted' and row['name']==case['name']
 p=Path(row['source']['path']);assert p==b/'media-01'/f"{row['id']:04}.wav" and not p.is_symlink()
 assert p.stat().st_size==row['source']['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['source']['sha256']
assert result['source_bytes']==469990540 and result['transferred_bytes']<=plan['limits']['network_bytes']
subprocess.run(['sudo','-n','systemctl','stop',UNIT],check=True,capture_output=True,timeout=20)
after=dict(x.split('=',1)for x in subprocess.check_output(['systemctl','show',UNIT,'--property=LoadState,MainPID,ControlGroup,ActiveState,SubState'],text=True,timeout=5).splitlines()if '='in x)
assert after['MainPID']=='0' and after['ActiveState']in('inactive','failed') and not after['ControlGroup']
cg=Path('/sys/fs/cgroup'+OWNER['ControlGroup']);assert not cg.exists() or not(cg/'cgroup.procs').read_text().strip()
record=dict(schema=1,result=result,source_hashes_reverified=93,unit=UNIT,original_invocation=OWNER['InvocationID'],terminal_state=state,retired_state=after,original_cgroup_absent_or_empty=True,model_GPU_audio_output_started=False,physical_readiness_consumed=False)
with(b/'closed-acquisition-01.json').open('x')as f:json.dump(record,f,indent=2)
print(json.dumps(record))
'''
assert not(B/'closed-acquisition-01.json').exists()
r=subprocess.run(SSH,input=code,text=True,capture_output=True,timeout=45)
if r.returncode:print(r.stderr[-5000:]);r.check_returncode()
value=json.loads(r.stdout)
(B/'closed-acquisition-01.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(dict(complete=value['result']['complete'],sources=value['source_hashes_reverified'],bytes=value['result']['source_bytes'],seconds=value['result']['seconds'],retired=True)))
