"""Stream the existing hashed CPU environment into CONFLUX's private Apollo area."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import tarfile
TARGET=Path(__file__).resolve().parent
BASE_SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
def save(p,value):
    with p.open('x')as f:json.dump(value,f,indent=2)

REMOTE='/srv/conflux-tests/work/brid-analysis-20261029-01/runtime-01'
SSH=BASE_SSH[:1]+['-o','ServerAliveInterval=10','-o','ServerAliveCountMax=2']+BASE_SSH[1:]


def main():
    manifest=json.loads((TARGET/'runtime-manifest-01.json').read_text())
    assert not(TARGET/'runtime-transfer-complete-01.json').exists()
    assert 1000<len(manifest['files'])<30000 and manifest['regular_bytes']<1536*1024**2 and not manifest['links']
    receiver='ROOTPATH='+repr(REMOTE)+'\nSPEC='+repr(manifest)+'\n'+r'''
from pathlib import Path,PurePosixPath
import hashlib,json,os,signal,sys,tarfile,time
base=Path(ROOTPATH);assets=base/'assets'
assert not assets.exists();assets.mkdir(mode=0o700)
expected={row['file']:row for row in SPEC['files']};assert len(expected)==len(SPEC['files'])<30000
seen=set();first=time.monotonic();received=0
def expired(number,frame):raise TimeoutError('Original 600-second source-copy budget exhausted')
signal.signal(signal.SIGALRM,expired);signal.alarm(600)
try:
 with tarfile.open(fileobj=sys.stdin.buffer,mode='r|gz')as archive:
  for member in archive:
   name=PurePosixPath(member.name)
   assert member.isfile()and not name.is_absolute()and '..'not in name.parts
   assert member.name in expected and member.name not in seen
   row=expected[member.name];assert member.size==row['bytes']and member.size<=512*1024**2
   received+=member.size;assert received<=1536*1024**2
   path=assets/member.name;path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
   stream=archive.extractfile(member);digest=hashlib.sha256();remaining=member.size
   with path.open('xb')as output:
    while remaining:
     block=stream.read(min(1024**2,remaining));assert block
     remaining-=len(block);output.write(block);digest.update(block)
   assert digest.hexdigest()==row['sha256']
   assert row['mode']in(0o644,0o755);path.chmod(row['mode'])
   seen.add(member.name)
 assert seen==set(expected)and received==SPEC['regular_bytes']
 for row in SPEC['links']:
  name=PurePosixPath(row['file']);assert not name.is_absolute()and '..'not in name.parts
  path=assets/row['file'];target=Path(os.path.normpath(str(path.parent/row['target'])))
  assert target.is_relative_to(assets)and target.exists()
  path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
  assert not path.exists()and not path.is_symlink()
  path.symlink_to(row['target'])
 result=dict(files=len(seen),links=len(SPEC['links']),bytes=received,all_hashes_verified=True,
  packages_installed=False,model_or_audio_started=False,elapsed_seconds=time.monotonic()-first)
 (base/'asset-transfer-complete-01.json').write_text(json.dumps(result,indent=2)+chr(10))
 print(json.dumps(result))
except BaseException as error:
 (base/'asset-transfer-failed-01.json').write_text(json.dumps(dict(files_received=len(seen),bytes=received,
  error=dict(type=type(error).__name__,message=str(error)[:1000]),model_started=False),indent=2)+chr(10))
 raise
finally:signal.alarm(0)
'''
    (TARGET/'receive_assets.py').write_text(receiver)
    bootstrap='ROOTPATH='+repr(REMOTE)+'\nRECEIVER='+repr(receiver)+'\n'+r'''
from pathlib import Path
import json,shutil
base=Path(ROOTPATH);assert base.parent.resolve()==base.parent and not base.exists()
assert shutil.disk_usage(base.parent).free>2*1024**3
base.mkdir(mode=0o700);(base/'receive_assets.py').write_text(RECEIVER)
print(json.dumps(dict(prepared=True,model_started=False)))
'''
    setup=subprocess.run(SSH+['python3 -'],input=bootstrap,capture_output=True,text=True,timeout=30)
    (TARGET/'runtime-bootstrap.stdout.log').write_text(setup.stdout)
    (TARGET/'runtime-bootstrap.stderr.log').write_text(setup.stderr)
    setup.check_returncode()
    child=None;first=__import__('time').monotonic()
    def expired(number,frame):raise TimeoutError('Original 600-second copy budget exhausted')
    prior=signal.signal(signal.SIGALRM,expired);signal.alarm(600)
    try:
        with (TARGET/'runtime-transfer.stdout.log').open('x')as out,(TARGET/'runtime-transfer.stderr.log').open('x')as err:
            child=subprocess.Popen(SSH+['python3 '+REMOTE+'/receive_assets.py'],stdin=subprocess.PIPE,
                stdout=out,stderr=err,start_new_session=True)
            with tarfile.open(fileobj=child.stdin,mode='w|gz',compresslevel=1)as archive:
                for row in manifest['files']:
                    path=Path(row['path']);assert path.is_file()and not path.is_symlink()and path.stat().st_size==row['bytes']
                    info=tarfile.TarInfo(row['file']);info.size=row['bytes'];info.mode=row['mode']
                    with path.open('rb')as stream:archive.addfile(info,stream)
            child.stdin.close();code=child.wait(timeout=max(1,600-(__import__('time').monotonic()-first)))
        assert code==0,(TARGET/'runtime-transfer.stderr.log').read_text()[-2000:]
        result=json.loads((TARGET/'runtime-transfer.stdout.log').read_text())
        assert result['files']==len(manifest['files'])and result['all_hashes_verified']
        save(TARGET/'runtime-transfer-complete-01.json',dict(remote_root=REMOTE,
            remote=result,local_archive_persisted=False,original_environment_changed=False,
            source_manifest_sha256=hashlib.sha256((TARGET/'runtime-manifest-01.json').read_bytes()).hexdigest(),
            music_inference_started=False))
        print(json.dumps(result))
    finally:
        signal.alarm(0);signal.signal(signal.SIGALRM,prior)
        if child is not None and child.poll()is None:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=3)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=3)


if __name__=='__main__':main()
