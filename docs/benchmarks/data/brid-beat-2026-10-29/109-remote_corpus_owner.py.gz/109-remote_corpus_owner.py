"""Bounded owner for one CPU-only corpus in the dedicated CONFLUX daemon."""
from pathlib import Path
import argparse,json,signal,subprocess,time
B=Path('/srv/conflux-tests/work/brid-analysis-20261029-01/corpus-02')
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
NAME='conflux-brid-cpu-corpus-20261029-02';LABEL='brid-cpu-corpus-20261029-02';IMAGE='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
def cleanup():
 r=subprocess.run(D+['inspect',NAME],capture_output=True,text=True,timeout=10)
 if r.returncode==0:
  c=json.loads(r.stdout)[0];assert c['Image']==IMAGE and c['Config']['Labels'].get('org.kyaulabs.conflux.run')==LABEL
  subprocess.run(D+['rm','-f',c['Id']],check=True,capture_output=True,timeout=20)
 assert subprocess.run(D+['inspect',NAME],capture_output=True,timeout=10).returncode!=0
 with(B/'cleanup.jsonl').open('a')as f:f.write(json.dumps(dict(monotonic=time.monotonic(),container_absent=True))+'\n')
def main():
 p=argparse.ArgumentParser();p.add_argument('--run',action='store_true');p.add_argument('--check-inputs',action='store_true');p.add_argument('--cleanup-only',action='store_true');a=p.parse_args()
 if a.cleanup_only:cleanup();return
 if not(a.run or a.check_inputs):print(json.dumps(dict(unarmed=True,model_started=False)));return
 work=B/('check-work'if a.check_inputs else'work');record=B/('checked-result.json'if a.check_inputs else'closed-result.json')
 assert not work.exists() and not record.exists()
 assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}'],timeout=10))=='/srv/conflux-tests/docker-data'
 assert subprocess.run(D+['inspect',NAME],capture_output=True,timeout=10).returncode!=0
 root=B.parent;assets=root/'runtime-01/assets';manifest=json.loads((B/'runtime-manifest-01.json').read_text())
 work.mkdir(mode=0o700)
 cmd=D+['run','--rm','--name',NAME,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true','--user=1000:1000','--memory=4g','--cpus=2','--pids-limit=512','--label','org.kyaulabs.conflux.run='+LABEL,'--tmpfs=/tmp:rw,nosuid,nodev,size=128m,mode=1777',
 '--mount','type=bind,src='+str(B)+',dst=/operations,readonly','--mount','type=bind,src='+str(work)+',dst=/work',
 '--mount','type=bind,src='+str(assets)+',dst=/assets,readonly','--mount','type=bind,src='+str(assets/'venv')+',dst='+manifest['source_venv']+',readonly',
 '--mount','type=bind,src='+str(assets/'base')+',dst='+manifest['source_base_python']+',readonly',
 '--mount','type=bind,src='+str(root/'acquisition-01/media-01')+',dst=/media,readonly',
 '--mount','type=bind,src='+str(root/'probe-build-01/output/build/native')+',dst=/probe,readonly',
 IMAGE,'timeout','--signal=TERM','--kill-after=10s','70s'if a.check_inputs else'1240s','python','-B','/operations/corpus_driver.py','--plan','/operations/apollo-plan.json','--check-inputs'if a.check_inputs else'--run']
 result=dict(command=cmd,complete=False,qualified=False);child=None;start=time.monotonic()
 def interrupted(number,frame):raise InterruptedError('CPU corpus owner interrupted')
 for number in(signal.SIGTERM,signal.SIGINT):signal.signal(number,interrupted)
 try:
  logfile=B/('check-container.log'if a.check_inputs else'container.log')
  with logfile.open('x')as log:
   child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT);child.wait(timeout=1260)
  result.update(container_exit=child.returncode,analysis=json.loads(logfile.read_text())if a.check_inputs else json.loads((work/'output/result.json').read_text()))
  result['complete']=child.returncode==0 and result['analysis']['passed'if a.check_inputs else'complete']
 except BaseException as error:result['error']=dict(type=type(error).__name__,message=str(error)[:3000])
 finally:
  cleanup()
  if child is not None and child.poll()is None:
   child.terminate()
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
  result.update(container_absent=True,client_reaped=child is None or child.poll()is not None,seconds=time.monotonic()-start)
  record.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:result.get(k)for k in('complete','container_absent','client_reaped','seconds','error')}),flush=True)
 raise SystemExit(0 if result['complete']else 1)
if __name__=='__main__':main()
