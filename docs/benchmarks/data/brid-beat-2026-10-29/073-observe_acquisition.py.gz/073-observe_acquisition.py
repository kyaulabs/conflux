"""Observe the exact data owner; never launch or retry an admission."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
B=Path(__file__).resolve().parent
owner=json.loads((B/'data-owner-01.json').read_text());expected=owner['owner']['InvocationID'];unit=owner['unit']
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','python3 -']
code='UNIT='+repr(unit)+'\nEXPECTED='+repr(expected)+'\n'+r'''
from pathlib import Path
import json,subprocess
b=Path('/srv/conflux-tests/work/brid-analysis-20261029-01/acquisition-01')
raw=subprocess.check_output(['systemctl','show',UNIT,'--property=LoadState,ActiveState,SubState,MainPID,InvocationID,ControlGroup,Result,ExecMainStatus'],text=True,timeout=5)
state=dict(x.split('=',1)for x in raw.splitlines()if '='in x);assert state['InvocationID']==EXPECTED
r=dict(owner=state)
if(b/'progress.json').exists():r['progress']=json.loads((b/'progress.json').read_text())
if(b/'source-admission-01.json').exists():
 x=json.loads((b/'source-admission-01.json').read_text());r['result']={k:x[k]for k in('complete','error','fixed_denominator','source_bytes','transferred_bytes','seconds')}
if state['MainPID']=='0':
 r['stderr']=subprocess.check_output(['sudo','-n','cat',str(b/'unit.stderr.log')],text=True,timeout=5)[-4000:]
 r['protocol_checks']=(b/'offline-checks.stderr.log').read_text()[-1000:]
print(json.dumps(r))
'''
r=subprocess.run(ssh,input=code,text=True,capture_output=True,timeout=20);r.check_returncode();value=json.loads(r.stdout)
number=len(list(B.glob('data-observation-*.json')))+1
(B/f'data-observation-{number:03}.json').write_text(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),**value),indent=2)+'\n')
print(json.dumps(value))
