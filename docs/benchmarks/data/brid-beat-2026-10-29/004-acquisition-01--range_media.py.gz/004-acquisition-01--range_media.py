"""Read selected public ZIP members with bounded HTTP ranges and stdlib ZIP CRCs."""
from contextlib import ExitStack
from datetime import datetime, timezone
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import resource
import time
import urllib.request
import zipfile
import zlib

BASE = Path(__file__).resolve().parent
MAX_MEMBER = 32*1024**2
MAX_HTTP_RANGE = 8*1024**2


class Budget:
    def __init__(self, seconds=600, byte_limit=384*1024**2):
        self.started = time.monotonic()
        self.deadline = self.started+seconds
        self.byte_limit = byte_limit
        self.bytes = 0
        self.requests = []

    def check(self):
        if time.monotonic() >= self.deadline:
            raise TimeoutError('Original media-admission deadline')
        if len(self.requests) >= 512:
            raise ValueError('Remote range request count exceeds the frozen budget')


class RangeFile(io.RawIOBase):
    def __init__(self, url, size, budget):
        super().__init__()
        self.url, self.size, self.budget, self.position = url, size, budget, 0

    def seekable(self):
        return True

    def readable(self):
        return True

    def tell(self):
        return self.position

    def seek(self, offset, whence=io.SEEK_SET):
        self._checkClosed()
        if type(offset) is not int or whence not in (io.SEEK_SET, io.SEEK_CUR, io.SEEK_END):
            raise ValueError('Invalid remote-file seek')
        target = offset+(self.position if whence == io.SEEK_CUR else self.size if whence == io.SEEK_END else 0)
        if not 0 <= target <= self.size:
            raise ValueError('Remote seek outside published archive')
        self.position = target
        return target

    def read(self, size=-1):
        self._checkClosed()
        if size is None:
            size = -1
        if type(size) is not int or size < -1:
            raise ValueError('Invalid remote read extent')
        count = self.size-self.position if size == -1 else min(size,self.size-self.position)
        if count > MAX_MEMBER or self.budget.bytes+count+1 > self.budget.byte_limit:
            raise ValueError('Remote request exceeds the frozen byte budget')
        chunks = []
        while count:
            amount = min(MAX_HTTP_RANGE,count)
            chunks.append(self._read_one(amount))
            count -= amount
        return b''.join(chunks)

    def _read_one(self, size=-1):
        self._checkClosed()
        if size is None:
            size = -1
        if type(size) is not int or size < -1:
            raise ValueError('Invalid remote read extent')
        count = self.size-self.position if size == -1 else min(size, self.size-self.position)
        if count == 0:
            return b''
        if count > MAX_MEMBER or self.budget.bytes+count+1 > self.budget.byte_limit:
            raise ValueError('Remote request exceeds the frozen byte budget')
        self.budget.check()
        start, end = self.position, self.position+count-1
        request = urllib.request.Request(self.url, headers={
            'Range':f'bytes={start}-{end}', 'Accept-Encoding':'identity',
            'User-Agent':'CONFLUX-M2-research/0.1'})
        raw = bytearray()
        with urllib.request.urlopen(request, timeout=min(20., self.budget.deadline-time.monotonic())) as response:
            if response.status != 206:
                raise ValueError('Publisher ignored the bounded Range request')
            match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
            if not match or tuple(map(int, match.groups())) != (start, end, self.size):
                raise ValueError('Returned Content-Range differs from the published archive')
            if response.headers.get('Content-Encoding') not in (None, 'identity'):
                raise ValueError('Encoded remote ranges are not accepted')
            length = response.headers.get('Content-Length')
            if length is not None and (not length.isdigit() or int(length) != count):
                raise ValueError('Returned range length differs')
            while len(raw) <= count:
                self.budget.check()
                chunk = response.read(min(65536, count+1-len(raw)))
                if not chunk:
                    break
                self.budget.bytes += len(chunk)
                raw.extend(chunk)
            self.budget.check()
            if len(raw) != count:
                raise ValueError(f'Truncated or oversized remote range: offset={start}, expected={count}, received={len(raw)}')
        self.budget.requests.append(dict(url=self.url, first_byte=start, bytes=count,
                                        SHA256=hashlib.sha256(raw).hexdigest()))
        self.position += count
        return bytes(raw)

