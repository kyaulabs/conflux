"""Acquire only the fixed93 publisher members; never open audio output or a model."""
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
import argparse,hashlib,io,json,math,os,resource,shutil,signal,time,wave,zipfile,zlib
from range_media import Budget,RangeFile
B=Path(__file__).resolve().parent

def wave_geometry(raw,beats):
 with wave.open(io.BytesIO(raw),'rb') as audio:
  channels,width,rate,frames=audio.getnchannels(),audio.getsampwidth(),audio.getframerate(),audio.getnframes()
  assert channels in (1,2) and width==2 and rate==44100 and 0<frames<=60*rate and audio.getcomptype()=='NONE'
  assert len(audio.readframes(frames+1))==channels*width*frames
 assert beats and all(type(v['seconds'])in(int,float) and math.isfinite(v['seconds']) and 0<=v['seconds']<frames/rate and v['bar_position']in(1,2) for v in beats)
 assert all(a['seconds']<b['seconds'] and a['bar_position']!=b['bar_position'] for a,b in zip(beats,beats[1:]))
 return dict(channels=channels,sample_width=width,sample_rate=rate,frames=frames,duration_seconds=frames/rate)

def admit(archive,case,destination):
 entry=case['source'];name=PurePosixPath(entry['name'])
 assert not name.is_absolute() and '..'not in name.parts and '\\'not in entry['name']
 matches=[i for i in archive.infolist() if i.filename==entry['name']]
 assert len(matches)==1
 member=matches[0]
 assert not member.is_dir() and not member.flag_bits&1 and ((member.external_attr>>16)&0o170000)!=0o120000
 assert member.compress_type in(zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED)
 assert member.file_size==entry['bytes'] and member.compress_size==entry['compressed_bytes']
 assert f'{member.CRC:08x}'==entry['CRC32'] and 0<member.file_size<=9*1024**2 and member.compress_size<=8*1024**2
 with archive.open(member) as stream:raw=stream.read(9*1024**2+1)
 assert len(raw)==member.file_size and zlib.crc32(raw)==member.CRC
 geometry=wave_geometry(raw,case['beats'])
 target=destination/f"{case['id']:04}.wav"
 with target.open('xb') as output:output.write(raw);output.flush();os.fsync(output.fileno())
 return dict(path=str(target),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),archive_member=entry['name'],
 ZIP_CRC32=f'{member.CRC:08x}',ZIP_CRC_verified=True,source_geometry=geometry,
 reference_count=len(case['beats']),position1_count=sum(r['bar_position']==1 for r in case['beats']))

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
 raw=(B/'plan.json').read_bytes();plan=json.loads(raw)
 assert plan['state']=='frozen_media_admission_only' and plan['fixed_denominator']==93 and [c['id']for c in plan['cases']]==list(range(1,94))
 if not args.run:
  print(json.dumps(dict(unarmed=True,network_started=False,model_started=False)));return 0
 for row in json.loads((B/'input-pins.json').read_text())['files']:
  p=B/row['file'];data=p.read_bytes();assert p.is_file() and not p.is_symlink() and len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert shutil.disk_usage(B).free>=plan['limits']['minimum_free_bytes']
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(120,120))
 budget=Budget(plan['limits']['seconds'],plan['limits']['network_bytes'])
 def stopped(number,frame):raise InterruptedError('Owned data acquisition stopped')
 signal.signal(signal.SIGTERM,stopped);signal.signal(signal.SIGINT,stopped)
 media=B/'media-01';media.mkdir(mode=0o700)
 rows=[dict(id=c['id'],name=c['name'],status='NotAttempted')for c in plan['cases']];error=None
 try:
  with RangeFile(plan['source_url'],plan['archive_published_bytes'],budget) as remote,zipfile.ZipFile(remote) as archive:
   observed=[dict(name=i.filename,bytes=i.file_size,compressed_bytes=i.compress_size,CRC32=f'{i.CRC:08x}',directory=i.is_dir())for i in archive.infolist()]
   assert observed==plan['index'],'Publisher central directory differs from the fixed selection'
   for index,case in enumerate(plan['cases']):
    budget.check();rows[index]['status']='SourceAttempted'
    source=admit(archive,case,media);budget.check()
    rows[index]=dict(id=case['id'],name=case['name'],status='SourceBytesAdmitted',source=source)
    assert sum(r.get('source',{}).get('bytes',0)for r in rows)<=plan['limits']['source_bytes']
    assert shutil.disk_usage(B).free>=plan['limits']['minimum_free_bytes']
    progress=dict(admitted=index+1,denominator=93,source_bytes=sum(r.get('source',{}).get('bytes',0)for r in rows),transferred_bytes=budget.bytes,elapsed_seconds=time.monotonic()-budget.started)
    temporary=B/'progress.tmp';temporary.write_text(json.dumps(progress)+'\n');temporary.replace(B/'progress.json')
    print(json.dumps(progress),flush=True)
 except BaseException as caught:
  error=dict(type=type(caught).__name__,detail=str(caught)[:1800])
  for r in rows:
   if r['status']=='SourceAttempted':r.update(status='SourceAdmissionFailed',error=error)
 result=dict(schema=1,utc=datetime.now(timezone.utc).isoformat(),complete=error is None,error=error,fixed_denominator=93,sources=rows,
 source_bytes=sum(r.get('source',{}).get('bytes',0)for r in rows),transferred_bytes=budget.bytes,requests=budget.requests,
 seconds=time.monotonic()-budget.started,plan_sha256=hashlib.sha256(raw).hexdigest(),
 integrity='Publisher HTTPS ranges, exact published ZIP directory/extent, standard member CRC, and new complete-WAV SHA256; full archive MD5 not computed.',
 native_source_decoded=False,audio_played=False,model_or_GPU_started=False,physical_readiness_consumed=False,
 host_policy_or_protected_service_changed=False,qualified=False)
 with (B/'source-admission-01.json').open('x') as out:json.dump(result,out,indent=2,allow_nan=False)
 print(json.dumps({k:result[k]for k in ('complete','error','fixed_denominator','source_bytes','transferred_bytes','seconds')}),flush=True)
 return 0 if result['complete'] else 1

if __name__=='__main__':raise SystemExit(main())
