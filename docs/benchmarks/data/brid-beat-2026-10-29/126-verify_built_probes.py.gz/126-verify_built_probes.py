"""Verify retained build/test outputs; do not repeat compilation or tests."""
from pathlib import Path
import json,subprocess
B=Path(__file__).resolve().parent;P=B/'probe-build-01'
COMMON=r'''
from pathlib import Path
import hashlib,json,re,wave
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def verify(b,inputs,source,libdir):
 old=json.loads((b/'result.json').read_text());assert not old['passed'] and old['error']['type']=='AssertionError'
 assert set(old['stages'])=={'configure','build','regression','long-source'}
 assert all(r['exit']==0 and r['reaped']for r in old['stages'].values())
 match=re.search(r'Totals: (\d+) passed, (\d+) failed, (\d+) skipped, (\d+) blacklisted',(b/'regression.log').read_text())
 assert match and tuple(map(int,match.groups()))==(113,0,0,0)
 rows=[json.loads(line)for line in(b/'long-source.log').read_text().splitlines()]
 assert len(rows)==2 and rows[0]['passed'] and rows[1]['complete'] and rows[1]['passed'] and rows[1]['completed']==rows[1]['expected']==1
 row=rows[0];fixture=b/'thirty-seconds-44100.wav'
 with wave.open(str(fixture),'rb')as audio:
  assert (audio.getnchannels(),audio.getsampwidth(),audio.getframerate(),audio.getnframes())==(2,2,44100,30*44100)
  raw=audio.readframes(30*44100+1);assert raw==b'\0'*(30*44100*4)
 assert row['source_bytes']==fixture.stat().st_size>5*1024*1024 and row['source_sha256']==pin(fixture)['sha256']
 extent=row['prepared_frames'];assert type(extent)is int and 30*48000<=extent<=30*48000+4096
 assert row['prepared_rate_hz']==48000 and row['prepared_bytes']==extent*8 and row['pcm_sha256']==hashlib.sha256(b'\0'*(extent*8)).hexdigest()
 assert row['analysis_status']=='NotRun' and not row['beats'] and not row['cache_hit']
 assert not list((b/'spool').iterdir())
 commands=json.loads((b/'native/compile_commands.json').read_text());assert commands
 assert all('-O2'in r['command'] and not any(x in r['command']for x in ('--coverage','-fprofile-arcs','-ftest-coverage','-Ofast','-ffast-math'))for r in commands)
 result=dict(schema=1,passed=True,regression_passed=113,original_driver_assertion_retained=True,original_failure='Private checker assumed30*48000; native converter correctly produced1440001frames.',verification_only_no_tests_repeated=True,
  actual_native_prepared_extent=extent,complete_prepared_silence_hash_verified=True,long_source=row,spool_retired=True,
  identities_observed_after_build={str(p):pin(p)for p in [inputs/'probe.cpp',inputs/'CMakeLists.txt',source/'tests/bpm_analyzer_test.cpp',libdir/'libconflux-library.a',libdir/'libconflux-audio.a',b/'native/brid-production-probe']},
  model_GPU_audio_output_started=False,physical_readiness_consumed=False,latency_qualified=False)
 target=b/'postbuild-verification-01.json'
 with target.open('x')as f:json.dump(result,f,indent=2)
 return result
'''
ns={};exec(COMMON,ns)
root=B.parent/'m2-current-player-hour-01/source-build-01/laptop'
local=ns['verify'](P/'laptop',P,root/'source',root/'native')
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','python3 -']
code=COMMON+r'''
b=Path('/srv/conflux-tests/work/brid-analysis-20261029-01/probe-build-01')
frozen=Path('/srv/conflux-tests/work/current-player-hour-20261029-01/source-build-01/output')
record=verify(b/'output/build',b,frozen/'source',frozen/'native')
closed=json.loads((b/'closed-result.json').read_text());assert closed['container_absent'] and closed['client_reaped']
record.update(container_absent=True,client_reaped=True)
print(json.dumps(record))
'''
r=subprocess.run(SSH,input=code,text=True,capture_output=True,timeout=30)
if r.returncode:print(r.stderr[-4000:]);r.check_returncode()
remote=json.loads(r.stdout)
assert local['long_source']['prepared_frames']==remote['long_source']['prepared_frames'] and local['long_source']['pcm_sha256']==remote['long_source']['pcm_sha256']
out=dict(schema=1,passed=True,hosts=dict(laptop=local,apollo=remote),both_hosts_same_actual_extent_and_PCM=True,all_check_processes_reaped=True,latency_qualified=False)
(P/'paired-verification-01.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(passed=True,regressions_per_host=113,source_frames=30*44100,prepared_frames=local['actual_native_prepared_extent'],both_hosts_exact_PCM=True,latency_qualified=False)))
