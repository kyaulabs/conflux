// SPDX-License-Identifier: AGPL-3.0-or-later
// Private CPU correctness corpus; no audio device, model change or latency gate.
#include "audio/AudioFile.hpp"
#include "library/BpmAnalyzer.hpp"
#include "library/StemEngineSupport.hpp"
#include <QCoreApplication>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QString>
#include <atomic>
#include <chrono>
#include <csignal>
#include <filesystem>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <stop_token>
#include <string_view>
#include <thread>
namespace {
using conflux::audio::PreparedAudio;
using Clock=std::chrono::steady_clock;
double elapsedMs(Clock::time_point began) { return std::chrono::duration<double,std::milli>(Clock::now()-began).count(); }
void require(bool value,const char* message) { if(!value)throw std::runtime_error(message); }
// Uncached production analysis, separate from the ordinary render corpus mode.
// No audio device, GUI, Python frontend copy or analysis-cache reuse is involved.
std::atomic_flag bpmInterrupted = ATOMIC_FLAG_INIT;
void interruptBpm(int) { bpmInterrupted.test_and_set(std::memory_order_relaxed); }

QJsonObject checkBpmFile(const std::filesystem::path& spoolDirectory, const char* name,
                       const conflux::library::BpmEngine* engine, std::stop_token stop)
{
    namespace detail = conflux::library::detail;
    QJsonObject row{{"schema", 1}, {"kind", "production-bpm-case"},
        {"source", QString::fromLocal8Bit(name)}, {"passed", false},
        {"prepared_rate_hz", 48000}, {"analysis_status", "NotRun"},
        {"analysis_error", ""}, {"cache_hit", false}, {"beats", QJsonArray{}}};
    const auto began = Clock::now();
    try {
        auto source = detail::pinStemFile(QString::fromLocal8Bit(name), false, stop);
        require(source.before.st_size <= 9 * 1024 * 1024, "BPM corpus source exceeds9MiB");
        row.insert("source", source.path);
        row.insert("source_sha256", source.identity.value("sha256"));
        row.insert("source_bytes", qint64(source.before.st_size));
        auto prepared = conflux::audio::prepareAudioFile(source.descriptor->get(),
            PreparedAudio::defaultMaxPreparedBytes, stop, spoolDirectory);
        // Record the produced extent, never a floor/ceil rate-ratio guess.
        require(prepared.frames() <= 60 * 48000 + 4096, "BPM corpus prepared extent exceeds bound");
        const auto pcm = detail::scan(prepared.descriptor(), prepared.frames() * 8, stop, prepared.frames());
        row.insert("prepared_frames", qint64(prepared.frames()));
        row.insert("prepared_bytes", qint64(prepared.frames() * 8));
        row.insert("pcm_sha256", QString::fromLatin1(pcm.sha256));
        row.insert("preparation_elapsed_ms", elapsedMs(began));
        if (engine) {
            const auto analysisBegan = Clock::now();
            const auto analysis = conflux::library::analyzeBpm(prepared, *engine, stop);
            row.insert("analysis_elapsed_ms", elapsedMs(analysisBegan));
            row.insert("analysis_status", analysis.status);
            row.insert("analysis_error", analysis.error);
            row.insert("analysis_frames", qint64(analysis.analysisFrames));
            row.insert("analysis_pcm_sha256", QString::fromLatin1(analysis.pcmSha256));
            row.insert("summary_bpm", analysis.bpm ? QJsonValue(*analysis.bpm) : QJsonValue(QJsonValue::Null));
            row.insert("cache_hit", analysis.cacheHit);
            QJsonArray beats;
            for (const auto& beat : analysis.beats)
                beats.append(QJsonObject{{"frame", qint64(beat.frame)}, {"downbeat", beat.downbeat}});
            row.insert("beats", beats);
            require(!analysis.cacheHit, "Uncached analysis unexpectedly reused a cache");
            if (analysis.status != "Estimated" && analysis.status != "Unknown")
                throw std::runtime_error("Production BPM analysis failed");
            require(analysis.error.isEmpty() && analysis.analysisFrames == prepared.frames() &&
                    analysis.pcmSha256 == pcm.sha256, "Accepted production source identity differs");
        }
        detail::verifyStemFile(source, stop);
        row.insert("passed", true);
    } catch (const std::exception& error) {
        row.insert("error", QString::fromUtf8(error.what()).left(2048));
    }
    row.insert("elapsed_ms", elapsedMs(began));
    return row;
}

int bpmCorpus(int argc, char** argv)
{
    const bool analyze = std::string_view(argv[1]) == "--bpm-analysis";
    const int firstFile = analyze ? 7 : 3;
    if (argc <= firstFile || argc > firstFile + 93) {
        std::cerr << "Usage: --bpm-prepare SPOOL FILE... or --bpm-analysis SPOOL PYTHON SOURCE_DIR MODEL WORKER FILE... (1..93)\n";
        return 2;
    }
    QCoreApplication application(argc, argv);
    std::optional<conflux::library::BpmEngine> engine;
    if (analyze) engine = conflux::library::BpmEngine{
        QString::fromLocal8Bit(argv[3]),QString::fromLocal8Bit(argv[4]),
        QString::fromLocal8Bit(argv[5]),QString::fromLocal8Bit(argv[6])};
    const auto began = Clock::now();
    std::stop_source cancellation;
    const auto oldTerm = std::signal(SIGTERM, interruptBpm), oldInt = std::signal(SIGINT, interruptBpm);
    std::jthread guard([&](std::stop_token done) {
        while (!done.stop_requested()) {
            if (bpmInterrupted.test(std::memory_order_relaxed) || Clock::now() - began >= std::chrono::seconds(1170)) {
                cancellation.request_stop(); return;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
        }
    });
    bool passed = true;
    int completed = 0;
    for (int index = firstFile; index < argc && !cancellation.stop_requested(); ++index) {
        auto row = checkBpmFile(std::filesystem::path(argv[2]),argv[index],engine ? &*engine : nullptr,
                                cancellation.get_token());
        row.insert("ordinal", completed++);
        passed = passed && row.value("passed").toBool();
        std::cout << QJsonDocument(row).toJson(QJsonDocument::Compact).constData() << '\n' << std::flush;
    }
    guard.request_stop(); guard.join();
    std::signal(SIGTERM, oldTerm); std::signal(SIGINT, oldInt);
    const bool complete = completed == argc-firstFile && !cancellation.stop_requested();
    std::cout << QJsonDocument(QJsonObject{{"schema",1},{"kind","production-bpm-complete"},
        {"mode",analyze ? "analysis" : "prepare"},{"completed",completed},{"expected",argc-firstFile},
        {"complete",complete},{"passed",complete && passed},{"elapsed_ms",elapsedMs(began)}})
        .toJson(QJsonDocument::Compact).constData() << '\n' << std::flush;
    return complete && passed ? 0 : 1;
}

} // namespace
int main(int argc,char**argv) {
 if(argc>=2 && (std::string_view(argv[1])=="--bpm-prepare" || std::string_view(argv[1])=="--bpm-analysis"))return bpmCorpus(argc,argv);
 std::cerr<<"Unarmed: select explicit --bpm-prepare or --bpm-analysis mode\n";return 2;
}
