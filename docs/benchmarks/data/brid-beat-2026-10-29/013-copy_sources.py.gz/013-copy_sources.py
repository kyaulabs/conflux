"""Stream the admitted WAVs without a second archive; retain the hour reserve."""
from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,tarfile,time
B=Path(__file__).resolve().parent
record=json.loads((B/'closed-acquisition-01.json').read_text());sources=record['result']['sources']
assert record['source_hashes_reverified']==len(sources)==93
dest=B/'media-01';assert not dest.exists()
assert shutil.disk_usage(B).free>=record['result']['source_bytes']+4*1024**3+32*1024**2
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ServerAliveInterval=10','-o','ServerAliveCountMax=2','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
sender='SOURCES='+repr(sources)+'\n'+r'''
from pathlib import Path
import hashlib,signal,sys,tarfile
def expired(number,frame):raise TimeoutError('Original240s media-copy budget exhausted')
signal.signal(signal.SIGALRM,expired);signal.alarm(240)
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz',compresslevel=1)as out:
 for row in SOURCES:
  p=Path(row['source']['path']);assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['source']['bytes']
  with p.open('rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['source']['sha256']
  info=tarfile.TarInfo(f"{row['id']:04}.wav");info.size=p.stat().st_size;info.mode=0o600
  with p.open('rb')as stream:out.addfile(info,stream)
signal.alarm(0)
'''
remote='/srv/conflux-tests/work/brid-analysis-20261029-01/send_sources.py'
bootstrap='CONTENT='+repr(sender)+'\nPATH='+repr(remote)+'\nfrom pathlib import Path\np=Path(PATH);assert not p.exists()\nwith p.open("x")as f:f.write(CONTENT)\n'
r=subprocess.run(SSH+['python3 -'],input=bootstrap,text=True,capture_output=True,timeout=20)
if r.returncode:print(r.stderr[-2500:]);r.check_returncode()
dest.mkdir(mode=0o700);expected={f"{r['id']:04}.wav":r for r in sources};seen=set();start=time.monotonic();child=None
def expired(number,frame):raise TimeoutError('Original240s media-copy budget exhausted')
old=signal.signal(signal.SIGALRM,expired);signal.alarm(240)
try:
 with(B/'source-copy.stderr.log').open('x')as err:
  child=subprocess.Popen(SSH+['python3 '+remote],stdout=subprocess.PIPE,stderr=err,start_new_session=True)
  with tarfile.open(fileobj=child.stdout,mode='r|gz')as archive:
   for entry in archive:
    assert entry.isfile() and entry.name in expected and entry.name not in seen
    row=expected[entry.name];assert entry.size==row['source']['bytes'] and entry.size<=9*1024**2
    stream=archive.extractfile(entry);data=stream.read(entry.size+1)
    assert len(data)==entry.size and hashlib.sha256(data).hexdigest()==row['source']['sha256']
    with(dest/entry.name).open('xb')as out:out.write(data)
    seen.add(entry.name);assert shutil.disk_usage(dest).free>=4*1024**3
  child.stdout.close();code=child.wait(timeout=max(1,240-(time.monotonic()-start)))
 assert code==0 and seen==set(expected)
 result=dict(complete=True,sources=len(seen),bytes=sum(r['source']['bytes']for r in sources),all_hashes_verified=True,no_local_archive=True,seconds=time.monotonic()-start,model_started=False,free_bytes_after=shutil.disk_usage(B).free)
except BaseException as error:
 result=dict(complete=False,sources=len(seen),error=dict(type=type(error).__name__,message=str(error)),model_started=False)
 raise
finally:
 signal.alarm(0);signal.signal(signal.SIGALRM,old)
 if child is not None and child.poll()is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=3)
 result['sender_reaped']=child is None or child.poll()is not None
 (B/'source-copy-result-01.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
