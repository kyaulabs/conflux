from pathlib import Path
import hashlib,json,os,subprocess
b=Path(__file__).resolve().parent
for row in json.loads((b/'input-pins.json').read_text())['files']:
 p=b/row['file'];raw=p.read_bytes();assert not p.is_symlink() and len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
r=subprocess.run(['/usr/bin/python3','-E','-s','-B','-m','unittest','discover','-s',str(b),'-p','test_*.py','-v'],capture_output=True,text=True,timeout=20)
(b/'offline-checks.stdout.log').write_text(r.stdout);(b/'offline-checks.stderr.log').write_text(r.stderr)
assert r.returncode==0 and 'Ran 10 tests'in r.stderr and r.stderr.rstrip().endswith('OK')
os.execv('/usr/bin/python3',['python3','-E','-s','-B',str(b/'acquire.py'),'--run'])
