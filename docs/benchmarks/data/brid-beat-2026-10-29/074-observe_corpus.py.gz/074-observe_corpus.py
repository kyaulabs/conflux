"""Read exact existing CPU corpus owners; never score, launch or retry."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
B=Path(__file__).resolve().parent;C=B/'corpus-02';d=json.loads((C/'dispatch.json').read_text())
COMMON=r'''
from pathlib import Path
import json,subprocess
def observe(unit,expected,b,user):
 cmd=['systemctl']+(['--user']if user else[])+['show',unit,'--property=MainPID,InvocationID,ControlGroup,ActiveState,SubState,Result,ExecMainStatus,CPUUsageNSec,MemoryCurrent,MemoryPeak']
 state=dict(x.split('=',1)for x in subprocess.check_output(cmd,text=True,timeout=5).splitlines()if '='in x)
 assert state['InvocationID']==expected
 result=dict(owner=state)
 out=b/'native.stdout.jsonl'
 if out.exists():
  assert out.stat().st_size<=16*1024**2
  lines=out.read_bytes().split(b'\n')[:-1];rows=[json.loads(line)for line in lines]
  result['complete_native_case_rows']=sum(row.get('kind')=='production-bpm-case'for row in rows)
  result['statuses']={status:sum(row.get('analysis_status')==status for row in rows)for status in('Estimated','Unknown','Failed','NotRun')}
  result['stdout_bytes']=out.stat().st_size
 if(b/'result.json').exists():
  result['result']=json.loads((b/'result.json').read_text())
 return result
'''
ns={};exec(COMMON,ns)
local=ns['observe'](d['laptop']['unit'],d['laptop']['owner']['InvocationID'],C/'laptop-output',True)
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','python3 -']
code=COMMON+'\nUNIT='+repr(d['apollo']['unit'])+'\nEXPECTED='+repr(d['apollo']['owner']['InvocationID'])+'\n'+r'''
b=Path('/srv/conflux-tests/work/brid-analysis-20261029-01/corpus-02')
value=observe(UNIT,EXPECTED,b/'work/output',False)
if(b/'closed-result.json').exists():value['closed_result']=json.loads((b/'closed-result.json').read_text())
print(json.dumps(value))
'''
r=subprocess.run(ssh,input=code,text=True,capture_output=True,timeout=20)
if r.returncode:print(r.stderr[-4000:]);r.check_returncode()
remote=json.loads(r.stdout);value=dict(utc=datetime.now(timezone.utc).isoformat(),laptop=local,apollo=remote)
number=len(list(C.glob('observation-*.json')))+1
(C/f'observation-{number:03}.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({host:dict(owner=row['owner'],completed=row.get('complete_native_case_rows',0),statuses=row.get('statuses'),terminal=row.get('result',{}).get('complete'),error=row.get('result',{}).get('error'))for host,row in value.items()if host!='utc'}))
