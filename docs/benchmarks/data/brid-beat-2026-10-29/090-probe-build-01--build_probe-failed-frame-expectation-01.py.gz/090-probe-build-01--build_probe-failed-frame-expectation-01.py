"""Bounded CPU-only compilation of the existing analyzer and corpus adapter."""
from pathlib import Path
import argparse,hashlib,json,os,re,signal,subprocess,time,wave

def pin(p):
    return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def main():
    p=argparse.ArgumentParser()
    for name in ('base','inputs','source','libdir'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();base=a.base.resolve();base.mkdir(mode=0o700)
    inputs=a.inputs.resolve();source=a.source.resolve();libdir=a.libdir.resolve()
    stages={};began=time.monotonic();deadline=began+240
    env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',XDG_CACHE_HOME=str(base/'cache'),TMPDIR=str(base/'tmp'))
    for name in ('tmp','cache','spool'):(base/name).mkdir(mode=0o700)
    pinned={str(q):pin(q)for q in [inputs/'probe.cpp',inputs/'CMakeLists.txt',source/'tests/bpm_analyzer_test.cpp',libdir/'libconflux-library.a',libdir/'libconflux-audio.a']}
    def run(name,command,budget):
        remaining=min(budget,deadline-time.monotonic());assert remaining>0
        start=time.monotonic()
        with(base/(name+'.log')).open('x')as log:
            child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
            try:code=child.wait(timeout=remaining)
            except BaseException:
                if child.poll()is None:
                    os.killpg(child.pid,signal.SIGTERM)
                    try:child.wait(timeout=5)
                    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
                raise
        stages[name]=dict(command=command,exit=code,seconds=time.monotonic()-start,reaped=child.poll()is not None)
        (base/'progress.json').write_text(json.dumps(stages,indent=2)+'\n')
        assert code==0,(name,code)
    def interrupted(number,frame):raise InterruptedError('CPU build interrupted')
    for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,interrupted)
    result=dict(passed=False,model_GPU_audio_output_started=False,physical_readiness_consumed=False,latency_qualified=False)
    try:
        run('configure',['cmake','-S',str(inputs),'-B',str(base/'native'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_FLAGS_RELEASE=-O2 -DNDEBUG','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCONFLUX_EXISTING_LIBDIR='+str(libdir),'-DCONFLUX_EXISTING_SOURCE='+str(source)],40)
        run('build',['cmake','--build',str(base/'native'),'-j','2'],140)
        run('regression',[str(base/'native/bpm-analyzer-test')],70)
        totals=re.search(r'Totals: (\d+) passed, (\d+) failed, (\d+) skipped, (\d+) blacklisted', (base/'regression.log').read_text())
        assert totals and int(totals[1])>0 and tuple(map(int,totals.groups()[1:]))==(0,0,0)
        fixture=base/'thirty-seconds-44100.wav'
        with wave.open(str(fixture),'wb')as out:
            out.setnchannels(2);out.setsampwidth(2);out.setframerate(44100)
            out.writeframes(b'\0'*(30*44100*4))
        assert fixture.stat().st_size>5*1024*1024
        run('long-source',[str(base/'native/brid-production-probe'),'--bpm-prepare',str(base/'spool'),str(fixture)],30)
        rows=[json.loads(line)for line in(base/'long-source.log').read_text().splitlines()]
        assert len(rows)==2 and rows[0]['passed'] and rows[1]['passed']
        assert rows[0]['prepared_frames']==30*48000 and rows[0]['source_sha256']==pin(fixture)['sha256']
        assert rows[0]['analysis_status']=='NotRun' and rows[0]['beats']==[]
        assert not list((base/'spool').iterdir()),'Prepared spool leaked'
        assert all(pin(Path(q))==v for q,v in pinned.items()),'Frozen input changed'
        commands=json.loads((base/'native/compile_commands.json').read_text())
        assert commands and all('-O2'in c['command'] and not any(x in c['command']for x in ('-ffast-math','-Ofast','--coverage','-fprofile-arcs','-ftest-coverage'))for c in commands)
        result.update(passed=True,regression_passed=int(totals[1]),long_source=rows[0],spool_retired=True,inputs_unchanged=True,inputs=pinned,probe=pin(base/'native/brid-production-probe'))
    except BaseException as error:result['error']=dict(type=type(error).__name__,message=str(error))
    finally:
        result.update(stages=stages,seconds=time.monotonic()-began)
        (base/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result.get(k)for k in('passed','regression_passed','seconds','error','latency_qualified')}),flush=True)
    raise SystemExit(0 if result['passed']else 1)

if __name__=='__main__':main()
