// Temporary framework-only diagnostic; no CONFLUX product linked.
#include <QCoreApplication>
#include <QtTest>
#include <cstring>
#include <thread>
#include <chrono>
class WatchdogControl : public QObject {
    Q_OBJECT
private slots:
    void onlyQt() { std::this_thread::sleep_for(std::chrono::milliseconds(10)); QVERIFY(true); }
};
__attribute__((noinline)) void reuseStack() {
    char bytes[16384];
    std::memset(bytes, 0xfe, sizeof bytes);
    asm volatile("" : : "r"(bytes) : "memory");
}
int main(int argc,char**argv) {
    QCoreApplication app(argc,argv);
    WatchdogControl check;
    int result=QTest::qExec(&check,argc,argv);
    reuseStack();
    return result;
}
#include "qt-watchdog-control.moc"
