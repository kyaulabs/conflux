import hashlib,json,os,signal,subprocess,time
from pathlib import Path
b=Path('benchmarks-local/m2-live-delivery-2026-10-19')
meta=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
pins=json.loads((b/'bridge-source-pins.json').read_text())
def verify():
    for name,expected in pins.items(): assert meta(Path(name))==expected,name
    freeze=json.loads((b/'live-bridge-implementation-freeze.json').read_text())
    for f in freeze['files']: assert meta(Path(f['path']))==dict(bytes=f['output_bytes'],sha256=f['output_sha256']),f['path']
verify()
rows=json.loads((b/'bridge-functional-result.json').read_text());assert len(rows)==8 and rows[-1]['stage']=='bridge-tsan-test' and rows[-1]['exit']==8
assert all(row['exit']==0 for row in rows[:-1])
cmd=['benchmarks-local/coverage-venv/bin/python','tools/coverage/run.py','--private-routing','--jobs','2']
start=time.monotonic();timed=False
with (b/'bridge-coverage.log').open('w') as log:
    child=subprocess.Popen(cmd,env=os.environ|{'QT_QPA_PLATFORM':'offscreen','QT_QUICK_BACKEND':'software','QT_QUICK_CONTROLS_STYLE':'Basic'},stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try: code=child.wait(timeout=1500)
    except subprocess.TimeoutExpired:
        timed=True;os.killpg(child.pid,signal.SIGTERM)
        try:code=child.wait(timeout=20)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
row=dict(stage='bridge-coverage',command=cmd,exit=code,timed_out=timed,elapsed_seconds=time.monotonic()-start)
rows.append(row);(b/'bridge-functional-result.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
if code:print((b/'bridge-coverage.log').read_text()[-6000:],flush=True);raise SystemExit(code)
verify()
artifacts=json.loads((b/'bridge-artifact-pins.json').read_text())
for group in artifacts.values():
    for name,expected in group.items():assert meta(Path(name))==expected,name
artifacts['build/coverage']={str(Path('build/coverage')/n):meta(Path('build/coverage')/n) for n in ['conflux','conflux-live-stem-bridge-test','conflux-prepared-track-store-test','conflux-manual-routing-check','conflux-preparation-controller-check']}
(b/'bridge-artifact-pins.json').write_text(json.dumps(artifacts,indent=2)+'\n')
(b/'bridge-source-stable.json').write_text(json.dumps(dict(status='all_pins_unchanged',files=len(pins)),indent=2)+'\n')
