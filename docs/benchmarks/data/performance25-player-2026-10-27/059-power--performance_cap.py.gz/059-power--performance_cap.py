"""Clamp only this laptop's Performance PL1; retain lower thermal limits."""
import json
from pathlib import Path
import signal
import time

PROFILE = Path('/sys/firmware/acpi/platform_profile')
PACKAGE = Path('/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0')
LIMIT_UW = 25_000_000
UNIT = 'conflux-performance-power-cap-25w.service'


def read_integer(name):
    value = int((PACKAGE / name).read_text().strip())
    if value <= 0:
        raise ValueError('Invalid powercap value: ' + name)
    return value


def enforce_once():
    if PROFILE.read_text().strip() != 'performance':
        return None
    if (PACKAGE / 'name').read_text().strip() != 'package-0':
        raise ValueError('Unexpected package domain')
    if (PACKAGE / 'constraint_0_name').read_text().strip() != 'long_term':
        raise ValueError('Unexpected power constraint')
    if read_integer('enabled') != 1:
        raise ValueError('Package power control is disabled')
    if read_integer('constraint_0_max_power_uw') < LIMIT_UW:
        raise ValueError('Requested ceiling exceeds the reported long-term maximum')
    cap = PACKAGE / 'constraint_0_power_limit_uw'
    before = read_integer(cap.name)
    if before <= LIMIT_UW:
        return None
    # Recheck immediately before writing; never intentionally raise a limit.
    if PROFILE.read_text().strip() != 'performance':
        return None
    latest = read_integer(cap.name)
    if latest <= LIMIT_UW:
        return None
    cap.write_text(str(LIMIT_UW) + '\n')
    profile_after = PROFILE.read_text().strip()
    after = read_integer(cap.name)
    # The guard may switch profiles between the last read and our write.
    # Restore the observed firmware's lower preset if that race occurred.
    reductions = {'low-power': 7_500_000, 'balanced': 15_000_000}
    if profile_after in reductions and after > reductions[profile_after]:
        cap.write_text(str(reductions[profile_after]) + '\n')
        after = read_integer(cap.name)
    if profile_after == 'performance' and after > LIMIT_UW:
        raise ValueError('Performance ceiling did not hold after write')
    return {'action': 'performance_ceiling_applied', 'previous_uw': latest,
            'readback_uw': after, 'profile_after': profile_after}


def main():
    stopped = False

    def stop(*_):
        nonlocal stopped
        stopped = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    print(json.dumps({'event': 'started', 'unit': UNIT, 'limit_uw': LIMIT_UW,
                      'scope': 'Performance only; existing lower limits retained'}), flush=True)
    while not stopped:
        result = enforce_once()
        if result is not None:
            print(json.dumps(result), flush=True)
        time.sleep(1)


if __name__ == '__main__':
    main()
