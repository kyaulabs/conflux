"""Bound the authorized firmware transition; no actual profiles or sysfs."""
import copy
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('performance25_policy',
    Path(__file__).resolve().parent / 'cases/baseline/profile_policy.py')
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)


class PerformanceSettleTests(unittest.TestCase):
    def exercise(self, values):
        clock = [1.0]
        key = policy.PERFORMANCE_LIMIT_PATH
        ceiling = {key:25000000, '/offline/enabled':1, '/offline/constraint_0_time_window_us':27983872}
        def read():
            current = values.pop(0) if len(values)>1 else values[0]
            return {**ceiling, **current}
        timing = SimpleNamespace(monotonic=lambda:clock[0],
            sleep=lambda seconds:clock.__setitem__(0,clock[0]+seconds))
        with patch.object(policy, 'power_limits', side_effect=read), patch.object(policy, 'time', timing):
            try:
                value, rows = policy.settle_performance_cap({'power_limits':ceiling}, 20)
                return clock[0], value, rows, None
            except ValueError as error:
                return clock[0], None, None, str(error)

    def test_known64W_preset_must_settle_before_workload(self):
        key = policy.PERFORMANCE_LIMIT_PATH
        clock, values, rows, error = self.exercise([{key:64000000}, {key:25000000}])
        self.assertIsNone(error)
        self.assertEqual(values[key], 25000000)
        self.assertEqual([row['values'][key] for row in rows], [64000000,25000000])
        self.assertAlmostEqual(clock, 1.1)

    def test_persistent64W_setting_is_rejected_within_five_seconds(self):
        clock, values, _, error = self.exercise([{policy.PERFORMANCE_LIMIT_PATH:64000000}])
        self.assertIsNone(values)
        self.assertIn('player must not start', error)
        self.assertLessEqual(clock, 6)

    def test_unknown_ceiling_enable_or_window_changes_are_immediately_fatal(self):
        for values in [{policy.PERFORMANCE_LIMIT_PATH:30000000}, {'/offline/enabled':0},
                       {'/offline/constraint_0_time_window_us':28000000}]:
            with self.subTest(values=values):
                clock, accepted, _, error = self.exercise([values])
                self.assertIsNone(accepted)
                self.assertIsNotNone(error)
                self.assertEqual(clock, 1)

    def test_lower_thermal_limit_is_preserved(self):
        key = policy.PERFORMANCE_LIMIT_PATH
        _, values, rows, error = self.exercise([{key:7500000}])
        self.assertIsNone(error)
        self.assertEqual(values[key], 7500000)
        self.assertEqual(len(rows), 1)


if __name__ == '__main__':unittest.main()
