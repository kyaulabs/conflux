"""Run the same isolated generated replay against the original and fixed harness."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
WORK = Path('/home/kyau/.codex/worktrees/release-tree-guard/conflux')


def main():
    helper = BASE / 'private-regression/pending-recovery-check-02'
    script = WORK / 'tools/experiments/private_routing_check.py'
    results = dict(schema=1, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        generated_service_only=True, host_audio_started=False, GPU_model_started=False, cases={})
    for name, binary, expected in [
            ('red-02', ROOT / 'build/m2-tail-capture-fix-01/native/conflux-manual-playback-soak', False),
            ('green-02', BASE / 'native/conflux-manual-playback-soak', True)]:
        output = BASE / name
        digest = hashlib.sha256(binary.read_bytes()).hexdigest()
        command = [sys.executable, '-B', str(script), str(helper), str(output),
            '--functional-only', '--ui-controls-soak', str(binary), '--soak-sha256', digest]
        began = time.monotonic()
        with (BASE / (name + '.log')).open('xb') as log:
            process = subprocess.run(command, cwd=WORK, stdout=log, stderr=subprocess.STDOUT, timeout=100)
        value = json.loads((output / 'result.json').read_text())
        native = json.loads((output / 'recordings/ui-controls/native-result.json').read_text())
        row = dict(command=command, returncode=process.returncode,
            elapsed_seconds=time.monotonic() - began, expected_regression_pass=expected,
            regression_passed=value['passed'], error=value.get('check', {}).get('error', value.get('error')),
            private_daemon_reaped=value.get('daemon_reaped'),
            graph_clean=value.get('cleanup', {}).get('only_dummy_driver_remains'),
            child_reaped=value.get('check', {}).get('child_reaped'),
            services_gone=value.get('check', {}).get('service_cleanup_proven'),
            native_passed=native.get('passed'), measurement_error=native.get('measurement_completion_error'),
            native_error=native.get('error'), last_recovery_complete=native.get('last_recovery_complete'),
            diagnostic_tail=native.get('diagnostic_tail'))
        results['cases'][name] = row
        (BASE / 'private-regression-results-02.json').write_text(json.dumps(results, indent=2) + '\n')
        print(json.dumps(dict(case=name, expected=expected, regression_passed=value['passed'],
            native_error=native.get('error'), cleaned=row['private_daemon_reaped'] and row['graph_clean'] and
            row['child_reaped'] and row['services_gone'])), flush=True)
        assert value['passed'] is expected and (process.returncode == 0) is expected, row
        assert native.get('passed') is False and native.get('last_recovery_complete') is False, row
        assert native.get('error', '').startswith('Playback/EOF/replay or last scheduled recovery incomplete'), row
        assert row['private_daemon_reaped'] and row['graph_clean'] and row['child_reaped'] and row['services_gone'], row
    results['passed'] = True
    (BASE / 'private-regression-results-02.json').write_text(json.dumps(results, indent=2) + '\n')
    print('The original harness loses the pending tail; the fixed harness captures it while retaining the failed boundary.')


if __name__ == '__main__':
    main()
