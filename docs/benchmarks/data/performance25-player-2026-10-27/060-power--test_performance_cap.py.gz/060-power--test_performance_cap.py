"""Offline power-policy behavior; no access to real sysfs or services."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('performance_cap',
    Path(__file__).with_name('performance_cap.py'))
capper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capper)


class PerformanceCapTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.profile = self.base / 'platform_profile'
        self.package = self.base / 'package'
        self.package.mkdir()
        self.profile.write_text('performance\n')
        for name, value in {'name': 'package-0', 'constraint_0_name': 'long_term',
                'constraint_0_max_power_uw': '28000000', 'enabled': '1',
                'constraint_0_power_limit_uw': '64000000',
                'constraint_0_time_window_us': '27983872',
                'constraint_1_power_limit_uw': '64000000'}.items():
            (self.package / name).write_text(value + '\n')
        self.addCleanup(patch.stopall)
        patch.object(capper, 'PROFILE', self.profile).start()
        patch.object(capper, 'PACKAGE', self.package).start()

    def test_caps_performance_and_preserves_other_constraints(self):
        before = {p.name: p.read_bytes() for p in self.package.iterdir()}
        result = capper.enforce_once()
        self.assertEqual(result['readback_uw'], 25000000)
        for name, raw in before.items():
            if name != 'constraint_0_power_limit_uw':
                self.assertEqual((self.package / name).read_bytes(), raw)
        self.assertIsNone(capper.enforce_once())

    def test_never_raises_an_existing_lower_limit(self):
        for limit in (7500000, 15000000, 20000000, 25000000):
            with self.subTest(limit=limit):
                path = self.package / 'constraint_0_power_limit_uw'
                path.write_text(str(limit) + '\n')
                with patch.object(Path, 'write_text', side_effect=AssertionError('Unexpected write')):
                    self.assertIsNone(capper.enforce_once())
                self.assertEqual(int(path.read_text()), limit)

    def test_other_profiles_are_untouched(self):
        for profile in ('balanced', 'low-power', 'unknown'):
            with self.subTest(profile=profile):
                self.profile.write_text(profile + '\n')
                with patch.object(Path, 'write_text', side_effect=AssertionError('Unexpected write')):
                    self.assertIsNone(capper.enforce_once())

    def test_invalid_or_disabled_domain_fails_before_write(self):
        cases = [('name', 'other-package'), ('constraint_0_name', 'short_term'),
                 ('enabled', '0'), ('constraint_0_max_power_uw', '20000000'),
                 ('constraint_0_power_limit_uw', '0'),
                 ('constraint_0_power_limit_uw', 'unreadable')]
        for name, bad in cases:
            path = self.package / name
            saved = path.read_bytes()
            path.write_text(bad + '\n')
            with self.subTest(name=name, bad=bad), \
                    patch.object(Path, 'write_text', side_effect=AssertionError('Unexpected write')):
                with self.assertRaises(ValueError):
                    capper.enforce_once()
            path.write_bytes(saved)

    def test_profile_change_before_write_is_respected(self):
        original = Path.read_text
        calls = 0

        def read(path, *args, **kwargs):
            nonlocal calls
            if path == self.profile:
                calls += 1
                return 'performance' if calls == 1 else 'low-power'
            return original(path, *args, **kwargs)

        with patch.object(Path, 'read_text', read), \
                patch.object(Path, 'write_text', side_effect=AssertionError('Unexpected write')):
            self.assertIsNone(capper.enforce_once())

    def test_guard_lowering_limit_before_write_is_not_undone(self):
        original = capper.read_integer
        calls = 0

        def read(name):
            nonlocal calls
            if name == 'constraint_0_power_limit_uw':
                calls += 1
                if calls == 2:
                    return 7500000
            return original(name)

        with patch.object(capper, 'read_integer', read), \
                patch.object(Path, 'write_text', side_effect=AssertionError('Unexpected write')):
            self.assertIsNone(capper.enforce_once())

    def test_guard_transition_during_write_restores_lower_profile(self):
        original = Path.write_text
        for profile, limit in [('low-power', 7500000), ('balanced', 15000000)]:
            self.profile.write_text('performance\n')
            target = self.package / 'constraint_0_power_limit_uw'
            target.write_text('64000000\n')

            def write(path, text, *args, **kwargs):
                result = original(path, text, *args, **kwargs)
                if path == target and text.strip() == '25000000':
                    original(self.profile, profile + '\n')
                return result

            with self.subTest(profile=profile), patch.object(Path, 'write_text', write):
                result = capper.enforce_once()
            self.assertEqual(result['readback_uw'], limit)
            self.assertEqual(int(target.read_text()), limit)


if __name__ == '__main__':
    unittest.main()
