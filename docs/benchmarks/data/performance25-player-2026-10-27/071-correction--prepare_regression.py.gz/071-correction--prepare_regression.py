"""Construct a temporary actual-harness replay regression on private audio only."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys

BASE = Path(__file__).resolve().parent
WORK = Path('/home/kyau/.codex/worktrees/release-tree-guard/conflux')


def once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after, 1)


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    directory = BASE / 'private-regression'
    directory.mkdir(exist_ok=True)
    header = (WORK / 'tests/StemServiceFixture.hpp').read_text()
    header = once(header, '#include "StemExportFixture.hpp"',
        '#include ' + json.dumps(str(WORK / 'tests/StemExportFixture.hpp')))
    header = once(header, '            emit(accepted)\n            if closing: break',
        '''            emit(accepted)
            if kind in ['load', 'seek'] and generation == 3:
                marker('.recovery-wait').touch()
                time.sleep(4)
            if closing: break''')
    # Keep the existing generated fixture and protocol; delay only the last
    # replay beyond the ten-second functional measurement boundary.
    (directory / 'StemServiceFixture-02.hpp').write_text(header)
    helper = (WORK / 'tools/experiments/preparation_controller_check.cpp').read_text()
    helper = once(helper, '#include "../../tests/StemExportFixture.hpp"',
        '#include ' + json.dumps(str(WORK / 'tests/StemExportFixture.hpp')))
    helper = once(helper, '#include "../../tests/StemServiceFixture.hpp"',
        '#include ' + json.dumps(str(directory / 'StemServiceFixture-02.hpp')))
    helper = once(helper,
        '        if (childStarted && (child.exitStatus() != QProcess::NormalExit || child.exitCode() != 0)) fail("Owned soak child failed");',
        '        if (childStarted && (child.exitStatus() != QProcess::NormalExit || child.exitCode() != 1)) fail("Pending-recovery child must retain failed exit1");')
    helper = once(helper,
        '            if (!document.isObject() || !native["passed"].toBool() || native["mode"].toString() != "live-stems-controls" ||',
        '            if (!document.isObject() || native["passed"].toBool() || native["mode"].toString() != "live-stems-controls" ||')
    helper = once(helper,
        '                throw std::runtime_error("Functional actual-UI sequence/health/cleanup did not pass");',
        '''                throw std::runtime_error("Functional actual-UI sequence/health/cleanup did not pass");
            const auto tail = native["diagnostic_tail"].toObject();
            const auto expected = QString("Playback/EOF/replay or last scheduled recovery incomplete");
            if (native["measurement_completion_error"].toString() != expected ||
                !native["error"].toString().startsWith(expected) || native["last_recovery_complete"].toBool() ||
                !native["measurement_intervals_closed"].toBool() ||
                tail["status"].toString() != "Failed" ||
                !tail["raw_complete"].toBool() || !tail["converter_complete"].toBool() || !tail["render_eof"].toBool() ||
                tail["drain_state"].toInt() != int(conflux::library::LiveStemObservations::DiagnosticDrainState::ReadyForStop) ||
                tail["validated_hops_end"].toInteger() <= tail["validated_hops_begin"].toInteger() ||
                tail["recording_written_frames_begin"].toInteger(-1) != tail["recording_written_frames_end"].toInteger(-2) ||
                tail["measured_wall_ms_begin"].toInteger(-1) != tail["measured_wall_ms_end"].toInteger(-2) ||
                tail["measured_output_end_begin"].toInteger(-1) != tail["measured_output_end_end"].toInteger(-2))
                throw std::runtime_error("Pending measured replay lost its failure, finite tail, WAV boundary or full close");''')
    helper = once(helper, 'const QStringList arguments{"--live-stems-controls",',
        'const QStringList arguments{"--live-stems",')
    helper = once(helper, 'native["mode"].toString() != "live-stems-controls"',
        'native["mode"].toString() != "live-stems"')
    helper = once(helper,
        '                !native["manual_controls_complete"].toBool() || native["manual_controls"].toArray().size() != 16 ||\n', '')
    source = directory / 'pending_recovery_check-02.cpp'
    source.write_text(helper)
    native = BASE / 'native'
    commands = json.loads((native / 'compile_commands.json').read_text())
    command = next(c for c in commands if c['file'].endswith('/tools/experiments/preparation_controller_check.cpp'))
    tokens = shlex.split(command['command'])
    obj = directory / 'pending_recovery_check-02.cpp.o'
    tokens[tokens.index('-o') + 1] = str(obj)
    tokens[tokens.index('-c') + 1] = str(source)
    with (directory / 'compile-02.log').open('xb') as log:
        result = subprocess.run(tokens, cwd=command['directory'], stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        print((directory / 'compile-02.log').read_text()[-5000:]);sys.exit(result.returncode)
    lines = subprocess.check_output(['ninja', '-t', 'commands', 'conflux-preparation-controller-check'], cwd=native, text=True).splitlines()
    link = shlex.split(lines[-1])
    assert link[:2] == [':', '&&'] and link[-2:] == ['&&', ':']
    link = link[2:-2]
    original = 'CMakeFiles/conflux-preparation-controller-check.dir/tools/experiments/preparation_controller_check.cpp.o'
    assert link.count(original) == 1
    link[link.index(original)] = str(obj)
    binary = directory / 'pending-recovery-check-02'
    link[link.index('-o') + 1] = str(binary)
    with (directory / 'link-02.log').open('xb') as log:
        result = subprocess.run(link, cwd=native, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        print((directory / 'link-02.log').read_text()[-5000:]);sys.exit(result.returncode)
    receipt = dict(schema=1, generated_fixture_only=True, native_started=False,
        model_started=False, host_audio_started=False,
        source=pin(source), service_fixture=pin(directory / 'StemServiceFixture-02.hpp'),
        compile=tokens, link=link, binary=pin(binary),
        scope='Actual private native ten-second playback. Third generated generation delays four seconds; pending boundary must remain failed while later finite hops/close and fixed WAV boundary are retained.')
    (directory / 'build-receipt-02.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(compiled=True, binary=str(binary), model_started=False)))


if __name__ == '__main__':
    main()
