"""Replay the observed setup spike; no real sensors, settings or workloads."""
import copy
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent


def load_fixture(directory, name):
    spec = importlib.util.spec_from_file_location(name, directory / 'test_host_player.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class SetupAdmissionTests(unittest.TestCase):
    def exercise(self, fixture, *, sensor='capture_temps', persistent=False, mutation=None):
        plan, clock, state, timing, loader = fixture.AdmissionTests.setup_mock(self, temp=50000)
        plan['requested_power_profile'] = 'performance'
        report = {}
        with patch.object(fixture.driver, 'load_source', side_effect=loader), \
                patch.object(fixture.driver, 'time', timing):
            fresh, recovery, cooldown = fixture.driver.prepare_admission(plan, report, 500, 1, lambda: None)
            recovery(); cooldown()
            state.update(profile='performance', platform='performance', epp='performance', observed_temp=63000)
            if persistent:
                state['temp'] = 74000
            else:
                state[sensor] = [74000, 50000]
            if mutation:
                state.update(mutation)
            result = None
            try:
                result = fresh('public_readiness_before_setup')
            except ValueError as error:
                return report, clock[0], str(error), result
        return report, clock[0], None, result

    def test_observed74C_setup_spike_fails_old_packet_and_settles_in_new_packet(self):
        previous = load_fixture(BASE.parent / 'm2-waveform-player-comparison-03/cases/baseline', 'old_setup_fixture')
        current = load_fixture(BASE / 'cases/baseline', 'new_setup_fixture')
        old, old_clock, old_error, _ = self.exercise(previous)
        self.assertIn('observer=74C, host=63C', old_error)
        self.assertEqual(old_clock, 61)
        for sensor in ['capture_temps', 'observed_temps']:
            with self.subTest(sensor=sensor):
                report, clock, error, accepted = self.exercise(current, sensor=sensor)
                self.assertIsNone(error)
                self.assertTrue(accepted['accepted'])
                rows = report['fresh_admissions']
                self.assertEqual(len(rows), 2)
                self.assertEqual(rows[0]['rejection_kind'], 'temperature_only')
                self.assertFalse(rows[0]['accepted'])
                self.assertEqual(clock, 62)
                self.assertEqual(report['cooldown_deadline'], 301)

    def test_sustained_setup_heat_remains_failed_within_five_seconds(self):
        current = load_fixture(BASE / 'cases/baseline', 'sustained_setup_fixture')
        report, clock, error, accepted = self.exercise(current, persistent=True)
        self.assertIsNone(accepted)
        self.assertIn('heat-only', error)
        self.assertLessEqual(clock, 66)
        self.assertTrue(all(not row['accepted'] for row in report['fresh_admissions']))

    def test_setup_heat_does_not_hide_changed_guard_or_power_or_hold(self):
        current = load_fixture(BASE / 'cases/baseline', 'fatal_setup_fixture')
        for change in [{'invocation':'b'*32}, {'ac':False}, {'lid':False}, {'holds':'unrelated hold'}]:
            with self.subTest(change=change):
                report, clock, error, accepted = self.exercise(current, mutation=change)
                self.assertIsNotNone(error)
                self.assertIsNone(accepted)
                self.assertEqual(clock, 61)
                self.assertEqual(report['fresh_admissions'][0]['rejection_kind'], 'fatal')


if __name__ == '__main__':unittest.main()
