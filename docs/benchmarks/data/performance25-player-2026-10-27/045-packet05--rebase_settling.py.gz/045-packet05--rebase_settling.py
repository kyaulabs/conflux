"""Reuse the closed packet and native builds; repair all fresh heat checks offline."""
from pathlib import Path
import ast
import hashlib
import json
import re
import shutil

BASE = Path(__file__).resolve().parent
OLD = BASE.parent / 'm2-waveform-player-comparison-04'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def rebase(text):
    return (text.replace(str(OLD), str(BASE))
        .replace('m2-waveform-cache-performance25-visible-120-04-',
                 'm2-waveform-cache-performance25-visible-120-05-')
        .replace('conflux-m2-waveform-cache-20261027-04-',
                 'conflux-m2-waveform-cache-20261027-05-'))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def refresh_pins(value):
    if isinstance(value, list):
        return [refresh_pins(item) for item in value]
    if not isinstance(value, dict):
        return value
    result = {key: refresh_pins(item) for key, item in value.items()}
    if {'path', 'bytes', 'sha256'} <= result.keys():
        path = Path(result['path'])
        if path.is_relative_to(BASE):
            result.update(pin(path))
    return result


def main():
    assert json.loads((OLD / 'pair-closed-01.json').read_text())['both_units_not_found']
    assert not (BASE / 'cases').exists()
    # Only source/helper files and immutable input manifests are reused. Run
    # records, physical readiness, output, unit dispatch and verdicts are not.
    for source in OLD.glob('*.py'):
        target = BASE / source.name
        assert not target.exists()
        target.write_text(rebase(source.read_text()))
    for name in ['build-pair-receipt-01.json', 'limiter-binding-01.json']:
        (BASE / name).write_text(rebase((OLD / name).read_text()))
    for arm in ['baseline', 'candidate']:
        source = OLD / 'cases' / arm
        case = BASE / 'cases' / arm
        case.mkdir(parents=True)
        for path in source.glob('*.py'):
            (case / path.name).write_text(rebase(path.read_text()))
        for name in ['plan.json', 'root-launch-plan-01.json', 'build-receipt-01.json',
                     'source-build-attestation-01.json', 'driver-cache-initial-01.json',
                     'launch-command-01.txt']:
            (case / name).write_text(rebase((source / name).read_text()))
        (BASE / arm).mkdir()
        (BASE / arm / 'source-manifest-01.json').write_bytes(
            (OLD / arm / 'source-manifest-01.json').read_bytes())
        shutil.copytree(source / 'driver-cache', case / 'driver-cache')

        path = case / 'run_host_player.py'
        driver = path.read_text()
        old = "        settling=final or label=='public_readiness_before_setup'"
        assert driver.count(old) == 1
        driver = driver.replace(old, """        settling=label in ('cooldown_complete','before_dispatch',
            'public_readiness_before_setup','public_readiness_before_Popen')""")
        assert driver.count('<=35+2*(FINAL_SETTLE_PAIRS-1)') == 1
        assert driver.count('<=4+2*(FINAL_SETTLE_PAIRS-1)') == 1
        driver = driver.replace('<=35+2*(FINAL_SETTLE_PAIRS-1)', '<=35+4*(FINAL_SETTLE_PAIRS-1)')
        driver = driver.replace('<=4+2*(FINAL_SETTLE_PAIRS-1)', '<=4+4*(FINAL_SETTLE_PAIRS-1)')
        path.write_text(driver)
        owner_path = case / 'run_player_owned.py'
        owner, count = re.subn(r'^LAUNCHER_SHA = .*$',
            'LAUNCHER_SHA = ' + repr(pin(path)['sha256']),
            owner_path.read_text(), count=1, flags=re.M)
        assert count == 1
        owner_path.write_text(owner)
        owner_path.chmod(0o755)

        receipt_path = case / 'build-receipt-01.json'
        write_json(receipt_path, refresh_pins(json.loads(receipt_path.read_text())))
        attestation_path = case / 'source-build-attestation-01.json'
        attestation = refresh_pins(json.loads(attestation_path.read_text()))
        attestation['build_receipt_sha256'] = pin(receipt_path)['sha256']
        write_json(attestation_path, attestation)

        plan_path = case / 'plan.json'
        plan = refresh_pins(json.loads(plan_path.read_text()))
        plan['status'] = 'draft_unarmed_pending_root_review'
        plan['sources']['all_fresh_settling_patch'] = pin(Path(__file__).resolve())
        plan['sources']['all_fresh_settling_regression'] = pin(BASE / 'test_all_fresh_settling.py')
        plan['fresh_temperature_settling_scope'] = (
            'The same 5-second/6-pair heat-only allowance at each of the four '
            'fresh checks. Both readings must reach <=70C. Non-heat faults fail '
            'immediately. All original owner/native/operator deadlines remain.')
        write_json(plan_path, plan)
        launch_path = case / 'root-launch-plan-01.json'
        launch = refresh_pins(json.loads(launch_path.read_text()))
        write_json(launch_path, launch)
    for path in BASE.rglob('*.py'):
        ast.parse(path.read_text(), filename=str(path))
    write_json(BASE / 'packet-preparation-01.json', dict(schema=1,
        prior_failed_packet=str(OLD), reused_immutable_native_builds=True,
        only_admission_heat_settling_changed=True, performance_ceiling_uw=25000000,
        strict_fresh_temperature_ceiling_millidegrees_C=70000,
        original_pair_operator_seconds=1200, per_arm_command_seconds=540,
        player_started=False, model_started=False, readiness_created=False))
    print('Both cases are unarmed; same native builds and 25 W policy, all four fresh heat checks bounded.')


if __name__ == '__main__':
    main()
