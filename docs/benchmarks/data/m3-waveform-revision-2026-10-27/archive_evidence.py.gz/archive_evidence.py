"""Retain functional waveform-cache evidence as checksum-bound UTF-8 files."""
import gzip
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
TARGET = BASE/'stage/docs/benchmarks/data/m3-waveform-revision-2026-10-27'
RAW = BASE/'uncompressed-review-01'
TARGET.mkdir(parents=True, exist_ok=False)
RAW.mkdir(mode=0o700)
names = ['ui-red-01.log', 'ui-green-01.log', 'ui-full-01.log',
         'controller-focused-01.log', 'controller-full-01.log',
         'configure-01.log', 'build-ui-red-01.log', 'build-controller-01.log',
         'verification-01.json', 'archive_evidence.py']
records = []
for name in names:
    raw = (BASE/name).read_bytes()
    raw.decode('utf-8')
    with (RAW/name).open('xb') as stream:
        stream.write(raw)
    packed = gzip.compress(raw, mtime=0)
    with (TARGET/(name+'.gz')).open('xb') as stream:
        stream.write(packed)
    records.append(dict(file=name+'.gz', bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                        gzip_bytes=len(packed), gzip_sha256=hashlib.sha256(packed).hexdigest(),
                        private_source=str((BASE/name).relative_to(BASE.parents[1]))))
with (TARGET/'manifest.json').open('x') as stream:
    stream.write(json.dumps(dict(schema=1, scope='Functional regression and build evidence only; no laptop performance measurement',
                                records=records, compressed_bytes=sum(r['gzip_bytes'] for r in records),
                                omitted=['Compiled executables and libraries', 'Media', 'Models', 'Installed dependencies'],
                                laptop_latency_qualified=False, M2_complete=False, M3_complete=False,
                                source_snapshots='Product and fixture sources are committed with this evidence; per-file hashes are in verification-01.json.gz.'),
                            indent=2)+'\n')
print(json.dumps(dict(files=len(records),compressed_bytes=sum(r['gzip_bytes'] for r in records))))
