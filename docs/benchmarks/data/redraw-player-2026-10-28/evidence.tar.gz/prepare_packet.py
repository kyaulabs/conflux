"""Prepare a signed-source16/50ms diagnostic; no readiness or workloads."""
from pathlib import Path
import ast,copy,hashlib,json,re,shutil,subprocess
ROOT=Path('/home/kyau/projects/kyaulabs/conflux');BASE=Path(__file__).resolve().parent
OLD=ROOT/'build/m2-waveform-player-comparison-07'
def pin(p):
 data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(p,v):
 with p.open('x') as f:f.write(json.dumps(v,indent=2,allow_nan=False)+'\n')
def change(s,old,new):
 assert s.count(old)==1,(old,s.count(old));return s.replace(old,new)
def constant(s,name,value):
 s,n=re.subn(r'^'+re.escape(name)+r' = .*$',name+' = '+value,s,count=1,flags=re.M);assert n==1;return s
binding=json.loads((BASE/'approved-build-binding-01.json').read_text())
assert binding['built_from_signed_source'] is True and binding['source_review_complete'] is True
source=BASE/'source';native=BASE/'native';manifest=json.loads((BASE/'source-manifest-01.json').read_text())
assert binding['source_head']==manifest['source_head'] and pin(native/'conflux-manual-playback-soak')==binding['binary']
assert manifest['source_signature']=='G'
for row in manifest['files']:assert pin(Path(row['path']))=={k:row[k] for k in ['path','bytes','sha256']}
for name in ['launch_case.py','pair_clock.py','test_pair_clock.py','test_owner_entry.py','test_all_fresh_settling.py','test_failed_recovery_capture.py','drm_usage.py','test_drm_usage.py','check_desktop_entry.py']:
 (BASE/name).write_bytes((OLD/name).read_bytes())
for arm in ['baseline','candidate']:
 normal=arm=='candidate';before=OLD/'cases/candidate';case=BASE/'cases'/arm;case.mkdir(parents=True,exist_ok=False)
 old_plan=json.loads((before/'plan.json').read_text());old_source=Path(old_plan['source_root'])
 for file in before.glob('*.py'):
  text=file.read_text()
  if file.name=='run_host_player.py':
   for key,value in {'W':'Path('+repr(str(source))+')','SOURCE_HEAD':repr(binding['source_head']),
    'WRAPPER_SHA':repr(pin(source/'tools/experiments/run_manual_playback_soak.py')['sha256']),
    'BINARY':'Path('+repr(str(native/'conflux-manual-playback-soak'))+')','BINARY_SHA':repr(binding['binary']['sha256']),
    'MODE':repr('m2-redraw-interval-balanced-visible-120-01-'+arm),'ARM':repr(arm),
    'COMPILE_COMMANDS_COUNT':str(binding['compile_commands_count'])}.items():text=constant(text,key,value)
   text=change(text,'ARM = '+repr(arm),'ARM = '+repr(arm)+'\nNORMAL_REDRAW = '+repr(normal))
   text=change(text,"plan.get('seconds')==120 and plan.get('qualified') is False", "plan.get('seconds')==120 and plan.get('normal_redraw') is NORMAL_REDRAW and type(plan.get('forced_redraw_interval_ms')) is int and plan['forced_redraw_interval_ms']==(50 if NORMAL_REDRAW else 16) and plan.get('qualified') is False")
   text=change(text,'actions=wrapper.validate_active_controls(n,o)','actions=wrapper.validate_active_controls(n,o,normal_redraw=NORMAL_REDRAW)')
   anchor="        report['measurement']=validate_measurement(result['native'])"
   guard="        require(native.get('mode')==('live-stems-controls-normal-redraw' if NORMAL_REDRAW else 'live-stems-controls') and\n            type(native.get('forced_redraw_interval_ms')) is int and native['forced_redraw_interval_ms']==(50 if NORMAL_REDRAW else 16),\n            'Native forced redraw mode/cadence differs; failed populations cannot change the comparison factor')\n"
   text=change(text,anchor,guard+anchor)
   text=change(text,'active_controls=True,output=OUTPUT,readiness_decision=HUMAN)','active_controls=True,normal_redraw=NORMAL_REDRAW,output=OUTPUT,readiness_decision=HUMAN)')
   text=text.replace('one waveform-cache comparison arm at Best quality.','one forced-redraw comparison arm at Best quality.').replace('only the waveform revision/cache code differs','only the forced redraw interval differs')
  elif file.name=='test_host_player.py':
   text=change(text,'native = {"mode": "live-stems-controls", "passed": True,','native = {"mode": "live-stems-controls-normal-redraw" if driver.NORMAL_REDRAW else "live-stems-controls",\n            "forced_redraw_interval_ms": 50 if driver.NORMAL_REDRAW else 16, "passed": True,')
   text=change(text,"result['active_controls']=controls_wrapper.validate_active_controls(native,observations)","result['active_controls']=controls_wrapper.validate_active_controls(native,observations,normal_redraw=driver.NORMAL_REDRAW)")
   assert text.count('self.assertTrue(args.active_controls);self.assertFalse(args.background)')==2
   text=text.replace('self.assertTrue(args.active_controls);self.assertFalse(args.background)','self.assertTrue(args.active_controls);self.assertFalse(args.background);self.assertIs(args.normal_redraw,driver.NORMAL_REDRAW)')
  (case/file.name).write_text(text)
 (case/'run_player_owned.py').chmod(0o755)
 owner=case/'run_player_owned.py';owner.write_text(constant(owner.read_text(),'LAUNCHER_SHA',repr(pin(case/'run_host_player.py')['sha256'])))
 (case/'launch-command-01.txt').write_text((before/'launch-command-01.txt').read_text().replace(str(before),str(case)))
 # Copy the original equal untouched seed, never the mutated cache of either07 run.
 shutil.copytree(OLD.parent/'m2-waveform-player-comparison-06/cases/candidate/driver-cache',case/'driver-cache')
 (case/'driver-cache-initial-01.json').write_bytes((OLD.parent/'m2-waveform-player-comparison-06/cases/candidate/driver-cache-initial-01.json').read_bytes())
 plan=copy.deepcopy(old_plan);plan.update(status='draft_unarmed_pending_root_review',mode='m2-redraw-interval-balanced-visible-120-01-'+arm,
  arm=arm,normal_redraw=normal,forced_redraw_interval_ms=50 if normal else 16,
  source_root=str(source),source_head=binding['source_head'],runtime_ui_source_root=str(source),ui_arm='candidate',
  comparison_factor='Forced window.update request interval16vs50ms only; same executable, product UI, audio and runtime.',
  workload_scope='Two unqualified120s Best-quality visible control diagnostics, same binary. Default16ms stress result and explicit50ms diagnostic remain distinct; no gate waiver.',
  source_publication_scope=binding['source_publication_scope'])
 plan['mesa_shader_cache']['path']=str(case/'driver-cache')
 for key in ['binary','service','worker','exporter']:
  plan['assets'][key]=binding['binary'] if key=='binary' else pin(source/'tools/stems'/Path(plan['assets'][key]['path']).name)
 for key,p in [('wrapper',source/'tools/experiments/run_manual_playback_soak.py'),('build_cache',native/'CMakeCache.txt'),('compile_commands',native/'compile_commands.json')]:plan['helpers'][key]=pin(p)
 for key,row in plan['helpers'].items():
  old=Path(row['path'])
  if old.is_relative_to(OLD) and (BASE/old.relative_to(OLD)).is_file():plan['helpers'][key]=pin(BASE/old.relative_to(OLD))
 source_pins=[pin(source/Path(row['path']).relative_to(old_source)) for row in plan['source_pins']]
 sources={row['path']:row for row in source_pins}
 for key,row in plan['sources'].items():
  if Path(key).is_absolute():continue
  path=Path(row['path'])
  if path.is_relative_to(before) and (case/path.relative_to(before)).is_file():path=case/path.relative_to(before)
  elif path.is_relative_to(OLD) and (BASE/path.relative_to(OLD)).is_file():path=BASE/path.relative_to(OLD)
  sources[key]=pin(path)
 for key in ['balanced_packet_preparer','waveform_pair_preparer','waveform_pair_builder','waveform_source_manifest','initial_driver_cache_manifest','refresh_pins.py','run_offline_checks.py','freeze_packet.py']:
  sources.pop(key,None)
 sources.update(redraw_packet_preparer=pin(Path(__file__).resolve()),redraw_build_binding=pin(BASE/'approved-build-binding-01.json'),redraw_source_manifest=pin(BASE/'source-manifest-01.json'),initial_driver_cache_manifest=pin(case/'driver-cache-initial-01.json'))
 plan['source_pins']=source_pins;plan['sources']=sources
 build=dict(refresh_exit=0,all_compiles_O2_without_coverage_or_fast_math=True,compile_commands_count=binding['compile_commands_count'],source_head=binding['source_head'],source_root=str(source),binary=plan['assets']['binary'],cache=plan['helpers']['build_cache'],compile_commands=plan['helpers']['compile_commands'])
 save(case/'build-receipt-01.json',build);plan['build_receipt']=pin(case/'build-receipt-01.json')
 proof=dict(source_root=str(source),source_head=binding['source_head'],binary=plan['assets']['binary'],source_pins=source_pins,build_receipt_sha256=plan['build_receipt']['sha256'],tracked_sources_match_head=True,build_completed_from_pinned_source=True,runtime_UI_matches_fixed_meter_snapshot=True,complete_source_manifest=pin(BASE/'source-manifest-01.json'))
 save(case/'source-build-attestation-01.json',proof);plan['source_build_attestation']=pin(case/'source-build-attestation-01.json');save(case/'plan.json',plan)
 launch=json.loads((before/'root-launch-plan-01.json').read_text());oldunit=launch['unit'];unit='conflux-m2-redraw-balanced-20261028-01-'+arm+'.service';launch.update(unit=unit,source_head=binding['source_head'],plan=pin(case/'plan.json'),idle_inhibition_scope=str(case/'run_player_owned.py'));launch['command']=[v.replace(str(before),str(case)).replace(oldunit,unit) for v in launch['command']];save(case/'root-launch-plan-01.json',launch)
 for p in case.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
save(BASE/'packet-preparation-01.json',dict(source_head=binding['source_head'],factor='forced redraw request interval16vs50ms',same_binary=binding['binary'],no_readiness_or_physical_launch=True,Best_quality_unchanged=True,laptop_gate_retained=True,profile_or_cap_writes=False,hard_cancellation_exercised=False,qualified=False))
print('Both draft redraw cases prepared. No readiness, player, model or physical audio started.')
