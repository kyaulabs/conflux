"""Check the draft launch paths without readiness or hardware/model workloads."""
from pathlib import Path
import json
import subprocess
import time

BASE = Path(__file__).resolve().parent
report = dict(schema=1, arms={}, details={}, readiness_created=False,
              player_or_model_benchmark_started=False)


def run(name, command):
    began = time.monotonic()
    path = BASE / (name + '.log')
    with path.open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    row = dict(passed=result.returncode == 0, exit=result.returncode,
               seconds=time.monotonic() - began, log=str(path))
    print(json.dumps(dict(name=name, **row)), flush=True)
    if result.returncode:
        print(path.read_text()[-4000:], flush=True)
    return row


for arm in ('baseline', 'candidate'):
    case = BASE / 'cases' / arm
    report['arms'][arm] = {}
    report['details'][arm] = {}
    for name, command in (
        ('offline_core', ['python', '-B', '-m', 'unittest', 'discover', '-s', str(case), '-p', 'test_*.py', '-v']),
        ('file_verification', ['python', '-B', str(case / 'run_host_player.py'), '--verify-files'])):
        row = run(arm + '-' + name + '-01', command)
        report['arms'][arm][name] = row['passed']
        report['details'][arm][name] = row
        if not row['passed']:
            break
    if not all(report['arms'][arm].values()):
        break
if len(report['arms']) == 2 and all(all(v.values()) for v in report['arms'].values()):
    # The real owner-entry test needs the finalized clearance, so run it after freezing.
    code = "import pathlib,sys,unittest;p=pathlib.Path(sys.argv[1]);sys.path.insert(0,str(p));s=unittest.defaultTestLoader.discover(str(p),pattern='test_*.py');f=lambda t:unittest.TestSuite(f(x) for x in t if not (isinstance(x,unittest.TestCase) and x.__class__.__name__=='ActualFrozenOwnerTests')) if isinstance(t,unittest.TestSuite) else t;r=unittest.TextTestRunner(verbosity=2).run(f(s));raise SystemExit(0 if r.wasSuccessful() else 1)"
    report['root_offline'] = run('draft-root-offline-01', ['python', '-B', '-c', code, str(BASE)])
report['passed'] = (set(report['arms']) == {'baseline', 'candidate'}
                    and all(set(v) == {'offline_core', 'file_verification'} and all(v.values())
                            for v in report['arms'].values())
                    and report.get('root_offline', {}).get('passed') is True)
with (BASE / 'offline-checks-01.json').open('x') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
raise SystemExit(0 if report['passed'] else 1)
