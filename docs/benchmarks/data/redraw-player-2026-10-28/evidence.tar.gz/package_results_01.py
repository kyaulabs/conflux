"""Package completed diagnostic text; omit audio, weights and generated arrays."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')


def package(base, selection, extra=()):
    output = base / 'publication-input'
    assert not output.exists()
    paths = []
    for path in base.rglob('*'):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(base)
        if set(relative.parts).intersection(selection['excluded_directories']):
            continue
        if path.suffix not in ('.py', '.json', '.jsonl', '.txt', '.log') and path.name != 'Dockerfile':
            continue
        paths.append(path)
    members = {str(path.relative_to(base)): path.read_bytes() for path in paths}
    for name, path in extra:
        assert name not in members
        members[name] = path.read_bytes()
    members['publication-selection.json'] = (json.dumps(selection, indent=2) + '\n').encode()
    output.mkdir()
    rows = []
    for name, raw in sorted(members.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        raw.decode('utf8')
        path = output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        rows.append(dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
    manifest = dict(schema=1, source=selection['source'], selection=selection, files=rows)
    raw_manifest = (json.dumps(manifest, indent=2) + '\n').encode()
    (output / 'manifest.json').write_bytes(raw_manifest)
    archive = base / 'results-evidence-01.tar.gz'
    with archive.open('xb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as tar:
                for name, raw in sorted({**members, 'manifest.json': raw_manifest}.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(raw), 0o600, 0
                    tar.addfile(info, io.BytesIO(raw))
    with tarfile.open(archive, 'r:gz') as tar:
        assert len(tar.getmembers()) == len(rows) + 1
        assert all(row.isfile() for row in tar.getmembers())
        for row in rows:
            raw = tar.extractfile(row['path']).read()
            assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        assert tar.extractfile('manifest.json').read() == raw_manifest
    receipt = dict(files=len(rows), plaintext_bytes=sum(row['bytes'] for row in rows),
                   archive_bytes=archive.stat().st_size,
                   archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                   all_members_verified=True)
    (base / 'results-evidence-verification-01.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(source=selection['source'], **receipt)))


package(ROOT / 'build/m2-redraw-player-comparison-01', dict(
    source='M2 laptop redraw comparison 01, 2026-10-28',
    scope='Complete current packet text, including all failed setup checks, source/build manifests, baseline full observations, candidate admission failure, original clock, analysis and independent closures. No service or host observation rows filtered.',
    excluded_directories=['source', 'native', 'driver-cache', 'publication-input', 'publication-01', '__pycache__'],
    excluded_payloads=['audio', 'executable/model', 'source-tree payload', 'driver-cache payload'],
    source_head='9661b8e7f26f9d97ebd8694d36a4b13b5cc1f41b', qualified=False))

tf = ROOT / 'build/m2-keycnn-tf115-reference-01'
package(tf, dict(
    source='M2 generated TensorFlow 1.15.2 numerical reference, 2026-10-28',
    scope='Frozen generated comparison plan, checker and revisions, dependency/build/execution records, all completed and failed reference result text, independently checked all-batch top classes, input hashes/shapes and exact owned-container cleanup. No comparison rows filtered.',
    excluded_directories=['input', 'publication-input', 'publication-01', '__pycache__'],
    excluded_payloads=['model weights', 'generated numeric arrays', 'container image/runtime'],
    model_sha256='0a99c26b7d8a4f7123b3cdade75c7986ef686d6805378c43cada874497f53f9a',
    musical_accuracy_qualified=False, product_backend_enabled=False),
    [('input-metadata/' + name, tf / 'input' / name)
     for name in ('plan.json', 'fixtures.json', 'tensors.json', 'model-config.json')])
