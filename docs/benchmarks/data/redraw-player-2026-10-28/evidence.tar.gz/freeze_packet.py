"""Freeze the one-binary redraw comparison after offline and source review."""
from pathlib import Path
import ast
import hashlib
import json
import re

BASE = Path(__file__).resolve().parent


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    checks = json.loads((BASE / 'offline-checks-01.json').read_text())
    build = json.loads((BASE / 'approved-build-binding-01.json').read_text())
    manifest = json.loads((BASE / 'source-manifest-01.json').read_text())
    private = json.loads((BASE / 'integrated-private-normal-verification-01.json').read_text())
    publication = json.loads((BASE / 'source-publication-binding-01.json').read_text())
    assert checks['passed'] is True and checks['root_offline']['passed'] is True
    assert build['source_head'] == publication['source_head'] == manifest['source_head']
    assert publication['source_PR_CI_passed'] is True and publication['exact_head_approved'] is True
    assert publication['merged'] is True and publication['merge_tree_matches_source'] is True
    assert type(publication['postmerge_run']) is int and publication['postmerge_CI_watch_started'] is True
    assert private['passed'] is True and private['exit'] == 0
    assert build['built_from_signed_source'] is True and build['source_review_complete'] is True
    assert manifest['source_signature'] == 'G'
    assert pin(Path(build['binary']['path'])) == build['binary']
    for row in manifest['files']:
        assert pin(Path(row['path'])) == {k: row[k] for k in ('path', 'bytes', 'sha256')}
    first_cache = None
    plans = {}
    for arm in ('baseline', 'candidate'):
        case = BASE / 'cases' / arm
        assert not any((case / name).exists() for name in (
            'readiness.json', 'output-01', 'root-unit-dispatch-01.json', 'dispatch-01.json'))
        for path in case.glob('*.py'):
            ast.parse(path.read_text(), filename=str(path))
        owner = case / 'run_player_owned.py'
        assert owner.stat().st_mode & 0o111
        assert re.search(r"LAUNCHER_SHA = '([0-9a-f]{64})'", owner.read_text())[1] == pin(case / 'run_host_player.py')['sha256']
        plan = json.loads((case / 'plan.json').read_text())
        assert plan['status'] == 'draft_unarmed_pending_root_review'
        assert plan['seconds'] == 120 and plan['operator_seconds'] == 1200 and plan['command_seconds'] == 540
        assert plan['normal_redraw'] is (arm == 'candidate')
        assert plan['forced_redraw_interval_ms'] == (50 if arm == 'candidate' else 16)
        assert plan['assets']['binary'] == build['binary'] and plan['source_head'] == build['source_head']
        assert plan['requested_power_profile'] == 'balanced' and plan['requested_qt_quick_backend'] is None
        assert plan['ui_arm'] == 'candidate' and plan['no_retries'] is True
        cache = json.loads((case / 'driver-cache-initial-01.json').read_text())['files']
        if first_cache is None:
            first_cache = cache
        else:
            assert cache == first_cache
        from pair_clock import validate_initial_cache
        validate_initial_cache(case)
        plans[arm] = plan
    # Workload inputs and runtime are identical. Output paths, arm label and redraw option differ.
    assert plans['baseline']['assets'] == plans['candidate']['assets']
    assert plans['baseline']['power_limits'] == plans['candidate']['power_limits']
    for arm, plan in plans.items():
        case = BASE / 'cases' / arm
        plan['status'] = 'frozen_pending_fresh_readiness'
        (case / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
        path = case / 'root-launch-plan-01.json'
        launch = json.loads(path.read_text())
        launch['plan'] = pin(case / 'plan.json')
        path.write_text(json.dumps(launch, indent=2) + '\n')
        paths = [*BASE.glob('*.py'), BASE / 'approved-build-binding-01.json',
                 BASE / 'source-manifest-01.json', BASE / 'offline-checks-01.json',
                 BASE / 'integrated-build-verification-01.json',
                 BASE / 'integrated-private-normal-verification-01.json',
                 BASE / 'source-publication-binding-01.json', case / 'plan.json',
                 path, case / 'driver-cache-initial-01.json', case / 'run_host_player.py',
                 owner, case / 'close_case.py', case / 'launch-command-01.txt']
        pins = {str(p): pin(p) for p in paths}
        pins.update({row['path']: {k: row[k] for k in ('path', 'bytes', 'sha256')}
                     for row in manifest['files']})
        save(case / 'root-launch-clearance-01.json', dict(
            schema=1, pins=list(pins.values()), native_started=False, readiness_created=False,
            one_factor_verified=True, source_snapshot_complete_and_binary_build_verified=True,
            original_pair_seconds=1200, no_direct_powercap_writes=True,
            authorized_profile_selection=None, authorized_long_term_ceiling_uw=15000000))
    save(BASE / 'freeze-verification-01.json', dict(
        schema=1, status='frozen_pending_real_entry_checks_and_fresh_human_conditions',
        source_head=build['source_head'], same_binary=build['binary'], source_files_verified=len(manifest['files']),
        same_initial_driver_cache_files=len(first_cache), factor='forced update request interval 16/50 ms',
        fixed_best_runtime=True, requested_power_profile='balanced',
        authorized_long_term_ceiling_uw=15000000, no_profile_or_cap_writes=True,
        thermal_guard_unchanged=True, player_started=False, model_started=False,
        readiness_created=False, hard_cancellation_exercised=False, qualified=False))
    print('Both redraw arms frozen; real desktop entry and fresh conditions remain.')


if __name__ == '__main__':
    main()
