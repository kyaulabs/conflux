"""Summarize complete failed captures; retain all hops and sampled policy changes."""
from pathlib import Path
import collections,hashlib,json,statistics
BASE=Path(__file__).resolve().parent
report=dict(target_ms=4095,primary_laptop_gate_retained=True,hard_cancellation_exercised=False,arms={})
for arm in ['baseline']:
 c=BASE/'cases'/arm;r=json.loads((c/'output-01/result.json').read_text());a=json.loads((c/'diagnostic-assessment.json').read_text());n=r['native'];closed=json.loads((c/'root-finished-01.json').read_text());assert a['diagnostic_complete'] and closed['cleanup_complete']
 hops=r['observations']['service_hops'];assert hops['complete'] and hops['count']==13
 host=[json.loads(x) for x in (c/'output-01/host-observations.jsonl').read_text().splitlines()]
 pl1='/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_power_limit_uw'
 gui=[]
 for row in host:
  for native in row.get('process_cpu_read_only',{}).get('native_thread_cpu',[]):
   for thread in native.get('threads',[]):
    value=thread.get('cpu_cores_since_previous_observation')
    if thread['pid']==native['pid'] and type(value) in (int,float):gui.append(value)
 fields=r['observations']['chunk_phases']['fields']
 report['arms'][arm]=dict(measured_ms=n['measured_wall_ms'],service_hops=hops['count'],p99_ms=a['ordinary_assessment']['nearest_rank_p99_ms'],at_or_above_target=a['ordinary_assessment']['at_or_above_target'],functional_passed=False,native_error=n['error'],steady_starved_seconds=n['steady_starved_frames']/48000,control_starved_seconds=n['control_starved_frames']/48000,tail_starved_seconds=n['diagnostic_tail']['starved_a']/48000,manual_controls=len(n['manual_controls']),seek_recovery_ms=[(x['recovered_cursor_observed_ns']-x['issued_ns'])/1e6 for x in n['controls'] if x['kind']=='incomplete_generation_seek'],replay_recovery_ms=[(x['recovered_cursor_observed_ns']-x['issued_ns'])/1e6 for x in n['controls'] if x['kind']=='replay_recovery'],first_advance_upper_ms=(n['first_advance_observed_ns']-n['load_issued_ns'])/1e6,callback_deadline_misses=n['execution_deadline_misses'],invalid_buffers=n['invalid_buffers'],source_read_failures=n['source_read_failures'],recording_frames=n['recording']['writtenFrames'],recording_overflow_frames=n['recording']['overflowFrames'],recording_count_matches=n['recording']['acceptedFrames']==n['recording']['writtenFrames'],callback_max_ns=max(t['maximum_execution_ns'] for t in n['timing']),driver_discontinuities=sum(t['driver_position_discontinuities'] for t in n['timing']),driver_recovery_flags=sum(t['driver_recovery_flags'] for t in n['timing']),forced_redraw_interval_ms=n['forced_redraw_interval_ms'], acknowledged_controls=sum(row.get('acknowledged') is True for row in n['manual_controls']), rejected_commands=n['rejected_commands'], measured_audio_seconds=a['measurement']['output_seconds'], source_read_p99_ms=fields['source_read_ms']['nearest_rank_p99_ms'],request_p99_ms=fields['request_ms']['nearest_rank_p99_ms'],graph_compute_wall_p99_ms=fields['native_graph_compute_ms']['nearest_rank_p99_ms'],graph_rebuild_max_ms=fields['native_graph_rebuild_ms']['maximum_ms'],native_inference_CPU_max_ms=fields['native_inference_cpu_ms']['maximum_ms'],pl1_sample_counts=dict(collections.Counter(str(x['configured_power_caps_read_only'][pl1]) for x in host)),thermal=r['thermal_summary'],GUI_main_thread_CPU_sample_count=len(gui),GUI_main_thread_CPU_median_cores=statistics.median(gui),GUI_main_thread_CPU_scope='Valid consecutive native-lifetime sampled thread deltas across the whole host-monitor interval; not a continuous measure or causal attribution.',no_UI_exposure_gap=n['ui_coverage']['any_gap'] is False,cleanup_complete=closed['cleanup_complete'])
candidate=BASE/'cases/candidate'
ca=json.loads((candidate/'diagnostic-assessment.json').read_text());cc=json.loads((candidate/'root-finished-01.json').read_text())
assert ca['status']=='admission_failed' and not ca['native_launched'] and cc['cleanup_complete']
report['arms']['candidate']=dict(forced_redraw_interval_ms=50,status=ca['status'],workload_dispatch_entered=False,native_launched=False,service_hops=0,p99_ms=None,errors=ca['errors'],cleanup_complete=cc['cleanup_complete'],qualification=False)
report['paired_comparison_completed']=False
report['effect_of_redraw_interval_established']=False
report['further_laptop_tests_authorized']=False
report['graph_scope']='Graph compute is the native blocking dispatch/wait wall interval, not a per-kernel timestamp or proof of continuous GPU execution. Maxima across phase fields need not belong to the same hop.'
report['self_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
with (BASE/'pair-analysis-01.json').open('x') as f:f.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({arm:{k:v for k,v in row.items() if k not in ['thermal','GUI_main_thread_CPU_scope']} for arm,row in report['arms'].items()}))
