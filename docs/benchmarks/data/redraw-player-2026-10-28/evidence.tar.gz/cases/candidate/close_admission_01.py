"""Close only this completed admission failure; preserve every original verdict."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

P = Path(__file__).resolve().parent


def read(name):
    return json.loads((P / name).read_text())


def show(unit):
    raw = subprocess.check_output(['systemctl', '--user', 'show', unit,
        '--property=LoadState,ActiveState,SubState,MainPID,ControlGroup,InvocationID'],
        text=True, timeout=5)
    return dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)


def main():
    d, outer, assessor, plan = (read(n) for n in (
        'root-unit-dispatch-01.json', 'dispatch-01.json',
        'diagnostic-assessment.json', 'plan.json'))
    assert assessor['status'] == 'admission_failed'
    assert assessor['failure_phase'] == 'before_public_wrapper'
    assert assessor['native_launched'] is False
    assert assessor['workload_dispatch_entered'] is False
    assert assessor['workload_cleanup_applicable'] is False
    assert not (P / 'output-01').exists()
    assert outer['finished_monotonic'] and outer['launcher_reaped'] and outer['complete_capture']
    assert not outer['remaining_known_processes'] and not outer['errors']
    rows = outer['known_processes'] + [d['owner_identity']]
    identities = {(row['pid'], row['start_ticks']) for row in rows}
    groups = {row['group'] for row in rows}
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            raw = (entry / 'stat').read_text()
            fields = raw[raw.rfind(')') + 2:].split()
        except (FileNotFoundError, ProcessLookupError):
            continue
        assert (int(entry.name), int(fields[19])) not in identities
        assert int(fields[2]) not in groups
    cgroup = d['original_owned_cgroup']
    assert cgroup and cgroup.endswith('/' + d['unit'])
    directory = Path('/sys/fs/cgroup') / cgroup.lstrip('/')
    assert not directory.exists() or all(not f.read_text().split() for f in directory.rglob('cgroup.procs'))
    unit_before = show(d['unit'])
    assert unit_before['MainPID'] == '0'
    assert unit_before['InvocationID'] == d['unit_after_launch']['InvocationID']
    assert unit_before['SubState'] in ('exited', 'dead', 'failed')
    command = ['busctl', '--user', '--timeout=2s', '--json=short', 'call',
        'org.kde.Solid.PowerManagement.PolicyAgent', '/org/kde/Solid/PowerManagement/PolicyAgent',
        'org.kde.Solid.PowerManagement.PolicyAgent', 'ListInhibitions']
    inhibition = json.loads(subprocess.check_output(command, text=True, timeout=4))
    assert inhibition['type'] == 'aas'
    assert not any(row[1] == str(P / 'run_player_owned.py') for row in inhibition['data'][0])
    pw = subprocess.run(['pw-dump', '-N'], capture_output=True, timeout=5, check=True)
    assert len(pw.stdout) <= 16 * 1024 * 1024
    known_pids = {str(pid) for pid, _ in identities}
    remaining_audio = [row['id'] for row in json.loads(pw.stdout)
        if str(row.get('info', {}).get('props', {}).get('application.process.id', '')) in known_pids]
    assert not remaining_audio
    pins = read('root-launch-clearance-01.json')['pins']
    for pin in pins:
        blob = Path(pin['path']).read_bytes()
        assert len(blob) == pin['bytes']
        assert hashlib.sha256(blob).hexdigest() == pin['sha256'], pin['path']
    guard = show('thermal-guard.service')
    assert guard['ActiveState'] == 'active'
    assert all(guard[key] == d['guard_before'][key] for key in ('MainPID', 'InvocationID'))
    for key in ('script', 'unit'):
        row = read('admission-01.json')['guard_before'][key]
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']
    ceiling = plan['power_limits']
    def within_ceiling(values):
        return all(0 < values[path] <= bound if path.endswith('power_limit_uw') else values[path] == bound
                   for path, bound in ceiling.items())
    assert all(within_ceiling(row['values']) for row in assessor['configured_power_cap_snapshots'])
    assert within_ceiling({path: int(Path(path).read_text()) for path in ceiling})
    subprocess.run(['systemctl', '--user', 'stop', d['unit']], capture_output=True, check=True, timeout=5)
    unit_after = show(d['unit'])
    assert unit_after['LoadState'] == 'not-found' and unit_after['MainPID'] == '0'
    assert not directory.exists() or all(not f.read_text().split() for f in directory.rglob('cgroup.procs'))
    now = time.monotonic()
    receipt = dict(schema=1, status='admission_failure_independently_closed',
        qualified=False, cleanup_complete=True,
        cleanup_scope='Independent admission-only process, original unit cgroup, PipeWire and idle-inhibition closure. Public wrapper never entered; original assessor cleanup flag and admission failure remain unchanged.',
        original_readiness_utc=d['original_readiness_utc'],
        original_readiness_monotonic=d['original_readiness_monotonic'],
        operator_deadline_monotonic=d['operator_deadline_monotonic'],
        automated_owner_finished_monotonic=outer['finished_monotonic'],
        automated_owner_elapsed_seconds=outer['finished_monotonic'] - d['original_readiness_monotonic'],
        automated_owner_within_original_1200_seconds=outer['finished_monotonic'] <= d['operator_deadline_monotonic'],
        root_verification_monotonic=now,
        root_verification_elapsed_seconds=now - d['original_readiness_monotonic'],
        root_verification_within_original_1200_seconds=now <= d['operator_deadline_monotonic'],
        known_unique_lifetimes=len(identities), known_groups=len(groups),
        remaining_known_processes=[], owned_groups_absent=True,
        original_owned_cgroup=cgroup, original_cgroup_absent_or_empty=True,
        own_pipewire_resources_remaining=remaining_audio, own_idle_inhibitions_remaining=0,
        unit_before_stop=unit_before, unit_after_stop=unit_after,
        guard_identity_and_files_unchanged=True, frozen_caps_respected=True,
        independently_verified_frozen_file_count=len(pins), frozen_inputs_unchanged=True,
        original_automated_cleanup_complete=assessor['cleanup_complete'],
        original_workload_cleanup_applicable=assessor['workload_cleanup_applicable'],
        original_outer_errors=outer['errors'], original_errors=assessor['errors'],
        requested120s_complete=False, native_launched=False, model_launched=False,
        audio_output_started=False, p99_for_requested_120s=None,
        cleanup_helper=dict(path=str(Path(__file__).resolve()),
            sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),
        further_laptop_tests_authorized=False)
    with (P / 'root-finished-01.json').open('x') as stream:
        stream.write(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: receipt[key] for key in ('status', 'cleanup_complete',
        'known_unique_lifetimes', 'known_groups', 'root_verification_elapsed_seconds',
        'root_verification_within_original_1200_seconds')}))


if __name__ == '__main__':
    main()
