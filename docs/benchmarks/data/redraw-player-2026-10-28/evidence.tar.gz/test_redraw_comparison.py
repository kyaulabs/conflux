"""Reject changed redraw factors even when retaining a complete failed run."""
import copy
import json
import unittest
from test_failed_recovery_capture import fixture, pending


class RedrawComparisonTests(unittest.TestCase):
    def test_plan_binds_typed_cadence_and_explicit_mode(self):
        for arm in ('baseline', 'candidate'):
            current = fixture(arm)
            driver = current.driver
            plan = json.loads(driver.PLAN.read_text())
            driver.validate_plan(plan)
            for change in ({'normal_redraw': not driver.NORMAL_REDRAW},
                           {'normal_redraw': int(driver.NORMAL_REDRAW)},
                           {'forced_redraw_interval_ms': True},
                           {'forced_redraw_interval_ms': '50'},
                           {'forced_redraw_interval_ms': 16 if driver.NORMAL_REDRAW else 50}):
                with self.subTest(arm=arm, change=change), self.assertRaises(ValueError):
                    driver.validate_plan(plan | change)

    def test_wrong_native_cadence_or_mode_blocks_failed_population_comparison(self):
        for arm in ('baseline', 'candidate'):
            current = fixture(arm)
            changes = ({'forced_redraw_interval_ms': None},
                       {'forced_redraw_interval_ms': True},
                       {'forced_redraw_interval_ms': 16 if current.driver.NORMAL_REDRAW else 50},
                       {'mode': 'live-stems-controls' if current.driver.NORMAL_REDRAW
                        else 'live-stems-controls-normal-redraw'})
            for change in changes:
                def mutation(output, result):
                    pending(output, result)
                    result['native'].update(copy.deepcopy(change))
                with self.subTest(arm=arm, change=change):
                    code, report = current.CompletedRunCaptureTests().exercise(mutation)
                    self.assertEqual(code, 1)
                    self.assertFalse(report['diagnostic_complete'])
                    self.assertFalse(report.get('passed', False))
                    self.assertTrue(any('mode/cadence' in r['message'] for r in report['errors']))


if __name__ == '__main__':
    unittest.main()
