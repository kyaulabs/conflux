"""Retire only the two completed, identity-matched test units; collect text evidence."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import hashlib,importlib.util,io,json,subprocess,tarfile
BASE=Path(__file__).resolve().parent.parent
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']

def retire(unit,invocation,local):
 prefix=['systemctl']+(['--user'] if local else [])
 def show():
  raw=subprocess.check_output(prefix+['show',unit,'--property=LoadState,ActiveState,SubState,MainPID,InvocationID,ControlGroup,Result,ExecMainStatus'],text=True,timeout=5)
  return dict(s.split('=',1) for s in raw.splitlines() if '='in s)
 before=show();assert before['InvocationID']==invocation and before['MainPID']=='0',before
 group=before['ControlGroup'];procs=Path('/sys/fs/cgroup'+group)/'cgroup.procs' if group else None
 assert not procs or not procs.exists() or not procs.read_text().strip(),'Owned cgroup still occupied'
 command=([] if local else ['sudo','-n'])+prefix+['stop',unit]
 subprocess.run(command,check=True,timeout=60)
 after=show()
 if after['ActiveState']=='failed':
  subprocess.run(([] if local else ['sudo','-n'])+prefix+['reset-failed',unit],check=True,timeout=5);after=show()
 assert after['MainPID']=='0'and after['ActiveState']=='inactive'and after['LoadState']=='not-found',after
 return dict(before=before,after=after,cgroup_empty_before_stop=True)

def local():
 spec=importlib.util.spec_from_file_location('pause_identity_only',BASE/'onedrive_pause.py');pause=importlib.util.module_from_spec(spec);spec.loader.exec_module(pause)
 state=pause.show();pause.validate(state,json.loads((BASE/'onedrive-proposal.json').read_text()))
 assert state['ActiveState']=='active'
 token=json.loads((BASE/'onedrive-pause-state.json').read_text())
 assert token['restore_complete']and token['pause_held_through_native_cleanup']and token['originally_active']
 assert token['question_item_id']=='["request_user_input_async","call_da158a2811994731a5ed6d8f42d1a3ab",0]'
 assert all(state[k]==token['restored_state'][k]for k in ('MainPID','InvocationID','ControlGroup'))
 row=retire('conflux-m2-basic-render-laptop-20261029-01.service','c9fff69895a14bd9b620ad28f1d8c873',True)
 again=pause.show();pause.validate(again,json.loads((BASE/'onedrive-proposal.json').read_text()))
 assert all(state[k]==again[k] for k in ('MainPID','InvocationID','ControlGroup'))
 row.update(OneDrive_restored=True,OneDrive_state=again,pause_held_through_native_cleanup=True,restoration=token['restoration'],
  same_restored_instance_after_unit_stop=True,guarded_outcome=json.loads((BASE/'guarded-outcome.json').read_text()))
 command=['busctl','--user','--timeout=2s','--json=short','call','org.kde.Solid.PowerManagement.PolicyAgent','/org/kde/Solid/PowerManagement/PolicyAgent','org.kde.Solid.PowerManagement.PolicyAgent','ListInhibitions']
 row['KDE_inhibitors']=json.loads(subprocess.check_output(command,text=True,timeout=5))
 assert row['KDE_inhibitors']['data']==[[]],row['KDE_inhibitors']
 return row

def remote():
 import inspect
 code='from pathlib import Path\nimport subprocess,json\n'+inspect.getsource(retire)+'''\nr=retire('conflux-m2-basic-render-apollo-20261029-01.service','ec616020c26c46d18bbf11936a65c71c',False)
command=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock','ps','--format','{{json .}}']
r['private_daemon_running_containers']=subprocess.check_output(command,text=True,timeout=10).splitlines()
assert not r['private_daemon_running_containers']
print(json.dumps(r))
'''
 p=subprocess.run(SSH+['python3 -'],input=code,text=True,capture_output=True,timeout=80);assert p.returncode==0,p.stderr
 return json.loads(p.stdout)

with ThreadPoolExecutor(max_workers=2)as pool:
 a=pool.submit(local);b=pool.submit(remote);report=dict(utc=datetime.now(timezone.utc).isoformat(),laptop=a.result(),apollo=b.result())
with (BASE/'unit-retirement-01.json').open('x')as f:f.write(json.dumps(report,indent=2)+'\n')
# Collect bounded result text, excluding audio, caches, binaries and sources.
code='''from pathlib import Path
import io,sys,tarfile
b=Path('/srv/conflux-tests/work/basic-render-player-20261029-01');files=[]
for root in (b/'cases',):
 for p in root.rglob('*'):
  if p.is_file()and not p.is_symlink()and p.suffix in ('.json','.jsonl','.log'):
   assert p.stat().st_size<=32*1024*1024;files.append(p)
for n in ('pair-result-01.json','unit.stdout.log','unit.stderr.log','unit-dispatch.json','pair-readiness-01.json','pair-reservation-01.json'):
 p=b/n
 if p.exists():files.append(p)
assert sum(p.stat().st_size for p in files)<=64*1024*1024
out=io.BytesIO()
with tarfile.open(fileobj=out,mode='w:gz')as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(b)),recursive=False)
sys.stdout.buffer.write(out.getvalue())
'''
r=subprocess.run(SSH+['sudo -n python3 -'],input=code.encode(),capture_output=True,timeout=45);assert r.returncode==0,r.stderr.decode()
raw=r.stdout;assert len(raw)<=16*1024*1024
archive=BASE/'analysis-01/apollo-results-01.tar.gz'
with archive.open('xb')as f:f.write(raw)
dest=BASE/'analysis-01/apollo';dest.mkdir()
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as t:
 for member in t.getmembers():
  assert member.isfile()and not Path(member.name).is_absolute()and '..'not in Path(member.name).parts
  p=dest/member.name;p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb')as f:f.write(t.extractfile(member).read())
print(json.dumps(dict(cleanup=report,apollo_archive_bytes=len(raw),apollo_archive_sha256=hashlib.sha256(raw).hexdigest())))
