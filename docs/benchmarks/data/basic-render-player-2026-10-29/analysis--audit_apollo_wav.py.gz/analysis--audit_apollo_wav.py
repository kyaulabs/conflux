"""Read only the completed recording's header; never start a workload."""
from pathlib import Path
import importlib.util,json,subprocess
BASE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('collect_args',BASE.parent/'observe_both.py')
# Keep the exact known SSH identity without executing the observer module.
import ast
m=ast.parse(s.loader.get_source('collect_args'))
ssh=ast.literal_eval(next(n.value for n in m.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='SSH'for t in n.targets)))
code='''from pathlib import Path
import json,struct
b=Path('/srv/conflux-tests/work/basic-render-player-20261029-01/cases/candidate/private-player-01/recordings/actual-player')
n=json.loads((b/'native-result.json').read_text());p=b/'master.wav';assert p.is_file()and not p.is_symlink()
size=p.stat().st_size
with p.open('rb')as f:head=f.read(65536)
assert head[:4]==b'RIFF'and head[8:12]==b'WAVE'and struct.unpack_from('<I',head,4)[0]+8==size
at=12;fmt=None;data=None
while at+8<=len(head):
 kind=head[at:at+4];length=struct.unpack_from('<I',head,at+4)[0]
 if kind==b'fmt ':fmt=struct.unpack_from('<HHIIHH',head,at+8)
 if kind==b'data':data=dict(offset=at+8,bytes=length);break
 at+=8+length+(length%2)
assert fmt==(3,2,48000,384000,8,32),fmt
assert data and data['bytes']==n['recording']['writtenFrames']*8 and data['offset']+data['bytes']<=size
assert n['recording']['acceptedFrames']==n['recording']['writtenFrames']==n['recorded_audio']['frames']
assert p.stat().st_size==size
print(json.dumps(dict(header_counts_match=True,format='stereo 48 kHz float32 RIFF WAV',bytes=size,frames=n['recording']['writtenFrames'],data=data,host_audio_qualification=False)))
'''
r=subprocess.run(ssh+['python3 -'],input=code,text=True,capture_output=True,timeout=20)
with (BASE/'WAV-audit-01.log').open('x')as f:f.write(r.stdout+r.stderr)
r.check_returncode()
with (BASE/'WAV-audit-01.json').open('x')as f:f.write(json.dumps(json.loads(r.stdout),indent=2)+'\n')
print(r.stdout,end='')
