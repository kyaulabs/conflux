"""Run the existing uninstrumented owner inside an approved, reversible sync pause."""
from datetime import datetime, timezone
from pathlib import Path
import importlib.util
import hashlib
import json
import sys
import time

BASE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def release_cap():
    if not (BASE / 'burst-cap-intent.json').exists():
        return dict(not_requested=True, restoration_complete=True)
    return load('bounded_cap_release', BASE / 'cap_client.py').release()


def main():
    if '--restore-only' in sys.argv:
        try:
            release_cap()
        finally:
            load('backup_sync_restore', BASE / 'onedrive_pause.py').restore()
        return 0
    human = json.loads((BASE / 'readiness.json').read_text()) if '--run' in sys.argv else None
    if human is not None and human.get('hour_duration_approved') is not True:
        raise PermissionError('Fresh human approval for the full hour is required before any service pause')
    plan = json.loads((BASE / 'laptop-plan.json').read_text())
    row = plan['pins']['driver']
    assert Path(row['path']) == BASE / 'run_laptop_pair.py'
    raw = Path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    runner = load('normal_player_owner', BASE / 'run_laptop_pair.py')
    if '--run' not in sys.argv:
        return runner.main()
    runner.clock(human, runner.pin(BASE / 'laptop-plan.json')['sha256'],
        datetime.now(timezone.utc), time.monotonic())
    runner.verify(plan)
    load('pre_pause_storage', BASE / 'storage_check.py').verify(BASE)
    pause = runner.load('approved_sync_pause', plan['pins']['sync_pause_helper'])
    assert pause.TOKEN == BASE / 'onedrive-pause-state.json', 'Pause helper must belong to this packet'
    assert pause.PROPOSAL == BASE / 'onedrive-proposal.json', 'Pause proposal must belong to this packet'
    assert not pause.TOKEN.exists(), 'Previous pause token belongs to an earlier attempt'
    outcome = dict(schema=1, owner_exit=None, passed=False,
        original_deadline_monotonic=human['operator_deadline_monotonic'])
    try:
        pause.pause(human.get('onedrive_pause_approved') is True, human['question_item_id'])
        code = runner.main()
        outcome['owner_exit'] = code
        pause.verify_held()
        return code
    except BaseException as error:
        outcome['run_error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        try:
            try:
                outcome['cap_cleanup'] = release_cap()
            finally:
                if pause.TOKEN.exists():
                    pause.restore()
        except BaseException as error:
            outcome['restoration_error'] = type(error).__name__ + ': ' + str(error)
            raise
        finally:
            state = json.loads(pause.TOKEN.read_text()) if pause.TOKEN.exists() else {}
            outcome.update(pause_held_through_native_cleanup=state.get('pause_held_through_native_cleanup') is True,
                restore_complete=state.get('restore_complete') is True,
                finished_monotonic=time.monotonic())
            outcome['within_original_window'] = outcome['finished_monotonic'] <= human['operator_deadline_monotonic']
            outcome['passed'] = bool(outcome['owner_exit'] == 0 and outcome.get('cap_cleanup', {}).get('restoration_complete') is True and outcome['restore_complete']
                and outcome['pause_held_through_native_cleanup'] and outcome['within_original_window']
                and not outcome.get('run_error') and not outcome.get('restoration_error'))
            with (BASE / 'guarded-outcome.json').open('x') as output:
                output.write(json.dumps(outcome, indent=2) + '\n')


if __name__ == '__main__':
    raise SystemExit(main())
