"""Hour admission, native-result separation and restoration budget regressions; no hardware."""
from datetime import datetime, timedelta, timezone
from pathlib import Path
import importlib.util
import sys
import unittest

BASE = Path(__file__).resolve().parent
SOURCE = Path('/home/kyau/projects/kyaulabs/conflux/build/m2-current-player-hour-01/source-build-01/laptop/source')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


pair = load('hour_pair_fixture', BASE/'run_laptop_pair.py')
launch = load('hour_launch_fixture', BASE/'launch_both.py')
public = load('pinned_hour_regressions', SOURCE/'tests/manual_playback_hour_test.py')


class HourOwnershipTests(unittest.TestCase):
    def result(self):
        native, observations = public.HourPlaybackTest().fixture()
        native.update(error='', forced_redraw_interval_ms=16, ui_mode='visible', window_policy='visible',
            recording=dict(status='Complete', error='', acceptedFrames=172800000,
                writtenFrames=172800000, overflowFrames=0))
        gates = public.soak.validate_hour_result(native, observations)
        return dict(requested_seconds=3600, native=native, observations=observations, native_exit=0,
            passed=True, qualified=True, hour_gates=gates, within_wall_budget=True,
            pins_unchanged=True, cleanup_proven=True, cleanup=dict(leader_reaped=True,
                cooperative_native_shutdown=True, ownership_complete=True, remaining_known_processes=[],
                remaining_pipewire_count=0, remaining_live_jobs=[], ownership_failures=[], engine_processes_observed=True))

    def human(self):
        now = datetime.now(timezone.utc)
        value = dict(mode=pair.MODE, plan_sha256='fixture', recorded_at_utc=now.isoformat(),
            operator_deadline_monotonic=6380, operator_seconds=4380,
            hour_duration_approved=True,human_reply='Generated offline fixture; not human readiness', question_item_id='fixture')
        value.update({key:True for key in ('AC_power','lid_open','visible_window','screen_awake',
            'Codex_minimized','other_work_paused','no_suspend')})
        return value, now

    def test_original_hour_clock_survives_service_stop_but_is_never_renewed(self):
        human, now = self.human()
        self.assertEqual(pair.clock(human,'fixture',now,2000),6380)
        self.assertEqual(pair.clock(human,'fixture',now+timedelta(seconds=100),2100),6380)
        for record, utc, mono in [(human,now+timedelta(seconds=181),2181),
                (dict(human,operator_deadline_monotonic=6480),now,2000),
                (dict(human,operator_seconds=1200),now,2000)]:
            with self.subTest(record=record), self.assertRaises(AssertionError):
                pair.clock(record,'fixture',utc,mono)

    def test_direct_owner_also_requires_the_longer_duration_approval(self):
        human,now=self.human()
        del human['hour_duration_approved']
        with self.assertRaisesRegex(PermissionError,'full hour'):
            pair.clock(human,'fixture',now,2000)

    def test_short_or_private_result_cannot_qualify_the_laptop_hour(self):
        for changes in [dict(requested_seconds=120),dict(measured_wall_ms=120000),
                dict(mode='live-stems-controls'),dict(functional_only=True,host_audio=False),
                dict(cancelled=True),dict(forced_redraw_interval_ms=50)]:
            value=self.result()
            if 'requested_seconds' in changes:value.update(changes)
            else:value['native'].update(changes)
            assessed=pair.assess(value)
            self.assertFalse(assessed['measurement_complete'])
            self.assertFalse(assessed['qualified'])

    def test_original_hour_validator_and_cleanup_are_both_required(self):
        self.assertTrue(pair.assess(self.result())['qualified'])
        for changes in [dict(qualified=False),dict(cleanup_proven=False),dict(within_wall_budget=False)]:
            value=self.result();value.update(changes)
            self.assertFalse(pair.assess(value)['qualified'])
        for p99,complete in [(4095,True),(4094,False)]:
            value=self.result();value['observations']['service_hops']['nearest_rank_p99_ms']=p99
            value['observations']['service_metrics_complete']=complete
            self.assertFalse(pair.assess(value)['qualified'])

    def test_unit_shutdown_reserves_service_start_wait_on_original_clock(self):
        command=launch.local_command('fixture.service',live=True,remaining=4380)
        runtime=int(next(s for s in command if s.startswith('--property=RuntimeMaxSec=')).split('=')[-1][:-1])
        stop=int(next(s for s in command if s.startswith('--property=TimeoutStopSec=')).split('=')[-1][:-1])
        self.assertGreaterEqual(stop,50)
        self.assertLessEqual(runtime+stop,4380)
        # The Python owner's alarm must leave 120 seconds for cap and sync restoration before
        # the unit deadline, plus room for a fallback stop on the same clock.
        self.assertGreaterEqual(runtime-(4380-240),120)
        self.assertTrue(any('ExecStopPost=' in part and 'run_local_guarded.py' in part and '--restore-only' in part for part in command))


if __name__ == '__main__':unittest.main(verbosity=2)
