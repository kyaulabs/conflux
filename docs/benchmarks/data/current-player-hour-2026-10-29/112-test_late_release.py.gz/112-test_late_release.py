"""Regression for repeat cleanup after the original owner has already retired."""
from contextlib import ExitStack
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('late_release_client', BASE / 'cap_client.py')
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)


class LateReleaseTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(dir=BASE)
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        for name, path in dict(BASE=self.root, INTENT=self.root / 'intent.json',
                STOP=self.root / 'stop', ROOT_DIRECTORY=self.root / 'root-owner',
                STATE=self.root / 'root-owner/state.json').items():
            self.stack.enter_context(patch.object(client, name, path))
        client.INTENT.write_text(json.dumps(dict(original_operator_deadline_monotonic=100)))
        self.stack.enter_context(patch.object(client.time, 'monotonic', return_value=200))
        self.sleep = self.stack.enter_context(patch.object(client.time, 'sleep'))
        self.show = self.stack.enter_context(patch.object(client, 'show', return_value=dict(
            LoadState='not-found', MainPID='0')))
        self.root_state = self.stack.enter_context(patch.object(client, 'root_state'))

    def state(self, finished=True, restored=True):
        client.ROOT_DIRECTORY.mkdir()
        client.STATE.write_text('{}')
        self.root_state.return_value = dict(finished=finished, restoration_complete=restored)

    def test_expired_cancelled_authentication_is_already_clean(self):
        result = client.release()
        self.assertTrue(result['restoration_complete'])
        self.assertTrue(result['late_apply_blocked'])
        self.assertTrue(client.STOP.exists())
        self.root_state.assert_not_called()
        self.sleep.assert_not_called()

    def test_expired_but_proven_restored_owner_can_be_observed_without_waiting(self):
        self.state()
        result = client.release()
        self.assertTrue(result['restoration_complete'])
        self.assertTrue(result['root_receipt']['finished'])
        self.show.assert_called_once_with()
        self.sleep.assert_not_called()

    def test_expired_uncertain_restoration_remains_an_error(self):
        self.state(restored=False)
        with self.assertRaisesRegex(RuntimeError, 'rollback is not proven'):
            client.release()
        self.sleep.assert_not_called()

    def test_expired_unfinished_or_live_owner_cannot_claim_cleanup_or_gain_time(self):
        self.state(finished=False)
        with self.assertRaises(TimeoutError):
            client.release()
        self.root_state.return_value = dict(finished=True, restoration_complete=True)
        self.show.return_value = dict(LoadState='loaded', MainPID='123')
        with self.assertRaises(TimeoutError):
            client.release()
        self.sleep.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
