# Current-player hour attempt

Apollo completed its full measured hour at **0.994-second p99**. The primary laptop retained **2.772-second p99** before the user switched desktops at **37 minutes 2.237 seconds**. That interrupted visible-UI run remains incomplete and unqualified. Neither M2/M3 nor the 0.1.0 release gate is closed.

| Observation | Laptop, interrupted | Apollo, private virtual audio |
| --- | ---: | ---: |
| Measured interval | 2,222.237 s | 3,600.005 s |
| Completed service deliveries | 331 | 555 |
| Nearest-rank p99 | 2.771754 s | 0.994327 s |
| Maximum service delivery | 2.897198 s | 1.026122 s |
| Deliveries at or above 4.095 s | 0 | 0 |
| Steady stem starvation | 0 s | 0 s |
| Seek/replay starvation | 299.237 s | 386.421 s |
| EOF/replay cycles | 82 | 137 |
| Peer rewinds | 5 | 8 |
| Callback deadline misses | 0 | 0 |
| Driver discontinuities / recovery flags | 0 / 0 | 0 / 0 |
| Recording overflow frames | 0 | 0 |
| Recording frames accepted and written | 106,980,608 | 173,330,432 |

The strict service target remains **less than 4.095 seconds** at Best quality. Both service populations are complete for their retained intervals; the shortened laptop interval is not substituted for an hour. Load to the first observed cursor advance was 6.713 seconds on the laptop and 11.010 seconds on Apollo. Service-hop latency and cursor observations do not establish physical acoustic latency. Seek/replay buffering remains a separate usability cost.

Both hosts sought an accepted generation before its RawComplete observation and discarded stale packets: two on the laptop and one on Apollo. This establishes logical unfinished-generation seek coverage, not a native GPU inference-start timestamp or hard worker termination. Invalid buffers, source-read failures, rejected commands and scene errors were zero. Recording headers, payload lengths and frame counts agree with the native stereo 48 kHz float32 scans. No new listening verdict was obtained.

The laptop stopped with `Live window hidden or not presenting`. Its retained Qt events show an exposure/focus transition while the window remained marked visible. The user confirmed: “sorry i alt tabbed to another desktop”. The failed native result and aborted final interval are preserved. The requested basic render loop is confirmed separately by the original journal message matched to the exact native PID, executable, user unit and invocation; empty stdout/stderr captures remain unchanged.

All 1,084 two-second laptop host samples retained Balanced mode. The sampled peak was 77°C, with no sample at or above 85°C or 95°C. Sampled readings cannot exclude shorter spikes. The existing thermal guard and long-term ceiling were unchanged. Only the approved temporary MMIO short-term cap changed from 64 W to 15 W; its root-owned receipt proves restoration to 64 W before OneDrive resumed. No permanent policy was installed.

Two earlier laptop attempts timed out at administrator authentication before any playback or cap installation. The third retry initially rejected copied dry-run log output; the inherited logs were retained separately and a fresh actual desktop check passed before launch. Each retry passed the existing 92 offline checks. Apollo was not restarted: its original hour overlapped the laptop retry, so the hosts did not share identical start times. This is not a counterbalanced causal comparison.

All exact test units and cgroups are retired, Apollo's owned private container is absent, and KDE's inhibition list is empty. The first timed-out owner retained a late cleanup failure after its original deadline; that journal was saved before resetting only its verified empty stale unit. No power-cap owner existed for that failed authentication attempt. The active OneDrive executable and restored short-term cap were independently checked.

The [result summary](results-summary-01.json), [WAV audit](WAV-audit-01.json), [render-loop journal proof](render-loop-journal-proof-01.json), [owner retirement](owner-retirement-01.json), [Apollo capture receipt](apollo-capture-receipt-01.json) and [user interruption](user-interruption-01.json) retain the evidence. The full redundant local benchmark WAV was retired after hashing and auditing it, preserving exact opening/closing excerpts and recovering 836,644,840 bytes; [audio retirement](audio-retirement-01.json) records the original hash and excerpt locations. User tracks remain unchanged.

An uninterrupted primary-laptop hour, hard-worker cancellation and the remaining musical-analysis/M3 acceptance gates are still required. This attempt changes no product code, production analysis backend, quality setting, latency target or release status.
