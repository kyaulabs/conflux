"""Render-loop activation must be observed, never inferred from the request."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('render_loop_owner', BASE/'run_laptop_pair.py')
pair = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pair)


class RenderLoopTests(unittest.TestCase):
    def proof(self, stderr, stdout=''):
        with tempfile.TemporaryDirectory(dir=BASE) as temporary:
            root = Path(temporary)
            (root/'native.stdout.log').write_text(stdout)
            (root/'native.stderr.log').write_text(stderr)
            return pair.render_loop_proof(root)

    def test_actual_category_message_confirms_basic(self):
        value = self.proof('qt.scenegraph.general: basic render loop\n')
        self.assertTrue(value['confirmed'])
        self.assertEqual(value['observed_loops'], ['basic'])
        self.assertEqual(len(value['captures']), 2)

    def test_request_text_and_other_categories_are_not_activation(self):
        for text in ('QSG_RENDER_LOOP=basic\n', 'request basic render loop\n',
                     'qt.other: basic render loop\n', 'qt.scenegraph.general: requested basic render loop\n'):
            with self.subTest(text=text):
                self.assertFalse(self.proof(text)['confirmed'])

    def test_wrong_or_conflicting_observed_loop_rejects_confirmation(self):
        self.assertFalse(self.proof('qt.scenegraph.general: threaded render loop\n')['confirmed'])
        self.assertFalse(self.proof('qt.scenegraph.general: basic render loop\n',
                                   'qt.scenegraph.general: threaded render loop\n')['confirmed'])

    def test_missing_or_oversized_capture_never_confirms(self):
        with tempfile.TemporaryDirectory(dir=BASE) as temporary:
            root = Path(temporary)
            (root/'native.stderr.log').write_text('qt.scenegraph.general: basic render loop\n')
            self.assertFalse(pair.render_loop_proof(root)['confirmed'])
            with (root/'native.stdout.log').open('wb') as stream:
                stream.truncate(4*1024*1024+1)
            self.assertFalse(pair.render_loop_proof(root)['confirmed'])

    def test_environment_preserves_backend_and_rules_and_reaches_child(self):
        with patch.dict(os.environ, {'QT_QUICK_BACKEND':'rhi','QT_LOGGING_RULES':'qt.other=false',
                                    'QSG_RENDER_LOOP':'threaded'}, clear=True):
            value = pair.configure_ui_environment()
            raw = subprocess.check_output([sys.executable,'-c',
                'import json,os;print(json.dumps({k:os.environ.get(k) for k in ("QSG_RENDER_LOOP","QT_QUICK_BACKEND","QT_LOGGING_RULES")}))'], text=True)
            child = json.loads(raw)
            self.assertEqual(child['QSG_RENDER_LOOP'], 'basic')
            self.assertEqual(child['QT_QUICK_BACKEND'], 'rhi')
            self.assertEqual(child['QT_LOGGING_RULES'], 'qt.other=false\nqt.scenegraph.general=true')
            self.assertTrue(value['graphics_backend_setting_unchanged'])
            self.assertTrue(value['actual_render_loop_requires_native_log'])

    def test_software_backend_is_rejected_before_setting_loop(self):
        with patch.dict(os.environ, {'QT_QUICK_BACKEND':'software','QSG_RENDER_LOOP':'threaded'}, clear=True):
            with self.assertRaisesRegex(AssertionError, 'Default graphics backend required'):
                pair.configure_ui_environment()
            self.assertEqual(os.environ['QSG_RENDER_LOOP'], 'threaded')


if __name__ == '__main__':
    unittest.main(verbosity=2)
