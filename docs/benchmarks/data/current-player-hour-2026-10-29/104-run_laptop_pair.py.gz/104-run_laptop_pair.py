"""Current player check with the approved three-sample guard and unchanged runtime; dry by default."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import time
from types import SimpleNamespace

BASE=Path(__file__).resolve().parent
ARMS=('candidate',)
MODE='m2-current-player-hour-20261029-01'


def save(path,value):
 temporary=path.with_suffix(path.suffix+'.tmp')
 temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)


def pin(path):
 path=Path(path);assert path.is_file() and not path.is_symlink(),str(path)
 with path.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(path),bytes=path.stat().st_size,sha256=sha)


def verify(plan):
 assert plan['schema']==1 and plan['mode']==MODE and plan['seconds_per_arm']==3600
 assert plan['operator_seconds']==4380 and plan['forced_redraw_interval_ms']==16 and plan['no_retries']
 assert Path(plan['pins']['sync_pause_helper']['path'])==BASE/'onedrive_pause.py','Pause helper must belong to this packet'
 assert Path(plan['pins']['sync_pause_proposal']['path'])==BASE/'onedrive-proposal.json','Pause proposal must belong to this packet'
 for row in plan['pins'].values():assert pin(row['path'])==row,row['path']
 for row in plan['source_files']:
  p=Path(plan['source_root'])/row['file'];assert p.stat().st_size==row['bytes'] and pin(p)['sha256']==row['sha256'],str(p)
 for row in plan['cache_seed_files']:
  p=Path(plan['cache_seed'])/row['file'];assert p.stat().st_size==row['bytes'] and pin(p)['sha256']==row['sha256'],str(p)
 assert len([p for p in Path(plan['cache_seed']).rglob('*') if p.is_file()])==len(plan['cache_seed_files'])
 proof=json.loads(Path(plan['pins']['exact_outputs']['path']).read_text())
 assert proof['correctness_complete_both_hosts'] and proof['timing_qualification'] is False
 for host in ('laptop','apollo'):
  for arm in ('baseline',):assert proof['hosts'][host]['arms'][arm]['requests']==proof['hosts'][host]['arms'][arm]['exact_outputs']==16
 numeric=json.loads(Path(plan['pins']['numeric_laptop_plan']['path']).read_text())
 human=json.loads(Path(plan['pins']['numeric_laptop_readiness']['path']).read_text())
 assert human['plan_sha256']==plan['pins']['numeric_laptop_plan']['sha256']
 for name in ('baseline','model'):assert plan['pins'][name]==numeric['pins'][name]
 assert plan['pins']['candidate']==numeric['pins']['baseline']
 clearance=json.loads(Path(plan['pins']['source_ci']['path']).read_text())
 assert clearance['merge']=='6e1623ff0261d3cc5200380cd8f1b15260bc57f4' and clearance['all_nine_CI_jobs_passed'] and clearance['merge_tree_matches_source']
 raw_result=json.loads(Path(plan['pins']['numeric_laptop_result']['path']).read_text())
 assert hashlib.sha256(json.dumps(raw_result,sort_keys=True).encode()).hexdigest()==proof['hosts']['laptop']['source_result_sha256']


def clock(human,plan_sha,now_utc,now_mono):
 if human.get('hour_duration_approved') is not True:
  raise PermissionError('Fresh human approval for the full hour is required')
 age=(now_utc-datetime.fromisoformat(human['recorded_at_utc'])).total_seconds()
 remaining=human['operator_deadline_monotonic']-now_mono
 assert human['mode']==MODE and human['plan_sha256']==plan_sha and 0<=age<=180 and 4100<=remaining<=4380-age+2
 assert human['operator_seconds']==4380 and all(human.get(k) is True for k in
  ('AC_power','lid_open','visible_window','screen_awake','Codex_minimized','other_work_paused','no_suspend'))
 assert human['human_reply'] and human['question_item_id']
 return human['operator_deadline_monotonic']


def load(name,row):
 assert pin(row['path'])==row
 spec=importlib.util.spec_from_file_location(name,row['path']);module=importlib.util.module_from_spec(spec)
 sys.modules[name]=module;spec.loader.exec_module(module);return module


def validate_caps(values,ceilings):
 assert values.keys()==ceilings.keys()
 for path,value in values.items():
  assert type(value) is int and value>0
  assert value<=ceilings[path] if path.endswith('_power_limit_uw') else value==ceilings[path],path


def prepare_host(plan,owner,guard,deadline,log):
 """Same guard, at most70C for60 sampled seconds; naturally recovered Balanced only."""
 since=None;before=None;paths=owner.sensor_paths()
 while time.monotonic()<deadline:
  row=owner.observation(paths);row['power']=owner.power_state()
  row['caps']={p:int(Path(p).read_text()) for p in plan['pre_cap_ceilings']};validate_caps(row['caps'],plan['pre_cap_ceilings'])
  assert not row['read_errors'] and row['power']['ac_online'] and row['power']['lid_open']
  assert owner.guard_identity(Path(plan['pins']['guard_script']['path']),Path(plan['pins']['guard_unit']['path']))==guard
  now=time.monotonic();profile=row['profile_epp_read_only']
  good=(max(row['temperatures_millidegrees_C'].values())<=70000 and
        profile['/sys/firmware/acpi/platform_profile']=='balanced' and
        profile['/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference']=='balance_performance' and
        (before is None or now-before<=5))
  since=(now if since is None else since) if good else None
  row['settled_span_seconds']=0 if since is None else now-since
  log.write(json.dumps(row)+'\n');log.flush()
  if good and now-since>=60:return
  before=now;time.sleep(min(2,max(0,deadline-time.monotonic())))
 raise TimeoutError('Bounded natural Balanced/70C settling interval not reached')


def assess(result):
 native=result.get('native',{});obs=result.get('observations',{});hops=obs.get('service_hops',{})
 count=hops.get('count',0);p99=hops.get('nearest_rank_p99_ms')
 complete=(result.get('requested_seconds')==3600 and native.get('measurement_intervals_closed') is True and
  3600000<=native.get('measured_wall_ms',0)<=3602000 and native.get('shutdown_completed') is True and
  native.get('cancelled') is False and native.get('mode')=='live-stems-hour' and
  native.get('functional_only') is False and native.get('host_audio') is True and
  native.get('forced_redraw_interval_ms')==16 and native.get('ui_mode')=='visible' and
  native.get('window_policy')=='visible')
 record=native.get('recording',{})
 recording_ok=(record.get('status')=='Complete' and record.get('error','')=='' and
  type(record.get('acceptedFrames')) is int and record['acceptedFrames']>0 and
  record['acceptedFrames']==record.get('writtenFrames') and record.get('overflowFrames')==0)
 functional=(complete and result.get('native_exit')==0 and native.get('passed') is True and native.get('error','')=='' and
  native.get('steady_starved_frames')==0 and recording_ok and
  all(native.get(k)==0 for k in ('execution_deadline_misses','invalid_buffers','source_read_failures','rejected_commands')))
 target=(obs.get('service_metrics_complete') is True and hops.get('complete') is True and count>0 and
         type(p99) in (int,float) and p99<4095)
 cleanup=result.get('cleanup',{})
 clean=(result.get('cleanup_proven') is True and cleanup.get('leader_reaped') is True and
        cleanup.get('cooperative_native_shutdown') is True and cleanup.get('ownership_complete') is True and
        not cleanup.get('remaining_known_processes') and cleanup.get('remaining_pipewire_count')==0 and
        not cleanup.get('remaining_live_jobs') and not cleanup.get('ownership_failures') and
        cleanup.get('engine_processes_observed') is True and result.get('pins_unchanged') is True and
        result.get('within_wall_budget') is True)
 return dict(measurement_complete=complete,native_functional_passed=functional,service_target_met=target,
  service_hops=hops,wrapper_passed=result.get('passed'),cleanup_complete=clean,qualified=bool(result.get('qualified') is True and complete and functional and target and clean),
  hard_cancellation_exercised=False,steady_starved_frames=native.get('steady_starved_frames'),
  control_starved_frames=native.get('control_starved_frames'),execution_deadline_misses=native.get('execution_deadline_misses'),
  invalid_buffers=native.get('invalid_buffers'),source_read_failures=native.get('source_read_failures'),recording=native.get('recording'))



def configure_ui_environment():
 """Select the documented basic loop without replacing the graphics backend."""
 assert os.environ.get('QT_QUICK_BACKEND', '') != 'software', 'Default graphics backend required'
 before={name:os.environ.get(name) for name in ('QSG_RENDER_LOOP','QT_LOGGING_RULES','QT_QUICK_BACKEND','QT_QPA_PLATFORM','QT_MESSAGE_PATTERN')}
 rules=os.environ.get('QT_LOGGING_RULES','')
 os.environ['QSG_RENDER_LOOP']='basic'
 os.environ['QT_LOGGING_RULES']=(rules+'\n' if rules else '')+'qt.scenegraph.general=true'
 return dict(before=before,requested_render_loop='basic',
  effective_environment={name:os.environ.get(name) for name in before},
  graphics_backend_setting_unchanged=os.environ.get('QT_QUICK_BACKEND')==before['QT_QUICK_BACKEND'],
  actual_render_loop_requires_native_log=True)


def render_loop_proof(output):
 """A requested environment value alone cannot establish the native render loop."""
 import re
 matches=[];issues=[];captures=[]
 for name in ('native.stdout.log','native.stderr.log'):
  path=Path(output)/name
  if not path.is_file() or path.is_symlink() or path.stat().st_size>4*1024*1024:
   issues.append(name+': missing, symlink or oversized');continue
  captures.append(pin(path))
  for line in path.read_text(errors='replace').splitlines():
   found=re.search(r'(?:^|[ \t])qt\.scenegraph\.general:[ \t]*(basic|threaded) render loop[ \t]*$',line)
   if found:matches.append(dict(capture=name,line=line,loop=found.group(1)))
 loops=sorted({row['loop'] for row in matches})
 return dict(requested='basic',observed_loops=loops,confirmed=loops==['basic'] and not issues,
  captures=captures,messages=matches,issues=issues,
  missing_or_conflicting_log_never_proves_requested_loop=True)


def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
 plan_path=BASE/'laptop-plan.json';plan=json.loads(plan_path.read_text())
 if not args.run:
  verify(plan);environment=configure_ui_environment();print(json.dumps(dict(verified=True,hardware_started=False,ui_environment=environment)));return 0
 assert plan['state']=='frozen_pending_fresh_readiness','Draft player packet is unarmed'
 human=json.loads((BASE/'readiness.json').read_text())
 deadline=clock(human,pin(plan_path)['sha256'],datetime.now(timezone.utc),time.monotonic())
 root=BASE/'laptop-results-01';root.mkdir(mode=0o700)
 report=dict(schema=1,mode=MODE,original_readiness_utc=human['recorded_at_utc'],deadline_monotonic=deadline,
  completed=False,cleanup_complete=False,qualified=False,no_retries=True,arms={},errors=[],workload_attempted_arms=[])
 def checkpoint():save(root/'pair-result.json',report)
 def alarm(number,frame):raise InterruptedError('Original owned deadline reached')
 # Reserve 120 seconds for cap and sync restoration before the unit's own
 # stop boundary, then 90 seconds for its independent fallback on this clock.
 signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,max(.1,deadline-time.monotonic()-240))
 try:
  verify(plan)
  owner=load('staging_host_readings',plan['pins']['host_readings'])
  guard=owner.guard_identity(Path(plan['pins']['guard_script']['path']),Path(plan['pins']['guard_unit']['path']))
  report['guard_before']=guard;checkpoint()
  for arm in ARMS:
   assert deadline-time.monotonic()>=4170,'No native setup/measurement/cleanup room on original clock'
   case=root/arm;case.mkdir(mode=0o700);started=time.monotonic();arm_deadline=deadline-240
   # Authentication has a bounded 90-second wait. Leave that room before
   # requesting a privileged apply, while retaining the native 3780s bound.
   with (case/'settling.jsonl').open('x') as log:prepare_host(plan,owner,guard,min(started+240,arm_deadline-3880),log)
   verify(plan)
   report['storage_before_cap']=load('pre_cap_storage',plan['pins']['storage_check']).verify(BASE);checkpoint()
   assert arm_deadline-time.monotonic()>=3870,'No time for authentication and the unchanged native bound'
   cap=load('approved_short_cap',plan['pins']['burst_client'])
   report['cap_apply']=cap.start(human,plan);checkpoint()
   assert arm_deadline-time.monotonic()>=3780,'No minimum native work/cleanup room'
   cache=case/'driver-cache';shutil.copytree(plan['cache_seed'],cache)
   os.environ.update(MESA_SHADER_CACHE_DIR=str(cache),MESA_SHADER_CACHE_MAX_SIZE='128M')
   wrapper=load('staging_actual_player_'+arm,plan['pins']['wrapper'])
   assert wrapper.FLASH_RUNTIME_SHA256==plan['original_promoted_runtime_sha256']
   # Explicit private runtime binding after the full-output prerequisite above.
   # All processing, collection, visibility, source and health gates stay in the public owner.
   wrapper.FLASH_RUNTIME_SHA256=plan['pins'][arm]['sha256']
   original_observation=wrapper.observation
   def monitored(paths):
    cap.verify_held()
    row=original_observation(paths);row['configured_power_caps']={p:int(Path(p).read_text()) for p in plan['cap_ceilings']}
    validate_caps(row['configured_power_caps'],plan['cap_ceilings']);return row
   wrapper.observation=monitored
   readiness=dict(human,schema=1,decision='ready',ready_for_run='output-01',ui_mode='visible')
   readiness_path=case/'readiness.json';save(readiness_path,readiness)
   parameters={k:Path(plan['pins'][k]['path']) for k in ('binary','track_a','track_b','python','exporter','worker','service','model','guard_script','guard_unit')}
   parameters.update(runtime=Path(plan['pins'][arm]['path']),seconds=3600,live_stems=False,live_stems_hour=True,background=False,
    active_controls=False,normal_redraw=False,output=case/'output-01',readiness_decision=readiness_path)
   signal.setitimer(signal.ITIMER_REAL,max(.1,arm_deadline-time.monotonic()))
   report['workload_attempted_arms'].append(arm);checkpoint()
   save(case/'ui-environment-01.json',configure_ui_environment())
   code=wrapper.run_live(SimpleNamespace(**parameters))
   signal.setitimer(signal.ITIMER_REAL,max(.1,deadline-time.monotonic()-240))
   cap.verify_held()
   result=json.loads((case/'output-01/result.json').read_text());assessment=assess(result)
   assessment.update(wrapper_exit=code,seconds=time.monotonic()-started,ui_render_loop=render_loop_proof(case/'output-01'))
   report['arms'][arm]=assessment;save(case/'assessment.json',assessment);checkpoint()
   assert assessment['cleanup_complete'],'Owned native/service cleanup not proven'
   assert assessment['measurement_complete'],'Incomplete first arm retained; no next arm'
  verify(plan)
  report['guard_after']=owner.guard_identity(Path(plan['pins']['guard_script']['path']),Path(plan['pins']['guard_unit']['path']))
  assert report['guard_after']==guard
  report['completed']=True
 except BaseException as error:report['errors'].append(dict(type=type(error).__name__,error=str(error)))
 finally:
  signal.setitimer(signal.ITIMER_REAL,0)
  report['finished_monotonic']=time.monotonic()
  report['within_original_window']=report['finished_monotonic']<=deadline
  for arm in report['workload_attempted_arms']:
   if arm not in report['arms']:
    p=root/arm/'output-01/result.json'
    if p.exists():
     try:report['arms'][arm]=assess(json.loads(p.read_text()))
     except Exception as error:report['errors'].append(dict(phase='partial-result-inspection',error=str(error)))
  report['cleanup_complete']=(len(report['arms'])==len(report['workload_attempted_arms']) and
    all(a['cleanup_complete'] for a in report['arms'].values()))
  report['completed']=report['completed'] and report['cleanup_complete'] and report['within_original_window'] and not report['errors']
  report['qualified']=bool(report['completed'] and report['arms'] and all(a['qualified'] for a in report['arms'].values()))
  checkpoint()
 print(json.dumps({k:report[k] for k in ('completed','cleanup_complete','errors')}))
 return 0 if report['completed'] else 1


if __name__=='__main__':raise SystemExit(main())
