#!/usr/bin/python
"""Private descriptor-limited player case, called only by the isolated audio owner."""
from pathlib import Path
import importlib.util
import json
import os
import signal
import stat
import subprocess
import sys
import time

if len(sys.argv)!=4 or sys.argv[3]!='--functional-only' or os.environ.get('CONFLUX_PRIVATE_ROUTING_CHECK')!='1':
    raise SystemExit('Explicit private functional routing only')
arm=os.environ.get('CONFLUX_STAGING_ARM');assert arm in ('baseline','candidate')
normal=False;mode='live-stems-hour'
runtime=Path(sys.argv[1]);assert runtime.is_absolute() and runtime.stat().st_uid==os.getuid() and stat.S_IMODE(runtime.stat().st_mode)==0o700
output=Path(sys.argv[2])/'actual-player';output.mkdir(mode=0o700);(output/'cache').mkdir(mode=0o700)
source=Path('/inputs/club-xl.wav');peer=Path('/inputs/quiet-peer.wav')
report=dict(schema=1,arm=arm,passed=False,measurement_complete=False,qualified=False,host_audio=False,
    scope='One-hour actual Best-quality NVIDIA repeated-generation diagnostic at16ms forced redraw; secondary virtual audio/software UI only, no laptop or physical qualification',
    hard_cancellation_exercised=False)
child=sink=None
try:
    with (output/'sink.stdout.log').open('x') as out,(output/'sink.stderr.log').open('x') as err:
        sink=subprocess.Popen(['/results/private_sink'],stdin=subprocess.PIPE,stdout=out,stderr=err,text=True)
    until=time.monotonic()+8
    while time.monotonic()<until:
        assert sink.poll() is None,'Private sink exited'
        graph=json.loads(subprocess.check_output(['pw-dump','-r',os.environ['PIPEWIRE_REMOTE'],'-N'],text=True,timeout=3))
        nodes=[p for p in graph if p.get('type','').endswith(':Node') and p.get('info',{}).get('props',{}).get('node.name')=='conflux-short-live-test-sink']
        if len(nodes)==1:break
        time.sleep(.05)
    else:raise TimeoutError('Owned sink did not appear')
    (output/'sink-graph.json').write_text(json.dumps(graph,indent=2)+'\n')
    client_id=nodes[0]['info']['props']['client.id']
    clients=[p for p in graph if p.get('type','').endswith(':Client') and str(p['id'])==str(client_id)]
    assert len(clients)==1 and str(clients[0]['info']['props']['application.process.id'])==str(sink.pid),'Sink client ownership differs'
    environment=dict(os.environ,QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software',QT_QUICK_CONTROLS_STYLE='Basic',XDG_CACHE_HOME=str(output/'cache'))
    environment.pop('CONFLUX_ALLOW_HOST_SOAK',None)
    command=['/player/conflux-manual-playback-soak','--'+mode,str(source),str(peer),str(output),'3600',str(output/'stop'),
        '/usr/bin/python','/work/source/tools/stems/export.py','/work/source/tools/stems/worker.py','/work/source/tools/stems/service.py',
        '/runtime/conflux-stem-runtime','/model/htdemucs-f16.gguf']
    report['command']=command;began=time.monotonic()
    with (output/'player.stdout.log').open('x') as out,(output/'player.stderr.log').open('x') as err:
        child=subprocess.Popen(command,env=environment,stdout=out,stderr=err,start_new_session=True)
        try:child.wait(timeout=3780)
        except subprocess.TimeoutExpired:
            (output/'stop').touch()
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=3)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=3)
            raise TimeoutError('Native player exceeded the original fixed3780s bound')
    report.update(native_exit=child.returncode,elapsed_seconds=time.monotonic()-began)
    path=output/'native-result.json';assert path.stat().st_size<=1024*1024
    native=json.loads(path.read_text())
    keys=['mode','forced_redraw_interval_ms','functional_only','host_audio','qualified','passed','error','measurement_completion_error',
        'setup','measured_wall_ms','frames_presented','maximum_gui_heartbeat_gap_ns','maximum_frame_presentation_gap_ns',
        'steady_starved_frames','control_starved_frames','eof_count','replay_count','last_recovery_complete','execution_deadline_misses',
        'invalid_buffers','source_read_failures','shutdown_completed','diagnostic_tail','configuration','observation_counters',
        'manual_controls_complete','manual_controls','controls','recording']
    report['native_summary']={k:native[k] for k in keys if k in native}
    report['measurement_complete']=(native.get('measurement_intervals_closed') is True and 3600000<=native.get('measured_wall_ms',0)<=3602000
        and native.get('mode')==mode and native.get('forced_redraw_interval_ms')==(50 if normal else 16)
        and native.get('functional_only') is True and native.get('host_audio') is False and native.get('qualified') is False
        and native.get('shutdown_completed') is True and native.get('cancelled') is False)
    spec=importlib.util.spec_from_file_location('matched_private_observations','/work/source/tools/experiments/run_manual_playback_soak.py')
    parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
    observations=parser.summarize_live_observations(output/'observations.jsonl',native)
    report['observations']=observations
    report['runtime_sha256_expected']=os.environ['CONFLUX_EXPECTED_RUNTIME_SHA256']
    assert native['setup']['runtime_sha256']==report['runtime_sha256_expected']
    assert native['setup']['model_sha256']=='f8c54ba35df95aafea7881eac214b58ec18a73cbcb6ff5a90f4b762631a286b6'
    (output/'observation-summary.json').write_text(json.dumps(observations,indent=2)+'\n')
    hops=observations['service_hops']
    report['service_target_met']=(observations['service_metrics_complete'] is True and hops['complete'] is True and hops['count']>0
        and hops['nearest_rank_p99_ms']<4095)
    report['strict_target_ms']=4095
    report['native_functional_passed']=(report['measurement_complete'] and child.returncode==0 and native.get('passed') is True and native.get('steady_starved_frames')==0)
    report['passed']=(report['measurement_complete'] and child.returncode==0 and native.get('passed') is True
        and native.get('last_recovery_complete') is True)
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
    if child is not None and child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
    if sink is not None:
        if sink.poll() is None:
            sink.stdin.write('stop\n');sink.stdin.flush();sink.stdin.close()
            try:sink.wait(timeout=5)
            except subprocess.TimeoutExpired:sink.kill();sink.wait(timeout=5)
        report['sink_reaped']=sink.poll() is not None
    (output/'assessment.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,allow_nan=False),flush=True)
raise SystemExit(0 if report['passed'] else 1)
