from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import os
import tempfile
import subprocess
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('pause_under_test', BASE / 'onedrive_pause.py')
pause = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pause)


class PauseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=BASE)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.token = self.root / 'onedrive-pause-state.json'
        self.proposal = self.root / 'proposal.json'
        self.proposal.write_text(json.dumps(dict(unit='onedrive.service')))
        self.state = dict(ActiveState='active', MainPID='15', InactiveEnterTimestampMonotonic='10')
        self.actions = []

    def mutate(self, action):
        self.actions.append(action)
        self.state.update(ActiveState='inactive' if action == 'stop' else 'active',
            MainPID='0' if action == 'stop' else '20', InactiveEnterTimestampMonotonic='20')

    def context(self):
        return (patch.object(pause, 'TOKEN', self.token), patch.object(pause, 'PROPOSAL', self.proposal),
            patch.object(pause, 'show', side_effect=lambda: copy.deepcopy(self.state)),
            patch.object(pause, 'validate'), patch.object(pause, 'change', side_effect=self.mutate))

    def test_no_approval_does_not_stop_an_active_service(self):
        a,b,c,d,e=self.context()
        with a,b,c,d,e,self.assertRaises(PermissionError):pause.pause(False,'fixture')
        self.assertEqual(self.actions,[])
        self.assertFalse(self.token.exists())

    def test_missing_token_restore_has_no_host_queries_or_actions(self):
        a,b,c,d,e=self.context()
        with a,b,c as query,d,e:
            self.assertTrue(pause.restore()['no_pause_token'])
            query.assert_not_called()
        self.assertEqual(self.actions,[])

    def test_approved_pause_restores_once_and_checks_held_state(self):
        a,b,c,d,e=self.context()
        with a,b,c,d,e:
            pause.pause(True,'fixture');pause.verify_held()
            result=pause.restore();again=pause.restore()
        self.assertEqual(self.actions,['stop','start'])
        self.assertEqual(result['restoration'],'original_active_service_restored')
        self.assertTrue(again['already_restored'])

    def test_originally_inactive_service_stays_inactive(self):
        self.state.update(ActiveState='inactive',MainPID='0')
        a,b,c,d,e=self.context()
        with a,b,c,d,e:
            pause.pause(False,'fixture');pause.verify_held();pause.restore()
        self.assertEqual(self.actions,[])

    def test_service_identity_failure_prevents_stop(self):
        a,b,c,d,e=self.context()
        with a,b,c,d as validate,e,self.assertRaises(AssertionError):
            validate.side_effect=AssertionError('wrong executable')
            pause.pause(True,'fixture')
        self.assertEqual(self.actions,[])

    def test_failure_after_stop_still_leaves_a_restorable_intent(self):
        a,b,c,d,e=self.context()
        with a,b,c,d,e:
            def stop_then_fail(action):
                self.mutate(action)
                if action=='stop':raise RuntimeError('transport ended after stop')
            with patch.object(pause,'change',side_effect=stop_then_fail),self.assertRaises(RuntimeError):
                pause.pause(True,'fixture')
            pause.restore()
        self.assertEqual(self.actions,['stop','start'])

    def test_user_transition_is_preserved_and_invalidates_isolation(self):
        a,b,c,d,e=self.context()
        with a,b,c,d,e:
            pause.pause(True,'fixture')
            self.state['InactiveEnterTimestampMonotonic']='30'
            with self.assertRaises(AssertionError):pause.verify_held()
            result=pause.restore()
        self.assertEqual(self.actions,['stop'])
        self.assertEqual(result['restoration'],'foreign_transition_left_unchanged')

    def test_proposal_drift_prevents_restoring_an_unknown_service(self):
        a,b,c,d,e=self.context()
        with a,b,c,d,e:
            pause.pause(True,'fixture');self.proposal.write_text('{}')
            with self.assertRaises(AssertionError):pause.restore()
        self.assertEqual(self.actions,['stop'])

    def test_missing_readiness_blocks_guarded_owner_import(self):
        s=importlib.util.spec_from_file_location('guarded_under_test',BASE/'run_local_guarded.py')
        guarded=importlib.util.module_from_spec(s);s.loader.exec_module(guarded)
        with patch.object(guarded,'BASE',self.root),patch('sys.argv',['fixture','--run']),patch.object(guarded,'load') as load,self.assertRaises(FileNotFoundError):guarded.main()
        load.assert_not_called()

    def metadata_fixture(self):
        unit=self.root/'onedrive.service';unit.write_text('fixture unit')
        binary=self.root/'onedrive';binary.write_text('fixture binary')
        def row(path):return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        proposal=dict(unit=pause.UNIT,user_uid=os.getuid(),unit_file=row(unit),executable=row(binary))
        state=dict(LoadState='loaded',DropInPaths='',FragmentPath=str(unit),ActiveState='inactive',MainPID='0')
        return proposal,state,unit,binary

    def test_actual_validator_rejects_changed_unit_bytes(self):
        proposal,state,unit,binary=self.metadata_fixture()
        pause.validate(state,proposal)
        unit.write_text('changed unit')
        with self.assertRaises(AssertionError):pause.validate(state,proposal)

    def test_actual_validator_requires_exact_executable_and_cgroup(self):
        proposal,state,unit,binary=self.metadata_fixture()
        proc=self.root/'proc';directory=proc/'15';directory.mkdir(parents=True)
        (directory/'exe').symlink_to(binary);(directory/'cgroup').write_text('0::/user/onedrive.service\n')
        state.update(ActiveState='active',MainPID='15',ControlGroup='/user/onedrive.service')
        with patch.object(pause,'PROC',proc):
            pause.validate(state,proposal)
            other=self.root/'unrelated';other.write_text('other')
            (directory/'exe').unlink();(directory/'exe').symlink_to(other)
            with self.assertRaises(AssertionError):pause.validate(state,proposal)

    def test_guarded_wrapper_restores_after_pause_raises(self):
        s=importlib.util.spec_from_file_location('guarded_finally_test',BASE/'run_local_guarded.py')
        guarded=importlib.util.module_from_spec(s);s.loader.exec_module(guarded)
        driver=self.root/'run_laptop_pair.py';driver.write_text('# fixture')
        row=dict(path=str(driver),bytes=driver.stat().st_size,sha256=hashlib.sha256(driver.read_bytes()).hexdigest())
        (self.root/'laptop-plan.json').write_text(json.dumps(dict(pins=dict(driver=row,sync_pause_helper={'fixture':True}))))
        (self.root/'readiness.json').write_text(json.dumps(dict(question_item_id='fixture',onedrive_pause_approved=True,hour_duration_approved=True,operator_deadline_monotonic=time.monotonic()+4380)))
        def stop_then_raise(*args):self.token.write_text('{}');raise RuntimeError('fixture failure after pause intent')
        helper=SimpleNamespace(TOKEN=self.token,PROPOSAL=self.root/'onedrive-proposal.json',pause=Mock(side_effect=stop_then_raise),restore=Mock())
        runner=SimpleNamespace(clock=Mock(),pin=Mock(return_value={'sha256':'fixture'}),verify=Mock(),load=Mock(return_value=helper),main=Mock())
        with patch.object(guarded,'BASE',self.root),patch('sys.argv',['fixture','--run']),patch.object(guarded,'load',return_value=runner),self.assertRaises(RuntimeError):guarded.main()
        helper.restore.assert_called_once_with();runner.main.assert_not_called()
        outcome=json.loads((self.root/'guarded-outcome.json').read_text())
        self.assertFalse(outcome['passed'])
        self.assertIn('fixture failure after pause intent',outcome['run_error'])

    def test_delayed_service_start_finishes_and_is_never_issued_twice(self):
        a,b,c,d,e=self.context()
        def delayed_systemctl(command,check,timeout):
            duration=15.1 if command[-2]=='start' else 2
            if timeout<duration:raise subprocess.TimeoutExpired(command,timeout)
            self.mutate(command[-2])
            return subprocess.CompletedProcess(command,0)
        # Run the real change() through a service that needs longer than its
        # unit's 15-second pre-start sleep. The original helper times out here.
        with a,b,c,d,patch.object(pause.subprocess,'run',side_effect=delayed_systemctl) as called:
            pause.pause(True,'fixture');pause.verify_held()
            result=pause.restore();pause.restore()
        self.assertEqual(self.actions,['stop','start'])
        self.assertEqual(called.call_count,2)
        self.assertTrue(result['restore_complete'])

    def test_genuine_start_timeout_is_retained_without_a_second_start(self):
        a,b,c,d,e=self.context()
        with a,b,c,d,e:
            pause.pause(True,'fixture')
            with patch.object(pause,'change',side_effect=subprocess.TimeoutExpired(['systemctl','start'],45)) as called:
                with self.assertRaises(subprocess.TimeoutExpired):pause.restore()
            called.assert_called_once_with('start')
        self.assertFalse(json.loads(self.token.read_text())['restore_complete'])

    def test_guarded_outcome_retains_restoration_failure_despite_zero_owner_exit(self):
        s=importlib.util.spec_from_file_location('guarded_restore_test',BASE/'run_local_guarded.py')
        guarded=importlib.util.module_from_spec(s);s.loader.exec_module(guarded)
        driver=self.root/'run_laptop_pair.py';driver.write_text('# fixture')
        row=dict(path=str(driver),bytes=driver.stat().st_size,sha256=hashlib.sha256(driver.read_bytes()).hexdigest())
        (self.root/'laptop-plan.json').write_text(json.dumps(dict(pins=dict(driver=row,sync_pause_helper={'fixture':True}))))
        (self.root/'readiness.json').write_text(json.dumps(dict(question_item_id='fixture',onedrive_pause_approved=True,hour_duration_approved=True,operator_deadline_monotonic=time.monotonic()+4380)))
        def paused(*args):self.token.write_text(json.dumps(dict(pause_held_through_native_cleanup=True,restore_complete=False)))
        helper=SimpleNamespace(TOKEN=self.token,PROPOSAL=self.root/'onedrive-proposal.json',pause=Mock(side_effect=paused),verify_held=Mock(),restore=Mock(side_effect=TimeoutError('start timeout')))
        runner=SimpleNamespace(clock=Mock(),pin=Mock(return_value={'sha256':'fixture'}),verify=Mock(),load=Mock(return_value=helper),main=Mock(return_value=0))
        with patch.object(guarded,'BASE',self.root),patch('sys.argv',['fixture','--run']),patch.object(guarded,'load',return_value=runner),self.assertRaises(TimeoutError):guarded.main()
        outcome=json.loads((self.root/'guarded-outcome.json').read_text())
        self.assertEqual(outcome['owner_exit'],0)
        self.assertFalse(outcome['passed'])
        self.assertIn('start timeout',outcome['restoration_error'])

    def test_guarded_success_requires_native_completion_held_pause_and_restoration(self):
        s=importlib.util.spec_from_file_location('guarded_success_test',BASE/'run_local_guarded.py')
        guarded=importlib.util.module_from_spec(s);s.loader.exec_module(guarded)
        driver=self.root/'run_laptop_pair.py';driver.write_text('# fixture')
        row=dict(path=str(driver),bytes=driver.stat().st_size,sha256=hashlib.sha256(driver.read_bytes()).hexdigest())
        (self.root/'laptop-plan.json').write_text(json.dumps(dict(pins=dict(driver=row,sync_pause_helper={'fixture':True}))))
        (self.root/'readiness.json').write_text(json.dumps(dict(question_item_id='fixture',onedrive_pause_approved=True,hour_duration_approved=True,operator_deadline_monotonic=time.monotonic()+4380)))
        def paused(*args):self.token.write_text(json.dumps(dict(pause_held_through_native_cleanup=True,restore_complete=False)))
        def restored():self.token.write_text(json.dumps(dict(pause_held_through_native_cleanup=True,restore_complete=True)))
        helper=SimpleNamespace(TOKEN=self.token,PROPOSAL=self.root/'onedrive-proposal.json',pause=Mock(side_effect=paused),verify_held=Mock(),restore=Mock(side_effect=restored))
        runner=SimpleNamespace(clock=Mock(),pin=Mock(return_value={'sha256':'fixture'}),verify=Mock(),load=Mock(return_value=helper),main=Mock(return_value=0))
        with patch.object(guarded,'BASE',self.root),patch('sys.argv',['fixture','--run']),patch.object(guarded,'load',return_value=runner):
            self.assertEqual(guarded.main(),0)
        self.assertTrue(json.loads((self.root/'guarded-outcome.json').read_text())['passed'])
        helper.restore.assert_called_once_with()


if __name__ == '__main__':unittest.main()
