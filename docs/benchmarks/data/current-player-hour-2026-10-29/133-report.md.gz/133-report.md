# Best-quality current-player hour results

The primary laptop completed the full hour and passed the unchanged **4.095-second service p99 target**, reaching **2.729 seconds** across 537 completed deliveries. Apollo's matching build completed its earlier private-virtual-audio hour at **0.994 seconds**. The laptop's result qualifies the fixed-mix hour under the tested configuration. M2/M3 and the 0.1.0 release still have other open gates.

| Observation | Laptop, physical audio and visible UI | Apollo, private virtual audio |
| --- | ---: | ---: |
| Closed measured interval | 3,600.011 s | 3,600.005 s |
| Completed service deliveries | 537 | 555 |
| Nearest-rank p99 | **2.728795 s** | **0.994327 s** |
| Maximum service delivery | 2.833984 s | 1.026122 s |
| Deliveries at or above 4.095 s | 0 | 0 |
| Steady stem starvation | 0 s | 0 s |
| Seek/replay buffering | 478.251 s | 386.421 s |
| EOF/replay cycles | 133 | 137 |
| Peer rewinds | 8 | 8 |
| Callback deadline misses | 0 | 0 |
| Driver discontinuities / recovery flags | 0 / 0 | 0 / 0 |
| Recording overflow frames | 0 | 0 |
| Recording frames accepted and written | 173,079,296 | 173,330,432 |

Both hosts used Best quality and the same frozen current-player source at `6e1623ff0261d3cc5200380cd8f1b15260bc57f4`. This is a two-deck fixed-mix workload with repeated Club XL playback, a quiet peer, seeks/replays, recording and visible 16 ms UI load. It does not exercise every M3 control. Apollo's completed original hour was retained while the laptop was retried after a user-confirmed desktop switch; the two successful hours did not share a start time. This is not a counterbalanced causal comparison.

The laptop p99 and maximum were independently recomputed from every completed hop, including the final hop retained during the bounded finite-generation drain. No late delivery was censored. Its 19.853-second diagnostic tail closed the final generation without additional starvation or callback misses; the measured interval and finalized recording counts stayed fixed. No observation records were dropped or had invalid clock reads.

All 1,761 two-second host samples retained Balanced mode and the approved 15 W MMIO long/short limits. The sampled maximum was **77°C**, with no sample at or above 85°C or 95°C. Samples do not exclude shorter spikes. The existing thermal guard remained active and unchanged. This result is conditional on the temporary 15 W short-term cap and copied verified shader-cache setup; it does not establish the same result with the normal 64 W burst setting, an empty cache or another workload.

Both hosts exercised a logical seek of an accepted generation without an observed RawComplete and rejected one stale packet each. No native inference-start instant or hard GPU-worker termination was measured. Seek/replay buffering remains an unresolved usability cost, reported separately above; zero steady starvation does not mean instant seeks. Load to the first observed cursor advance was 5.820 seconds on the laptop and 11.010 seconds on Apollo. These service and cursor timings do not measure physical acoustic latency.

Invalid buffers, rejected commands, source-read failures and scene errors were zero. The finalized stereo 48 kHz float32 WAV header, payload length and frame count agree with the native whole-recording scan. No new listening verdict was obtained. The laptop's requested basic render loop was independently confirmed from the exact native process's original journal message; the original empty stdout/stderr assessment remains preserved.

The temporary short-term allowance was restored from 15 W to its original **64 W before OneDrive resumed**. Independent checks confirm the pinned OneDrive executable is active, the same thermal-guard process remains active, the root cap helper is gone, the completed user unit and its original cgroup are gone, and KDE's inhibition list is empty. No permanent host policy was installed. The earlier interrupted laptop result and authentication timeouts remain retained. The later retry also fixes idempotent observation of already-restored cleanup after a deadline; four regression cases cover the cleanup boundary, with three reproducing the previous error before the fix; all 96 offline checks plus the actual unarmed desktop entry pass.

The [audited summary](results-summary-01.json), [WAV audit](WAV-audit-01.json), [render-loop journal proof](render-loop-journal-proof-01.json) and [owner retirement](owner-retirement-01.json) retain the result. [Apollo's full evidence](../../m2-current-player-hour-03/analysis-01/apollo-capture-receipt-01.json) and the [interrupted predecessor](../../m2-current-player-hour-03/analysis-01/report.md) remain separate. The [evidence manifest](evidence-manifest-01.json) binds the input files; audio, models, binaries and mutable caches are excluded.

This closes the current fixed-mix laptop hour requirement for these explicit conditions. Hard-worker cancellation, remaining musical-analysis/fallback and live-stem tempo work, and the combined prepared-loop/Master Tempo listening check remain open. No milestone or release was marked complete, and no new hardware test is running.
