"""One bounded, reversible MMIO short-term cap; importing or dry mode does nothing."""
import argparse
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import stat
import tempfile
import time

DIRECTORY = Path('/run/conflux-m2-current-hour-cap-20261029-04')
CAP = Path('/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_1_power_limit_uw')
MSR = Path('/sys/devices/virtual/powercap/intel-rapl/intel-rapl:0')
STOP = Path('/home/kyau/projects/kyaulabs/conflux/build/m2-current-player-hour-04/packet-01/burst-cap-stop')
UNIT = 'conflux-m2-current-hour-cap-20261029-04.service'
GUARD = Path('/home/kyau/.local/bin/thermal-guard')
GUARD_SHA = '6e2ebbe97e3fc4a679c16b347b67fe99f9daf88391cb68aa3ca8924fd65886d6'
GUARD_UNIT = Path('/home/kyau/.config/systemd/user/thermal-guard.service')
GUARD_UNIT_SHA = 'e5c6c89f2b186b976379b2ee4ffb0d3e044e1cf9b1fca3a0cf60cc600c9b2d8f'
LIMIT = 15000000
BEFORE = 64000000
STATE = DIRECTORY / 'state.json'
CONFIG = DIRECTORY / 'config.json'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def trusted_json(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022 or info.st_size > 65536:
        raise PermissionError('Unsafe root receipt: ' + str(path))
    return json.loads(path.read_text())


def save(path, value):
    """Publish a root-owned receipt durably before any potentially ambiguous write."""
    fd, temporary = tempfile.mkstemp(prefix='.receipt-', dir=DIRECTORY)
    try:
        with os.fdopen(fd, 'w') as stream:
            stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')
            stream.flush()
            os.fchmod(stream.fileno(), 0o644)
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        directory_fd = os.open(DIRECTORY, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def number(path):
    value = path.read_text().strip()
    if not value.isdecimal() or int(value) <= 0:
        raise ValueError('Invalid positive constraint: ' + str(path))
    return int(value)


def constraints():
    values = {}
    for domain in (CAP.parent, MSR):
        if (domain / 'name').read_text().strip() != 'package-0' or (domain / 'enabled').read_text().strip() != '1':
            raise ValueError('Unexpected or disabled package domain')
        for index, name in ((0, 'long_term'), (1, 'short_term')):
            if (domain / f'constraint_{index}_name').read_text().strip() != name:
                raise ValueError('Unexpected constraint identity')
            for suffix in ('power_limit_uw', 'time_window_us'):
                path = domain / f'constraint_{index}_{suffix}'
                values[str(path)] = number(path)
    return values


def check_deadline(config):
    now = time.monotonic()
    deadline = config['deadline_monotonic']
    if type(deadline) not in (int, float) or not math.isfinite(deadline) or not 0 < deadline - now <= 4380:
        raise TimeoutError('Original bounded lease expired or invalid')
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip() != config['boot_id']:
        raise ValueError('Lease belongs to another boot')
    if os.path.lexists(STOP):
        raise InterruptedError('Stop requested before apply')


def validate_host(config):
    check_deadline(config)
    if Path('/sys/class/dmi/id/product_name').read_text().strip() != '20XW004NUS':
        raise ValueError('Only the verified X1 Carbon is authorized')
    if digest(GUARD) != GUARD_SHA or digest(GUARD_UNIT) != GUARD_UNIT_SHA:
        raise ValueError('Approved thermal guard identity changed')
    if Path('/sys/firmware/acpi/platform_profile').read_text().strip() != 'balanced':
        raise ValueError('Wait for natural Balanced recovery before applying')
    values = constraints()
    if values[str(CAP)] != BEFORE or values[str(CAP.parent / 'constraint_0_power_limit_uw')] > LIMIT:
        raise ValueError('Current ceilings do not match the approved comparison')
    return values


def write_cap(value):
    # This is the only host-policy write in the payload. There is no arbitrary path option.
    with CAP.open('w') as stream:
        stream.write(str(value) + '\n')


def apply(config):
    values = validate_host(config)
    if STATE.exists():
        raise FileExistsError('This lease cannot apply twice')
    record = dict(schema=1, cap=str(CAP), before_uw=values[str(CAP)], applied_uw=LIMIT,
        deadline_monotonic=config['deadline_monotonic'], boot_id=config['boot_id'],
        constraints_before=values, phase='write_intent', write_returned=False,
        external_values_observed=[], restoration_complete=False, finished=False)
    save(STATE, record)
    # Recheck immediately before writing; do not raise an observed lower external limit.
    check_deadline(config)
    if number(CAP) != record['before_uw']:
        record.update(phase='external_change_before_apply', no_write=True)
        save(STATE, record)
        raise ValueError('Short-term limit changed before the sole apply')
    write_cap(LIMIT)
    record.update(write_returned=True, phase='write_returned')
    save(STATE, record)
    if number(CAP) != LIMIT:
        raise ValueError('Short-term cap readback did not match')
    record.update(phase='applied', applied_monotonic=time.monotonic())
    save(STATE, record)
    return record


def observe(record):
    current = number(CAP)
    if current != LIMIT:
        record['external_values_observed'].append(current)
        save(STATE, record)
        raise ValueError('External short-term transition invalidates the comparison')
    values = constraints()
    for path, before in record['constraints_before'].items():
        if path == str(CAP):
            continue
        # Thermal firmware may lower another power ceiling; never counteract it.
        okay = values[path] <= before if path.endswith('_power_limit_uw') else values[path] == before
        if not okay:
            raise ValueError('Unrelated constraint rose or time window changed: ' + path)
    if digest(GUARD) != GUARD_SHA or digest(GUARD_UNIT) != GUARD_UNIT_SHA:
        raise ValueError('Guard changed during the lease')


def restore():
    if not STATE.exists():
        result = dict(schema=1, no_apply_receipt=True, restoration_complete=True, finished=True)
        save(STATE, result)
        return result
    record = trusted_json(STATE)
    if record.get('finished'):
        return record
    if record.get('cap') != str(CAP) or record.get('before_uw') != BEFORE or record.get('applied_uw') != LIMIT:
        raise ValueError('Unexpected restore receipt')
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip() != record['boot_id']:
        raise ValueError('Never restore across a reboot')
    current = number(CAP)
    record['before_restore_uw'] = current
    if record.get('no_write'):
        disposition = 'external_change_before_apply_left_unchanged'
    elif not record.get('write_returned'):
        # SIGKILL between the sysfs write and durable confirmation is ambiguous.
        # Keep the safer observed ceiling; never infer permission to raise it.
        record.update(phase='unconfirmed_apply_preserved', finished=True, restoration_complete=False,
            after_restore_uw=current)
        save(STATE, record)
        return record
    elif current != LIMIT:
        disposition = 'external_value_left_unchanged'
    elif record['external_values_observed']:
        target = min([current] + record['external_values_observed'])
        if target < current:
            write_cap(target)
        disposition = 'observed_external_limit_preserved'
    else:
        write_cap(record['before_uw'])
        disposition = 'owned_unchanged_write_restored'
    after = number(CAP)
    expected = record['before_uw'] if disposition == 'owned_unchanged_write_restored' else (
        min([current] + record['external_values_observed']) if disposition == 'observed_external_limit_preserved' else current)
    if after != expected:
        raise ValueError('Restoration readback failed; cleanup not proven')
    record.update(phase='finished', restoration=disposition, after_restore_uw=after,
        restored_monotonic=time.monotonic(), restoration_complete=True, finished=True)
    save(STATE, record)
    return record


def run(config):
    try:
        record = apply(config)
        while time.monotonic() < config['deadline_monotonic'] and not os.path.lexists(STOP):
            observe(record)
            time.sleep(min(1, max(0, config['deadline_monotonic'] - time.monotonic())))
    finally:
        restore()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--restore', action='store_true')
    args = parser.parse_args()
    if not (args.run or args.restore):
        print(json.dumps(dict(unarmed=True, host_queried=False, policy_written=False,
            cap=str(CAP), ceiling_uw=LIMIT, maximum_seconds=4380)))
        return 0
    if args.run and args.restore:
        raise ValueError('Choose exactly one action')
    if os.geteuid() != 0:
        raise PermissionError('The bounded helper requires administrator authentication')
    info = DIRECTORY.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise PermissionError('Unsafe lease directory')
    fd = os.open(DIRECTORY / 'lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if args.restore:
            result = restore()
            print(json.dumps(result))
            return 0 if result['restoration_complete'] else 1
        config = trusted_json(CONFIG)
        def stop(number, frame):
            raise InterruptedError('Bounded service stopped')
        for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(number, stop)
        run(config)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
