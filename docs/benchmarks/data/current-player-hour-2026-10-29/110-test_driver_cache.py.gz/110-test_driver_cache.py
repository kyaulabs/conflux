"""Exercise the real cache-copy/setup statements with a child lookup fixture; no GPU."""
from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,sys,tempfile,unittest
from unittest.mock import patch
BASE=Path(__file__).resolve().parent
OLD=BASE.parent.parent/'m2-short-power-cap-player-02/run_laptop_pair.py'

def setup_code(path):
 tree=ast.parse(path.read_text());matches=[]
 for node in ast.walk(tree):
  body=getattr(node,'body',None)
  if not isinstance(body,list):continue
  for i,item in enumerate(body):
   if isinstance(item,ast.Assign) and isinstance(item.value,ast.BinOp) and isinstance(item.value.right,ast.Constant) and item.value.right.value=='driver-cache':matches.append(body[i:i+3])
 assert len(matches)==1 and len(matches[0])==3
 return compile(ast.fix_missing_locations(ast.Module(body=matches[0],type_ignores=[])),str(path),'exec')

CHILD="""from pathlib import Path
import json,os
p=Path(os.environ['MESA_SHADER_CACHE_DIR'])/'mesa_shader_cache'
print(json.dumps({'marker':(p/'marker').read_text(),'shader':(p/'ab'/'fixture').read_text(),'maximum':os.environ['MESA_SHADER_CACHE_MAX_SIZE']}))
"""

class DriverCacheTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=BASE);self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.seed=self.root/'seed';cache=self.seed/'mesa_shader_cache';(cache/'ab').mkdir(parents=True);(cache/'marker').write_text('offline marker');(cache/'ab/fixture').write_text('offline shader fixture')
  self.original={str(p.relative_to(self.seed)):hashlib.sha256(p.read_bytes()).hexdigest() for p in self.seed.rglob('*') if p.is_file()}
 def invoke(self,path,name):
  case=self.root/name;case.mkdir()
  exec(setup_code(path),{'case':case,'plan':{'cache_seed':str(self.seed)},'shutil':shutil,'os':os})
  return case,subprocess.run([sys.executable,'-I','-B','-c',CHILD],capture_output=True,text=True,timeout=5)
 def test_previous_setup_misses_seed_but_corrected_setup_reaches_it_in_child(self):
  with patch.dict(os.environ,{},clear=False):
   _,previous=self.invoke(OLD,'old');self.assertNotEqual(previous.returncode,0);self.assertIn('FileNotFoundError',previous.stderr)
   case,current=self.invoke(BASE/'run_laptop_pair.py','corrected');self.assertEqual(current.returncode,0,current.stderr)
   self.assertEqual(json.loads(current.stdout),{'marker':'offline marker','shader':'offline shader fixture','maximum':'128M'})
   self.assertEqual(Path(os.environ['MESA_SHADER_CACHE_DIR']),case/'driver-cache')
 def test_run_copies_are_independent_and_original_seed_stays_unchanged(self):
  with patch.dict(os.environ,{},clear=False):
   first,a=self.invoke(BASE/'run_laptop_pair.py','first');second,b=self.invoke(BASE/'run_laptop_pair.py','second');self.assertEqual((a.returncode,b.returncode),(0,0))
   (first/'driver-cache/mesa_shader_cache/ab/fixture').write_text('changed private copy')
   self.assertEqual((second/'driver-cache/mesa_shader_cache/ab/fixture').read_text(),'offline shader fixture')
  self.assertEqual(self.original,{str(p.relative_to(self.seed)):hashlib.sha256(p.read_bytes()).hexdigest() for p in self.seed.rglob('*') if p.is_file()})
 def test_existing_destination_is_not_overwritten_or_selected(self):
  case=self.root/'collision';(case/'driver-cache').mkdir(parents=True);sentinel=case/'driver-cache/keep';sentinel.write_text('keep')
  with patch.dict(os.environ,{'MESA_SHADER_CACHE_DIR':'previous-fixture'},clear=False):
   with self.assertRaises(FileExistsError):exec(setup_code(BASE/'run_laptop_pair.py'),{'case':case,'plan':{'cache_seed':str(self.seed)},'shutil':shutil,'os':os})
   self.assertEqual(os.environ['MESA_SHADER_CACHE_DIR'],'previous-fixture')
  self.assertEqual(sentinel.read_text(),'keep')

if __name__=='__main__':unittest.main(verbosity=2)
