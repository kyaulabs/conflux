"""Fake sysfs and process failures only; never install or change a host limit."""
import contextlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch, Mock

BASE = Path(__file__).resolve().parent


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, BASE / file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


policy = load('burst_policy_test', 'burst_cap.py')
installer = load('burst_installer_test', 'install_cap.py')
client = load('burst_client_test', 'cap_client.py')


class CapTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(dir=BASE)
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.domain = self.root / 'mmio'
        self.msr = self.root / 'msr'
        for domain in (self.domain, self.msr):
            domain.mkdir()
            for name, value in dict(name='package-0', enabled='1', constraint_0_name='long_term',
                constraint_1_name='short_term', constraint_0_power_limit_uw=15000000 if domain == self.domain else 64000000,
                constraint_1_power_limit_uw=64000000, constraint_0_time_window_us=27983872, constraint_1_time_window_us=2440).items():
                (domain / name).write_text(str(value) + '\n')
        self.cap = self.domain / 'constraint_1_power_limit_uw'
        self.state = self.root / 'state.json'
        self.stop = self.root / 'stop'
        self.config = dict(deadline_monotonic=time.monotonic() + 1000,
            boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip())
        stack = contextlib.ExitStack()
        self.addCleanup(stack.close)
        for name, value in dict(DIRECTORY=self.root, CAP=self.cap, MSR=self.msr, STATE=self.state, STOP=self.stop).items():
            stack.enter_context(patch.object(policy, name, value))
        stack.enter_context(patch.object(policy, 'validate_host', side_effect=lambda config: (policy.check_deadline(config), policy.constraints())[1]))
        stack.enter_context(patch.object(policy, 'trusted_json', side_effect=lambda path: json.loads(path.read_text())))
        self.other = {path: path.read_bytes() for domain in (self.domain, self.msr) for path in domain.iterdir() if path != self.cap}

    def assert_other_unchanged(self):
        self.assertEqual({path: path.read_bytes() for path in self.other}, self.other)

    def test_only_short_term_changes_then_restores_once(self):
        record = policy.apply(self.config)
        self.assertEqual(policy.number(self.cap), 15000000)
        self.assert_other_unchanged()
        result = policy.restore()
        self.assertEqual(result['restoration'], 'owned_unchanged_write_restored')
        self.assertEqual(policy.number(self.cap), 64000000)
        with patch.object(policy, 'write_cap') as write:
            self.assertEqual(policy.restore(), result)
            write.assert_not_called()
        self.assertTrue(record['write_returned'])
        self.assert_other_unchanged()

    def test_second_apply_cannot_overwrite_a_saved_initial_value(self):
        policy.apply(self.config)
        before = self.state.read_bytes()
        with self.assertRaises(FileExistsError):
            policy.apply(self.config)
        self.assertEqual(self.state.read_bytes(), before)

    def test_external_lower_value_is_never_raised(self):
        policy.apply(self.config)
        self.cap.write_text('7500000\n')
        result = policy.restore()
        self.assertEqual(policy.number(self.cap), 7500000)
        self.assertEqual(result['restoration'], 'external_value_left_unchanged')

    def test_external_different_higher_value_is_not_overwritten(self):
        policy.apply(self.config)
        self.cap.write_text('20000000\n')
        with patch.object(policy, 'write_cap') as write:
            self.assertTrue(policy.restore()['restoration_complete'])
            write.assert_not_called()

    def test_observed_lower_value_is_preserved_if_firmware_returns_to_our_value(self):
        record = policy.apply(self.config)
        self.cap.write_text('7500000\n')
        with self.assertRaises(ValueError):
            policy.observe(record)
        self.cap.write_text('15000000\n')
        result = policy.restore()
        self.assertEqual(policy.number(self.cap), 7500000)
        self.assertEqual(result['restoration'], 'observed_external_limit_preserved')

    def test_long_term_reduction_by_guard_is_not_counteracted(self):
        record = policy.apply(self.config)
        path = self.domain / 'constraint_0_power_limit_uw'
        path.write_text('7500000\n')
        with patch.object(policy, 'digest', side_effect=[policy.GUARD_SHA, policy.GUARD_UNIT_SHA]):
            policy.observe(record)
        policy.restore()
        self.assertEqual(policy.number(path), 7500000)

    def test_time_window_change_invalidates_run_without_overwriting_it(self):
        record = policy.apply(self.config)
        path = self.domain / 'constraint_1_time_window_us'
        path.write_text('3000\n')
        with self.assertRaises(ValueError):
            policy.observe(record)
        policy.restore()
        self.assertEqual(policy.number(path), 3000)

    def test_constraint_identity_failure_prevents_any_write(self):
        (self.domain / 'constraint_1_name').write_text('wrong\n')
        with patch.object(policy, 'write_cap') as write, self.assertRaises(ValueError):
            policy.apply(self.config)
        write.assert_not_called()

    def test_disabled_domain_prevents_any_write(self):
        (self.msr / 'enabled').write_text('0\n')
        with patch.object(policy, 'write_cap') as write, self.assertRaises(ValueError):
            policy.apply(self.config)
        write.assert_not_called()

    def test_expired_or_unbounded_deadline_prevents_any_write(self):
        for deadline in (time.monotonic() - 1, time.monotonic() + 4381, float('nan'), float('inf')):
            with self.subTest(deadline=deadline), patch.object(policy, 'write_cap') as write, self.assertRaises(TimeoutError):
                policy.apply(dict(self.config, deadline_monotonic=deadline))
            write.assert_not_called()

    def test_longer_lease_keeps_the_original_finite_upper_bound(self):
        with patch.object(policy.time,'monotonic',return_value=100):
            policy.check_deadline(dict(self.config,deadline_monotonic=4480))
            with self.assertRaises(TimeoutError):
                policy.check_deadline(dict(self.config,deadline_monotonic=4480.001))

    def test_different_boot_prevents_apply_and_restore(self):
        with patch.object(policy, 'write_cap') as write, self.assertRaises(ValueError):
            policy.apply(dict(self.config, boot_id='another-boot'))
        write.assert_not_called()
        policy.apply(self.config)
        record = json.loads(self.state.read_text())
        record['boot_id'] = 'another-boot'
        policy.save(self.state, record)
        with patch.object(policy, 'write_cap') as write, self.assertRaises(ValueError):
            policy.restore()
        write.assert_not_called()

    def test_stop_flag_blocks_even_a_late_admin_response(self):
        self.stop.touch()
        with patch.object(policy, 'write_cap') as write, self.assertRaises(InterruptedError):
            policy.apply(self.config)
        write.assert_not_called()

    def test_ambiguous_write_is_kept_lower_and_never_claimed_restored(self):
        real_write = policy.write_cap
        def crash(value):
            real_write(value)
            raise OSError('transport lost after sysfs accepted write')
        with patch.object(policy, 'write_cap', side_effect=crash), self.assertRaises(OSError):
            policy.apply(self.config)
        with patch.object(policy, 'write_cap') as write:
            result = policy.restore()
        write.assert_not_called()
        self.assertFalse(result['restoration_complete'])
        self.assertEqual(policy.number(self.cap), 15000000)

    def test_confirmed_write_readback_failure_still_has_restorable_receipt(self):
        real_number = policy.number
        reads = 0
        def read(path):
            nonlocal reads
            if path == self.cap:
                reads += 1
                if reads == 3:
                    raise OSError('readback failure')
            return real_number(path)
        with patch.object(policy, 'number', side_effect=read), self.assertRaises(OSError):
            policy.apply(self.config)
        self.assertTrue(policy.restore()['restoration_complete'])
        self.assertEqual(policy.number(self.cap), 64000000)

    def test_restoration_failure_does_not_claim_cleanup_then_backup_can_retry(self):
        policy.apply(self.config)
        with patch.object(policy, 'write_cap', side_effect=OSError('restore denied')), self.assertRaises(OSError):
            policy.restore()
        self.assertFalse(json.loads(self.state.read_text())['restoration_complete'])
        self.assertTrue(policy.restore()['restoration_complete'])

    def test_stop_during_owned_loop_restores_in_finally(self):
        def sleep(seconds):
            self.stop.touch()
        with patch.object(policy, 'observe'), patch.object(policy.time, 'sleep', side_effect=sleep):
            policy.run(self.config)
        self.assertEqual(policy.number(self.cap), 64000000)
        self.assertTrue(json.loads(self.state.read_text())['restoration_complete'])

    def test_signal_or_observer_failure_restores_in_finally(self):
        for error in (InterruptedError('SIGTERM'), OSError('observer failed')):
            if self.state.exists():
                self.state.unlink()
            with patch.object(policy, 'observe', side_effect=error), self.assertRaises(type(error)):
                policy.run(self.config)
            self.assertEqual(policy.number(self.cap), 64000000)

    def test_default_policy_and_installer_do_not_query_host_or_write(self):
        for module in (policy, installer):
            with patch.object(sys, 'argv', ['offline-fixture']), patch.object(Path, 'read_text', side_effect=AssertionError('host query')), \
                patch('subprocess.run') as run, patch('subprocess.check_output') as query, patch('builtins.print'):
                self.assertEqual(module.main(), 0)
            run.assert_not_called()
            query.assert_not_called()

    def test_root_receipt_rejects_user_writable_or_symlink_state(self):
        self.state.write_text('{}')
        self.state.chmod(0o666)
        with self.assertRaises(PermissionError):
            # Use the original implementation, bypassing this fixture's reader.
            load('burst_real_receipt', 'burst_cap.py').trusted_json(self.state)
        other = self.root / 'symlink'
        other.symlink_to(self.state)
        with self.assertRaises(PermissionError):
            load('burst_real_symlink', 'burst_cap.py').trusted_json(other)

    def test_installer_has_bounded_owner_immutable_poststop_restore_and_one_writable_sysfs_field(self):
        command = installer.command(1100, 100)
        self.assertIn('--property=Restart=no', command)
        self.assertIn('--property=RuntimeMaxSec=1000s', command)
        self.assertTrue(any(part.startswith('--property=ExecStopPost=') and part.endswith(' --restore') for part in command))
        fields = [part for part in command if part.startswith('--property=ReadWritePaths=')]
        self.assertEqual(fields, ['--property=ReadWritePaths=' + str(installer.DIRECTORY) + ' ' + str(installer.SOURCE_CAP)])
        self.assertNotIn('performance', ' '.join(command))
        with self.assertRaises(TimeoutError):
            installer.command(4481, 100)

    def test_installer_receipts_remain_readable_under_the_actual_user_unit_umask(self):
        directory = self.root / 'fake-root-lease'
        state = directory / 'state.json'
        source = self.root / 'offline-payload.py'
        source.write_text('from pathlib import Path\nimport json\nSTATE=Path(' + repr(str(state)) + ')\n'
            'def validate_host(config):pass\ndef check_deadline(config):pass\n'
            'def trusted_json(path):return json.loads(path.read_text())\ndef number(path):return 15000000\n')
        def dispatched(*args, **kwargs):
            state.write_text(json.dumps(dict(phase='applied')))
            return subprocess.CompletedProcess(args[0], 0)
        services = [dict(LoadState='not-found'), dict(ActiveState='active', MainPID='123',
            ExecStart='{ path=' + installer.PYTHON + ' ; argv[]=' + installer.PYTHON + ' -I -B ' + str(directory/'policy.py') + ' --run ; ignore_errors=no ; }')]
        previous = os.umask(0o077)
        try:
            with patch.object(installer, 'DIRECTORY', directory), patch.object(installer, 'SOURCE', source), \
                patch.object(installer, 'EXPECTED_SHA256', policy.digest(source)), patch.object(installer.os, 'geteuid', return_value=0), \
                patch.object(installer, 'show', side_effect=services), patch.object(installer, 'command', return_value=['offline-only']), \
                patch.object(installer.subprocess, 'run', side_effect=dispatched), patch('builtins.print'), \
                patch.object(sys, 'argv', ['fixture', '--install', '--deadline', str(time.monotonic()+1000), '--boot-id', 'offline']):
                self.assertEqual(installer.main(), 0)
        finally:
            os.umask(previous)
        self.assertEqual(directory.stat().st_mode & 0o777, 0o755)
        for name in ('policy.py', 'config.json'):
            self.assertEqual((directory/name).stat().st_mode & 0o777, 0o444)

    def test_foreign_same_name_system_unit_is_never_treated_as_our_owner(self):
        for command in ('/usr/bin/sleep 120', '/usr/bin/python3.14 /foreign/policy.py --run',
            '/usr/bin/echo /usr/bin/python3.14 -I -B ' + str(installer.DIRECTORY/'policy.py') + ' --run'):
            self.assertFalse(installer.is_ours(dict(ExecStart=command)))

    def test_client_missing_intent_cleanup_does_not_query_host(self):
        with patch.object(client, 'INTENT', self.root / 'missing'), patch.object(client, 'show') as show, patch.object(client, 'root_state') as state:
            self.assertTrue(client.release()['not_requested'])
        show.assert_not_called()
        state.assert_not_called()

    def test_client_requires_fresh_acknowledgement_before_privileged_install(self):
        with patch.object(client.subprocess, 'run') as run, self.assertRaises(PermissionError):
            client.start({}, {})
        run.assert_not_called()

    def test_client_cleanup_blocks_late_install_without_an_admin_prompt(self):
        intent = self.root / 'intent.json'
        intent.write_text(json.dumps(dict(original_operator_deadline_monotonic=time.monotonic() + 1200)))
        with patch.object(client, 'BASE', self.root), patch.object(client, 'INTENT', intent), patch.object(client, 'STOP', self.stop), \
            patch.object(client, 'ROOT_DIRECTORY', self.root / 'missing-root'), patch.object(client, 'STATE', self.root / 'missing-state'), \
            patch.object(client, 'show', return_value=dict(LoadState='not-found', MainPID='0')):
            self.assertTrue(client.release()['late_apply_blocked'])
        self.assertTrue(self.stop.exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
