"""Offline lifecycle checks; all processes, Docker and GPU observations are mocked."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import subprocess
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('apollo_pair_offline',Path(__file__).with_name('run_apollo_pair.py'))
owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)

class ApolloPairTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name);self.ops=self.base/'operations';self.ops.mkdir()
        seed=self.base/'seed';seed.mkdir();(seed/'one').write_text('seed')
        runtimes={a:dict(path='/'+a+'/conflux-stem-runtime',bytes=1,sha256=str(i)*64) for i,a in enumerate(owner.ARMS)}
        proof=dict(correctness_complete_both_hosts=True,timing_qualification=False,
            hosts={'apollo':{'arms':{'baseline':dict(requests=16,exact_outputs=16)}}},
            runtime_identities={'apollo':dict(baseline=runtimes['candidate'],model=dict(sha256='m'*64))})
        self.write(self.base/'exact-outputs.json',proof)
        self.write(self.base/'source-ci.json',dict(merge='6e1623ff0261d3cc5200380cd8f1b15260bc57f4',all_nine_CI_jobs_passed=True,merge_tree_matches_source=True))
        self.write(self.ops/'binding.json',dict(source_ci=str(self.base/'source-ci.json'),schema=1,state='frozen_pending_fresh_readiness',source_head='6e1623ff0261d3cc5200380cd8f1b15260bc57f4',
            files=[],source_root=str(self.base/'source'),native_root=str(self.base/'native'),driver_cache_seed=str(seed),inputs_root=str(self.base/'inputs'),runtimes=runtimes,
            exact_outputs=str(self.base/'exact-outputs.json'),model=dict(sha256='m'*64)))
        self.write(self.base/'pair-readiness-01.json',dict(schema=1,source_head='6e1623ff0261d3cc5200380cd8f1b15260bc57f4',
            original_readiness_utc=(datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(seconds=1)).isoformat(),
            operator_seconds=4380,host_tests_concurrent=True,retries=False,apollo_deadline_monotonic=4479.,
            binding_sha256=hashlib.sha256((self.ops/'binding.json').read_bytes()).hexdigest(),
            human_reply='Offline generated fixture',question_item_id='offline-fixture',physical_conditions_confirmed=True,hour_duration_approved=True))
        self.clock=100.;self.containers=set();self.commands=[];self.removed=[];self.host_queries=[]
        self.complete=True;self.timeout=False;self.wrong_label=False;self.late=False
    def write(self,path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value))
    def check_output(self,cmd,**kwargs):
        self.host_queries.append(cmd)
        return '"/srv/conflux-tests/docker-data"' if 'info' in cmd else ''
    def mock_run(self,cmd,**kwargs):
        if 'inspect' in cmd:
            name=cmd[-1]
            if name in self.containers:
                value=[dict(Id=name,Image=owner.IMAGE,Config=dict(Labels={'org.kyaulabs.conflux.run':'unrelated' if self.wrong_label else owner.RUN}))]
                return subprocess.CompletedProcess(cmd,0,json.dumps(value),'')
            return subprocess.CompletedProcess(cmd,1,'','absent')
        if 'rm' in cmd:
            self.removed.append(cmd[-1]);self.containers.remove(cmd[-1]);return subprocess.CompletedProcess(cmd,0,'','')
        self.fail(str(cmd))
    def popen(self,cmd,**kwargs):
        self.commands.append(cmd)
        test=self
        if 'run' in cmd:
            name=cmd[cmd.index('--name')+1];self.containers.add(name)
            arm=next(x.split('=',1)[1] for x in cmd if x.startswith('CONFLUX_STAGING_ARM='))
            self.assertIn('CONFLUX_EXPECTED_RUNTIME_SHA256='+('0'*64),cmd)
            self.assertIn('type=bind,src=/'+arm+',dst=/runtime,readonly',cmd)
            for name,dest in [('source','/work/source'),('native','/player')]:self.assertIn('type=bind,src='+str(self.base/name)+',dst='+dest+',readonly',cmd)
            case=self.base/'cases'/arm
            self.write(case/'private-player-01/result.json',dict(passed=True,daemon_reaped=True,cleanup=dict(only_dummy_driver_remains=True)))
            self.write(case/'private-player-01/recordings/actual-player/assessment.json',dict(measurement_complete=self.complete,sink_reaped=True,passed=True,service_target_met=True))
            class Child:
                waited=False
                def wait(self,timeout):
                    if test.timeout and not self.waited:self.waited=True;raise subprocess.TimeoutExpired(cmd,timeout)
                    test.clock+=1000 if test.late else 150
                    return 0
                def kill(self):pass
            return Child()
        class Monitor:
            def terminate(self):pass
            def kill(self):pass
            def wait(self,timeout):return 0
        return Monitor()
    def invoke(self):
        with patch.object(owner,'BASE',self.base),patch.object(owner,'OPS',self.ops), \
             patch.object(owner.time,'monotonic',side_effect=lambda:self.clock), \
             patch.object(owner.signal,'signal'),patch.object(owner.subprocess,'check_output',side_effect=self.check_output), \
             patch.object(owner.subprocess,'run',side_effect=self.mock_run),patch.object(owner.subprocess,'Popen',side_effect=self.popen), \
             patch('sys.argv',['pair','--run']),patch('builtins.print'):
            with self.assertRaises(SystemExit) as exit:owner.main()
        return exit.exception.code,json.loads((self.base/'pair-result-01.json').read_text())
    def test_only_candidate_and_cleanup_without_checkins(self):
        code,result=self.invoke();self.assertEqual(code,0)
        self.assertTrue(result['pair_complete'] and result['cleanup_complete'])
        self.assertEqual(list(result['arms']),['candidate'])
        self.assertEqual(self.removed,['conflux-'+owner.RUN+'-'+a for a in owner.ARMS])
    def test_incomplete_first_arm_prevents_second_and_retains_result(self):
        self.complete=False;code,result=self.invoke()
        self.assertEqual(code,1);self.assertFalse(result['pair_complete']);self.assertTrue(result['cleanup_complete'])
        self.assertEqual(list(result['arms']),['candidate']);self.assertFalse(result['arms']['candidate']['measurement_complete'])
    def test_timeout_forces_only_the_owned_container_and_reaps(self):
        self.timeout=True;code,result=self.invoke();self.assertEqual(code,1)
        self.assertEqual(self.removed,['conflux-'+owner.RUN+'-candidate']);self.assertEqual(self.containers,set())
        self.assertFalse(result['pair_complete']);self.assertIn('TimeoutExpired',str(result['errors']))
    def test_unrelated_container_identity_is_never_removed(self):
        self.wrong_label=True;code,result=self.invoke();self.assertEqual(code,1)
        self.assertFalse(result['cleanup_complete']);self.assertEqual(self.removed,[])
    def test_expired_original_clock_prevents_any_launch(self):
        self.clock=4480.
        with self.assertRaises(AssertionError):self.invoke()
        self.assertEqual(self.commands,[])
        self.assertEqual(self.host_queries,[])
    def test_source_ci_clearance_required_before_host_queries(self):
        self.write(self.base/'source-ci.json',dict(merge='6e1623ff0261d3cc5200380cd8f1b15260bc57f4',all_nine_CI_jobs_passed=False,merge_tree_matches_source=True))
        with self.assertRaises(AssertionError):self.invoke()
        self.assertEqual(self.commands,[])
        self.assertEqual(self.host_queries,[])
    def test_changed_binding_or_failed_exact_outputs_prevents_any_container(self):
        human=json.loads((self.base/'pair-readiness-01.json').read_text());human['binding_sha256']='wrong'
        self.write(self.base/'pair-readiness-01.json',human)
        with self.assertRaises(AssertionError):self.invoke()
        self.assertEqual(self.commands,[])
        proof=json.loads((self.base/'exact-outputs.json').read_text());proof['hosts']['apollo']['arms']['baseline']['exact_outputs']=15
        self.write(self.base/'exact-outputs.json',proof)
        with self.assertRaises(AssertionError):self.invoke()
        self.assertEqual(self.commands,[])

    def test_missing_readiness_prevents_any_host_or_container_query(self):
        (self.base/'pair-readiness-01.json').unlink()
        with self.assertRaises(FileNotFoundError):self.invoke()
        self.assertEqual(self.commands,[])
        self.assertEqual(self.host_queries,[])

    def test_short_readiness_cannot_start_the_hour_or_query_the_gpu(self):
        human=json.loads((self.base/'pair-readiness-01.json').read_text())
        del human['hour_duration_approved']
        self.write(self.base/'pair-readiness-01.json',human)
        with self.assertRaisesRegex(AssertionError,'full hour'):self.invoke()
        self.assertEqual(self.host_queries,[])
        self.assertEqual(self.commands,[])

if __name__=='__main__':unittest.main()
