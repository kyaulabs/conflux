from pathlib import Path
import json,subprocess,base64,hashlib
P=Path(__file__).resolve().parent
names=['compare_pcm.py', 'worker.py', 'native_exit.py', 'test_native_exit.py', 'cache_control.py', 'native_fixture.py', 'test_cache_compare.py', 'entry_check.py', 'inputs-manifest.json', 'apollo-plan.json', 'apollo_owner.py']
files={'packet/'+n:base64.b64encode((P/n).read_bytes()).decode()for n in names}
files['pair.py']=base64.b64encode((P/'apollo_pair.py').read_bytes()).decode();files['config.json']=base64.b64encode((P/'apollo-config.json').read_bytes()).decode()
s='FILES='+repr(files)+'\n'+r"""
from pathlib import Path
import subprocess,json,os,hashlib,base64
r=Path('/srv/conflux-tests/work/current-driver-cache-20261106-01');assert not r.exists();r.mkdir(mode=0o700);os.chown(r,1000,1000)
for name,data in FILES.items():
 p=r/name;p.parent.mkdir(parents=True,exist_ok=True);os.chown(p.parent,1000,1000);p.write_bytes(base64.b64decode(data));os.chown(p,1000,1000);p.chmod(0o600)
for name in ['tmp','cache','data','state','config']:
 p=r/name;p.mkdir(mode=0o700);os.chown(p,1000,1000)
source=Path('/srv/conflux-tests/work/vulkan-submission-sync-20261105-01/conflux-stem-runtime');assert hashlib.sha256(source.read_bytes()).hexdigest()=='ebcc2a0576c9ca07720ad91316aa66e35b88f9f6fd4ee84b640ee9e6277ee43b';os.link(source,r/'conflux-stem-runtime')
a=['sudo','-u','#1000','-g','#1000','env','PYTHONDONTWRITEBYTECODE=1','TMPDIR='+str(r/'tmp'),'XDG_CACHE_HOME='+str(r/'cache'),'XDG_DATA_HOME='+str(r/'data'),'XDG_STATE_HOME='+str(r/'state'),'XDG_CONFIG_HOME='+str(r/'config'),'python3','-B'];steps=[]
for label,cmd in [('root-unarmed',a+[str(r/'pair.py')]),('container-unarmed',a+[str(r/'packet/apollo_owner.py'),'--offline-entry'])]:
 z=subprocess.run(cmd,capture_output=True,text=True,timeout=100);(r/(label+'.stdout.log')).write_text(z.stdout);(r/(label+'.stderr.log')).write_text(z.stderr);steps.append(dict(name=label,exit=z.returncode,stdout=z.stdout,stderr=z.stderr));assert z.returncode==0,steps[-1]
owner=json.loads((r/'packet/offline-entry-results-01/owner-result.json').read_text());assert owner['completed']and owner['cleanup_complete']and not owner['GPU_device_attached']
d=['env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock'];assert not subprocess.check_output(d+['ps','-aq'],text=True,timeout=5).strip()
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
result=dict(unarmed=True,passed=True,hardware_started=False,container_absent=True,steps=steps,files=[pin(r/n)for n in FILES]+[pin(r/'conflux-stem-runtime')],config=pin(r/'config.json'));(r/'stage-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
"""
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','sudo -n python3 -']
with(P/'apollo-stage.stdout.log').open('x')as out,(P/'apollo-stage.stderr.log').open('x')as err:z=subprocess.run(ssh,input=s,text=True,stdout=out,stderr=err,timeout=130)
assert z.returncode==0,z.returncode
result=json.loads((P/'apollo-stage.stdout.log').read_text().splitlines()[-1]);(P/'apollo-stage.json').write_text(json.dumps(result,indent=2)+'\n');print('Apollo unarmed root/container entries passed; no GPU attached.')
