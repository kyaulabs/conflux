"""Read-only identity audit for the captured Mesa v1 multifile cache format.

A matching build is necessary, not sufficient, for an actual GPU cache hit.
No cache data is rewritten, moved or loaded into a driver.
"""
from pathlib import Path
import argparse,collections,hashlib,json,os,re,struct,subprocess

def driver_id(build_id):
    if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',build_id):
        raise ValueError('Expected a 20- or 32-byte GNU build ID')
    return bytes.fromhex(build_id).ljust(32,b'\0').hex()

def header(raw):
    if len(raw)<84 or raw[0]!=1:
        raise ValueError('Unsupported or truncated Mesa cache header')
    end=raw.find(b'\0',1,66)
    if end!=65:raise ValueError('Invalid driver identity header')
    identity=raw[1:end].decode('ascii')
    if not re.fullmatch(r'[0-9a-f]{64}',identity):raise ValueError('Invalid driver identity')
    gpu_end=raw.find(b'\0',66,83)
    if gpu_end<0:raise ValueError('Missing renderer terminator')
    renderer=raw[66:gpu_end].decode('ascii')
    if not re.fullmatch(r'anv_[0-9a-f]{4}',renderer):raise ValueError('Unsupported renderer identity')
    if len(raw)<gpu_end+10:raise ValueError('Truncated pointer/flags header')
    return dict(driver_id=identity,renderer=renderer,pointer_bytes=raw[gpu_end+1],
                compiler_flags=int.from_bytes(raw[gpu_end+2:gpu_end+10],'little'))

def audit(seed,build_id,renderer):
    seed=Path(seed)
    if seed.is_symlink()or not seed.is_dir():raise ValueError('Regular seed directory required')
    entries=[];ignored=[]
    for p in sorted(seed.rglob('*')):
        if p.is_symlink():raise ValueError('Symlink in seed: '+str(p.relative_to(seed)))
        if not p.is_file():continue
        name=str(p.relative_to(seed))
        if name in ['mesa_shader_cache/index','mesa_shader_cache/marker']:
            ignored.append(name);continue
        parts=p.relative_to(seed).parts
        if len(parts)!=3 or parts[0]!='mesa_shader_cache' or not re.fullmatch(r'[0-9a-f]{2}',parts[1])or not re.fullmatch(r'[0-9a-f]{62}',parts[2]):
            raise ValueError('Unrecognized cache member: '+name)
        with p.open('rb')as f:h=header(f.read(256))
        entries.append(dict(path=name,**h,matches_driver_build=h['driver_id']==driver_id(build_id),
                            matches_renderer=h['renderer']==renderer,pointer_matches=h['pointer_bytes']==struct.calcsize('P')))
    count=sum(e['matches_driver_build']and e['matches_renderer']and e['pointer_matches']for e in entries)
    return dict(seed=str(seed),installed_build_id=build_id,expected_driver_id=driver_id(build_id),
                renderer=renderer,entry_count=len(entries),same_build_renderer_pointer_entries=count,
                mismatched_entries=len(entries)-count,usable_as_current_driver_seed=count>0,
                actual_cache_hits_measured=False,warm_cache_proven=False,compiler_flags_validated=False,
                no_GPU_or_model_started=True,ignored=ignored,entries=entries)

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('seed',type=Path)
    ap.add_argument('--library',type=Path,default=Path('/usr/lib/libvulkan_intel.so'));ap.add_argument('--renderer',default='anv_9a49');ap.add_argument('--require-current-driver-seed',action='store_true');args=ap.parse_args()
    notes=subprocess.check_output(['readelf','-n',str(args.library)],text=True,timeout=10)
    matches=re.findall(r'Build ID: ([0-9a-f]+)',notes)
    if len(matches)!=1:raise SystemExit('Expected one GNU driver build ID')
    result=audit(args.seed,matches[0],args.renderer)
    with args.library.open('rb')as f:result['library_sha256']=hashlib.file_digest(f,'sha256').hexdigest()
    print(json.dumps(result,indent=2))
    raise SystemExit(1 if args.require_current_driver_seed and not result['usable_as_current_driver_seed']else 0)
