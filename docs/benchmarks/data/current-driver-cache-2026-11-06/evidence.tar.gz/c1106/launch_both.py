from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import argparse,json,hashlib,subprocess,sys,time
BASE=Path(__file__).resolve().parent
LOCAL='conflux-m2-cache-compare-laptop-20261106-01.service'
REMOTE='conflux-m2-cache-compare-apollo-20261106-01.service'
SSH=['/usr/bin/ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
def pin(path):
 p=Path(path)
 with p.open('rb')as f:d=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=d)
def save(p,v):
 with Path(p).open('x')as f:f.write(json.dumps(v,indent=2)+'\n')
def local_command(unit,live,remaining=1200):
 return ['systemd-run','--user','--unit='+unit,'--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no','--property=RuntimeMaxSec='+str(int(remaining)-60)+'s','--property=TimeoutStopSec=50s','--property=KillMode=control-group','--property=MemoryMax=8G','--property=TasksMax=1024','--property=UMask=0077','--property=WorkingDirectory='+str(BASE),'--property=StandardOutput=append:'+str(BASE/('unit.stdout.log'if live else'offline.stdout.log')),'--property=StandardError=append:'+str(BASE/('unit.stderr.log'if live else'offline.stderr.log')),'--setenv=TMPDIR='+str(BASE/'t'),'--setenv=XDG_CACHE_HOME='+str(BASE/'launcher-cache'),'--setenv=XDG_CONFIG_HOME='+str(BASE/'launcher-config'),'--setenv=XDG_DATA_HOME='+str(BASE/'launcher-data'),'--setenv=XDG_STATE_HOME='+str(BASE/'launcher-state'),'--setenv=PYTHONDONTWRITEBYTECODE=1','/usr/bin/kde-inhibit','--power','/usr/bin/python3.14','-B',str(BASE/'run_laptop.py')]+(['--run']if live else[])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--launch',action='store_true');args=ap.parse_args();frozen=json.loads((BASE/'packet-pins.json').read_text());assert frozen['offline_checks_passed']and frozen['hardware_started']is False
 for row in frozen['local_files']:assert pin(row['path'])==row
 assert not any((BASE/n).exists()for n in ['readiness.json','reservation.json','case','result.json','dispatch.json'])
 if not args.launch:print(json.dumps(dict(verified=True,unarmed=True)));return
 raw=sys.stdin.read(32769);assert len(raw)<=32768;h=json.loads(raw)
 assert h['operator_seconds']==1200 and h['question_item_id']and h['human_reply']and all(h.get(k)is True for k in ['AC_power','lid_open','other_work_paused','Codex_minimized','no_suspend','CONFLUX_closed'])
 age=(datetime.now(timezone.utc)-datetime.fromisoformat(h['reply_utc'])).total_seconds();assert 0<=age<60,'Physical confirmation expired before dispatch'
 state=subprocess.check_output(['systemctl','--user','show',LOCAL,'-p','LoadState','-p','MainPID'],text=True,timeout=5);assert'LoadState=not-found'in state and'MainPID=0'in state
 h['original_readiness_utc']=h.pop('reply_utc');h['config_sha256']=pin(BASE/'laptop-plan.json')['sha256'];save(BASE/'readiness.json',h)
 remote=dict(h,config_sha256=frozen['remote_config']['sha256']);remote_script='H='+repr(remote)+'\nBINDING='+repr(frozen['remote_config'])+'\nFILE_ROWS='+repr(frozen['remote_files'])+'\nUNIT='+repr(REMOTE)+'\n'+r"""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess
for row in FILE_ROWS:
 b=Path(row['path']).read_bytes();assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']
p=Path(BINDING['path']).parent;raw=Path(BINDING['path']).read_bytes();assert len(raw)==BINDING['bytes']and hashlib.sha256(raw).hexdigest()==BINDING['sha256'];assert not any((p/n).exists()for n in ['readiness.json','reservation.json','case','result.json'])
age=(datetime.now(timezone.utc)-datetime.fromisoformat(H['original_readiness_utc'])).total_seconds();assert 0<=age<60
state=subprocess.check_output(['systemctl','show',UNIT,'-p','LoadState','-p','MainPID'],text=True,timeout=5);assert'LoadState=not-found'in state and'MainPID=0'in state
with(p/'readiness.json').open('x')as f:f.write(json.dumps(H,indent=2)+'\n')
command=['sudo','-n','systemd-run','--unit='+UNIT,'--uid=1000','--gid=1000','--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no','--property=RuntimeMaxSec='+str(int(1140-age))+'s','--property=TimeoutStopSec=50s','--property=KillMode=control-group','--property=MemoryMax=8G','--property=TasksMax=1024','--property=UMask=0077','--property=WorkingDirectory='+str(p),'--property=StandardOutput=append:'+str(p/'unit.stdout.log'),'--property=StandardError=append:'+str(p/'unit.stderr.log'),'/usr/bin/python3','-B',str(p/'pair.py'),'--run']
r=subprocess.run(command,text=True,capture_output=True,timeout=15);print(json.dumps(dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)));assert r.returncode==0
"""
 def start(command,data=None):
  r=subprocess.run(command,input=data,text=True,capture_output=True,timeout=30);return dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
 with ThreadPoolExecutor(max_workers=2)as pool:
  laptop=pool.submit(start,local_command(LOCAL,True,1200-age));apollo=pool.submit(start,SSH+['python3 -'],remote_script);result=dict(laptop=laptop.result(),apollo=apollo.result(),original_readiness_utc=h['original_readiness_utc'],both_submitted_concurrently=True,retries=False)
 save(BASE/'dispatch.json',result);print(json.dumps(result))
if __name__=='__main__':main()
