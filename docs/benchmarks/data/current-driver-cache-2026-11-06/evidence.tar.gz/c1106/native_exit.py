"""Bounded teardown capture for the private runtime checker; no model startup."""
import os
import selectors
import time


def wait_native(native, timeout=5):
    """Drain both pipes while waiting; never wait for descendants to close them."""
    if not 0 < timeout <= 5:
        raise ValueError("Teardown timeout must be in (0, 5]")
    limit = native.max_stderr_bytes
    if type(limit) is not int or not 0 < limit <= 65536:
        raise ValueError("Bounded stderr capture required")
    process = native.process
    deadline = time.monotonic() + timeout
    stdout_tail = bytearray()
    blocking = {}
    with selectors.DefaultSelector() as selector:
        for stream in (process.stdout, process.stderr):
            fd = stream.fileno()
            blocking[fd] = os.get_blocking(fd)
            os.set_blocking(fd, False)
            selector.register(stream, selectors.EVENT_READ)
        def drain(wait):
            events = selector.select(wait)
            for key, _ in events:
                try:
                    data = os.read(key.fd, 4096)
                except BlockingIOError:
                    continue
                if not data:
                    selector.unregister(key.fileobj)
                elif key.fileobj is process.stderr:
                    native._stderr_tail.extend(data)
                    del native._stderr_tail[:-limit]
                else:
                    stdout_tail.extend(data)
                    del stdout_tail[:-4096]
            return bool(events)
        try:
            while True:
                code = process.poll()
                if code is not None:
                    # Bounded post-exit drain, even if an inherited writer stays open.
                    for _ in range(32):
                        if not drain(0):
                            break
                    native._flush_diagnostics()
                    return {"returncode": code, "stdout_tail": stdout_tail.decode(errors="replace"),
                            "stderr_retained_bytes": len(native._stderr_tail)}
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    native._flush_diagnostics()
                    raise TimeoutError("Native teardown exceeded its fixed deadline")
                drain(min(.05, remaining))
        finally:
            for fd, was_blocking in blocking.items():
                os.set_blocking(fd, was_blocking)
