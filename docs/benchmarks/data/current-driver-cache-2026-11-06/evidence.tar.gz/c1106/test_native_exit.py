import subprocess,sys,unittest,time,signal,os
from types import SimpleNamespace
from native_exit import wait_native

class NativeExitChecks(unittest.TestCase):
    def start(self,script):
        p=subprocess.Popen([sys.executable,'-B','-c',script],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        self.addCleanup(self.close,p)
        return SimpleNamespace(process=p,max_stderr_bytes=65536,_stderr_tail=bytearray(),_flush_diagnostics=lambda:None)
    @staticmethod
    def close(p):
        if p.poll()is None:p.kill()
        p.wait(timeout=2)
        for stream in (p.stdin,p.stdout,p.stderr):
            if stream:stream.close()
    def test_exit_code_and_final_stderr_retained(self):
        n=self.start("import os,sys;os.write(1,b'final protocol message\\n');os.write(2,b'late teardown error\\n');sys.exit(7)")
        r=wait_native(n);self.assertEqual(r['returncode'],7);self.assertIn(b'late teardown error',n._stderr_tail);self.assertIn('final protocol message',r['stdout_tail'])
    def test_flood_drains_both_pipes_and_keeps_bounded_tail(self):
        n=self.start("import os,sys;os.write(2,b'e'*524288+b'END-ERR');os.write(1,b'o'*131072+b'END-OUT');sys.exit(9)")
        r=wait_native(n);self.assertEqual(r['returncode'],9);self.assertEqual(len(n._stderr_tail),65536);self.assertTrue(n._stderr_tail.endswith(b'END-ERR'));self.assertTrue(r['stdout_tail'].endswith('END-OUT'));self.assertLessEqual(len(r['stdout_tail']),4096)
    def test_continuous_output_cannot_reset_absolute_deadline(self):
        n=self.start("import os\nwhile True:os.write(2,b'f'*4096)")
        t=time.monotonic()
        with self.assertRaises(TimeoutError):wait_native(n,.15)
        self.assertLess(time.monotonic()-t,1);self.assertLessEqual(len(n._stderr_tail),65536)
        n.process.kill();n.process.wait(timeout=2);self.assertEqual(n.process.returncode,-signal.SIGKILL)
    def test_signal_returncode_retained(self):
        n=self.start("import os,signal;os.write(2,b'before termination');os.kill(os.getpid(),signal.SIGTERM)")
        r=wait_native(n);self.assertEqual(r['returncode'],-signal.SIGTERM);self.assertIn(b'before termination',n._stderr_tail)
    def test_open_inherited_writer_does_not_delay_finished_child(self):
        readfd,writefd=os.pipe()
        try:
            p=subprocess.Popen([sys.executable,'-B','-c',"import os;os.write(2,b'final stderr')"],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=writefd)
            p.stderr=os.fdopen(readfd,'rb',buffering=0);readfd=None;self.addCleanup(self.close,p)
            n=SimpleNamespace(process=p,max_stderr_bytes=65536,_stderr_tail=bytearray(),_flush_diagnostics=lambda:None)
            t=time.monotonic();r=wait_native(n,1);self.assertEqual(r['returncode'],0);self.assertLess(time.monotonic()-t,.8);self.assertIn(b'final stderr',n._stderr_tail)
        finally:
            os.close(writefd)
            if readfd is not None:os.close(readfd)
if __name__=='__main__':unittest.main(verbosity=2)
