from pathlib import Path
from datetime import datetime,timezone
import argparse,json,hashlib,subprocess,time,sys,os
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');args=ap.parse_args()
def pin(p):
 with p.open('rb')as f:d=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=d)
plan=P/'laptop-plan.json'
assert not any(os.environ.get(k)for k in ['LD_LIBRARY_PATH','LD_PRELOAD','VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_ADD_DRIVER_FILES']),'Inherited loader override differs from the pinned Intel diagnostic'
assert not any(k.startswith(('GGML_VK_','GGML_VULKAN_','MESA_','INTEL_DEBUG','CONFLUX_DRM_','CONFLUX_REQUEST_TRACE_'))for k in os.environ),'Inherited GPU experiment switches'
if not args.run:
 subprocess.run([sys.executable,'-B',str(P/'compare_pcm.py'),'--plan',str(plan)],check=True,timeout=35)
 native=json.loads(plan.read_text())['pins']['baseline']['path']
 subprocess.run([native,'--help'],check=True,timeout=10)
 print(json.dumps(dict(verified=True,hardware_started=False)));raise SystemExit(0)
h=json.loads((P/'readiness.json').read_text());age=(datetime.now(timezone.utc)-datetime.fromisoformat(h['original_readiness_utc'])).total_seconds()
assert 0<=age<90 and h['operator_seconds']==1200 and h['question_item_id']and h['human_reply']
assert h['config_sha256']==pin(plan)['sha256'],'Readiness plan binding differs'
assert all(h.get(k)is True for k in ['AC_power','lid_open','other_work_paused','Codex_minimized','no_suspend','CONFLUX_closed'])
assert not(P/'reservation.json').exists()and not(P/'output-01').exists()
with(P/'reservation.json').open('x')as f:f.write(json.dumps(dict(original_readiness_utc=h['original_readiness_utc'],retries=False))+'\n')
h.update(schema=1,mode='m2-current-driver-cache-20261106-01',plan_sha256=pin(plan)['sha256'],deadline_monotonic=time.monotonic()+1200-age,physical_conditions_confirmed=True)
with(P/'native-readiness.json').open('x')as f:f.write(json.dumps(h,indent=2)+'\n')
z=subprocess.run([sys.executable,'-B',str(P/'compare_pcm.py'),'--plan',str(plan),'--run'],timeout=930)
raise SystemExit(z.returncode)
