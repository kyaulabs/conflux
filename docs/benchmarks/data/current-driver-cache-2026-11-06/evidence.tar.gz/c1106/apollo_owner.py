"""Private-daemon owner for the silent Apollo comparison; dry by default."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

BASE = Path('/srv/conflux-tests/work/current-driver-cache-20261106-01')
INPUTS = Path('/srv/conflux-tests/work/m2-shared-staging-20261028-01')
OPS = BASE / 'packet'
MODEL = Path('/srv/conflux-tests/work/htdemucs-f16.gguf')
DOCKER = ['sudo', '-n', 'env', 'DOCKER_CONFIG=/srv/conflux-tests/docker-client', 'docker',
          '--host', 'unix:///srv/conflux-tests/daemon/docker.sock']
IMAGE = 'sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
NAME = 'conflux-m2-current-driver-cache-20261106-01'
GPU = 'nvidia.com/gpu=GPU-c58fa4ef-cda8-be9f-eb37-caeb7cf7d42b'


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def digest(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    with path.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()


def actual_path(path):
    p = Path(path)
    assert p.is_absolute() and '..' not in p.parts, str(p)
    if p.is_relative_to('/probe'):
        return BASE / p.relative_to('/probe')
    if p.is_relative_to('/inputs'):
        return INPUTS / p.relative_to('/inputs')
    assert p == Path('/model/htdemucs-f16.gguf'), str(p)
    return MODEL


def verify():
    plan = json.loads((OPS / 'apollo-plan.json').read_text())
    assert plan['host'] == 'apollo' and plan['mode'] == 'm2-current-driver-cache-20261106-01'
    for row in plan['pins'].values():
        p = actual_path(row['path'])
        assert p.stat().st_size == row['bytes'] and digest(p) == row['sha256'], str(p)
    manifest = json.loads(actual_path(plan['pins']['inputs_manifest']['path']).read_text())
    for case in manifest['cases']:
        p = actual_path(plan['input_root']) / case['file']
        assert p.stat().st_size == case['bytes'] and digest(p) == case['sha256'], str(p)
    assert json.loads(subprocess.check_output(DOCKER + ['info', '--format', '{{json .DockerRootDir}}'], timeout=5)) == '/srv/conflux-tests/docker-data'
    return plan


def container_command(results, *, live):
    command = DOCKER + ['run', '--rm', '--name', NAME if live else NAME + '-offline-entry', '--init', '--runtime=runc',
        '--label', 'org.kyaulabs.conflux.tests=1', '--label', 'org.kyaulabs.conflux.run=' + NAME,
        '--network=none', '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges:true',
        '--user', '1000:1000', '--pids-limit=256', '--memory=8g',
        '--tmpfs=/tmp:rw,nosuid,nodev,size=256m,mode=1777',
        '--env', 'TMPDIR=/tmp', '--env', 'XDG_CACHE_HOME=/results/cache',
        '--env', 'XDG_DATA_HOME=/results/data', '--env', 'XDG_STATE_HOME=/results/state',
        '--env', 'XDG_CONFIG_HOME=/results/config', '--env', '__GL_SHADER_DISK_CACHE_PATH=/results/driver-cache']
    if live: command += ['--device', GPU]
    for source, target, readonly in [(BASE, '/probe', True), (INPUTS, '/inputs', True), (MODEL, '/model/htdemucs-f16.gguf', True), (results, '/results', False)]:
        command += ['--mount', 'type=bind,src=' + str(source) + ',dst=' + target + (',readonly' if readonly else '')]
    command += [IMAGE, 'timeout', '--signal=TERM', '--kill-after=5s', '915' if live else '60', 'python3', '-B']
    if live:
        command += ['/probe/packet/compare_pcm.py', '--plan', '/probe/packet/apollo-plan.json', '--run']
    else:
        command += ['/probe/packet/entry_check.py']
    return command


def remove_owned(name):
    found = subprocess.run(DOCKER + ['inspect', name], capture_output=True, text=True, timeout=5)
    if found.returncode == 0:
        value = json.loads(found.stdout)[0]
        assert value['Image'] == IMAGE and value['Config']['Labels'].get('org.kyaulabs.conflux.run') == NAME
        subprocess.run(DOCKER + ['rm', '--force', value['Id']], check=True, capture_output=True, timeout=15)
    assert subprocess.run(DOCKER + ['inspect', name], capture_output=True, timeout=5).returncode != 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--offline-entry', action='store_true')
    args = parser.parse_args()
    assert not (args.run and args.offline_entry)
    if not args.run and not args.offline_entry:
        verify(); print(json.dumps(dict(verified=True, GPU_started=False))); return 0
    if args.run:
        human = json.loads((OPS / 'readiness.json').read_text())
        age = (datetime.now(timezone.utc) - datetime.fromisoformat(human['original_readiness_utc'])).total_seconds()
        assert human['physical_conditions_confirmed'] is True and human['operator_seconds'] == 1200 and 0 <= age <= 90
        assert human['plan_sha256'] == digest(OPS / 'apollo-plan.json')
        assert 1000 <= human['deadline_monotonic'] - time.monotonic() <= 1200 - age + 2
    verify()
    name = NAME if args.run else NAME + '-offline-entry'
    assert subprocess.run(DOCKER + ['inspect', name], capture_output=True, timeout=5).returncode != 0
    # Only this dedicated daemon is inspected. Protected application resources are never queried or changed.
    assert subprocess.check_output(DOCKER + ['ps', '-aq'], text=True, timeout=5).strip() == ''
    results = OPS / ('container-results-01' if args.run else 'offline-entry-results-02')
    results.mkdir(mode=0o700)
    report = dict(schema=1, live=args.run, GPU_device_attached=args.run, completed=False, cleanup_complete=False, errors=[])
    process = None
    def interrupted(number, frame): raise InterruptedError('Owned container signal ' + str(number))
    for number in (signal.SIGTERM, signal.SIGINT): signal.signal(number, interrupted)
    try:
        command = container_command(results, live=args.run)
        report['command'] = command
        save(results / 'owner-dispatch.json', report)
        with (results / 'container.log').open('x') as log:
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
            report['exit'] = process.wait(timeout=930 if args.run else 75)
        if args.run:
            inner = json.loads((results / 'output-01/result.json').read_text())
            report['completed'] = report['exit'] == 0 and inner['completed'] and inner['cleanup_complete']
        else:
            report['completed'] = report['exit'] == 0
    except BaseException as error:
        report['errors'].append(dict(type=type(error).__name__, error=str(error)))
    finally:
        for number in (signal.SIGTERM, signal.SIGINT): signal.signal(number, signal.SIG_IGN)
        try:
            remove_owned(name)
            if process is not None:
                try: process.wait(timeout=5)
                except subprocess.TimeoutExpired: process.kill(); process.wait(timeout=5)
            report['cleanup_complete'] = True
        except BaseException as error:
            report['errors'].append(dict(phase='cleanup', error=str(error)))
        report['completed'] = report['completed'] and report['cleanup_complete'] and not report['errors']
        save(results / 'owner-result.json', report)
    print(json.dumps({k:report[k] for k in ('completed','cleanup_complete','errors')}))
    return 0 if report['completed'] else 1


if __name__ == '__main__': raise SystemExit(main())
