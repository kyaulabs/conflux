from pathlib import Path
import importlib.util,tempfile,unittest,sys,subprocess,hashlib,json,os
R=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('cache_control',R/'cache_control.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
s=importlib.util.spec_from_file_location('cache_driver',R/'compare_pcm.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
s=importlib.util.spec_from_file_location('prior_native_fixture',R/'native_fixture.py');old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
class CacheChecks(unittest.TestCase):
 def scratch(self):
  d=tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR',str(R)));self.addCleanup(d.cleanup);return Path(d.name)
 def test_copy_preserves_generated_bytes_without_modifying_source(self):
  p=self.scratch();a,before=m.prepare('baseline',p);self.assertEqual(before['files'],[]);(a/'real-generated-fixture').write_bytes(b'not a GPU shader');original=m.inventory(a);b,got=m.prepare('candidate',p);self.assertEqual(got,original);self.assertEqual(m.inventory(a),original);self.assertNotEqual(a,b)
 def test_existing_cache_destination_rejected(self):
  p=self.scratch();m.prepare('baseline',p)
  with self.assertRaises(ValueError):m.prepare('baseline',p)
 def test_symlink_source_rejected(self):
  p=self.scratch();a,_=m.prepare('baseline',p);(a/'outside').symlink_to(p/'not-owned')
  with self.assertRaises(ValueError):m.prepare('candidate',p)
 def test_late_shutdown_stats_parsed(self):
  self.assertEqual(m.stats(b'pipeline ready\nMESA: info: disk shader cache:  hits = 63, misses = 4\n','laptop'),[{'hits':63,'misses':4}])
 def test_missing_or_ambiguous_intel_stats_rejected(self):
  for raw in [b'none',b'disk shader cache:  hits = 1, misses = 2\n'*2]:
   with self.assertRaises(ValueError):m.stats(raw,'laptop')
 def test_non_mesa_host_does_not_invent_stats(self):self.assertEqual(m.stats(b'NVIDIA worker','apollo'),[])
 def test_immediate_critical_temperature(self):
  with self.assertRaises(RuntimeError):m.thermal_sample(95000,0)
 def test_warning_bursts_need_three_consecutive_samples(self):
  c=m.thermal_sample(85000,0);c=m.thermal_sample(90000,c);self.assertEqual(c,2);self.assertEqual(m.thermal_sample(84999,c),0)
  with self.assertRaises(RuntimeError):m.thermal_sample(85000,c)
 def test_stats_environment_does_not_enable_runtime_experiments(self):
  env=m.environment('/owned/cache','laptop','/owned/intel.json');self.assertEqual(env['MESA_SHADER_CACHE_SHOW_STATS'],'true');self.assertEqual(env['VK_DRIVER_FILES'],'/owned/intel.json');self.assertFalse(any(k.startswith('GGML')for k in env))
 def test_full_comparison_entry_with_fake_backend_and_cache_reuse(self):self.full(False)
 def test_unclean_population_stops_before_retained_arm(self):self.full(True)
 def full(self,crash):
  r=self.scratch();model=r/'fake.gguf';model.write_bytes(b'CPU-only fixture');runtime=r/'not-a-native-binary';runtime.write_bytes(b'CPU-only fixture')
  fake=old.FAKE
  a="self.candidate=os.environ.get('GGML_VK_SERIALIZE_SUBMISSIONS')=='1'";self.assertEqual(fake.count(a),1)
  fake=fake.replace(a,"self.candidate='candidate-cache' in os.environ['MESA_SHADER_CACHE_DIR']\n  cache=Path(os.environ['MESA_SHADER_CACHE_DIR']);(cache/'generated-fixture').write_bytes(b'CPU-only cache fixture')")
  worker=r/'worker.py';worker.write_text('DIAGNOSTIC_BASELINE='+repr(old.diagnostic(False,'apollo'))+'\nDIAGNOSTIC_CANDIDATE='+repr(old.diagnostic(False,'apollo'))+'\nNATIVE_FIELDS='+repr(q.NATIVE_FIELDS)+'\n'+fake)
  exitfile=r/'exit.py';exitfile.write_text("def wait_native(n,timeout):\n import os\n code=7 if os.environ.get('CONFLUX_CPU_FIXTURE_CRASH')=='1' else 0\n n.process.returncode=code\n return dict(returncode=code,stdout_tail='',stderr_retained_bytes=len(n._stderr_tail))\n")
  manifest=json.loads((R/'inputs-manifest.json').read_text());zero=hashlib.sha256(bytes(4*343980*2*4)).hexdigest();manifest['model_sha256']=q.pin(model)['sha256']
  for c in manifest['cases']:c['accepted_NVIDIA_output_sha256']=zero
  mp=r/'manifest.json';mp.write_text(json.dumps(manifest));plan=dict(schema=1,mode=q.MODE,host='apollo',operator_seconds=1200,command_seconds=900,request_seconds=30,requests_per_arm={'baseline':2,'candidate':2},timing_qualification=False,retries=False,input_root=('/inputs/pcm-inputs'if Path('/inputs/pcm-inputs').is_dir()else'/srv/conflux-tests/laptop/retained/build/m2-flash-shared-staging-01/pcm-inputs'),readiness=str(r/'readiness.json'),output=str(r/'output'),cap_ceilings={})
  plan['pins']={k:q.pin(p)for k,p in dict(driver=R/'compare_pcm.py',worker=worker,model=model,inputs_manifest=mp,baseline=runtime,candidate=runtime,native_exit=exitfile,cache_control=R/'cache_control.py').items()};pp=r/'plan.json';pp.write_text(json.dumps(plan))
  from datetime import datetime,timezone
  import time
  h=dict(schema=1,mode=q.MODE,plan_sha256=q.pin(pp)['sha256'],operator_seconds=1200,original_readiness_utc=datetime.now(timezone.utc).isoformat(),deadline_monotonic=time.monotonic()+1200,physical_conditions_confirmed=True,human_question='CPU-only fixture',human_reply='CPU-only fixture',question_item_id='CPU-only fixture');(r/'readiness.json').write_text(json.dumps(h))
  env=dict(os.environ)
  for k in list(env):
   if k.startswith(('GGML_VK_','GGML_VULKAN_','MESA_','INTEL_DEBUG','CONFLUX_DRM_','CONFLUX_REQUEST_TRACE_')):env.pop(k)
  if crash:env['CONFLUX_CPU_FIXTURE_CRASH']='1'
  z=subprocess.run([sys.executable,'-B',str(R/'compare_pcm.py'),'--plan',str(pp),'--run'],env=env,capture_output=True,text=True,timeout=20);self.assertEqual(z.returncode,1 if crash else 0,z.stdout+z.stderr);v=json.loads((r/'output/result.json').read_text());self.assertTrue(v['cleanup_complete']);
  if crash:
   self.assertFalse(v['completed']);self.assertNotIn('candidate',v['arms']);self.assertEqual(v['arms']['baseline']['teardown']['returncode'],7);self.assertTrue(v['arms']['baseline']['native_reaped']);return
  self.assertTrue(v['completed']);self.assertIsNone(v['cache_reuse_observed']);self.assertTrue(v['cache_files_retained_between_processes']);self.assertFalse(v['timing_qualification']);self.assertFalse(v['shader_submission_serialization']);self.assertEqual([len(v['arms'][a]['requests'])for a in ['baseline','candidate']],[2,2]);self.assertEqual(v['arms']['candidate']['cache_before'],v['arms']['baseline']['cache_after']);self.assertFalse(v['arms']['baseline']['cache_before']['files'])
if __name__=='__main__':unittest.main(verbosity=2)
