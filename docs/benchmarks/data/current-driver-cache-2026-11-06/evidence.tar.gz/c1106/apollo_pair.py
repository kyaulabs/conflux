from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');args=ap.parse_args()
if not args.run:
 subprocess.run([sys.executable,'-B',str(P/'packet/apollo_owner.py')],check=True,timeout=30)
 print(json.dumps(dict(verified=True,hardware_started=False)));raise SystemExit(0)
h=json.loads((P/'readiness.json').read_text());age=(datetime.now(timezone.utc)-datetime.fromisoformat(h['original_readiness_utc'])).total_seconds()
assert 0<=age<=90 and h['operator_seconds']==1200 and h['config_sha256']==hashlib.sha256((P/'config.json').read_bytes()).hexdigest()
assert all(h.get(k)is True for k in ['AC_power','lid_open','other_work_paused','Codex_minimized','no_suspend','CONFLUX_closed'])
plan=P/'packet/apollo-plan.json';child=dict(h,schema=1,mode='m2-current-driver-cache-20261106-01',plan_sha256=hashlib.sha256(plan.read_bytes()).hexdigest(),deadline_monotonic=__import__('time').monotonic()+1200-age,physical_conditions_confirmed=True)
with(P/'packet/readiness.json').open('x')as f:f.write(json.dumps(child,indent=2)+'\n')
z=subprocess.run([sys.executable,'-B',str(P/'packet/apollo_owner.py'),'--run'],timeout=960)
raise SystemExit(z.returncode)
