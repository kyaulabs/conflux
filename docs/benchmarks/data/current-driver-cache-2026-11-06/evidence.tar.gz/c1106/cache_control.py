"""Owned per-arm cache handling and shutdown-stat parsing; no driver calls."""
from pathlib import Path
import hashlib,os,re,shutil
MAX_BYTES=128*1024*1024

def inventory(root):
    root=Path(root)
    if root.is_symlink()or not root.is_dir():raise ValueError('Owned regular cache directory required')
    rows=[];total=0
    for p in sorted(root.rglob('*')):
        if p.is_symlink():raise ValueError('Cache symlink refused')
        if not p.is_file():continue
        total+=p.stat().st_size
        if total>MAX_BYTES or len(rows)>=10000:raise ValueError('Cache capture exceeds bound')
        with p.open('rb')as f:d=hashlib.file_digest(f,'sha256').hexdigest()
        rows.append(dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=d))
    return dict(files=rows,bytes=total)

def prepare(arm,output):
    root=Path(output)/(arm+'-cache')
    if root.exists()or root.is_symlink():raise ValueError('Consumed cache destination refused')
    if arm=='baseline':root.mkdir(mode=0o700)
    elif arm=='candidate':
        source=Path(output)/'baseline-cache';before=inventory(source)
        shutil.copytree(source,root)
        if inventory(root)!=before:raise ValueError('Retained cache copy differs')
    else:raise ValueError('Unknown arm')
    return root,inventory(root)

def environment(root,host,icd=None):
    e={'MESA_SHADER_CACHE_DIR':str(root),'MESA_SHADER_CACHE_MAX_SIZE':'128M',
       'XDG_CACHE_HOME':str(root),'__GL_SHADER_DISK_CACHE':'1','__GL_SHADER_DISK_CACHE_PATH':str(root)}
    if host=='laptop':
        if icd is None:raise ValueError('Explicit Intel ICD required')
        e.update(MESA_SHADER_CACHE_SHOW_STATS='true',VK_DRIVER_FILES=str(icd))
    elif host!='apollo':raise ValueError('Unknown host')
    return e

def stats(raw,host):
    rows=[dict(hits=int(h),misses=int(m))for h,m in re.findall(rb'disk shader cache:\s+hits = ([0-9]+), misses = ([0-9]+)',raw)]
    if host=='laptop'and len(rows)!=1:raise ValueError('Expected one Intel Mesa disk-cache stats row at real exit')
    return rows

def thermal_sample(peak,consecutive):
    consecutive=consecutive+1 if peak>=85000 else 0
    if peak>=95000 or consecutive>=3:raise RuntimeError('Retained95C/three-sample85C thermal stop')
    return consecutive
