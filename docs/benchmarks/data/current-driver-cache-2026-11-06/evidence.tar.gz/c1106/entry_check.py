"""Read-only container entry check. Never imports a model/GPU backend."""
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path('/probe/packet')
steps = [[sys.executable, '-B', str(BASE/'compare_pcm.py'), '--plan', str(BASE/'apollo-plan.json')]]
steps += [['/probe/conflux-stem-runtime', '--help']]
steps += [[sys.executable, '-B', '/probe/packet/test_native_exit.py']]
steps += [[sys.executable, '-B', '/probe/packet/test_cache_compare.py']]
scratch=Path('/results/test-tmp');scratch.mkdir(mode=0o700)
environment=dict(os.environ,TMPDIR=str(scratch))
report = dict(hardware_started=False, steps=[])
for command in steps:
    result = subprocess.run(command, env=environment, capture_output=True, text=True, timeout=30)
    report['steps'].append(dict(command=command, exit=result.returncode, stdout=result.stdout[:4096], stderr=result.stderr[:4096]))
    assert result.returncode == 0, report
Path('/results/entry-result.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(dict(verified=True, steps=len(steps), hardware_started=False)))
