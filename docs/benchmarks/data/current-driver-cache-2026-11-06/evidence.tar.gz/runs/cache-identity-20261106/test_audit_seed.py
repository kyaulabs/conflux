from pathlib import Path
import importlib.util,tempfile,struct,unittest
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('audit_seed',P/'audit_seed.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
OLD='6ce609c1a667be4f4358bbbbdc5dd02a7ad6a5dd'
NEW='75a40bb22a8833b077a212b1a91afb83d2db5552'
def entry(build=NEW,gpu='anv_9a49'):
    return b'\x01'+m.driver_id(build).encode()+b'\0'+gpu.encode()+b'\0'+bytes([struct.calcsize('P')])+(0).to_bytes(8,'little')+b'CPU fixture, never a shader'
class SeedTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=P);self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.file=self.root/'mesa_shader_cache/aa'/('b'*62);self.file.parent.mkdir(parents=True)
 def test_obsolete_build_refused_even_with_correct_renderer(self):
  self.file.write_bytes(entry(OLD));r=m.audit(self.root,NEW,'anv_9a49');self.assertFalse(r['usable_as_current_driver_seed']);self.assertEqual(r['mismatched_entries'],1)
 def test_matching_identity_does_not_claim_hit_or_warmness(self):
  self.file.write_bytes(entry());r=m.audit(self.root,NEW,'anv_9a49');self.assertTrue(r['usable_as_current_driver_seed']);self.assertFalse(r['actual_cache_hits_measured']);self.assertFalse(r['warm_cache_proven'])
 def test_wrong_gpu_refused(self):
  self.file.write_bytes(entry(gpu='anv_1234'));self.assertFalse(m.audit(self.root,NEW,'anv_9a49')['usable_as_current_driver_seed'])
 def test_truncated_cache_member_refused(self):
  self.file.write_bytes(entry()[:83])
  with self.assertRaises(ValueError):m.audit(self.root,NEW,'anv_9a49')
 def test_symlink_refused(self):
  outside=self.root/'outside';outside.write_bytes(entry());self.file.symlink_to(outside)
  with self.assertRaises(ValueError):m.audit(self.root,NEW,'anv_9a49')
 def test_empty_seed_is_not_warm(self):
  r=m.audit(self.root,NEW,'anv_9a49');self.assertFalse(r['usable_as_current_driver_seed']);self.assertEqual(r['entry_count'],0)
 def test_real_seed_identity_and_input_preservation(self):
  p=Path('/srv/conflux-tests/laptop/retained/build/m2-shared-staging-player-01/cache-seed');before={str(f.relative_to(p)):(f.stat().st_size,f.stat().st_mtime_ns)for f in p.rglob('*')if f.is_file()};r=m.audit(p,NEW,'anv_9a49');self.assertEqual(r['entry_count'],64);self.assertEqual(r['same_build_renderer_pointer_entries'],0);self.assertEqual(r['mismatched_entries'],64);self.assertEqual(before,{str(f.relative_to(p)):(f.stat().st_size,f.stat().st_mtime_ns)for f in p.rglob('*')if f.is_file()})
if __name__=='__main__':unittest.main(verbosity=2)
