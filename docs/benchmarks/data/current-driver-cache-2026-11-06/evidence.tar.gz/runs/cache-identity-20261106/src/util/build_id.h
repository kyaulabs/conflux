/*
 * Copyright © 2016 Intel Corporation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the next
 * paragraph) shall be included in all copies or substantial portions of the
 * Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#ifndef BUILD_ID_H
#define BUILD_ID_H

#include "detect_os.h"

#if defined(HAVE_DL_ITERATE_PHDR) || DETECT_OS_APPLE
#define HAVE_BUILD_ID 1
#else
#define HAVE_BUILD_ID 0
#endif /* defined(HAVE_DL_ITERATE_PHDR) || DETECT_OS_APPLE */

#ifdef __cplusplus
extern "C" {
#endif

#include "mesa-blake3.h"

#if HAVE_BUILD_ID

#define BUILD_ID_EXPECTED_HASH_LENGTH 20 /* sha1 */

struct build_id_note;

const struct build_id_note *
build_id_find_nhdr_for_addr(const void *addr);

unsigned
build_id_length(const struct build_id_note *note);

const uint8_t *
build_id_data(const struct build_id_note *note);

void
copy_build_id_to_sha1(uint8_t sha1[BLAKE3_KEY_LEN],
                      const struct build_id_note *note);

#endif

void
_mesa_sha1_format(char *buf, const unsigned char *sha1);

#ifdef __cplusplus
}
#endif
#endif /* BUILD_ID_H */
