import json,importlib.util,unittest,tempfile,time,copy,hashlib
from pathlib import Path
from datetime import datetime,timezone
D=Path(__file__).resolve().parent;C=Path('/srv/conflux-tests/laptop/c1106');s=importlib.util.spec_from_file_location('continued_probe',D/'compare_retained.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
class OriginTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=D/'t');self.addCleanup(self.tmp.cleanup);self.p=Path(self.tmp.name)/'original.json';self.cold=json.loads((C/'output-01/result.json').read_text());self.h=json.loads((C/'native-readiness.json').read_text())
 def check(self):
  self.p.write_text(json.dumps(self.cold));return q.retained_origin({'original_result':str(self.p),'pins':{'original_result':q.pin(self.p)}},self.h)
 def test_actual_successful_cold_outputs_and_reaping_preserved(self):
  r=self.check();self.assertEqual(len(r['requests']),2);self.assertTrue(r['native_reaped']);self.assertTrue(r['original_capture_reused'])
 def test_unclean_exit_rejected(self):
  self.cold['failed_native_returncode']=-9
  with self.assertRaises(RuntimeError):self.check()
 def test_unproven_reaping_rejected(self):
  self.cold['failed_runtime_reaped']=False
  with self.assertRaises(RuntimeError):self.check()
 def test_missing_original_request_rejected(self):
  self.cold['arms']['baseline']['requests'].pop()
  with self.assertRaises(RuntimeError):self.check()
 def test_changed_failure_cannot_be_waived(self):
  self.cold['errors'][0]['error']='A different failure'
  with self.assertRaises(RuntimeError):self.check()
 def test_second_original_arm_cannot_be_rerun(self):
  self.cold['arms']['candidate']={}
  with self.assertRaises(RuntimeError):self.check()
 def test_operator_deadline_cannot_be_renewed(self):
  self.h['deadline_monotonic']+=1200
  with self.assertRaises(RuntimeError):self.check()
 def test_operator_timestamp_cannot_be_renewed(self):
  self.h['original_readiness_utc']=datetime.now(timezone.utc).isoformat()
  with self.assertRaises(RuntimeError):self.check()
if __name__=='__main__':unittest.main(verbosity=2)
