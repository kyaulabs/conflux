#!/usr/bin/env python3
"""Private, dry-by-default normal-runtime output comparison; no audio or timing gate."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time

MODE = 'm2-cache-retained-continuation-20261106-01'
FRAMES, CHANNELS, STEMS = 343980, 2, ['drums', 'bass', 'other', 'vocals']
NATIVE_FIELDS = ('elapsed_ms', 'inference_wall_ms', 'inference_cpu_ms', 'frontend_ms',
                 'graph_ms', 'graph_upload_ms', 'graph_compute_ms', 'graph_readback_ms',
                 'postprocess_ms', 'graph_rebuild_ms')
GRAPH = ('conflux_flash_f32_graph nodes=2871 flash_nodes=10 self1344=3 self2688=3 '
         'cross2688to1344=2 cross1344to2688=2')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def pin(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'Regular, nonsymlink file required: ' + str(path))
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def verify(plan):
    require(plan['schema'] == 1 and plan['mode'] == MODE and plan['host'] in ('laptop', 'apollo'), 'Wrong plan')
    require(plan['operator_seconds'] == 1200 and plan['command_seconds'] == 900 and
            plan['request_seconds'] == 30 and plan['requests_per_arm'] == {'baseline': 2, 'candidate': 2} and
            plan['timing_qualification'] is False and plan['retries'] is False, 'Workload/budget differs')
    for row in plan['pins'].values():
        require(pin(row['path']) == row, 'Frozen file changed: ' + row['path'])
    manifest = json.loads(Path(plan['pins']['inputs_manifest']['path']).read_text())
    require(manifest['case_count'] == 16 and manifest['window_frames'] == FRAMES and
            manifest['channels'] == CHANNELS and manifest['sample_rate'] == 44100 and
            manifest['model_sha256'] == plan['pins']['model']['sha256'], 'Wrong input geometry/model')
    expected_ids = [f'{track}:{start}' for track in
                    ('club_xl', 'when_the_light_breaks', 'under_my_skin', 'stfu')
                    for start in (0, 257985, 515970, 773955)]
    require([c['id'] for c in manifest['cases']] == expected_ids, 'Input order differs')
    for case in manifest['cases']:
        require(re.fullmatch(r'[0-9]{2}-[a-z_]+-[0-9]+\.f32', case['file']) is not None,
                'Invalid input filename')
        row = pin(Path(plan['input_root']) / case['file'])
        require(row['sha256'] == case['sha256'] and row['bytes'] == case['bytes'] == FRAMES * CHANNELS * 4,
                'Input differs: ' + case['id'])
    return manifest


def validate_human(human, plan_sha, now_utc, now_mono):
    original = datetime.fromisoformat(human['original_readiness_utc'])
    require(original.tzinfo is not None, 'Readiness requires a timezone')
    age = (now_utc - original).total_seconds()
    remaining = human['deadline_monotonic'] - now_mono
    require(human['schema'] == 1 and human['mode'] == MODE and human['plan_sha256'] == plan_sha and
            human['operator_seconds'] == 1200 and 0 <= age <= 1200 and
            180 <= remaining <= 1200 - age + 2 and human['physical_conditions_confirmed'] is True and
            all(isinstance(human.get(k), str) and 0 < len(human[k]) <= 8192
                for k in ('human_question', 'human_reply', 'question_item_id')), 'Fresh original readiness required')
    return min(now_mono + 900, human['deadline_monotonic'] - 60)


def load(name, row):
    require(pin(row['path']) == row, 'Import pin changed')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def check_metrics(metrics, request_id):
    require(metrics.get('event') == 'result' and type(metrics.get('id')) is int and
            metrics['id'] == request_id and metrics.get('frames') == FRAMES and
            metrics.get('stems') == 4, 'Native result identity/geometry differs')
    for name in NATIVE_FIELDS:
        value = metrics.get(name)
        require(type(value) in (int, float) and math.isfinite(value) and value >= 0,
                'Invalid native phase: ' + name)


def activation(stderr, candidate, host):
    lines = stderr.decode('utf-8', errors='replace').splitlines()
    require([s for s in lines if s.startswith('conflux_flash_f32_graph ')] == [GRAPH], 'Wrong Flash graph')
    vendor = 'Intel(R) Iris(R) Xe' if host == 'laptop' else 'NVIDIA'
    require(any(s.startswith('ggml_vulkan: 0 = ') and vendor in s for s in lines), 'Wrong Vulkan device')
    signatures = []
    for line in lines:
        if not line.startswith('conflux_flash_f32_pipeline '):
            continue
        fields = dict(word.split('=', 1) for word in line.split()[1:])
        for key, value in {'shader': 'flash_attn_f32_f16_fp32', 'path': 'scalar',
                           'intermediate_bytes': '4', 'accumulation_bytes': '4',
                           'hsk': '64', 'hsv': '64', 'k': 'f32', 'v': 'f32'}.items():
            require(fields.get(key) == value, 'Full-F32 activation differs')

        if host == 'laptop':
            require(fields.get('Br') == '4' and fields.get('Bc') == '32' and
                    fields.get('workgroup') == '128', 'Intel tile changed')
        signatures.append(fields)
    marker = 'conflux_vulkan: serialized graph submissions enabled'
    require(lines.count(marker) == (1 if candidate else 0), 'Submission synchronization activation differs')
    require(bool(signatures), 'Missing actual pipeline activation')
    return signatures


def check_ready(ready, model, pid):
    require(ready.get('event') == 'ready' and ready.get('fence_wait_mode') == 'blocking' and
            ready.get('revision') == '0097d365a00b52a6991ad7618f0a04e8d2935e47' and
            ready.get('model') == str(Path(model).resolve()) and ready.get('pid') == pid and
            ready.get('backend') == 'vulkan' and ready.get('threads') == 2 and
            ready.get('weight_storage') == 'native' and ready.get('sample_rate') == 44100 and
            ready.get('channels') == CHANNELS and ready.get('segment_frames') == FRAMES and
            ready.get('stems') == STEMS and ready.get('process_environment') ==
            {'OMP_WAIT_POLICY': 'PASSIVE', 'GOMP_SPINCOUNT': '0'}, 'Wrong normal runtime contract')


def check_caps(values, ceilings):
    require(values.keys() == ceilings.keys(), 'Power-cap fields differ')
    for path, ceiling in ceilings.items():
        value = values[path]
        require(type(value) is int and value > 0 and
                (value <= ceiling if path.endswith('_power_limit_uw') else value == ceiling),
                'Power ceiling increased: ' + path)


def retained_origin(plan,human):
    require(pin(Path(plan['original_result']))==plan['pins']['original_result'],'Original result changed')
    cold=json.loads(Path(plan['original_result']).read_text())
    require(cold['original_readiness_utc']==human['original_readiness_utc']and cold['original_operator_deadline']==human['deadline_monotonic'],'Original operator lease cannot be renewed')
    require(cold['cleanup_complete'] and cold.get('failed_runtime_reaped') is True and cold.get('failed_native_returncode')==0,'Original native reaping unproven')
    require(cold['errors']==[dict(phase='comparison',type='ValueError',error='Expected one Intel Mesa disk-cache stats row at real exit')],'Original failure differs')
    require(set(cold['arms'])=={'baseline'},'Original retained arm was already attempted')
    row=cold['arms']['baseline']
    require(len(row['requests'])==2 and all(r['exact_match']for r in row['requests'])and row['graceful_shutdown']and row['teardown']['returncode']==0,'Original full outputs/shutdown unproven')
    row=dict(row,native_reaped=True,reap_evidence=plan['original_result'],original_capture_reused=True)
    return row

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    if not args.run:
        manifest = verify(plan)
        print(json.dumps({'verified': True, 'cases': len(manifest['cases']), 'hardware_started': False}))
        return 0
    human = json.loads(Path(plan['readiness']).read_text())
    started = time.monotonic()
    deadline = validate_human(human, pin(args.plan)['sha256'], datetime.now(timezone.utc), started)
    output = Path(plan['output'])
    output.mkdir(mode=0o700)  # A consumed window/output is never retried.
    report = dict(schema=1, mode=MODE, host=plan['host'], completed=False, cleanup_complete=False,
                  timing_qualification=False, service_target_ms=4095, audio_started=False,
                  hard_cancellation_exercised=False, retries=False, arms={}, errors=[],
                  cache_comparison='Empty owned cache, then separate copy of actually generated cache; same binary/math/inputs; first cold request retained',
                  shader_submission_serialization=False,
                  original_readiness_utc=human['original_readiness_utc'], started_monotonic=started,
                  deadline_monotonic=deadline, original_operator_deadline=human['deadline_monotonic'])
    report['arms']['baseline']=retained_origin(plan,human)
    report['original_diagnostic_passed']=False
    report['all_expected_cache_statistics_collected']=False
    report['continuation_scope']='Only the two remaining retained-cache requests; original cold requests and collector failure preserved'
    native = None
    stop = threading.Event()
    monitor = None
    def checkpoint(): save(output / 'result.json', report)
    def interrupted(signum, frame): raise InterruptedError('Owned diagnostic signal ' + str(signum))
    for number in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM, signal.SIGUSR1):
        signal.signal(number, interrupted)
    signal.setitimer(signal.ITIMER_REAL, max(.1, deadline - time.monotonic()))
    try:
        checkpoint()
        manifest = verify(plan)
        require(not any(k.startswith(('GGML_VK_', 'GGML_VULKAN_', 'MESA_', 'INTEL_DEBUG', 'CONFLUX_DRM_',
                                     'CONFLUX_REQUEST_TRACE_')) for k in os.environ), 'Inherited GPU experiment switches')
        worker = load('shared_staging_worker', plan['pins']['worker'])
        cache = load('owned_cache_control', plan['pins']['cache_control'])
        import numpy as np
        if plan['host'] == 'laptop':
            owner = load('shared_staging_host_readings', plan['pins']['host_readings'])
            guard = owner.guard_identity(Path(plan['pins']['guard_script']['path']), Path(plan['pins']['guard_unit']['path']))
            report['guard_before'] = guard
            sensors = owner.sensor_paths()
            def snapshot():
                require((datetime.now(timezone.utc)-datetime.fromisoformat(human['original_readiness_utc'])).total_seconds()<=1200,'Original wall-clock window expired')
                row = owner.observation(sensors)
                row['power'] = owner.power_state()
                row['caps'] = {p: int(Path(p).read_text()) for p in plan['cap_ceilings']}
                check_caps(row['caps'], plan['cap_ceilings'])
                require(not row['read_errors'] and row['power']['ac_online'] and row['power']['lid_open'], 'AC/lid/sensor changed')
                require(row['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'] in ('balanced', 'low-power'),
                        'Performance profile is outside this comparison')
                require(owner.process_identity(guard['process']['pid']) == guard['process'], 'Thermal guard identity changed')
                return row
            # Same natural <=70C/60s admission before each arm; never select a profile.
            def settle(label, reserve):
                cool_deadline = min(time.monotonic() + 240, deadline - reserve)
                since = None
                with (output / (label + '-cooldown.jsonl')).open('x') as log:
                    while time.monotonic() < cool_deadline:
                        row = snapshot(); now = time.monotonic()
                        cool = max(row['temperatures_millidegrees_C'].values()) <= 70000
                        since = (now if since is None else since) if cool else None
                        log.write(json.dumps(row) + '\n'); log.flush()
                        if since is not None and now - since >= 60:
                            return row
                        time.sleep(min(2, max(0, cool_deadline - time.monotonic())))
                raise RuntimeError('Bounded <=70C/60s settling interval not reached: ' + label)
            baseline_start_snapshot = settle('retained', 150)
            def observe():
                try:
                    with (output / 'host-observations.jsonl').open('x') as log:
                        consecutive = 0
                        while not stop.is_set():
                            sampled = snapshot()
                            peak = max(sampled['temperatures_millidegrees_C'].values())
                            log.write(json.dumps(sampled) + '\n'); log.flush()
                            consecutive = cache.thermal_sample(peak, consecutive)
                            stop.wait(2)
                except BaseException as error:
                    report['errors'].append({'phase': 'host_observation', 'error': str(error)})
                    os.kill(os.getpid(), signal.SIGUSR1)
            monitor = threading.Thread(target=observe, daemon=True)
            monitor.start()
        exit_helper = load('private_native_exit', plan['pins']['native_exit'])
        baseline_signatures = report['arms']['baseline']['pipeline_signatures']
        for arm in ('candidate',):
            require(deadline - time.monotonic() >= 45, 'No remaining request/cleanup budget')
            row = report['arms'][arm] = dict(requests=[], graceful_shutdown=False, native_reaped=False)
            if plan['host'] == 'laptop':
                row['start_snapshot'] = baseline_start_snapshot
            import shutil
            cache_root=output/'candidate-cache'
            before=cache.inventory(Path(plan['retained_seed']))
            expected=json.loads(Path(plan['retained_seed_inventory']).read_text())
            require(before==expected,'Captured original cache changed')
            shutil.copytree(plan['retained_seed'],cache_root)
            require(cache.inventory(cache_root)==before,'Retained copy differs')
            row['cache_before']=before
            cache_environment = cache.environment(cache_root, plan['host'], plan.get('intel_icd'))
            previous_environment = {k: os.environ.get(k) for k in cache_environment}
            os.environ.update(cache_environment)
            try:
                native = worker.NativeRuntime(Path(plan['pins'][arm]['path']), Path(plan['pins']['model']['path']),
                                              'vulkan', 2, min(30, deadline - time.monotonic() - 15),
                                              spool_directory=output / (arm + '-spool'), max_stderr_bytes=65536)
            finally:
                for key, value in previous_environment.items():
                    if value is None: os.environ.pop(key, None)
                    else: os.environ[key] = value
            row['ready'] = native.start()
            check_ready(row['ready'], plan['pins']['model']['path'], native.process.pid)
            checkpoint()
            cases = manifest['cases'][:plan['requests_per_arm'][arm]]
            for request_id, case in enumerate(cases, 1):
                require(deadline - time.monotonic() >= 45, 'No remaining request/cleanup budget')
                samples = np.fromfile(Path(plan['input_root']) / case['file'], dtype='<f4').reshape(FRAMES, CHANNELS)
                require(np.isfinite(samples).all() and hashlib.sha256(samples.tobytes()).hexdigest() == case['sha256'], 'Input changed')
                native.timeout = min(30, deadline - time.monotonic() - 15)
                began = time.monotonic()
                pcm, metrics = native.infer(samples, request_id)
                digest = hashlib.sha256(pcm.tobytes()).hexdigest()
                check_metrics(metrics, request_id)
                expected = case['accepted_Intel_output_sha256' if plan['host'] == 'laptop' else 'accepted_NVIDIA_output_sha256']
                request = dict(id=request_id, case_id=case['id'], input_sha256=case['sha256'],
                               output_sha256=digest, expected_sha256=expected, exact_match=digest == expected,
                               round_trip_ms=(time.monotonic() - began) * 1000, native_metrics=metrics)
                row['requests'].append(request); checkpoint()
                require(request['exact_match'], 'Complete PCM differs: ' + arm + ' ' + case['id'])
            signatures = activation(bytes(native._stderr_tail), False, plan['host'])
            row['pipeline_signatures'] = signatures
            if arm == 'baseline': baseline_signatures = signatures
            else: require(signatures == baseline_signatures, 'Other pipeline tuning changed')
            native.process.stdin.write(b'{"command":"quit"}\n')
            row['teardown'] = exit_helper.wait_native(native, timeout=5)
            row['graceful_shutdown'] = row['teardown']['returncode'] == 0
            if not row['graceful_shutdown']:
                report['errors'].append(dict(phase='native_shutdown', arm=arm,
                                             returncode=row['teardown']['returncode']))
            # Both complete baseline requests are validated before this point.
            # Retain failed teardown, reap it, and check the candidate separately.
            stderr = bytes(native._stderr_tail)
            (output / (arm + '.stderr')).write_bytes(stderr)
            row['cache_stats']=[dict(hits=int(h),misses=int(m))for h,m in re.findall(rb'disk shader cache:\s+hits = ([0-9]+), misses = ([0-9]+)',stderr)]
            row['cache_statistics_available']=len(row['cache_stats'])==1
            row['cache_statistics_note']='Unavailable unless a real shutdown row exists; no hit count inferred from files or timing'
            row['cache_after'] = cache.inventory(cache_root)
            if plan['host'] == 'laptop':
                identity = load('cache_identity_audit', plan['pins']['cache_identity'])
                row['cache_identity_after'] = identity.audit(cache_root, plan['intel_build_id'], 'anv_9a49')
            native.close()
            row['native_reaped'] = native._process_reaped
            native = None
            checkpoint()
            require(row['graceful_shutdown'], 'Cache population did not exit cleanly; retained arm cannot use it')
        verify(plan)
        if plan['host'] == 'laptop':
            report['guard_after'] = owner.guard_identity(Path(plan['pins']['guard_script']['path']), Path(plan['pins']['guard_unit']['path']))
            require(report['guard_after'] == report['guard_before'], 'Guard changed')
            report['final_host_snapshot'] = snapshot()
        require(not report['errors'], 'One or more teardown/observer checks failed')
        candidate = report['arms']['candidate']
        report['cache_files_retained_between_processes'] = bool(candidate['cache_before']['files'])
        report['cache_reuse_observed'] = None  # NVIDIA supplies no Mesa hit/miss counters.
        if plan['host'] == 'laptop':
            report['cache_reuse_observed'] = ((report['cache_files_retained_between_processes']
                and candidate['cache_stats'][0]['hits'] > 0
                and candidate['cache_identity_after']['same_build_renderer_pointer_entries'] > 0)
                if candidate['cache_statistics_available'] else None)
        report['completed'] = True
    except BaseException as error:
        report['errors'].append({'phase': 'comparison', 'type': type(error).__name__, 'error': str(error)})
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        for number in (signal.SIGINT, signal.SIGTERM, signal.SIGUSR1): signal.signal(number, signal.SIG_IGN)
        stop.set()
        if monitor is not None: monitor.join(timeout=5)
        if native is not None:
            try:
                (output / 'failed-runtime.stderr').write_bytes(bytes(native._stderr_tail))
                native.close()
                report['failed_runtime_reaped'] = native._process_reaped
                report['failed_native_returncode'] = native.process.returncode
                report['failed_stderr_complete'] = False  # Normal exit drainer was not reached.
            except BaseException as error: report['errors'].append({'phase': 'cleanup', 'error': str(error)})
        report['cleanup_complete'] = (monitor is None or not monitor.is_alive()) and all(
            r['native_reaped'] for r in report['arms'].values()) if native is None else report.get('failed_runtime_reaped') is True and (monitor is None or not monitor.is_alive())
        report['finished_monotonic'] = time.monotonic()
        report['within_command_budget'] = report['finished_monotonic'] <= deadline
        report['completed'] = report['completed'] and report['cleanup_complete'] and report['within_command_budget'] and not report['errors']
        checkpoint()
    print(json.dumps({'completed': report['completed'], 'cleanup_complete': report['cleanup_complete'], 'errors': report['errors']}))
    return 0 if report['completed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
