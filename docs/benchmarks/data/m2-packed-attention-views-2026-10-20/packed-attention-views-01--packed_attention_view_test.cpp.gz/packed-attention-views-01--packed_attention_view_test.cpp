#include "packed_attention_view.hpp"

#include <ggml-alloc.h>
#include <ggml-backend.h>
#include <ggml-cpu.h>

#include <array>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
size_t checks = 0;
size_t compared = 0;

void require(bool condition, const std::string & message) {
    if (!condition) throw std::runtime_error(message);
    ++checks;
}

using Context = std::unique_ptr<ggml_context, decltype(&ggml_free)>;
using Backend = std::unique_ptr<ggml_backend, decltype(&ggml_backend_free)>;
using Allocator = std::unique_ptr<ggml_gallocr, decltype(&ggml_gallocr_free)>;

// Reproduce the original SliceModule -> cont -> reshape -> TransposeModule ->
// cont path using only the pinned ggml primitives, without a model/backend shim.
ggml_tensor * original_heads(ggml_context * ctx, ggml_tensor * packed, int projection) {
    auto * slice = ggml_view_3d(ctx, packed, 512, packed->ne[1], 1,
        packed->nb[1], packed->nb[2], static_cast<size_t>(projection) * 2048);
    auto * first_copy = ggml_is_contiguous(slice) && slice->view_offs == 0
        ? slice : ggml_cont(ctx, slice);
    auto * split = ggml_reshape_4d(ctx, first_copy, 64, 8, packed->ne[1], 1);
    return ggml_cont(ctx, ggml_permute(ctx, split, 0, 2, 1, 3));
}

std::vector<uint32_t> values(size_t count, uint32_t round) {
    // Raw F32 bits include signed zero, both denorm extremes and large finite
    // values. The remaining finite bit patterns distinguish tokens/heads/slabs.
    constexpr std::array<uint32_t, 10> edge = {
        0, 0x80000000u, 1, 0x80000001u, 0x007fffffu,
        0x807fffffu, 0x00800000u, 0x80800000u, 0x7f7fffffu, 0xff7fffffu};
    std::vector<uint32_t> out(count);
    for (size_t i = 0; i < count; ++i) {
        const uint32_t x = static_cast<uint32_t>(i) * 2654435761u + round * 2246822519u;
        out[i] = i % 257 == 0 ? edge[(i / 257 + round) % edge.size()]
            : ((x & 0x807fffffu) | (((x >> 24) % 254u) << 23));
    }
    return out;
}

std::vector<uint32_t> read_bits(ggml_tensor * tensor) {
    std::vector<uint32_t> out(static_cast<size_t>(ggml_nelements(tensor)));
    ggml_backend_tensor_get(tensor, out.data(), 0, out.size() * sizeof(uint32_t));
    return out;
}

void layout_case(ggml_backend_t backend, int projections, int64_t length) {
    Context ctx(ggml_init({4u * 1024u * 1024u, nullptr, true}), ggml_free);
    require(ctx != nullptr, "allocate descriptor context");
    auto * input = ggml_new_tensor_3d(ctx.get(), GGML_TYPE_F32, projections * 512, length, 1);
    auto * poison = ggml_new_tensor_3d(ctx.get(), GGML_TYPE_F32, projections * 512, length, 1);
    ggml_set_input(input);
    ggml_set_input(poison);
    // Packed is deliberately an intermediate, so view lifetime bookkeeping is
    // responsible for keeping it alive, rather than GGML_TENSOR_FLAG_INPUT.
    auto * packed_storage = ggml_cont(ctx.get(), input);
    // LinearModule returns a zero-offset reshape view of its computed output.
    auto * packed = ggml_reshape_3d(ctx.get(), packed_storage, projections * 512, length, 1);
    std::vector<ggml_tensor *> old_outputs, new_outputs;
    auto * graph = ggml_new_graph(ctx.get());
    for (int c = 0; c < projections; ++c) {
        auto * view = conflux_packed_attention::head_view(ctx.get(), packed, projections, c);
        require(view->type == GGML_TYPE_F32 && view->view_src == packed_storage && view->src[0] == packed,
            "new view owns an ordinary packed-source graph dependency");
        require(view->ne[0] == 64 && view->ne[1] == length && view->ne[2] == 8 && view->ne[3] == 1 &&
            view->nb[0] == 4 && view->nb[1] == static_cast<size_t>(projections) * 2048 &&
            view->nb[2] == 256 && view->nb[3] == static_cast<size_t>(projections * 2048 * length) &&
            view->view_offs == static_cast<size_t>(c) * 2048,
            "head view geometry and nonzero slab offsets");
        require(view->view_offs + (length - 1) * view->nb[1] + 7 * view->nb[2] +
            63 * view->nb[0] + 4 <= ggml_nbytes(packed), "last addressed sample is inside packed storage");
        auto * old_output = original_heads(ctx.get(), packed, c);
        auto * new_output = ggml_cont(ctx.get(), view);
        ggml_set_output(old_output);
        ggml_set_output(new_output);
        old_outputs.push_back(old_output);
        new_outputs.push_back(new_output);
        ggml_build_forward_expand(graph, old_output);
        ggml_build_forward_expand(graph, new_output);
    }
    // A further shared consumer must still see the full packed source. A later
    // unrelated same-size branch then reuses its freed pool block and poisons it.
    auto * retained = ggml_cont(ctx.get(), packed);
    ggml_set_output(retained);
    ggml_build_forward_expand(graph, retained);
    auto * reuse = ggml_cont(ctx.get(), poison);
    auto * reuse_output = ggml_cont(ctx.get(), reuse);
    ggml_set_output(reuse_output);
    ggml_build_forward_expand(graph, reuse_output);
    Allocator allocator(ggml_gallocr_new(ggml_backend_get_default_buffer_type(backend)), ggml_gallocr_free);
    require(allocator != nullptr && ggml_gallocr_alloc_graph(allocator.get(), graph), "allocate shared-source graph");
    require(packed->data == reuse->data, "test actually reuses packed intermediate storage after its final consumer");
    for (uint32_t round = 1; round <= 3; ++round) {
        const auto input_bits = values(static_cast<size_t>(ggml_nelements(input)), round);
        const auto poison_bits = values(input_bits.size(), round + 101);
        ggml_backend_tensor_set(input, input_bits.data(), 0, input_bits.size() * 4);
        ggml_backend_tensor_set(poison, poison_bits.data(), 0, poison_bits.size() * 4);
        require(ggml_backend_graph_compute(backend, graph) == GGML_STATUS_SUCCESS, "compute CPU layout graph");
        require(read_bits(retained) == input_bits, "shared packed consumer survived all head copies");
        require(read_bits(reuse_output) == poison_bits, "later allocator reuse branch wrote different data");
        for (int c = 0; c < projections; ++c) {
            const auto old_bits = read_bits(old_outputs[c]);
            const auto new_bits = read_bits(new_outputs[c]);
            require(old_bits == new_bits, "new layout is bit-exact to original materialized layout");
            bool matches = true;
            for (size_t h = 0; h < 8; ++h) {
                for (size_t t = 0; t < static_cast<size_t>(length); ++t) {
                    for (size_t d = 0; d < 64; ++d) {
                        const size_t src = (t * projections + c) * 512 + h * 64 + d;
                        const size_t dst = (h * length + t) * 64 + d;
                        matches = matches && new_bits[dst] == input_bits[src];
                        ++compared;
                    }
                }
            }
            require(matches, "independent packed-byte address oracle");
        }
    }
}

template<class F> void rejected(F action, const char * label) {
    bool failed = false;
    try { action(); } catch (const std::runtime_error &) { failed = true; }
    require(failed, label);
}

void invalid_sources() {
    Context ctx(ggml_init({1024u * 1024u, nullptr, true}), ggml_free);
    require(ctx != nullptr, "allocate invalid-source context");
    auto * good = ggml_new_tensor_3d(ctx.get(), GGML_TYPE_F32, 1536, 17, 1);
    rejected([&] { conflux_packed_attention::head_view(nullptr, good, 3, 0); }, "reject null context");
    rejected([&] { conflux_packed_attention::head_view(ctx.get(), nullptr, 3, 0); }, "reject null source");
    rejected([&] { conflux_packed_attention::head_view(ctx.get(), good, 1, 0); }, "reject wrong packed factor");
    rejected([&] { conflux_packed_attention::head_view(ctx.get(), good, 3, -1); }, "reject negative slab");
    rejected([&] { conflux_packed_attention::head_view(ctx.get(), good, 3, 3); }, "reject out-of-range slab");
    for (int mutation = 0; mutation < 9; ++mutation) {
        ggml_tensor bad = *good;
        switch (mutation) {
        case 0: bad.type = GGML_TYPE_F16; break;
        case 1: bad.view_offs = 4; break;
        case 2: bad.ne[0] -= 1; break;
        case 3: bad.ne[1] = 0; break;
        case 4: bad.ne[1] = 2689; break;
        case 5: bad.ne[2] = 2; break;
        case 6: bad.ne[3] = 2; break;
        case 7: bad.nb[1] += 4; break;
        case 8: bad.nb[3] += 4; break;
        }
        rejected([&] { conflux_packed_attention::head_view(ctx.get(), &bad, 3, 0); },
            "reject unsupported source type/shape/stride/offset");
    }
}
} // namespace

int main() {
    try {
        // No backend registry/discovery/Vulkan library or model is used.
        Backend backend(ggml_backend_cpu_init(), ggml_backend_free);
        require(backend != nullptr, "initialize only CPU backend");
        ggml_backend_cpu_set_n_threads(backend.get(), 1);
        invalid_sources();
        for (int projections : {2, 3}) {
            for (int64_t length : {1, 3, 17, 1344, 2688}) {
                layout_case(backend.get(), projections, length);
            }
        }
        std::cout << checks << " CPU layout/allocator assertions passed; "
                  << compared << " independently addressed F32 samples compared\n";
        return 0;
    } catch (const std::exception & error) {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
