#pragma once

#include <ggml.h>

#include <cstddef>
#include <cstdint>
#include <stdexcept>

namespace conflux_packed_attention {

// Private fixed-geometry F32 candidate. This is a view, never a reshape of a
// noncontiguous slice. The following ggml_cont remains the Flash input owner.
inline ggml_tensor * head_view(
    ggml_context * ctx, ggml_tensor * packed, int projections, int projection) {
    constexpr int64_t hidden = 512;
    constexpr int64_t heads = 8;
    constexpr int64_t head_dim = 64;
    constexpr size_t scalar = sizeof(float);
    if (ctx == nullptr || packed == nullptr ||
        (projections != 2 && projections != 3) ||
        projection < 0 || projection >= projections ||
        packed->type != GGML_TYPE_F32 || packed->view_offs != 0 ||
        packed->ne[0] != projections * hidden ||
        packed->ne[1] <= 0 || packed->ne[1] > 2688 ||
        packed->ne[2] != 1 || packed->ne[3] != 1) {
        throw std::runtime_error("Packed attention view geometry rejected");
    }
    const auto length = static_cast<size_t>(packed->ne[1]);
    const size_t token_stride = static_cast<size_t>(projections) * hidden * scalar;
    const size_t batch_stride = token_stride * length;
    const size_t offset = static_cast<size_t>(projection) * hidden * scalar;
    // Explicit extent check: ggml_view_4d's initial contiguous-size check is
    // performed before its custom strides are assigned.
    const size_t end = offset + (length - 1) * token_stride + hidden * scalar;
    if (packed->nb[0] != scalar || packed->nb[1] != token_stride ||
        packed->nb[2] != batch_stride || packed->nb[3] != batch_stride ||
        !ggml_is_contiguous(packed) || end > ggml_nbytes(packed)) {
        throw std::runtime_error("Packed attention view storage rejected");
    }
    return ggml_view_4d(ctx, packed, head_dim, packed->ne[1], heads, 1,
        token_stride, head_dim * scalar, batch_stride, offset);
}

} // namespace conflux_packed_attention
