#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Private full-client DRM diagnostic; exact PCM proof is mandatory before player launch."""
import argparse
import importlib.util
from types import SimpleNamespace
from datetime import datetime, timezone
import hashlib
import json
import math
import stat
import sys
import re
sys.dont_write_bytecode = True
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time


def read_command(command, timeout=3):
    value = subprocess.run(command, capture_output=True, text=True, timeout=timeout,
                           stdin=subprocess.DEVNULL)
    if value.returncode:
        raise RuntimeError(f"Read-only command failed: {command[0]}: {value.stderr.strip()}")
    return value.stdout.strip()


def save(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def pin(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    info = path.stat()
    return {"path": str(path), "bytes": info.st_size, "sha256": value.hexdigest()}


def process_identity(pid):
    root = Path("/proc") / str(pid)
    if root.stat().st_uid != os.getuid():
        raise RuntimeError("Observed PID is not owned by the current user")
    fields = (root / "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": pid, "start_ticks": int(fields[19]),
            "command": [part.decode(errors="replace") for part in (root / "cmdline").read_bytes().split(b"\0") if part]}


def guard_identity(script, service_file):
    raw = read_command(["systemctl", "--user", "show", "thermal-guard.service",
                        "--property=ActiveState,MainPID,InvocationID,ExecMainStartTimestampMonotonic"])
    fields = dict(line.split("=", 1) for line in raw.splitlines() if "=" in line)
    if fields.get("ActiveState") != "active" or int(fields.get("MainPID", 0)) <= 0:
        raise RuntimeError("Existing thermal-guard.service must remain active")
    identity = process_identity(int(fields["MainPID"]))
    if str(script) not in identity["command"]:
        raise RuntimeError("Active thermal guard does not match the pinned script")
    return {"service": fields, "process": identity, "script": pin(script), "unit": pin(service_file)}


def power_state():
    supplies = []
    for root in sorted(Path("/sys/class/power_supply").glob("*")):
        try:
            kind = (root / "type").read_text().strip()
            if kind in ("Mains", "USB", "USB_C", "USB_PD") and (root / "online").exists():
                supplies.append({"name": root.name, "type": kind, "online": int((root / "online").read_text())})
        except (OSError, ValueError):
            continue
    lids = {}
    for path in sorted(Path("/proc/acpi/button/lid").glob("*/state")):
        lids[str(path)] = path.read_text().strip()
    if lids:
        lid_open = all(value.lower().endswith("open") for value in lids.values())
    else:
        raw = read_command(["busctl", "--system", "get-property", "org.freedesktop.login1",
                            "/org/freedesktop/login1", "org.freedesktop.login1.Manager", "LidClosed"])
        if raw not in ("b true", "b false"):
            raise RuntimeError("Cannot establish the laptop lid state")
        lids["login1.LidClosed"] = raw
        lid_open = raw == "b false"
    return {"ac_online": any(item["online"] == 1 for item in supplies), "supplies": supplies,
            "lid_open": lid_open, "lid_sources": lids}


def sensor_paths():
    values = {}
    for root in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
        try:
            kind = (root / "type").read_text().strip()
            if kind in ("acpitz", "TCPU", "x86_pkg_temp"):
                values[str(root / "temp")] = kind
        except OSError:
            continue
    for root in sorted(Path("/sys/class/hwmon").glob("hwmon*")):
        try:
            if (root / "name").read_text().strip() == "coretemp":
                for path in sorted(root.glob("temp*_input")):
                    values[str(path)] = "coretemp"
        except OSError:
            continue
    if not values:
        raise RuntimeError("No CPU/ACPI temperature sensors used by the existing guard are readable")
    return values


def observation(paths):
    temperatures, errors = {}, {}
    for name in paths:
        try:
            temperatures[name] = int(Path(name).read_text().strip())
        except (OSError, ValueError) as error:
            errors[name] = str(error)
    policy = {}
    for path in (Path("/sys/firmware/acpi/platform_profile"),
                 Path("/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference")):
        try:
            policy[str(path)] = path.read_text().strip()
        except OSError as error:
            errors[str(path)] = str(error)
    return {"monotonic_ns": time.monotonic_ns(), "at_utc": datetime.now(timezone.utc).isoformat(),
            "temperatures_millidegrees_C": temperatures, "profile_epp_read_only": policy, "read_errors": errors}


def thermal_summary(path):
    records = [json.loads(line) for line in path.read_text().splitlines() if line]
    result = {"samples": len(records), "sample_interval_seconds": 2,
              "scope": "Observed CPU/ACPI samples; sampled spans do not establish continuous exposure or exclude shorter spikes"}
    maxima = [max(item["temperatures_millidegrees_C"].values(), default=None) for item in records]
    result["maximum_observed_millidegrees_C"] = max((item for item in maxima if item is not None), default=None)
    for threshold in (85000, 95000):
        start, longest, count = None, 0.0, 0
        for record, maximum in zip(records, maxima):
            if maximum is not None and maximum >= threshold:
                count += 1
                start = record["monotonic_ns"] if start is None else start
                longest = max(longest, (record["monotonic_ns"] - start) / 1e9)
            else:
                start = None
        result[str(threshold)] = {"samples_at_or_above": count, "longest_consecutive_sample_span_seconds": longest}
    result["profile_epp_observations"] = []
    previous = None
    for record in records:
        value = record["profile_epp_read_only"]
        if value != previous:
            result["profile_epp_observations"].append({"at_utc": record["at_utc"], "values": value})
            previous = value
    return result


def owned_objects(objects, pid):
    selected, ids = {}, set()
    for item in objects:
        if str(item.get("info", {}).get("props", {}).get("application.process.id", "")) == str(pid):
            selected[item["id"]] = item
            ids.add(str(item["id"]))
    for _ in range(3):
        for item in objects:
            props = item.get("info", {}).get("props", {})
            if any(str(props.get(key, "")) in ids for key in ("client.id", "node.id", "link.output.node")):
                selected[item["id"]] = item
                ids.add(str(item["id"]))
    return list(selected.values())



# These identities select the previously promoted pair; paths remain explicit.
FLASH_RUNTIME_SHA256 = "6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53"
FLASH_MODEL_SHA256 = "f8c54ba35df95aafea7881eac214b58ec18a73cbcb6ff5a90f4b762631a286b6"


RUNNER_ROOT = Path(__file__).resolve().parent
SOURCE_ROOT = Path(__file__).resolve().parents[3]
CANDIDATE_ROOT = SOURCE_ROOT / "benchmarks-local/background-player-01/request-trace-candidate"
OBSERVER_ROOT = RUNNER_ROOT.parent / "drm-clients-01"
PLAN = RUNNER_ROOT / "packed-attention-plan-02.json"
HUMAN = RUNNER_ROOT / "human-readiness-packed-attention-02.json"
MODE = "packed-attention-views-pcm16-player120-02"
NATIVE_SCHEMA = 2
NATIVE_MODE = "passive_drm_owned_client_set_v1"
NATIVE_TRACE_LIMITS = {"record_bytes": 16384, "file_bytes": 1048576, "requests": 64, "physical_rows": 82}
GPU_HELPER = CANDIDATE_ROOT / "frequency/gpu_observation.py"
GPU_HELPER_SHA256 = "349740c8a3b25fb15a647460a578c5075ffda64c2fe73226f8e6a817e54b9504"
CACHE_HELPER = RUNNER_ROOT / "cache_support.py"
CACHE_HELPER_SHA256 = "ae6a4d488b3b18c181808bfeb1cc68000392028b9feacea69ab9b17edbc58331"
OUTPUT = RUNNER_ROOT / "short-live-packed-attention-02"
PACKAGE_HELPER = CANDIDATE_ROOT / "hidden-power-limit-03/package_observation.py"
PACKAGE_HELPER_SHA256 = "6e16b6dbea45835523158389b0449f68f6d52700b42b91fece579a01ac6d65c1"
_PACKAGE_DOMAINS = {"mmio": ("/sys/class/powercap/intel-rapl-mmio:0", "/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0"),
    "msr": ("/sys/class/powercap/intel-rapl:0", "/sys/devices/virtual/powercap/intel-rapl/intel-rapl:0")}
_PACKAGE_LEAVES = (("name", "name", "identity"), ("enabled", "kernel_integer", "integer"),
    ("constraint_0_name", "name", "identity"), ("constraint_0_power_limit_uw", "uW", "integer"),
    ("constraint_0_time_window_us", "us", "integer"), ("constraint_1_name", "name", "identity"),
    ("constraint_1_power_limit_uw", "uW", "integer"), ("constraint_1_time_window_us", "us", "integer"))
_PACKAGE_NAMES = {"name": "package-0", "constraint_0_name": "long_term", "constraint_1_name": "short_term"}
LOGGER_ENV_KEYS = ("GGML_VK_PERF_LOGGER", "GGML_VK_PERF_LOGGER_FREQUENCY")
ASSET_PATHS = {"binary": SOURCE_ROOT / "build/dev/conflux-manual-playback-soak",
    "track_a": SOURCE_ROOT / "benchmarks-local/user-tracks-2026-10-17/assets/club_xl-30s-23p4s.wav",
    "track_b": SOURCE_ROOT / "benchmarks-local/m1-handoff-2026-10-17/quiet-soak-1.wav",
    "python": Path("/usr/bin/python3.14"), "exporter": SOURCE_ROOT / "tools/stems/export.py",
    "worker": SOURCE_ROOT / "tools/stems/worker.py", "service": RUNNER_ROOT / "service_drm.py",
    "runtime": RUNNER_ROOT / "conflux-stem-runtime",
    "model": Path("/tmp/conflux-stem-m0/models/htdemucs-f16.gguf"),
    "guard_script": Path("/home/kyau/.local/bin/thermal-guard"),
    "guard_unit": Path("/home/kyau/.config/systemd/user/thermal-guard.service")}

PCM_OUTPUT = RUNNER_ROOT / "pcm-equivalence-packed-attention-02"
INTERSTAGE_AUDIT = RUNNER_ROOT / "interstage-root-audit-02.json"
ALIAS_PATHS = {
    "python": (Path("/bin/python3"), ASSET_PATHS["python"], "assets", "python"),
    "libvulkan": (Path("/usr/lib/libvulkan.so"), Path("/usr/lib/libvulkan.so.1.4.363"), "source_pins", "reused_link_input:8"),
    "libgomp": (Path("/usr/lib/libgomp.so"), Path("/usr/lib/libgomp.so.1.0.0"), "source_pins", "reused_link_input:12"),
}
NATIVE_TRACE_NAME = "native-drm.jsonl"
TRACE_DIRECTORY_NAME = "drm-traces"
PCM_CASE_IDS = tuple(f"{track}:{start}" for track in
    ("club_xl", "when_the_light_breaks", "under_my_skin", "stfu") for start in (0,257985,515970,773955))
ORIGINAL_PCM = CANDIDATE_ROOT / "pcm-only/run_pcm_comparison.py"
ORIGINAL_PCM_SHA256 = "93139387253d91d59c2ce03448e888613da895c592905aba38368010d4b9ba3f"
REFERENCE = SOURCE_ROOT / "benchmarks-local/m2-graph-phase-2026-10-18/flash-promoted-repro-01/result.json"
REFERENCE_SHA256 = "44554b8e1caca9e92a49be7b9cc0e05ba7248f0091b4cdfc005e87e2c87ffe70"
TRACE_ENV_KEYS = ("CONFLUX_DRM_USAGE_TRACE", "CONFLUX_DRM_USAGE_RUN_ID", "CONFLUX_DRM_CONTEXT_DIRECTORY")
MANDATORY_SOURCES = {
    "runner": RUNNER_ROOT / "run_drm_player_retry02.py", "pcm_driver": RUNNER_ROOT / "run_drm_pcm_retry02.py",
    "runner_tests": RUNNER_ROOT / "drm_runner_retry02_check.py",
    "context_helper": RUNNER_ROOT / "context_capture.py", "trace_validator": RUNNER_ROOT / "drm_trace_validation.py",
    "trace_helper": CANDIDATE_ROOT / "trace_sidecar.py", "trace_parser": CANDIDATE_ROOT / "parse_trace.py",
    "original_service": SOURCE_ROOT / "tools/stems/service.py", "worker": SOURCE_ROOT / "tools/stems/worker.py",
    "private_service": RUNNER_ROOT / "service_drm.py", "native_source": RUNNER_ROOT / "pipeline.cpp",
    "native_helper": RUNNER_ROOT / "packed_attention_view.hpp", "native_abi": RUNNER_ROOT / "implementation-receipt.json",
    "native_fixture": RUNNER_ROOT / "packed_attention_view_test.cpp",
    "candidate_pipeline_object": RUNNER_ROOT / "pipeline.cpp.o", "candidate_engine_archive": RUNNER_ROOT / "libengine_runtime.a",
    "candidate_CPU_fixture": RUNNER_ROOT / "packed_attention_view_test",
    "observer_source": OBSERVER_ROOT / "htdemucs_segment.cpp", "observer_header": OBSERVER_ROOT / "drm_client_usage.hpp",
    "observer_object": OBSERVER_ROOT / "htdemucs_segment.cpp.o", "observer_abi": OBSERVER_ROOT / "implementation-receipt.json",
    "observer_review": OBSERVER_ROOT / "independent-native-review-01.json", "observer_build": OBSERVER_ROOT / "adapter-build-result.json",
    "observer_recipe": OBSERVER_ROOT / "build_recipe.json",
    "build_recipe": RUNNER_ROOT / "build_recipe.json", "pcm_original": ORIGINAL_PCM, "reference": REFERENCE,
    "native_review": RUNNER_ROOT / "independent-native-review-01.json",
}


def require_trace(condition, message):
    if not condition:
        raise RuntimeError(message)

def verify_gpu_helper(pinned):
    info = GPU_HELPER.lstat()
    require_trace(stat.S_ISREG(info.st_mode) and
        [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns] == pinned["identity"],
        "GPU observer source identity changed")

def load_gpu_observer(pinned):
    require_trace(pinned["sha256"] == GPU_HELPER_SHA256, "Frozen GPU observer source differs")
    verify_gpu_helper(pinned)
    spec = importlib.util.spec_from_file_location("conflux_frequency_observer", GPU_HELPER)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def validate_gpu_snapshot(discovery, snapshot):
    require_trace(discovery.get("identity_validated") is True and discovery.get("vendor") == "0x8086"
        and discovery.get("device") == "0x9a49" and discovery.get("actual_frequency_field") == "gt_act_freq_mhz"
        and discovery.get("requested_frequency_field") == "gt_cur_freq_mhz", "GPU discovery identity differs")
    fields = {row["relative_path"]: row["unit"] for row in discovery["fields"]}
    require_trace(len(fields) == len(discovery["fields"]) == 14 and "gt_act_freq_mhz" in fields
        and snapshot.get("identity_validated") is True
        and type(snapshot.get("schema")) is int and snapshot["schema"] == 1
        and type(snapshot.get("fields")) is dict and set(snapshot["fields"]) == set(fields),
        "GPU snapshot field binding differs")
    def number(value):
        return type(value) in (int, float) and math.isfinite(value) and value >= 0
    start, finish = snapshot.get("capture_started_monotonic"), snapshot.get("capture_finished_monotonic")
    require_trace(number(start) and number(finish) and start <= finish, "GPU capture clocks differ")
    for name, row in snapshot["fields"].items():
        began, ended = row.get("read_started_monotonic"), row.get("read_finished_monotonic")
        require_trace(type(row) is dict and row.get("unit") == fields[name] and number(began) and number(ended)
            and start <= began <= ended <= finish and (("value" in row) != ("error" in row)),
            "GPU field identity/clocks/value-error binding differs")
        if "value" in row:
            require_trace(type(row["value"]) is int and row["value"] >= 0, "GPU numeric value differs")
        else:
            require_trace(type(row["error"]) is dict and isinstance(row["error"].get("kind"), str),
                "GPU read error missing")
    return "value" in snapshot["fields"]["gt_act_freq_mhz"]

def verify_package_helper(pinned):
    info = PACKAGE_HELPER.lstat()
    require_trace(stat.S_ISREG(info.st_mode) and [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns] == pinned["identity"],
        "Package observer source identity changed")


def load_package_observer(pinned):
    require_trace(pinned["sha256"] == PACKAGE_HELPER_SHA256, "Frozen package observer source differs")
    verify_package_helper(pinned)
    spec = importlib.util.spec_from_file_location("conflux_package_limit_observer", PACKAGE_HELPER)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    verify_package_helper(pinned)
    return module


def validate_package_snapshot(discovery, snapshot):
    identity_keys = {"device", "inode", "mode", "uid", "gid"}
    def identity(value):
        return type(value) is dict and set(value) == identity_keys and all(type(v) is int and v >= 0 for v in value.values())
    require_trace(type(discovery) is dict and type(discovery.get("schema")) is int and discovery["schema"] == 1
        and discovery.get("identity_validated") is True and discovery.get("leaf_byte_limit") == 128
        and discovery.get("maximum_integer") == 2**63 - 1 and type(discovery.get("domains")) is dict
        and set(discovery["domains"]) == {"mmio", "msr"} and type(discovery.get("fields")) is list
        and len(discovery["fields"]) == 16, "Fixed package discovery scope differs")
    expected = {}
    for domain, (class_path, device_path) in _PACKAGE_DOMAINS.items():
        item = discovery["domains"][domain]
        require_trace(type(item) is dict and set(item) == {"class_path", "device_path", "class_identity", "device_identity"}
            and item["class_path"] == class_path and item["device_path"] == device_path
            and identity(item["class_identity"]) and identity(item["device_identity"]), "Package canonical domain binding differs")
        for name, unit, kind in _PACKAGE_LEAVES:
            expected[domain + "/" + name] = (str(Path(device_path) / name), unit, kind, name)
    declared = {}
    for field in discovery["fields"]:
        require_trace(type(field) is dict and set(field) == {"relative_path", "path", "unit", "kind", "identity"}
            and field.get("relative_path") in expected and identity(field["identity"]), "Package leaf identity binding differs")
        key = field["relative_path"]
        require_trace(key not in declared and (field["path"], field["unit"], field["kind"]) == expected[key][:3],
            "Package path/unit/kind differs")
        declared[key] = field
    require_trace(set(declared) == set(expected) and type(snapshot) is dict and type(snapshot.get("schema")) is int
        and snapshot["schema"] == 1 and snapshot.get("identity_validated") is True
        and type(snapshot.get("fields")) is dict and set(snapshot["fields"]) == set(expected), "Package snapshot field scope differs")
    def number(value):
        return type(value) in (int, float) and math.isfinite(value) and value >= 0
    start, finish = snapshot.get("capture_started_monotonic"), snapshot.get("capture_finished_monotonic")
    require_trace(number(start) and number(finish) and start <= finish, "Package capture clocks differ")
    complete = True
    for key, row in snapshot["fields"].items():
        path, unit, kind, name = expected[key]
        require_trace(type(row) is dict and row.get("unit") == unit and row.get("kind") == kind
            and number(row.get("read_started_monotonic")) and number(row.get("read_finished_monotonic"))
            and start <= row["read_started_monotonic"] <= row["read_finished_monotonic"] <= finish
            and (("value" in row) != ("error" in row)), "Package row unit/kind/clocks/value-error differs")
        if "error" in row:
            error = row["error"]
            require_trace(type(error) is dict and type(error.get("kind")) is str and 0 < len(error["kind"]) <= 160
                and type(error.get("message")) is str and len(error["message"]) <= 160
                and (error.get("errno") is None or type(error["errno"]) is int), "Package typed read error missing")
            complete = False
        elif kind == "identity":
            require_trace(row["value"] == _PACKAGE_NAMES[name], "Package identity name differs")
        else:
            require_trace(type(row["value"]) is int and 0 <= row["value"] <= 2**63 - 1
                and (name != "enabled" or row["value"] in (0, 1)), "Package bounded integer differs")
    return complete


def frequency_observation(paths, helper, discovery, pinned, package_helper, package_discovery, package_pinned):
    verify_gpu_helper(pinned); verify_package_helper(package_pinned)
    row = observation(paths)
    row["gpu"] = helper.read_gpu_snapshot(discovery)
    validate_gpu_snapshot(discovery, row["gpu"])
    row["package_constraints"] = package_helper.read_package_snapshot(package_discovery)
    validate_package_snapshot(package_discovery, row["package_constraints"])
    verify_gpu_helper(pinned); verify_package_helper(package_pinned)
    return row


def package_coverage(path, discovery):
    rows = complete = 0; errors = {}; ranges = {}; maximum_read_seconds = 0
    descriptor = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        require_trace(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid() and 0 < before.st_size <= 2 * 1024**2,
            "Package host observations exceed2MiB or are unsafe")
        while True:
            line = stream.readline(16385)
            if not line: break
            rows += 1
            require_trace(rows <= 192 and len(line) <= 16384 and line.endswith(b"\n"), "Package observation record bound exceeded")
            record = json.loads(line)
            require_trace(type(record) is dict and "package_constraints" in record, "Package observation missing")
            snapshot = record["package_constraints"]
            complete += validate_package_snapshot(discovery, snapshot)
            maximum_read_seconds = max(maximum_read_seconds, snapshot["capture_finished_monotonic"] - snapshot["capture_started_monotonic"])
            for key, row in snapshot["fields"].items():
                if "error" in row: errors[key] = errors.get(key, 0) + 1
                elif row["kind"] == "integer":
                    item = ranges.setdefault(key, {"unit": row["unit"], "minimum": row["value"], "maximum": row["value"]})
                    item["minimum"] = min(item["minimum"], row["value"]); item["maximum"] = max(item["maximum"], row["value"])
        after = os.fstat(stream.fileno())
        require_trace((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), "Package observations changed during validation")
    require_trace(rows > 0, "No package constraint observations")
    return {"samples": rows, "complete_samples": complete, "complete": complete == rows, "read_errors_by_field": errors,
        "numeric_ranges": ranges, "maximum_observed_snapshot_read_seconds": maximum_read_seconds,
        "sample_interval_seconds": 2, "qualified": False,
        "scope": "Intermittent separate MMIO/MSR constraint settings; no consumption, effective-limit, continuous or causal claim"}


def write_host_observation(stream, row, rows, byte_count):
    encoded = json.dumps(row) + "\n"
    size = len(encoded.encode("utf-8"))
    require_trace(rows + 1 <= 192 and size <= 16384 and byte_count + size <= 2 * 1024**2,
        "Combined host observation bounds exceeded")
    stream.write(encoded)
    stream.flush()
    return rows + 1, byte_count + size


def gpu_coverage(path, discovery):
    rows, actual, errors, maximum_read_seconds = 0, [], {}, 0
    descriptor = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        require_trace(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid()
            and 0 < before.st_size <= 2 * 1024**2, "GPU host observations exceed2MiB or are unsafe")
        while True:
            line = stream.readline(16385)
            if not line:
                break
            rows += 1
            require_trace(rows <= 192 and len(line) <= 16384 and line.endswith(b"\n"),
                "GPU host observation record bound exceeded")
            snapshot = json.loads(line)["gpu"]
            has_actual = validate_gpu_snapshot(discovery, snapshot)
            maximum_read_seconds = max(maximum_read_seconds,
                snapshot["capture_finished_monotonic"] - snapshot["capture_started_monotonic"])
            if has_actual:
                actual.append(snapshot["fields"]["gt_act_freq_mhz"]["value"])
            for name, item in snapshot["fields"].items():
                if "error" in item:
                    errors[name] = errors.get(name, 0) + 1
        after = os.fstat(stream.fileno())
        require_trace((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            "GPU host observations changed during validation")
    require_trace(rows > 0 and actual, "No actual GPU MHz coverage in measured host observations")
    return {"samples": rows, "actual_MHz_samples": len(actual), "actual_MHz_min": min(actual),
        "actual_MHz_max": max(actual), "read_errors_by_field": errors,
        "maximum_observed_snapshot_read_seconds": maximum_read_seconds,
        "sample_interval_seconds": 2, "qualified": False,
        "scope": "Intermittent read-only actual versus requested/current GPU clocks and throttle reasons; no continuous or causal thermal/frequency claim."}

def bounded_json(path, maximum=2 * 1024**2):
    descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        before = os.fstat(descriptor)
        signature = lambda info: [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns]
        require_trace(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid() and before.st_nlink == 1
            and 0 < before.st_size <= maximum, "Unsafe or oversized experiment JSON")
        raw = b""
        while len(raw) < before.st_size:
            data = os.read(descriptor, min(65536, before.st_size - len(raw)))
            require_trace(bool(data), "Experiment JSON truncated")
            raw += data
        require_trace(signature(os.fstat(descriptor)) == signature(before)
            and signature(path.lstat()) == signature(before), "Experiment JSON changed")
        return json.loads(raw), {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                                 "identity": signature(before)}
    finally:
        os.close(descriptor)


def load_plan(path):
    require_trace(path == PLAN, "Only the fixed passive DRM plan is allowed")
    plan, pinned = bounded_json(path)
    require_trace(plan.get("schema") == 1 and plan.get("status") == "frozen_pending_fresh_packed_attention_readiness"
        and plan.get("mode") == MODE and plan.get("consent") is None and plan.get("qualified") is False
        and type(plan.get("native_schema")) is int and plan["native_schema"] == NATIVE_SCHEMA
        and plan.get("native_mode") == NATIVE_MODE
        and plan.get("native_trace_limits") == NATIVE_TRACE_LIMITS
        and all(type(v) is int for v in plan["native_trace_limits"].values())
        and plan.get("window_policy") == "hidden" and plan.get("source_root") == str(SOURCE_ROOT)
        and type(plan.get("source_head")) is str and re.fullmatch(r"[0-9a-f]{40}", plan["source_head"])
        and plan.get("seconds") == 120 and plan.get("operator_seconds") == 960
        and plan.get("pcm_seconds") == 300 and plan.get("phase_seconds") == 480
        and plan.get("interstage_seconds") == 60 and plan.get("strict_service_target_ms") == 4095
        and type(plan.get("review")) is dict and plan["review"].get("status") == "passed"
        and plan.get("cache_policy") == "identical-verified-private-seed-copies-128M",
        "Passive DRM plan is unarmed, incomplete or outside the approved fixed scope")
    assets = plan.get("assets", {})
    require_trace(set(assets) == set(ASSET_PATHS) and all(assets[k].get("path") == str(p) for k,p in ASSET_PATHS.items()),
        "Fixed candidate/player asset paths differ")
    require_trace(assets["runtime"].get("sha256") != FLASH_RUNTIME_SHA256
        and assets["model"].get("sha256") == FLASH_MODEL_SHA256
        and plan.get("reference_runtime_sha256") == FLASH_RUNTIME_SHA256
        and plan.get("cache_helper", {}).get("sha256") == CACHE_HELPER_SHA256
        and plan.get("gpu_helper", {}).get("sha256") == GPU_HELPER_SHA256
        and plan.get("package_helper", {}).get("sha256") == PACKAGE_HELPER_SHA256,
        "Candidate/promoted/model/helper identities differ")
    sources = plan.get("source_pins", {})
    require_trace(all(k in sources and sources[k].get("path") == str(p) for k,p in MANDATORY_SOURCES.items()),
        "Mandatory source/context/build/reference bindings are absent")
    for item in [*assets.values(), *sources.values(), plan["cache_helper"], plan["gpu_helper"], plan["package_helper"],
                 plan.get("seed_proof", {}), plan.get("build_result", {}), plan["review"]]:
        require_trace(type(item) is dict and type(item.get("path")) is str and Path(item["path"]).is_absolute()
            and type(item.get("bytes")) is int and item["bytes"] > 0 and type(item.get("sha256")) is str
            and re.fullmatch(r"[0-9a-f]{64}", item["sha256"]), "Plan byte/hash pin incomplete")
    require_trace(plan["cache_helper"]["path"] == str(CACHE_HELPER)
        and plan["gpu_helper"]["path"] == str(GPU_HELPER) and plan["package_helper"]["path"] == str(PACKAGE_HELPER)
        and plan["seed_proof"]["path"] == str(CANDIDATE_ROOT / "cache-pair/short-live-cache-reused-01/result.json")
        and plan["build_result"]["path"] == str(RUNNER_ROOT / "adapter-build-result.json")
        and sources["pcm_original"]["sha256"] == ORIGINAL_PCM_SHA256
        and sources["reference"]["sha256"] == REFERENCE_SHA256
        and plan.get("drm_device") == {"driver":"i915", "pdev":"0000:00:02.0"},
        "Fixed proof/observer/build/device bindings differ")
    return plan, pinned

def verify_canonical_aliases(plan):
    bindings = plan.get("canonical_alias_bindings", {})
    require_trace(type(bindings) is dict and set(bindings) == set(ALIAS_PATHS),
                  "Exactly the three frozen canonical alias bindings are required")
    for name, (alias, canonical, section, key) in ALIAS_PATHS.items():
        row = bindings[name]
        pinned = plan[section][key]
        require_trace(type(row) is dict and set(row) == {
            "alias_path", "canonical_path", "bytes", "sha256", "alias_identity"}
            and row["alias_path"] == str(alias) and row["canonical_path"] == str(canonical)
            and pinned["path"] == str(canonical) and type(row["bytes"]) is int
            and row["bytes"] > 0 and row["bytes"] == pinned["bytes"]
            and type(row["sha256"]) is str and re.fullmatch(r"[0-9a-f]{64}", row["sha256"])
            and row["sha256"] == pinned["sha256"]
            and type(row["alias_identity"]) is list and len(row["alias_identity"]) == 5
            and all(type(v) is int and v >= 0 for v in row["alias_identity"]),
            "Frozen alias/target/content binding differs: " + name)
        signature = lambda st: [st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns]
        before = alias.lstat()
        require_trace(stat.S_ISLNK(before.st_mode) and signature(before) == row["alias_identity"]
            and alias.resolve(strict=True) == canonical and canonical.resolve(strict=True) == canonical
            and signature(alias.lstat()) == row["alias_identity"],
            "Frozen alias identity or canonical target changed: " + name)


def verify_plan_files(plan, deadline):
    verify_canonical_aliases(plan)
    for row in [*plan["assets"].values(), *plan["source_pins"].values(), plan["cache_helper"], plan["gpu_helper"], plan["package_helper"], plan["seed_proof"], plan["build_result"], plan["review"]]:
        require_trace(time.monotonic() < deadline, "Original plan-pin budget exhausted")
        path = Path(row["path"])
        require_trace(path.resolve(strict=True) == path, "Frozen read pin is not canonical")
        descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_CLOEXEC | os.O_NOFOLLOW)
        try:
            before = os.fstat(descriptor)
            require_trace(stat.S_ISREG(before.st_mode) and before.st_size == row["bytes"]
                and 0 < before.st_size <= 1024**3, "Frozen plan file size/type differs")
            digest, count = hashlib.sha256(), 0
            while count < before.st_size:
                require_trace(time.monotonic() < deadline, "Original plan-pin budget exhausted")
                data = os.read(descriptor, min(1024**2, before.st_size - count))
                require_trace(bool(data), "Frozen plan file truncated")
                digest.update(data); count += len(data)
            signature = lambda st: (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
            require_trace(signature(before) == signature(os.fstat(descriptor)) == signature(path.lstat())
                and digest.hexdigest() == row["sha256"], "Frozen plan content changed")
        finally:
            os.close(descriptor)
    verify_canonical_aliases(plan)
    require_trace(time.monotonic() < deadline, "Original plan-pin budget exhausted")


def readiness(path, plan_pin):
    require_trace(path == HUMAN, "One original combined readiness record is required")
    value, pinned = bounded_json(path, 16384)
    issued = datetime.fromisoformat(value.get("recorded_at_utc", ""))
    sampled_monotonic = time.monotonic()
    age = (datetime.now(timezone.utc) - issued).total_seconds() if issued.tzinfo else -1
    require_trace(value.get("schema") == 1 and value.get("decision") == "ready"
        and value.get("ready_for_diagnostic") == MODE and value.get("diagnostic_mode") == MODE
        and value.get("stages") == ["pcm16", "player120"] and value.get("ui_mode") == "background"
        and value.get("window_policy") == "hidden" and type(value.get("maximum_operator_seconds")) is int
        and value["maximum_operator_seconds"] == 960 and value.get("plan_sha256") == plan_pin["sha256"]
        and 0 <= age < 960 and all(value.get(k) is True for k in
            ("AC_power","lid_open","Codex_minimized","other_work_paused","controls_untouched","no_suspend"))
        and all(type(value.get(k)) is str and 0 < len(value[k]) <= 8192
            for k in ("question_item_id","human_question","human_reply")),
        "Original combined approval/UTC/conditions/plan required; no standalone record relabeling")
    return {"record":value,"pin":pinned,"age_seconds":age,"maximum_age_seconds":960,
            "sampled_monotonic":sampled_monotonic}

def operator_budget(ready, now_monotonic, phase_started, phase="player"):
    age = ready["age_seconds"]
    require_trace(type(age) in (int,float) and math.isfinite(age) and 0 <= age < 960, "Invalid original approval age")
    sampled = ready["sampled_monotonic"]
    require_trace(type(sampled) in (int,float) and math.isfinite(sampled) and 0 <= sampled <= now_monotonic,
        "Original approval clock anchor differs")
    operator_deadline = sampled + 960 - age
    remaining = operator_deadline - now_monotonic
    require_trace(phase in ("pcm","player") and remaining >= (840 if phase == "pcm" else 480),
        "Insufficient original combined window; do not launch another stage")
    maximum = 300 if phase == "pcm" else 480
    permitted = min(maximum, remaining)
    return {"age_seconds":age,"approval_sample_monotonic":sampled,"remaining_operator_seconds":remaining,"permitted_seconds":permitted,
        "phase":phase,"phase_deadline_monotonic":min(phase_started+maximum,operator_deadline),
        "operator_deadline_monotonic":operator_deadline,
        "external_INT_after_seconds":permitted-30,"external_kill_grace_seconds":30,
        "scope":"One original960s humanUTC; PCM300 then player480, no renewed approval/deadline"}


def boot_identity():
    with Path("/proc/sys/kernel/random/boot_id").open("rb") as stream:
        raw = stream.read(65)
    require_trace(len(raw) <= 64, "Boot identity exceeds fixed bound")
    value = raw.decode("ascii").strip()
    require_trace(re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",value),
        "Boot identity unavailable")
    return value


def retain_original_budget(budget, pcm_gate, now):
    deadline = min(budget["operator_deadline_monotonic"],pcm_gate["original_operator_deadline_monotonic"])
    require_trace(deadline-now >= 480, "Original PCM-established operator window cannot fit player phase")
    return {**budget,"operator_deadline_monotonic":deadline,
        "phase_deadline_monotonic":min(budget["phase_deadline_monotonic"],deadline),
        "remaining_operator_seconds":deadline-now,"permitted_seconds":min(480,deadline-now),
        "external_INT_after_seconds":min(480,deadline-now)-30,
        "original_pcm_operator_deadline_monotonic":pcm_gate["original_operator_deadline_monotonic"]}

def phase_readiness(args):
    ready = readiness(args.readiness_decision, args.plan_pin)
    require_trace(ready["pin"] == args.human_pin and time.monotonic() < args.operator_deadline,
        "Original human approval changed or standalone deadline expired")
    return ready


def logger_environment(inherited):
    require_trace(not any(key.startswith(("GGML_VK_", "GGML_VULKAN_")) or key.startswith("CONFLUX_REQUEST_TRACE_")
        or key == "CONFLUX_REQUEST_INTERVAL_SECONDS" or key.startswith("CONFLUX_DRM_")
        or key in ("MESA_GPU_TRACES","MESA_GPU_TRACEFILE","INTEL_DEBUG") for key in inherited), "Inherited logger/trace/cadence controls forbidden")
    environment = dict(inherited)
    environment["QT_QUICK_BACKEND"] = "software"
    return environment


def logger_contract(args):
    require_trace(args.output == OUTPUT and args.seconds == 120 and args.live_stems
        and not args.live_stems_hour and args.background
        and args.service == RUNNER_ROOT / "service_drm.py" and args.worker == SOURCE_ROOT / "tools/stems/worker.py"
        and not os.environ.get("CONFLUX_PRIVATE_ROUTING_CHECK") and os.environ.get("QT_QPA_PLATFORM") not in ("offscreen", "minimal"),
        "Only the fixed normal120s standalone hidden logger-OFF diagnostic is allowed")
    logger_environment(os.environ)


def verify_cache_helper(pinned):
    info = CACHE_HELPER.lstat()
    require_trace(stat.S_ISREG(info.st_mode) and [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns] == pinned["identity"],
        "Fixed logger cache helper changed")


def load_cache_support():
    value = pin(CACHE_HELPER)
    require_trace(value["sha256"] == CACHE_HELPER_SHA256, "Frozen cache helper hash differs")
    info = CACHE_HELPER.lstat()
    value["identity"] = [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns]
    verify_cache_helper(value)
    spec = importlib.util.spec_from_file_location("conflux_logger_seed_cache", CACHE_HELPER)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    verify_cache_helper(value)
    return helper, value


def validate_hidden_native(native):
    require_trace(type(native) is dict and native.get("ui_mode") == "background"
        and native.get("window_policy") == "hidden" and type(native.get("frames_presented")) is int
        and native["frames_presented"] == 0, "Controlled hidden native policy or frame count differs")
    coverage, history = native.get("ui_coverage", {}), native.get("window_events", {})
    checks = coverage.get("checks")
    require_trace(type(checks) is int and checks > 0 and coverage.get("window_policy") == "hidden"
        and coverage.get("hidden_policy_violated") is False and coverage.get("visible_ui_qualification_eligible") is False
        and all(type(coverage.get(key)) is int and coverage[key] == checks
            for key in ("hidden_checks", "unexposed_checks", "missing_frame_checks"))
        and all(type(coverage.get(key)) is int and coverage[key] == 0
            for key in ("missing_window_checks", "visible_healthy_checks")),
        "Controlled hidden window was visible, exposed, missing, framed or violated its latched policy")
    metadata = history.get("metadata", {})
    require_trace(metadata.get("functional_ui_bypass") is False and metadata.get("hidden_activity_latched") is True
        and all(type(metadata.get(key)) is int and metadata[key] == 0
            for key in ("startup_minimum_frames", "startup_wait_ms")), "Strict hidden startup/activity metadata differs")
    events, attempted, retained = history.get("events"), history.get("attempted"), history.get("retained")
    dropped = history.get("dropped")
    require_trace(type(events) is list and type(attempted) is int and type(retained) is int
        and type(history.get("capacity")) is int and history["capacity"] == 64
        and type(dropped) is int and dropped >= 0 and attempted > 0
        and retained == len(events) == min(attempted, 64) and attempted == retained + dropped
        and history.get("frozen_before_cleanup") is True,
        "Hidden window activity ring is missing or its bounded accounting differs")
    identity = None
    for index, event in enumerate(events):
        require_trace(type(event) is dict and type(event.get("ordinal")) is int and event["ordinal"] == dropped + index + 1,
            "Hidden window activity order differs")
        if event.get("exists") is True and identity is None:
            identity = event.get("window_object_identity")
            require_trace(type(identity) is str and 0 < len(identity) <= 128, "Hidden window identity missing")
        if identity is None:
            require_trace(dropped == 0 and event.get("exists") is False
                and event.get("visible") is False and event.get("exposed") is False
                and type(event.get("frames_presented")) is int and event["frames_presented"] == 0
                and "window_object_identity" in event and event["window_object_identity"] is None
                and event.get("phase") == "validating" and event.get("source") == "snapshot:progress",
                "Hidden window pre-attachment prefix is malformed or its startup provenance was overwritten")
        if identity is not None:
            require_trace(event.get("exists") is True and event.get("visible") is False and event.get("exposed") is False
                and event.get("window_object_identity") == identity and type(event.get("frames_presented")) is int
                and event["frames_presented"] == 0, "Hidden window activity changed after attachment")
    require_trace(identity is not None, "Hidden window was never observed attached")
    return native


def finalize_logger_result(result, args, deadline):
    result.pop("comparison_eligible", None)
    result.update(diagnostic_mode=MODE, window_policy="hidden", plan_pin=args.plan_pin,
        operator_budget=args.operator_budget, shader_cache=args.cache_preparation,
        preflight=args.preflight,
        gpu_query_trace_available=False, gpu_query_trace_scope="Logger controls absent; no GPU query trace or top32 profile in this standalone OFF diagnostic",
        qualified=False, timing_qualification=False)
    try:
        require_trace(result.get("cleanup_proven") is True and time.monotonic() < deadline,
            "Cache post-inventory requires proven cleanup within original deadline")
        verify_cache_helper(args.cache_helper_pin)
        prepared = args.cache_preparation
        result["shader_cache"]["post"] = args.cache_helper.inventory(Path(prepared["cache_path"]), prepared["parent"], deadline, prepared["cache_identity"])
        verify_cache_helper(args.cache_helper_pin)
        require_trace(time.monotonic() < deadline, "Original post-cache inventory budget exhausted")
        result["cache_inventory_complete"] = True
    except Exception as error:
        result["cache_inventory_complete"] = False; result["cache_inventory_error"] = str(error); result["passed"] = False
    try:
        args.cache_lock.close()
        result["shader_cache"]["lock_released"] = True
    except Exception as error:
        result["shader_cache"]["lock_release_error"] = str(error); result["passed"] = False
    try:
        validate_hidden_native(result.get("native", {}))
        result["hidden_policy_validated"] = True
    except Exception as error:
        result["hidden_policy_validated"] = False
        result["hidden_policy_error"] = str(error)
        result["passed"] = False
    phases = result.get("observations", {}).get("chunk_phases", {}).get("fields", {})
    complete_phases = all(phases.get(name, {}).get("present_for_all_chunks") is True for name in LIVE_PHASE_NAMES)
    native = result.get("native", {})
    native_functional = (native.get("passed") is True and native.get("error") == ""
        and type(native.get("steady_starved_frames")) is int and native["steady_starved_frames"] == 0)
    result["functional_passed"] = bool(result.get("passed") and native_functional and complete_phases
        and result.get("package_coverage", {}).get("complete") is True)
    hops = result.get("observations", {}).get("service_hops", {})
    p99 = hops.get("nearest_rank_p99_ms")
    result["service_target_met"] = bool(hops.get("complete") is True and type(p99) in (int, float)
        and math.isfinite(p99) and p99 < 4095)
    result["passed"] = bool(result["functional_passed"] and result["service_target_met"])
    result["scope"] = "Short passive DRM accounting diagnostic; all first/seek/replay/observer costs and failures retained; no idle/current-request execution classifier, timing, visible-UI or hard-cancel qualification"


def cool_start(deadline):
    rows = []
    while time.monotonic() < deadline:
        paths = sensor_paths(); row = observation(paths)
        row["power"] = power_state()
        row["profile"] = read_command(["powerprofilesctl", "get"], timeout=max(.1, min(3, deadline - time.monotonic())))
        rows.append(row)
        values = list(row["temperatures_millidegrees_C"].values())
        require_trace(row["power"]["ac_online"] and row["power"]["lid_open"], "AC/open lid required throughout natural cooldown")
        if values and 0 < max(values) <= 70000 and row["profile"] == "balanced":
            require_trace(time.monotonic() < deadline, "Original cooldown deadline exhausted")
            return rows
        time.sleep(min(2, max(0, deadline - time.monotonic())))
    raise RuntimeError("Natural balanced/cool start not reached within original180s")


LIVE_PHASE_NAMES = ("source_read_ms", "request_ms", "overlap_ms", "native_elapsed_ms", "native_inference_wall_ms",
                    "native_inference_cpu_ms", "native_frontend_ms", "native_graph_ms", "native_graph_upload_ms",
                    "native_graph_compute_ms", "native_graph_readback_ms", "native_postprocess_ms", "native_graph_rebuild_ms")


def live_evidence_limits(hour):
    return (65536, 64 * 1024**2) if hour else (16384, 32 * 1024**2)


def live_required_free_bytes(seconds, hour):
    return 3 * 1024**3 + (seconds + 120) * 384000 + 40 * 1024**2 + (64 * 1024**2 if hour else 0) + 4 * 1024**2 + 1048576


def duration_stats(values):
    ordered = sorted(values)
    return {"count": len(values), "maximum_ms": ordered[-1] if ordered else None,
            "nearest_rank_p99_ms": ordered[math.ceil(.99 * len(ordered)) - 1] if ordered else None}


def validate_hour_result(native, observations, background=False):
    """Check bounded native hour evidence before the wrapper's cleanup gate."""
    def check(condition, description):
        if not condition:
            raise RuntimeError("Hour qualification: " + description)
    check(native.get("mode") == "live-stems-hour" and native.get("requested_seconds") == 3600
          and native.get("passed") is True and native.get("cancelled") is False
          and native.get("functional_only") is False and native.get("host_audio") is True
          and native.get("shutdown_completed") is True, "incomplete/non-host hour")
    check(native.get("ui_mode", "visible") == ("background" if background else "visible"), "UI mode differs from launched mode")
    coverage = native.get("ui_coverage", {})
    if background:
        check(isinstance(coverage, dict) and coverage.get("visible_ui_qualification_eligible") is False,
              "background evidence cannot qualify visible UI")
        checks = coverage.get("checks")
        counts = ("visible_healthy_checks", "missing_window_checks", "hidden_checks", "unexposed_checks",
                  "stale_frame_checks", "missing_frame_checks")
        check(type(checks) is int and 0 < checks <= 4000000 and
              all(type(coverage.get(key)) is int and 0 <= coverage[key] <= checks for key in counts) and
              coverage["missing_window_checks"] == 0 and type(coverage.get("any_gap")) is bool and
              type(coverage.get("maximum_frame_age_ns")) is int and coverage["maximum_frame_age_ns"] >= 0,
              "background UI observation counts invalid")
    else:
        check(isinstance(coverage, dict) and coverage.get("visible_ui_qualification_eligible", True) is True,
              "background UI evidence cannot enter visible qualification")
    check(native["setup"]["input_frames"] == 1031940 and native["setup"]["output_frames"] == 1123201
          and native["peer"]["frames"] == 480 * 48000,
          "changed source/peer geometry")
    check(native["measurement_intervals_closed"] and native["last_recovery_complete"], "open measurement/control")
    begin, end = native["measurement_begin_output_frame"], native["measurement_end_output_frame"]
    wall = native["measured_wall_ms"] / 1000
    check(3600 <= wall <= 3602 and abs((end - begin) / 48000 - wall) <= max(.25, wall * .002),
          "wall/output duration agreement failed")
    check(native["callbacks"] > 0 and not native["scene_errors"]
          and 0 < native["maximum_gui_heartbeat_gap_ns"] < 2000000000, "audio/control loop not responsive")
    if not background:
        check(native["frames_presented"] >= 10
              and 0 < native["maximum_frame_presentation_gap_ns"] < 2000000000, "visible UI not responsive")
    check(all(native[key] == 0 for key in ("invalid_buffers", "source_read_failures", "rejected_commands", "execution_deadline_misses")),
          "audio callback/source/command fault")
    check(bool(native["timing"]) and all(row["callbacks"] > 0 and row["driver_position_observed"]
          and not row["driver_position_discontinuities"] and not row["driver_recovery_flags"]
          and row["graph_quantum_min"] == row["graph_quantum_max"] == 256 for row in native["timing"]),
          "driver continuity/quantum failed")
    samples = native["samples"]
    check(2 <= len(samples) <= 362 and samples[0]["elapsed_ms"] < 2000
          and samples[-1]["elapsed_ms"] >= 3590000
          and all(not row["snapshot_drops"] for row in samples)
          and all(10000 <= b["elapsed_ms"] - a["elapsed_ms"] < 12000 for a, b in zip(samples, samples[1:])),
          "bounded ten-second snapshots incomplete")
    controls, peers, intervals = native["controls"], native["peer_controls"], native["intervals"]
    check(len(controls) <= 512 and len(peers) == 8 and 0 < len(intervals) <= 2048, "control/interval capacity")
    anchor, cursor = begin, native["measurement_begin_peer_frame"]
    check(0 <= cursor < 420 * 48000, "peer already due before measurement")
    for control in peers:
        first, last = control["output_begin"], control["output_end"]
        check(control["kind"] == "peer_rewind" and control["target_frame"] == 0
              and anchor <= first <= control["ack_output_frame"] <= last <= end
              and control["source_before"] == cursor + first - anchor
              and 420 * 48000 <= control["source_before"] < 422 * 48000
              and 0 <= control["ack_source_frame"] <= control["source_after"] < 4 * 48000
              and control["settled_ns"] - control["issued_ns"] >= 2000000000,
              "peer rewind cursor/acknowledgement/two-second settle differs")
        anchor, cursor = last, control["source_after"]
    check(cursor + end - anchor < 420 * 48000, "due peer rewind omitted")
    for control in controls:
        check(begin <= control["output_begin"] <= control["output_end"] <= end, "A control outside measurement")
    boundary = begin; steady = [0, 0]; controlled = [0, 0]
    endpoints = {begin, end}
    for row in intervals:
        first, last = row["output_begin"], row["output_end"]
        check(first == boundary and first <= last <= end and row["frames"] == last - first
              and not row["aborted"] and not row["read_failure_observed"], "interval partition/health failed")
        endpoints.add(last); boundary = last
        check(row["starved_frames"] == row["starved_a"] + row["starved_b"], "per-deck starvation sum differs")
        for deck, (key, events) in enumerate((("a_recovery", controls), ("b_recovery", peers))):
            active = any(c["output_begin"] <= first and last <= c["output_end"] for c in events)
            check(isinstance(row[key], bool) and (first == last or row[key] == active), "control mask differs from boundaries")
            value = row["starved_a" if deck == 0 else "starved_b"]
            check(type(value) is int and value >= 0 and (first != last or value == 0), "invalid starvation count")
            (controlled if row[key] else steady)[deck] += value
        if not row["b_recovery"]:
            check(row["source_b_end"] - row["source_b_begin"] == last - first, "steady peer lost source/output alignment")
    check(boundary == end and all(c[key] in endpoints for c in controls + peers for key in ("output_begin", "output_end")),
          "control edge missing from interval partition")
    check(steady == [native["steady_starved_a"], native["steady_starved_b"]] == [0, 0]
          and native["steady_starved_frames"] == sum(steady) and native["control_starved_frames"] == sum(controlled),
          "deck-specific steady starvation observed")
    hops = observations["service_hops"]; phases = observations["chunk_phases"]["fields"]
    check(observations["service_metrics_complete"] and hops["complete"]
          and hops["count"] == observations["kind_counts"]["ChunkValidated"] > 0
          and hops["nearest_rank_p99_ms"] < 4095, "service hop p99/loss gate failed")
    check(set(phases) == set(LIVE_PHASE_NAMES) and all(row["present_for_all_chunks"] and row["count"] == hops["count"] for row in phases.values()),
          "all thirteen phases required on every validated chunk")
    return {"peer_rewinds": len(peers), "service_hops": hops["count"],
            "service_hops_at_or_above_target": hops["at_or_above_target"],
            "strict_service_p99_target_ms": 4095, "steady_starved_a": steady[0], "steady_starved_b": steady[1],
            "visible_ui_qualification_eligible": not background,
            "scope": "background audio/stem hour; visible UI not qualified" if background else "visible audio/UI hour"}


def live_qualified(result, hour, background=False):
    """Keep background diagnostics outside visible audio/UI hour qualification."""
    gates, native = result.get("hour_gates"), result.get("native", {})
    return bool(hour and not background and result.get("passed") is True and result.get("cleanup_proven") is True
                and result.get("ui_mode", "visible") == "visible" and isinstance(native, dict)
                and native.get("ui_mode", "visible") == "visible" and isinstance(gates, dict) and gates
                and gates.get("visible_ui_qualification_eligible", True) is True)


def summarize_live_observations(path, native):
    # The writer has already bounded lines/bytes. Enforce the same bounds when
    # reopening evidence; this parser never reads a media or slot file.
    line_limit, byte_limit = live_evidence_limits(native.get("mode") == "live-stems-hour")
    if path.stat().st_size > byte_limit:
        raise RuntimeError("Observation file exceeds its bound")
    rows = []
    with path.open("rb") as stream:
        for _ in range(line_limit + 1):
            line = stream.readline(4097)
            if not line:
                break
            if len(line) > 4096 or not line.endswith(b"\n"):
                raise RuntimeError("Malformed or oversized observation line")
            rows.append(json.loads(line))
        else:
            raise RuntimeError("Observation record limit exceeded")
    if not rows or rows[0].get("type") != "setup" or rows[0].get("context") != native["setup"]:
        raise RuntimeError("Observation setup differs from final native context")
    records = rows[1:]
    counters = native["observation_counters"]
    if not (counters["producer_finished"] and not counters["dropped"] and not counters["invalid_clock_reads"]
            and counters["retained"] == counters["attempted"] == len(records)):
        raise RuntimeError("Observation evidence is incomplete")
    names = ("ServiceReady", "RuntimeReady", "RequestObserved", "CommandQueued", "CommandAccepted", "ChunkValidated",
             "PacketAccepted", "PacketDiscarded", "RawComplete", "ConverterComplete", "ServiceClosed")
    counts = dict.fromkeys(names, 0)
    hops, ready_to_pre_emit, validation, publication, full_waits = [], [], [], [], []
    phase_names = LIVE_PHASE_NAMES
    phases = {key: [] for key in phase_names}
    phase_hops = []
    current_epoch, previous_ordinal = 0, None
    epochs, commands, accepted_at, completed_at, telemetry = {}, {}, {}, {}, []
    last_sequence = last_generation = 0; last_accepted_epoch = 0
    total_input, total_output = native["setup"]["input_frames"], native["setup"]["output_frames"]
    for row in records:
        ordinal = row["ordinal"]
        if previous_ordinal is not None and ordinal != previous_ordinal + 1:
            raise RuntimeError("Observation ordinal gap without reported loss")
        previous_ordinal = ordinal
        if not 0 <= row["kind"] < len(names) or row["observed_ns"] <= 0:
            raise RuntimeError("Observation kind/clock is invalid")
        kind = names[row["kind"]]; counts[kind] += 1
        if kind == "RequestObserved":
            current_epoch = row["epoch"]
            if not current_epoch or current_epoch in epochs:
                raise RuntimeError("Repeated or empty provider request epoch")
            epochs[current_epoch] = {"target": row["output_first"], "next": row["output_first"], "generation": None,
                                     "observed_ns": row["observed_ns"], "reserve_published_ns": None, "final": False}
        elif kind == "CommandQueued":
            if row["command_id"] in commands or row["epoch"] not in epochs:
                raise RuntimeError("Unbound or duplicate queued load/seek")
            commands[row["command_id"]] = row
        elif kind == "CommandAccepted":
            queued = commands[row["command_id"]]
            if (row["epoch"], row["input_first"], row["output_first"]) != (queued["epoch"], queued["input_first"], queued["output_first"]) or row["observed_ns"] < queued["observed_ns"]:
                raise RuntimeError("Accepted load/seek lost its exact queued binding")
            if row["generation"] != last_generation + 1:
                raise RuntimeError("Accepted generation did not advance exactly once")
            last_generation = row["generation"]; last_accepted_epoch = row["epoch"]
            epochs[row["epoch"]].update(generation=row["generation"], validated_end=row["input_first"], validated_contiguous=True, raw_service_endpoint=None, command_ns=queued["observed_ns"],
                                        first_validated_ns=None)
            accepted_at[row["generation"]] = row["observed_ns"]
        elif kind == "ChunkValidated":
            epoch = epochs[row["epoch"]]
            end = row["input_first"] + row["input_frames"]
            if (row["generation"] != epoch["generation"] or row["input_first"] < epoch["validated_end"]
                    or row["input_frames"] != min(257985 - row["input_first"] % 257985, total_input - row["input_first"])
                    or not 0 < row["input_frames"] <= 257985 or end > total_input or row["final"] != (end == total_input)
                    or row["lease_sequence"] <= last_sequence):
                raise RuntimeError("Raw lease lost accepted epoch/generation/contiguity/sequence")
            epoch["validated_contiguous"] = epoch["validated_contiguous"] and row["input_first"] == epoch["validated_end"]
            epoch["validated_end"] = end; last_sequence = row["lease_sequence"]
            if epoch["first_validated_ns"] is None:
                epoch["first_validated_ns"] = row["validated_ns"]
            if row["validated_ns"] < row["observed_ns"] or not row["request_id"]:
                raise RuntimeError("Validated lease lost identity/clock binding")
            validation.append((row["validated_ns"] - row["observed_ns"]) / 1e6)
            delay = (row["service_published_seconds"] - row["worker_ready_seconds"]) * 1000
            if not math.isfinite(delay) or delay < 0:
                raise RuntimeError("Python-domain ready-to-pre-emit interval is invalid")
            ready_to_pre_emit.append(delay)
            if row["hop_service_present"]:
                if not math.isfinite(row["hop_service_ms"]) or row["hop_service_ms"] < 0:
                    raise RuntimeError("Invalid optional hop service interval")
                hops.append(row["hop_service_ms"])
            phase_row = {key: row[key] for key in ("epoch", "generation", "request_id", "lease_sequence", "input_first", "input_frames")}
            if row["hop_service_present"]:
                phase_row["hop_service_ms"] = row["hop_service_ms"]
            for key in phase_names:
                if key in row:
                    value = row[key]
                    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                        raise RuntimeError("Invalid optional phase timing")
                    phases[key].append(value)
                    phase_row[key] = value
            phase_hops.append(phase_row)
        elif kind == "PacketAccepted":
            epoch = epochs[row["epoch"]]
            end = row["output_first"] + row["output_frames"]
            if (row["epoch"] != current_epoch or row["generation"] != epoch["generation"] or epoch["final"]
                    or row["output_first"] != epoch["next"] or not 0 < row["output_frames"] <= 4096
                    or (not row["final"] and row["output_frames"] != 4096) or end > total_output
                    or (row["final"] and (end != total_output or not epoch.get("converter_complete")))
                    or not 0 < row["packet_ready_ns"] <= row["publish_begin_ns"] <= row["publish_end_ns"]):
                raise RuntimeError("Accepted packet range/generation/chronology differs")
            epoch["next"], epoch["final"] = end, row["final"]
            publication.append((row["publish_end_ns"] - row["packet_ready_ns"]) / 1e6)
            if row["full_observed"]:
                if not row["packet_ready_ns"] <= row["first_full_ns"] <= row["publish_begin_ns"]:
                    raise RuntimeError("Full wait lies outside packet/publication interval")
                full_waits.append((row["publish_end_ns"] - row["first_full_ns"]) / 1e6)
            if epoch["reserve_published_ns"] is None and end >= min(total_output, epoch["target"] + 262144):
                epoch["reserve_published_ns"] = row["publish_end_ns"]
        elif kind == "PacketDiscarded":
            epoch = epochs[row["epoch"]]
            if row["generation"] != epoch["generation"] or row["output_first"] != epoch["next"] or not 0 < row["output_frames"] <= 4096:
                raise RuntimeError("Observed pending discard lost its old range/generation")
        elif kind == "RawComplete":
            if row["epoch"] not in epochs or row["generation"] != epochs[row["epoch"]]["generation"] or row["input_first"] != total_input or row["input_frames"]:
                raise RuntimeError("Raw completion endpoint differs")
            completed_at[row["generation"]] = row["observed_ns"]
            epochs[row["epoch"]]["raw_service_endpoint"] = total_input
        elif kind == "ConverterComplete":
            if (row["epoch"] not in epochs or row["generation"] != epochs[row["epoch"]]["generation"] or row["input_first"] != total_input or
                    row["output_first"] != total_output or row["input_frames"] or row["output_frames"] or
                    completed_at.get(row["generation"], math.inf) > row["observed_ns"] or
                    not epochs[row["epoch"]]["validated_contiguous"] or epochs[row["epoch"]]["validated_end"] != total_input):
                raise RuntimeError("Converter completion endpoint/binding differs")
            epochs[row["epoch"]]["converter_complete"] = True
        elif kind == "ServiceClosed":
            if (row["epoch"] != last_accepted_epoch or row["generation"] != last_generation or
                    not epochs[last_accepted_epoch]["validated_end"] <= row["input_first"] <= total_input):
                raise RuntimeError("Closed raw endpoint/binding differs")
            epochs[last_accepted_epoch]["raw_service_endpoint"] = row["input_first"]
        if row["telemetry_dropped_present"]:
            telemetry.append({"kind": kind, "generation": row["generation"], "dropped": row["telemetry_dropped"]})
    stats = duration_stats
    seek = next((row for row in native["controls"] if row["kind"] == "incomplete_generation_seek"), None)
    seek_observed = bool(seek and accepted_at.get(seek["previous_generation"], math.inf) <= seek["issued_ns"]
        and completed_at.get(seek["previous_generation"], math.inf) > seek["issued_ns"])
    for epoch in epochs.values():
        if epoch.get("first_validated_ns") is not None:
            epoch["command_to_first_validated_ms"] = (epoch["first_validated_ns"] - epoch["command_ns"]) / 1e6
        if epoch.get("reserve_published_ns") is not None:
            epoch["command_to_published_reserve_ms"] = (epoch["reserve_published_ns"] - epoch["command_ns"]) / 1e6
    setup = native["setup"]
    return {"service_telemetry_loss": telemetry, "service_metrics_complete": not any(row["dropped"] for row in telemetry),
            "factory_spans_ms": {"entry_to_capture": (setup["input_captured_ns"] - setup["factory_entry_ns"]) / 1e6,
                "capture_to_count": (setup["count_complete_ns"] - setup["input_captured_ns"]) / 1e6,
                "count_to_commit": (setup["factory_committed_ns"] - setup["count_complete_ns"]) / 1e6},
            "load_to_first_cursor_poll_upper_ms": (native["first_advance_observed_ns"] - native["load_issued_ns"]) / 1e6,
            "incomplete_generation_seek": {"submitted": seek is not None, "exercised": seek_observed,
                "scope": "Retrospective accepted/RawComplete C++ stamps at seek issue; no native inference-start claim"},
            "scope": ("Sustained repeated-generation actual-player observations; qualification remains gated by native health and wrapper cleanup; no physical/consumed timing qualification"
                      if native.get("mode") == "live-stems-hour" else
                      "Short repeated-generation diagnostics; no sustained p99 or physical/consumed timing qualification"),
            "kind_counts": counts, "epochs": epochs, "service_hops": {**stats(hops), "strict_target_ms": 4095,
                "at_or_above_target": sum(value >= 4095 for value in hops), "complete": len(hops) == counts["ChunkValidated"] > 0 and not any(row["dropped"] for row in telemetry)}, "lease_validation": stats(validation),
            "worker_ready_to_service_pre_emit": {**stats(ready_to_pre_emit),
                "scope": "Python monotonic domain only; excludes JSON serialization/write, pipe delivery and C++ receipt"},
            "chunk_phases": {"scope": "Original nested durations in ms for validated chunks only; omissions remain absent. Preroll, canceled and discarded work is not fully covered. No cross-clock subtraction or additive phase interpretation.",
                "hops": phase_hops, "fields": {key: {**stats(values), "present_for_all_chunks": len(values) == counts["ChunkValidated"] > 0}
                                                 for key, values in phases.items()}},
            "packet_ready_to_publish": stats(publication), "actual_full_waits": stats(full_waits),
            "discard_coverage": "Observed discards validated; nonempty discard is not forced", "file": pin(path)}


def run_live(args):
    import selectors
    logger_contract(args)
    hour = args.live_stems_hour
    background = args.background
    binary = args.binary.resolve(strict=True)
    source, peer = args.track_a.resolve(strict=True), args.track_b.resolve(strict=True)
    assets = {name: getattr(args, name).absolute() for name in ("python", "exporter", "worker", "service", "runtime", "model")}
    for path in assets.values():
        if not path.is_absolute() or not path.resolve(strict=True).is_file():
            raise RuntimeError("Live tools must be explicit regular executable/source/model paths")
    output = args.output.absolute(); output.mkdir(mode=0o700, parents=False, exist_ok=False)
    cache = output / "cache"; cache.mkdir(mode=0o700); stop = output / "stop"
    result = {"schema": 2, "passed": False, "qualified": False, "mode": "live-stems-hour" if hour else "live-stems", "requested_seconds": args.seconds,
              "ui_mode": "background" if background else "visible", "window_policy": "hidden", "visible_ui_required": not background,
              "started_at_utc": datetime.now(timezone.utc).isoformat(), "scope": "Explicit short native actual-model controller playback; no endurance, fallback or physical latency qualification"}
    if hour:
        result["scope"] = "Sustained actual-player qualification only for the recorded two-deck, one-separator fixed mix; other M2 requirements remain open"
        result["qualified_scope"] = "Exact pinned source/model/runtime, Vulkan two threads, Best conversion, 48kHz/256 stereo, A stems/B finite peer, fixed gains, visible Main.qml, float WAV; no hardware cue, EQ/effects, four-deck, fallback, musical-quality or physical latency qualification"
    if background:
        result["scope"] = "Background actual-player audio/stem diagnostics with observed UI coverage; no visible UI or full audio/UI qualification"
        result.pop("qualified_scope", None)
    child = None; root_identity = None; owned = {}; observed_groups = set(); known_graph = set(); requested_stop = None; stop_at = None
    previous = {}; began = time.monotonic(); deadline = min(began + args.seconds + 180, args.phase_deadline, args.operator_deadline)
    selector = selectors.DefaultSelector(); captures = {}; complete_capture = True
    ownership_complete = True
    command_history = {}; ownership_failures = []; ownership_failure_count = 0; ownership_failure_overflow = False
    def live_pin(path, maximum=1024 * 1024 * 1024):
        canonical = path.resolve(strict=True)
        descriptor = os.open(canonical, os.O_RDONLY | os.O_NONBLOCK | os.O_CLOEXEC | os.O_NOFOLLOW)
        try:
            before = os.fstat(descriptor)
            identity = lambda st: (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
            if not stat.S_ISREG(before.st_mode) or not 0 < before.st_size <= maximum:
                raise RuntimeError("Live pin must be a bounded nonempty regular file")
            digest = hashlib.sha256(); count = 0
            while count < before.st_size:
                if time.monotonic() >= deadline - 15:
                    raise RuntimeError("Live setup pin exhausted wall budget")
                data = os.read(descriptor, min(1024 * 1024, before.st_size - count))
                if not data:
                    raise RuntimeError("Live pin changed/truncated")
                digest.update(data); count += len(data)
            if identity(os.fstat(descriptor)) != identity(before) or path.resolve(strict=True) != canonical or identity(canonical.stat()) != identity(before):
                raise RuntimeError("Live pin identity changed")
            return {"path": str(path), "canonical_path": str(canonical), "bytes": count, "sha256": digest.hexdigest(),
                    "identity": list(identity(before))}
        finally:
            os.close(descriptor)
    def live_guard():
        raw = read_command(["systemctl", "--user", "show", "thermal-guard.service",
            "--property=ActiveState,MainPID,InvocationID,ExecMainStartTimestampMonotonic"], timeout=max(.1, min(3, deadline - time.monotonic() - 10)))
        fields = dict(line.split("=", 1) for line in raw.splitlines() if "=" in line)
        if fields.get("ActiveState") != "active" or int(fields.get("MainPID", 0)) <= 0:
            raise RuntimeError("Existing thermal guard must stay active")
        identity = process_identity(int(fields["MainPID"]))
        if str(args.guard_script.resolve(strict=True)) not in identity["command"]:
            raise RuntimeError("Active guard command differs")
        return {"service": fields, "process": identity, "script": live_pin(args.guard_script.resolve(), 1024 * 1024),
                "unit": live_pin(args.guard_unit.resolve(), 1024 * 1024)}
    def process_record(pid):
        root = Path("/proc") / str(pid)
        if root.stat().st_uid != os.getuid():
            raise RuntimeError("Owned process UID differs")
        fields = (root / "stat").read_text().rsplit(")", 1)[1].split()
        command = (root / "cmdline").read_bytes()
        if len(command) > 65536:
            raise RuntimeError("Owned process command exceeds bound")
        return {"pid": pid, "start_ticks": int(fields[19]), "group": int(fields[2]), "session": int(fields[3]),
                "ppid": int(fields[1]), "state": fields[0], "observed_monotonic_ns": time.monotonic_ns(),
                "command": [part.decode(errors="replace") for part in command.split(b"\0") if part]}
    def same_identity(first, second):
        return all(first[key] == second[key] for key in ("pid", "start_ticks", "group", "session"))
    def request_stop(reason):
        nonlocal requested_stop, stop_at
        if requested_stop is None:
            requested_stop, stop_at = reason, time.monotonic(); stop.write_text(reason + "\n")
    def record_ownership_loss(reason, pid, parent_proof=None, observed=None):
        nonlocal ownership_complete, ownership_failure_count, ownership_failure_overflow
        ownership_complete = False; ownership_failure_count += 1
        if len(ownership_failures) >= 128:
            ownership_failure_overflow = True
            raise RuntimeError("Owned proof-loss history exceeds fixed128 bound")
        def context(value):
            return None if value is None else {key: value[key] for key in ("pid", "start_ticks", "group", "session", "ppid")}
        ownership_failures.append({"reason": reason, "pid": pid, "observed_monotonic_ns": time.monotonic_ns(),
            "parent_proof": context(parent_proof), "observed_identity": context(observed)})
    def remember_command(identity, parent_proof):
        key = tuple(identity[name] for name in ("pid", "start_ticks", "group", "session"))
        if key not in command_history:
            if len(command_history) >= 64:
                record_ownership_loss("command_history_identity_bound", identity["pid"], parent_proof, identity)
                raise RuntimeError("Owned command identity history exceeds fixed64 bound")
            command_history[key] = []
        history = command_history[key]
        if any(value["command"] == identity["command"] for value in history):
            return
        if len(history) >= 8:
            record_ownership_loss("command_history_argv_bound", identity["pid"], parent_proof, identity)
            raise RuntimeError("Owned command history exceeds fixed8 argv bound")
        snapshot = {**identity, "command": list(identity["command"]), "parent_identity": None if parent_proof is None
            else {name: parent_proof[name] for name in ("pid", "start_ticks", "group", "session", "ppid")}}
        history.append(snapshot)
    def proven_command_snapshots():
        return [value for history in command_history.values() for value in history]
    def remember_owned():
        if child is None or root_identity is None:
            return
        pending = [(child.pid, None)]; visited = set()
        while pending:
            pid, parent_proof = pending.pop()
            if pid in visited:
                continue
            visited.add(pid)
            if len(visited) > 64:
                raise RuntimeError("Owned process observation exceeds fixed64 tree bound")
            try:
                identity = process_record(pid)
                if parent_proof is None:
                    if not same_identity(identity, root_identity):
                        return  # Never adopt a replacement for our direct child.
                elif identity["ppid"] != parent_proof["pid"]:
                    record_ownership_loss("parent_pid_changed_before_walk", pid, parent_proof, identity); continue
                elif not same_identity(process_record(parent_proof["pid"]), parent_proof):
                    record_ownership_loss("parent_identity_changed_before_walk", pid, parent_proof, identity); continue
                key = (pid, identity["start_ticks"])
                if key not in owned and len(owned) >= 64:
                    raise RuntimeError("Owned identity history exceeds fixed64 bound")
                tasks = list((Path("/proc") / str(pid) / "task").iterdir())
                if len(tasks) > 256:
                    raise RuntimeError("Owned process exceeds fixed256 thread bound")
                children = set()
                for task in tasks:
                    try:
                        raw = (task / "children").read_text()
                        if len(raw) > 16384:
                            raise RuntimeError("Owned thread children exceeds bound")
                        children.update(int(value) for value in raw.split())
                    except (FileNotFoundError, ProcessLookupError):
                        pass
                if not same_identity(process_record(pid), identity):
                    record_ownership_loss("identity_changed_during_walk", pid, parent_proof, identity); continue
                if parent_proof is not None and not same_identity(process_record(parent_proof["pid"]), parent_proof):
                    record_ownership_loss("parent_identity_changed_during_walk", pid, parent_proof, identity); continue
                remember_command(identity, parent_proof)
                owned[key] = identity; observed_groups.add(identity["group"])
                if len(observed_groups) > 64:
                    raise RuntimeError("Owned group history exceeds fixed64 bound")
                pending.extend((value, identity) for value in children)
            except (FileNotFoundError, ProcessLookupError):
                if parent_proof is not None:
                    record_ownership_loss("process_or_parent_disappeared_during_walk", pid, parent_proof)
    def live_owned():
        matches = {}
        for (pid, _), expected in owned.items():
            try:
                fields = (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
                if (int(fields[19]), int(fields[2]), int(fields[3])) == (expected["start_ticks"], expected["group"], expected["session"]):
                    matches[pid] = expected
            except (FileNotFoundError, ProcessLookupError):
                pass
        return matches
    def signal_owned(number):
        # Popen owns this unreaped direct child and start_new_session fixes its
        # initial group even if /proc/pipe registration failed before snapshots.
        if child is not None and child.poll() is None:
            try:
                os.killpg(child.pid, number)
            except ProcessLookupError:
                pass
        matches = list(live_owned().values())
        if any(value["session"] != value["group"] for value in matches):
            raise RuntimeError("Owned cleanup group/session binding differs")
        for group in {value["group"] for value in matches}:
            if group <= 1 or group == os.getpgrp():
                raise RuntimeError("Refusing unsafe cleanup process group")
            try:
                os.killpg(group, number)
            except ProcessLookupError:
                pass
    def drain_capture(timeout=.1):
        nonlocal complete_capture
        for key, _ in selector.select(timeout):
            try:
                data = os.read(key.fd, 8192)
            except BlockingIOError:
                continue
            if not data:
                selector.unregister(key.fileobj); key.fileobj.close(); continue
            stream, count, digest = captures[key.data]
            digest.update(data)
            if count + len(data) > 2 * 1024 * 1024:
                complete_capture = False; request_stop("Native stdout/stderr bound exceeded")
            else:
                stream.write(data)
            captures[key.data] = (stream, count + len(data), digest)
    try:
        result["human_before_setup"] = phase_readiness(args)
        source_root = SOURCE_ROOT
        ui_assets = ("qml/Main.qml", "qml/DeckSurface.qml", "qml/MixerSurface.qml", "qml/DeckButton.qml", "qml/SurfaceKnob.qml", "qml/StereoMeter.qml",
            "brand/integration/qtquick/ConfluxTheme.qml", "brand/integration/qtquick/qmldir",
            "brand/assets/logos/conflux-horizontal-dark.svg", "brand/assets/logos/conflux-horizontal-light.svg",
            "brand/assets/fonts/Barlow-Regular.ttf", "brand/assets/fonts/BarlowCondensed-SemiBold.ttf", "brand/assets/fonts/JetBrainsMono-Regular.ttf")
        result["runtime_ui_source_root"] = str(source_root)
        paths = {"binary": binary, "track_a": source, "track_b": peer, "runner": Path(__file__).resolve(), **assets,
                 **{"ui:" + name: source_root / name for name in ui_assets},
                 "gpu_observer": GPU_HELPER, "package_observer": PACKAGE_HELPER, "cache_support": CACHE_HELPER, "plan": PLAN,
                 "seed_proof": Path(args.plan["seed_proof"]["path"]), "pcm_prerequisite": PCM_OUTPUT / "result.json",
                 "interstage_audit": INTERSTAGE_AUDIT,
                 **{key: MANDATORY_SOURCES[key] for key in ("context_helper","trace_validator","trace_helper","trace_parser","original_service")}}
        result["pins_before"] = {name: live_pin(path, 256 * 1024 * 1024 if name not in ("track_a", "track_b") else 1024**3) for name, path in paths.items()}
        require_trace(all(result["pins_before"]["plan"][key] == args.plan_pin[key] for key in ("sha256", "bytes", "identity")),
            "Original approved plan changed before player setup")
        if result["pins_before"]["runtime"]["sha256"] != args.plan["assets"]["runtime"]["sha256"] or result["pins_before"]["model"]["sha256"] != FLASH_MODEL_SHA256:
            raise RuntimeError("Passive DRM check requires exact approved candidate runtime and promoted model")
        require_trace(all(result["pins_before"][key][field] == args.preflight["pcm_gate"][source][field]
            for key,source in (("pcm_prerequisite","pcm_result_pin"),("interstage_audit","root_audit_pin"))
            for field in ("sha256","bytes")), "PCM prerequisite/audit changed before player setup")
        verify_plan_files(args.plan, deadline - 15)
        result["repository_head"] = read_command(["git", "-C", str(SOURCE_ROOT), "rev-parse", "HEAD"])
        require_trace(result["repository_head"] == args.plan["source_head"], "Frozen product HEAD differs")
        gpu_helper = load_gpu_observer(result["pins_before"]["gpu_observer"])
        result["gpu_discovery"] = gpu_discovery = gpu_helper.discover_gpu_fields()
        result["gpu_preflight"] = gpu_helper.read_gpu_snapshot(gpu_discovery)
        require_trace(validate_gpu_snapshot(gpu_discovery, result["gpu_preflight"]), "Actual GPU MHz required before child")
        package_helper = load_package_observer(result["pins_before"]["package_observer"])
        result["package_discovery"] = package_discovery = package_helper.discover_package_constraints()
        result["package_preflight"] = package_helper.read_package_snapshot(package_discovery)
        require_trace(validate_package_snapshot(package_discovery, result["package_preflight"]), "Complete package constraints required before child")
        result["guard_before"] = live_guard()
        result["power_before"] = power_state()
        if not result["power_before"]["ac_online"] or not result["power_before"]["lid_open"]:
            raise RuntimeError("Live host check requires AC power and open lid")
        sensors = sensor_paths(); result["host_before"] = frequency_observation(sensors, gpu_helper, gpu_discovery, result["pins_before"]["gpu_observer"], package_helper, package_discovery, result["pins_before"]["package_observer"])
        require_trace(validate_package_snapshot(package_discovery, result["host_before"]["package_constraints"]), "Package constraints incomplete before native launch")
        result["required_free_bytes"] = live_required_free_bytes(args.seconds, hour)
        if shutil.disk_usage(output).free < result["required_free_bytes"]:
            raise RuntimeError("Insufficient free space for bounded cache, recording and evidence")
        result["human_before_launch"] = phase_readiness(args)
        if result["human_before_launch"]["pin"] != result["human_before_setup"]["pin"]:
            raise RuntimeError("Readiness record changed during setup")
        environment = logger_environment(args.cache_helper.cache_environment(os.environ, "player"))
        trace_directory = output / TRACE_DIRECTORY_NAME
        trace_directory.mkdir(mode=0o700)
        environment.update({TRACE_ENV_KEYS[0]:str(trace_directory / NATIVE_TRACE_NAME),
            TRACE_ENV_KEYS[1]:output.name, TRACE_ENV_KEYS[2]:str(trace_directory)})
        environment.update({"CONFLUX_ALLOW_HOST_SOAK": "1", "XDG_CACHE_HOME": str(cache)})
        result["effective_child_environment"] = {key: environment[key] for key in (*LOGGER_ENV_KEYS, *TRACE_ENV_KEYS, "MESA_SHADER_CACHE_DIR", "MESA_SHADER_CACHE_MAX_SIZE", "QT_QUICK_BACKEND") if key in environment}
        for number in (signal.SIGINT, signal.SIGTERM):
            previous[number] = signal.signal(number, lambda signum, _frame: request_stop(f"runner signal {signum}"))
        native_mode = "--live-stems-hidden"
        command = [str(binary), native_mode, str(source), str(peer), str(output), str(args.seconds), str(stop),
                   *(str(assets[name]) for name in ("python", "exporter", "worker", "service", "runtime", "model"))]
        result["command"] = command
        for name in ("stdout", "stderr"):
            captures[name] = ((output / f"native.{name}.log").open("wb"), 0, hashlib.sha256())
        child = subprocess.Popen(command, env=environment, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, start_new_session=True)
        result["owned_direct_group"] = child.pid
        root_identity = process_record(child.pid)
        for name in ("stdout", "stderr"):
            pipe = getattr(child, name); os.set_blocking(pipe.fileno(), False); selector.register(pipe, selectors.EVENT_READ, name)
        remember_owned()
        next_sample = next_guard = next_graph = 0.0
        progress_stamp = None; progress_seen_at = time.monotonic()
        host_rows = host_bytes = 0
        with (output / "host-observations.jsonl").open("w") as host_log:
            while child.poll() is None or selector.get_map():
                drain_capture()
                now = time.monotonic(); elapsed = now - began
                remember_owned()
                if stop.exists() and requested_stop is None:
                    request_stop("user stop file")
                if now >= next_sample:
                    verify_cache_helper(args.cache_helper_pin)
                    host = frequency_observation(sensors, gpu_helper, gpu_discovery, result["pins_before"]["gpu_observer"], package_helper, package_discovery, result["pins_before"]["package_observer"]); host["power"] = power_state()
                    host_rows, host_bytes = write_host_observation(host_log, host, host_rows, host_bytes)
                    next_sample = now + 2
                    if not validate_package_snapshot(package_discovery, host["package_constraints"]):
                        request_stop("Package constraint observation incomplete")
                    if not host["power"]["ac_online"] or not host["power"]["lid_open"] or not host["temperatures_millidegrees_C"]:
                        request_stop("Power/lid/thermal observation failed")
                if now >= next_guard:
                    if live_guard() != result["guard_before"]:
                        request_stop("Existing thermal guard identity changed")
                    next_guard = now + 10
                progress = output / "progress.json"
                if progress.exists():
                    if progress.stat().st_size > 16384:
                        raise RuntimeError("Progress exceeds fixed metadata bound")
                    pulse = json.loads(progress.read_text()); result["last_progress"] = pulse
                    if pulse["monotonic_ns"] != progress_stamp:
                        progress_stamp = pulse["monotonic_ns"]; progress_seen_at = now
                    if pulse["phase"] in ("steady", "replay_recovery", "incomplete_generation_seek") and now - progress_seen_at > 10:
                        request_stop("Native live progress unchanged for ten seconds")
                elif elapsed > 30:
                    request_stop("Native startup progress missing")
                if now >= next_graph and progress.exists():
                    objects = json.loads(read_command(["pw-dump", "-N"], timeout=max(.1, min(8, deadline - time.monotonic() - 2))))
                    for item in owned_objects(objects, child.pid):
                        known_graph.add((item["id"], str(item.get("info", {}).get("props", {}).get("object.serial", ""))))
                    next_graph = now + 5
                if now >= deadline - 45:
                    request_stop("Fixed live-run wall budget reached")
                if requested_stop is not None and now - stop_at >= 20:
                    break
                if now >= deadline - 25:
                    break
        result["native_exit"] = child.poll()
        native_path = output / "native-result.json"
        if not native_path.exists() or native_path.stat().st_size > 1024 * 1024:
            raise RuntimeError("Bounded native result missing")
        result["native"] = json.loads(native_path.read_text())
        native = result["native"]
        validate_hidden_native(native)
        if native.get("functional_only") is not False or native.get("host_audio") is not True or native.get("source_root") != str(source_root):
            raise RuntimeError("Synthetic/private result cannot qualify as host evidence")
        if native.get("ui_mode", "visible") != result["ui_mode"]:
            raise RuntimeError("Native UI mode differs from explicitly launched mode")
        if background and native.get("ui_coverage", {}).get("visible_ui_qualification_eligible") is not False:
            raise RuntimeError("Background result must exclude visible UI qualification")
        result["ui_coverage"] = native.get("ui_coverage")
        result["observations"] = summarize_live_observations(output / "observations.jsonl", native)
        setup = native["setup"]
        if any(setup[key] != result["pins_before"][name]["sha256"] for key, name in (
                ("source_sha256", "track_a"), ("model_sha256", "model"), ("runtime_sha256", "runtime"), ("service_sha256", "service"))):
            raise RuntimeError("Published live context differs from launched input/engine")
        result["pins_after"] = {name: live_pin(path, 256 * 1024 * 1024 if name not in ("track_a", "track_b") else 1024**3) for name, path in paths.items()}
        result["pins_unchanged"] = result["pins_before"] == result["pins_after"]
        result["host_after"] = frequency_observation(sensors, gpu_helper, gpu_discovery, result["pins_before"]["gpu_observer"], package_helper, package_discovery, result["pins_before"]["package_observer"])
        result["gpu_coverage"] = gpu_coverage(output / "host-observations.jsonl", gpu_discovery)
        result["package_coverage"] = package_coverage(output / "host-observations.jsonl", package_discovery)
        require_trace(validate_package_snapshot(package_discovery, result["host_after"]["package_constraints"]), "Package constraints incomplete after native run")
        result["thermal_summary"] = thermal_summary(output / "host-observations.jsonl")
        verify_plan_files(args.plan, deadline)
        result["head_after"] = read_command(["git", "-C", str(SOURCE_ROOT), "rev-parse", "HEAD"])
        require_trace(result["head_after"] == args.plan["source_head"], "Frozen product HEAD changed")
        result["power_after"] = power_state(); result["guard_after"] = live_guard()
        if hour:
            result["hour_gates"] = validate_hour_result(native, result["observations"], background)
        result["passed"] = bool(child.poll() == 0 and native["passed"] and not requested_stop and complete_capture and result["pins_unchanged"]
            and result["guard_after"] == result["guard_before"] and result["power_after"]["ac_online"] and result["power_after"]["lid_open"] and known_graph
            and result["package_coverage"]["complete"])
    except Exception as error:
        result["error"] = str(error)
        result["error_type"] = type(error).__name__
        if isinstance(error, OSError):
            result["error_errno"] = error.errno
        if child is not None and child.poll() is None:
            request_stop("Live runner observation error")
    finally:
        for number in previous:
            signal.signal(number, signal.SIG_IGN)
        try:
            if child is not None:
                remember_owned()
                until = min(deadline - 15, time.monotonic() + 20)
                while child.poll() is None and time.monotonic() < until:
                    drain_capture(.1); remember_owned()
                signal_owned(signal.SIGTERM)
                until = min(deadline - 12, time.monotonic() + 1)
                while live_owned() and time.monotonic() < until:
                    drain_capture(.05)
                signal_owned(signal.SIGKILL)
                child.wait(timeout=2)
                while selector.get_map() and time.monotonic() < deadline - 10:
                    drain_capture(.05)
                remaining = live_owned()
                objects = json.loads(read_command(["pw-dump", "-N"], timeout=max(.1, min(8, deadline - time.monotonic() - 2))))
                graph_remaining = [item for item in objects if (item["id"], str(item.get("info", {}).get("props", {}).get("object.serial", ""))) in known_graph
                    or str(item.get("info", {}).get("props", {}).get("application.process.id", "")) == str(child.pid)]
                save(output / "owned-pipewire-cleanup.json", {"remaining_objects": graph_remaining})
                live_jobs = sorted(str(path.relative_to(cache)) for path in cache.rglob(".live-*"))
                groups = observed_groups | {child.pid}
                absent = {}
                for group in groups:
                    try:
                        os.killpg(group, 0); absent[str(group)] = False
                    except ProcessLookupError:
                        absent[str(group)] = True
                    except PermissionError:
                        absent[str(group)] = False
                service_path = str(assets["service"].resolve())
                runtime_path, model_path = str(assets["runtime"].resolve()), str(assets["model"].resolve())
                def service_matches(value):
                    command = value["command"]
                    if len(command) < 3 or command[0] not in (str(assets["python"]), str(assets["python"].resolve())) or command[1:3] != ["-B", service_path]:
                        return False
                    return all(command.count(flag) == 1 and command.index(flag) + 1 < len(command) and command[command.index(flag) + 1] == expected
                        for flag, expected in (("--runtime", runtime_path), ("--model", model_path), ("--backend", "vulkan"), ("--threads", "2")))
                snapshots = proven_command_snapshots()
                services = [value for value in snapshots if service_matches(value)]
                runtimes = [value for value in snapshots if value["command"] == [runtime_path, "--model", model_path, "--backend", "vulkan", "--threads", "2"]]
                engine_observed = bool(services and runtimes and all(any(value["group"] == service["group"] and
                    value["session"] == service["session"] and value["parent_identity"] is not None and
                    same_identity(value["parent_identity"], service) for service in services) for value in runtimes))
                cooperative = bool(result.get("native", {}).get("shutdown_completed") and child.returncode in (0, 1, 2))
                result["cleanup"] = {"known_processes": list(owned.values()), "remaining_known_processes": list(remaining.values()),
                    "leader_reaped": child.poll() is not None, "remaining_pipewire_count": len(graph_remaining), "remaining_live_jobs": live_jobs,
                    "cooperative_native_shutdown": cooperative, "ownership_complete": ownership_complete, "owned_group_absent": absent,
                    "service_processes": services, "runtime_processes": runtimes, "engine_processes_observed": engine_observed,
                    "scope": "Known descendant snapshots cannot discover an unobserved escaped session; abnormal/missing cooperative completion preserves cache even when known groups are gone"}
                proven = cooperative and ownership_complete and engine_observed and all(absent.values()) and not remaining and not graph_remaining and not live_jobs and not selector.get_map()
            else:
                proven = True  # No app/worker was launched.
            result["cleanup_proven"] = proven
            if proven:
                shutil.rmtree(cache)
            result["owned_cache_removed"] = not cache.exists()
            result["cache_preserved"] = cache.exists()
            result["passed"] = bool(result["passed"] and proven)
        except Exception as error:
            if child is not None and child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL); child.wait(timeout=2)
                except (ProcessLookupError, subprocess.TimeoutExpired):
                    pass
            result["cleanup_error"] = str(error); result["cleanup_proven"] = False; result["cache_preserved"] = cache.exists(); result["passed"] = False
        finally:
            result.setdefault("cleanup", {}).update({"ownership_complete": ownership_complete,
                "proven_command_history": proven_command_snapshots(), "ownership_failures": ownership_failures,
                "ownership_failure_count": ownership_failure_count, "ownership_failure_overflow": ownership_failure_overflow})
            selector.close()
            if child is not None:
                for pipe in (child.stdout, child.stderr):
                    if pipe is not None and not pipe.closed:
                        pipe.close()
            for stream, count, digest in captures.values():
                stream.close()
            result["capture"] = {name: {"bytes_received": count, "sha256_received": digest.hexdigest(), "complete": complete_capture,
                                           "retained_file": pin(output / f"native.{name}.log")} for name, (_, count, digest) in captures.items()}
            for number, handler in previous.items():
                signal.signal(number, handler)
        result["stop_reason"] = requested_stop
        finalize_passive_trace(output, result, args.plan, deadline)
        finalize_logger_result(result, args, deadline)
        result["elapsed_seconds"] = time.monotonic() - began
        result["wall_budget_seconds"] = min(args.seconds + 180, max(0, deadline - began)); result["within_wall_budget"] = time.monotonic() <= deadline
        result["passed"] = bool(result["passed"] and result["within_wall_budget"])
        result["qualified"] = False
        result["timing_qualification"] = False
        result["finished_at_utc"] = datetime.now(timezone.utc).isoformat(); save(output / "result.json", result)
    print(json.dumps(result, indent=2))
    return 0 if result["passed"] else 2 if requested_stop else 1



def load_frozen_module(name, path, expected):
    require_trace(path.is_file() and path.stat().st_size <= 256 * 1024
        and hashlib.sha256(path.read_bytes()).hexdigest() == expected, "Frozen private helper changed: " + name)
    spec = importlib.util.spec_from_file_location("conflux_drm_" + name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def validate_build_result(plan):
    value, pinned = bounded_json(Path(plan["build_result"]["path"]))
    recipe, recipe_pin = bounded_json(Path(plan["source_pins"]["build_recipe"]["path"]))
    abi, abi_pin = bounded_json(Path(plan["source_pins"]["native_abi"]["path"]))
    commands = value.get("commands", [])
    by_label = {row.get("label"):row for row in commands if type(row) is dict}
    expected_commands = {"compile-fixture":"compile_fixture_argv", "run-CPU-fixture":"fixture_timeout_argv_future_only",
        "compile-pipeline":"compile_pipeline_argv", "archive":"archive_argv",
        "index-archive":"index_archive_argv", "link-adapter":"link_adapter_argv"}
    for rows in (abi.get("candidate_source_pins", []), recipe.get("private_source_pins", [])):
        by_path = {row.get("path"): row for row in rows if type(row) is dict}
        require_trace(len(rows) == len(by_path) == 3 and all(all(
            by_path.get(plan["source_pins"][key]["path"], {}).get(field) == plan["source_pins"][key][field]
            for field in ("path", "bytes", "sha256")) for key in ("native_source", "native_helper", "native_fixture")),
            "Compiled packed-attention source/helper/fixture differs from planned source")
    same_pin = lambda a, b: type(a) is dict and type(b) is dict and all(a.get(k) == b.get(k) for k in ("path","bytes","sha256"))
    sources = plan["source_pins"]
    require_trace(same_pin(recipe.get("baseline_pipeline"), sources.get("baseline_pipeline"))
        and same_pin(abi.get("source_baseline"), sources.get("baseline_pipeline"))
        and same_pin(recipe.get("original_archive"), sources.get("original_engine_archive")),
        "Packed pipeline baseline source/archive lineage differs")
    unchanged = recipe.get("unchanged_cached_objects", [])
    baseline = recipe.get("baseline_pipeline_object", {})
    archive = recipe.get("archive_argv", [])
    require_trace(type(recipe.get("cached_archive_object_count")) is int and recipe["cached_archive_object_count"] == 187
        and len(unchanged) == 186 and len({row.get("path") for row in unchanged}) == 186
        and len(archive) == 190 and archive[1:3] == ["qc",str(RUNNER_ROOT / "libengine_runtime.a")]
        and archive[3:].count(str(RUNNER_ROOT / "pipeline.cpp.o")) == 1
        and [path for path in archive[3:] if path != str(RUNNER_ROOT / "pipeline.cpp.o")] == [row["path"] for row in unchanged],
        "Packed engine archive must preserve187 original ordered members with one pipeline replacement")
    old_inputs = {row["path"]:row for row in [*unchanged, baseline]}
    require_trace(len(old_inputs) == 187, "Cached pipeline overlaps another archive input")
    for index, path in enumerate(archive[3:]):
        old_path = baseline["path"] if path == str(RUNNER_ROOT / "pipeline.cpp.o") else path
        require_trace(same_pin(sources.get("archive_input:" + str(index)), old_inputs.get(old_path)),
            "Planned cached archive input/order differs at index" + str(index))
    observer, observer_pin = bounded_json(Path(sources["observer_build"]["path"]))
    observer_abi, observer_abi_pin = bounded_json(Path(sources["observer_abi"]["path"]))
    observer_sources = {row.get("path"):row for row in observer_abi.get("candidate_source_pins", [])}
    observer_recipe_pins = recipe.get("unchanged_adapter_pins", [])
    require_trace(len(observer_recipe_pins) == 3 and {row.get("path") for row in observer_recipe_pins} ==
        {sources[key]["path"] for key in ("observer_source","observer_header","observer_object")}
        and all(any(same_pin(row,sources[key]) for row in observer_recipe_pins)
            for key in ("observer_source","observer_header","observer_object"))
        and all(same_pin(observer_sources.get(sources[key]["path"]), sources[key])
            for key in ("observer_source","observer_header"))
        and same_pin(observer_pin,sources["observer_build"]) and same_pin(observer_abi_pin,sources["observer_abi"])
        and same_pin(recipe.get("input_recipe"),sources["observer_recipe"])
        and observer.get("status") == "passed_CPU_fixture_compiled_and_linked_no_native_execution"
        and observer.get("unchanged_pins_match_after_build") is True
        and observer.get("source_receipt_sha256") == observer_abi_pin["sha256"]
        and observer.get("independent_review_sha256") == sources["observer_review"]["sha256"]
        and observer.get("recipe_sha256") == sources["observer_recipe"]["sha256"]
        and observer.get("native_model_or_GPU_executed") is False and observer.get("physical_launch") is False
        and observer.get("proc_or_counter_probed") is False
        and any(same_pin(row,sources["observer_object"]) for row in observer.get("artifacts", []))
        and recipe["link_adapter_argv"].count(sources["observer_object"]["path"]) == 1
        and str(RUNNER_ROOT / "libengine_runtime.a") in recipe["link_adapter_argv"],
        "Retained reviewed full-client observer object/provenance or candidate archive link differs")
    cpu = value.get("CPU_fixture_output")
    cpu_log = by_label.get("run-CPU-fixture", {}).get("log", {})
    proof = re.fullmatch(r"([1-9][0-9]{0,19}) CPU layout/allocator assertions passed; "
        r"([1-9][0-9]{0,19}) independently addressed F32 samples compared\n", cpu) if type(cpu) is str else None
    require_trace(proof is not None and all(int(v) <= (1 << 64)-1 for v in proof.groups())
        and cpu_log.get("path") == str(RUNNER_ROOT / "run-CPU-fixture.log")
        and type(cpu_log.get("bytes")) is int and cpu_log["bytes"] == len(cpu.encode())
        and cpu_log.get("sha256") == hashlib.sha256(cpu.encode()).hexdigest(),
        "CPU fixture stdout differs from actual pinned build log")
    require_trace(type(value.get("schema")) is int and value["schema"] == 1
        and all(pinned[k] == plan["build_result"][k] for k in ("path","bytes","sha256"))
        and value.get("status") == "passed_CPU_fixture_compiled_and_linked_no_native_execution"
        and value.get("native_model_or_GPU_executed") is False and value.get("physical_launch") is False
        and value.get("proc_or_counter_probed") is False and value.get("unchanged_pins_match_after_build") is True
        and value.get("actual_parallel_compiles") == 1
        and value.get("source_receipt_sha256") == abi_pin["sha256"] == plan["source_pins"]["native_abi"]["sha256"]
        and value.get("independent_review_sha256") == plan["source_pins"]["native_review"]["sha256"]
        and recipe_pin["sha256"] == plan["source_pins"]["build_recipe"]["sha256"]
        and value.get("recipe_sha256") == recipe_pin["sha256"]
        and len(value.get("artifacts", [])) == 4
        and all(any(same_pin(row,expected) for row in value["artifacts"]) for expected in
            [plan["assets"]["runtime"], sources["candidate_pipeline_object"], sources["candidate_engine_archive"], sources["candidate_CPU_fixture"]])
        and len(commands) == len(by_label) == len(expected_commands)
        and [row.get("label") for row in commands] == list(expected_commands)
        and all(type(by_label[label].get("exit")) is int and by_label[label]["exit"] == 0
            and by_label[label].get("argv") == recipe[key] for label,key in expected_commands.items()),
        "Candidate build result does not bind the reviewed source/libraries/runtime")
    return pinned


def validate_pcm_gate(plan, plan_pin, human):
    value, pinned = bounded_json(PCM_OUTPUT / "result.json")
    audit, audit_pin = bounded_json(INTERSTAGE_AUDIT, 128 * 1024)
    now = datetime.now(timezone.utc)
    finished = datetime.fromisoformat(value.get("finished_at_utc", ""))
    audited = datetime.fromisoformat(audit.get("created_at_utc", ""))
    now_mono = time.monotonic()
    prior = value.get("operator_budget", {})
    anchor, ended = value.get("started_monotonic"),value.get("finished_monotonic")
    prior_age, prior_deadline = prior.get("age_seconds"),prior.get("operator_deadline_monotonic")
    sampled = prior.get("approval_sample_monotonic")
    require_trace(all(type(v) in (int,float) and math.isfinite(v) for v in (anchor,ended,prior_age,prior_deadline,sampled))
        and 0 <= prior_age <= 120 and 0 <= sampled <= anchor <= ended <= now_mono
        and now_mono-ended <= 60 and prior.get("phase") == "pcm"
        and abs(prior_deadline-(sampled+960-prior_age)) <= 1e-6
        and value.get("boot_id") == boot_identity(), "Original PCM monotonic budget/boot lineage differs")
    require_trace(finished.tzinfo is not None and audited.tzinfo is not None
        and 0 <= (now-finished).total_seconds() <= 60 and finished <= audited <= now,
        "Original sixty-second interstage admission window expired")
    require_trace(value.get("status") == "passed" and value.get("qualified") is False
        and value.get("timing_qualification") is False and value.get("mode") == MODE
        and value.get("plan_pin") == plan_pin and value.get("human_pin") == human["pin"]
        and value.get("source_head") == plan["source_head"] and value.get("pins_unchanged") is True
        and value.get("pins_before") == value.get("pins_after") and bool(value.get("pins_before"))
        and value.get("candidate_runtime") == plan["assets"]["runtime"]
        and value.get("model") == plan["assets"]["model"] and value.get("reference_runtime_sha256") == FLASH_RUNTIME_SHA256
        and value.get("cleanup_complete") is True and value.get("guard_before") == value.get("guard_after")
        and value.get("errors") == [] and value.get("within_wall_budget") is True
        and value.get("native_trace", {}).get("passed") is True
        and type(value["native_trace"].get("native_schema")) is int
        and value["native_trace"]["native_schema"] == NATIVE_SCHEMA
        and value["native_trace"].get("native_mode") == NATIVE_MODE
        and value["native_trace"].get("completed_requests") == 16
        and value["native_trace"].get("request_ids") == list(range(1,17))
        and value.get("shader_cache", {}).get("inventory_complete") is True,
        "Fresh candidate PCM/cleanup/guard/cache/source prerequisite failed")
    require_trace(audit.get("status") == "passed" and audit.get("plan_sha256") == plan_pin["sha256"]
        and audit.get("human_sha256") == human["pin"]["sha256"] and audit.get("pcm_result_sha256") == pinned["sha256"]
        and audit.get("source_head") == plan["source_head"]
        and audit.get("candidate_runtime_sha256") == plan["assets"]["runtime"]["sha256"]
        and all(audit.get(k) is True for k in ("guard_unchanged","owned_processes_absent","owned_groups_absent",
            "no_owned_pipewire","immutable_seed_unchanged")), "Root interstage cleanup audit missing or mismatched")
    original = load_frozen_module("original_pcm", ORIGINAL_PCM, ORIGINAL_PCM_SHA256)
    proof, proof_pin = bounded_json(REFERENCE)
    require_trace(proof_pin["sha256"] == REFERENCE_SHA256, "Immutable baseline reference changed")
    cases = original.validate_reference(proof, FLASH_MODEL_SHA256)
    for prefix, pins in (("asset:",plan["assets"]),("source:",plan["source_pins"])):
        for key, expected_pin in pins.items():
            actual = value["pins_before"].get(prefix + key, {})
            require_trace(all(actual.get(field) == expected_pin[field] for field in ("path","bytes","sha256")),
                "PCM prerequisite lacks an exact planned file pin: " + prefix + key)
    requests = value.get("requests")
    require_trace(type(requests) is list and len(requests) == 16
        and [row.get("case_id") for row in requests] == list(PCM_CASE_IDS), "New PCM case list differs")
    for request_id, row in enumerate(requests, 1):
        expected = cases[row["case_id"]]
        require_trace(row.get("request_id") == request_id and row.get("completed") is True
            and row.get("exact_pcm_match") is True and row.get("input_sha256") == expected["input_sha256"]
            and row.get("output_sha256") == expected["output_sha256"]
            and row.get("output_shape") == [4,343980,2] and row.get("output_dtype") == "<f4"
            and row.get("output_bytes") == 4*343980*2*4, "New candidate PCM output differs from immutable reference")
    return {"passed":True,"pcm_result_pin":pinned,"root_audit_pin":audit_pin,
            "original_human_pin":human["pin"],"interstage_age_seconds":(now-finished).total_seconds(),
            "original_operator_deadline_monotonic":prior_deadline}


def finalize_passive_trace(output, result, plan, deadline):
    result["qualified"] = result["timing_qualification"] = False
    try:
        require_trace(result.get("cleanup_proven") is True and time.monotonic() < deadline,
            "Owned cleanup and original budget required before passive trace validation")
        expected = plan["source_pins"]["trace_validator"]
        validator = load_frozen_module("trace_validation", Path(expected["path"]), expected["sha256"])
        rows, _ = validator.read_records(output / TRACE_DIRECTORY_NAME / "native-request-trace.jsonl",
            byte_limit=4*1024**2,line_limit=32768,row_limit=258,deadline=deadline)
        require_trace(len(rows) >= 5 and rows[-2].get("event") == "native_shutdown", "Native observed shutdown record missing")
        shutdown = rows[-2]
        result["native_trace"] = validator.native_trace(output / TRACE_DIRECTORY_NAME / NATIVE_TRACE_NAME,
            run_id=output.name,native_identity=shutdown.get("native"),exit_code=shutdown.get("exit_code"),
            deadline=deadline,expected_device=plan["drm_device"])
        require_trace(time.monotonic() < deadline, "Original context validation deadline exhausted")
        result["request_trace"] = validate_context_sidecar(output,result,result["native_trace"])
        require_trace(time.monotonic() < deadline, "Original post-trace validation deadline exhausted")
    except Exception as error:
        result["passive_trace_error"] = str(error)
        result["request_trace"] = {"passed":False,"retained_directory":str(output / TRACE_DIRECTORY_NAME)}
        result["passed"] = False


def validate_context_sidecar(output, result, native_capture):
    """Validate the completed private sidecar against independently owned snapshots."""
    parent = output / TRACE_DIRECTORY_NAME
    parent_fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    descriptor = None
    try:
        before_parent = os.fstat(parent_fd)
        require_trace(stat.S_ISDIR(before_parent.st_mode) and before_parent.st_uid == os.getuid()
            and stat.S_IMODE(before_parent.st_mode) == 0o700
            and (parent.lstat().st_dev, parent.lstat().st_ino) == (before_parent.st_dev, before_parent.st_ino), "Unsafe trace parent")
        descriptor = os.open("native-request-trace.jsonl", os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                             dir_fd=parent_fd)
        before = os.fstat(descriptor)
        signature = lambda st: (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
        require_trace(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid() and before.st_nlink == 1
            and stat.S_IMODE(before.st_mode) == 0o600 and 0 < before.st_size <= (4 * 1024**2), "Unsafe or oversized trace sidecar")
        raw = b""
        while len(raw) <= (4 * 1024**2):
            block = os.read(descriptor, min(65536, (4 * 1024**2) + 1 - len(raw)))
            if not block:
                break
            raw += block
        require_trace(len(raw) == before.st_size and signature(os.fstat(descriptor)) == signature(before)
            and signature(os.stat("native-request-trace.jsonl", dir_fd=parent_fd, follow_symlinks=False)) == signature(before)
            and (parent.lstat().st_dev, parent.lstat().st_ino) == (before_parent.st_dev, before_parent.st_ino),
            "Trace sidecar changed while reading")
        after_parent = os.fstat(parent_fd)
        require_trace(stat.S_ISDIR(after_parent.st_mode) and after_parent.st_uid == os.getuid()
            and stat.S_IMODE(after_parent.st_mode) == 0o700, "Trace parent permissions changed")
    finally:
        if descriptor is not None:
            os.close(descriptor)
        os.close(parent_fd)
    lines = raw.splitlines(keepends=True)
    require_trace(4 <= len(lines) <= 258 and all(line.endswith(b"\n") and len(line) <= 32768 for line in lines),
                  "Incomplete or oversized trace records")
    def unique(pairs):
        value = {}
        for key, item in pairs:
            require_trace(key not in value, "Duplicate trace JSON key")
            value[key] = item
        return value
    records = [json.loads(line, object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite trace JSON"))) for line in lines]
    require_trace(all(type(row) is dict and type(row.get("schema")) is int and row["schema"] == 1 for row in records),
                  "Trace schema differs")
    header, final = records[0], records[-1]
    require_trace(header.get("event") == "run_begin" and header.get("run_id") == output.name
        and final.get("event") == "run_end" and final.get("complete") is True and final.get("worker_joined") is True
        and type(final.get("failed")) is int and final["failed"] == 0 and final.get("failure") is None and final.get("pending_request_id") is None
        and type(final.get("started")) is int and 1 <= final["started"] <= 64
        and type(final.get("completed")) is int and final["completed"] == final["started"] and len(records) == 3 + final["started"] * 2,
        "Trace finalization is incomplete")
    require_trace(header.get("limits") == {"record_bytes": 32768, "requests": 128, "records": 258,
                  "file_bytes": (4 * 1024**2), "raw_bytes": 16384}, "Trace producer limits differ")
    cleanup = result.get("cleanup", {})
    require_trace(result.get("cleanup_proven") is True and cleanup.get("ownership_complete") is True
                  and cleanup.get("engine_processes_observed") is True, "Trace validation requires independent engine cleanup")
    services, runtimes = cleanup.get("service_processes", []), cleanup.get("runtime_processes", [])
    def matches(identity, snapshot):
        return type(identity) is dict and set(identity) == {"pid", "start_ticks"} and all(
            type(identity[k]) is int and identity[k] > 0 and identity[k] == snapshot.get(k) for k in identity)
    service_matches = [row for row in services if matches(header.get("service"), row)]
    require_trace(len(service_matches) == 1, "Trace header service identity was not independently owned")
    service = service_matches[0]
    require_trace(service in cleanup.get("proven_command_history", []), "Trace service lacks proven command history")
    def flag(command, name):
        require_trace(command.count(name) == 1 and command.index(name) + 1 < len(command), "Trace service argv lacks unique " + name)
        return command[command.index(name) + 1]
    require_trace(header.get("job", {}).get("path") == flag(service["command"], "--directory")
        and Path(header["job"]["path"]) == Path(header["job"]["path"]).resolve()
        and Path(header["job"]["path"]).is_relative_to(output / "cache"), "Trace job differs from owned service cache")
    pins = header.get("pins", [])
    require_trace(type(pins) is list and len(pins) == 10, "Trace header pin list differs")
    setup = result["native"]["setup"]
    source = pins[0]
    require_trace(source.get("path") == flag(service["command"], "--input")
        and source.get("sha256") == setup["input_sha256"] and source.get("bytes") == setup["input_frames"] * 8,
        "Trace source differs from actual decoded input")
    expected = result["pins_before"]
    for key, item in zip(("model", "runtime", "service", "exporter", "worker", "context_helper", "trace_helper", "trace_parser", "original_service"), pins[1:]):
        pinned = expected[key]
        require_trace(item.get("path") == pinned["canonical_path"] and item.get("sha256") == pinned["sha256"]
            and item.get("bytes") == pinned["bytes"] and item.get("signature") == pinned["identity"],
            "Trace header asset pin differs: " + key)
    shutdown = records[-2]
    require_trace(shutdown.get("event") == "native_shutdown" and shutdown.get("requested_quit") is True
        and shutdown.get("quit_write_complete") is True and shutdown.get("killed") is False
        and type(shutdown.get("exit_code")) is int and shutdown["exit_code"] == 0
        and shutdown.get("process_reaped") is True and shutdown.get("within_same_shutdown_budget") is True
        and shutdown.get("graceful_complete") is True and shutdown.get("native") == native_capture["native"],
        "Native trace lacks observed exit0/idle quit/reap within original2s")
    require_trace(native_capture["request_ids"] == list(range(1, final["started"] + 1)),
        "Native/context completed request set differs")
    requests = []
    for request_id in range(1, final["started"] + 1):
        begin, complete = records[request_id * 2 - 1:request_id * 2 + 1]
        context = begin.get("context", {})
        require_trace(begin.get("event") == "request_begin" and complete.get("event") == "request_complete"
            and type(complete.get("request_id")) is int and complete["request_id"] == request_id
            and set(context) == {"request_id", "generation", "window_start_frame", "source_id", "preroll", "timestamp"}
            and type(context["request_id"]) is int and context["request_id"] == request_id
            and all(type(context[k]) is int and 1 <= context[k] <= (1 << 53) - 1 for k in ("generation",))
            and type(context["window_start_frame"]) is int and 0 <= context["window_start_frame"] <= (1 << 53) - 1
            and context["window_start_frame"] % 257985 == 0 and context["source_id"] == source["sha256"]
            and type(context["preroll"]) is bool and type(context["timestamp"]) in (int, float)
            and math.isfinite(context["timestamp"]) and context["timestamp"] >= 0,
            "Trace original request context differs")
        native_matches = [row for row in runtimes if matches(begin.get("native"), row)
            and row in cleanup.get("proven_command_history", [])
            and row.get("group") == service.get("group") and row.get("session") == service.get("session")
            and row.get("parent_identity") is not None and all(row["parent_identity"].get(k) == service.get(k)
                for k in ("pid", "start_ticks", "group", "session"))]
        require_trace(len(native_matches) == 1, "Trace native request identity was not independently owned")
        state = complete.get("worker_at_return", {})
        require_trace(set(state) == {"generation", "closed"} and type(state["generation"]) is int
            and 0 <= state["generation"] <= (1 << 53) - 1 and type(state["closed"]) is bool,
            "Trace completion worker state differs")
        binding = complete.get("gpu_trace", {})
        require_trace(type(binding.get("schema")) is int and type(binding.get("request_id")) is int
            and binding == {"schema":1,"kind":"passive_drm_request_binding","run_id":output.name,
            "native":begin["native"],"request_id":request_id} and begin["native"] == native_capture["native"],
            "Passive DRM/context native request binding differs")
        requests.append({"context":context,"native":begin["native"],"worker_at_return":state})
    by_request = {row["context"]["request_id"]:row for row in requests}
    validated = result.get("observations", {}).get("chunk_phases", {}).get("hops", [])
    seen = set()
    for hop in validated:
        request_id = hop.get("request_id")
        require_trace(type(request_id) is int and request_id in by_request and request_id not in seen,
            "Validated hop lacks a unique captured native attempt")
        context = by_request[request_id]["context"]
        require_trace(context["preroll"] is False and hop.get("generation") == context["generation"]
            and type(hop.get("input_first")) is int
            and hop["input_first"] // 257985 * 257985 == context["window_start_frame"],
            "Validated hop changed its original worker generation/window")
        seen.add(request_id)
        by_request[request_id]["validated_hop"] = hop
    for request in requests:
        request.setdefault("validated_hop",None)
    return {"passed": True, "qualified": False, "path": str(parent / "native-request-trace.jsonl"),
            "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "records": len(records),
            "completed_requests": len(requests), "requests": requests,
            "scope": "Original worker inflight context; no lease/publication or hard-cancel proof. Passive client accounting freshness remains unknown."}



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--allow-host-audio", action="store_true", required=True)
    parser.add_argument("--drm-busy-diagnostic", action="store_true", required=True)
    parser.add_argument("--plan", type=Path, default=PLAN)
    parser.add_argument("--readiness-decision", type=Path, default=HUMAN)
    values = parser.parse_args()
    phase_started = time.monotonic()
    lock = None
    entered_runner = False
    try:
        plan, plan_pin = load_plan(values.plan) # Unarmed plans stop before any cache/host activity.
        validate_build_result(plan)
        human = readiness(values.readiness_decision, plan_pin)
        budget = operator_budget(human, time.monotonic(), phase_started)
        pcm_gate = validate_pcm_gate(plan, plan_pin, human)
        budget = retain_original_budget(budget,pcm_gate,time.monotonic())
        cool_deadline = min(phase_started + 180, budget["phase_deadline_monotonic"])
        verify_plan_files(plan, cool_deadline)
        require_trace(read_command(["git", "-C", str(SOURCE_ROOT), "rev-parse", "HEAD"]) == plan["source_head"], "Frozen source HEAD differs")
        assets = {key: Path(row["path"]) for key, row in plan["assets"].items()}
        helper, helper_pin = load_cache_support()
        parent = helper.capture_cache_parent()
        lock = helper.acquire_cache_lock(parent, cool_deadline)
        seed, seed_pin = bounded_json(Path(plan["seed_proof"]["path"]))
        require_trace(seed_pin["sha256"] == plan["seed_proof"]["sha256"] and seed.get("cleanup_proven") is True
            and seed.get("pins_unchanged") is True and seed.get("shader_cache", {}).get("inventory_complete") is True,
            "Retained immutable cache seed proof differs or is incomplete")
        manifest = seed["shader_cache"]["post"]
        require_trace(manifest.get("manifest_sha256") == plan["seed_manifest_sha256"], "Exact seed manifest differs")
        preparation = helper.prepare_phase("player", manifest, cool_deadline)
        guard_before = guard_identity(assets["guard_script"], assets["guard_unit"])
        rows = cool_start(cool_deadline)
        require_trace(guard_identity(assets["guard_script"], assets["guard_unit"]) == guard_before,
            "Active guard changed during natural cooldown")
        fresh = readiness(values.readiness_decision, plan_pin)
        require_trace(fresh["pin"] == human["pin"] and time.monotonic() + 150 < budget["phase_deadline_monotonic"],
            "Original approval changed or insufficient time remains for120s and cleanup")
        arguments = SimpleNamespace(**assets, seconds=120, live_stems=True, live_stems_hour=False, background=True,
            output=OUTPUT, readiness_decision=values.readiness_decision,
            plan=plan, plan_pin=plan_pin, human_pin=human["pin"], operator_budget=budget,
            phase_deadline=budget["phase_deadline_monotonic"], operator_deadline=budget["operator_deadline_monotonic"],
            cache_helper=helper, cache_helper_pin=helper_pin, cache_preparation=preparation, cache_lock=lock,
            preflight={"natural_cool_observations": rows, "guard": guard_before, "seed_proof_pin": seed_pin, "pcm_gate":pcm_gate})
        entered_runner = True
        return run_live(arguments)
    except Exception as error:
        print(json.dumps({"passed": False, "qualified": False, "timing_qualification": False,
            "error": str(error), "runner_entered": entered_runner,
            "scope": "Exception summary only; inspect standalone evidence for native launch/cleanup state"}))
        return 1
    finally:
        if lock is not None:
            lock.close()


if __name__ == "__main__":
    raise SystemExit(main())
