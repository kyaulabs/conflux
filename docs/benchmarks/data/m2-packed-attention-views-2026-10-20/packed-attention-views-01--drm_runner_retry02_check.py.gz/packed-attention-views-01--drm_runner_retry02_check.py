#!/usr/bin/env python3
"""Offline fakes only. Held for independent review before the first execution."""
import copy
import contextlib
from datetime import datetime, timedelta, timezone
import errno
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location("drm_check_"+name,BASE/(name+".py"))
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


player = load("run_drm_player_retry02")
validator = load("drm_trace_validation")
context = load("context_capture")
pcm = load("run_drm_pcm_retry02")


def native_records():
    def client(client_id, fd, value, begin, end):
        return {"driver":"i915","pdev":"0000:00:02.0","rdev":"123","client_id":str(client_id),
            "fd":str(fd),"alias_fds":[str(fd)],"alias_policy":"fixed_lowest_fd_per_owner_not_summed",
            "read_begin_ns":str(begin),"read_end_ns":str(end),"engines":{"render":{"ns":str(value),"capacity":"2"}}}
    def snapshot(begin,end,value,second):
        return {"read_begin_ns":str(begin),"read_end_ns":str(end),"status":"observed","reason":"",
            "fd_enumeration_complete":True,"candidate_scan_complete":True,
            "clients":[client(9,7,value,begin+1,begin+2),client(10,8,second,begin+3,begin+4)]}
    def accounting(client_id, within, gap, cumulative, high):
        return {"driver":"i915","pdev":"0000:00:02.0","rdev":"123","client_id":str(client_id),
            "engines":{"render":{"within_call_delta_ns":str(within),"between_call_delta_ns":gap,
                "cumulative_delta_ns":str(cumulative),"high_water_ns":str(high),"regressed_or_below_high_water":False}}}
    high = (1<<53)+7
    prefix = {"schema":2,"mode":validator.NATIVE_MODE,"run_id":"fake","native_pid":"42","start_ticks":"500","freshness":"unknown"}
    inventory = {"candidate_count":2,"fd_enumeration_complete":True,"candidate_scan_complete":True}
    setup = snapshot(1,10,high-5,1000)
    candidates = []
    for ordinal,c in enumerate(setup["clients"],1):
        raw = {k:v for k,v in c.items() if k not in ("alias_fds","read_begin_ns","read_end_ns")}
        raw["alias_policy"] = "raw_per_fd_not_selected_or_summed"
        candidates.append({**prefix,"event":"discovery_candidate","ordinal":ordinal,"inventory":copy.deepcopy(inventory),
            "read_begin_ns":c["read_begin_ns"],"read_end_ns":c["read_end_ns"],"fd_identity_stable":True,"client":raw})
    return candidates + [
        {**prefix,"event":"setup","backend":"vulkan","threads":2,"fence_wait_mode":"blocking",
            "inventory":inventory,"limits":copy.deepcopy(validator.LIMITS),
            "reservation":{"request_row_max_bytes":16384,"footer_max_bytes":2048},"snapshot":setup},
        {**prefix,"event":"inference","request_id":"1","status":"returned","before":snapshot(11,20,high,1000),
            "call_begin_ns":"21","call_end_ns":"22","after":snapshot(23,32,high+40,1000),
            "accounting":[accounting(9,40,None,40,high+40),accounting(10,0,None,0,1000)]},
        {**prefix,"event":"inference","request_id":"2","status":"returned","before":snapshot(33,42,high+50,1005),
            "call_begin_ns":"43","call_end_ns":"44","after":snapshot(45,54,high+80,1025),
            "accounting":[accounting(9,30,"10",80,high+80),accounting(10,20,"5",25,1025)]},
        {**prefix,"event":"footer","status":"complete","reason":"","reason_bytes":"0","reason_truncated":False}]


class OfflineChecks(unittest.TestCase):
    def setUp(self):
        self.no_child = mock.patch("subprocess.Popen",side_effect=AssertionError("No real child in offline fixture"))
        self.no_child.start();self.addCleanup(self.no_child.stop)
        self.no_signal = mock.patch("os.killpg",side_effect=AssertionError("No real group in offline fixture"))
        self.no_signal.start();self.addCleanup(self.no_signal.stop)
        self.temp = tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name);self.root.chmod(0o700)

    def write(self,name,rows):
        path = self.root/name
        path.write_text("".join(json.dumps(row,separators=(",",":"))+"\n" for row in rows))
        path.chmod(0o600)
        return path

    def parse(self,rows,exit_code=0):
        return validator.native_trace(self.write("native.jsonl",rows),run_id="fake",
            native_identity={"pid":42,"start_ticks":500},exit_code=exit_code,
            deadline=player.time.monotonic()+5,expected_device={"driver":"i915","pdev":"0000:00:02.0"})

    def test_actual_roots_and_distinct_reference(self):
        self.assertEqual(player.SOURCE_ROOT,BASE.parents[2])
        self.assertEqual(player.ASSET_PATHS["worker"],player.SOURCE_ROOT/"tools/stems/worker.py")
        self.assertEqual(player.ASSET_PATHS["service"],BASE/"service_drm.py")
        self.assertEqual(player.ASSET_PATHS["runtime"],BASE/"conflux-stem-runtime")
        self.assertEqual(len(player.PCM_CASE_IDS),len(set(player.PCM_CASE_IDS)))
        self.assertEqual(len(player.PCM_CASE_IDS),16)

    def test_actual_private_cache_parent_is_0700(self):
        helper = load("cache_support")
        parent = helper.capture_cache_parent()
        self.assertEqual(parent["path"],str(BASE))
        self.assertEqual(parent["mode"],0o700)
        self.assertEqual(player.MANDATORY_SOURCES["runner_tests"],BASE/"drm_runner_retry02_check.py")

    def canonical_alias_fixture(self):
        plan = {"assets":{}, "source_pins":{}, "canonical_alias_bindings":{}}
        aliases, specs = {}, {}
        for name, (_alias, _canonical, section, key) in player.ALIAS_PATHS.items():
            target, alias = self.root/(name+".regular"), self.root/(name+".alias")
            data = (name+" frozen fixture\n").encode()
            target.write_bytes(data)
            alias.symlink_to(target.name)
            digest = hashlib.sha256(data).hexdigest()
            info = alias.lstat()
            plan[section][key] = {"path":str(target), "bytes":len(data), "sha256":digest}
            plan["canonical_alias_bindings"][name] = {
                "alias_path":str(alias), "canonical_path":str(target), "bytes":len(data), "sha256":digest,
                "alias_identity":[info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns]}
            aliases[name] = (alias,target,section,key)
            specs[name] = (target,digest,1024)
        for key in ("cache_helper","gpu_helper","package_helper","seed_proof","build_result","review"):
            plan[key] = plan["assets"]["python"].copy()
        comparison = player.load_frozen_module("canonical_alias_fixture_comparison",
            player.SOURCE_ROOT/"benchmarks-local/m2-graph-phase-2026-10-18/compare_runtime.py",
            "5022aeed8eaf932adead05404f80b94c7d992f4b6f68dc81d05edb6126077e5b")
        return plan, aliases, specs, comparison

    def test_real_NOFOLLOW_alias_failure_and_canonical_capture(self):
        plan,aliases,specs,comparison = self.canonical_alias_fixture()
        alias,target,_section,_key = aliases["python"]
        with self.assertRaises(OSError) as raised:
            comparison.capture_pins({"python":(alias,specs["python"][1],1024)},player.time.monotonic()+5)
        self.assertEqual(raised.exception.errno,errno.ELOOP)
        with mock.patch.object(player,"ALIAS_PATHS",aliases):
            captured = pcm.capture_plan_pins(plan,player,comparison,specs,player.time.monotonic()+5)
            self.assertEqual(captured["python"]["path"],str(target))
            self.assertEqual(captured["python"]["sha256"],specs["python"][1])
            player.verify_plan_files(plan,player.time.monotonic()+5)
            plan["cache_helper"] = {**plan["cache_helper"],"path":str(alias)}
            with self.assertRaisesRegex(RuntimeError,"not canonical"):
                player.verify_plan_files(plan,player.time.monotonic()+5)

    def test_real_alias_retarget_after_capture_rejects_unchanged_content(self):
        plan,aliases,specs,comparison = self.canonical_alias_fixture()
        alias,target,_section,_key = aliases["libvulkan"]
        replacement = self.root/"replacement.regular"
        replacement.write_bytes(target.read_bytes())
        actual_capture = comparison.capture_pins
        def captured_then_retargeted(*args,**kwargs):
            result = actual_capture(*args,**kwargs)
            alias.unlink()
            alias.symlink_to(replacement.name)
            return result
        with mock.patch.object(player,"ALIAS_PATHS",aliases), \
             mock.patch.object(comparison,"capture_pins",side_effect=captured_then_retargeted):
            with self.assertRaisesRegex(RuntimeError,"alias identity or canonical target changed"):
                pcm.capture_plan_pins(plan,player,comparison,specs,player.time.monotonic()+5)
        self.assertEqual(hashlib.sha256(target.read_bytes()).hexdigest(),specs["libvulkan"][1])
        with mock.patch.object(player,"ALIAS_PATHS",aliases),mock.patch.object(comparison,"capture_pins") as capture:
            with self.assertRaises(RuntimeError):
                pcm.capture_plan_pins(plan,player,comparison,specs,player.time.monotonic()+5,verify=False)
            capture.assert_not_called()

    def test_inherited_presence_controls_reject_even_zero(self):
        for key in ("GGML_VK_PERF_LOGGER","CONFLUX_DRM_USAGE_TRACE","CONFLUX_REQUEST_INTERVAL_SECONDS","INTEL_DEBUG"):
            with self.subTest(key=key),self.assertRaises(RuntimeError):
                player.logger_environment({key:"0"})
        self.assertEqual(player.logger_environment({})["QT_QUICK_BACKEND"],"software")

    def test_unarmed_plan_stops_before_cache_or_host(self):
        with mock.patch.object(player,"bounded_json",return_value=({"schema":1,"status":"unarmed"},{})):
            with self.assertRaises(RuntimeError): player.load_plan(player.PLAN)

    def test_missing_PCM_prevents_player_setup(self):
        with mock.patch.object(player,"load_plan",return_value=({},{})), \
             mock.patch.object(player,"validate_build_result"),mock.patch.object(player,"readiness",return_value={}), \
             mock.patch.object(player,"operator_budget",return_value={}), \
             mock.patch.object(player,"validate_pcm_gate",side_effect=RuntimeError("PCM incomplete")), \
             mock.patch.object(player,"load_cache_support") as cache, \
             mock.patch.object(sys,"argv",["runner","--allow-host-audio","--drm-busy-diagnostic"]), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(player.main(),1)
            cache.assert_not_called()

    def test_combined_budget_does_not_renew_on_rollback(self):
        ready = {"age_seconds":40.,"sampled_monotonic":100.}
        pcm_budget = player.operator_budget(ready,100.,100.,phase="pcm")
        self.assertEqual(pcm_budget["operator_deadline_monotonic"],1020.)
        self.assertEqual(pcm_budget["external_INT_after_seconds"],270.)
        new = player.operator_budget({"age_seconds":20.,"sampled_monotonic":400.},400.,400.)
        kept = player.retain_original_budget(new,{"original_operator_deadline_monotonic":1020.},400.)
        self.assertEqual(kept["operator_deadline_monotonic"],1020.)
        self.assertEqual(kept["phase_deadline_monotonic"],880.)
        with self.assertRaises(RuntimeError):
            player.retain_original_budget(new,{"original_operator_deadline_monotonic":879.},400.)

    def test_first_stage_requires_whole_declared_remaining_window(self):
        with self.assertRaises(RuntimeError):
            player.operator_budget({"age_seconds":121.,"sampled_monotonic":0.},0.,0.,phase="pcm")
        with self.assertRaises(RuntimeError):
            player.operator_budget({"age_seconds":40.,"sampled_monotonic":10.},9.,9.,phase="pcm")

    def build_fixture(self, mutate=None):
        native = {key:{"path":str(BASE/name),"bytes":10+i,"sha256":str(i+1)*64}
            for i,(key,name) in enumerate((("native_source","pipeline.cpp"),
                ("native_helper","packed_attention_view.hpp"),("native_fixture","packed_attention_view_test.cpp")))}
        pins = {**native, **{key:{"path":str(BASE/name),"bytes":1,"sha256":str(i+4)*64}
            for i,(key,name) in enumerate((("native_abi","implementation-receipt.json"),
                ("native_review","independent-native-review-01.json"),("build_recipe","build_recipe.json")))}}
        def file_pin(path, number):
            return {"path":str(path),"bytes":number+1,"sha256":f"{number:064x}"}
        for i,key in enumerate(("candidate_pipeline_object","candidate_engine_archive","candidate_CPU_fixture"),10):
            pins[key] = file_pin(player.MANDATORY_SOURCES[key],i)
        for i,key in enumerate(("observer_source","observer_header","observer_object","observer_abi",
                               "observer_review","observer_build","observer_recipe"),20):
            pins[key] = file_pin(player.MANDATORY_SOURCES[key],i)
        old_objects = [file_pin(self.root/f"old-{i}.o",100+i) for i in range(187)]
        pins.update({"archive_input:"+str(i):row for i,row in enumerate(old_objects)})
        pins["baseline_pipeline"] = file_pin(self.root/"baseline-pipeline.cpp",300)
        pins["original_engine_archive"] = file_pin(self.root/"baseline-engine.a",301)
        runtime = {"path":str(BASE/"conflux-stem-runtime"),"bytes":1,"sha256":"a"*64}
        build_pin = {"path":str(BASE/"adapter-build-result.json"),"bytes":1,"sha256":"b"*64}
        plan = {"source_pins":pins,"assets":{"runtime":runtime},"build_result":build_pin}
        labels = {"compile-fixture":"compile_fixture_argv","run-CPU-fixture":"fixture_timeout_argv_future_only",
            "compile-pipeline":"compile_pipeline_argv","archive":"archive_argv",
            "index-archive":"index_archive_argv","link-adapter":"link_adapter_argv"}
        recipe = {key:[label] for label,key in labels.items()}
        recipe["private_source_pins"] = list(copy.deepcopy(native).values())
        recipe.update(cached_archive_object_count=187,baseline_pipeline_object=copy.deepcopy(old_objects[185]),
            baseline_pipeline=copy.deepcopy(pins["baseline_pipeline"]),original_archive=copy.deepcopy(pins["original_engine_archive"]),
            unchanged_cached_objects=[copy.deepcopy(row) for i,row in enumerate(old_objects) if i != 185],
            unchanged_adapter_pins=[copy.deepcopy(pins[key]) for key in ("observer_source","observer_header","observer_object")],
            input_recipe=copy.deepcopy(pins["observer_recipe"]))
        recipe["archive_argv"] = ["/usr/bin/ar","qc",str(BASE/"libengine_runtime.a")] + [
            str(BASE/"pipeline.cpp.o") if i == 185 else row["path"] for i,row in enumerate(old_objects)]
        recipe["link_adapter_argv"] = [pins["observer_object"]["path"],str(BASE/"libengine_runtime.a")]
        abi = {"candidate_source_pins":list(copy.deepcopy(native).values()),"source_baseline":copy.deepcopy(pins["baseline_pipeline"])}
        observer_abi = {"candidate_source_pins":[copy.deepcopy(pins[key]) for key in ("observer_source","observer_header")]}
        observer = {"status":"passed_CPU_fixture_compiled_and_linked_no_native_execution",
            "unchanged_pins_match_after_build":True,"source_receipt_sha256":pins["observer_abi"]["sha256"],
            "independent_review_sha256":pins["observer_review"]["sha256"],"recipe_sha256":pins["observer_recipe"]["sha256"],
            "native_model_or_GPU_executed":False,"physical_launch":False,"proc_or_counter_probed":False,
            "artifacts":[copy.deepcopy(pins["observer_object"])]}
        cpu = "3 CPU layout/allocator assertions passed; 123456789 independently addressed F32 samples compared\n"
        commands = [{"label":label,"argv":copy.deepcopy(recipe[key]),"exit":0} for label,key in labels.items()]
        commands[1]["log"] = {"path":str(BASE/"run-CPU-fixture.log"),"bytes":len(cpu.encode()),
            "sha256":hashlib.sha256(cpu.encode()).hexdigest()}
        build = {"schema":1,"status":"passed_CPU_fixture_compiled_and_linked_no_native_execution",
            "native_model_or_GPU_executed":False,"physical_launch":False,"proc_or_counter_probed":False,
            "unchanged_pins_match_after_build":True,"actual_parallel_compiles":1,"CPU_fixture_output":cpu,
            "source_receipt_sha256":pins["native_abi"]["sha256"],"independent_review_sha256":pins["native_review"]["sha256"],
            "recipe_sha256":pins["build_recipe"]["sha256"],
            "commands":commands,"artifacts":[runtime]+[pins[key] for key in
                ("candidate_pipeline_object","candidate_engine_archive","candidate_CPU_fixture")]}
        if mutate: mutate(build,recipe,abi,observer,plan)
        values = {build_pin["path"]:(build,build_pin),pins["build_recipe"]["path"]:(recipe,pins["build_recipe"]),
                  pins["native_abi"]["path"]:(abi,pins["native_abi"]),
                  pins["observer_abi"]["path"]:(observer_abi,pins["observer_abi"]),
                  pins["observer_build"]["path"]:(observer,pins["observer_build"])}
        with mock.patch.object(player,"bounded_json",side_effect=lambda path:values[str(path)]):
            return player.validate_build_result(plan)

    def test_compiled_source_and_real_CPU_log_binding(self):
        self.assertEqual(self.build_fixture()["sha256"],"b"*64)
        for mutation in (lambda b,r,a,o,p:a["candidate_source_pins"][1].update(bytes=999),
                         lambda b,r,a,o,p:r["private_source_pins"][2].update(sha256="0"*64),
                         lambda b,r,a,o,p:b.update(CPU_fixture_output=b["CPU_fixture_output"].replace("3 CPU", "4 CPU"))):
            with self.assertRaises(RuntimeError): self.build_fixture(mutation)

    def test_CPU_output_contract_rejects_observer_fixture_or_overflow(self):
        for output in ("18446744073709551616 CPU layout/allocator assertions passed; 1 independently addressed F32 samples compared\n",
                       "client_set_size_proof request_max=4000 footer_max=1000 physical_rows=82 bytes=300000\n3 CPU fixture assertions passed\n"):
            def mutate(build, _recipe, _abi, _observer, _plan):
                build["CPU_fixture_output"] = output
                build["commands"][1]["log"].update(bytes=len(output.encode()),sha256=hashlib.sha256(output.encode()).hexdigest())
            with self.assertRaises(RuntimeError): self.build_fixture(mutate)

    def test_archive_members_order_and_replacement_are_bound(self):
        def reorder(_build, recipe, _abi, _observer, _plan):
            recipe["archive_argv"][3:5] = reversed(recipe["archive_argv"][3:5])
            recipe["unchanged_cached_objects"][:2] = reversed(recipe["unchanged_cached_objects"][:2])
        for mutation in (reorder,lambda b,r,a,o,p:r["unchanged_cached_objects"].pop(),
                         lambda b,r,a,o,p:r["archive_argv"].__setitem__(188,"old-pipeline.cpp.o")):
            with self.assertRaises(RuntimeError): self.build_fixture(mutation)

    def test_old_adapter_build_or_changed_observer_cannot_produce_candidate(self):
        for mutation in (lambda b,r,a,o,p:b["commands"].pop(3),
                         lambda b,r,a,o,p:b["commands"].reverse(),
                         lambda b,r,a,o,p:b["commands"][2].update(label="compile-adapter"),
                         lambda b,r,a,o,p:o["artifacts"][0].update(sha256="0"*64),
                         lambda b,r,a,o,p:o.update(independent_review_sha256="0"*64),
                         lambda b,r,a,o,p:b["artifacts"].pop(2)):
            with self.assertRaises(RuntimeError): self.build_fixture(mutation)

    def gate_fixture(self,mutate=None):
        runtime = {"path":str(BASE/"conflux-stem-runtime"),"bytes":1,"sha256":"b"*64}
        model = {"path":"/fake/model","bytes":1,"sha256":player.FLASH_MODEL_SHA256}
        source = {"path":str(BASE/"run_drm_player_retry02.py"),"bytes":1,"sha256":"c"*64}
        plan = {"source_head":"f"*40,"assets":{"runtime":runtime,"model":model},"source_pins":{"runner":source}}
        plan_pin = {"sha256":"d"*64};human = {"pin":{"sha256":"e"*64}}
        expected = {case:{"input_sha256":f"{i:064x}","output_sha256":f"{i+100:064x}"}
            for i,case in enumerate(player.PCM_CASE_IDS)}
        now = datetime(2026,10,21,1,0,tzinfo=timezone.utc)
        pins = {"asset:runtime":runtime,"asset:model":model,"source:runner":source}
        result = {"status":"passed","qualified":False,"timing_qualification":False,"mode":player.MODE,
            "plan_pin":plan_pin,"human_pin":human["pin"],"source_head":plan["source_head"],
            "pins_before":pins,"pins_after":copy.deepcopy(pins),"pins_unchanged":True,
            "candidate_runtime":runtime,"model":model,"reference_runtime_sha256":player.FLASH_RUNTIME_SHA256,
            "cleanup_complete":True,"guard_before":{"identity":"same"},"guard_after":{"identity":"same"},
            "errors":[],"within_wall_budget":True,"native_trace":{"passed":True,"native_schema":2,"native_mode":validator.NATIVE_MODE,
                "completed_requests":16,"request_ids":list(range(1,17))},
            "shader_cache":{"inventory_complete":True},"started_monotonic":100.,"finished_monotonic":200.,
            "boot_id":"fakeboot","operator_budget":{"age_seconds":40.,"approval_sample_monotonic":90.,
                "operator_deadline_monotonic":1010.,"phase":"pcm"},
            "finished_at_utc":(now-timedelta(seconds=10)).isoformat(),"requests":[
                {"case_id":case,"request_id":i,"completed":True,"exact_pcm_match":True,
                 **expected[case],"output_shape":[4,343980,2],"output_dtype":"<f4","output_bytes":4*343980*2*4}
                for i,case in enumerate(player.PCM_CASE_IDS,1)]}
        result_pin = {"sha256":"1"*64}
        audit = {"status":"passed","plan_sha256":plan_pin["sha256"],"human_sha256":human["pin"]["sha256"],
            "pcm_result_sha256":result_pin["sha256"],"source_head":plan["source_head"],
            "candidate_runtime_sha256":runtime["sha256"],"created_at_utc":(now-timedelta(seconds=5)).isoformat(),
            **dict.fromkeys(("guard_unchanged","owned_processes_absent","owned_groups_absent","no_owned_pipewire","immutable_seed_unchanged"),True)}
        if mutate: mutate(result,audit)
        def read(path,*_args):
            if path == player.PCM_OUTPUT/"result.json": return result,result_pin
            if path == player.INTERSTAGE_AUDIT: return audit,{"sha256":"2"*64}
            if path == player.REFERENCE: return {},{"sha256":player.REFERENCE_SHA256}
            raise AssertionError("Unexpected fixture read")
        with mock.patch.object(player,"bounded_json",side_effect=read), \
             mock.patch.object(player,"load_frozen_module",return_value=SimpleNamespace(validate_reference=lambda *_:expected)), \
             mock.patch.object(player,"boot_identity",return_value="fakeboot"), \
             mock.patch.object(player.time,"monotonic",return_value=210.), \
             mock.patch.object(player,"datetime",wraps=datetime) as dates:
            dates.now.return_value = now
            return player.validate_pcm_gate(plan,plan_pin,human)

    def test_exact_new_sixteen_case_gate_and_monotonic_lineage(self):
        self.assertEqual(self.gate_fixture()["original_operator_deadline_monotonic"],1010.)

    def test_PCM_changes_and_missing_cases_block_player(self):
        changes = [lambda r,a:r["requests"][0].update(output_sha256="0"*64),
            lambda r,a:r["requests"].pop(),lambda r,a:r.update(human_pin={"sha256":"wrong"}),
            lambda r,a:r.update(candidate_runtime={}),lambda r,a:r.update(boot_id="other"),
            lambda r,a:r.update(mode="request-bound-owned-drm-clients-pcm16-player120-01"),
            lambda r,a:r["native_trace"].update(native_schema=1),lambda r,a:r["native_trace"].update(native_mode="scalar"),
            lambda r,a:r["operator_budget"].update(operator_deadline_monotonic=1110.),
            lambda r,a:a.update(owned_groups_absent=False),lambda r,a:r.update(cleanup_complete=False)]
        for mutation in changes:
            with self.subTest(mutation=mutation),self.assertRaises(RuntimeError): self.gate_fixture(mutation)

    def test_private_service_describe_is_honest_and_threads_gate_is_early(self):
        service = load("service_drm")
        actual = service.describe()
        self.assertEqual(actual["worker_sha256"],context.PINNED[context.ROOT/"tools/stems/worker.py"])
        self.assertEqual(actual["helper_sha256"],service.exporter.describe()["helper_sha256"])
        self.assertEqual(actual["service_sha256"],hashlib.sha256((BASE/"service_drm.py").read_bytes()).hexdigest())
        with self.assertRaises(ValueError): service.serve_f32(None,None,None,None,threads=1)

    def context_fixture(self,mutation=None):
        output = self.root/"fake";output.mkdir(mode=0o700)
        parent = output/player.TRACE_DIRECTORY_NAME;parent.mkdir(mode=0o700)
        source_path = output/"cache/job/source.f32"
        job = source_path.parent
        service = {"pid":41,"start_ticks":499,"group":41,"session":41,
            "command":["/bin/python3","-B",str(BASE/"service_drm.py"),"--directory",str(job),"--input",str(source_path)]}
        native = {"pid":42,"start_ticks":500,"group":41,"session":41,
            "parent_identity":{k:service[k] for k in ("pid","start_ticks","group","session")}}
        identity = {"pid":42,"start_ticks":500}
        pins = {key:{"canonical_path":str(self.root/key),"sha256":str(i)*64,"bytes":1,"identity":[1,i,1,2,3]}
            for i,key in enumerate(("model","runtime","service","exporter","worker","context_helper","trace_helper","trace_parser","original_service"),1)}
        pin_rows = [{"path":str(source_path),"bytes":64*8,"sha256":"a"*64}]+[
            {"path":v["canonical_path"],"bytes":v["bytes"],"sha256":v["sha256"],"signature":v["identity"]} for v in pins.values()]
        inflight = {"request_id":1,"generation":1,"window_start_frame":0,"source_id":"a"*64,"preroll":True,"timestamp":1.}
        binding = {"schema":1,"kind":"passive_drm_request_binding","run_id":"fake","native":identity,"request_id":1}
        rows = [{"event":"run_begin","run_id":"fake","service":{"pid":41,"start_ticks":499},
                 "job":{"path":str(job)},"pins":pin_rows,"limits":{"record_bytes":32768,"requests":128,"records":258,"file_bytes":4*1024**2,"raw_bytes":16384}},
            {"event":"request_begin","context":inflight,"native":identity},
            {"event":"request_complete","request_id":1,"gpu_trace":binding,"worker_at_return":{"generation":2,"closed":False}},
            {"event":"native_shutdown","native":identity,"requested_quit":True,"quit_write_complete":True,
             "killed":False,"exit_code":0,"process_reaped":True,"within_same_shutdown_budget":True,"graceful_complete":True},
            {"event":"run_end","complete":True,"worker_joined":True,"started":1,"completed":1,
             "failed":0,"failure":None,"pending_request_id":None}]
        rows = [{"schema":1,**row} for row in rows]
        if mutation: mutation(rows)
        path = parent/"native-request-trace.jsonl"
        path.write_text("".join(json.dumps(row)+"\n" for row in rows));path.chmod(0o600)
        result = {"cleanup_proven":True,"cleanup":{"ownership_complete":True,"engine_processes_observed":True,
            "service_processes":[service],"runtime_processes":[native],"proven_command_history":[service,native]},
            "native":{"setup":{"input_sha256":"a"*64,"input_frames":64}},"pins_before":pins,
            "observations":{"chunk_phases":{"hops":[]}}}
        return player.validate_context_sidecar(output,result,{"native":identity,"request_ids":[1]})

    def test_unpublished_preroll_context_keeps_original_generation(self):
        result = self.context_fixture()
        self.assertEqual(result["requests"][0]["context"]["generation"],1)
        self.assertEqual(result["requests"][0]["worker_at_return"]["generation"],2)
        self.assertIsNone(result["requests"][0]["validated_hop"])

    def test_old_intrusive_trace_and_unobserved_exit_are_rejected(self):
        with self.assertRaises(RuntimeError):
            self.context_fixture(lambda rows:rows[2].update(gpu_trace={"schema":1,"raw":"old top32"}))
        # A separate fresh fixture parent for the second complete recorded-file case.
        with tempfile.TemporaryDirectory() as temporary:
            self.root = Path(temporary);self.root.chmod(0o700)
            with self.assertRaises(RuntimeError):
                self.context_fixture(lambda rows:rows[3].update(exit_code=1,graceful_complete=False))

    def test_native_decimal_precision_brackets_and_accounting(self):
        result = self.parse(native_records())
        self.assertEqual(result["request_ids"],[1,2])
        self.assertEqual([c["client_id"] for c in result["clients"]],["9","10"])
        self.assertEqual([c["engines"] for c in result["clients"]],[{"render":2},{"render":2}])
        self.assertEqual(result["freshness"],"unknown")
        self.assertFalse(result["qualified"])

    def test_native_footer_is_not_exit_proof(self):
        for exit_code in (1,-9,False,None):
            with self.subTest(exit_code=exit_code),self.assertRaises(RuntimeError):
                self.parse(native_records(),exit_code)
        with self.assertRaises(RuntimeError): self.parse(native_records()[:-1])

    def test_native_identity_counter_and_capacity_failures(self):
        mutations = [lambda r:r[3].update(native_pid="43"),lambda r:r[3].update(request_id="2"),
            lambda r:r[3].update(call_begin_ns="3"),
            lambda r:r[3]["after"]["clients"][0]["engines"]["render"].update(capacity="1"),
            lambda r:r[3]["after"]["clients"][0]["engines"]["render"].update(ns=True),
            lambda r:r[3]["accounting"][0]["engines"]["render"].update(within_call_delta_ns="0"),
            lambda r:r[3]["after"]["clients"].pop(),lambda r:r[3]["after"].update(fd_enumeration_complete=False),
            lambda r:r[3]["before"].update(candidate_scan_complete=1),
            lambda r:r[3]["after"]["clients"][0].update(alias_fds=["7","12"]),
            lambda r:r[3]["after"]["clients"][0].update(read_begin_ns="21"),
            lambda r:r[0]["inventory"].update(candidate_count=True),lambda r:r[0].update(fd_identity_stable=False),
            lambda r:r[2]["reservation"].update(request_row_max_bytes=1),lambda r:r[-1].update(reason_truncated=True)]
        for mutation in mutations:
            rows = native_records();mutation(rows)
            with self.subTest(mutation=mutation),self.assertRaises(RuntimeError): self.parse(rows)

    def test_native_regression_retains_unknown_and_null(self):
        rows = native_records()[:4]+[native_records()[-1]]
        a = int(rows[3]["before"]["clients"][0]["engines"]["render"]["ns"])
        rows[3]["after"]["clients"][0]["engines"]["render"]["ns"] = str(a-10)
        rows[3]["accounting"][0]["engines"]["render"] = {"within_call_delta_ns":None,"between_call_delta_ns":None,
            "cumulative_delta_ns":None,"high_water_ns":str(a),"regressed_or_below_high_water":True}
        self.assertEqual(self.parse(rows)["freshness"],"unknown")

    def test_scalar_mode_is_never_accepted_as_full_client_proof(self):
        for mutation in (lambda r:r[3].update(schema=1),lambda r:r[0].update(mode="scalar"),
                         lambda r:r[3]["after"].update(client={})):
            rows = native_records();mutation(rows)
            with self.assertRaises(RuntimeError): self.parse(rows)

    def test_alias_counters_can_differ_without_sums_or_representative_switch(self):
        rows = native_records()
        alias = copy.deepcopy(rows[0]);alias.update(ordinal=3,read_begin_ns="6",read_end_ns="7")
        alias["client"].update(fd="9");alias["client"]["engines"]["render"]["ns"] = "9999999999999999999"
        rows.insert(2,alias)
        for row in rows[:4]:
            row["inventory"]["candidate_count"] = 3
        for row in rows[3:-1]:
            for snap in ([row["snapshot"]] if row["event"] == "setup" else [row["before"],row["after"]]):
                snap["clients"][0]["alias_fds"] = ["7","9"]
        self.assertEqual(self.parse(rows)["clients"][0]["fd"],"7")
        rows[4]["after"]["clients"][0].update(fd="9")
        with self.assertRaises(RuntimeError): self.parse(rows)

    def test_private_file_modes_link_and_encoded_bounds(self):
        path = self.write("unsafe.jsonl",native_records());path.chmod(0o644)
        with self.assertRaises(RuntimeError):
            validator.read_records(path,byte_limit=262144,line_limit=4096,row_limit=66,deadline=player.time.monotonic()+5)
        path.chmod(0o600);os.link(path,self.root/"alias")
        with self.assertRaises(RuntimeError):
            validator.read_records(path,byte_limit=262144,line_limit=4096,row_limit=66,deadline=player.time.monotonic()+5)
        oversized = self.write("long.jsonl",[{"v":"x"*4096},{}])
        with self.assertRaises(RuntimeError):
            validator.read_records(oversized,byte_limit=262144,line_limit=4096,row_limit=66,deadline=player.time.monotonic()+5)

    def test_finalization_deadline_is_not_renewed(self):
        result = {"passed":True,"cleanup_proven":True}
        plan = {"source_pins":{"trace_validator":{"path":str(BASE/"drm_trace_validation.py"),"sha256":"x"}}}
        with mock.patch.object(player.time,"monotonic",return_value=11.),mock.patch.object(player,"load_frozen_module") as loader:
            player.finalize_passive_trace(self.root,result,plan,10.)
            loader.assert_not_called()
        self.assertFalse(result["passed"])

    def fake_process(self,*,hang=False):
        clock = SimpleNamespace(now=100.)
        class Process:
            stdin = SimpleNamespace(fileno=lambda:77)
            returncode = None
            killed = False
            def poll(self): return self.returncode
            def kill(self): self.killed = True
            def wait(self,timeout):
                if self.killed: self.returncode = -9;return -9
                if hang:
                    clock.now += timeout
                    raise subprocess.TimeoutExpired("fake",timeout)
                self.returncode = 0;return 0
        return Process(),clock

    def test_idle_quit_observes_actual_exit_and_same_budget(self):
        process,clock = self.fake_process()
        with mock.patch.object(context.os,"get_blocking",return_value=True), \
             mock.patch.object(context.os,"set_blocking"),mock.patch.object(context.os,"write",side_effect=lambda _fd,data:len(data)):
            result = context.idle_quit(process,completed_idle=True,deadline=102.,clock=lambda:clock.now)
        self.assertTrue(result["graceful_complete"])
        self.assertEqual(result["exit_code"],0)
        self.assertFalse(process.killed)

    def test_idle_quit_timeout_preserves_failed_trace_and_kill_reap(self):
        process,clock = self.fake_process(hang=True)
        with mock.patch.object(context.os,"get_blocking",return_value=True), \
             mock.patch.object(context.os,"set_blocking"),mock.patch.object(context.os,"write",side_effect=lambda _fd,data:len(data)):
            result = context.idle_quit(process,completed_idle=True,deadline=102.,clock=lambda:clock.now)
        self.assertTrue(result["process_reaped"])
        self.assertTrue(result["killed"])
        self.assertFalse(result["graceful_complete"])
        self.assertLessEqual(clock.now,102.)

    def test_inflight_abort_never_sends_quit_or_claims_complete(self):
        process,clock = self.fake_process()
        with mock.patch.object(context.os,"write") as writer:
            result = context.idle_quit(process,completed_idle=False,deadline=102.,clock=lambda:clock.now)
        writer.assert_not_called()
        self.assertFalse(result["graceful_complete"])
        self.assertTrue(result["process_reaped"])

    def context_wrapper(self,request_id):
        native = context.ContextNativeRuntime.__new__(context.ContextNativeRuntime)
        identity = {"pid":42,"start_ticks":500}
        inflight = {"request_id":request_id,"generation":7,"window_start_frame":257985,
                    "source_id":"a"*64,"preroll":False,"timestamp":12.25}
        worker = mock.Mock()
        worker.statistics.side_effect = [{"inflight":inflight},{"generation":8,"closed":False}]
        native.trace_worker = lambda:worker
        native.trace_sink = mock.Mock(source_digest="a"*64)
        native.process = SimpleNamespace(pid=42)
        native.trace_native_identity = identity
        native.context_run_id = "fake"
        native._infer_active = False
        native._last_infer_completed = True
        return native,worker,inflight,identity

    def test_context_wrapper_preserves_original_attempt_and_result_objects(self):
        native,worker,inflight,identity = self.context_wrapper(11)
        samples,output = object(),object()
        original_result = {"event":"result","id":11,"elapsed_ms":1.25}
        def infer(owner,actual_samples,request_id):
            self.assertIs(owner,native)
            self.assertIs(actual_samples,samples)
            self.assertEqual(request_id,11)
            self.assertTrue(native._infer_active)
            native.trace_sink.begin.assert_called_once()
            return output,original_result
        with mock.patch.object(context,"process_identity",return_value=identity) as process_id, \
             mock.patch.object(context.original.NativeRuntime,"infer",side_effect=infer):
            actual_output,actual_result = native.infer(samples,11)
        process_id.assert_called_once_with(42)
        self.assertIs(actual_output,output)
        self.assertIs(actual_result,original_result)
        self.assertNotIn("gpu_trace",actual_result)
        captured,actual_identity = native.trace_sink.begin.call_args.args
        inflight["generation"] = 99
        self.assertEqual(captured,{"request_id":11,"generation":7,"window_start_frame":257985,
            "source_id":"a"*64,"preroll":False,"timestamp":12.25})
        self.assertEqual(actual_identity,identity)
        native.trace_sink.complete.assert_called_once_with(11,{
            "schema":1,"kind":"passive_drm_request_binding","run_id":"fake","native":identity,"request_id":11},
            {"generation":8,"closed":False})
        self.assertEqual(worker.statistics.call_count,2)
        native.trace_sink.mark_failure.assert_not_called()
        native.trace_sink.request_failed.assert_not_called()
        self.assertFalse(native._infer_active)
        self.assertTrue(native._last_infer_completed)

    def test_context_wrapper_backend_error_retains_failure_and_clears_idle_state(self):
        native,worker,_inflight,identity = self.context_wrapper(3)
        error = RuntimeError("fake backend error")
        with mock.patch.object(context,"process_identity",return_value=identity), \
             mock.patch.object(context.original.NativeRuntime,"infer",side_effect=error), \
             self.assertRaises(RuntimeError) as raised:
            native.infer(object(),3)
        self.assertIs(raised.exception,error)
        native.trace_sink.begin.assert_called_once()
        native.trace_sink.complete.assert_not_called()
        native.trace_sink.mark_failure.assert_called_once_with(error,3)
        native.trace_sink.request_failed.assert_called_once_with(3,error)
        self.assertEqual(worker.statistics.call_count,1)
        self.assertFalse(native._infer_active)
        self.assertFalse(native._last_infer_completed)


if __name__ == "__main__":
    unittest.main()
