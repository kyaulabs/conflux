"""Offline only: generated protocol/capture data, no app/native/model imports."""
import copy
import contextlib
import io
from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
import json
import shlex
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, BASE/filename)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


driver = module('private_host_player_test', 'run_host_player.py')
controls_wrapper = module('normal_controls_test_wrapper', '/home/kyau/projects/kyaulabs/conflux/build/m2-profile-reporting-worktree/tools/experiments/run_manual_playback_soak.py')


_cap_fixture=None
def setUpModule():
    global _cap_fixture
    _cap_fixture=patch.object(driver,'read_power_caps',side_effect=lambda:copy.deepcopy(driver.CAP_CEILINGS))
    _cap_fixture.start()
def tearDownModule():
    _cap_fixture.stop()


class AdmissionTests(unittest.TestCase):
    def setup_mock(self,temp=55000):
        clock=[1.0]
        state={'temp':temp,'epp':'balance_performance','platform':'balanced','profile':'balanced',
            'recovered':True,'ac':True,'lid':True,'read_errors':{},'observer_errors':[]}
        plan={'requested_power_profile':'balanced','requested_qt_quick_backend':None,'helpers':{'admission_owner':{'path':'/offline/owner.py'},
            'admission_readiness':{'path':'/offline/readiness.py'}},
            'assets':{'guard_script':{'path':'/offline/guard'},'guard_unit':{'path':'/offline/unit'}}}
        actual=driver.load_source('offline_actual_normal_ready',
            driver.ROOT/'benchmarks-local/user-tracks-2026-10-17/normal_ready.py',
            '4e94000d5966357c653a6ef64729f9b513df723ce0badb17e496d4b85c07135f')
        def recover_if_due():
            if 'guard_spike_at' in state:
                ready=(clock[0]<state['guard_spike_at'] or clock[0]>=state['guard_recovered_at'])
                state.update(profile='balanced' if ready else 'power-saver',recovered=ready,
                    platform='balanced' if ready else 'low-power',epp='balance_performance' if ready else 'power')
            elif 'recover_at' in state:
                ready=clock[0]>=state['recover_at']
                state.update(profile='balanced' if ready else 'power-saver',recovered=ready,
                    platform='balanced' if ready else 'low-power',epp='balance_performance' if ready else 'power')
        def capture(zone,deadline):
            recover_if_due()
            if state.get('capture_temps'):state['temp']=state['capture_temps'].pop(0)
            message=('2026-10-23T00:00:00+00:00 recovered: temperature 41.0C; balanced profile restored=1'
                if state['recovered'] else '2026-10-23T00:00:00+00:00 warning: CPU/ACPI temperature 92.0C; power-saver engaged (was balanced)')
            return {'finished_monotonic':clock[0],'errors':copy.deepcopy(state['observer_errors']),
                'package_millidegrees_C':state['temp'],'profile':state['profile'],'holds':state.get('holds',''),
                'service_identity':{'ActiveState':'active','SubState':'running','MainPID':'100',
                    'InvocationID':state.get('invocation','a'*32)},
                'latest_guard_entry':{'_PID':'100','_SYSTEMD_INVOCATION_ID':state.get('invocation','a'*32),'MESSAGE':message}}
        owner=SimpleNamespace(guard_identity=lambda *args:{
            'service':{'MainPID':'100','InvocationID':state.get('invocation','a'*32)},
            'process':{'pid':100,'start_ticks':state.get('guard_start',1)}},
            sensor_paths=lambda:{'/offline/thermal_zone7/temp':'x86_pkg_temp'},
            power_state=lambda:{'ac_online':state['ac'],'lid_open':state['lid']},
            observation=lambda sensors:{'read_errors':copy.deepcopy(state['read_errors']),
                'temperatures_millidegrees_C':{'/offline/thermal_zone7/temp':
                    state['observed_temps'].pop(0) if state.get('observed_temps') else state.get('observed_temp',state['temp'])},
                'profile_epp_read_only':{'/sys/firmware/acpi/platform_profile':state['platform'],
                    '/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference':state['epp']}},
            read_command=lambda command,timeout=3:None)
        observer=SimpleNamespace(identity=actual.identity,ready=actual.ready,capture=capture)
        timing=SimpleNamespace(monotonic=lambda:clock[0],sleep=lambda seconds:clock.__setitem__(0,clock[0]+seconds))
        def load(name,*args):return owner if name.endswith('_owner') else observer
        return plan,clock,state,timing,load

    def test_unchanged60s_cooldown_and_final_EPP_gate(self):
        plan,clock,state,timing,load=self.setup_mock();report={}
        with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
            fresh,recovery,cooldown=driver.prepare_admission(plan,report,500,1,lambda:None)
            recovery();cooldown()
            self.assertEqual(report['cool_readiness'][-1]['consecutive_span_seconds'],60)
            self.assertEqual(clock[0],61)
            state['temp']=60000
            self.assertEqual(fresh('fresh60C_explicit70C_policy')['package_millidegrees_C'],60000)
            state['epp']='power'
            with self.assertRaises(ValueError):fresh('before_Popen')
            state['epp']='balance_performance';state['observed_temp']=71000
            with self.assertRaises(ValueError):fresh('contradictory_package_before_Popen')

    def test_contradictory_platform_or_package_resets_posthash_cooldown(self):
        for key,value in [('platform','low-power'),('observed_temp',56000),('temp',56000)]:
            plan,clock,state,timing,load=self.setup_mock();report={}
            with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
                fresh,recovery,cooldown=driver.prepare_admission(plan,report,500,1,lambda:None)
                recovery();state[key]=value
                with self.assertRaisesRegex(ValueError,'Original bounded60s'):cooldown()
            self.assertEqual(clock[0],271)
            self.assertFalse(any(x['ready_observation'] for x in report['cool_readiness']))
            self.assertTrue(report['host_observations'])

    def test_failed_strict_fresh_temperature_and_guard_rows_retained(self):
        for key,value,match in [('temp',71000,'Fresh<=70C'),('invocation','b'*32,'Fresh<=70C'),
                                ('guard_start',2,'Guard identity changed')]:
            plan,clock,state,timing,load=self.setup_mock();report={};saved=[]
            with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
                fresh,recovery,cooldown=driver.prepare_admission(plan,report,500,1,lambda:saved.append(copy.deepcopy(report)))
                recovery();fresh('before_dispatch');state[key]=value
                with self.assertRaisesRegex(ValueError,match):fresh('public_readiness_before_setup')
            failed=report['fresh_admissions'][-1]
            self.assertFalse(failed['accepted']);self.assertIn(match,failed['rejection']['message'])
            self.assertEqual(saved[-1]['fresh_admissions'][-1],failed)
            self.assertEqual(report['cool_readiness'],[]);self.assertEqual(clock[0],1)

    def test_initial_natural_recovery90s_is_not_an_extra60s_cooldown(self):
        plan,clock,state,timing,load=self.setup_mock(temp=33000);report={};state['recover_at']=91
        with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
            fresh,recovery,cooldown=driver.prepare_admission(plan,report,361,1,lambda:None)
            recovery()
            self.assertEqual(clock[0],91);self.assertTrue(report['initial_recovery_complete'])
            self.assertEqual(report['cool_readiness'],[])
            self.assertEqual(report['initial_recovery_samples'][0]['profile'],'power-saver')
            self.assertFalse(report['initial_recovery_samples'][0]['latest_message_claims_recovered'])
            fresh('before_dispatch');fresh('public_readiness_before_setup');cooldown()
            self.assertEqual(clock[0],151)
            self.assertEqual(report['cool_readiness'][-1]['consecutive_span_seconds'],60)
            self.assertEqual((report['initial_recovery_deadline'],report['cooldown_deadline']),(151,211))
            fresh('cooldown_complete');fresh('public_readiness_before_Popen')
            with self.assertRaisesRegex(ValueError,'Single initial'):recovery()
            with self.assertRaisesRegex(ValueError,'Single cooldown'):cooldown()

    def test_never_recovered_stops_at150_without_strict_gate_or_cooldown(self):
        plan,clock,state,timing,load=self.setup_mock(temp=33000);report={};state['recover_at']=1000
        with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
            fresh,recovery,cooldown=driver.prepare_admission(plan,report,361,1,lambda:None)
            with self.assertRaisesRegex(ValueError,'Initial natural guard recovery'):recovery()
        self.assertEqual(clock[0],151);self.assertEqual(report['fresh_admissions'],[])
        self.assertEqual(report['cool_readiness'],[]);self.assertFalse(report.get('cooldown_started',False))

    def test_initial_recovery_read_errors_power_or_guard_changes_fail_closed(self):
        cases=[('invocation','b'*32,'Guard changed'),('guard_start',2,'Guard identity changed'),
            ('ac',False,'AC/open lid changed'),('lid',False,'AC/open lid changed'),
            ('read_errors',{'temperature':'read failed'},'Host observation failed'),
            ('observer_errors',[{'error':'read failed'}],'Initial recovery observation failed')]
        for key,value,match in cases:
            with self.subTest(key=key):
                plan,clock,state,timing,load=self.setup_mock();report={}
                with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
                    fresh,recovery,cooldown=driver.prepare_admission(plan,report,361,1,lambda:None)
                    state[key]=value
                    with self.assertRaisesRegex(ValueError,match):recovery()
                self.assertEqual(clock[0],1);self.assertEqual(report['cool_readiness'],[])
                self.assertIn(match,report['initial_recovery_samples'][-1]['rejection']['message'])

    def test_stage_order_and_original_deadline_cannot_be_reset(self):
        plan,clock,state,timing,load=self.setup_mock();report={}
        with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
            fresh,recovery,cooldown=driver.prepare_admission(plan,report,361,1,lambda:None)
            with self.assertRaisesRegex(ValueError,'Initial natural recovery must complete'):fresh('before_dispatch')
            with self.assertRaisesRegex(ValueError,'Initial natural recovery must complete'):cooldown()
            recovery();clock[0]=171
            with self.assertRaisesRegex(ValueError,'Original bounded60s'):cooldown()
            self.assertEqual((clock[0],report['cooldown_deadline']),(211,211))
            with self.assertRaisesRegex(ValueError,'Single cooldown'):cooldown()


class BudgetTests(unittest.TestCase):
    def fixture(self):
        now=datetime(2026,10,23,12,tzinfo=timezone.utc)
        row={'schema':1,'decision':'ready','diagnostic_mode':driver.MODE,'ready_for_run':'output-01',
            'plan_sha256':'a'*64,'maximum_operator_seconds':600,'maximum_command_seconds':540,
            'ui_mode':'visible','visible_window':True,'screen_awake':True,'recorded_at_utc':now.isoformat(),'AC_power':True,'lid_open':True,
            'Codex_minimized':True,'other_work_paused':True,'no_suspend':True,
            'human_reply':'ready','human_question':'conditions','question_item_id':'offline-oracle'}
        return now,row

    def test_original600_remaining_budget_boundaries(self):
        now,row=self.fixture()
        for age in (0,120,300,450):
            row['recorded_at_utc']=(now-timedelta(seconds=age)).isoformat()
            result=driver.budget(row,'a'*64,now,1000)
            self.assertEqual(result['age_seconds'],age)
            self.assertEqual(result['operator_deadline'],1000+600-age)
            self.assertEqual(result['command_deadline'],1540)
        for age in (-.001,450.001,600):
            row['recorded_at_utc']=(now-timedelta(seconds=age)).isoformat()
            with self.assertRaises(ValueError):driver.budget(row,'a'*64,now,1000)

    def test_repeated_checks_keep_original_timestamp_and_operator_deadline(self):
        issued,first=self.fixture();second={**first}
        a=driver.budget(first,'a'*64,issued+timedelta(seconds=60),1060)
        b=driver.budget(second,'a'*64,issued+timedelta(seconds=120),1120)
        self.assertEqual(first['recorded_at_utc'],second['recorded_at_utc'])
        self.assertEqual(a['operator_deadline'],b['operator_deadline'])
        self.assertEqual(a['operator_deadline'],1600)
        self.assertEqual((a['command_deadline'],b['command_deadline']),(1600,1660))
        # Root retains this once-only first-observation deadline, deducting UTC age.
        self.assertEqual(1060+(600-a['age_seconds']),1600)

    def test_malformed_or_unbound_human_conditions_rejected(self):
        now,original=self.fixture()
        cases=[('maximum_command_seconds',360),('maximum_operator_seconds',960),('plan_sha256','b'*64),
            ('diagnostic_mode','wrong'),('ready_for_run','wrong'),('ui_mode','background'),('AC_power',1),
            ('visible_window',False),('screen_awake',False),('no_suspend',False),('human_reply',''),('question_item_id','x'*8193),
            ('recorded_at_utc',now.replace(tzinfo=None).isoformat()),('recorded_at_utc','malformed')]
        for key,value in cases:
            with self.subTest(key=key):
                row={**original,key:value}
                with self.assertRaises(ValueError):driver.budget(row,'a'*64,now,1000)


class RendererEnvironmentTests(unittest.TestCase):
    def test_exact_requests_and_allowlist_without_graphics_api_claim(self):
        common={'QT_QPA_PLATFORM':'wayland','QSG_RHI_BACKEND':'vulkan','XDG_SESSION_TYPE':'wayland',
            'MESA_SHADER_CACHE_DIR':'/offline/cache','MESA_SHADER_CACHE_MAX_SIZE':'1G','PRIVATE_TOKEN':'not recorded'}
        default=driver.renderer_environment({'requested_qt_quick_backend':None},common)
        software=driver.renderer_environment({'requested_qt_quick_backend':'software'},
            {**common,'QT_QUICK_BACKEND':'software'})
        self.assertEqual(set(default),set(driver.RENDERER_ENVIRONMENT_KEYS))
        self.assertIsNone(default['QT_QUICK_BACKEND']);self.assertEqual(software.pop('QT_QUICK_BACKEND'),'software')
        self.assertEqual({k:v for k,v in default.items() if k!='QT_QUICK_BACKEND'},software)
        self.assertNotIn('PRIVATE_TOKEN',default)

    def test_missing_invalid_or_inherited_request_fails_before_admission(self):
        cases=[({},{}),({'requested_qt_quick_backend':False},{}),
            ({'requested_qt_quick_backend':''},{}),({'requested_qt_quick_backend':'opengl'},{}),
            ({'requested_qt_quick_backend':None},{'QT_QUICK_BACKEND':''}),
            ({'requested_qt_quick_backend':None},{'QT_QUICK_BACKEND':'software'}),
            ({'requested_qt_quick_backend':'software'},{}),
            ({'requested_qt_quick_backend':'software'},{'QT_QUICK_BACKEND':'Software'})]
        for plan,environment in cases:
            with self.subTest(plan=plan,environment=environment):
                with self.assertRaises(ValueError):driver.renderer_environment(plan,environment)


class OwnerClockTests(unittest.TestCase):
    def fixture(self,base):
        plan={'path':'/offline/plan','bytes':1,'sha256':'a'*64}
        human={'path':'/offline/human','bytes':1,'sha256':'b'*64}
        row={'schema':1,'mode':driver.MODE,'plan_pin':plan,'human_pin':human,
            'started_monotonic':10.,'deadline_monotonic':550.,'command_maximum_seconds':540,
            'term_seconds':525,'kill_seconds':537}
        (base/'dispatch-01.json').write_text(json.dumps(row))
        return plan,human,row

    def test_real_checkpoint_identity_and_original_absolute_cuts(self):
        with tempfile.TemporaryDirectory() as directory:
            base=Path(directory);plan,human,row=self.fixture(base)
            with patch.object(driver,'BASE',base):clock=driver.read_owner_clock(plan,human,float('inf'),11)
            self.assertEqual((clock['started_monotonic'],clock['deadline_monotonic'],clock['term_monotonic'],clock['kill_monotonic']),
                (10,550,535,547))
            self.assertEqual(clock['checkpoint_pin']['sha256'],hashlib.sha256((base/'dispatch-01.json').read_bytes()).hexdigest())
            self.assertEqual(len(clock['checkpoint_pin']['identity']),5)

    def test_actual_owner_cuts_and_explicit_pinned_default_command(self):
        owner=module('recovery_budget_actual_owner','run_player_owned.py')
        self.assertEqual((owner.TERM_AT,owner.KILL_AT,owner.MAXIMUM),(525,537,540))
        self.assertEqual(owner.escalation(100,None),(625,637))
        self.assertEqual(owner.escalation(100,150),(150,162))
        self.assertEqual(owner.escalation(100,900),(625,637))
        plan=json.loads(driver.PLAN.read_bytes())
        row=plan['sources']['operator_launch'];path=Path(row['path']);raw=path.read_bytes()
        self.assertEqual(row,{'path':str(BASE/'launch-command-01.txt'),'bytes':len(raw),
            'sha256':hashlib.sha256(raw).hexdigest()})
        self.assertEqual(shlex.split(raw.decode()),['/usr/bin/kde-inhibit','--power','--screenSaver',
            str(BASE/'run_player_owned.py'),'--run'])
        self.assertIsNone(plan['requested_qt_quick_backend'])
        self.assertEqual(plan['command_seconds'],540)
        self.assertEqual(plan['operator_seconds'],600)
        self.assertEqual(owner.LAUNCHER_SHA,hashlib.sha256((BASE/'run_host_player.py').read_bytes()).hexdigest())
        now,record=BudgetTests().fixture()
        for age in (30,30.001):
            with self.subTest(original_human_age=age),tempfile.TemporaryDirectory() as directory:
                base=Path(directory);plan_path=base/'plan';human_path=base/'human'
                fixed={'status':'frozen_pending_fresh_readiness','sources':{'outer_owner':{}}}
                current={**record,'recorded_at_utc':(now-timedelta(seconds=age)).isoformat()}
                def pin(path,*args,**kwargs):
                    return {'path':str(path),'sha256':'a'*64,'bytes':1},json.dumps(
                        fixed if Path(path)==plan_path else current).encode()
                gate=SimpleNamespace(PLAN=plan_path,HUMAN=human_path,pin_read=pin,decode=json.loads,
                    validate_plan=lambda value:value,budget=driver.budget,
                    OUTPUT=SimpleNamespace(exists=lambda:(_ for _ in ()).throw(RuntimeError('540 gate accepted'))))
                with patch.object(owner,'BASE',base),patch.object(owner,'load_driver',return_value=gate),\
                     patch.object(owner.time,'monotonic',return_value=10),\
                     patch.object(owner,'datetime',SimpleNamespace(now=lambda zone:now)),\
                     patch.object(owner.subprocess,'Popen',side_effect=AssertionError('No fixture child')) as popen:
                    if age==30:
                        with self.assertRaisesRegex(RuntimeError,'540 gate accepted'):owner.run(10)
                    else:
                        with self.assertRaisesRegex(ValueError,'less than570s launch/cleanup room'):owner.run(10)
                popen.assert_not_called();self.assertEqual(list(base.iterdir()),[])

    def test_foreign_or_changed_owner_checkpoint_never_grants_work(self):
        cases=[('schema',True),('mode','foreign'),('plan_pin',{}),('human_pin',{}),
            ('command_maximum_seconds',360),('term_seconds',345),('kill_seconds',357),
            ('started_monotonic',True),('started_monotonic',12),('deadline_monotonic',551)]
        with tempfile.TemporaryDirectory() as directory:
            base=Path(directory);plan,human,row=self.fixture(base)
            with patch.object(driver,'BASE',base):
                for key,value in cases:
                    with self.subTest(field=key,value=value):
                        (base/'dispatch-01.json').write_text(json.dumps({**row,key:value}))
                        with self.assertRaises(ValueError):driver.read_owner_clock(plan,human,float('inf'),11)
                (base/'dispatch-01.json').unlink()
                with self.assertRaises(FileNotFoundError):driver.read_owner_clock(plan,human,float('inf'),11)


class ReportingAndOrderingTests(unittest.TestCase):
    # No subprocess, host inventory, app/model/native import, asset hash or real sleep.
    def exercise(self,*,launched=False,setup_seconds=.3,after_setup=None,extra_ready=False,
                 wrong_label=False,cleanup_proven=True,fresh_over70=False,owner_history=None,
                 recover_after=0,initial_change=None,stop_reason=None,native_error=None,cool_recover_after=0,
                 guard_spike_after=None,guard_recovered_after=None,
                 power_profile='balanced',selection_failure=False,restore_failure=False,owner_age_seconds=0,before_monitor=None):
        plan,clock,state,timing,helpers=AdmissionTests.setup_mock(self,temp=33000)
        plan['requested_power_profile']=power_profile
        plan['sources']={'profile_policy':{'path':'/offline/profile_policy.py','sha256':'f'*64}}
        if recover_after:state['recover_at']=1+recover_after
        if initial_change:state.update(initial_change)
        if guard_spike_after is not None:
            state.update(guard_spike_at=1+guard_spike_after,guard_recovered_at=1+guard_recovered_after)
        events=[];saved={};pin_calls=[];human={'fixture':'offline-only'}
        def select(case,*args):
            self.assertEqual(case,'performance');events.append('select_performance')
            state.update(profile='performance',platform='performance',epp='performance')
            if selection_failure:raise RuntimeError('Fixture selection failed after change')
            return {'requested_profile':'performance','setting_changed':True}
        def restore(case,*args):
            self.assertEqual(case,'performance');events.append('restore_prior_profile')
            if restore_failure:raise RuntimeError('Fixture restoration unavailable')
            state.update(profile='balanced',platform='balanced',epp='balance_performance')
            return {'complete':True,'prior_profile_observed':True,'power_limits_unchanged':True,
                    'power_caps_within_observed_ceiling':True}
        policy=SimpleNamespace(select=select,restore=restore)
        oracle=SimpleNamespace(environment_contract=lambda env:None,
            assess=lambda result:events.append('ordinary_oracle') or {'passed':False})
        wrapper=SimpleNamespace(FLASH_RUNTIME_SHA256=driver.NORMAL,FLASH_MODEL_SHA256=driver.MODEL,observation=lambda *_:{'fixture':True})
        def original_readiness(path,label,background=False):
            events.append('human_readiness');return {'pin':human_pin,'record':human}
        wrapper.live_readiness=original_readiness
        original_observation=wrapper.observation
        def workload(args):
            events.append('wrapper_entered');args.output.mkdir()
            self.assertTrue(args.live_stems);self.assertFalse(args.live_stems_hour)
            self.assertTrue(args.active_controls);self.assertFalse(args.background)
            self.assertEqual(args.seconds,120)
            self.assertEqual(wrapper.FLASH_RUNTIME_SHA256,driver.RUNTIME_SHA)
            self.assertFalse(any(k.startswith(('CONFLUX_DRM_','CONFLUX_REQUEST_TRACE_','GGML_VK_','GGML_VULKAN_')) for k in driver.os.environ))
            result={'passed':False,'qualified':False,'capture':{},'cleanup_proven':cleanup_proven,
                'owned_cache_removed':True,'cleanup':{'ownership_complete':True,
                    'proven_command_history':[] if owner_history is None else owner_history,
                    'ownership_failure_count':0,'ownership_failures':[],'ownership_failure_overflow':False}}
            try:
                wrapper.live_readiness(args.readiness_decision,'wrong' if wrong_label else 'output-01',background=False)
                events.append('all_wrapper_SHA_pins_complete');clock[0]+=setup_seconds
                if after_setup is not None:after_setup(state)
                wrapper.live_readiness(args.readiness_decision,'output-01',background=False)
                events.append('final_admission_returned')
                if before_monitor is not None:
                    before_monitor();wrapper.observation(None)
                    events.append('public_cap_monitor_returned')
                if extra_ready:wrapper.live_readiness(args.readiness_decision,'output-01',background=False)
                if launched:
                    result.update(owned_direct_group=200,command=['/offline/native'],error_type='RuntimeError',
                        error='Fixture native failed; observations intentionally missing')
                    if stop_reason is not None:result['stop_reason']=stop_reason
                    result['native']={'quick_backend_environment':''}
                    if native_error is not None:result['native'].update(passed=False,error=native_error)
                else:result.update(error_type='ValueError',error='Fixture stopped before native launch')
            except Exception as error:result.update(error_type=type(error).__name__,error=str(error))
            (args.output/'result.json').write_text(json.dumps(result));return 1
        wrapper.run_live=workload
        def load(name,*args):
            if name=='private_host_player_oracle':return oracle
            if name=='private_host_player_workload':return wrapper
            if name=='private_guarded_profile_policy':return policy
            return helpers(name,*args)
        prepare=driver.prepare_admission
        def prepare_logged(*args):
            fresh,recovery,cooldown=prepare(*args)
            def f(label,**kwargs):
                events.append('fresh:'+label)
                if fresh_over70 and label=='public_readiness_before_Popen':state['temp']=71000
                return fresh(label,**kwargs)
            def r():events.append('initial_recovery');return recovery()
            def c():
                events.append('single_cooldown')
                if cool_recover_after:state['recover_at']=clock[0]+cool_recover_after
                return cooldown()
            return f,r,c
        def save(path,value):
            saved[Path(path).name]=copy.deepcopy(value);Path(path).write_text(json.dumps(value))
        def pin(path,*args,**kwargs):
            path=Path(path);pin_calls.append(path.name);raw=path.read_bytes()
            return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},raw
        with tempfile.TemporaryDirectory() as directory:
            base=Path(directory);output=base/'output-01';capture=base/'capture';human_path=base/'human.json';plan_path=base/'plan.json'
            human_path.write_text(json.dumps(human));plan_path.write_text(json.dumps(plan))
            human_pin=pin(human_path)[0];plan_pin=pin(plan_path)[0];pin_calls.clear()
            with (
                patch.object(driver,'capture_process_cpu',return_value={'fixture':True}),patch.object(driver,'BASE',base),patch.object(driver,'OUTPUT',output),
                patch.object(driver,'PLAN',plan_path),patch.object(driver,'HUMAN',human_path),
                patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing),
                patch.object(driver,'prepare_admission',side_effect=prepare_logged),
                patch.object(driver,'read_owner_clock',return_value={'started_monotonic':1.-owner_age_seconds,'deadline_monotonic':541.-owner_age_seconds,
                    'term_monotonic':526.-owner_age_seconds,'kill_monotonic':538.-owner_age_seconds,'checkpoint_pin':{}},create=True),
                patch.object(driver,'verify_files',side_effect=lambda *args:events.append('outer_full_pins_complete')),
                patch.object(driver,'budget',return_value={'command_deadline':541,'operator_deadline':601}),
                patch.object(driver,'pin_read',side_effect=pin),patch.object(driver,'decode',side_effect=json.loads),
                patch.object(driver,'save',side_effect=save),
                patch.object(driver,'assess_visible',side_effect=lambda *args:events.append('ordinary_oracle') or {'passed':False}),
                patch.dict(driver.os.environ,{},clear=True),
            ):
                self.assertEqual(driver.run(plan,plan_pin,human,human_pin),1)
            self.assertEqual(wrapper.FLASH_RUNTIME_SHA256,driver.NORMAL)
            self.assertIs(wrapper.live_readiness,original_readiness)
            self.assertIs(wrapper.observation,original_observation)
            self.assertFalse((output/'observations.jsonl').exists());self.assertFalse(capture.exists())
            self.assertTrue((base/'diagnostic-assessment.json').is_file())
            self.assertFalse((output/'diagnostic-assessment.json').exists())
            output_created=output.exists()
        return saved,events,clock,pin_calls,output_created

    def test_cooldown_precedes_public_clock_and_both_public_pin_edges_remain(self):
        saved,events,clock,pins,_=self.exercise()
        self.assertLess(events.index('outer_full_pins_complete'),events.index('single_cooldown'))
        self.assertLess(events.index('single_cooldown'),events.index('fresh:before_dispatch'))
        self.assertLess(events.index('single_cooldown'),events.index('wrapper_entered'))
        self.assertLess(events.index('fresh:public_readiness_before_setup'),events.index('all_wrapper_SHA_pins_complete'))
        self.assertLess(events.index('all_wrapper_SHA_pins_complete'),events.index('fresh:public_readiness_before_Popen'))
        self.assertEqual(events.count('single_cooldown'),1)
        admission=saved['admission-01.json']
        self.assertEqual((admission['initial_recovery_deadline'],admission['cooldown_deadline']),(151,271))
        span=admission['cool_readiness'][-1]['consecutive_span_seconds']
        self.assertGreaterEqual(span,60);self.assertLess(span,60+1e-9)
        self.assertAlmostEqual(clock[0],61.3);self.assertEqual(admission['public_readiness_calls'],2)
        for row in admission['native_budget_samples']:
            self.assertTrue(row['accepted']);self.assertGreaterEqual(row['working_seconds_remaining'],210)

    def test_original_owner_start_is_never_renewed_after_preparation_delay(self):
        # A540s owner that started60s before the driver still has TERM466.
        saved,events,clock,pins,output=self.exercise(cool_recover_after=190,setup_seconds=4.9,owner_age_seconds=60)
        self.assertTrue(output);self.assertIn('final_admission_returned',events)
        self.assertAlmostEqual(clock[0],255.9)
        admission=saved['admission-01.json']
        self.assertAlmostEqual(admission['native_budget_samples'][-1]['working_seconds_remaining'],210.1)
        self.assertEqual(saved['diagnostic-assessment.json']['owner_clock']['term_monotonic'],466)
        self.assertEqual(saved['diagnostic-assessment.json']['operator_clock']['command_deadline'],541)
        for setup in (5.0,5.1):
            with self.subTest(setup=setup):
                saved,events,clock,pins,output=self.exercise(cool_recover_after=190,setup_seconds=setup,owner_age_seconds=60)
                self.assertTrue(output);self.assertNotIn('final_admission_returned',events)
                self.assertIn('210s',saved['diagnostic-assessment.json']['workload_error']['message'])
                self.assertEqual(saved['admission-01.json']['final_temperature_settle']['deadline_monotonic'],256)
                self.assertFalse(saved['admission-01.json']['launched'])
        saved,events,clock,pins,output=self.exercise(cool_recover_after=200,owner_age_seconds=60)
        self.assertFalse(output);self.assertNotIn('wrapper_entered',events)
        self.assertEqual(clock[0],261)
        self.assertEqual(saved['admission-01.json']['native_budget_samples'][-1]['working_seconds_remaining'],205)
        self.assertFalse(saved['admission-01.json']['native_budget_samples'][-1]['accepted'])

    def test_recovery90s_plus60s_cooldown_does_not_reset_owner_clock(self):
        saved,events,clock,pins,output=self.exercise(recover_after=90)
        self.assertAlmostEqual(clock[0],151.3);self.assertTrue(output)
        self.assertIn('final_admission_returned',events)
        self.assertEqual(saved['admission-01.json']['native_budget_samples'][0]['working_seconds_remaining'],375)
        self.assertAlmostEqual(saved['admission-01.json']['native_budget_samples'][-1]['working_seconds_remaining'],254.7)
        self.assertEqual(saved['diagnostic-assessment.json']['operator_clock']['command_deadline'],541)
        self.assertEqual(saved['diagnostic-assessment.json']['owner_clock']['deadline_monotonic'],541)

    def test_recovery122s_then_full60s_cooldown_keeps_original_clocks(self):
        # Actual failure recovered about1.68s after the old120s initial deadline.
        # Ten-second polling sees this synthetic122s recovery at130s.
        saved,events,clock,pins,output=self.exercise(recover_after=122)
        admission=saved['admission-01.json'];report=saved['diagnostic-assessment.json']
        self.assertTrue(output);self.assertIn('final_admission_returned',events)
        self.assertEqual(admission['initial_recovery_deadline'],151)
        self.assertEqual(admission['cooldown_deadline'],271)
        self.assertEqual(admission['cool_readiness'][-1]['consecutive_span_seconds'],60)
        self.assertAlmostEqual(clock[0],191.3)
        self.assertEqual(report['operator_clock']['command_deadline'],541)
        self.assertEqual(report['owner_clock']['deadline_monotonic'],541)
        self.assertEqual(report['owner_clock']['term_monotonic'],526)
        self.assertGreaterEqual(admission['native_budget_samples'][-1]['working_seconds_remaining'],210)
        self.assertFalse(report['diagnostic_complete']);self.assertFalse(report['qualified'])

    def test_guard_warning42_recovery163_then_full60s_cooldown(self):
        # Synthetic guard journal/profile timeline; no thermal guard or host runs.
        saved,events,clock,pins,output=self.exercise(guard_spike_after=42,guard_recovered_after=163)
        admission=saved['admission-01.json'];report=saved['diagnostic-assessment.json']
        self.assertTrue(output);self.assertIn('final_admission_returned',events)
        rows=admission['cool_readiness'];bad=[r for r in rows if not r['ready_observation']]
        self.assertTrue(bad);self.assertTrue(all(r['profile']=='power-saver' for r in bad))
        self.assertTrue(all(not r['latest_message_claims_recovered'] for r in bad))
        self.assertEqual(rows[-1]['consecutive_span_seconds'],60)
        self.assertEqual(rows[-1]['finished_monotonic'],231)
        self.assertEqual(admission['initial_recovery_deadline'],151)
        self.assertEqual(admission['cooldown_deadline'],271)
        self.assertAlmostEqual(clock[0],231.3)
        self.assertEqual(events.count('single_cooldown'),1)
        self.assertEqual(admission['public_readiness_calls'],2)
        self.assertEqual(report['operator_clock']['command_deadline'],541)
        self.assertEqual(report['owner_clock']['term_monotonic'],526)
        self.assertGreaterEqual(admission['native_budget_samples'][-1]['working_seconds_remaining'],210)
        self.assertLessEqual(len(admission['host_observations']),37)
        self.assertIsNot(report.get('passed'),True);self.assertFalse(report['diagnostic_complete'])

    def test_late_or_never_guard_recovery_retains_original270s_cap(self):
        for recovered in (213,1000):
            with self.subTest(recovered=recovered):
                saved,events,clock,pins,output=self.exercise(guard_spike_after=42,guard_recovered_after=recovered)
                admission=saved['admission-01.json'];report=saved['diagnostic-assessment.json']
                self.assertFalse(output);self.assertNotIn('wrapper_entered',events)
                self.assertEqual(clock[0],271);self.assertEqual(admission['cooldown_deadline'],271)
                self.assertEqual(admission['initial_recovery_deadline'],151)
                self.assertEqual(report['operator_clock']['command_deadline'],541)
                self.assertIn('Original bounded60s',report['errors'][0]['message'])
                self.assertLessEqual(len(admission['host_observations']),37)
                self.assertEqual(events.count('single_cooldown'),1)
                self.assertFalse(report['workload_dispatch_entered']);self.assertFalse(report['native_launched'])

    def test_public_setup_consumes255s_work_clock_without_reset(self):
        saved,events,clock,pins,output=self.exercise(setup_seconds=46)
        self.assertTrue(output);self.assertNotIn('final_admission_returned',events)
        admission=saved['admission-01.json'];settle=admission['final_temperature_settle']
        self.assertAlmostEqual(settle['deadline_monotonic'],106)  # Original public255s stop316 minus210s.
        self.assertIn('210s',settle['stop_reason']);self.assertFalse(settle['accepted'])
        self.assertEqual(len(admission['native_budget_samples']),1)  # Rejected before any final helper/sample.
        self.assertEqual(len([r for r in admission['fresh_admissions'] if r['phase']=='public_readiness_before_Popen']),0)
        self.assertEqual(saved['diagnostic-assessment.json']['operator_clock']['command_deadline'],541)

    def test_never_recovered_before_wrapper_has_receipt_without_fake_public_output(self):
        saved,events,clock,pins,output=self.exercise(recover_after=1000)
        result=saved['diagnostic-assessment.json'];admission=saved['admission-01.json']
        self.assertFalse(output);self.assertNotIn('wrapper_entered',events);self.assertEqual(pins,[])
        self.assertEqual(clock[0],151);self.assertEqual(result['status'],'admission_failed')
        self.assertEqual(result['failure_phase'],'before_public_wrapper')
        self.assertFalse(result['workload_dispatch_entered']);self.assertFalse(result['native_launched'])
        self.assertFalse(result['workload_cleanup_applicable']);self.assertFalse(result['cleanup_complete'])
        self.assertFalse(result['diagnostic_complete']);self.assertFalse(result['qualified'])
        self.assertIn('Initial natural guard recovery',result['errors'][0]['message'])
        self.assertEqual(result['errors'],admission['errors'])
        self.assertEqual(admission['initial_recovery_samples'][0]['profile'],'power-saver')

    def test_initial_host_read_error_is_primary_not_missing_inner_receipt(self):
        saved,events,clock,pins,output=self.exercise(initial_change={'read_errors':{'temp':'offline failed read'}})
        result=saved['diagnostic-assessment.json']
        self.assertFalse(output);self.assertEqual(clock[0],1);self.assertEqual(pins,[])
        self.assertIn('Host observation failed',result['errors'][0]['message'])
        self.assertEqual(result['status'],'admission_failed');self.assertNotIn('wrapper_entered',events)

    def test_prelaunch_primary71C_error_preserved_without_capture_reads(self):
        saved,events,clock,pins,_=self.exercise(fresh_over70=True)
        result=saved['diagnostic-assessment.json'];admission=saved['admission-01.json']
        self.assertEqual(result['errors'][0]['type'],'ValueError');self.assertIn('Fresh<=70C',result['errors'][0]['message'])
        self.assertEqual(admission['fresh_admissions'][-1]['package_millidegrees_C'],71000)
        self.assertFalse(admission['fresh_admissions'][-1]['accepted'])
        self.assertEqual(result['workload_error'],result['errors'][0])
        self.assertFalse(admission['launched']);self.assertTrue(result['cleanup_complete'])
        self.assertFalse(result['diagnostic_complete']);self.assertFalse(result['raw_capture_complete'])
        self.assertFalse(result['qualified']);self.assertEqual(result['status'],'prelaunch_failed')
        self.assertIsNone(result['ordinary_assessment']['nearest_rank_p99_ms'])
        self.assertNotIn('ordinary_oracle',events);self.assertEqual(pins,['result.json','plan.json','human.json'])

    def test_original_budget_not_reset_by_wrapper_setup(self):
        saved,events,clock,pins,_=self.exercise(setup_seconds=170)
        self.assertEqual(saved['admission-01.json']['cooldown_deadline'],271)
        self.assertAlmostEqual(clock[0],231)
        self.assertEqual(events.count('single_cooldown'),1)
        self.assertIn('210s',saved['diagnostic-assessment.json']['workload_error']['message'])
        self.assertNotIn('final_admission_returned',events)

    def test_guard_change_after_pins_rejects_without_retry(self):
        saved,events,clock,pins,_=self.exercise(after_setup=lambda state:state.update(invocation='b'*32))
        self.assertIn('Fresh<=70C requested-profile/recovered/same-guard',saved['diagnostic-assessment.json']['workload_error']['message'])
        self.assertFalse(saved['admission-01.json']['launched']);self.assertNotIn('ordinary_oracle',events)

    def test_extra_or_wrong_scope_readiness_is_not_retry(self):
        for options,match in [({'extra_ready':True},'Public readiness call count/order differs'),
                              ({'wrong_label':True},'Fixed readiness scope differs')]:
            with self.subTest(options=options):
                saved,events,clock,pins,_=self.exercise(**options)
                self.assertIn(match,saved['diagnostic-assessment.json']['workload_error']['message'])
                self.assertLessEqual(events.count('single_cooldown'),1)

    def test_missing_capture_after_real_native_launch_remains_failure(self):
        saved,events,clock,pins,_=self.exercise(launched=True)
        result=saved['diagnostic-assessment.json'];self.assertTrue(saved['admission-01.json']['launched'])
        self.assertTrue(any(row['type']=='FileNotFoundError' for row in result['errors']))
        self.assertTrue(any('observations.jsonl' in row['message'] for row in result['errors']));self.assertIn('ordinary_oracle',events)
        self.assertFalse(result['raw_capture_complete']);self.assertFalse(result['diagnostic_complete'])
        self.assertFalse(result['qualified']);self.assertFalse(result['cleanup_complete'])

    def test_earliest_stop_is_retained_before_secondary_capture_failure(self):
        saved,events,clock,pins,_=self.exercise(launched=True,stop_reason='Native startup progress missing',
            native_error='Stop file requested graceful live cancellation')
        result=saved['diagnostic-assessment.json'];admission=saved['admission-01.json']
        primary={'type':'RuntimeError','message':'Native startup progress missing'}
        self.assertEqual(result['workload_error'],primary);self.assertEqual(result['errors'][0],primary)
        self.assertEqual(admission['errors'][0],primary)
        self.assertTrue(any(row['type']=='FileNotFoundError' for row in result['errors']))
        self.assertTrue(any('observations.jsonl' in row['message'] for row in result['errors']))
        self.assertTrue(result['native_launched']);self.assertFalse(result['diagnostic_complete'])
        self.assertFalse(result['raw_capture_complete']);self.assertFalse(result['qualified'])

    def test_failed_native_reason_precedes_wrapper_and_capture_errors(self):
        saved,events,clock,pins,_=self.exercise(launched=True,native_error='Fixture track preparation failed')
        result=saved['diagnostic-assessment.json']
        self.assertEqual(result['errors'][0],{'type':'RuntimeError','message':'Fixture track preparation failed'})
        self.assertTrue(any(row['type']=='FileNotFoundError' for row in result['errors']))
        self.assertFalse(result['diagnostic_complete']);self.assertFalse(result['raw_capture_complete'])
        self.assertFalse(result['qualified']);self.assertFalse(result['cleanup_complete'])

    def test_unproved_or_nonempty_owner_cleanup_does_not_fabricate_success(self):
        for options,launched in [({'cleanup_proven':False},None),
            ({'owner_history':[{'pid':200,'command':['/offline/unexpected']}]},False)]:
            with self.subTest(options=options):
                saved,events,clock,pins,_=self.exercise(**options)
                self.assertIs(saved['admission-01.json']['launched'],launched)
                result=saved['diagnostic-assessment.json']
                self.assertFalse(result['cleanup_complete']);self.assertFalse(result['diagnostic_complete'])
                self.assertFalse(result['qualified'])


class MeasurementTests(unittest.TestCase):
    def test_full_closed_partition_required(self):
        native={'requested_seconds':120,'measured_wall_ms':120015,
            'measurement_begin_output_frame':256,'measurement_end_output_frame':5760256,
            'measurement_intervals_closed':True,'last_recovery_complete':True,
            'intervals':[{'output_begin':256,'output_end':5760256,'frames':5760000,'aborted':False}]}
        self.assertTrue(driver.validate_measurement(native)['complete_120s'])
        for field,value in [('measured_wall_ms',5000),('measurement_intervals_closed',False),
                            ('measurement_end_output_frame',5000000)]:
            changed={**native,field:value}
            with self.assertRaises(ValueError):driver.validate_measurement(changed)
        changed=copy.deepcopy(native);changed['intervals'][0]['aborted']=True
        with self.assertRaises(ValueError):driver.validate_measurement(changed)


class NormalAssessmentTests(unittest.TestCase):
    def controls_fixture(self, functional=False):
        # Independent fixed target table. B starts selected so restoring false
        # unconditionally is a real regression, rather than a passing no-op.
        baseline = {"deck_gains": [.25, 1.], "eq_db": [[0., 0., 0.], [0., 0., 0.]],
                    "crossfader": .5, "cue_selected": [False, True], "master_gain": .25,
                    "cue_gain": 1., "stem_gains": [[1.] * 4, [0.] * 4]}
        snapshot = baseline | {"output_frame": 1000, "source_frames": [0, 10000],
            "source_lengths": [1123201, 14400000], "source_generations": [1, 2], "transport_revisions": [1, 1],
            "cue_frames": [0, 0], "cue_held": [False, False], "cue_preview": [False, False],
            "playing": [True, True], "applied": 10, "last_command_id": 10, "callbacks": 1,
            "invalid_buffers": 0, "rejected": 0, "starved": [0, 0], "read_failure": [False, False]}
        native = {"mode": "live-stems-controls", "passed": True, "cancelled": False, "shutdown_completed": True,
            "functional_only": functional, "host_audio": not functional, "requested_seconds": 10 if functional else 120,
            "ui_mode": "visible", "window_policy": "visible", "manual_controls_complete": True,
            "manual_controls_baseline": copy.deepcopy(snapshot), "manual_controls": [],
            "measurement_intervals_closed": True, "last_recovery_complete": True,
            "measured_wall_ms": 10000 if functional else 120000, "measurement_begin_output_frame": 1000,
            "measurement_end_output_frame": 481000 if functional else 5761000, "steady_starved_frames": 0,
            "starved_frames_outside_measured_intervals": 0, "invalid_buffers": 0, "rejected_commands": 0,
            "source_read_failures": 0, "execution_deadline_misses": 0, "scene_errors": [], "frames_presented": 100,
            "maximum_gui_heartbeat_gap_ns": 20000000, "maximum_frame_presentation_gap_ns": 20000000,
            "intervals": [{"kind": "steady", "starved_frames": 0}],
            "timing": [{"driver_position_observed": True, "driver_position_discontinuities": 0,
                        "driver_recovery_flags": 0, "graph_quantum_min": 256, "graph_quantum_max": 256}]}
        for deck in range(2):
            targets = (("gain", .125 if deck == 0 else .5), ("gain", baseline["deck_gains"][deck]),
                       ("cross", .25 if deck == 0 else .75), ("cross", .5), ("eq", -6.5), ("eq", 0.),
                       ("cue", not baseline["cue_selected"][deck]), ("cue", baseline["cue_selected"][deck]))
            for step, (action, target) in enumerate(targets):
                index = deck * 8 + step
                due = ((7000 if deck else 500) + step * 100 if functional else
                       (70000 if deck else 10000) + step * 2000)
                before = copy.deepcopy(snapshot)
                before["output_frame"] = 1000 + due * 48
                before["source_frames"] = [(due % 23000) * 48, 10000 + due * 48]
                ack = copy.deepcopy(before)
                if action == "gain": ack["deck_gains"][deck] = target
                elif action == "cross": ack["crossfader"] = target
                elif action == "eq": ack["eq_db"][deck][2] = target
                else: ack["cue_selected"][deck] = target
                ack["output_frame"] += 256; ack["source_frames"] = [x + 256 for x in before["source_frames"]]
                ack["applied"] += 1; ack["last_command_id"] += 1; ack["callbacks"] += 1
                name = {"gain": f"deck{deck}Gain", "cross": "crossfader", "eq": f"deck{deck}EqHI", "cue": f"deck{deck}CueSelect"}[action]
                issued = 1000000000 + due * 1000000
                native["manual_controls"].append({"index": index, "deck": deck, "step": step, "object": name,
                    "due_ms": due, "issued_elapsed_ms": due, "issued_ns": issued, "ack_poll_ns": issued + 20000000,
                    "acknowledged": True, "before": before, "ack": ack, "expected": copy.deepcopy(ack),
                    "expected_command": ack["last_command_id"], "session_before": 0, "session_after": 0,
                    "presented_before": index, "presented_after": index + 1,
                    "ui_value": (.375 if target == -6.5 else .5) if action == "eq" else target})
                snapshot = ack
        observations = {"service_metrics_complete": True, "service_hops": {"complete": True, "count": 21,
                        "nearest_rank_p99_ms": 3012.7}, "kind_counts": {"ChunkValidated": 21},
                        "chunk_phases": {"fields": {key: {"present_for_all_chunks": True, "count": 21}
                                                     for key in controls_wrapper.LIVE_PHASE_NAMES}}}
        return native, observations

    def result_fixture(self):
        native,observations=self.controls_fixture()
        native.update(source_root='/offline/merged-source',error='',
            observation_counters={'producer_finished':True,'attempted':21,'retained':21,'dropped':0,'invalid_clock_reads':0},
            ui_coverage={'checks':20,'visible_healthy_checks':20,'any_gap':False,'visible_ui_qualification_eligible':True,
                'missing_window_checks':0,'hidden_checks':0,'unexposed_checks':0,'stale_frame_checks':0,'missing_frame_checks':0},
            recording={'status':'Complete','error':'','active':False,'overflowFrames':0,'acceptedFrames':5760000,'writtenFrames':5760000},
            recorded_audio={'frames':5760000,'sample_rate':48000,'channels':2})
        for interval in native['intervals']:interval['starved_b']=0
        values=[3000.]*21
        observations['service_hops'].update(nearest_rank_p99_ms=3000.,maximum_ms=3000.,at_or_above_target=0,strict_target_ms=4095)
        observations['chunk_phases']['hops']=[{'hop_service_ms':v,**{k:1. for k in driver.PHASES}} for v in values]
        observations['service_telemetry_loss']=[{'kind':'ServiceClosed','dropped':0}]
        result={'passed':True,'native_exit':0,'stop_reason':None,'qualified':False,'ui_mode':'visible','visible_ui_required':True,
            'within_wall_budget':True,'wall_budget_seconds':300,'pins_unchanged':True,'pins_before':{'fixture':'same'},'pins_after':{'fixture':'same'},
            'guard_before':{'fixture':'same'},'guard_after':{'fixture':'same'},'native':native,'observations':observations,
            'cleanup_proven':True,'owned_cache_removed':True,'cache_preserved':False,
            'cleanup':{'ownership_complete':True,'leader_reaped':True,'cooperative_native_shutdown':True,'engine_processes_observed':True,
                'remaining_known_processes':[],'remaining_live_jobs':[],'remaining_pipewire_count':0,'ownership_failure_count':0,
                'owned_group_absent':{'200':True},'ownership_failure_overflow':False},
            'capture':{'stdout':{'complete':True},'stderr':{'complete':True}},
            'power_before':{'ac_online':True,'lid_open':True},'power_after':{'ac_online':True,'lid_open':True}}
        result['active_controls']=controls_wrapper.validate_active_controls(native,observations)
        return result

    def assess(self,result):
        with patch.object(driver,'W',Path('/offline/merged-source')):
            return driver.assess_visible(result,controls_wrapper)

    def test_real_validator_keeps_all16_actions_and_normal_visible_health(self):
        result=self.result_fixture();verdict=self.assess(result)
        self.assertTrue(verdict['passed']);self.assertFalse(verdict['qualified'])
        self.assertEqual((verdict['hop_count'],verdict['nearest_rank_p99_ms']),(21,3000.))
        self.assertEqual(len(result['native']['manual_controls']),16)
        self.assertTrue(result['native']['manual_controls'][-1]['ack']['cue_selected'][1])

    def test_missing_ack_or_wrong_workload_cannot_pass(self):
        for mutation in (lambda r:r['native']['manual_controls'].pop(),
                lambda r:r['native']['manual_controls'][0].update(acknowledged=False),
                lambda r:r['native'].update(mode='live-stems'),
                lambda r:r.update(ui_mode='background'),
                lambda r:r['native'].update(ui_mode='background'),
                lambda r:r.update(active_controls={})):
            result=self.result_fixture();mutation(result)
            self.assertFalse(self.assess(result)['passed'])

    def test_strict4095_all13_loss_and_mix_interval_audio_checks_are_preserved(self):
        mutations=(lambda r:r['observations']['chunk_phases']['fields'].pop(driver.PHASES[0]),
            lambda r:r['observations']['service_telemetry_loss'][0].update(dropped=1),
            lambda r:r['native'].update(steady_starved_frames=1),
            lambda r:r['native']['intervals'][0].update(kind='manual_controls',starved_frames=256),
            lambda r:r['native']['timing'][0].update(driver_recovery_flags=1),
            lambda r:r['native']['recording'].update(overflowFrames=1),
            lambda r:r['cleanup'].update(ownership_complete=False),
            lambda r:r['native']['ui_coverage'].update(unexposed_checks=1,any_gap=True))
        for mutation in mutations:
            result=self.result_fixture();mutation(result)
            self.assertFalse(self.assess(result)['passed'])
        result=self.result_fixture()
        for row in result['observations']['chunk_phases']['hops']:row['hop_service_ms']=4095.
        result['observations']['service_hops'].update(nearest_rank_p99_ms=4095.,maximum_ms=4095.,at_or_above_target=21)
        verdict=self.assess(result);self.assertFalse(verdict['passed']);self.assertFalse(verdict['service_target_met'])

    def test_draft_source_binding_is_unarmed_before_file_or_readiness_access(self):
        with patch.object(driver,'W',None), patch.object(driver,'pin_read',side_effect=AssertionError('No assets/readiness may be read')):
            with self.assertRaisesRegex(ValueError,'Merged source/build bindings are absent'):
                driver.validate_plan(json.loads(driver.PLAN.read_bytes()))


class _OuterStdoutBudget:
    """Fixed256KiB owner contract, counting real Python writes without buffering."""
    def __init__(self):self.bytes_received=0
    def write(self,value):
        self.bytes_received+=len(value.encode('utf-8'))
        if self.bytes_received>256*1024:raise RuntimeError('Fixture outer stdout limit exceeded')
        return len(value)
    def flush(self):pass


class CompletedRunCaptureTests(unittest.TestCase):
    def exercise(self,mutation=None,*,emit_summary=False,capture_payload=b'',real_capture=False,wrapper_exception=None,
                 renderer=None,inherited_renderer=None,postrun_changed=False):
        plan,clock,state,timing,helpers=AdmissionTests.setup_mock(self,temp=33000)
        capture_helper=driver.utility() if real_capture else None
        capture_reads=[]
        capture_clock=patch.object(capture_helper,'time',timing) if capture_helper else contextlib.nullcontext()
        result=NormalAssessmentTests().result_fixture()
        result.update(requested_seconds=120,owned_direct_group=200,command=['/offline/native'])
        result['cleanup'].update(runtime_processes=[{'pid':201,'start_ticks':2}],service_processes=[{'pid':202,'start_ticks':3}])
        plan['requested_qt_quick_backend']=renderer
        result['native']['quick_backend_environment']=renderer or ''
        result['native']['setup']={'runtime_sha256':driver.RUNTIME_SHA,'model_sha256':driver.MODEL,'input_frames':1031940,'output_frames':1123201}
        result['native']['configuration']=dict(backend='vulkan',threads=2,request_timeout_seconds=30,
            prime_bound_seconds=60,deck_a_gain=.25,deck_b_gain=1,master_gain=.25,stem_gains=[1,1,1,1])
        result['native']['intervals'][0].update(output_begin=1000,output_end=5761000,frames=5760000,aborted=False)
        wrapper=SimpleNamespace(FLASH_RUNTIME_SHA256=driver.NORMAL,FLASH_MODEL_SHA256=driver.MODEL,
            observation=lambda *_:{'fixture':True},validate_active_controls=controls_wrapper.validate_active_controls)
        oracle=SimpleNamespace(environment_contract=lambda env:None)
        with tempfile.TemporaryDirectory() as directory:
            base=Path(directory);output=base/'output-01';human_path=base/'readiness.json';plan_path=base/'plan.json'
            human={'fixture':'offline-only'};human_path.write_text(json.dumps(human));plan_path.write_text(json.dumps(plan))
            def pin(path,*args,**kwargs):
                path=Path(path)
                if capture_helper and path.name in ('native.stdout.log','native.stderr.log'):
                    if args and args[0] is not None:capture_reads.append(path.name)
                    return capture_helper.pin_read(path,*args,**kwargs)
                raw=path.read_bytes()
                value={'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
                if args and args[0] is not None and value!=args[0]:raise ValueError('Fixture pin differs')
                return value,raw
            human_pin=pin(human_path)[0];plan_pin=pin(plan_path)[0]
            def readiness(path,label,background=False):
                self.assertFalse(background);return {'record':human,'pin':human_pin}
            wrapper.live_readiness=readiness
            def workload(args):
                self.assertTrue(args.active_controls);self.assertFalse(args.background)
                self.assertEqual(wrapper.FLASH_RUNTIME_SHA256,driver.RUNTIME_SHA)
                self.assertFalse(any(k.startswith(('CONFLUX_DRM_','CONFLUX_REQUEST_TRACE_')) for k in driver.os.environ))
                if wrapper_exception:
                    print('fixture wrapper stdout before exception')
                    raise RuntimeError(wrapper_exception)
                output.mkdir();wrapper.live_readiness(args.readiness_decision,'output-01',background=False)
                clock[0]+=.3
                wrapper.live_readiness(args.readiness_decision,'output-01',background=False)
                clock[0]+=120
                result['capture']={}
                for name in ('stdout','stderr'):
                    path=output/('native.'+name+'.log');path.write_bytes(capture_payload)
                    actual=pin(path)[0];value={k:actual[k] for k in ('path','bytes','sha256')}
                    result['capture'][name]={'retained_file':value,'complete':True,'bytes_received':len(capture_payload),'sha256_received':value['sha256']}
                rows=[{'type':'record','hop_service_present':True,**row} for row in result['observations']['chunk_phases']['hops']]
                (output/'observations.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in rows))
                if mutation:mutation(output,result)
                if emit_summary:result['fixture_saved_summary_padding']='x'*(272*1024)
                rendered=json.dumps(result,indent=2 if emit_summary else None)
                (output/'result.json').write_text(rendered)
                if emit_summary:
                    print('fixture wrapper stderr remains visible',file=sys.stderr)
                    print(rendered) # Real print of the same fully saved JSON, larger than owner cap.
                return 0 if result['passed'] else 1
            wrapper.run_live=workload
            def load(name,*args):
                if name=='private_host_player_oracle':return oracle
                if name=='private_host_player_workload':return wrapper
                return helpers(name,*args)
            def save(path,value):path.write_text(json.dumps(value))
            def verify(plan,deadline):
                if postrun_changed and (output/'result.json').exists():raise ValueError('fixture frozen input changed')
            with (patch.object(driver,'capture_process_cpu',return_value={'fixture':True}),patch.object(driver,'BASE',base),patch.object(driver,'PLAN',plan_path),patch.object(driver,'OUTPUT',output),
                  patch.object(driver,'HUMAN',human_path),patch.object(driver,'W',Path('/offline/merged-source')),
                  patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing),
                  patch.object(driver,'verify_files',side_effect=verify),patch.object(driver,'pin_read',side_effect=pin),
                  patch.object(driver,'read_owner_clock',return_value={'started_monotonic':1.,'deadline_monotonic':541.,
                      'term_monotonic':526.,'kill_monotonic':538.,'checkpoint_pin':{}},create=True),
                  patch.object(driver,'decode',side_effect=json.loads),patch.object(driver,'save',side_effect=save),
                  patch.object(driver,'budget',return_value={'command_deadline':541,'operator_deadline':601}),
                  patch.dict(driver.os.environ,{} if inherited_renderer is None else {'QT_QUICK_BACKEND':inherited_renderer},clear=True),capture_clock):
                code=driver.run(plan,plan_pin,human,human_pin)
            self.assertIs(wrapper.live_readiness,readiness);self.assertEqual(wrapper.FLASH_RUNTIME_SHA256,driver.NORMAL)
            report=json.loads((base/'diagnostic-assessment.json').read_text())
            if capture_helper and report.get('raw_capture_complete'):
                self.assertEqual(capture_reads,['native.stdout.log','native.stderr.log'])
                for name in ('stdout','stderr'):self.assertEqual((output/('native.'+name+'.log')).read_bytes(),capture_payload)
            return code,report

    def test_saved_oversized_summary_does_not_consume_owner_stdout_or_mask_native_failure(self):
        primary='fixture native last replay recovery incomplete'
        def failed_native(output,result):
            result.update(passed=False,error='Active controls: incomplete/wrong mode')
            result['native'].update(passed=False,error=primary,last_recovery_complete=False)
        for failure in (False,True):
            with self.subTest(native_failure=failure):
                outer=_OuterStdoutBudget();stderr=io.StringIO()
                with contextlib.redirect_stdout(outer),contextlib.redirect_stderr(stderr):
                    code,report=self.exercise(failed_native if failure else None,emit_summary=True,
                        capture_payload=b'actual retained native bytes\n',real_capture=True)
                    self.assertIs(sys.stdout,outer);self.assertEqual(outer.bytes_received,0)
                    print('stdout restored')
                self.assertEqual(outer.bytes_received,len('stdout restored\n'))
                self.assertEqual(stderr.getvalue(),'fixture wrapper stderr remains visible\n')
                self.assertGreater(report['workload_result_pin']['bytes'],256*1024)
                self.assertTrue(report['raw_capture_complete']);self.assertFalse(report['qualified'])
                if failure:
                    self.assertEqual(code,1);self.assertFalse(report['diagnostic_complete'])
                    self.assertEqual(report['workload_error']['message'],primary)
                    self.assertEqual(report['errors'][0]['message'],primary)
                    self.assertFalse(report['ordinary_assessment']['functional_passed'])
                else:
                    self.assertEqual(code,0);self.assertTrue(report['diagnostic_complete'])
                    self.assertTrue(report['passed']);self.assertTrue(report['cleanup_complete'])
        with self.subTest(wrapper_exception=True):
            outer=_OuterStdoutBudget()
            with contextlib.redirect_stdout(outer):
                code,report=self.exercise(wrapper_exception='fixture wrapper failure')
                self.assertIs(sys.stdout,outer);self.assertEqual(outer.bytes_received,0)
                print('exception stdout restored')
            self.assertEqual(outer.bytes_received,len('exception stdout restored\n'))
            self.assertEqual(code,1);self.assertFalse(report['diagnostic_complete'])
            self.assertIn('fixture wrapper failure',report['errors'][0]['message'])

    def test_real_pin_helper_nonempty_capture_identity_and_integrity(self):
        real=driver.utility() # Exact frozen stdlib helper, not the three-field test double.
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'native.stdout.log';payload=b'bounded normal native output\n';path.write_bytes(payload)
            expected={'path':str(path),'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}
            row={'retained_file':expected,'complete':True,'bytes_received':len(payload),'sha256_received':expected['sha256']}
            with patch.object(driver,'pin_read',wraps=real.pin_read):
                with self.subTest(case='valid_nonempty_with_real_identity'):
                    actual=driver.verify_capture(path,row,float('inf'))
                    self.assertEqual({k:actual[k] for k in ('path','bytes','sha256')},expected)
                    self.assertEqual(len(actual['identity']),5)
                for field,value in (('bytes',len(payload)+1),('sha256','0'*64)):
                    with self.subTest(case='wrong_'+field):
                        bad=copy.deepcopy(row);bad['retained_file'][field]=value
                        if field=='bytes':bad['bytes_received']=value
                        else:bad['sha256_received']=value
                        with self.assertRaises(ValueError):driver.verify_capture(path,bad,float('inf'))
                with self.subTest(case='symlink'):
                    link=Path(directory)/'capture-link';link.symlink_to(path)
                    bad=copy.deepcopy(row);bad['retained_file']['path']=str(link)
                    with self.assertRaises(ValueError):driver.verify_capture(link,bad,float('inf'))

    def test_both_renderer_requests_reach_native_and_mismatch_remains_failed(self):
        for requested,inherited in ((None,None),('software','software')):
            with self.subTest(requested=requested):
                code,report=self.exercise(renderer=requested,inherited_renderer=inherited)
                self.assertEqual(code,0);self.assertTrue(report['diagnostic_complete'])
                self.assertEqual(report['requested_qt_quick_backend'],requested)
                self.assertEqual(report['inherited_environment']['QT_QUICK_BACKEND'],inherited)
                self.assertEqual(report['native_quick_backend_environment'],requested or '')
                self.assertFalse(report['qualified'])
        code,report=self.exercise(lambda output,result:result['native'].update(quick_backend_environment=''),
            renderer='software',inherited_renderer='software')
        self.assertEqual(code,1);self.assertFalse(report['diagnostic_complete'])
        self.assertIn('Native Qt Quick backend environment differs',report['errors'][0]['message'])
        self.assertFalse(report['qualified'])

    def test_failed_measurement_retains_cleanup_and_postrun_frozen_inputs_separately(self):
        def stopped(output,result):
            result['passed']=False
            result['native'].update(passed=False,error='fixture cancelled at56s',measured_wall_ms=56411)
        code,report=self.exercise(stopped)
        self.assertEqual(code,1);self.assertFalse(report['diagnostic_complete'])
        self.assertTrue(report['raw_capture_complete']);self.assertTrue(report['cleanup_complete'])
        self.assertTrue(report['post_run_frozen_inputs_unchanged'])
        self.assertEqual(report['errors'][0]['message'],'fixture cancelled at56s')
        self.assertTrue(any('Completed120s' in row['message'] for row in report['errors']))
        self.assertFalse(report.get('passed',False));self.assertFalse(report['qualified'])

    def test_failed_measurement_still_detects_postrun_input_change_or_ambiguous_cleanup(self):
        for changed,ambiguous in ((True,False),(False,True)):
            def stopped(output,result):
                result['native']['measured_wall_ms']=56411
                if ambiguous:result['cleanup']['owned_group_absent']['200']=False
            code,report=self.exercise(stopped,postrun_changed=changed)
            self.assertEqual(code,1);self.assertFalse(report['diagnostic_complete'])
            self.assertEqual(report['cleanup_complete'],not ambiguous)
            self.assertEqual(report['post_run_frozen_inputs_unchanged'],not changed)
            if changed:self.assertTrue(any('fixture frozen input changed' in row['message'] for row in report['errors']))
            self.assertFalse(report.get('passed',False));self.assertFalse(report['qualified'])

    def test_actual_run_accepts_exact_empty_standard_captures(self):
        code,report=self.exercise()
        self.assertEqual(code,0);self.assertTrue(report['diagnostic_complete']);self.assertTrue(report['passed'])
        self.assertTrue(report['raw_capture_complete']);self.assertTrue(report['cleanup_complete'])
        self.assertFalse(report['qualified']);self.assertEqual(report['ordinary_assessment']['hop_count'],21)

    def test_actual_run_rejects_capture_bytes_hash_missing_or_symlink(self):
        def symlink(output,result):
            path=output/'native.stdout.log';path.unlink();path.symlink_to(output/'native.stderr.log')
        for mutation in (lambda output,result:(output/'native.stdout.log').write_bytes(b'x'),
                lambda output,result:result['capture']['stdout'].update(sha256_received='f'*64),
                lambda output,result:(output/'native.stderr.log').unlink(),symlink):
            code,report=self.exercise(mutation)
            self.assertEqual(code,1);self.assertFalse(report['diagnostic_complete']);self.assertFalse(report['cleanup_complete'])
            self.assertTrue(report['errors']);self.assertFalse(report['qualified'])



class FinalAdmissionSettlingTests(unittest.TestCase):
    exercise=ReportingAndOrderingTests.exercise

    def test_brief79C_final_pair_settles_without_renewal(self):
        for sensor in ('observed_temps','capture_temps'):
            with self.subTest(sensor=sensor):
                saved,events,clock,pins,_=self.exercise(after_setup=lambda state:state.update(
                    **{sensor:[79000,50000]},observed_temp=50000))
                self.assertIn('final_admission_returned',events)
                admission=saved['admission-01.json']
                pairs=[r for r in admission['fresh_admissions'] if r['phase']=='public_readiness_before_Popen']
                self.assertEqual(len(pairs),2);self.assertFalse(pairs[0]['accepted']);self.assertTrue(pairs[1]['accepted'])
                self.assertEqual(pairs[0]['rejection_kind'],'temperature_only')
                self.assertIn('79',pairs[0]['rejection']['message'])
                self.assertEqual(pairs[1]['settle_attempt'],2)
                self.assertLessEqual(clock[0]-61.3,5)
                self.assertEqual(events.count('single_cooldown'),1)
                self.assertEqual(admission['public_readiness_calls'],2)
                self.assertEqual(admission['native_budget_samples'][-1]['minimum_working_seconds'],210)
                self.assertGreaterEqual(admission['native_budget_samples'][-1]['working_seconds_remaining'],210)
                self.assertEqual(saved['diagnostic-assessment.json']['operator_clock']['command_deadline'],541)
                self.assertEqual(admission['cooldown_deadline'],271)

    def test_sustained_final_heat_stays_failed_and_bounded(self):
        saved,events,clock,pins,_=self.exercise(after_setup=lambda state:state.update(observed_temp=79000))
        self.assertNotIn('final_admission_returned',events)
        admission=saved['admission-01.json'];result=saved['diagnostic-assessment.json']
        pairs=[r for r in admission['fresh_admissions'] if r['phase']=='public_readiness_before_Popen']
        self.assertGreaterEqual(len(pairs),1);self.assertLessEqual(len(pairs),6)
        self.assertTrue(all(not r['accepted'] and r['rejection_kind']=='temperature_only' for r in pairs))
        self.assertLessEqual(clock[0]-61.3,5+1e-9)
        self.assertIn('heat-only',result['workload_error']['message'])
        self.assertFalse(admission['launched']);self.assertTrue(result['cleanup_complete'])
        self.assertFalse(result['diagnostic_complete']);self.assertFalse(result['qualified'])

    def test_hot_pair_never_waits_on_fatal_or_invalid_conditions(self):
        cases=[('invocation','b'*32),('guard_start',2),('profile','power-saver'),('holds','fixture-hold'),
            ('recovered',False),('epp','power'),('platform','low-power'),('ac',False),('lid',False),
            ('read_errors',{'temperature':'read failed'}),('observer_errors',[{'error':'read failed'}]),
            ('observed_temp',None),('temp',None)]
        for key,value in cases:
            with self.subTest(key=key):
                saved,events,clock,pins,_=self.exercise(after_setup=lambda state:state.update(observed_temp=79000,**{key:value})
                    if key!='observed_temp' else state.update(observed_temp=value))
                self.assertNotIn('final_admission_returned',events)
                pairs=[r for r in saved['admission-01.json']['fresh_admissions'] if r['phase']=='public_readiness_before_Popen']
                self.assertEqual(len(pairs),1);self.assertEqual(pairs[0]['rejection_kind'],'fatal')
                self.assertAlmostEqual(clock[0],61.3)
                self.assertFalse(saved['admission-01.json']['launched'])

    def test_settling_cannot_spend_the_original210s_reserve(self):
        saved,events,clock,pins,_=self.exercise(setup_seconds=44.5,
            after_setup=lambda state:state.update(observed_temps=[79000,50000]))
        self.assertNotIn('final_admission_returned',events)
        self.assertLessEqual(clock[0],106)
        self.assertIn('210s',saved['diagnostic-assessment.json']['workload_error']['message'])
        self.assertEqual(saved['diagnostic-assessment.json']['operator_clock']['command_deadline'],541)
        self.assertFalse(saved['admission-01.json']['launched'])

    def test_final_host_command_timeout_uses_one_absolute_settle_cutoff(self):
        plan,clock,state,timing,load=AdmissionTests.setup_mock(self,temp=50000);report={};timeouts=[]
        owner=load('fixture_owner');original_guard=owner.guard_identity
        def command(argv,timeout=3):
            timeouts.append(timeout);clock[0]+=timeout
        owner.read_command=command
        def guard(*args):
            if state.get('final'):owner.read_command(['offline-only'],timeout=3)
            return original_guard(*args)
        owner.guard_identity=guard
        with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
            fresh,recovery,cooldown=driver.prepare_admission(plan,report,361,1,lambda:None)
            recovery();state.update(final=True,observed_temps=[79000,50000])
            with self.assertRaisesRegex(ValueError,'heat-only'):
                fresh('public_readiness_before_Popen')
        self.assertEqual(timeouts,[3,1])
        self.assertEqual(clock[0],6)
        self.assertIs(owner.read_command,command)



class PowerCapIntegrationTests(unittest.TestCase):
    def raised(self):
        values=copy.deepcopy(driver.CAP_CEILINGS)
        key=next(p for p in values if 'intel-rapl-mmio' in p and p.endswith('constraint_0_power_limit_uw'))
        values[key]=64000000
        return values

    def test_raised_cap_prevents_public_workload_entry(self):
        helper=ReportingAndOrderingTests(methodName='runTest')
        with patch.object(driver,'read_power_caps',return_value=self.raised()):
            saved,events,_,_,output=helper.exercise()
        self.assertNotIn('wrapper_entered',events)
        report=saved['diagnostic-assessment.json']
        self.assertFalse(report['diagnostic_complete'])
        self.assertIn('Configured power cap increased',report['errors'][0]['message'])
        self.assertEqual(report['configured_power_cap_snapshots'][0]['values'],self.raised())
        self.assertTrue(report['power_caps_failed'])

    def test_public_monitor_retains_violation_and_restores_module_hooks(self):
        helper=ReportingAndOrderingTests(methodName='runTest');state={'high':False}
        def caps():return self.raised() if state['high'] else copy.deepcopy(driver.CAP_CEILINGS)
        with patch.object(driver,'read_power_caps',side_effect=caps):
            saved,events,_,_,_=helper.exercise(before_monitor=lambda:state.update(high=True))
        self.assertIn('wrapper_entered',events)
        self.assertNotIn('public_cap_monitor_returned',events)
        report=saved['diagnostic-assessment.json']
        self.assertFalse(report['diagnostic_complete'])
        monitor=[r for r in report['configured_power_cap_snapshots'] if r['phase']=='public_host_monitor']
        self.assertEqual(len(monitor),1)
        self.assertEqual(monitor[0]['values'],self.raised())
        self.assertIn('Configured power cap increased',report['workload_error']['message'])

if __name__=='__main__':unittest.main()
