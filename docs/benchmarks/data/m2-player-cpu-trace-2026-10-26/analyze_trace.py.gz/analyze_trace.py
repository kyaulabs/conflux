from pathlib import Path
from array import array
import hashlib
import json
import math
import statistics
import struct
import sys

P = Path(__file__).resolve().parent
def read(name): return json.loads((P / name).read_text())
def save(name, value): (P / name).write_text(json.dumps(value, indent=2) + '\n')
def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

wrapper = read('output-01/result.json')
native = wrapper['native']
assessment = read('diagnostic-assessment.json')
closure = read('root-finished-01.json')
assert closure['cleanup_complete'] and assessment['diagnostic_complete']
observations = [json.loads(line) for line in (P / 'output-01/observations.jsonl').read_text().splitlines()]
hops = [r for r in observations if r.get('hop_service_present')]
times = [r['hop_service_ms'] for r in hops]
phases = ('source_read_ms', 'request_ms', 'overlap_ms', 'native_elapsed_ms', 'native_inference_wall_ms',
          'native_inference_cpu_ms', 'native_frontend_ms', 'native_graph_ms', 'native_graph_upload_ms',
          'native_graph_compute_ms', 'native_graph_readback_ms', 'native_postprocess_ms', 'native_graph_rebuild_ms')
assert len(hops) == 21 and max(times) == assessment['ordinary_assessment']['nearest_rank_p99_ms']
assert max(times) < 4095
assert all(all(k in h and math.isfinite(h[k]) and h[k] >= 0 for k in phases) for h in hops)

wav_path = P / 'output-01/master.wav'
wav = wav_path.read_bytes()
assert wav[:4] == b'RIFF' and wav[8:12] == b'WAVE' and int.from_bytes(wav[4:8], 'little') + 8 == len(wav)
offset = 12; chunks = {}; data = None
while offset + 8 <= len(wav):
    kind = wav[offset:offset + 4]; size = int.from_bytes(wav[offset + 4:offset + 8], 'little')
    start = offset + 8; assert start + size <= len(wav)
    chunks[kind.decode('ascii')] = {'start': start, 'bytes': size}
    if kind == b'fmt ': fmt = struct.unpack_from('<HHIIHH', wav, start)
    if kind == b'data': data = wav[start:start + size]
    offset = start + size + (size & 1)
assert offset == len(wav) and fmt[0] == 3 and fmt[1] == 2 and fmt[2] == 48000 and fmt[5] == 32
assert data is not None and len(data) % 8 == 0
samples = array('f'); samples.frombytes(data)
if sys.byteorder != 'little': samples.byteswap()
assert all(math.isfinite(x) for x in samples)
frames = len(samples) // 2
nonzero = sum(x != 0 for x in samples)
peaks = [max(map(abs, samples[c::2]), default=0) for c in (0, 1)]
expected = native['recorded_audio']; writer = native['recording']
assert frames == expected['frames'] == writer['acceptedFrames'] == writer['writtenFrames']
assert nonzero == expected['nonzero_samples'] and peaks == [expected['peak_left'], expected['peak_right']]
assert writer['overflowFrames'] == 0
recovery = [{'kind': c['kind'], 'seconds': (c['recovered_cursor_observed_ns'] - c['issued_ns']) / 1e9}
            for c in native['controls']]
audio = {'schema': 1, 'qualified': False,
    'scope': 'Short instrumented trace and saved WAV integrity only; no sustained, native executing-GPU preemption, physical output-latency or new listening qualification.',
    'measured_wall_ms': native['measured_wall_ms'], 'service_hops': len(hops),
    'service_median_ms': statistics.median(times), 'service_nearest_rank_p99_and_maximum_ms': max(times),
    'hops_at_or_above_4095_ms': sum(x >= 4095 for x in times), 'all13_service_fields_complete': True,
    'steady_starved_frames': native['steady_starved_frames'], 'control_starved_frames': native['control_starved_frames'],
    'control_starved_seconds': native['control_starved_frames'] / 48000,
    'peer_starved_frames': sum(i['starved_b'] for i in native['intervals']),
    'control_recovery_poll_upper_seconds': recovery,
    'manual_controls': len(native['manual_controls']),
    'manual_control_acknowledgements': sum(c['acknowledged'] for c in native['manual_controls']),
    'callback_execution_deadline_misses': native['execution_deadline_misses'],
    'invalid_buffers': native['invalid_buffers'], 'rejected_commands': native['rejected_commands'],
    'source_read_failures': native['source_read_failures'], 'driver_timing': native['timing'],
    'UI': native['ui_coverage'], 'WAV': {**pin(wav_path), 'frames': frames, 'samples': len(samples),
        'all_samples_finite': True, 'nonzero_samples': nonzero, 'peaks': peaks, 'sample_rate': 48000,
        'channels': 2, 'matches_native_counts_and_peaks': True, 'recording_overflow_frames': 0},
    'thermal_summary': wrapper['thermal_summary'],
    'worst_chunk': max(hops, key=lambda h: h['hop_service_ms'])}
save('root-audio-results-01.json', audio)

host = [json.loads(line) for line in (P / 'output-01/host-observations.jsonl').read_text().splitlines()]
processes = {}; scan_costs = []; hot = []
for observation in host:
    trace = observation['process_cpu_read_only']; hz = trace['ticks_per_second']
    scan_costs.append({'cpu_ns': trace['scan_thread_cpu_ns'],
                       'wall_ns': trace['finished_monotonic_ns'] - trace['began_monotonic_ns']})
    for row in trace['processes']:
        key = (row['pid'], row['start_ticks'])
        e = processes.setdefault(key, {'pid': row['pid'], 'start_ticks': row['start_ticks'], 'comm': row['comm'],
            'first_ticks': row['cpu_ticks'], 'last_ticks': row['cpu_ticks'], 'first_ns': row['observed_monotonic_ns'],
            'last_ns': row['observed_monotonic_ns'], 'max_observed_threads': 0, 'peak_observed_interval_cpu_cores': 0,
            'ticks_per_second': hz})
        assert hz == e['ticks_per_second']
        e['last_ticks'] = row['cpu_ticks']; e['last_ns'] = row['observed_monotonic_ns']
        e['max_observed_threads'] = max(e['max_observed_threads'], row['threads'])
        e['peak_observed_interval_cpu_cores'] = max(e['peak_observed_interval_cpu_cores'],
                                                  row['cpu_cores_since_previous_observation'] or 0)
    peak = max(observation['temperatures_millidegrees_C'].values())
    if peak >= 85000:
        top = sorted(trace['processes'], key=lambda r: r['cpu_cores_since_previous_observation'] or 0, reverse=True)[:6]
        hot.append({'at_utc': observation['at_utc'], 'monotonic_ns': observation['monotonic_ns'],
            'maximum_temperature_C': peak / 1000,
            'top_process_intervals': [{k: r[k] for k in ('pid', 'comm', 'threads', 'cpu_cores_since_previous_observation')} for r in top]})
for e in processes.values():
    e['observed_span_cpu_seconds'] = (e['last_ticks'] - e['first_ticks']) / e['ticks_per_second']
    e['observed_span_wall_seconds'] = (e['last_ns'] - e['first_ns']) / 1e9
    e['last_observed_total_CPU_seconds_since_process_birth'] = e['last_ticks'] / e['ticks_per_second']
ordered = sorted(processes.values(), key=lambda r: r['observed_span_cpu_seconds'], reverse=True)
journal = read('root-guard-journal-01.json')
warnings = [r for r in journal['records'] if 'warning:' in r.get('MESSAGE', '')]
guard_context = None
if warnings:
    ns = min(int(r['__MONOTONIC_TIMESTAMP']) * 1000 for r in warnings)
    guard_context = {'first_warning_monotonic_ns': ns,
        'validated_hops_after_first_warning': sum(h['validated_ns'] >= ns for h in hops),
        'measured_loop_end_minus_first_warning_seconds': (native['diagnostic_tail']['begin_ns'] - ns) / 1e9,
        'scope': 'Validation event stamps and measured-loop boundary only; no exclusive GPU ownership or causal thermal claim.'}
cpu = {'schema': 1, 'qualified': False, 'host_observations': len(host),
    'scope': 'Process totals across threads. Observed-span CPU changes exclude work before first/after last observation; missing processes or samples can omit work. Thread counts and interval peaks are sampled, not continuous maxima. Same PID/start-ticks required for rates. No causal attribution or prior-run CPU reconstruction.',
    'observer': {'total_thread_cpu_seconds': sum(x['cpu_ns'] for x in scan_costs) / 1e9,
        'mean_thread_cpu_ms_per_observation': statistics.mean(x['cpu_ns'] for x in scan_costs) / 1e6,
        'maximum_thread_cpu_ms_per_observation': max(x['cpu_ns'] for x in scan_costs) / 1e6,
        'maximum_scan_wall_ms': max(x['wall_ns'] for x in scan_costs) / 1e6},
    'processes_by_observed_span_cpu': ordered, 'hot_observations': hot,
    'guard_context': guard_context, 'guard_messages': [r['MESSAGE'] for r in journal['records']],
    'inputs': [pin(P / n) for n in ('analyze_trace.py', 'output-01/host-observations.jsonl',
        'output-01/observations.jsonl', 'output-01/result.json', 'root-guard-journal-01.json')]}
save('root-cpu-analysis-01.json', cpu)
print(json.dumps({'p99_ms': max(times), 'median_ms': statistics.median(times), 'hops': len(hops),
    'WAV_frames': frames, 'WAV_samples_all_finite': True, 'control_starvation_seconds': audio['control_starved_seconds'],
    'recovery_upper_seconds': recovery, 'guard_context': guard_context, 'observer': cpu['observer'],
    'top3_process_CPU_seconds': [{k: x[k] for k in ('pid', 'comm', 'observed_span_cpu_seconds')} for x in ordered[:3]]}))
