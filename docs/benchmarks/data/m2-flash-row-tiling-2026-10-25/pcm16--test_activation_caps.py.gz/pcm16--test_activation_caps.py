"""Generated evidence; no host, helper, native process or GPU work."""
from copy import deepcopy
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('tiling_pcm_driver', Path(__file__).with_name('run_host_pcm.py'))
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)

GRAPH = b'conflux_flash_f32_graph nodes=2871 flash_nodes=10 self1344=3 self2688=3 cross2688to1344=2 cross1344to2688=2\n'
PIPELINE = (b'conflux_flash_f32_pipeline shader=flash_attn_f32_f16_fp32 path=scalar '
    b'intermediate_bytes=4 accumulation_bytes=4 hsk=64 hsv=64 Br=8 Bc=32 '
    b'workgroup=128 subgroup=0 k=f32 v=f32\n')

class ActivationAndCapsTests(unittest.TestCase):
    def test_complete_unchanged_graph_and_full_f32_eight_row_pipeline(self):
        result = driver.validate_candidate_graph(b'ordinary diagnostic\n'+GRAPH+PIPELINE)
        self.assertTrue(result['complete'])
        self.assertEqual(result['graph_nodes'], 2871)
        self.assertEqual(result['removed_graph_nodes'], 0)
        self.assertEqual(result['query_tile_rows'], 8)

    def test_baseline_precision_route_and_foreign_graph_rejected(self):
        for old,new in ((b'Br=8',b'Br=4'), (b'nodes=2871',b'nodes=2823'),
                        (b'accumulation_bytes=4',b'accumulation_bytes=2'),
                        (b'Bc=32',b'Bc=64'), (b'hsk=64',b'hsk=128'),
                        (b'workgroup=128',b'workgroup=256'),
                        (b'subgroup=0',b'subgroup=32'), (b'k=f32',b'k=f16'),
                        (b'flash_nodes=10',b'flash_nodes=9')):
            with self.subTest(field=old), self.assertRaises(ValueError):
                driver.validate_candidate_graph((GRAPH+PIPELINE).replace(old,new))

    def test_missing_duplicate_truncated_and_oversized_activation_rejected(self):
        for raw in (GRAPH, PIPELINE, GRAPH*2+PIPELINE, GRAPH+PIPELINE*2,
                    (GRAPH+PIPELINE)[:-1], b'x'*(256*1024)+b'\n', None):
            with self.subTest(kind=type(raw).__name__), self.assertRaises(ValueError):
                driver.validate_candidate_graph(raw)

    def test_original_caps_and_guard_reduction_allowed(self):
        values = deepcopy(driver.CAP_CEILINGS)
        self.assertEqual(driver.validate_power_caps(values), values)
        path = next(p for p in values if 'intel-rapl-mmio' in p and p.endswith('constraint_0_power_limit_uw'))
        values[path] = 7500000
        self.assertEqual(driver.validate_power_caps(values)[path], 7500000)

    def test_cap_increase_missing_field_and_invalid_values_fail_closed(self):
        original = driver.CAP_CEILINGS
        long_term = next(p for p in original if 'intel-rapl-mmio' in p and p.endswith('constraint_0_power_limit_uw'))
        for value in (64000000,15000001,0,-1,True,'15000000',float('nan')):
            values = deepcopy(original); values[long_term] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                driver.validate_power_caps(values)
        values = deepcopy(original); values.pop(long_term)
        with self.assertRaises(ValueError): driver.validate_power_caps(values)
        values = deepcopy(original); values['/foreign'] = 1
        with self.assertRaises(ValueError): driver.validate_power_caps(values)
        enabled = next(p for p in original if p.endswith('/enabled'))
        values = deepcopy(original); values[enabled] = 0
        with self.assertRaises(ValueError): driver.validate_power_caps(values)
        window = next(p for p in original if p.endswith('_time_window_us'))
        values = deepcopy(original); values[window] -= 1
        with self.assertRaises(ValueError): driver.validate_power_caps(values)

    def test_missing_or_raised_final_cap_proof_cannot_pass(self):
        report = {'candidate_graph':driver.validate_candidate_graph(GRAPH+PIPELINE),
            'cleanup_complete':True,'pins_unchanged':True,'guard_before':{},'guard_after':{},
            'within_command_budget':True,'capture':{'complete':True},
            'host_boundaries':{'complete':True,'gpu_intervals_complete':True,'input_identities_complete':True},
            'native_shutdown':{'graceful_complete':True},
            'retained_streams':{'stderr':{'truncated':False},'stdout':{'truncated':False}},
            'errors':[],'watchdog_errors':[],'requests':[
                {'case_id':case,'request_id':n,'completed':True,'exact_pcm_match':True,
                 'native_metrics':{'elapsed_ms':1.0}} for n,case in enumerate(driver.CASE_IDS,1)]}
        with self.assertRaises(ValueError): driver.final_gates(report)
        report['configured_power_caps_after'] = deepcopy(driver.CAP_CEILINGS)
        driver.final_gates(report)
        self.assertTrue(report['diagnostic_complete'])
        self.assertFalse(report['service_timing_qualification'])
        path = next(p for p in driver.CAP_CEILINGS if 'intel-rapl-mmio' in p and p.endswith('constraint_0_power_limit_uw'))
        report['configured_power_caps_after'][path] = 64000000
        with self.assertRaises(ValueError): driver.final_gates(report)

if __name__ == '__main__':
    unittest.main()
