"""Exact read-only host functions retained from the production soak wrapper."""
from datetime import datetime, timezone
import hashlib
import os
from pathlib import Path
import subprocess
import time

def read_command(command, timeout=3):
    value = subprocess.run(command, capture_output=True, text=True, timeout=timeout,
                           stdin=subprocess.DEVNULL)
    if value.returncode:
        raise RuntimeError(f"Read-only command failed: {command[0]}: {value.stderr.strip()}")
    return value.stdout.strip()


def pin(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    info = path.stat()
    return {"path": str(path), "bytes": info.st_size, "sha256": value.hexdigest()}


def process_identity(pid):
    root = Path("/proc") / str(pid)
    if root.stat().st_uid != os.getuid():
        raise RuntimeError("Observed PID is not owned by the current user")
    fields = (root / "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": pid, "start_ticks": int(fields[19]),
            "command": [part.decode(errors="replace") for part in (root / "cmdline").read_bytes().split(b"\0") if part]}


def guard_identity(script, service_file):
    raw = read_command(["systemctl", "--user", "show", "thermal-guard.service",
                        "--property=ActiveState,MainPID,InvocationID,ExecMainStartTimestampMonotonic"])
    fields = dict(line.split("=", 1) for line in raw.splitlines() if "=" in line)
    if fields.get("ActiveState") != "active" or int(fields.get("MainPID", 0)) <= 0:
        raise RuntimeError("Existing thermal-guard.service must remain active")
    identity = process_identity(int(fields["MainPID"]))
    if str(script) not in identity["command"]:
        raise RuntimeError("Active thermal guard does not match the pinned script")
    return {"service": fields, "process": identity, "script": pin(script), "unit": pin(service_file)}


def power_state():
    supplies = []
    for root in sorted(Path("/sys/class/power_supply").glob("*")):
        try:
            kind = (root / "type").read_text().strip()
            if kind in ("Mains", "USB", "USB_C", "USB_PD") and (root / "online").exists():
                supplies.append({"name": root.name, "type": kind, "online": int((root / "online").read_text())})
        except (OSError, ValueError):
            continue
    lids = {}
    for path in sorted(Path("/proc/acpi/button/lid").glob("*/state")):
        lids[str(path)] = path.read_text().strip()
    if lids:
        lid_open = all(value.lower().endswith("open") for value in lids.values())
    else:
        raw = read_command(["busctl", "--system", "get-property", "org.freedesktop.login1",
                            "/org/freedesktop/login1", "org.freedesktop.login1.Manager", "LidClosed"])
        if raw not in ("b true", "b false"):
            raise RuntimeError("Cannot establish the laptop lid state")
        lids["login1.LidClosed"] = raw
        lid_open = raw == "b false"
    return {"ac_online": any(item["online"] == 1 for item in supplies), "supplies": supplies,
            "lid_open": lid_open, "lid_sources": lids}


def sensor_paths():
    values = {}
    for root in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
        try:
            kind = (root / "type").read_text().strip()
            if kind in ("acpitz", "TCPU", "x86_pkg_temp"):
                values[str(root / "temp")] = kind
        except OSError:
            continue
    for root in sorted(Path("/sys/class/hwmon").glob("hwmon*")):
        try:
            if (root / "name").read_text().strip() == "coretemp":
                for path in sorted(root.glob("temp*_input")):
                    values[str(path)] = "coretemp"
        except OSError:
            continue
    if not values:
        raise RuntimeError("No CPU/ACPI temperature sensors used by the existing guard are readable")
    return values


def observation(paths):
    temperatures, errors = {}, {}
    for name in paths:
        try:
            temperatures[name] = int(Path(name).read_text().strip())
        except (OSError, ValueError) as error:
            errors[name] = str(error)
    policy = {}
    for path in (Path("/sys/firmware/acpi/platform_profile"),
                 Path("/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference")):
        try:
            policy[str(path)] = path.read_text().strip()
        except OSError as error:
            errors[str(path)] = str(error)
    return {"monotonic_ns": time.monotonic_ns(), "at_utc": datetime.now(timezone.utc).isoformat(),
            "temperatures_millidegrees_C": temperatures, "profile_epp_read_only": policy, "read_errors": errors}
