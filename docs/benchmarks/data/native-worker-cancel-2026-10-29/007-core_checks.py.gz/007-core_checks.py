#!/usr/bin/env python3
"""Bounded fake-process checks; no actual model, GPU, audio or window."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import struct
import subprocess
import sys
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
SOURCE = Path('/home/kyau/.codex/worktrees/player-startup-clock/conflux')
PROBE = BASE / 'probe.py'
EVIDENCE = BASE / 'offline-02'

FAKE = r'''import argparse,json,os,pathlib,signal,sys,time
p=argparse.ArgumentParser()
p.add_argument('--model');p.add_argument('--backend');p.add_argument('--threads',type=int)
a=p.parse_args()
signal.signal(signal.SIGTERM,signal.SIG_IGN)
root=pathlib.Path(__file__).parent
(root/'fake-native.pid').write_text(str(os.getpid()))
print(json.dumps(dict(event='ready',sample_rate=44100,channels=2,segment_frames=343980,
 stems=['drums','bass','other','vocals'],pid=os.getpid()+(1 if MODE=='wrong-pid' else 0),
 backend=a.backend,threads=a.threads)),flush=True)
if MODE=='idle':
 while True:time.sleep(.01)
for line in sys.stdin:
 q=json.loads(line)
 if MODE.startswith('other-read'):
  other=pathlib.Path(q['input']).with_name('unrelated')
  other.write_bytes(b'not the native input')
  other.read_bytes()
  if MODE=='other-read':other.unlink()
  while True:time.sleep(.01)
 if MODE=='output-started':pathlib.Path(q['output']).write_bytes(b'')
 data=pathlib.Path(q['input']).read_bytes()
 assert len(data)==343980*2*4
 (root/'fake-input-consumed').write_text(str(q['id']))
 while True:time.sleep(.01)
'''


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class ProbeBehavior(unittest.TestCase):
    def run_case(self, mode, *, bad_pin=False, existing=False, retained=False):
        case = EVIDENCE / self._testMethodName
        case.mkdir(mode=0o700)
        model = case / 'model.fixture'
        model.write_bytes(b'not an actual model; no model library is imported by the fake child')
        runtime = case / 'runtime.py'
        runtime.write_text('#!' + sys.executable + '\nMODE=' + repr(mode) + '\n' + FAKE)
        runtime.chmod(0o700)
        job = case / 'job'
        if existing:
            job.mkdir(mode=0o700)
            (job / 'sentinel').write_text('retain existing owner')
        command = [sys.executable, '-B', str(PROBE), '--source-root', str(SOURCE),
                   '--runtime', str(runtime), '--runtime-sha256', '0'*64 if bad_pin else digest(runtime),
                   '--model', str(model), '--model-sha256', digest(model),
                   '--worker-sha256', digest(SOURCE / 'tools/stems/worker.py'),
                   '--job', str(job), '--backend', 'cpu', '--max-wait', '1']
        environment = os.environ.copy()
        environment['PYTHONDONTWRITEBYTECODE'] = '1'
        process = subprocess.Popen(command, start_new_session=True, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, env=environment)
        try:
            output, error = process.communicate(timeout=7)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                output, error = process.communicate(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                output, error = process.communicate(timeout=2)
            (case / 'stdout.txt').write_bytes(output)
            (case / 'stderr.txt').write_bytes(error)
            self.fail('fixture exceeded its bounded completion window')
        (case / 'stdout.txt').write_bytes(output)
        (case / 'stderr.txt').write_bytes(error)
        # Independent proof after reaping the probe: the new process group is gone.
        try:
            os.killpg(process.pid, 0)
        except ProcessLookupError:
            group_absent = True
        else:
            os.killpg(process.pid, signal.SIGKILL)
            group_absent = False
        self.assertTrue(group_absent, 'owned process group retained members')
        result = json.loads((job / 'result.json').read_text()) if (job / 'result.json').exists() else None
        (case / 'owner.json').write_text(json.dumps(dict(pid=process.pid, returncode=process.returncode,
            exact_owned_group_absent=group_absent, model_fixture_only=True), indent=2)+'\n')
        if result is not None and (case / 'fake-native.pid').exists():
            self.assertTrue(result['final_native_reaped'])
            self.assertEqual(result['final_native_spool_absent'], not retained)
        return case, result, process.returncode

    def test_consumed_blocked_request_is_killed_reaped_and_unpublished(self):
        case, result, code = self.run_case('blocked')
        self.assertEqual(code, 0, result)
        self.assertTrue(result['passed'])
        self.assertTrue((case / 'fake-input-consumed').exists())
        self.assertEqual(result['native_returncode'], -signal.SIGKILL)
        self.assertTrue(result['native_pidfd_readable'])
        self.assertTrue(result['supervisor_thread_stopped'])
        self.assertEqual(result['after_close']['ready_count'], 0)
        self.assertFalse(result['GPU_fence_preemption_proven'])

    def test_dispatch_without_input_read_never_qualifies(self):
        case, result, code = self.run_case('idle')
        self.assertNotEqual(code, 0)
        self.assertFalse(result['passed'])
        self.assertNotIn('input_close_read_observed_ns', result)
        self.assertFalse((case / 'fake-input-consumed').exists())

    def test_unrelated_read_does_not_qualify(self):
        _, result, code = self.run_case('other-read')
        self.assertNotEqual(code, 0)
        self.assertFalse(result['passed'])
        self.assertNotIn('input_close_read_observed_ns', result)

    def test_unknown_spool_entry_retains_job_and_refuses_qualification(self):
        case, result, code = self.run_case('other-read-retained', retained=True)
        self.assertNotEqual(code, 0)
        self.assertFalse(result['passed'])
        self.assertIn('cleanup_error', result)
        self.assertTrue((case / 'job/native/unrelated').exists())

    def test_started_output_is_refused(self):
        _, result, code = self.run_case('output-started')
        self.assertNotEqual(code, 0)
        self.assertFalse(result['passed'])
        self.assertIn('not unfinished', result['error'])

    def test_wrong_ready_pid_is_refused(self):
        _, result, code = self.run_case('wrong-pid')
        self.assertNotEqual(code, 0)
        self.assertFalse(result['passed'])
        self.assertIn('identity', result['error'])

    def test_wrong_asset_pin_stops_before_native_start(self):
        case, result, code = self.run_case('blocked', bad_pin=True)
        self.assertNotEqual(code, 0)
        self.assertFalse(result['passed'])
        self.assertIn('digest differs', result['error'])
        self.assertFalse((case / 'fake-native.pid').exists())
        self.assertFalse((case / 'job/source.f32').exists())

    def test_existing_job_is_not_adopted_or_modified(self):
        case, result, code = self.run_case('blocked', existing=True)
        self.assertNotEqual(code, 0)
        self.assertIsNone(result)
        self.assertEqual((case / 'job/sentinel').read_text(), 'retain existing owner')
        self.assertEqual(sorted(p.name for p in (case / 'job').iterdir()), ['sentinel'])
        self.assertFalse((case / 'fake-native.pid').exists())

    def test_observer_overflow_is_an_error(self):
        spec = importlib.util.spec_from_file_location('private_cancel_probe', PROBE)
        probe = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(probe)
        watch = object.__new__(probe.InputReadWatch)
        watch.fd, watch.wd = -1, 2
        with patch.object(probe.os, 'read', return_value=struct.pack('iIII', -1, 0x4000, 0, 0)):
            with self.assertRaisesRegex(RuntimeError, 'observation lost'):
                watch.drain()


if __name__ == '__main__':
    EVIDENCE.mkdir(mode=0o700)
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ProbeBehavior))
    (EVIDENCE / 'verification.json').write_text(json.dumps(dict(tests=result.testsRun,
        failures=len(result.failures), errors=len(result.errors), passed=result.wasSuccessful(),
        actual_model_executed=False, GPU_used=False, audio_or_UI_started=False,
        hardware_cancellation_qualified=False), indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
