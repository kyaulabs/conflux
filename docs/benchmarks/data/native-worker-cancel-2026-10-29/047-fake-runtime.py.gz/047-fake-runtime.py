#!/bin/python3
MODE='blocked'
import argparse,json,os,pathlib,signal,sys,time
p=argparse.ArgumentParser();p.add_argument('--model');p.add_argument('--backend');p.add_argument('--threads',type=int);a=p.parse_args()
signal.signal(signal.SIGTERM,signal.SIG_IGN)
print('ggml_vulkan: 0 = NVIDIA OFFLINE FIXTURE; no GPU library loaded',file=sys.stderr,flush=True)
print(json.dumps(dict(event='ready',sample_rate=44100,channels=2,segment_frames=343980,
 stems=['drums','bass','other','vocals'],pid=os.getpid(),backend=a.backend,threads=a.threads,
 revision='0097d365a00b52a6991ad7618f0a04e8d2935e47',fence_wait_mode='blocking',
 weight_storage='native',model=str(pathlib.Path(a.model).resolve()))),flush=True)
for line in sys.stdin:
 q=json.loads(line)
 if MODE=='output-started':pathlib.Path(q['output']).write_bytes(b'')
 pathlib.Path(q['input']).read_bytes()
 while True:time.sleep(.01)
