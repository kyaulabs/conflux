#!/usr/bin/env python3
"""Own only the dedicated CONFLUX cancellation container; dry by default."""
from datetime import datetime, timezone
import argparse
import hashlib
import json
from pathlib import Path
import signal
import subprocess
import time

BASE = Path('/srv/conflux-tests/work/native-hard-cancel-20261029-01/packet-01')
ASSETS = Path('/srv/conflux-tests/work/m2-shared-staging-20261028-01')
MODEL = Path('/srv/conflux-tests/work/htdemucs-f16.gguf')
DOCKER = ['sudo', '-n', 'env', 'DOCKER_CONFIG=/srv/conflux-tests/docker-client', 'docker',
          '--host', 'unix:///srv/conflux-tests/daemon/docker.sock']
IMAGE = 'sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
NAME = 'conflux-native-hard-cancel-20261029-01'
GPU = 'nvidia.com/gpu=GPU-c58fa4ef-cda8-be9f-eb37-caeb7cf7d42b'
MODE = 'm2-native-hard-cancel-20261029-01'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'Regular file required: ' + str(path))
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save_new(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def actual_path(value):
    path = Path(value)
    require(path.is_absolute() and '..' not in path.parts, 'Invalid container asset path')
    if path.is_relative_to('/packet'):
        return BASE / path.relative_to('/packet')
    if path.is_relative_to('/assets'):
        return ASSETS / path.relative_to('/assets')
    require(path == Path('/model/htdemucs-f16.gguf'), 'Unrecognized container asset')
    return MODEL


def verify():
    binding = json.loads((BASE / 'remote-binding.json').read_text())
    require(binding['mode'] == MODE and binding['hardware_started'] is False, 'Wrong binding')
    for row in binding['remote_files']:
        path = Path(row['path'])
        require(path.is_relative_to(BASE), 'Remote packet pin escapes its directory')
        require(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], 'Packet changed: ' + str(path))
    plan = json.loads((BASE / 'apollo-plan.json').read_text())
    require(plan['mode'] == MODE and plan['host'] == 'apollo' and plan['operator_seconds'] == 300, 'Wrong plan')
    for key, row in plan['pins'].items():
        if key == 'python':
            continue  # The immutable image/actual CPU entry check binds its interpreter.
        path = actual_path(row['path'])
        require(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], 'Frozen asset differs: ' + key)
    return plan


def validate_human(human, now_utc, now_mono):
    age = (now_utc - datetime.fromisoformat(human['original_readiness_utc'])).total_seconds()
    require(human['mode'] == MODE and human['operator_seconds'] == 300 and 0 <= age <= 90 and
            human['physical_conditions_confirmed'] is True and
            all(human.get(key) is True for key in ('AC_power', 'lid_open', 'Codex_minimized',
                'other_work_paused', 'CONFLUX_closed', 'no_suspend')) and
            all(type(human.get(key)) is str and 0 < len(human[key]) <= 8192 for key in
                ('question_item_id', 'human_question', 'human_reply')) and
            human['plan_sha256'] == digest(BASE / 'apollo-plan.json') and
            200 <= human['deadline_monotonic'] - now_mono <= 302 - age,
            'Fresh current physical readiness required')


def command(results, *, live, seconds=120):
    require(type(seconds) is int and 60 <= seconds <= 120, 'Invalid remaining container budget')
    name = NAME if live else NAME + '-offline-entry'
    args = DOCKER + ['run', '--rm', '--name', name, '--init', '--runtime=runc',
        '--label', 'org.kyaulabs.conflux.tests=1', '--label', 'org.kyaulabs.conflux.run=' + NAME,
        '--network=none', '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges:true',
        '--user', '1000:1000', '--pids-limit=256', '--memory=8g',
        '--tmpfs=/tmp:rw,nosuid,nodev,size=256m,mode=1777',
        '--env', 'XDG_CACHE_HOME=/results/cache', '--env', '__GL_SHADER_DISK_CACHE_PATH=/results/driver-cache']
    if live:
        args += ['--device', GPU]
    for source, target, readonly in ((BASE, '/packet', True), (ASSETS, '/assets', True),
                                    (MODEL, '/model/htdemucs-f16.gguf', True), (results, '/results', False)):
        args += ['--mount', 'type=bind,src=' + str(source) + ',dst=' + target + (',readonly' if readonly else '')]
    args += [IMAGE, 'timeout', '--signal=TERM', '--kill-after=5s', str(seconds) if live else '45', 'python3', '-B']
    args += ['/packet/run_guarded.py', '--plan', '/packet/apollo-plan.json'] + (['--run'] if live else [])
    return args


def remove_owned(name):
    found = subprocess.run(DOCKER + ['inspect', name], capture_output=True, text=True, timeout=5)
    if found.returncode == 0:
        value = json.loads(found.stdout)[0]
        require(value['Image'] == IMAGE and value['Config']['Labels'].get('org.kyaulabs.conflux.run') == NAME,
                'Container identity differs; refusing adoption')
        subprocess.run(DOCKER + ['rm', '--force', value['Id']], check=True, capture_output=True, timeout=10)
    remaining = subprocess.check_output(DOCKER + ['ps', '-aq', '--no-trunc', '--filter', 'name=^/' + name + '$'],
                                        text=True, timeout=5)
    require(not remaining.strip(), 'Owned container remains')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--offline-entry', action='store_true')
    args = parser.parse_args()
    require(not (args.run and args.offline_entry), 'Choose one mode')
    if args.run:
        # Gate before Docker info, asset reads or any container.
        human = json.loads((BASE / 'readiness.json').read_text())
        validate_human(human, datetime.now(timezone.utc), time.monotonic())
    verify()
    if not args.run and not args.offline_entry:
        print(json.dumps(dict(verified=True, unarmed=True, GPU_started=False)))
        return 0
    require(json.loads(subprocess.check_output(DOCKER + ['info', '--format', '{{json .DockerRootDir}}'], timeout=5))
            == '/srv/conflux-tests/docker-data', 'Wrong Docker daemon')
    require(subprocess.check_output(DOCKER + ['ps', '-aq'], text=True, timeout=5).strip() == '',
            'Dedicated daemon already has a container')
    name = NAME if args.run else NAME + '-offline-entry'
    require(subprocess.run(DOCKER + ['inspect', name], capture_output=True, timeout=5).returncode != 0,
            'Container name already owned')
    results = BASE / ('container-results-01' if args.run else 'offline-entry-results-01')
    results.mkdir(mode=0o700)
    report = dict(completed=False, cleanup_complete=False, GPU_device_attached=args.run, errors=[])
    process = None
    def interrupted(number, _frame):
        raise InterruptedError('Owned container signal ' + str(number))
    for number in (signal.SIGTERM, signal.SIGINT):
        signal.signal(number, interrupted)
    try:
        seconds = min(120, int(human['deadline_monotonic'] - time.monotonic()) - 90) if report['GPU_device_attached'] else 120
        command_line = command(results, live=report['GPU_device_attached'], seconds=seconds)
        save_new(results / 'dispatch.json', dict(command=command_line))
        with (results / 'container.log').open('x') as log:
            process = subprocess.Popen(command_line, stdout=log, stderr=subprocess.STDOUT)
            report['exit'] = process.wait(timeout=seconds + 10 if report['GPU_device_attached'] else 50)
        if report['GPU_device_attached']:
            inner = json.loads((results / 'output-01/result.json').read_text())
            report['completed'] = report['exit'] == 0 and inner['passed'] and inner['cleanup_complete']
        else:
            report['completed'] = report['exit'] == 0
    except BaseException as error:
        report['errors'].append(type(error).__name__ + ': ' + str(error))
    finally:
        for number in (signal.SIGTERM, signal.SIGINT):
            signal.signal(number, signal.SIG_IGN)
        try:
            remove_owned(name)
            if process is not None:
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait(timeout=2)
            report['cleanup_complete'] = True
        except BaseException as error:
            report['errors'].append('cleanup: ' + str(error))
        report['completed'] = report['completed'] and report['cleanup_complete'] and not report['errors']
        save_new(results / 'owner-result.json', report)
    print(json.dumps(report))
    return 0 if report['completed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
