#!/usr/bin/env python3
"""Verify only by default; dispatch both hosts only after fresh physical readiness."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
REMOTE = '/srv/conflux-tests/work/native-hard-cancel-20261029-01/packet-01'
MODE = 'm2-native-hard-cancel-20261029-01'
LOCAL_UNIT = 'conflux-native-cancel-laptop-20261029-01.service'
REMOTE_UNIT = 'conflux-native-cancel-apollo-20261029-01.service'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'ForwardAgent=no',
       '-o', 'ForwardX11=no', '-o', 'ClearAllForwardings=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'HostName=10.4.20.101', '-o', 'HostKeyAlias=[apollo.kyaulabs]:4222', '-p', '4222', 'kyau@apollo.kyaulabs']
CONDITIONS = ('AC_power', 'lid_open', 'Codex_minimized', 'other_work_paused', 'CONFLUX_closed', 'no_suspend')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'Regular frozen file required: ' + str(path))
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save_new(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def verify():
    packet = json.loads((BASE / 'packet-pins.json').read_text())
    require(packet['mode'] == MODE and packet['hardware_started'] is False and
            packet['offline_checks_passed'] is True and packet['operator_seconds'] == 300 and
            packet['requests_per_host'] == 1 and packet['retries'] is False, 'Unverified or wrong packet')
    for row in packet['local_files']:
        path = Path(row['path'])
        require(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], 'Frozen input changed: ' + str(path))
    require(not any((BASE / name).exists() for name in ('readiness.json', 'launch-reservation.json',
        'both-dispatch.json', 'output-01', 'unit.stdout.log', 'unit.stderr.log')), 'Earlier attempt already owns this packet')
    return packet


def local_command(remaining):
    require(200 <= remaining <= 300, 'Insufficient original dispatch/cleanup budget')
    return ['systemd-run', '--user', '--unit=' + LOCAL_UNIT, '--property=Type=exec',
        '--property=RemainAfterExit=yes', '--property=Restart=no', '--property=RuntimeMaxSec=' + str(int(remaining) - 45) + 's',
        '--property=TimeoutStopSec=15s', '--property=KillMode=control-group', '--property=MemoryMax=8G',
        '--property=TasksMax=256', '--property=UMask=0077', '--property=WorkingDirectory=' + str(ROOT),
        '--property=StandardOutput=append:' + str(BASE / 'unit.stdout.log'),
        '--property=StandardError=append:' + str(BASE / 'unit.stderr.log'),
        '--setenv=XDG_CACHE_HOME=' + str(BASE / 'driver-cache'),
        '/usr/bin/kde-inhibit', '--power', '/usr/bin/python3.14', '-B', str(BASE / 'run_guarded.py'),
        '--plan', str(BASE / 'laptop-plan.json'), '--run']


def remote_script(packet, human):
    header = 'REMOTE=' + repr(REMOTE) + '\nBINDING=' + repr(packet['remote_binding']) + '\nHUMAN=' + repr(human) + '\nUNIT=' + repr(REMOTE_UNIT) + '\n'
    return header + r'''
from datetime import datetime,timezone
import hashlib,json,subprocess,time
from pathlib import Path
base=Path(REMOTE);binding=BINDING;human=HUMAN;unit=UNIT
raw=Path(binding['path']).read_bytes()
if len(raw)!=binding['bytes'] or hashlib.sha256(raw).hexdigest()!=binding['sha256']:raise RuntimeError('Remote binding changed')
age=(datetime.now(timezone.utc)-datetime.fromisoformat(human['original_readiness_utc'])).total_seconds()
if not 0<=age<60:raise RuntimeError('Fresh original readiness required')
if not all(human.get(k) is True for k in ('physical_conditions_confirmed','AC_power','lid_open','Codex_minimized','other_work_paused','CONFLUX_closed','no_suspend')):raise RuntimeError('Physical readiness declined')
state=subprocess.check_output(['systemctl','show',unit,'--property=LoadState,MainPID'],text=True,timeout=5)
if 'LoadState=not-found' not in state or 'MainPID=0' not in state:raise RuntimeError('Remote unit already exists')
if any((base/n).exists() for n in ('readiness.json','launch-reservation.json','container-results-01','unit-dispatch.json')):raise RuntimeError('Remote attempt already owned')
human['deadline_monotonic']=time.monotonic()+300-age
human['plan_sha256']=hashlib.sha256((base/'apollo-plan.json').read_bytes()).hexdigest()
for name,value in (('readiness.json',human),('launch-reservation.json',dict(original_readiness_utc=human['original_readiness_utc'],deadline_monotonic=human['deadline_monotonic'],retries=False))):
 with (base/name).open('x') as f:f.write(json.dumps(value,indent=2)+'\n')
remaining=human['deadline_monotonic']-time.monotonic()
if not 200<=remaining<=300:raise RuntimeError('Insufficient original remote dispatch/cleanup budget')
command=['sudo','-n','systemd-run','--unit='+unit,'--uid=1000','--gid=1000','--property=Type=exec',
 '--property=RemainAfterExit=yes','--property=Restart=no','--property=RuntimeMaxSec='+str(int(remaining)-45)+'s',
 '--property=TimeoutStopSec=15s','--property=KillMode=control-group','--property=MemoryMax=8G',
 '--property=TasksMax=512','--property=UMask=0077','--property=WorkingDirectory='+str(base),
 '--property=StandardOutput=append:'+str(base/'unit.stdout.log'),'--property=StandardError=append:'+str(base/'unit.stderr.log'),
 '/usr/bin/python3','-B',str(base/'apollo_owner.py'),'--run']
r=subprocess.run(command,capture_output=True,text=True,timeout=15)
receipt=dict(command=command,exit=r.returncode,stdout=r.stdout,stderr=r.stderr,original_readiness_utc=human['original_readiness_utc'],deadline_monotonic=human['deadline_monotonic'])
with (base/'unit-dispatch.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
if r.returncode:raise SystemExit(r.returncode)
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--launch', action='store_true')
    args = parser.parse_args()
    packet = verify()
    if not args.launch:
        print(json.dumps(dict(verified=True, unarmed=True, hardware_started=False)))
        return 0
    raw = sys.stdin.read(32769)
    require(len(raw) <= 32768, 'Oversized human reply')
    reply = json.loads(raw)
    require(reply.get('physical_conditions_confirmed') is True and
            all(reply.get(key) is True for key in CONDITIONS) and
            all(type(reply.get(key)) is str and 0 < len(reply[key]) <= 8192 for key in
                ('question_item_id', 'human_question', 'human_reply')), 'Fresh physical readiness required')
    original_utc, original_mono = datetime.now(timezone.utc).isoformat(), time.monotonic()
    # No host command, reservation or dispatch occurs before the positive reply.
    state = subprocess.check_output(['systemctl', '--user', 'show', LOCAL_UNIT,
                                    '--property=LoadState,MainPID'], text=True, timeout=5)
    require('LoadState=not-found' in state and 'MainPID=0' in state, 'Local unit already exists')
    human = dict(schema=1, mode=MODE, operator_seconds=300, original_readiness_utc=original_utc,
                 deadline_monotonic=original_mono + 300, **reply)
    local_human = dict(human, plan_sha256=digest(BASE / 'laptop-plan.json'))
    save_new(BASE / 'readiness.json', local_human)
    save_new(BASE / 'launch-reservation.json', dict(original_readiness_utc=original_utc,
        original_monotonic=original_mono, deadline_monotonic=original_mono + 300, retries=False))
    code = remote_script(packet, human)
    def dispatch(host, command, data=None):
        with (BASE / (host + '-dispatch.stdout.log')).open('x') as out, (BASE / (host + '-dispatch.stderr.log')).open('x') as err:
            try:
                result = subprocess.run(command, input=data, text=True, stdout=out, stderr=err, timeout=30)
                return dict(exit=result.returncode)
            except BaseException as error:
                return dict(error=str(error), outcome_requires_unit_observation=True)
    require(time.monotonic() - original_mono < 45, 'Readiness dispatch window expired')
    with ThreadPoolExecutor(max_workers=2) as pool:
        local = pool.submit(dispatch, 'laptop', local_command(original_mono + 300 - time.monotonic()))
        remote = pool.submit(dispatch, 'apollo', SSH + ['python3 -'], code)
        receipt = dict(laptop=local.result(), apollo=remote.result(), original_readiness_utc=original_utc,
            operator_deadline_monotonic=original_mono + 300, hosts_dispatched_concurrently=True, retries=False)
    save_new(BASE / 'both-dispatch.json', receipt)
    print(json.dumps(receipt))
    return 0 if all(receipt[host].get('exit') == 0 for host in ('laptop', 'apollo')) else 1


if __name__ == '__main__':
    raise SystemExit(main())
