#!/bin/python3
MODE='other-read-retained'
import argparse,json,os,pathlib,signal,sys,time
p=argparse.ArgumentParser()
p.add_argument('--model');p.add_argument('--backend');p.add_argument('--threads',type=int)
a=p.parse_args()
signal.signal(signal.SIGTERM,signal.SIG_IGN)
root=pathlib.Path(__file__).parent
(root/'fake-native.pid').write_text(str(os.getpid()))
print(json.dumps(dict(event='ready',sample_rate=44100,channels=2,segment_frames=343980,
 stems=['drums','bass','other','vocals'],pid=os.getpid()+(1 if MODE=='wrong-pid' else 0),
 backend=a.backend,threads=a.threads)),flush=True)
if MODE=='idle':
 while True:time.sleep(.01)
for line in sys.stdin:
 q=json.loads(line)
 if MODE.startswith('other-read'):
  other=pathlib.Path(q['input']).with_name('unrelated')
  other.write_bytes(b'not the native input')
  other.read_bytes()
  if MODE=='other-read':other.unlink()
  while True:time.sleep(.01)
 if MODE=='output-started':pathlib.Path(q['output']).write_bytes(b'')
 data=pathlib.Path(q['input']).read_bytes()
 assert len(data)==343980*2*4
 (root/'fake-input-consumed').write_text(str(q['id']))
 while True:time.sleep(.01)
