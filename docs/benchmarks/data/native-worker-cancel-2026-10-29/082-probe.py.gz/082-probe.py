#!/usr/bin/env python3
"""Private Linux cancellation diagnostic; no audio, UI or latency qualification.

Run in a caller-owned new session. Real GPU execution additionally needs the
existing guarded launcher and fresh human readiness. This file does not launch
a model unless explicitly invoked with runtime/model arguments.
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import stat
import struct
import sys
import threading
import time


class InputReadWatch:
    """Observe close-after-read in the private native spool, not dispatch alone.

    inotify supplies no reader PID or GPU timeline. Attribution assumes the
    existing cooperative same-user scope and only the pinned child reading this
    new private spool. The observation does not prove an active GPU fence.
    """
    CLOSE_READ, OVERFLOW, DELETE_SELF, IGNORED = 0x10, 0x4000, 0x400, 0x8000
    HEADER = struct.Struct('iIII')

    def __init__(self, root):
        libc = ctypes.CDLL(None, use_errno=True)
        libc.inotify_init1.argtypes = [ctypes.c_int]
        libc.inotify_init1.restype = ctypes.c_int
        libc.inotify_add_watch.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_uint32]
        libc.inotify_add_watch.restype = ctypes.c_int
        self.fd = libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
        if self.fd < 0:
            raise OSError(ctypes.get_errno(), 'inotify_init1')
        self.wd = libc.inotify_add_watch(self.fd, os.fsencode(root), self.CLOSE_READ | self.DELETE_SELF)
        if self.wd < 0:
            error = ctypes.get_errno()
            self.close()
            raise OSError(error, 'inotify_add_watch')

    def drain(self):
        count = 0
        while True:
            try:
                raw = os.read(self.fd, 8192)
            except BlockingIOError:
                return count
            offset = 0
            while offset < len(raw):
                if len(raw) - offset < self.HEADER.size:
                    raise RuntimeError('truncated inotify header')
                wd, mask, _, size = self.HEADER.unpack_from(raw, offset)
                offset += self.HEADER.size
                if offset + size > len(raw):
                    raise RuntimeError('truncated inotify name')
                name = raw[offset:offset + size].split(b'\0', 1)[0]
                offset += size
                if mask & (self.OVERFLOW | self.DELETE_SELF | self.IGNORED):
                    raise RuntimeError('input-read observation lost')
                if wd == self.wd and mask & self.CLOSE_READ and name == b'input.f32':
                    count += 1

    def close(self):
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1


def identity(pid):
    fields = Path(f'/proc/{pid}/stat').read_text().split(') ', 1)[1].split()
    return dict(pid=pid, start_ticks=int(fields[19]), group=int(fields[2]), session=int(fields[3]))


def pin(path, expected):
    path = Path(path)
    if not path.is_absolute():
        raise ValueError('absolute input paths required')
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise ValueError('regular input required')
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.lstat()
    if (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns) != (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise ValueError('input identity changed during hashing')
    if digest != expected:
        raise ValueError('input digest differs')
    return dict(path=str(path), bytes=info.st_size, sha256=digest)


def run(args):
    if os.getsid(0) != os.getpid() or os.getpgrp() != os.getpid():
        raise RuntimeError('caller must launch this probe in its own new session')
    if not 0.1 <= args.max_wait <= 40:
        raise ValueError('max-wait must be between 0.1 and 40 seconds')
    source_root = Path(args.source_root)
    if not source_root.is_absolute():
        raise ValueError('source-root must be absolute')
    job = Path(args.job)
    if not job.is_absolute():
        raise ValueError('job must be absolute')
    job.mkdir(mode=0o700)  # Never adopt or clean an existing directory.
    report = dict(schema=1, passed=False, backend=args.backend, audio_output=False,
                  latency_qualified=False, GPU_fence_preemption_proven=False,
                  observation='IN_CLOSE_NOWRITE in a new private spool; no reader PID in the event',
                  source_root=str(source_root), events=[])
    worker = None
    state = {}
    attached = threading.Event()
    previous = {}
    def interrupted(number, _frame):
        raise InterruptedError(f'probe interrupted by signal {number}')
    for number in (signal.SIGALRM, signal.SIGTERM, signal.SIGINT):
        previous[number] = signal.signal(number, interrupted)
    signal.setitimer(signal.ITIMER_REAL, args.max_wait + 5)
    try:
        report['runtime'] = pin(args.runtime, args.runtime_sha256)
        report['model'] = pin(args.model, args.model_sha256)
        report['worker'] = pin(source_root / 'tools/stems/worker.py', args.worker_sha256)
        sys.path.insert(0, str(source_root))
        from tools.stems.worker import NativeRuntime, StemWorker, WINDOW, CHANNELS

        source = job / 'source.f32'
        source.write_bytes(b''.join(struct.pack('<ff', (i - 32) / 64, (32 - i) / 128) for i in range(64)))

        def factory(*values):
            native = NativeRuntime(*values, spool_directory=job / 'native', max_stderr_bytes=65536)
            try:
                watch = InputReadWatch(native.root)
                fd = os.pidfd_open(native.process.pid)
                proof = identity(native.process.pid)
                if proof['group'] != os.getpid() or proof['session'] != os.getpid():
                    raise RuntimeError('native escaped the caller-owned session')
                state.update(native=native, watch=watch, pidfd=fd, identity=proof)
                attached.set()
                return native
            except BaseException:
                if 'watch' in locals():
                    watch.close()
                if 'fd' in locals():
                    os.close(fd)
                native.close()
                raise

        worker = StemWorker(args.runtime, args.model, backend=args.backend, threads=2,
                            max_ready=1, request_timeout=args.max_wait, _backend_factory=factory)
        generation = worker.load_f32(source)
        deadline = time.monotonic() + args.max_wait
        started = ready = None
        while time.monotonic() < deadline:
            event = worker.poll(.001)
            if event is not None:
                if event['event'] in ('chunk', 'complete'):
                    raise RuntimeError('request completed before cancellation observation')
                if event['event'] == 'error':
                    raise RuntimeError(event['message'])
                report['events'].append(event)
                if event['event'] == 'started':
                    started = event
                elif event['event'] == 'runtime_ready':
                    ready = event['runtime']
            if not (attached.is_set() and started is not None and ready is not None):
                continue
            count = state['watch'].drain()
            if not count:
                continue
            native = state['native']
            report['input_close_read_observed_ns'] = time.monotonic_ns()
            before = worker.statistics()
            report['before_close'] = before
            inflight = before['inflight']
            if (count != 1 or inflight is None or inflight['generation'] != generation or
                    inflight['request_id'] != started['request_id'] or before['ready_count'] or
                    native.process.poll() is not None or (native.root / 'output.f32').exists()):
                raise RuntimeError('native request is not unfinished at the observation')
            if (ready['pid'] != native.process.pid or ready['backend'] != args.backend or
                    ready['threads'] != 2 or identity(native.process.pid) != state['identity']):
                raise RuntimeError('native identity or requested runtime settings differ')
            if (native.root / 'input.f32').stat().st_size != WINDOW * CHANNELS * 4:
                raise RuntimeError('native input extent differs')
            report['native_identity'] = state['identity']
            began = time.monotonic_ns()
            worker.close(timeout=0)
            report['close_ms'] = (time.monotonic_ns() - began) / 1e6
            report['native_returncode'] = native.process.returncode
            report['after_close'] = worker.statistics()
            report['native_pidfd_readable'] = bool(select.select([state['pidfd']], [], [], 0)[0])
            report['native_spool_absent'] = not native.root.exists()
            report['supervisor_thread_stopped'] = not worker._thread.is_alive()
            if (native.process.returncode != -signal.SIGKILL or not native._process_reaped or
                    not report['native_pidfd_readable'] or not report['native_spool_absent'] or
                    not report['supervisor_thread_stopped'] or report['after_close']['ready_count']):
                raise RuntimeError('hard cancellation or owned cleanup is unproven')
            while (event := worker.poll()) is not None:
                if event['event'] == 'chunk':
                    raise RuntimeError('partial/stale chunk published after close')
                report['events'].append(event)
            report['passed'] = True
            break
        else:
            raise TimeoutError('no consumed unfinished native request observed within the budget')
    except BaseException as error:
        report['error'] = f'{type(error).__name__}: {error}'
    finally:
        if worker is not None:
            try:
                worker.close(timeout=0)
            except BaseException as error:
                report['cleanup_error'] = f'{type(error).__name__}: {error}'
                report['passed'] = False
        if attached.is_set():
            state['watch'].close()
            os.close(state['pidfd'])
            report['final_native_reaped'] = state['native']._process_reaped
            report['final_native_spool_absent'] = not state['native'].root.exists()
            diagnostic = bytes(state['native']._stderr_tail)
            report['native_diagnostic_tail'] = dict(bytes=len(diagnostic),
                sha256=hashlib.sha256(diagnostic).hexdigest(), text=diagnostic.decode('utf-8', errors='replace'))
        signal.setitimer(signal.ITIMER_REAL, 0)
        for number, handler in previous.items():
            signal.signal(number, handler)
        (job / 'result.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source-root', 'runtime', 'runtime-sha256', 'model', 'model-sha256', 'worker-sha256', 'job'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--backend', choices=('cpu', 'vulkan'), required=True)
    parser.add_argument('--max-wait', type=float, default=30)
    result = run(parser.parse_args())
    print(json.dumps({key: result[key] for key in ('passed', 'backend', 'GPU_fence_preemption_proven', 'error') if key in result}))
    raise SystemExit(0 if result['passed'] else 1)
