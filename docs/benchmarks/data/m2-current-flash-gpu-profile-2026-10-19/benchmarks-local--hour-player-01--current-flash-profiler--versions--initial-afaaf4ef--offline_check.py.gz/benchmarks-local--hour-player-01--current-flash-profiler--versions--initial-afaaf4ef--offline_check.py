#!/usr/bin/env python3
"""Admission and uncertain-cleanup checks with process creation forbidden."""
from pathlib import Path
import importlib.util, contextlib, io, tempfile, json, sys, hashlib, types
from datetime import datetime, timezone, timedelta
from unittest.mock import patch, Mock
path = Path(__file__).with_name('profile_current_flash.py').resolve()
spec = importlib.util.spec_from_file_location('current_flash_probe', path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
checks = []
def check(name, action):
    action()
    checks.append({'name': name, 'passed': True})
def forbidden(*args, **kwargs):
    raise AssertionError('Unexpected process launch during offline check')
with tempfile.TemporaryDirectory(prefix='conflux-flash-profiler-offline-') as temporary:
    folder = Path(temporary)
    def dry():
        with patch.object(sys, 'argv', [str(path), 'offline-dry']), patch.object(m.subprocess, 'Popen', side_effect=forbidden), contextlib.redirect_stdout(io.StringIO()) as output:
            assert m.main() == 0
        plan = json.loads(output.getvalue())
        assert plan['host_queried'] is False and plan['native_started'] is False and len(plan['cases']) == 1
    check('dry plan creates no child and performs no host query', dry)
    original_load = m.load
    def load(name, source):
        value = original_load(name, source)
        if name == 'retained':
            value.head = lambda: '0' * 40
        return value
    def admission(label, configuration, human=None, error=''):
        base = folder / label
        base.mkdir()
        (base / 'expected-pins.json').write_text(json.dumps(configuration))
        readiness = base / 'human.json'
        if human is not None:
            readiness.write_text(json.dumps(human))
        arguments = [str(path), label, '--run', '--readiness-decision', str(readiness), '--source-pins', str(base / 'not-read.json')]
        with patch.object(m, 'BASE', base), patch.object(m, 'load', side_effect=load), patch.object(sys, 'argv', arguments), patch.object(m.subprocess, 'Popen', side_effect=forbidden), contextlib.redirect_stdout(io.StringIO()):
            assert m.main() == 1
        result = json.loads((base / label / 'result.json').read_text())
        assert result['native_started'] is False and result['AC_lid'] == []
        assert result['errors'] and error in result['errors'][0]['message'], result['errors']
        assert 'tools.stems.worker' not in sys.modules
    configuration = json.loads((path.parent / 'expected-pins.json').read_text())
    configuration.update(status='unarmed', repository_head=None)
    check('unarmed HEAD rejected before readiness, worker import or host query', lambda: admission('unarmed', configuration, error='not armed'))
    armed = {**configuration, 'status': 'ready', 'repository_head': '0' * 40}
    check('missing readiness rejected before worker import or host query', lambda: admission('missing', armed, error='fresh human-readiness'))
    human = {'schema': 1, 'decision': 'ready', 'ready_for_run': 'stale', 'AC_power': True, 'lid_open': True, 'Codex_minimized': True, 'other_work_paused': True, 'human_reply': 'Ready', 'recorded_at_utc': (datetime.now(timezone.utc) - timedelta(seconds=901)).isoformat()}
    check('expired readiness rejected before worker import or host query', lambda: admission('stale', armed, human, 'older than 15 minutes'))
    human.update(ready_for_run='not-minimized', recorded_at_utc=datetime.now(timezone.utc).isoformat(), Codex_minimized=False)
    check('minimized condition required before worker import or host query', lambda: admission('not-minimized', armed, human, 'minimized Codex'))
    for name, (helper, expected) in m.HELPERS.items():
        assert hashlib.sha256(helper.read_bytes()).hexdigest() == expected
        checks.append({'name': 'frozen helper ' + name, 'passed': True})
    def uncertain_cleanup():
        root = folder / 'unreaped-spool'
        root.mkdir()
        (root / 'input.f32').write_bytes(b'evidence')
        process = Mock(pid=12345, returncode=None)
        process.poll.return_value = None
        process.wait.side_effect = RuntimeError('unreaped')
        native = types.SimpleNamespace(process=process, root=root, close=Mock(side_effect=AssertionError('must not delete unreaped spool')))
        cleanup, _, errors = m.cleanup_native(native, True, folder)
        assert not cleanup['native_reaped'] and root.exists() and (root / 'input.f32').exists() and errors and not native.close.called
    check('unreaped child preserves spool and prevents normal close', uncertain_cleanup)
    def failed_request_files():
        root = folder / 'failed-request-spool'
        root.mkdir()
        for name in ('input.f32', 'output.f32'):
            (root / name).write_bytes(b'in-flight evidence')
        process = Mock()
        process.poll.return_value = None
        native = types.SimpleNamespace(root=root, process=process, infer=Mock(side_effect=TimeoutError('request failed while child remains live')))
        row = {'completed': False}
        try:
            native.infer(None, 1)
        except TimeoutError:
            pass
        finally:
            m.cleanup_request(native, row)
        assert native.process.poll() is None and all((root / name).exists() for name in ('input.f32', 'output.f32'))
        row['completed'] = True
        m.cleanup_request(native, row)
        assert not any((root / name).exists() for name in ('input.f32', 'output.f32'))
    check('failed live request retains files until proven outer cleanup; completed request can release them', failed_request_files)
    def expired_final_hash_budget():
        base = folder / 'expired-final-hash'
        base.mkdir()
        (base / 'expected-pins.json').write_text(json.dumps(armed))
        readiness = base / 'human.json'
        fresh = {**human, 'ready_for_run': 'expired-final-hash', 'Codex_minimized': True,
                 'recorded_at_utc': datetime.now(timezone.utc).isoformat()}
        readiness.write_text(json.dumps(fresh))
        clock = [1000.0]
        pin_deadlines = []
        def timed_load(name, source):
            module = load(name, source)
            if name == 'comparison':
                real_capture = module.capture_pins
                def capture(specifications, deadline, **options):
                    pin_deadlines.append(deadline)
                    if len(pin_deadlines) == 1:
                        clock[0] = 1301.0
                        raise RuntimeError('setup failure after fixed total deadline')
                    return real_capture(specifications, deadline, **options)
                module.capture_pins = capture
            return module
        arguments = [str(path), 'expired-final-hash', '--run', '--readiness-decision', str(readiness),
                     '--source-pins', str(path.parent / 'comparison-source-pins.json')]
        with patch.object(m, 'BASE', base), patch.object(m, 'load', side_effect=timed_load), \
                patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]), \
                patch.object(sys, 'argv', arguments), patch.object(m.subprocess, 'Popen', side_effect=forbidden), \
                contextlib.redirect_stdout(io.StringIO()):
            assert m.main() == 1
        result = json.loads((base / 'expired-final-hash' / 'result.json').read_text())
        assert pin_deadlines == [1300.0, 1300.0], pin_deadlines
        assert any(row.get('phase') == 'after_pins' and 'time budget exhausted' in row['message'] for row in result['errors']), result['errors']
        assert result['native_started'] is False and result['AC_lid'] == []
    check('expired final hash uses original total deadline and rejects without renewed sixty seconds', expired_final_hash_budget)
    proof = json.loads(m.PROOF.read_text())
    case = next(row for row in proof['runtimes'][0]['requests'] if row['id'] == 'club_xl:257985')
    assert proof['runtime_sha256'] == '6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53'
    assert case['output_sha256'] == 'e3dd10681d94efd2ebfbd3f98c34d74cbb25595559047c39156ba2388b73a856'
    assert case['input_sha256'] == '18182094f2b40017ba2b8445f8cbe4192ce2c45c04619edcaa3da3e4b82f3861'
    checks.append({'name': 'exact current own-Flash reference case retained', 'passed': True})
result = {'schema': 1, 'status': 'passed', 'scope': 'Offline admission/cleanup checks only; process creation forbidden, no worker import, GPU work, host query or audio output.', 'checks': checks, 'driver_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'earlier_check_correction': 'Initial temporary check expected the stale-readiness text without a space before minutes; corrected the check literal. Launcher emitted the intended rejection; no model/host process launched.'}
(path.parent / 'offline-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'status': result['status']}))
