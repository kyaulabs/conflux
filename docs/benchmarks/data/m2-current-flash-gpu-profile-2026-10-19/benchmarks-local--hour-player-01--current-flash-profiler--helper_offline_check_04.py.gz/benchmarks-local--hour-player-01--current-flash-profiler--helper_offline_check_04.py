#!/usr/bin/env python3
"""Terminal confirmation/source guards with input and exec mocked; no child."""
from pathlib import Path
import importlib.util
import json
import hashlib
import tempfile
import contextlib
import io
import stat
from datetime import datetime, timezone
from unittest.mock import patch, Mock

HERE = Path(__file__).resolve().parent
source = HERE / 'run_outside_codex.py'
spec = importlib.util.spec_from_file_location('outside_codex_check', source)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
checks = []

def require(condition, message='check failed'):
    if not condition:
        raise AssertionError(message)

def scenario(name, reply=None, action=None, conflict=None, unarmed=False, tty=True):
    with tempfile.TemporaryDirectory(prefix='conflux-terminal-offline-') as temporary:
        base = Path(temporary)
        driver, config, sources = (base / name for name in ('profile_current_flash.py', 'expected-pins.json', 'comparison-source-pins.json'))
        guard, unit = base / 'thermal-guard', base / 'thermal-guard.service'
        driver.write_text('# mock reviewed driver; never executed\n')
        config.write_text(json.dumps({'status': 'ready', 'repository_head': '0' * 40}))
        sources.write_text(json.dumps({str(driver): hashlib.sha256(driver.read_bytes()).hexdigest()}))
        guard.write_text('# mock guard source\n'); unit.write_text('# mock unit source\n')
        readiness = base / 'human-readiness-05.json'
        plan_path = base / 'outside-codex-plan-05.json'
        files = {'helper': source, 'driver': driver, 'config': config, 'source_pins': sources,
                 'guard_script': guard, 'guard_unit': unit}
        expected_command = ['/bin/python3', '-B', str(driver), helper.LABEL, '--run',
                            '--readiness-decision', str(readiness), '--source-pins', str(sources)]
        plan = {'status': 'unarmed' if unarmed else 'ready', 'label': helper.LABEL, 'repository_head': '0' * 40,
                'budgets': {'total_seconds': 300, 'request_seconds': 30, 'native_seconds': 60,
                            'readiness_seconds': 195, 'cleanup_reserve_seconds': 45},
                'command': expected_command,
                'files': {key: {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for key, path in files.items()}}
        plan_path.write_text(json.dumps(plan))
        if conflict == 'output':
            (base / helper.LABEL).mkdir()
        elif conflict == 'readiness':
            readiness.write_text('preserve existing human decision')
        def input_reply(prompt):
            require(prompt == helper.PROMPT)
            if action == 'driver_change':
                driver.write_text('# mutated while user was closing Codex\n')
            elif action == 'plan_change':
                plan_path.write_text(json.dumps({**plan, 'note': 'changed'}))
            elif action == 'readiness_race':
                readiness.write_text('preserve competing human decision')
            if isinstance(reply, BaseException):
                raise reply
            return reply
        with patch.multiple(helper, BASE=base, DRIVER=driver, CONFIG=config, SOURCES=sources,
                            GUARD_SCRIPT=guard, GUARD_UNIT=unit, READINESS=readiness, PLAN=plan_path), \
                patch('builtins.input', side_effect=input_reply) as confirmation, \
                patch.object(helper.os, 'execv') as execute, patch.object(helper.sys.stdin, 'isatty', return_value=tty), contextlib.redirect_stdout(io.StringIO()):
            error = None
            try:
                result = helper.main()
            except (OSError, RuntimeError, ValueError) as caught:
                error = str(caught)
                result = None
        if conflict or unarmed or not tty:
            require(error and not confirmation.called and not execute.called)
            if not tty:
                require('external interactive terminal' in error and not readiness.exists())
            if conflict == 'readiness':
                require(readiness.read_text() == 'preserve existing human decision')
        elif action:
            require(error and confirmation.call_count == 1 and not execute.called)
            if action == 'readiness_race':
                require(readiness.read_text() == 'preserve competing human decision')
            else:
                require(not readiness.exists())
        elif reply == 'READY':
            require(error is None and result == 0 and execute.call_count == 1)
            require(execute.call_args.args == ('/bin/python3', expected_command))
            record = json.loads(readiness.read_text())
            require(record['Codex_closed'] is True and record['Codex_minimized'] is False)
            require(record['AC_power'] is True and record['lid_open'] is True and record['other_work_paused'] is True)
            require(record['human_prompt'] == helper.PROMPT and record['human_reply'] == 'READY')
            require(record['ready_for_run'] == helper.LABEL and record['decision'] == 'ready')
            age = (datetime.now(timezone.utc) - datetime.fromisoformat(record['recorded_at_utc'])).total_seconds()
            require(0 <= age < 5 and stat.S_IMODE(readiness.stat().st_mode) == 0o600)
        else:
            require(error is None and not execute.called and not readiness.exists())
            require(result == (130 if isinstance(reply, BaseException) else 0))
        checks.append({'name': name, 'passed': True})

scenario('non-TTY READY cannot create a direct-human decision or exec', 'READY', tty=False)
scenario('EOF creates no decision and executes nothing', EOFError())
scenario('interrupt creates no decision and executes nothing', KeyboardInterrupt())
scenario('explicit abort creates no decision and executes nothing', 'cancel')
scenario('blank input creates no decision and executes nothing', '')
scenario('exact READY creates honest fresh0600 closed decision and execs exact fixed argv', 'READY')
scenario('existing output label prevents prompting or exec', 'READY', conflict='output')
scenario('existing readiness is never overwritten', 'READY', conflict='readiness')
scenario('unarmed plan prevents prompting or exec', 'READY', unarmed=True)
scenario('source change during confirmation prevents decision and exec', 'READY', action='driver_change')
scenario('plan change during confirmation prevents decision and exec', 'READY', action='plan_change')
scenario('readiness conflict during confirmation preserves existing decision', 'READY', action='readiness_race')
result = {'schema': 1, 'status': 'passed', 'scope': 'Real bounded plan/source validation and temporary files; human input and exec mocked. No host query, Codex close, native/model/Git subprocess, audio or UI action.',
          'helper_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'checks': checks}
output = HERE / 'helper-offline-checks-outside-04-tty.json'
if output.exists():
    raise SystemExit('Refusing to overwrite historical helper check receipt')
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'status': result['status']}))
