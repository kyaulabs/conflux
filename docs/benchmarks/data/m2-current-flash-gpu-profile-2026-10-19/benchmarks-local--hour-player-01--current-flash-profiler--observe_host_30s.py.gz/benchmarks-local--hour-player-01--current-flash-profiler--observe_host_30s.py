#!/usr/bin/env python3
"""One bounded read-only host temperature/process observer; no process arguments."""
from pathlib import Path
from datetime import datetime, timezone
import os, time, json, hashlib

BASE = Path(__file__).resolve().parent
OUTPUT = BASE / 'host-observation-30s-01.json'
if OUTPUT.exists():
    raise SystemExit('Refusing to repeat or overwrite the observation')

def utc():
    return datetime.now(timezone.utc).isoformat()

def processes():
    result, errors = {}, 0
    for directory in Path('/proc').iterdir():
        if not directory.name.isdecimal():
            continue
        try:
            raw = (directory / 'stat').read_text()
            opening, closing = raw.index('('), raw.rindex(')')
            fields = raw[closing + 1:].split()
            pid, start = int(directory.name), int(fields[19])
            result[(pid, start)] = {
                'pid': pid, 'start_ticks': start, 'comm': raw[opening + 1:closing],
                'ppid': int(fields[1]), 'cpu_ticks': int(fields[11]) + int(fields[12])}
        except (OSError, ValueError, IndexError):
            errors += 1
    return result, errors

def temperatures():
    result, errors = {}, []
    for zone in sorted(Path('/sys/class/thermal').glob('thermal_zone*')):
        try:
            kind = (zone / 'type').read_text().strip()
            if kind in ('acpitz', 'TCPU', 'x86_pkg_temp'):
                path = zone / 'temp'
                result[str(path)] = {'kind': kind, 'millidegrees_C': int(path.read_text())}
        except (OSError, ValueError):
            errors.append(str(zone))
    for chip in sorted(Path('/sys/class/hwmon').glob('hwmon*')):
        try:
            if (chip / 'name').read_text().strip() != 'coretemp':
                continue
            for path in sorted(chip.glob('temp*_input')):
                try:
                    result[str(path)] = {'kind': 'coretemp', 'millidegrees_C': int(path.read_text())}
                except (OSError, ValueError):
                    errors.append(str(path))
        except (OSError, ValueError):
            errors.append(str(chip))
    return result, errors

hz = os.sysconf('SC_CLK_TCK')
began = time.monotonic()
began_utc = utc()
previous, _ = processes()
previous_at = time.monotonic()
rows = []
for index in range(30):
    due = began + index + 1
    remaining = due - time.monotonic()
    if remaining > 0:
        time.sleep(remaining)
    if time.monotonic() - began >= 30:
        break
    current, process_errors = processes()
    now = time.monotonic()
    span = now - previous_at
    ranked = []
    for key, process in current.items():
        if key in previous:
            ticks = process['cpu_ticks'] - previous[key]['cpu_ticks']
            if ticks >= 0:
                ranked.append({k: process[k] for k in ('pid', 'start_ticks', 'comm', 'ppid')} |
                              {'cpu_ticks_delta': ticks, 'cpu_cores': ticks / hz / span,
                               'cpu_percent': 100 * ticks / hz / span})
    ranked.sort(key=lambda row: row['cpu_ticks_delta'], reverse=True)
    sensors, thermal_errors = temperatures()
    rows.append({'index': index, 'at_utc': utc(), 'monotonic_seconds': now,
                 'elapsed_seconds': now - began, 'delta_seconds': span,
                 'selected_temperatures': sensors, 'thermal_read_errors': thermal_errors,
                 'process_count': len(current), 'process_read_errors': process_errors,
                 'top10_cpu_deltas': ranked[:10]})
    previous, previous_at = current, now
result = {'schema': 1, 'scope': 'One read-only host observation, approximately 30 seconds at one-second cadence. Selected guard thermal/coretemp inputs; process identity and CPU deltas only, no arguments or environment. Co-observed load is not causal attribution and cannot explain earlier heat retrospectively.',
          'started_at_utc': began_utc, 'finished_at_utc': utc(),
          'elapsed_seconds': time.monotonic() - began, 'clock_ticks_per_second': hz,
          'observer_pid': os.getpid(), 'cpu_count': os.cpu_count(),
          'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'rows': rows}
with OUTPUT.open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({'output': str(OUTPUT), 'rows': len(rows), 'elapsed_seconds': result['elapsed_seconds']}))
