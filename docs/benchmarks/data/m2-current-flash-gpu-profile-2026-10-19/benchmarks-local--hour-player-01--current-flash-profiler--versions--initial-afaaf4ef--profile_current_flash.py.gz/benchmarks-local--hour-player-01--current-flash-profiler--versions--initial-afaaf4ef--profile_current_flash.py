#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Dry by default: one current-Flash exact-PCM Vulkan operation profile, no UI/audio load.

Only --run imports the worker/NumPy, queries admission or creates processes.
Profiling adds timestamps, barriers and query/printing work. Its operation GPU
intervals are not exclusive kernel time, and this is neither a latency gate nor
an overhead comparison. Ordinary benchmark diagnostic-flag guards stay intact.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True
SELF = Path(__file__).resolve()
BASE = SELF.parent
ROOT = SELF.parents[3]
OLD = ROOT / "benchmarks-local/m2-graph-phase-2026-10-18"
RUNTIME = OLD / "flash-promoted-native-build/conflux-stem-runtime"
HELPERS = {
    "comparison": (OLD / "compare_runtime.py", "5022aeed8eaf932adead05404f80b94c7d992f4b6f68dc81d05edb6126077e5b"),
    "launch": (OLD / "compare_launch.py", "338a42325617a19f72771239b00de17f4d12b822949e06966d598af95f5be7a8"),
    "retained": (OLD / "observed_launch.py", "511bb712d2f7af01abb1ab25ca92b001c6f82af4ee6f42547a5b43fa32b237d6"),
}
PROOF = OLD / "flash-promoted-repro-01/result.json"
PROOF_SHA = "44554b8e1caca9e92a49be7b9cc0e05ba7248f0091b4cdfc005e87e2c87ffe70"
CASE_IDS = ("club_xl:257985",)
ORDER = CASE_IDS
LOGGER_ENV = {"GGML_VK_PERF_LOGGER": "1", "GGML_VK_PERF_LOGGER_FREQUENCY": "1"}
LOGGER_KEYS = tuple(LOGGER_ENV) + ("GGML_VK_PERF_LOGGER_CONCURRENT",)
REQUEST_SECONDS, PROFILE_SECONDS = 30, 60
READINESS_SECONDS, TOTAL_SECONDS = 180, 300
STDERR_LIMIT = 8 * 1024 * 1024
SCOPE = ("One request in the exact promoted Flash Vulkan/two-thread/blocking/passive child; "
         "one fixed Club XL window checked against current promoted own-Flash PCM. "
         "No UI, audio output, policy/service mutation, timing qualification or "
         "overhead claim. Profiler barriers/timestamps/query/formatting perturb "
         "execution; GPU intervals include synchronization/internal work.")


def require(value, message):
    if not value:
        raise RuntimeError(message)


def load(name, path):
    spec = importlib.util.spec_from_file_location("conflux_ops_" + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save_stderr(native, output):
    native.stderr.flush()
    path = native.root / "runtime.stderr"
    total = path.stat().st_size
    with path.open("rb") as stream:
        contents = stream.read(STDERR_LIMIT)
    target = output / "native.stderr"
    target.write_bytes(contents)
    return {"path": str(target), "bytes": len(contents), "original_bytes": total,
            "truncated": total > len(contents), "limit_bytes": STDERR_LIMIT,
            "sha256": hashlib.sha256(contents).hexdigest()}


def cleanup_request(native, row):
    # A failed request may still be writing. The outer reap proof owns its files.
    if row.get("completed") is True:
        for name in ("input.f32", "output.f32"):
            (native.root / name).unlink(missing_ok=True)


def cleanup_native(native, initialized, output):
    """Close this NativeRuntime's known fields, including a failed constructor."""
    process, root = getattr(native, "process", None), getattr(native, "root", None)
    errors, stderr_record = [], None
    cleanup = {"native_started": process is not None, "native_constructed": initialized}
    if process is not None:
        cleanup["native_pid"] = process.pid
        try:
            if process.poll() is None:
                process.kill()
            process.wait(timeout=3)
        except Exception as error:
            errors.append({"phase": "native_reap", "message": str(error)})
    reaped = process is None or process.poll() is not None
    # Keep the complete bounded log before normal close removes its directory.
    if reaped and root is not None and (root / "runtime.stderr").is_file():
        try:
            stderr_record = save_stderr(native, output)
        except Exception as error:
            errors.append({"phase": "native_log_cleanup", "message": str(error)})
    normal_closed = False
    if initialized and reaped:
        try:
            native.close()
            normal_closed = True
        except Exception as error:
            errors.append({"phase": "native_close", "message": str(error)})
    resource_errors = []
    if not normal_closed:
        # __init__ may have spawned before selector allocation/register failed.
        # Each exact resource is independent: one close error cannot skip others.
        for name, resource in (("selector", getattr(native, "selector", None)),
                               ("stdin", getattr(process, "stdin", None)),
                               ("stdout", getattr(process, "stdout", None)),
                               ("stderr", getattr(native, "stderr", None))):
            if resource is not None:
                try:
                    resource.close()
                except Exception as error:
                    resource_errors.append({"phase": "native_partial_" + name, "message": str(error)})
        directory = getattr(native, "directory", None)
        if directory is not None and (process is None or process.poll() is not None):
            try:
                directory.cleanup()
            except Exception as error:
                resource_errors.append({"phase": "native_partial_directory", "message": str(error)})
    cleanup.update(native_reaped=process is None or process.poll() is not None,
                   native_returncode=process.returncode if process is not None else None,
                   normal_close_returned=normal_closed, native_resources_closed=not resource_errors,
                   temporary_directory_removed=root is None or not root.exists())
    return cleanup, stderr_record, errors + resource_errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("name", help="Fresh plain run/readiness label")
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--readiness-decision", type=Path, default=BASE / "human-readiness.json")
    parser.add_argument("--source-pins", type=Path, default=BASE / "comparison-source-pins.json")
    args = parser.parse_args()
    require(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,95}", args.name), "Use a fresh plain run label")
    output = BASE / args.name
    if not args.run:
        print(json.dumps({"schema": 1, "status": "dry_run", "native_started": False,
              "host_queried": False, "output": str(output), "cases": list(ORDER),
              "child_environment": LOGGER_ENV, "child_unset": ["GGML_VK_PERF_LOGGER_CONCURRENT"],
              "readiness_decision": str(args.readiness_decision), "source_pins": str(args.source_pins),
              "expected_pins": str(BASE / "expected-pins.json"), "comparison_proof": str(PROOF),
              "request_timeout_seconds": REQUEST_SECONDS, "profile_budget_seconds": PROFILE_SECONDS,
              "readiness_maximum_seconds": READINESS_SECONDS, "maximum_total_seconds": TOTAL_SECONDS,
              "stderr_limit_bytes": STDERR_LIMIT, "scope": SCOPE}, indent=2))
        return 0

    require(args.source_pins.is_absolute() and args.readiness_decision.is_absolute(), "Use absolute input paths")
    require(not output.exists(), "Output exists; use a fresh label")
    output.mkdir(mode=0o700)
    admission = output / "admission"
    admission.mkdir()
    started, native, readiness_child = time.monotonic(), None, None
    native_initialized = False
    deadline = started + TOTAL_SECONDS
    report = {"schema": 1, "status": "checking", "native_started": False,
              "scope": SCOPE, "requests": [], "errors": [], "pins_before": {}, "pins_after": {},
              "AC_lid": [], "cleanup": {}, "child_environment": LOGGER_ENV,
              "child_unset": ["GGML_VK_PERF_LOGGER_CONCURRENT"], "planned_requests": 1,
              "request_timeout_seconds": REQUEST_SECONDS, "profile_budget_seconds": PROFILE_SECONDS,
              "maximum_total_seconds": TOTAL_SECONDS, "UI_load": False, "audio_load": False,
              "profile_mutation": False, "service_mutation": False, "pins_unchanged": False}
    comparison = launch = retained = admission_helper = None
    specs, handlers, watchdog_errors = {}, {}, []
    watchdog_stop, watchdog = threading.Event(), None
    constructing_child = False

    def checkpoint():
        report["elapsed_seconds"] = time.monotonic() - started
        if comparison is not None:
            comparison.atomic_json(output / "result.json", report)
        else:
            temp = output / "result.json.tmp"
            temp.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
            temp.replace(output / "result.json")

    def interrupted(signum, _frame):
        report["interruption_signal"] = signum
        if not constructing_child:
            raise KeyboardInterrupt

    def ac_lid(phase):
        row = {"phase": phase, **admission_helper.ac_lid()}
        report["AC_lid"].append(row)
        checkpoint()
        require(row["ready"], "AC/lid observation failed or changed: " + phase)

    try:
        handlers = {sig: signal.signal(sig, interrupted) for sig in (signal.SIGINT, signal.SIGTERM)}
        checkpoint()
        # No worker import until all directly imported helpers have frozen hashes.
        for name, (path, digest) in HELPERS.items():
            require(path.is_file() and path.stat().st_size <= 128 * 1024
                    and hashlib.sha256(path.read_bytes()).hexdigest() == digest,
                    "Frozen helper differs: " + name)
        comparison = load("comparison", HELPERS["comparison"][0])
        comparison.DIAGNOSTIC = RUNTIME
        launch = load("launch", HELPERS["launch"][0])
        retained = load("retained", HELPERS["retained"][0])
        config = BASE / "expected-pins.json"
        _, config_bytes = comparison.inspect_file(config, 64 * 1024, deadline, keep=True)
        expected = comparison.decode_json(config_bytes)
        require(expected.get("status") == "ready"
                and re.fullmatch(r"[0-9a-f]{40}", expected.get("repository_head", ""))
                and comparison.HEX.fullmatch(expected.get("pins", {}).get("runtime", ""))
                and expected["pins"].get("model") == comparison.MODEL_SHA,
                "Expected HEAD/runtime/model pins are not armed")
        require(retained.head() == expected["repository_head"], "Exact expected HEAD differs")
        report.update(started_at_utc=comparison.utc(), expected_producer=expected,
                      repository_head=expected["repository_head"])
        initial_human = launch.human_readiness(args.readiness_decision, args.name)
        require(initial_human["record"].get("Codex_minimized") is True and
                initial_human["record"].get("other_work_paused") is True,
                "Fresh readiness must also cover minimized Codex and paused other work")
        report["human_readiness_before_setup"] = initial_human
        _, sources = comparison.source_specs(args.source_pins, deadline)
        specs = {"runtime": (comparison.DIAGNOSTIC, expected["pins"]["runtime"], 256 * 1024 * 1024),
                 "model": (comparison.MODEL, comparison.MODEL_SHA, 2 * 1024 * 1024 * 1024),
                 "proof": (PROOF, PROOF_SHA, 2 * 1024 * 1024)}
        for path, digest in sources.items():
            specs["source:" + path] = (Path(path), digest, 32 * 1024 * 1024)
        for name, (path, digest) in HELPERS.items():
            specs["helper:" + name] = (path, digest, 128 * 1024)
        for name in ("admission_source", "readiness_source", "native_replay_source"):
            path, digest = retained.HELPERS[name]
            specs["helper:" + name] = (path, digest, 128 * 1024)
        for name, path in (("driver", SELF), ("config", config), ("source_pins", args.source_pins),
                           ("human_readiness", args.readiness_decision)):
            pin, _ = comparison.inspect_file(path, 128 * 1024, deadline)
            specs[name] = (path, pin["sha256"], 128 * 1024)
        for label, digest in comparison.TRACKS:
            specs["asset:" + label] = (comparison.ASSETS / f"{label}-30s-23p4s.wav", digest, comparison.ASSET_BYTES)
        report["pins_before"] = comparison.capture_pins(specs, deadline)
        _, proof_bytes = comparison.inspect_file(PROOF, 2 * 1024 * 1024, deadline, expected=PROOF_SHA, keep=True)
        proof = comparison.decode_json(proof_bytes)
        require(proof.get("status") == "reproduction_complete" and proof.get("cleanup_complete") is True
                and proof.get("private_spool_removed") is True and proof.get("pins_unchanged") is True
                and proof.get("all_outputs_match_closed_B") is True and proof.get("input_sha_match") is True
                and proof.get("phase_fields_valid") is True and proof.get("completed_requests") == 16
                and proof.get("runtime_sha256") == expected["pins"]["runtime"]
                and proof.get("model_sha256") == expected["pins"]["model"]
                and len(proof["runtimes"]) == 1 and proof["runtimes"][0]["label"] == "diagnostic"
                and proof["runtimes"][0]["executable"] == str(RUNTIME), "Current own-Flash proof differs")
        for key in ("runtime", "model"):
            require(proof["pins_before"][key]["sha256"] == proof["pins_after"][key]["sha256"] == expected["pins"][key],
                    "Current Flash reference artifact pin differs: " + key)
        report["comparison_proof"] = {"pin": comparison.inspect_file(PROOF, 2 * 1024 * 1024, deadline)[0],
                                      "status": proof["status"], "own_Flash_PCM": True, "threads": 2}
        expected_cases = {row["id"]: row for row in proof["runtimes"][0]["requests"] if row["id"] in CASE_IDS}
        require(set(expected_cases) == set(CASE_IDS), "Retained current-Flash case proof incomplete")
        # Presence-tested Vulkan flags must be absent, even when their value is 0.
        forbidden = set(comparison.DEBUG_FLAGS) | set(LOGGER_KEYS) | {
            "GGML_VK_SYNC_LOGGER", "GGML_VK_MEMORY_LOGGER", "GGML_VK_PIPELINE_STATS"}
        require(not forbidden.intersection(os.environ)
                and not any(key.startswith(("GGML_VK_", "GGML_VULKAN_")) for key in os.environ),
                "Inherited GPU diagnostic/backend flags must be unset")
        report["inherited_compute_environment"] = {key: value for key, value in os.environ.items()
            if key.startswith(("MESA_", "INTEL_", "GGML_", "OMP_", "GOMP_"))}
        np, NativeRuntime, prepared = comparison.prepare_cases(comparison.load_track_plan(deadline), deadline)
        cases = {case["id"]: case for case in prepared if case["id"] in CASE_IDS}
        del prepared
        require(set(cases) == set(CASE_IDS), "Prepared single-case selection incomplete")
        for case_id, case in cases.items():
            proven = expected_cases[case_id]
            require(all(case[key] == proven[key] for key in
                        ("input_sha256", "shape", "dtype", "valid_frames", "normalization")),
                    "Normalized input differs from immutable proof: " + case_id)
        report.update(numpy_version=np.__version__, python_version=sys.version,
                      cases=[{k: v for k, v in cases[key].items() if k != "samples"} for key in CASE_IDS])
        admission_helper = load("admission", retained.HELPERS["admission_source"][0])
        admission_helper.readiness_module()
        ac_lid("before_normal_readiness")
        command = [sys.executable, "-B", "-c",
                   "import runpy,sys;from pathlib import Path;sys.exit(runpy.run_path(sys.argv[1])['run']('admission',Path(sys.argv[2])))",
                   str(retained.HELPERS["readiness_source"][0]), str(admission)]
        report.update(status="normal_readiness", readiness_command=command)
        checkpoint()
        with (admission / "stdout").open("x") as out, (admission / "stderr").open("x") as err:
            constructing_child = True
            try:
                readiness_child = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err, start_new_session=True)
            finally:
                constructing_child = False
            if "interruption_signal" in report:
                raise KeyboardInterrupt
            until, next_ac = min(deadline - PROFILE_SECONDS - 60, time.monotonic() + READINESS_SECONDS), 0
            while readiness_child.poll() is None:
                require(time.monotonic() < until, "Normal readiness exhausted bounded wait")
                if time.monotonic() >= next_ac:
                    ac_lid("normal_readiness")
                    next_ac = time.monotonic() + 45
                time.sleep(.25)
            report["readiness_returncode"] = readiness_child.wait()
        require(report["readiness_returncode"] == 0, "Normal readiness did not match")
        report["pins_before_native"] = comparison.capture_pins(specs, deadline)
        require(report["pins_before_native"] == report["pins_before"]
                and retained.head() == expected["repository_head"], "HEAD/source/artifact/config changed during setup")
        report["human_readiness_before_native"] = launch.human_readiness(args.readiness_decision, args.name)
        require(report["human_readiness_before_native"]["pin"] == initial_human["pin"], "Human readiness record changed")
        report["admission"] = admission_helper.fresh_admission(admission)
        profile_started = time.monotonic()
        profile_deadline = min(deadline - 60, profile_started + PROFILE_SECONDS)
        report.update(status="profiling", profile_started_monotonic=profile_started, profile_started_at_utc=comparison.utc(),
                      native_construction_attempted=True)
        checkpoint()
        # Constructor copies the environment into the child. Defer a parent
        # interruption until assignment/restore; never pass a blocked signal mask
        # to either child. No other process is launched while these flags are set.
        constructing_child = True
        try:
            saved_env = {key: os.environ.get(key) for key in LOGGER_KEYS}
            try:
                os.environ.update(LOGGER_ENV)
                os.environ.pop("GGML_VK_PERF_LOGGER_CONCURRENT", None)
                # Retain the owner BEFORE __init__: selector allocation/register
                # can raise after Popen, so a normal constructor assignment leaks.
                native = NativeRuntime.__new__(NativeRuntime)
                try:
                    NativeRuntime.__init__(native, comparison.DIAGNOSTIC, comparison.MODEL, "vulkan", 2,
                        min(REQUEST_SECONDS, comparison.check_deadline(profile_deadline)), passive_openmp=True,
                        spool_directory=output / "native-spool")
                    native_initialized = True
                finally:
                    report["native_started"] = getattr(native, "process", None) is not None
                    report["native_construction_completed"] = native_initialized
            finally:
                for key, value in saved_env.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value
        finally:
            constructing_child = False
        if "interruption_signal" in report:
            raise KeyboardInterrupt
        report.update(pid=native.process.pid, temporary_directory=str(native.root))
        proc_fields = (Path("/proc") / str(native.process.pid) / "stat").read_text().rsplit(")", 1)[1].split()
        report["native_identity"] = {"pid": native.process.pid, "start_ticks": int(proc_fields[19]),
                                     "group": int(proc_fields[2]), "session": int(proc_fields[3]),
                                     "command": [str(RUNTIME), "--model", str(comparison.MODEL), "--backend", "vulkan", "--threads", "2"]}

        def monitor_native():
            while not watchdog_stop.wait(.05):
                try:
                    require(time.monotonic() < profile_deadline, "Native profile budget exhausted")
                    require((native.root / "runtime.stderr").stat().st_size <= STDERR_LIMIT,
                            "Native stderr exceeded 8MiB; diagnostic aborted")
                except Exception as error:
                    watchdog_errors.append({"type": type(error).__name__, "message": str(error)})
                    native.abort()
                    return
        watchdog = threading.Thread(target=monitor_native, name="conflux-ops-log-bound", daemon=True)
        watchdog.start()
        began_ready = time.monotonic()
        ready = native.start()
        report.update(ready=ready, startup_wall_ms=(time.monotonic() - began_ready) * 1000)
        require(ready.get("backend") == "vulkan" and ready.get("threads") == 2
                and ready.get("revision") == comparison.REVISION and ready.get("model") == str(comparison.MODEL)
                and ready.get("pid") == native.process.pid and ready.get("weight_storage") == "native"
                and ready.get("fence_wait_mode") == "blocking"
                and ready.get("process_environment") == {"OMP_WAIT_POLICY": "PASSIVE", "GOMP_SPINCOUNT": "0"},
                "Native readiness differs from pinned configuration")
        comparison.validate_number(ready, "load_ms")
        checkpoint()
        for request_id, case_id in enumerate(ORDER, 1):
            ac_lid("before_request_" + str(request_id))
            require(not watchdog_errors, "Native watchdog failed")
            case, proven = cases[case_id], expected_cases[case_id]
            native.timeout = min(REQUEST_SECONDS, comparison.check_deadline(profile_deadline))
            offset = (native.root / "runtime.stderr").stat().st_size
            row = {"request_id": request_id, "case_id": case_id, "repetition": (request_id - 1) // 2 + 1,
                   "started_monotonic": time.monotonic(), "started_at_utc": comparison.utc(), "stderr_begin": offset, "completed": False}
            report["requests"].append(row)
            checkpoint()
            produced = None
            try:
                produced, metrics = native.infer(case["samples"], request_id)
                row.update(finished_monotonic=time.monotonic(), native_metrics=metrics)
                row["request_wall_ms"] = (row["finished_monotonic"] - row["started_monotonic"]) * 1000
                require(not watchdog_errors, "Native watchdog failed during request")
                for name in comparison.COMMON_TIMINGS + comparison.PHASE_TIMINGS:
                    comparison.validate_number(metrics, name)
                for name in comparison.SWITCH_COUNTS:
                    comparison.validate_number(metrics, name, integral=True)
                require(produced.shape == (4, comparison.WINDOW, 2) and produced.dtype.str == "<f4"
                        and produced.flags.c_contiguous and np.isfinite(produced).all(), "Native PCM contract differs")
                actual_input, _ = comparison.inspect_file(native.root / "input.f32", comparison.WINDOW * 8,
                    profile_deadline, expected=proven["input_sha256"])
                row.update(input_sha256=actual_input["sha256"], output_sha256=hashlib.sha256(memoryview(produced)).hexdigest(),
                           output_shape=list(produced.shape), output_dtype=produced.dtype.str,
                           output_bytes=produced.nbytes, expected_output_sha256=proven["output_sha256"])
                require(row["output_sha256"] == proven["output_sha256"], "Exact PCM mismatch: " + case_id)
                row["stderr_end"] = end = (native.root / "runtime.stderr").stat().st_size
                require(offset <= end <= STDERR_LIMIT, "Native stderr size bound exceeded")
                with (native.root / "runtime.stderr").open("rb") as stream:
                    stream.seek(offset)
                    table = stream.read(end - offset)
                totals = re.findall(rb"^Total time: ([0-9.eE+-]+) us\.$", table, re.MULTILINE)
                require(table.count(b"Vulkan Timings:\n") == 1 and len(totals) == 1,
                        "Expected exactly one complete operation table per request")
                row["profiled_gpu_interval_total_us"] = float(totals[0])
                require(math.isfinite(row["profiled_gpu_interval_total_us"])
                        and row["profiled_gpu_interval_total_us"] > 0, "Invalid profiler interval total")
                row.update(completed=True, exact_pcm_match=True, finished_at_utc=comparison.utc())
            finally:
                produced = None
                cleanup_request(native, row)
                checkpoint()
            ac_lid("after_request_" + str(request_id))
        report["host_after"] = admission_helper.readiness_module().capture(
            Path(json.loads((admission / "admission-normal-ready.json").read_text())["package_zone"]),
            min(deadline - 30, time.monotonic() + 12))
        require(not report["host_after"]["errors"] and
                admission_helper.readiness_module().identity(report["host_after"]) == report["admission"]["same_guard_service_identity"],
                "Existing thermal guard identity changed during profiling")
        report.update(status="passed", exact_pcm_match=True,
                      profile_elapsed_seconds=time.monotonic() - profile_started)
    except KeyboardInterrupt:
        report["status"] = "interrupted"
    except Exception as error:
        report["status"] = "failed"
        report["errors"].append({"type": type(error).__name__, "message": str(error)[:8192]})
    finally:
        for sig in handlers:
            signal.signal(sig, signal.SIG_IGN)
        if readiness_child is not None:
            try:
                if readiness_child.poll() is None:
                    os.killpg(readiness_child.pid, signal.SIGINT)
                    try:
                        readiness_child.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        os.killpg(readiness_child.pid, signal.SIGKILL)
                readiness_child.wait(timeout=3)
                report["cleanup"]["readiness_reaped"] = True
            except Exception as error:
                report["cleanup"]["readiness_reaped"] = False
                report["errors"].append({"phase": "readiness_cleanup", "message": str(error)})
        watchdog_stop.set()
        if watchdog is not None:
            watchdog.join(timeout=2)
        report["watchdog_errors"] = watchdog_errors
        if native is not None:
            native_cleanup, stderr_record, cleanup_errors = cleanup_native(native, native_initialized, output)
            report["cleanup"].update(native_cleanup)
            report["errors"].extend(cleanup_errors)
            if stderr_record is not None:
                report["native_stderr"] = stderr_record
        if admission_helper is not None and (admission / "admission-normal-ready.json").is_file() and "host_after" not in report:
            try:
                zone = Path(json.loads((admission / "admission-normal-ready.json").read_text())["package_zone"])
                report["host_after"] = admission_helper.readiness_module().capture(zone, min(deadline - 10, time.monotonic() + 12))
            except Exception as error:
                report["errors"].append({"phase": "host_after", "message": str(error)})
        report["cleanup"]["watchdog_joined"] = watchdog is None or not watchdog.is_alive()
        if specs:
            try:
                report["pins_after"] = comparison.capture_pins(specs, min(deadline, time.monotonic() + 60), verify=False)
                report["pins_unchanged"] = report["pins_after"] == report["pins_before"]
                report["head_after"] = retained.head()
                require(report["head_after"] == report["repository_head"], "HEAD changed during diagnostic")
            except Exception as error:
                report["errors"].append({"phase": "after_pins", "message": str(error)})
        complete = (native is not None and report["cleanup"].get("native_reaped")
                    and report["cleanup"].get("native_resources_closed")
                    and report["cleanup"].get("temporary_directory_removed")
                    and report["cleanup"].get("watchdog_joined")
                    and report["cleanup"].get("readiness_reaped")
                    and len(report["requests"]) == 1 and all(row["completed"] for row in report["requests"]))
        if report["status"] == "passed" and (not complete or not report["pins_unchanged"]
                or report["errors"] or watchdog_errors or report.get("native_stderr", {}).get("truncated", True)):
            report["status"] = "failed"
        report["cleanup_complete"] = bool(native is not None and report["cleanup"].get("native_reaped")
            and report["cleanup"].get("native_resources_closed")
            and report["cleanup"].get("temporary_directory_removed") and report["cleanup"].get("watchdog_joined")
            and report["cleanup"].get("readiness_reaped"))
        report["finished_at_utc"] = comparison.utc() if comparison is not None else None
        checkpoint()
        for sig, handler in handlers.items():
            signal.signal(sig, handler)
    print(json.dumps({"status": report["status"], "result": str(output / "result.json"),
                      "completed_requests": sum(row["completed"] for row in report["requests"])}))
    return 0 if report["status"] == "passed" else 130 if report["status"] == "interrupted" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, ValueError) as error:
        print("operation profiler admission failed: " + str(error), file=sys.stderr)
        raise SystemExit(1)
