#!/usr/bin/env python3
"""Archive closed profile05 text evidence without executing its code or using Git."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import stat
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HOUR = ROOT / "benchmarks-local/hour-player-01"
PROFILE = HOUR / "current-flash-profiler"
DEST = ROOT / "docs/benchmarks/data/m2-current-flash-gpu-profile-2026-10-19"
STAGE = HOUR / "profile05-archive-stage"
RAW = HOUR / "profile05-archive-raw"
INVENTORY = HOUR / "profile05-archive-inputs.json"
SUMMARY = HOUR / "profile05-archive-summary.json"
SCAN_LOG = HOUR / "profile05-archive-gitleaks.log"
SCAN_REPORT = HOUR / "profile05-archive-gitleaks-findings.json"
HEAD = "7c130e1a9cef91639a219db30f78857f8c515772"
LIMIT = 16 * 1024 * 1024
ALLOWED = {".json", ".jsonl", ".py", ".patch", ".stderr", ".stdout", ".txt", ".log"}


def pin(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def read(path):
    assert path.is_relative_to(ROOT)
    for item in (path, *path.relative_to(ROOT).parents):
        actual = item if item.is_absolute() else ROOT / item
        assert not actual.is_symlink(), str(actual)
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size <= LIMIT
    data = path.read_bytes()
    after = path.lstat()
    signature = lambda info: (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
    assert signature(before) == signature(after) and len(data) == before.st_size
    assert b"\0" not in data
    data.decode("utf-8")
    return data


def dump(path, value):
    data = (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(data)
    return data


def profile_paths():
    included, excluded = set(), []
    for folder, dirs, names in os.walk(PROFILE, followlinks=False):
        parent = Path(folder)
        kept = []
        for name in sorted(dirs):
            path = parent / name
            if name == "__pycache__" or path.is_symlink():
                excluded.append({"path": str(path.relative_to(ROOT)), "reason": "pycache_or_symlink_directory"})
            else:
                kept.append(name)
        dirs[:] = kept
        for name in sorted(names):
            path = parent / name
            if path.is_symlink():
                excluded.append({"path": str(path.relative_to(ROOT)), "reason": "symlink"})
            elif path.suffix in ALLOWED or name in {"stdout", "stderr"}:
                assert stat.S_ISREG(path.lstat().st_mode)
                included.add(path)
            else:
                excluded.append({"path": str(path.relative_to(ROOT)), "reason": "outside_named_text_suffixes"})
    return included, excluded


assert not any(os.path.lexists(path) for path in (DEST, STAGE, RAW, INVENTORY, SUMMARY, SCAN_LOG, SCAN_REPORT))
paths, excluded = profile_paths()
profile_inputs = set(paths)
paths.add(Path(__file__).resolve())
paths.add(ROOT / "benchmarks-local/m2-graph-phase-2026-10-18/flash-promoted-repro-01/result.json")
paths.update(HOUR / name for name in (
    "pr32-complete.json", "pr32-merge-signature.json", "pr32-feature-coverage-audit.json",
    "pr32-feature-coverage-metadata.json", "pr32-feature-ci.json", "pr32-pr-ci.json",
    "pr32-develop-ci.json", "profile05-work-branch.json"))

# Freeze the complete source list and every source byte hash before creating raw/stage files.
frozen = {str(path.relative_to(ROOT)): read(path) for path in sorted(paths)}
inputs = {name: pin(data) for name, data in frozen.items()}
assert sum(item["bytes"] for item in inputs.values()) <= LIMIT
inventory = {
    "schema": "conflux.profile05-archive-inputs.v1", "source_head": HEAD,
    "profile_scope": str(PROFILE.relative_to(ROOT)), "source_input_count": len(inputs),
    "source_input_bytes": sum(item["bytes"] for item in inputs.values()),
    "maximum_raw_bytes": LIMIT, "inputs": inputs, "excluded_profile_paths": excluded,
    "scope": "All named UTF-8 profile source/metadata/raw logs/history, plus explicit small reference/PR32 receipts and this builder. Generated inventory/summary and scanner receipts are separately identified archive controls. No root CURRENT state, raw PCM, audio, model, executable, cache or CI artifact directory."
}
inventory_data = dump(INVENTORY, inventory)

def load(path):
    return json.loads(frozen[str(path.relative_to(ROOT))])


result = load(PROFILE / "current-flash-profile-05/result.json")
request = result["requests"][0]
host = load(PROFILE / "profile05-host-audit.json")
operation = load(PROFILE / "profile05-operation-audit.json")
signature = load(HOUR / "pr32-merge-signature.json")
complete = load(HOUR / "pr32-complete.json")
proof_path = ROOT / "benchmarks-local/m2-graph-phase-2026-10-18/flash-promoted-repro-01/result.json"
proof = load(proof_path)
assert signature["sha"] == complete["merge_head"] == result["repository_head"] == result["head_after"] == HEAD
assert signature["verification"] == {"reason": "valid", "verified": True}
assert result["status"] == "passed" and result["planned_requests"] == len(result["requests"]) == 1
assert result["exact_pcm_match"] and request["completed"] and request["exact_pcm_match"]
assert not result["errors"] and not result["watchdog_errors"] and result["cleanup_complete"]
assert result["pins_before"] == result["pins_after"] and result["pins_unchanged"]
assert result["pins_before"]["driver"]["sha256"] == "79061da525dc749e16bd974181cb5f91b66049624d50da5796a9b5b0baabb622"
assert host["pins"]["count"] == 37 and host["pins"]["current_rehash_all_matches_recorded_after"]
assert inputs[str(proof_path.relative_to(ROOT))]["sha256"] == "44554b8e1caca9e92a49be7b9cc0e05ba7248f0091b4cdfc005e87e2c87ffe70"
reference = next(row for row in proof["runtimes"][0]["requests"] if row["id"] == request["case_id"])
assert request["output_sha256"] == request["expected_output_sha256"] == reference["output_sha256"]
attempts = []
for number in range(1, 5):
    name = f"current-flash-profile-{number:02d}"
    attempt = load(PROFILE / name / "result.json")
    assert attempt["status"] == "failed" and attempt["native_started"] is False
    attempts.append({"name": name, "status": attempt["status"], "native_started": False,
                     "elapsed_seconds": attempt["elapsed_seconds"], "errors": attempt["errors"]})
summary = {
    "schema": "conflux.m2-current-flash-gpu-profile-summary.v1", "source_head": HEAD,
    "status": "one_current_flash_gpu_operation_profile_passed_four_preflights_failed",
    "m2_open": True, "sustained_actual_player_qualified": False,
    "source_signature": {"kind": "retained_GitHub_commit_API_receipt", "verified": True,
                         "reason": "valid", "receipt": "benchmarks-local/hour-player-01/pr32-merge-signature.json",
                         "receipt_sha256": inputs["benchmarks-local/hour-player-01/pr32-merge-signature.json"]["sha256"]},
    "profile": {"name": "current-flash-profile-05", "status": "passed", "completed_requests": 1,
                "case_id": request["case_id"], "exact_pcm_match": True,
                "output_sha256": request["output_sha256"], "output_shape": request["output_shape"],
                "output_dtype": request["output_dtype"], "output_bytes": request["output_bytes"],
                "request_wall_ms": request["request_wall_ms"],
                "graph_compute_ms": request["native_metrics"]["graph_compute_ms"],
                "startup_wall_ms": result["startup_wall_ms"], "profile_elapsed_seconds": result["profile_elapsed_seconds"],
                "elapsed_with_admission_seconds": result["elapsed_seconds"],
                "backend": "vulkan", "threads": result["ready"]["threads"],
                "fence_wait_mode": result["ready"]["fence_wait_mode"],
                "process_environment": result["ready"]["process_environment"],
                "native_stderr": result["native_stderr"], "cleanup_complete": True},
    "failed_preflights": attempts,
    "operation_summary": {key: operation["table"][key] for key in
                          ("rows", "logged_node_or_fusion_intervals", "reported_total_ms", "categories")},
    "operation_limit": operation["interpretation"]["dispatch_conclusion"],
    "pins": {"count": 37, "current_rehash_all_match_from_independent_host_audit": True,
             "before_after_equal": True, "runtime_sha256": result["pins_after"]["runtime"]["sha256"],
             "model_sha256": result["pins_after"]["model"]["sha256"],
             "historical_driver_sha256": result["pins_after"]["driver"]["sha256"]},
    "host": {"fresh_admission_package_C": result["admission"]["live_normal_readiness"]["package_millidegrees_C"] / 1000,
             "after_request_package_C": result["host_after"]["package_millidegrees_C"] / 1000,
             "kernel_conclusion": host["kernel_conclusion"],
             "native_cleanup": "Completed request followed by owned native reap/resource/spool cleanup; -9 is not a cancellation-test result."},
    "unchanged_acceptance": {"strict_service_p99_target_ms": 4095, "p99_measured": False,
                             "audio_UI_qualified": False, "cancellation_exercised": False,
                             "actual_hour_qualified": False, "musical_quality_rejudged": False},
    "claim_limits": ["One diagnostic request gives no p99/tail, sustained timing, profiler-overhead or playback qualification.",
                     "No causal claim links Codex closure or hashing to this result or the earlier GPU hang.",
                     "No visible matching kernel entries in the exact retained window does not establish global absence or reproduce/explain the earlier i915 hang.",
                     "Archive contains code and text evidence with digest inventory; it contains no raw PCM/audio/model/executable."],
    "independent_audits": [str((PROFILE / name).relative_to(ROOT)) for name in
                           ("profile05-operation-audit.json", "profile05-host-audit.json", "profile05-next-step-review.json")]
}
summary_data = dump(SUMMARY, summary)

STAGE.mkdir(mode=0o700)
RAW.mkdir(mode=0o700)
files, uncompressed, origins = {}, {}, {}


def add(origin_path, data):
    origin_name = str(origin_path.relative_to(ROOT))
    name = origin_name.replace("/", "--")
    packed_name = name + ".gz"
    assert packed_name not in files
    (RAW / name).write_bytes(data)
    packed = gzip.compress(data, mtime=0)
    assert packed[4:8] == b"\0\0\0\0"
    (STAGE / packed_name).write_bytes(packed)
    files[packed_name] = pin(packed)
    uncompressed[packed_name] = pin(data)
    origins[packed_name] = {"path": origin_name, **pin(data)}


for name, data in frozen.items():
    add(ROOT / name, data)
add(INVENTORY, inventory_data)
add(SUMMARY, summary_data)
raw_scanned_bytes = sum(item["bytes"] for item in uncompressed.values())
raw_scanned_files = len(files)
assert raw_scanned_bytes <= LIMIT
with SCAN_LOG.open("xb") as stream:
    scan = subprocess.run(["gitleaks", "dir", str(RAW), "--redact", "--no-color", "--report-format", "json",
                           "--report-path", str(SCAN_REPORT)], stdin=subprocess.DEVNULL,
                          stdout=stream, stderr=subprocess.STDOUT, timeout=60)
assert scan.returncode == 0 and json.loads(read(SCAN_REPORT)) == []
for path in (SCAN_LOG, SCAN_REPORT):
    add(path, read(path))

# Verify all archive layers against their current origins and the original frozen source list.
assert profile_paths() == (profile_inputs, excluded)
for name, expected in inputs.items():
    assert pin(read(ROOT / name)) == expected
for name, expected in files.items():
    packed = (STAGE / name).read_bytes()
    data = gzip.decompress(packed)
    origin = origins[name]
    assert pin(packed) == expected and pin(data) == uncompressed[name]
    assert pin(data) == {key: origin[key] for key in ("bytes", "sha256")}
    assert data == read(ROOT / origin["path"]) and packed == gzip.compress(data, mtime=0)
verification = {
    "schema": "conflux.m2-current-flash-gpu-profile.v1", "source_head": HEAD,
    "source_signature": summary["source_signature"], "status": summary["status"],
    "m2_open": True, "sustained_actual_player_qualified": False, "summary": summary,
    "files": files, "uncompressed": uncompressed, "origins": origins,
    "source_inputs": inputs, "source_input_count": len(inputs),
    "raw_source_input_bytes": inventory["source_input_bytes"],
    "raw_scanned_input_bytes": raw_scanned_bytes, "raw_scanned_file_count": raw_scanned_files,
    "maximum_raw_bytes": LIMIT, "raw_secret_scan_exit": scan.returncode,
    "raw_secret_scan_findings": 0, "source_inventory_unchanged_after_packaging": True,
    "generated_controls": [str(INVENTORY.relative_to(ROOT)), str(SUMMARY.relative_to(ROOT))],
    "scanner_outputs_added_after_scan": [str(SCAN_LOG.relative_to(ROOT)), str(SCAN_REPORT.relative_to(ROOT))],
    "scope": "Closed UTF-8 metadata/source/raw-log/history only; deterministic gzip mtime zero with compressed/raw/origin digests. All named P inputs frozen and rechecked; no root CURRENT, raw PCM/audio/model/executable/cache/CI artifact directory. Raw Gitleaks scan precedes packaging its empty finding and log receipts; verification itself and scanner output are not in that scan. Source signature is the retained valid GitHub receipt, not a new local Git invocation."
}
dump(STAGE / "verification.json", verification)
STAGE.rename(DEST)
print(json.dumps({"destination": str(DEST), "files": len(files) + 1, "source_inputs": len(inputs),
                  "raw_scanned_bytes": raw_scanned_bytes, "compressed_bytes": sum(item["bytes"] for item in files.values()),
                  "verification": pin((DEST / "verification.json").read_bytes()),
                  "source_head": HEAD, "raw_secret_scan_exit": scan.returncode,
                  "sustained_actual_player_qualified": False}, indent=2))
