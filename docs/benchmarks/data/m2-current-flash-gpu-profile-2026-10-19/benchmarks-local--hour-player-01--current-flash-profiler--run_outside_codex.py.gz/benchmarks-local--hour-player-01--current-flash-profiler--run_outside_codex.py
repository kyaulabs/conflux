#!/usr/bin/env python3
"""Human-operated, one-shot terminal entry for the reviewed silent diagnostic."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import stat
import sys

SELF = Path(__file__).resolve()
BASE = SELF.parent
PLAN = BASE / 'outside-codex-plan-05.json'
LABEL = 'current-flash-profile-05'
DRIVER = BASE / 'profile_current_flash.py'
CONFIG = BASE / 'expected-pins.json'
SOURCES = BASE / 'comparison-source-pins.json'
READINESS = BASE / 'human-readiness-05.json'
GUARD_SCRIPT = Path.home() / '.local/bin/thermal-guard'
GUARD_UNIT = Path.home() / '.config/systemd/user/thermal-guard.service'
PROMPT = ('Close Codex completely now. Keep AC connected, the lid open and other work paused.\n'
          'After Codex is closed, type READY to run one silent GPU request, allowing up to five minutes.\n'
          'Type anything else to cancel. Reopen Codex only after the shell prompt returns.\n> ')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def read_regular(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        before = os.fstat(descriptor)
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= 1024 * 1024,
                'Expected a bounded regular plan/source file: ' + str(path))
        data = bytearray()
        while len(data) < before.st_size:
            chunk = os.read(descriptor, before.st_size - len(data))
            require(bool(chunk), 'File shortened while validating: ' + str(path))
            data.extend(chunk)
        signature = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
        require(signature(before) == signature(os.fstat(descriptor)) == signature(os.stat(path, follow_symlinks=False)),
                'Plan/source changed while validating: ' + str(path))
        return bytes(data)
    finally:
        os.close(descriptor)


def command():
    return ['/bin/python3', '-B', str(DRIVER), LABEL, '--run',
            '--readiness-decision', str(READINESS), '--source-pins', str(SOURCES)]


def validate(plan):
    require(plan.get('status') == 'ready' and plan.get('label') == LABEL,
            'The terminal diagnostic plan is not armed for this exact fresh label')
    require(plan.get('command') == command() and plan.get('budgets') ==
            {'total_seconds': 300, 'request_seconds': 30, 'native_seconds': 60,
             'readiness_seconds': 195, 'cleanup_reserve_seconds': 45}, 'Diagnostic command or bounds differ')
    expected = {'helper': SELF, 'driver': DRIVER, 'config': CONFIG, 'source_pins': SOURCES,
                'guard_script': GUARD_SCRIPT, 'guard_unit': GUARD_UNIT}
    require(set(plan.get('files', {})) == set(expected), 'Missing frozen terminal inputs')
    contents = {}
    for name, path in expected.items():
        pinned = plan['files'][name]
        require(pinned.get('path') == str(path) and re.fullmatch('[0-9a-f]{64}', pinned.get('sha256', '')),
                'Frozen input path or hash differs: ' + name)
        contents[name] = read_regular(path)
        require(hashlib.sha256(contents[name]).hexdigest() == pinned['sha256'], 'Frozen input changed: ' + name)
    config = json.loads(contents['config'])
    require(config.get('status') == 'ready' and re.fullmatch('[0-9a-f]{40}', plan.get('repository_head', ''))
            and config.get('repository_head') == plan['repository_head'], 'Expected source HEAD is not armed')
    require(json.loads(contents['source_pins']).get(str(DRIVER)) == plan['files']['driver']['sha256'],
            'Core source pin map differs')
    require(not os.path.lexists(BASE / LABEL) and not os.path.lexists(READINESS),
            'This output or human-readiness label already exists; do not repeat it')


def main():
    require(sys.stdin.isatty(), 'Use an external interactive terminal; piped READY is not accepted as human confirmation')
    plan_bytes = read_regular(PLAN)
    plan = json.loads(plan_bytes)
    validate(plan)
    try:
        reply = input(PROMPT)
    except (EOFError, KeyboardInterrupt):
        print('\nCancelled; no diagnostic was started.')
        return 130
    if reply != 'READY':
        print('Cancelled; no diagnostic was started.')
        return 0
    require(read_regular(PLAN) == plan_bytes, 'Plan changed while waiting for confirmation')
    validate(plan)
    record = {'schema': 1, 'decision': 'ready', 'ready_for_run': LABEL,
              'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
              'AC_power': True, 'lid_open': True, 'other_work_paused': True,
              'Codex_closed': True, 'Codex_minimized': False,
              'human_prompt': PROMPT, 'human_reply': reply,
              'source': 'Direct human terminal confirmation after closing Codex',
              'plan_sha256': hashlib.sha256(plan_bytes).hexdigest()}
    descriptor = os.open(READINESS, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, 'w') as stream:
        json.dump(record, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print('Starting the one-request diagnostic. Wait for the shell prompt before reopening Codex.', flush=True)
    argv = command()
    os.execv(argv[0], argv)
    return 0  # Only reached by offline mocks; exec replaces this process.


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, ValueError) as error:
        print('Terminal diagnostic stopped: ' + str(error))
        raise SystemExit(1)
