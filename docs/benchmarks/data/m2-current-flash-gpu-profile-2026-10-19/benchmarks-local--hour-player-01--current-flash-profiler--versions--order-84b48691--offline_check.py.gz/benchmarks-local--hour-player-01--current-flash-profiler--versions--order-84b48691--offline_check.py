#!/usr/bin/env python3
"""Admission and uncertain-cleanup checks with process creation forbidden."""
from pathlib import Path
import importlib.util, contextlib, io, tempfile, json, sys, hashlib, types
from datetime import datetime, timezone, timedelta
from unittest.mock import patch, Mock
path = Path(__file__).with_name('profile_current_flash.py').resolve()
spec = importlib.util.spec_from_file_location('current_flash_probe', path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
checks = []
def check(name, action):
    action()
    checks.append({'name': name, 'passed': True})
def forbidden(*args, **kwargs):
    raise AssertionError('Unexpected process launch during offline check')
with tempfile.TemporaryDirectory(prefix='conflux-flash-profiler-offline-') as temporary:
    folder = Path(temporary)
    def dry():
        with patch.object(sys, 'argv', [str(path), 'offline-dry']), patch.object(m.subprocess, 'Popen', side_effect=forbidden), contextlib.redirect_stdout(io.StringIO()) as output:
            assert m.main() == 0
        plan = json.loads(output.getvalue())
        assert plan['host_queried'] is False and plan['native_started'] is False and len(plan['cases']) == 1
    check('dry plan creates no child and performs no host query', dry)
    original_load = m.load
    def load(name, source):
        value = original_load(name, source)
        if name == 'retained':
            value.head = lambda: '0' * 40
        return value
    def admission(label, configuration, human=None, error=''):
        base = folder / label
        base.mkdir()
        (base / 'expected-pins.json').write_text(json.dumps(configuration))
        readiness = base / 'human.json'
        if human is not None:
            readiness.write_text(json.dumps(human))
        arguments = [str(path), label, '--run', '--readiness-decision', str(readiness), '--source-pins', str(base / 'not-read.json')]
        with patch.object(m, 'BASE', base), patch.object(m, 'load', side_effect=load), patch.object(sys, 'argv', arguments), patch.object(m.subprocess, 'Popen', side_effect=forbidden), contextlib.redirect_stdout(io.StringIO()):
            assert m.main() == 1
        result = json.loads((base / label / 'result.json').read_text())
        assert result['native_started'] is False and result['AC_lid'] == []
        assert result['errors'] and error in result['errors'][0]['message'], result['errors']
        assert 'tools.stems.worker' not in sys.modules
    configuration = json.loads((path.parent / 'expected-pins.json').read_text())
    configuration.update(status='unarmed', repository_head=None)
    check('unarmed HEAD rejected before readiness, worker import or host query', lambda: admission('unarmed', configuration, error='not armed'))
    armed = {**configuration, 'status': 'ready', 'repository_head': '0' * 40}
    check('missing readiness rejected before worker import or host query', lambda: admission('missing', armed, error='fresh human-readiness'))
    human = {'schema': 1, 'decision': 'ready', 'ready_for_run': 'stale', 'AC_power': True, 'lid_open': True, 'Codex_minimized': True, 'other_work_paused': True, 'human_reply': 'Ready', 'recorded_at_utc': (datetime.now(timezone.utc) - timedelta(seconds=901)).isoformat()}
    check('expired readiness rejected before worker import or host query', lambda: admission('stale', armed, human, 'older than 15 minutes'))
    human.update(ready_for_run='not-minimized', recorded_at_utc=datetime.now(timezone.utc).isoformat(), Codex_minimized=False)
    check('minimized condition required before worker import or host query', lambda: admission('not-minimized', armed, human, 'minimized Codex'))
    for name, (helper, expected) in m.HELPERS.items():
        assert hashlib.sha256(helper.read_bytes()).hexdigest() == expected
        checks.append({'name': 'frozen helper ' + name, 'passed': True})
    def uncertain_cleanup():
        root = folder / 'unreaped-spool'
        root.mkdir()
        (root / 'input.f32').write_bytes(b'evidence')
        process = Mock(pid=12345, returncode=None)
        process.poll.return_value = None
        process.wait.side_effect = RuntimeError('unreaped')
        native = types.SimpleNamespace(process=process, root=root, close=Mock(side_effect=AssertionError('must not delete unreaped spool')))
        cleanup, _, errors = m.cleanup_native(native, True, folder)
        assert not cleanup['native_reaped'] and root.exists() and (root / 'input.f32').exists() and errors and not native.close.called
    check('unreaped child preserves spool and prevents normal close', uncertain_cleanup)
    def failed_request_files():
        root = folder / 'failed-request-spool'
        root.mkdir()
        for name in ('input.f32', 'output.f32'):
            (root / name).write_bytes(b'in-flight evidence')
        process = Mock()
        process.poll.return_value = None
        native = types.SimpleNamespace(root=root, process=process, infer=Mock(side_effect=TimeoutError('request failed while child remains live')))
        row = {'completed': False}
        try:
            native.infer(None, 1)
        except TimeoutError:
            pass
        finally:
            m.cleanup_request(native, row)
        assert native.process.poll() is None and all((root / name).exists() for name in ('input.f32', 'output.f32'))
        row['completed'] = True
        m.cleanup_request(native, row)
        assert not any((root / name).exists() for name in ('input.f32', 'output.f32'))
    check('failed live request retains files until proven outer cleanup; completed request can release them', failed_request_files)
    def expired_final_hash_budget():
        base = folder / 'expired-final-hash'
        base.mkdir()
        (base / 'expected-pins.json').write_text(json.dumps(armed))
        readiness = base / 'human.json'
        fresh = {**human, 'ready_for_run': 'expired-final-hash', 'Codex_minimized': True,
                 'recorded_at_utc': datetime.now(timezone.utc).isoformat()}
        readiness.write_text(json.dumps(fresh))
        clock = [1000.0]
        pin_deadlines = []
        def timed_load(name, source):
            module = load(name, source)
            if name == 'comparison':
                real_capture = module.capture_pins
                def capture(specifications, deadline, **options):
                    pin_deadlines.append(deadline)
                    if len(pin_deadlines) == 1:
                        clock[0] = 1301.0
                        raise RuntimeError('setup failure after fixed total deadline')
                    return real_capture(specifications, deadline, **options)
                module.capture_pins = capture
            return module
        arguments = [str(path), 'expired-final-hash', '--run', '--readiness-decision', str(readiness),
                     '--source-pins', str(path.parent / 'comparison-source-pins.json')]
        with patch.object(m, 'BASE', base), patch.object(m, 'load', side_effect=timed_load), \
                patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]), \
                patch.object(sys, 'argv', arguments), patch.object(m.subprocess, 'Popen', side_effect=forbidden), \
                contextlib.redirect_stdout(io.StringIO()):
            assert m.main() == 1
        result = json.loads((base / 'expired-final-hash' / 'result.json').read_text())
        assert pin_deadlines == [1300.0, 1300.0], pin_deadlines
        assert any(row.get('phase') == 'after_pins' and 'time budget exhausted' in row['message'] for row in result['errors']), result['errors']
        assert result['native_started'] is False and result['AC_lid'] == []
    check('expired final hash uses original total deadline and rejects without renewed sixty seconds', expired_final_hash_budget)
    def readiness_flow(ready_seconds, expect_native_boundary, mutation=None, fresh_temperature=53000, fresh_finished=None):
        import ast
        label = 'readiness-' + str(ready_seconds) + '-' + str(mutation) + '-' + str(fresh_temperature) + '-' + str(fresh_finished)
        base = folder / label
        base.mkdir()
        (base / 'expected-pins.json').write_text(json.dumps(armed))
        fresh = {**human, 'ready_for_run': label, 'Codex_minimized': True,
                 'recorded_at_utc': datetime.now(timezone.utc).isoformat()}
        readiness = base / 'human.json'
        readiness.write_text(json.dumps(fresh))
        clock, native_boundaries, launches, signals, git_queries, events, fresh_calls = [1000.0], [], [], [], [], [], []
        reference = json.loads(m.PROOF.read_text())
        selected = next(row for row in reference['runtimes'][0]['requests'] if row['id'] == 'club_xl:257985')
        fixture_files = []
        for index in range(37):
            item = base / ('fixture-' + str(index))
            item.write_bytes(b'fixture')
            fixture_files.append(item)
        fixture_specs = {str(index): (item, hashlib.sha256(item.read_bytes()).hexdigest(), 64) for index, item in enumerate(fixture_files)}
        normal = original_load('offline_readiness_function', m.OLD.parent / 'user-tracks-2026-10-17/normal_ready.py')
        recorded_fresh = json.loads((path.parent / 'current-flash-profile-03/admission/fresh-admission.json').read_text())
        def capture(zone, deadline):
            row = json.loads(json.dumps(recorded_fresh['live_normal_readiness']))
            row.update(package_millidegrees_C=fresh_temperature, started_monotonic=clock[0], finished_monotonic=clock[0])
            return row
        normal.capture = capture
        helper_source = m.OLD.parent / 'music-profile-2026-10-17/interleaved_replay.py'
        function = next(node for node in ast.parse(helper_source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'fresh_admission')
        def require(value, message):
            if not value:
                raise ValueError(message)
        namespace = {'json': json, 'Path': Path, 'time': m.time, 'require': require,
                     'pin': lambda item: {'path': str(item), 'sha256': hashlib.sha256(item.read_bytes()).hexdigest()},
                     'readiness_module': lambda: normal, 'ac_lid': lambda: {'ready': True, 'AC': '1', 'lid': 'b false'},
                     'replay': types.SimpleNamespace(atomic_json=lambda item, value: item.write_text(json.dumps(value)))}
        exec(compile(ast.Module(body=[function], type_ignores=[]), str(helper_source), 'exec'), namespace)
        def fresh_admission(output):
            fresh_calls.append(clock[0]); events.append('fresh')
            result = namespace['fresh_admission'](output)
            if fresh_finished is not None:
                clock[0] = 1000 + fresh_finished
            return result
        class NativeBoundary:
            def __new__(cls):
                native_boundaries.append(clock[0]); events.append('native')
                raise RuntimeError('Offline native boundary reached; process construction forbidden')
        class ReadinessChild:
            pid = 424242
            returncode = None
            def poll(self):
                if self.returncode is None and clock[0] >= 1000 + ready_seconds:
                    self.returncode = 0
                    proof = {'status': 'matched', 'profile_mutation': False, 'service_mutation': False,
                             'package_zone': '/mock/package-zone', 'guard_service_identity': recorded_fresh['same_guard_service_identity'],
                             'package_threshold_millidegrees_C': 55000}
                    (base / label / 'admission/admission-normal-ready.json').write_text(json.dumps(proof))
                    target = fixture_files[-1]
                    if mutation == 'in-place':
                        before = target.stat()
                        target.write_bytes(b'changed')
                        m.os.utime(target, ns=(before.st_atime_ns, before.st_mtime_ns))
                    elif mutation == 'symlink':
                        target.unlink(); target.symlink_to(fixture_files[0])
                    elif mutation == 'missing':
                        target.unlink()
                return self.returncode
            def wait(self, timeout=None):
                assert self.poll() is not None
                return self.returncode
        child = ReadinessChild()
        def popen(arguments, **options):
            assert arguments[1:3] == ['-B', '-c'] and 'normal_ready.py' in arguments[4]
            launches.append(arguments); events.append('readiness')
            return child
        def killpg(group, signum):
            assert group == child.pid
            signals.append(signum); child.returncode = -signum
        def git(arguments, **options):
            assert arguments == ['git', 'rev-parse', 'HEAD']
            assert 0 < options['timeout'] <= 1300 - clock[0]
            git_queries.append(options['timeout'])
            return '0' * 40 + '\n'
        def flow_load(name, source):
            if name == 'admission':
                return types.SimpleNamespace(readiness_module=lambda: normal,
                    ac_lid=lambda: {'ready': True, 'AC': '1', 'lid': 'b false'}, fresh_admission=fresh_admission)
            module = load(name, source)
            if name == 'comparison':
                real_capture = module.capture_pins
                def full_capture(specifications, deadline, **options):
                    events.append('hash')
                    return real_capture(fixture_specs, deadline, **options)
                def prepare(*arguments):
                    events.append('prepare')
                    return types.SimpleNamespace(__version__='offline'), NativeBoundary, [selected]
                module.capture_pins, module.prepare_cases = full_capture, prepare
            return module
        arguments = [str(path), label, '--run', '--readiness-decision', str(readiness),
                     '--source-pins', str(path.parent / 'comparison-source-pins.json')]
        with patch.object(m, 'BASE', base), patch.object(m, 'load', side_effect=flow_load), \
                patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]), \
                patch.object(m.time, 'sleep', side_effect=lambda seconds: clock.__setitem__(0, clock[0] + seconds)), \
                patch.object(m.subprocess, 'Popen', side_effect=popen), patch.object(m.subprocess, 'check_output', side_effect=git), \
                patch.object(m.subprocess, 'run', side_effect=forbidden), patch.object(m.os, 'killpg', side_effect=killpg), \
                patch.object(sys, 'argv', arguments), contextlib.redirect_stdout(io.StringIO()):
            assert m.main() == 1
        result = json.loads((base / label / 'result.json').read_text())
        assert len(launches) == 1 and result['native_started'] is False and result['requests'] == [], result['errors']
        assert events[:4] == ['hash', 'prepare', 'hash', 'readiness'], events
        assert events.count('hash') == 3, events
        assert result['cleanup']['readiness_reaped'] is True and result['cleanup']['watchdog_joined'] is True
        if expect_native_boundary:
            assert native_boundaries == [1000 + ready_seconds] and not signals
            assert result['native_construction_attempted'] is True and len(result['metadata_before_native']) == 37
            assert len(fresh_calls) == 1 and events[4:6] == ['fresh', 'native'], events
        elif ready_seconds > 195:
            assert not native_boundaries and signals == [m.signal.SIGINT] and not fresh_calls
            assert 'native_construction_attempted' not in result and result['elapsed_seconds'] == 195.0
        elif mutation is not None:
            assert not native_boundaries and not fresh_calls and 'native_construction_attempted' not in result
            assert 'metadata changed' in result['errors'][0]['message'] or result['errors'][0]['type'] == 'FileNotFoundError', result['errors']
        elif fresh_temperature > 70000:
            assert not native_boundaries and len(fresh_calls) == 1
            assert result['errors'][0]['message'] == 'Fresh <=70C/balanced/no-holds/same recovered guard/AC/lid admission failed'
        elif fresh_finished is not None:
            assert not native_boundaries and len(fresh_calls) == 1 and 'time budget exhausted' in result['errors'][0]['message']
        assert git_queries and 'tools.stems.worker' not in sys.modules
    check('actual flow hashes before stable wait then accepts37 unchanged identities before mocked native boundary', lambda: readiness_flow(190, True))
    check('actual flow rejects readiness past195s and reaps without native construction', lambda: readiness_flow(196, False))
    check('same-size in-place content edit with restoredmtime after wait aborts before fresh/native', lambda: readiness_flow(60, False, 'in-place'))
    check('symlink replacement after wait aborts before fresh/native', lambda: readiness_flow(60, False, 'symlink'))
    check('missing pinned file after wait aborts before fresh/native', lambda: readiness_flow(60, False, 'missing'))
    check('unchanged frozen fresh-admission78C failure is called once and prevents native', lambda: readiness_flow(60, False, fresh_temperature=78000))
    check('fresh helper finishing beyond195s prevents native without retry', lambda: readiness_flow(190, False, fresh_finished=196))
    def expired_metadata_deadline():
        comparison = original_load('offline_metadata_deadline', m.HELPERS['comparison'][0])
        item = folder / 'metadata-deadline-file'
        item.write_bytes(b'fixture')
        info = item.stat()
        pins = {'last': {'path': str(item), 'device': info.st_dev, 'inode': info.st_ino,
                         'bytes': info.st_size, 'mtime_ns': info.st_mtime_ns, 'ctime_ns': info.st_ctime_ns}}
        with patch.object(m.time, 'monotonic', return_value=1196), patch.object(m.os, 'stat', side_effect=forbidden):
            try:
                m.verify_pinned_metadata(comparison, pins, 1195)
            except TimeoutError:
                pass
            else:
                raise AssertionError('Expired metadata deadline admitted')
    check('metadata verification rejects expired pre-native deadline before any file probe', expired_metadata_deadline)
    def final_head_budget():
        queries = []
        def git(arguments, **options):
            queries.append((arguments, options['timeout']))
            return '0' * 40 + '\n'
        with patch.object(m.time, 'monotonic', return_value=1298), patch.object(m.subprocess, 'check_output', side_effect=git):
            assert m.bounded_head(1300) == '0' * 40
        assert queries == [(['git', 'rev-parse', 'HEAD'], 2)]
        with patch.object(m.time, 'monotonic', return_value=1301), patch.object(m.subprocess, 'check_output', side_effect=forbidden):
            try:
                m.bounded_head(1300)
            except RuntimeError as error:
                assert 'deadline exhausted' in str(error)
            else:
                raise AssertionError('Expired final HEAD budget accepted')
    check('final HEAD uses remaining original deadline and starts no query after expiration', final_head_budget)
    def unchanged_temperature_gate():
        readiness_path = m.OLD.parent / 'user-tracks-2026-10-17/normal_ready.py'
        readiness_module = original_load('offline_ready_gate', readiness_path)
        proof = json.loads((path.parent / 'current-flash-profile-02/admission/admission-normal-ready.json').read_text())
        row = json.loads(json.dumps(proof['rows'][-1]))
        assert readiness_module.ready(row, proof['guard_service_identity']) is True
        row['package_millidegrees_C'] = 83000
        assert readiness_module.ready(row, proof['guard_service_identity']) is False
    check('unchanged frozen readiness gate rejects83C despite balanced recovered state', unchanged_temperature_gate)
    proof = json.loads(m.PROOF.read_text())
    case = next(row for row in proof['runtimes'][0]['requests'] if row['id'] == 'club_xl:257985')
    assert proof['runtime_sha256'] == '6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53'
    assert case['output_sha256'] == 'e3dd10681d94efd2ebfbd3f98c34d74cbb25595559047c39156ba2388b73a856'
    assert case['input_sha256'] == '18182094f2b40017ba2b8445f8cbe4192ce2c45c04619edcaa3da3e4b82f3861'
    checks.append({'name': 'exact current own-Flash reference case retained', 'passed': True})
result = {'schema': 1, 'status': 'passed', 'scope': 'Offline admission/cleanup checks only; process creation forbidden, no worker import, GPU work, host query or audio output.', 'checks': checks, 'driver_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'earlier_check_correction': 'Initial temporary check expected the stale-readiness text without a space before minutes; corrected the check literal. Launcher emitted the intended rejection; no model/host process launched.'}
(path.parent / 'offline-checks-order-03.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'status': result['status']}))
