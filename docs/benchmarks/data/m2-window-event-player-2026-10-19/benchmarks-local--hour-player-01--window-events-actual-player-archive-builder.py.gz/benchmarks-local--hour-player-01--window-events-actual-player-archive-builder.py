from pathlib import Path
import json,gzip,hashlib,stat,subprocess,os
ROOT=Path(__file__).resolve().parents[2]; H=ROOT/'benchmarks-local/hour-player-01'
DEST=ROOT/'docs/benchmarks/data/m2-window-event-player-2026-10-19'
RAW=H/'window-events-player-archive-raw';STAGE=H/'window-events-player-archive-stage'
LIMIT=16*1024*1024;HEAD='daef9362c2ca6119b2c062659a0489fde3bf01a7'
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):
 assert p.is_relative_to(ROOT) and not p.is_symlink()
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size<=LIMIT
 b=p.read_bytes();t=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns)
 assert b'\0' not in b;b.decode('utf-8');return b
assert not any(os.path.lexists(p) for p in (DEST,RAW,STAGE))
paths={Path(__file__).resolve()}
for name in ('window-events-short-recipe.json','window-events-short-wait-launch.py','window-events-short-cool-start.json','window-events-short-preparation.json','window-events-short-launch-review.json','window-events-short-02-recipe.json','window-events-short-02-wait-launch.py','window-events-short-02-cool-start.json','window-events-short-02-preparation.json','window-events-short-02-independent-review.json','window-events-short-operation-audit.json','window-events-short-02-operation-audit.json','window-events-both-host-audit.json','window-events-host-audit.py','window-events-short-02-observation-cleanup-review.json','window-events-executed-runner.py','window-events-executed-source.json','window-events-independent-review.json','window-events-preparation.json'):
 paths.add(H/name)
for n in (1,2):
 label=f'short-live-window-events-{n:02}';paths.add(H/(label+'-readiness.json'))
 for name in ('result.json','native-result.json','progress.json','observations.jsonl','host-observations.jsonl','owned-pipewire-cleanup.json','native.stdout.log','native.stderr.log'):
  paths.add(H/label/name)
 for kind in ('graphics','oom'):
  for suffix in ('jsonl','stderr'):paths.add(H/f'window-events-short-{n:02}-kernel-{kind}.{suffix}')
frozen={str(p.relative_to(ROOT)):read(p) for p in sorted(paths)}
assert sum(len(b) for b in frozen.values())<=LIMIT
load=lambda name:json.loads(frozen[str((H/name).relative_to(ROOT))])
audits=[load('window-events-short-operation-audit.json'),load('window-events-short-02-operation-audit.json')]
source=load('window-events-executed-source.json');assert source['source_head']==HEAD and ' G F621F658D66098CBE9E5C55D66788CCBB5E215AC ' in source['signature_verified']
summaries=[]
for n,a in enumerate(audits,1):
 label=f'short-live-window-events-{n:02}';r=load(label+'/result.json');native=load(label+'/native-result.json')
 assert not r['passed'] and not r['qualified'] and not native['passed'] and not native['qualified']
 assert native['window_events']['frozen_before_cleanup'] is True
 assert a['observations']['service_hops']['count']==(13 if n==1 else 15)
 assert a['observations']['service_hops']['at_or_above_target']==11
 summaries.append({'name':label,'wrapper':{k:r.get(k) for k in ('started_at_utc','finished_at_utc','elapsed_seconds','error','stop_reason','cleanup_proven','owned_cache_removed','cache_preserved')},'native':{k:native.get(k) for k in ('measured_wall_ms','error','shutdown_completed','cancelled','frames_presented','steady_starved_frames','control_starved_frames','starved_frames_outside_measured_intervals')},'service_hops':a['observations']['service_hops'],'controls':a['controls'],'callback_and_UI':a['callback_and_UI'],'WAV':a['WAV'],'window_history':{k:a['window_event_history'][k] for k in ('capacity','attempted','retained','dropped','ordinal_range','frozen_before_cleanup','no_UI_guard_failure_snapshot')},'audit_path':str((H/('window-events-short-operation-audit.json' if n==1 else 'window-events-short-02-operation-audit.json')).relative_to(ROOT))})
summary={'schema':'conflux.m2-window-event-player.v1','source_head':HEAD,'source_signature':source['signature_verified'],'status':'both_actual_player_attempts_failed_unqualified','M2_open':True,'Best_quality_retained':True,'strict_target_ms':4095,'runs':summaries,'operator_intervention':{'run':'short-live-window-events-01','human_report':'I think it was cause I tried to move a knob','retry_instruction':'My bad feel free to run again','limit':'Monitored control movement plausibly explains the configuration abort; the exact failed value was not captured. Earlier latency and starvation remain retained.'},'run02_wrapper_limit':'ESRCH process observation error prevented final wrapper result ingestion; standalone native shutdown completed, but cleanup_proven remains false and cache is preserved. Later known-identity/group absence does not retroactively qualify cleanup.','limits':['Short nearest-rank p99 describes only retained validated hops, not sustained qualification.','Healthy callback counters and finite WAV files do not erase live-stem starvation.','No cancellation or actual-player hour qualification.','Exact-window visible kernel query absence is not proof of a GPU hang fix or global absence.','Temperatures are discrete CPU/ACPI observations, with no continuous exposure or causal attribution.'],'raw_source_input_count':len(frozen),'raw_source_input_bytes':sum(len(b) for b in frozen.values())}
summary_bytes=(json.dumps(summary,indent=2,allow_nan=False)+'\n').encode()
RAW.mkdir(mode=0o700);STAGE.mkdir(mode=0o700)
files={};uncompressed={};origins={}
def add(name,b,origin=None):
 packed=gzip.compress(b,mtime=0);assert packed[4:8]==b'\0'*4
 (RAW/name).write_bytes(b);(STAGE/(name+'.gz')).write_bytes(packed)
 files[name+'.gz']=pin(packed);uncompressed[name+'.gz']=pin(b);origins[name+'.gz']={'path':origin,'generated':origin is None,**pin(b)}
for p,b in frozen.items():add(p.replace('/','--'),b,p)
add('summary.json',summary_bytes)
scan_report=H/'window-events-player-archive-gitleaks-findings.json';scan_log=H/'window-events-player-archive-gitleaks.log'
assert not scan_report.exists() and not scan_log.exists()
with scan_log.open('xb') as stream:
 scan=subprocess.run(['gitleaks','dir',str(RAW),'--redact','--no-color','--report-format','json','--report-path',str(scan_report)],stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
assert scan.returncode==0 and json.loads(scan_report.read_text())==[]
scanned_files=len(files);scanned_bytes=sum(v['bytes'] for v in uncompressed.values());assert scanned_bytes<=LIMIT
for p in (scan_report,scan_log):add(str(p.relative_to(ROOT)).replace('/','--'),read(p),str(p.relative_to(ROOT)))
for name,v in files.items():
 p=STAGE/name;b=gzip.decompress(p.read_bytes());assert pin(p.read_bytes())==v and pin(b)==uncompressed[name] and gzip.compress(b,mtime=0)==p.read_bytes()
 origin=origins[name]['path']
 if origin:assert b==read(ROOT/origin)
assert all(read(ROOT/name)==b for name,b in frozen.items())
verification={'schema':'conflux.m2-window-event-player-archive.v1','summary':summary,'files':files,'uncompressed':uncompressed,'origins':origins,'source_inputs':{p:pin(b) for p,b in frozen.items()},'raw_secret_scan_exit':0,'raw_secret_scan_findings':0,'raw_scanned_files':scanned_files,'raw_scanned_bytes':scanned_bytes,'maximum_raw_bytes':LIMIT,'scope':'Frozen UTF-8 launch/readiness/host/raw observation/results/source and independent audit evidence. Deterministic gzip zero mtime, compressed/raw/origin hashes. No audio, PCM, binary, model, cache or mutable CURRENT file. Raw secret scan precedes packaging scanner outputs; verification and scanner outputs were not included in that scan.'}
(STAGE/'verification.json').write_text(json.dumps(verification,indent=2,allow_nan=False)+'\n');STAGE.rename(DEST)
print(json.dumps({'destination':str(DEST),'verification':pin((DEST/'verification.json').read_bytes()),'files':len(files)+1,'raw_scanned_files':scanned_files,'raw_scanned_bytes':scanned_bytes,'compressed_bytes':sum(x['bytes'] for x in files.values()),'physical_runs_qualified':False},indent=2))
