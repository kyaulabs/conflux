from pathlib import Path
import json,subprocess,datetime,hashlib,os,errno
h=Path(__file__).resolve().parent
stamp=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
summary={'schema':1,'created_utc':stamp(),'host_namespace':{'pid1_comm':Path('/proc/1/comm').read_text().strip(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'self_pid_namespace':os.readlink('/proc/self/ns/pid')},'runs':{}}
for n in (1,2):
 label=f'short-live-window-events-{n:02}';d=h/label;r=json.loads((d/'result.json').read_text());out={'result':pin(d/'result.json'),'exact_UTC_bounds':[r['started_at_utc'],r['finished_at_utc']],'owned_processes':[],'owned_groups':{},'kernel':{}}
 for v in r['cleanup']['known_processes']:
  p=Path('/proc')/str(v['pid'])
  try:
   fields=(p/'stat').read_text().rsplit(')',1)[1].split();same=int(fields[19])==v['start_ticks'] and int(fields[2])==v['group'] and int(fields[3])==v['session']
   current={'start_ticks':int(fields[19]),'group':int(fields[2]),'session':int(fields[3]),'state':fields[0]};absent=not same
  except (FileNotFoundError,ProcessLookupError):current=None;absent=True
  out['owned_processes'].append({'expected':{k:v[k] for k in ('pid','start_ticks','group','session')},'current':current,'original_identity_absent':absent,'observed_utc':stamp()})
 for g in r['cleanup']['owned_group_absent']:
  try:os.killpg(int(g),0);state='present'
  except ProcessLookupError:state='absent'
  except PermissionError:state='permission_denied'
  out['owned_groups'][g]=state
 for kind,pattern in [('graphics','(?i)(i915|drm|gpu|fence|hang|reset|preempt)'),('oom','(?i)(oom|out[ -]of[ -]memory|killed process)')]:
  cmd=['journalctl','--no-pager','--utc','-k','--since',r['started_at_utc'],'--until',r['finished_at_utc'],'--grep',pattern,'--output=json','--output-fields=__REALTIME_TIMESTAMP,__MONOTONIC_TIMESTAMP,MESSAGE,SYSLOG_IDENTIFIER,_TRANSPORT,_BOOT_ID','--lines=1001']
  q=subprocess.run(cmd,capture_output=True,timeout=10);raw=h/f'window-events-short-{n:02}-kernel-{kind}.jsonl';err=h/f'window-events-short-{n:02}-kernel-{kind}.stderr';raw.write_bytes(q.stdout[:1048576]);err.write_bytes(q.stderr[:65536]);rows=q.stdout.splitlines()
  out['kernel'][kind]={'command':cmd,'exit_code':q.returncode,'stdout':pin(raw),'stderr':pin(err),'truncated':len(q.stdout)>1048576 or len(q.stderr)>65536,'rows':len(rows),'record_limit_reached':len(rows)>=1001,'conclusion':'No matching visible entries within exact window' if q.returncode==1 and not q.stdout and not q.stderr else 'Inspect retained output'}
 out['wrapper_cleanup_claims']={k:r.get(k) for k in ('cleanup_proven','owned_cache_removed','cache_preserved')};out['owned_pipewire_cleanup']=pin(d/'owned-pipewire-cleanup.json');out['remaining_objects_saved']=json.loads((d/'owned-pipewire-cleanup.json').read_text())['remaining_objects'];out['cache_exists_now']=(d/'cache').exists();out['remaining_live_jobs_now']=[str(p.relative_to(d)) for p in (d/'cache').rglob('.live-*')] if (d/'cache').exists() else []
 summary['runs'][label]=out
q=subprocess.run(['systemctl','--user','show','thermal-guard.service','--property=ActiveState,MainPID,InvocationID'],capture_output=True,text=True,timeout=5);summary['guard_now']={'exit_code':q.returncode,'fields':dict(v.split('=',1) for v in q.stdout.splitlines() if '=' in v),'stderr':q.stderr[:4096]}
summary['limits']='Read-only present identities and bounded exact-window visible kernel query. No raw result modified; run02 cleanup_proven remains false and cache is retained. Known-identity absence does not prove absence of an unobserved escaped process; no global no-hang or causal claim.'
p=h/'window-events-both-host-audit.json';p.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'receipt':pin(p),'host_namespace':summary['host_namespace'],'runs':{k:{'all_owned_identities_absent':all(v['original_identity_absent'] for v in r['owned_processes']),'owned_groups':r['owned_groups'],'kernel':{x:{'rows':v['rows'],'exit_code':v['exit_code'],'truncated':v['truncated']} for x,v in r['kernel'].items()},'cache_exists_now':r['cache_exists_now'],'remaining_live_jobs_now':r['remaining_live_jobs_now']} for k,r in summary['runs'].items()},'guard_now':summary['guard_now']},indent=2))
