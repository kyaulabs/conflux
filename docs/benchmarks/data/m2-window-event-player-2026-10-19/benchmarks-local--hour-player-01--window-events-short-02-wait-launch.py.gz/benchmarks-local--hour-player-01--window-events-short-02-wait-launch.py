from pathlib import Path
import datetime,json,os,subprocess,time
base=Path(__file__).resolve().parent
recipe=json.loads((base/'window-events-short-02-recipe.json').read_text())
assert recipe['status']=='ready_pending_fresh_human_window_confirmation'
deadline=time.monotonic()+180
source_root=Path(recipe['source_root'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source_root,text=True,timeout=5).strip()==recipe['source_head']
import hashlib,stat
frozen={}
for name,pin in {**recipe['source_pins'],**recipe['normal_artifacts']}.items():
    path=source_root/name; before=path.stat(follow_symlinks=False)
    assert stat.S_ISREG(before.st_mode) and before.st_size==pin['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==pin['sha256'],name
    frozen[path]=(before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)
rows=[]
while True:
    values=[]
    for zone in Path('/sys/class/thermal').glob('thermal_zone*'):
        try:
            if (zone/'type').read_text().strip() in ('acpitz','TCPU','x86_pkg_temp'): values.append(int((zone/'temp').read_text()))
        except (OSError,ValueError): pass
    for hw in Path('/sys/class/hwmon').glob('hwmon*'):
        try:
            if (hw/'name').read_text().strip()=='coretemp': values.extend(int(p.read_text()) for p in hw.glob('temp*_input'))
        except (OSError,ValueError): pass
    profile=subprocess.check_output(['powerprofilesctl','get'],text=True,timeout=3).strip()
    row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'profile':profile,'maximum_millidegrees_C':max(values) if values else None};rows.append(row)
    ready=profile=='balanced' and values and 0<max(values)<=70000
    if ready or time.monotonic()>=deadline:
        (base/'window-events-short-02-cool-start.json').write_text(json.dumps({'ready':bool(ready),'observations':rows,'scope':'Read-only bounded wait for natural balanced/cool recovery; guard and profile unchanged.'},indent=2)+'\n')
        if not ready: raise SystemExit('Natural cool/balanced start not reached within180s; no player launched')
        for path,expected in frozen.items():
            current=path.stat(follow_symlinks=False)
            assert stat.S_ISREG(current.st_mode) and (current.st_dev,current.st_ino,current.st_size,current.st_mtime_ns,current.st_ctime_ns)==expected
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source_root,text=True,timeout=5).strip()==recipe['source_head']
        assert time.monotonic()<deadline,'Pre-launch deadline exhausted'
        argv=recipe['root_only_argv_after_all_pending_items_are_satisfied']
        print('Natural cool/balanced start reached; launching confirmed120s diagnostic',flush=True)
        os.execv(argv[0],argv)
    time.sleep(2)
