#!/usr/bin/env python3
"""Dry default; fixed hidden baseline player profiling after new PCM16 proof."""
import argparse
import hashlib
import importlib.util
import json
import os
import re
import stat
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
COMMON = BASE/'profile_launch.py'
COMMON_SHA = '9cd3f04f572e85602505f6f3db6c9d01576ea758e9cb9ae563bc7e534a378380'


def require(ok,message):
    if not ok:
        raise ValueError(message)


def load_common():
    require(re.fullmatch(r"[0-9a-f]{64}",COMMON_SHA),"Launch common is not frozen; wrapper unarmed")
    fd = os.open(COMMON,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        first = os.fstat(fd)
        require(stat.S_ISREG(first.st_mode) and first.st_uid == os.getuid() and first.st_nlink == 1
                and 0 < first.st_size <= 256*1024,"Unsafe launch common source")
        raw = bytearray()
        while len(raw) < first.st_size:
            block = os.read(fd,min(65536,first.st_size-len(raw)))
            require(block,"Launch common truncated");raw.extend(block)
        signature = lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        require(signature(first) == signature(os.fstat(fd)) == signature(COMMON.lstat())
                and hashlib.sha256(raw).hexdigest() == COMMON_SHA,"Launch common pin changed")
    finally:
        os.close(fd)
    spec = importlib.util.spec_from_file_location("fixed_player_profile_launch",COMMON)
    common = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = common
    exec(compile(bytes(raw),str(COMMON),"exec"),common.__dict__)
    return common

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true')
    parser.add_argument('--allow-host-audio',action='store_true')
    parser.add_argument('--drm-busy-diagnostic',action='store_true')
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({'status':'unarmed_dry_plan','host_queried':False,'native_started':False,
            'seconds':120,'original_combined_seconds':960,'requires_new_exact_PCM16':True}))
        return 0
    if not (args.allow_host_audio and args.drm_busy_diagnostic):
        raise ValueError('Explicit host-audio and DRM diagnostic flags are required')
    common = load_common()
    plan,pin = common.load_plan()
    common.readiness(common.HUMAN,pin)
    player = common.load_player(plan)
    sys.argv = [str(Path(__file__).resolve()),'--allow-host-audio','--drm-busy-diagnostic',
        '--plan',str(common.PLAN),'--readiness-decision',str(common.HUMAN)]
    return player.main()


if __name__=='__main__':
    raise SystemExit(main())
