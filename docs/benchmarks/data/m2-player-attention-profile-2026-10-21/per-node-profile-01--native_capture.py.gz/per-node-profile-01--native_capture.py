"""Private full-capture specialization of the pinned product NativeRuntime."""
from contextlib import ExitStack, suppress
import json
import os
from pathlib import Path
import selectors
import subprocess
import time
from tools.stems.worker import NativeRuntime

PARENT_SOURCE_SHA256 = "b38ab1dae456f9da69cbb30563595559f10e018246e86763dffffa89b9bacdff"
STDERR_LIMIT, STDOUT_LIMIT = 8 * 1024**2, 128 * 1024


class CapturedNativeRuntime(NativeRuntime):
    def __init__(self, runtime, model, backend, threads, timeout, *, passive_openmp=True,
                 spool_directory=None, max_stderr_bytes=STDERR_LIMIT):
        if spool_directory is None or max_stderr_bytes != STDERR_LIMIT or backend != "vulkan" or threads != 2:
            raise ValueError("Fixed private Vulkan2 capture/spool required")
        self._fixed_spool, self._process_reaped, self._closed, self._close_failed = True, False, False, False
        self.max_stderr_bytes, self._stderr_tail, self.timeout = 65536, bytearray(), timeout
        self.capture = {"stderr_received": 0, "stderr_written": 0, "stdout_received": 0, "stdout_written": 0,
                        "stderr_eof": False, "stdout_eof": False, "overflow": False,
                        "read_errors": 0, "write_errors": 0, "first_error": ""}
        self._cleanup = ExitStack()
        try:
            self.root = Path(spool_directory)
            self.root.mkdir(mode=0o700)
            self._cleanup.callback(self._remove_spool)
            self.stderr = self._cleanup.enter_context((self.root / "runtime.stderr").open("xb"))
            self.stdout_capture = self._cleanup.enter_context((self.root / "runtime.stdout").open("xb"))
            environment = os.environ.copy()
            if passive_openmp:
                environment.update(OMP_WAIT_POLICY="PASSIVE", GOMP_SPINCOUNT="0")
            self.process_environment = {k: environment[k] for k in ("OMP_WAIT_POLICY", "GOMP_SPINCOUNT") if k in environment}
            self.process = subprocess.Popen([str(runtime), "--model", str(model), "--backend", backend,
                    "--threads", str(threads)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, bufsize=0, env=environment, start_new_session=True)
            for resource in (self.process.stderr, self.process.stdout, self.process.stdin):
                self._cleanup.callback(resource.close)
            self._cleanup.callback(self._close_process)
            self.selector = selectors.DefaultSelector()
            self._cleanup.callback(self.selector.close)
            self.selector.register(self.process.stdout, selectors.EVENT_READ)
            self.selector.register(self.process.stderr, selectors.EVENT_READ)
            self.buffer = bytearray()
        except BaseException:
            with suppress(Exception):
                self._cleanup.close()
            raise

    def _remove_spool(self):
        if hasattr(self, "process") and not self._process_reaped:
            return
        (self.root / "runtime.stdout").unlink(missing_ok=True)
        super()._remove_spool()

    def _capture_error(self, kind, error):
        self.capture[kind + "_errors"] += 1
        if not self.capture["first_error"]:
            self.capture["first_error"] = str(error)[:1024]

    def _flush_diagnostics(self):
        for sink in (getattr(self, "stderr", None), getattr(self, "stdout_capture", None)):
            if sink is not None and not sink.closed:
                try:
                    sink.flush()
                except OSError as error:
                    self._capture_error("write", error)

    def _capture_read(self, key):
        stderr = key.fileobj is self.process.stderr
        stream = "stderr" if stderr else "stdout"
        try:
            data = os.read(key.fileobj.fileno(), 4096)
        except OSError as error:
            self._capture_error("read", error)
            self.selector.unregister(key.fileobj)
            return b""
        if not data:
            self.capture[stream + "_eof"] = True
            self.selector.unregister(key.fileobj)
            return b""
        self.capture[stream + "_received"] += len(data)
        if stderr:
            self._stderr_tail.extend(data)
            del self._stderr_tail[:-65536]
        maximum, sink = (STDERR_LIMIT, self.stderr) if stderr else (STDOUT_LIMIT, self.stdout_capture)
        remaining = maximum - self.capture[stream + "_written"]
        if len(data) > remaining:
            self.capture["overflow"] = True
        # Continue draining/discarding after overflow or write failure; never block the native pipe.
        if self.capture["write_errors"] == 0 and remaining:
            try:
                payload = memoryview(data)[:remaining]
                while payload:
                    written = sink.write(payload)
                    if not written:
                        raise OSError("Short private capture write")
                    self.capture[stream + "_written"] += written
                    payload = payload[written:]
            except OSError as error:
                self._capture_error("write", error)
        return b"" if stderr else data

    def _receive_bounded(self):
        deadline = time.monotonic() + self.timeout
        while b"\n" not in self.buffer:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self.abort(); self._flush_diagnostics()
                raise TimeoutError("native stem request timed out; child terminated")
            for key, _ in self.selector.select(remaining):
                if time.monotonic() >= deadline:
                    break
                data = self._capture_read(key)
                if key.fileobj is self.process.stdout:
                    if not data:
                        raise RuntimeError("native closed protocol: " + self._stderr_tail[-4096:].decode(errors="replace"))
                    self.buffer.extend(data)
                    if len(self.buffer) > 65536:
                        raise RuntimeError("native stem protocol line exceeds limit")
        self._flush_diagnostics()
        line, _, remainder = self.buffer.partition(b"\n")
        self.buffer = bytearray(remainder)
        event = json.loads(line)
        if not isinstance(event, dict):
            raise RuntimeError("native stem protocol requires an object")
        return event

    def finish_capture(self, deadline):
        # Called after the exact owned child is reaped; no renewed relative deadline.
        if self.process.poll() is None:
            raise RuntimeError("Capture completion requires the owned native child to be reaped")
        while self.selector.get_map() and time.monotonic() < deadline:
            for key, _ in self.selector.select(min(0.05, max(0, deadline - time.monotonic()))):
                self._capture_read(key)
        self._flush_diagnostics()
        return self.capture_status()

    def capture_status(self):
        c = self.capture
        c["complete"] = (c["stderr_eof"] and c["stdout_eof"] and not c["overflow"]
                         and c["read_errors"] == c["write_errors"] == 0
                         and c["stderr_received"] == c["stderr_written"]
                         and c["stdout_received"] == c["stdout_written"])
        return dict(c)

    def idle_quit(self, *, completed_idle, deadline):
        """Existing quit, but drain both captured pipes while the owned child exits."""
        result = {"requested_quit": False, "quit_write_complete": False, "killed": False}
        primary = None
        try:
            if self.process.poll() is None and completed_idle and time.monotonic() < deadline:
                result["requested_quit"] = True
                fd = self.process.stdin.fileno()
                blocking = os.get_blocking(fd)
                try:
                    os.set_blocking(fd, False)
                    wire = b'{"command":"quit"}\n'
                    result["quit_write_complete"] = os.write(fd, wire) == len(wire)
                finally:
                    os.set_blocking(fd, blocking)
                while (result["quit_write_complete"] and self.process.poll() is None
                       and time.monotonic() < deadline - .25):
                    for key, _ in self.selector.select(min(.05, max(0, deadline - .25 - time.monotonic()))):
                        self._capture_read(key)
        except BaseException as error:
            primary = error
            result["quit_error"] = type(error).__name__ + ": " + str(error)[:256]
        finally:
            if self.process.poll() is None:
                result["killed"] = True
                try:
                    self.process.kill()
                except ProcessLookupError:
                    pass
            try:
                # Draining remains bounded by the same close deadline, including kill/reap.
                while self.process.poll() is None and time.monotonic() < deadline:
                    for key, _ in self.selector.select(min(.01, max(0, deadline - time.monotonic()))):
                        self._capture_read(key)
                self.process.wait(timeout=max(0, deadline - time.monotonic()))
            except BaseException as error:
                if primary is None: primary = error
                result["reap_error"] = type(error).__name__ + ": " + str(error)[:256]
            result.update(exit_code=self.process.poll(), process_reaped=self.process.poll() is not None,
                          within_same_shutdown_budget=time.monotonic() <= deadline)
        result["graceful_complete"] = bool(result["requested_quit"] and result["quit_write_complete"]
            and not result["killed"] and result["exit_code"] == 0 and result["process_reaped"]
            and result["within_same_shutdown_budget"] and primary is None)
        return result
