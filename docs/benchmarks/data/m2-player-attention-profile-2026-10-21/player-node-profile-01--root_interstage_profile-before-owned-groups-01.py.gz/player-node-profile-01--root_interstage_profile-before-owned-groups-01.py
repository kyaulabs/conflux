#!/usr/bin/env python3
"""Fixed read-only PCM16 interstage audit; no player dispatch; dry by default."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import signal
import stat
import sys
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
WRAPPER = BASE / "run_profile_player.py"
WRAPPER_SHA = "63990a1cc8884a73384366f111bdfb49c05a085edb90a3854d6ace858b555969"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def load_wrapper():
    fd = os.open(WRAPPER, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid() and before.st_nlink == 1
                and 0 < before.st_size <= 262144, "Unsafe fixed player wrapper")
        raw = bytearray()
        while len(raw) < before.st_size:
            block = os.read(fd, min(65536, before.st_size - len(raw)))
            require(block, "Truncated player wrapper"); raw.extend(block)
        sig = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        require(sig(before) == sig(os.fstat(fd)) == sig(WRAPPER.lstat())
                and hashlib.sha256(raw).hexdigest() == WRAPPER_SHA, "Fixed player wrapper changed")
    finally:
        os.close(fd)
    spec = importlib.util.spec_from_file_location("interstage_profile_wrapper", WRAPPER)
    module = importlib.util.module_from_spec(spec)
    exec(compile(bytes(raw), str(WRAPPER), "exec"), module.__dict__)
    return module


def pid_absent(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    return False


def guard_metadata(guard):
    fields = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
    result = {}
    for key in ("script", "unit"):
        info = Path(guard[key]["path"]).lstat()
        result[key] = {name: getattr(info, name) for name in fields}
    return result


def same_guard(current, prior):
    return (type(prior) is dict and set(current) == set(prior) == {"service", "process", "script", "unit"}
            and current["service"] == prior["service"] and current["process"] == prior["process"]
            and all(all(current[key].get(k) == prior[key].get(k) for k in ("path", "bytes", "sha256")) for key in ("script", "unit")))


def audit(common, player, plan, plan_pin, human):
    began = time.monotonic()
    target = common.INTERSTAGE_AUDIT
    require(target == BASE / "interstage-root-audit-01.json", "Fixed interstage output required")
    require(not target.exists() and not target.is_symlink(), "Preserve prior interstage evidence")
    receipt = {"schema": 1, "status": "failed", "strict_pcm_gate_passed": False, "qualified": False,
               "physical_workload_started": False, "plan_sha256": plan_pin["sha256"], "human_sha256": human["pin"]["sha256"]}
    fd = None
    def write():
        nonlocal fd
        raw = (json.dumps(receipt, indent=2, allow_nan=False) + "\n").encode()
        require(len(raw) <= 128 * 1024, "Interstage receipt exceeds bound")
        if fd is None:
            fd = os.open(target, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
        require(os.fstat(fd).st_ino == target.lstat().st_ino and os.fstat(fd).st_dev == target.lstat().st_dev,
                "Owned audit output changed")
        os.lseek(fd, 0, os.SEEK_SET); os.ftruncate(fd, 0)
        with os.fdopen(os.dup(fd), "wb") as stream:
            stream.write(raw); stream.flush()
    try:
        common.read_file(Path(__file__).resolve(), 65536, plan["source_pins"]["root_interstage"])
        result, result_pin = common.read_json(common.PCM_OUTPUT / "result.json", 8 * 1024**2)
        prior, ended = result.get("operator_budget", {}), result.get("finished_monotonic")
        anchor = prior.get("approval_sample_monotonic"); age = prior.get("age_seconds"); original = prior.get("operator_deadline_monotonic")
        now = time.monotonic(); boot = player.boot_identity()
        require(all(type(x) in (int, float) and math.isfinite(x) for x in (anchor, age, original, ended))
                and 0 <= age <= 120 and 0 <= anchor <= result.get("started_monotonic", -1) <= ended <= now
                and original == anchor + 960 - age and prior.get("phase") == "pcm" and result.get("boot_id") == boot,
                "Original PCM clock/boot differs")
        budget = player.operator_budget(human, now, began, phase="player")
        original = min(original, budget["operator_deadline_monotonic"])
        deadline = min(began + 45, original, ended + 60)
        require(now < deadline and original - now >= 480, "Original interstage/operator budget expired")
        finished = datetime.fromisoformat(result.get("finished_at_utc", ""))
        require(finished.tzinfo is not None and 0 <= (datetime.now(timezone.utc) - finished).total_seconds() <= 60,
                "Original PCM UTC interstage window expired")
        require(result.get("status") == "passed" and result.get("plan_pin") == plan_pin and result.get("human_pin") == human["pin"]
                and result.get("source_head") == plan["source_head"] and result.get("candidate_runtime") == plan["assets"]["runtime"]
                and result.get("cleanup_complete") is True and result.get("pins_unchanged") is True
                and result.get("pins_before") == result.get("pins_after") and bool(result.get("pins_before"))
                and result.get("errors") == [] and result.get("within_wall_budget") is True
                and len(result.get("requests", [])) == 16 and [r.get("case_id") for r in result["requests"]] == list(player.PCM_CASE_IDS)
                and [r.get("request_id") for r in result["requests"]] == list(range(1, 17))
                and all(r.get("completed") is True and r.get("exact_pcm_match") is True for r in result["requests"])
                and all(result.get(k, {}).get("complete" if k == "capture" else "passed") is True
                        for k in ("capture", "attention_series", "stdout_protocol", "native_trace")), "Incomplete PCM16 profile/cleanup")
        player.verify_plan_files(plan, deadline)
        require(player.read_command(["git", "-C", str(player.SOURCE_ROOT), "rev-parse", "HEAD"]) == plan["source_head"], "Current source HEAD differs")
        identities = [result[k] for k in ("native_identity", "readiness_identity")]
        require(all(type(v.get("pid")) is int and v["pid"] > 1 for v in identities), "Known PID identity missing")
        native = identities[0]
        require(native["pid"] == native.get("group") == native.get("session"), "Owned native group differs")
        absent = {str(v["pid"]): pid_absent(v["pid"]) for v in identities}
        raw = player.read_command(["ps", "-e", "-o", "pid=,pgid="])
        require(len(raw.encode()) <= 1048576, "Process-group observation exceeds bound")
        group_absent = native["group"] not in {int(line.split()[1]) for line in raw.splitlines() if line.strip()}
        require(all(absent.values()) and group_absent, "Known PCM owner/group remains")
        raw = player.read_command(["pw-dump"], timeout=5)
        require(len(raw.encode()) <= 8 * 1024**2, "PipeWire observation exceeds bound")
        objects = json.loads(raw); require(type(objects) is list, "Malformed PipeWire objects")
        owned = {str(v["pid"]): len(player.owned_objects(objects, v["pid"])) for v in identities}
        require(not any(owned.values()), "Known owned PipeWire objects remain")
        guard = player.guard_identity(Path(plan["assets"]["guard_script"]["path"]), Path(plan["assets"]["guard_unit"]["path"]))
        rich = guard_metadata(guard)
        require(result["guard_before"] == result["guard_after"] and same_guard(guard, result["guard_before"]), "PCM/current guard differs")
        power = player.power_state(); require(power.get("ac_online") is True and power.get("lid_open") is True, "Current AC/lid differs")
        helper, _ = player.load_cache_support()
        seed, _ = common.read_json(Path(plan["seed_proof"]["path"]), 2 * 1024**2, plan["seed_proof"])
        expected = seed["shader_cache"]["post"]
        actual = helper.inventory(helper.SEED_CACHE, expected["parent"], deadline, expected["cache_identity"])
        stable = lambda v: {k: x for k, x in v.items() if k not in ("capture_started_monotonic", "capture_finished_monotonic")}
        require(stable(actual) == stable(expected) and actual["manifest_sha256"] == plan["seed_manifest_sha256"], "Immutable seed differs")
        require(player.guard_identity(Path(guard["script"]["path"]), Path(guard["unit"]["path"])) == guard
                and guard_metadata(guard) == rich and time.monotonic() < deadline and original - time.monotonic() >= 480,
                "Guard/original budget changed during audit")
        receipt.update(status="passed", created_at_utc=datetime.now(timezone.utc).isoformat(), pcm_result_sha256=result_pin["sha256"],
            source_head=plan["source_head"], candidate_runtime_sha256=plan["assets"]["runtime"]["sha256"], boot_id=boot,
            original_operator_deadline_monotonic=original, audit_deadline_monotonic=deadline,
            guard_unchanged=True, owned_processes_absent=True, owned_groups_absent=True, no_owned_pipewire=True, immutable_seed_unchanged=True,
            known_pids_absent=absent, native_group_absent=group_absent, known_owned_pipewire_counts=owned, guard_identity=guard,
            guard_file_metadata=rich, power=power, seed_manifest_sha256=actual["manifest_sha256"])
        write()
        player.validate_pcm_gate(plan, plan_pin, human)  # actual existing full16/reference/source + profile gate
        require(time.monotonic() < deadline and original - time.monotonic() >= 480, "Strict gate exhausted original interstage budget")
        receipt.update(strict_pcm_gate_passed=True, elapsed_seconds=time.monotonic() - began); write()
        return receipt
    except BaseException as error:
        receipt.update(status="failed", strict_pcm_gate_passed=False, error=str(error)[:8192], elapsed_seconds=time.monotonic() - began)
        write(); raise
    finally:
        if fd is not None:
            os.close(fd)


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({"status": "unarmed_dry_audit", "host_queried": False, "player_dispatched": False})); return 0
    wrapper = load_wrapper(); common = wrapper.load_common()
    plan, pin = common.load_plan(); human = common.readiness(common.HUMAN, pin)
    player = common.load_player(plan)
    old = signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt("Interstage audit terminated")))
    try:
        print(json.dumps(audit(common, player, plan, pin, human))); return 0
    finally:
        signal.signal(signal.SIGTERM, old)


if __name__ == "__main__":
    raise SystemExit(main())
