"""Prepared CPU-only actual capture -> strict player consumer interface check.

One generated service/native lifetime is shared by two checks. Tensor timings and
DRM rows are explicit synthetic fixtures, not GPU measurements or validation.
The capture summary, raw streams and TraceSink context are the actual producer's
unmodified bytes. No physical readiness or model/audio backend is involved.
"""
import copy
import hashlib
import json
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PINS = {
    "capture_factory_checks_01.py": "8025728ea00aba18d8bfd3998fb935f89c88ca74f553be48adf911a04c350874",
    "attention_series_checks.py": "6dee5e1834293a7dccef53a80e80654b43d9b14fec9c1e7610354c2cac3b0b70",
    "attention_series.py": "4062106fdbc95a35c4ee56750b213fbd000e2e4d7fbcfe16d9398db7c620d311",
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(name):
    path = HERE / name
    raw = path.read_bytes()
    if not 0 < len(raw) <= 65536 or sha(raw) != PINS[name]:
        raise RuntimeError("Frozen integration fixture source differs: " + name)
    scope = {"__name__": "capture_series_integration_import", "__file__": str(path)}
    exec(compile(raw, str(path), "exec"), scope)
    return scope


class CaptureSeriesIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        factory = load("capture_factory_checks_01.py")
        declared = load("attention_series_checks.py")
        cls.consumer = load("attention_series.py")["consume_player_series"]
        declarations = declared["SeriesChecks"]
        declarations.setUpClass()
        semantic = declarations.semantic
        # The same independent fixed ten-signature/forty-target baseline rows
        # used in the reviewed consumer fixtures, with synthetic nanoseconds.
        metadata = semantic["wire"](semantic["full_graph"](False, 1))
        result_line = " print(json.dumps({'event':'result'"
        original_child = factory["FAKE_NATIVE"]
        if original_child.count(result_line) != 1:
            raise RuntimeError("Frozen CPU-child result seam differs")
        factory["FAKE_NATIVE"] = original_child.replace(result_line,
            " sys.stderr.buffer.write(" + repr(metadata) + ");sys.stderr.flush()\n" + result_line, 1)
        case = unittest.TestCase()
        try:
            h = factory["RunningService"](case, "normal")
            # The helper checks actual wrapper/factory, inherited service group,
            # exact 211 source frames, slot ACK and the original job allowlist.
            ready = h.completed()
            h.close_request()
            h.event("closed")
            case.assertEqual(h.child.wait(timeout=5), 0)
            capture = h.summary()
            case.assertTrue(capture["complete"])
            case.assertEqual(capture["native"]["pid"], ready["pid"])
            case.assertEqual(capture["native_shutdown"]["exit_code"], 0)
            case.assertTrue(capture["native_shutdown"]["process_reaped"])
            case.assertFalse((h.job / "service" / "native").exists())
            stderr = (h.trace / "native-profiler.stderr").read_bytes()
            stdout = (h.trace / "native-profiler.stdout").read_bytes()
            context_path = h.trace / "native-request-trace.jsonl"
            context_raw = context_path.read_bytes()
            context = [json.loads(row) for row in context_raw.splitlines()]
            case.assertEqual([row["event"] for row in context],
                ["run_begin", "request_begin", "request_complete", "native_shutdown", "run_end"])
            run_id, identity = context[0]["run_id"], capture["native"]
            case.assertEqual(run_id, capture["run_id"])
            case.assertEqual(context[-2]["native"], identity)

            # Reuse only the existing synthetic DRM declarations/validator shape.
            # The fake CPU child has no DRM client or device: these rows are NOT
            # the output of drm_trace_validation, and make no accounting claim.
            synthetic = declarations().fixture(1)
            native_rows = [json.loads(row) for row in synthetic["native_bytes"].splitlines()]
            for row in native_rows:
                row.update(run_id=run_id, native_pid=str(identity["pid"]),
                           start_ticks=str(identity["start_ticks"]))
            native_raw = declared["wire"](native_rows)
            native_path = h.trace / "native-drm.jsonl"
            with native_path.open("xb") as stream:
                case.assertEqual(stream.write(native_raw), len(native_raw))
            native_validation = synthetic["native_validation"]
            native_validation.update(native=identity)
            native_validation["pin"] = {"path": str(native_path), "bytes": len(native_raw),
                                        "sha256": sha(native_raw)}
            context_validation = {"passed": True, "path": str(context_path),
                "bytes": len(context_raw), "sha256": sha(context_raw), "completed_requests": 1,
                "requests": [{"context": context[1]["context"], "native": identity,
                    "worker_at_return": context[2]["worker_at_return"], "validated_hop": None}]}
            cls.actual = {"stderr_bytes": stderr, "stdout_bytes": stdout, "capture": capture,
                "context_bytes": context_raw, "native_bytes": native_raw,
                "context_validation": context_validation, "native_validation": native_validation,
                "run_id": run_id, "native_identity": identity}
            cls.metadata = metadata
        finally:
            # Reuse the already-tested bounded owned-group/identity cleanup even
            # on an interface assertion failure; never leave the service running.
            case.doCleanups()

    def test_actual_capture_context_and_normal_close_feed_strict_consumer(self):
        result = type(self).consumer(**copy.deepcopy(self.actual))
        self.assertTrue(result["passed"])
        self.assertIs(result["qualified"], False)
        self.assertEqual(result["mode"], "baseline_player_attention_series_v1")
        self.assertEqual(result["request_ids"], [1])
        self.assertEqual(result["request_count"], 1)
        self.assertEqual(len(result["graphs"]), 1)
        self.assertEqual(len(result["graphs"][0]["targets"]), 40)
        self.assertEqual(result["graphs"][0]["metadata_sha256"], sha(self.metadata))
        self.assertEqual(result["requests"][0]["context"],
                         self.actual["context_validation"]["requests"][0]["context"])
        self.assertEqual(result["native"], self.actual["capture"]["native"])
        for name in ("stderr", "stdout", "native", "context"):
            raw = self.actual[name + "_bytes"]
            self.assertEqual(result["raw_pins"][name], {"bytes": len(raw), "sha256": sha(raw)})

    def test_tampered_actual_capture_proof_is_rejected(self):
        changed = copy.deepcopy(self.actual)
        changed["capture"]["streams"]["stderr"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "Player stream ownership/completion/counters/hash differs"):
            type(self).consumer(**changed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
