"""Prepared CPU-only interstage fixtures. Root owns first execution."""
import contextlib
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent


def load(path):
    spec = importlib.util.spec_from_file_location("interstage_fixture_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    raw = path.read_bytes()
    if len(raw) > 262144:
        raise ValueError("Oversized fixture definition")
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def pin(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(path, value):
    path.write_text(json.dumps(value))


class InterstageChecks(unittest.TestCase):
    @contextlib.contextmanager
    def fixture(self):
        audit = load(HERE / "root_interstage_profile.py")
        common = load(HERE / "profile_launch.py")
        base = load(HERE.parent / "run_drm_player_retry02.py")
        with tempfile.TemporaryDirectory() as temporary, contextlib.ExitStack() as stack:
            directory = Path(temporary)
            pcm = directory / "pcm"; pcm.mkdir()
            target = directory / "interstage-root-audit-01.json"
            guard_script, guard_unit = directory / "guard", directory / "guard.service"
            guard_script.write_text("generated guard identity"); guard_unit.write_text("generated unit identity")
            assets = {"runtime": {"path": str(directory / "runtime"), "bytes": 1, "sha256": "b" * 64},
                      "model": {"path": str(directory / "model"), "bytes": 1, "sha256": "c" * 64},
                      "guard_script": pin(guard_script), "guard_unit": pin(guard_unit)}
            guard = {"script": pin(guard_script), "unit": pin(guard_unit), "service": {"ActiveState": "active"},
                     "process": {"pid": 700, "start_ticks": 12, "command": [str(guard_script)]}}
            expected_seed = {"parent": {"synthetic": True}, "cache_identity": {"synthetic": True},
                             "manifest_sha256": "d" * 64, "file_count": 1, "total_bytes": 1}
            seed_path = directory / "seed.json"; save(seed_path, {"shader_cache": {"post": expected_seed}})
            reference = directory / "reference.json"; save(reference, {"generated_reference": True})
            source = pin(HERE / "root_interstage_profile.py")
            plan = {"assets": assets, "source_head": "a" * 40, "source_pins": {"root_interstage": source},
                    "cache_helper": {"sha256": "f" * 64}, "seed_proof": pin(seed_path), "seed_manifest_sha256": "d" * 64}
            plan_pin, human = {"sha256": "1" * 64}, {"pin": {"sha256": "2" * 64}, "age_seconds": 0, "sampled_monotonic": 900}
            cases = {key: {"input_sha256": f"input-{i}", "output_sha256": f"output-{i}"} for i, key in enumerate(base.PCM_CASE_IDS)}
            requests = [{"case_id": key, "request_id": i, "completed": True, "exact_pcm_match": True, **cases[key],
                         "output_shape": [4, 343980, 2], "output_dtype": "<f4", "output_bytes": 4 * 343980 * 2 * 4}
                        for i, key in enumerate(base.PCM_CASE_IDS, 1)]
            before = {prefix + k: v for prefix, rows in (("asset:", assets), ("source:", plan["source_pins"])) for k, v in rows.items()}
            report = {"status": "passed", "qualified": False, "timing_qualification": False, "mode": common.MODE,
                "plan_pin": plan_pin, "human_pin": human["pin"], "source_head": plan["source_head"], "candidate_runtime": assets["runtime"],
                "model": assets["model"], "reference_runtime_sha256": base.FLASH_RUNTIME_SHA256,
                "pins_unchanged": True, "pins_before": before, "pins_after": copy.deepcopy(before), "cleanup_complete": True,
                "guard_before": guard, "guard_after": copy.deepcopy(guard), "errors": [], "within_wall_budget": True,
                "native_trace": {"passed": True, "native_schema": 2, "native_mode": "passive_drm_owned_client_set_v1",
                                 "completed_requests": 16, "request_ids": list(range(1, 17))},
                "capture": {"complete": True}, "attention_series": {"passed": True}, "stdout_protocol": {"passed": True},
                "shader_cache": {"inventory_complete": True}, "requests": requests, "boot_id": "same-boot",
                "started_monotonic": 910, "finished_monotonic": 995,
                "finished_at_utc": (datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(),
                "operator_budget": {"approval_sample_monotonic": 900, "age_seconds": 0, "operator_deadline_monotonic": 1860, "phase": "pcm"},
                "native_identity": {"pid": 501, "start_ticks": 31, "group": 501, "session": 501},
                "readiness_identity": {"pid": 502, "start_ticks": 32, "group": 502, "session": 502}}
            save(pcm / "result.json", report)
            stack.enter_context(mock.patch.object(audit, "BASE", directory))
            stack.enter_context(mock.patch.object(common, "PCM_OUTPUT", pcm))
            stack.enter_context(mock.patch.object(common, "INTERSTAGE_AUDIT", target))
            stack.enter_context(mock.patch.object(common, "ASSETS", {k: Path(v["path"]) for k, v in assets.items()}))
            stack.enter_context(mock.patch.object(common, "load_module", return_value=base))
            stack.enter_context(mock.patch.object(common, "support", return_value=types.SimpleNamespace(validate_build=mock.Mock())))
            player = common.load_player(plan)  # real cap/profile wrappers around the actual frozen strict16 gate
            player.REFERENCE, player.REFERENCE_SHA256 = reference, pin(reference)["sha256"]
            stack.enter_context(mock.patch.object(player, "load_frozen_module", return_value=types.SimpleNamespace(validate_reference=lambda *_: cases)))
            stack.enter_context(mock.patch.object(player, "verify_plan_files"))
            stack.enter_context(mock.patch.object(player, "boot_identity", return_value="same-boot"))
            stack.enter_context(mock.patch.object(player, "guard_identity", return_value=guard))
            stack.enter_context(mock.patch.object(player, "power_state", return_value={"ac_online": True, "lid_open": True}))
            cache = types.SimpleNamespace(SEED_CACHE=directory / "seed-cache", inventory=mock.Mock(return_value=copy.deepcopy(expected_seed)))
            stack.enter_context(mock.patch.object(player, "load_cache_support", return_value=(cache, {})))
            commands = mock.Mock(side_effect=lambda argv, **_: plan["source_head"] if argv[0] == "git" else ("900 900\n" if argv[0] == "ps" else "[]"))
            stack.enter_context(mock.patch.object(player, "read_command", commands))
            absent = stack.enter_context(mock.patch.object(audit, "pid_absent", return_value=True))
            stack.enter_context(mock.patch.object(audit.time, "monotonic", return_value=1000))
            yield types.SimpleNamespace(audit=audit, common=common, player=player, plan=plan, pin=plan_pin, human=human,
                report=report, path=pcm / "result.json", target=target, guard=guard, cache=cache, commands=commands, absent=absent)

    def test_dry_and_fresh_human_precede_all_retained_and_host_helpers(self):
        audit = load(HERE / "root_interstage_profile.py")
        with mock.patch.object(sys, "argv", ["audit"]), mock.patch.object(audit, "load_wrapper", side_effect=AssertionError("dry source read")), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(audit.main(), 0)
        for failing in ("plan", "human"):
            order = []
            def plan():
                order.append("plan")
                if failing == "plan": raise ValueError("unarmed")
                return {}, {}
            def human(*_):
                order.append("human"); raise ValueError("no fresh human")
            common = types.SimpleNamespace(load_plan=plan, readiness=human, HUMAN=Path("/unused"), load_player=mock.Mock())
            wrapper = types.SimpleNamespace(load_common=lambda: common)
            with mock.patch.object(sys, "argv", ["audit", "--run"]), mock.patch.object(audit, "load_wrapper", return_value=wrapper):
                with self.assertRaises(ValueError): audit.main()
            common.load_player.assert_not_called()
            self.assertEqual(order, ["plan"] if failing == "plan" else ["plan", "human"])

    def test_full_written_audit_passes_actual_strict16_and_profile_gate_once(self):
        with self.fixture() as f:
            result = f.audit.audit(f.common, f.player, f.plan, f.pin, f.human)
            self.assertEqual(result["status"], "passed"); self.assertTrue(result["strict_pcm_gate_passed"])
            saved = json.loads(f.target.read_text())
            self.assertEqual(saved, result)
            gate = f.player.validate_pcm_gate(f.plan, f.pin, f.human)
            self.assertTrue(gate["passed"]); self.assertEqual(gate["pcm_result_pin"]["sha256"], pin(f.path)["sha256"])
            self.assertEqual(result["original_operator_deadline_monotonic"], 1860)
            self.assertEqual(result["audit_deadline_monotonic"], 1045)
            self.assertEqual(result["known_pids_absent"], {"501": True, "502": True})
            self.assertEqual(result["known_groups_absent"], {"501": True, "502": True})
            self.assertIs(result["native_group_absent"], True)
            original = f.target.read_bytes()
            with self.assertRaises(ValueError): f.audit.audit(f.common, f.player, f.plan, f.pin, f.human)
            self.assertEqual(f.target.read_bytes(), original)

    def test_bad_lineage_deadlines_or_exact_pcm_cannot_leave_passing_receipt(self):
        for mutation in ("boot", "expired", "renewed", "remaining", "utc", "plan", "case", "profile", "output"):
            with self.subTest(mutation=mutation), self.fixture() as f:
                if mutation == "boot": f.report["boot_id"] = "wrong-boot"
                elif mutation == "expired": f.report["finished_monotonic"] = 939
                elif mutation == "renewed": f.report["operator_budget"]["operator_deadline_monotonic"] += 1
                elif mutation == "remaining":
                    f.report["operator_budget"].update(approval_sample_monotonic=500, operator_deadline_monotonic=1460)
                    f.report["started_monotonic"] = 510
                elif mutation == "utc": f.report["finished_at_utc"] = (datetime.now(timezone.utc) - timedelta(seconds=61)).isoformat()
                elif mutation == "plan": f.report["plan_pin"] = {"sha256": "3" * 64}
                elif mutation == "case": f.report["requests"].pop()
                elif mutation == "profile": f.report["attention_series"]["passed"] = False
                elif mutation == "output": f.report["requests"][0]["output_sha256"] = "wrong"
                save(f.path, f.report)
                with self.assertRaises((ValueError, RuntimeError)): f.audit.audit(f.common, f.player, f.plan, f.pin, f.human)
                result = json.loads(f.target.read_text())
                self.assertEqual(result["status"], "failed"); self.assertFalse(result["strict_pcm_gate_passed"])
                if mutation == "output": self.assertIn("immutable reference", result["error"])
                else: f.commands.assert_not_called()

    def test_owned_resources_power_guard_seed_or_changed_source_fail_closed(self):
        for mutation in ("pid", "group", "readiness_group", "pipewire", "power", "guard", "seed", "source"):
            with self.subTest(mutation=mutation), self.fixture() as f:
                if mutation == "pid": f.absent.return_value = False
                elif mutation == "group": f.commands.side_effect = lambda argv, **_: f.plan["source_head"] if argv[0] == "git" else "501 501\n"
                elif mutation == "readiness_group": f.commands.side_effect = lambda argv, **_: f.plan["source_head"] if argv[0] == "git" else "777 502\n"
                elif mutation == "pipewire":
                    f.commands.side_effect = lambda argv, **_: f.plan["source_head"] if argv[0] == "git" else ("900 900\n" if argv[0] == "ps" else '[{"id":1,"info":{"props":{"application.process.id":501}}}]')
                elif mutation == "power": f.player.power_state.return_value = {"ac_online": False, "lid_open": True}
                elif mutation == "guard":
                    changed = copy.deepcopy(f.guard); changed["service"]["ActiveState"] = "changed"
                    f.player.guard_identity.side_effect = [f.guard, changed]
                elif mutation == "seed": f.cache.inventory.return_value["total_bytes"] = 2
                elif mutation == "source": f.player.verify_plan_files.side_effect = ValueError("changed source")
                with self.assertRaises((ValueError, RuntimeError)): f.audit.audit(f.common, f.player, f.plan, f.pin, f.human)
                saved = json.loads(f.target.read_text())
                self.assertEqual(saved["status"], "failed"); self.assertFalse(saved["strict_pcm_gate_passed"])


if __name__ == "__main__":
    unittest.main()
