"""Prepared CPU-only launch-gate checks; host/process boundaries remain forbidden."""
import contextlib
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent


def load(path, expected=None):
    raw = path.read_bytes()
    if len(raw) > 256 * 1024 or (expected and hashlib.sha256(raw).hexdigest() != expected):
        raise RuntimeError("Bounded reviewed CPU fixture source required")
    spec = importlib.util.spec_from_file_location("profile_launch_fixture_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def pin(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


class LaunchChecks(unittest.TestCase):
    def setUp(self):
        self.common = load(HERE / "profile_launch.py")
        self.player_cli = load(HERE / "run_profile_player.py")

    def plan(self):
        c = self.common
        def row(path):
            return {"path": str(path), "bytes": 1, "sha256": "a" * 64}
        value = {"schema": 1, "status": "frozen_pending_fresh_player_node_readiness", "mode": c.MODE,
            "consent": None, "qualified": False, "physical_execution": False, "timing_qualification": False,
            "source_root": str(c.ROOT), "source_head": "a" * 40, "stages": ["pcm16", "player120"],
            "seconds": 120, "operator_seconds": 960, "pcm_seconds": 300, "phase_seconds": 480,
            "interstage_seconds": 60, "strict_service_target_ms": 4095, "window_policy": "hidden",
            "native_schema": 2, "native_mode": "passive_drm_owned_client_set_v1",
            "native_trace_limits": {"record_bytes": 16384, "file_bytes": 1048576, "requests": 64, "physical_rows": 82},
            "drm_device": {"driver": "i915", "pdev": "0000:00:02.0"}, "logger_environment": dict(c.LOGGER),
            "cache_policy": "identical-verified-private-seed-copies-128M", "assets": {k: row(v) for k, v in c.ASSETS.items()},
            "source_pins": {k: row(v) for k, v in c.SOURCES.items()},
            "reference_runtime_sha256": "6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53"}
        value["assets"]["runtime"]["sha256"] = c.RUNTIME_SHA
        value["assets"]["binary"]["sha256"] = "64158dfce52d03c319585459bd35571f8872faeb0bf5ab0bf5211451ac033bce"
        value["assets"]["model"]["sha256"] = "f8c54ba35df95aafea7881eac214b58ec18a73cbcb6ff5a90f4b762631a286b6"
        value["source_pins"]["launch_common"] = pin(Path(c.__file__))
        value["source_pins"]["base_player"]["sha256"] = c.PLAYER_SHA
        value["source_pins"]["standalone_support"]["sha256"] = c.SUPPORT_SHA
        for name, path in (("build_result", c.P / "build-admission-01.json"), ("cache_helper", c.BASE / "cache_support.py"),
                           ("gpu_helper", c.BASE / "gpu.py"), ("package_helper", c.BASE / "package.py"),
                           ("seed_proof", c.BASE / "seed.json"), ("review", c.BASE / "review.json")):
            value[name] = row(path)
        value["review"]["status"] = "passed"
        return value

    def wrapped_player(self):
        c = self.common
        player = load(c.PLAYER, c.PLAYER_SHA)  # stdlib definitions only; no main or host function runs
        player.validate_pcm_gate = mock.Mock(return_value={"pcm_result_pin": {"synthetic": True}})
        with mock.patch.object(c, "load_module", return_value=player), \
             mock.patch.object(c, "support", return_value=types.SimpleNamespace(validate_build=mock.Mock())):
            return c.load_player(self.plan())

    def test_dry_and_unarmed_paths_do_not_load_helpers_or_start_host_work(self):
        cli = self.player_cli
        with mock.patch.object(sys, "argv", ["run_profile_player.py"]), \
             mock.patch.object(cli, "load_common", side_effect=AssertionError("helper import")), \
             contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(cli.main(), 0)
        self.assertFalse(json.loads(output.getvalue())["host_queried"])
        with mock.patch.object(sys, "argv", ["run_profile_player.py", "--run"]), \
             mock.patch.object(cli, "load_common", side_effect=AssertionError("helper import")):
            with self.assertRaises(ValueError): cli.main()
        for failure in ("plan", "human"):
            calls = []
            def load_plan():
                calls.append("plan")
                if failure == "plan": raise ValueError("unarmed")
                return {}, {"sha256": "a" * 64}
            def readiness(*_):
                calls.append("human"); raise ValueError("missing future readiness")
            common = types.SimpleNamespace(load_plan=load_plan, readiness=readiness,
                HUMAN=Path("/unused/readiness.json"), load_player=mock.Mock(side_effect=AssertionError("host helper imported")))
            with self.subTest(failure=failure), mock.patch.object(cli, "load_common", return_value=common), \
                 mock.patch.object(sys, "argv", ["run_profile_player.py", "--run", "--allow-host-audio", "--drm-busy-diagnostic"]):
                with self.assertRaises(ValueError): cli.main()
            self.assertEqual(calls, ["plan"] if failure == "plan" else ["plan", "human"])
            common.load_player.assert_not_called()

    def test_actual_player_bootstrap_checks_bounded_fixed_source_before_exec(self):
        cli = self.player_cli
        with mock.patch.object(cli, "COMMON_SHA", "PENDING_UNARMED"), \
             mock.patch.object(cli.os, "open", side_effect=AssertionError("unarmed source read")):
            with self.assertRaisesRegex(ValueError, "unarmed"): cli.load_common()
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary); path = directory / "profile_launch.py"
            path.write_text("VALUE = 17\n")
            expected = hashlib.sha256(path.read_bytes()).hexdigest()
            with mock.patch.object(cli, "COMMON", path), mock.patch.object(cli, "COMMON_SHA", expected):
                self.assertEqual(cli.load_common().VALUE, 17)
                path.write_text("raise AssertionError('changed source executed')\n")
                with self.assertRaises(ValueError): cli.load_common()
                path.write_bytes(b"#" * (256 * 1024 + 1))
                # A matching digest isolates the size cap: the old unbounded
                # loader would otherwise execute this valid oversized comment.
                with mock.patch.object(cli, "COMMON_SHA", hashlib.sha256(path.read_bytes()).hexdigest()):
                    with self.assertRaises(ValueError): cli.load_common()
            path.unlink(); target = directory / "actual.py"; target.write_text("VALUE = 17\n"); path.symlink_to(target)
            with mock.patch.object(cli, "COMMON", path), mock.patch.object(cli, "COMMON_SHA", expected):
                with self.assertRaises((ValueError, OSError)): cli.load_common()

    def test_real_plan_reader_enforces_assets_source_identity_and_review_before_support(self):
        c = self.common
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "plan.json"
            build = mock.Mock()
            for change in (None, "unarmed", "runtime_path", "binary_hash", "missing_consumer", "common_hash", "logger", "budget", "float_limits"):
                value = self.plan()
                if change == "unarmed": value["review"]["status"] = "pending"
                elif change == "runtime_path": value["assets"]["runtime"]["path"] = str(c.A / "conflux-stem-runtime")
                elif change == "binary_hash": value["assets"]["binary"]["sha256"] = "b" * 64
                elif change == "missing_consumer": del value["source_pins"]["profile_consumer"]
                elif change == "common_hash": value["source_pins"]["launch_common"]["sha256"] = "b" * 64
                elif change == "logger": value["logger_environment"]["GGML_VK_PERF_LOGGER_CONCURRENT"] = "1"
                elif change == "budget": value["operator_seconds"] = 961
                elif change == "float_limits": value["native_trace_limits"]["requests"] = 64.0
                path.write_text(json.dumps(value)); build.reset_mock()
                with self.subTest(change=change), mock.patch.object(c, "PLAN", path), \
                     mock.patch.object(c, "support", return_value=types.SimpleNamespace(validate_build=build)):
                    if change is None:
                        actual, actual_pin = c.load_plan(path)
                        self.assertEqual(actual, value); self.assertEqual(actual_pin["sha256"], pin(path)["sha256"])
                        build.assert_called_once_with(value)
                    else:
                        with self.assertRaises(ValueError): c.load_plan(path)
                        build.assert_not_called()

    def test_common_reader_rejects_alias_empty_overbound_and_changed_identity(self):
        c = self.common
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "pin.json"; path.write_bytes(b"{}\n")
            data, original = c.read_file(path, 3)
            self.assertEqual(data, b"{}\n")
            self.assertEqual(c.read_json(path, 3, original)[0], {})
            alias = path.parent / "alias"; alias.symlink_to(path)
            with self.assertRaises(ValueError): c.read_file(alias)
            with self.assertRaises(ValueError): c.read_file(path, 2)
            before = path.stat()
            os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns + 1))
            with self.assertRaises(ValueError): c.read_file(path, 3, original)
            path.write_bytes(b"[]\n")
            with self.assertRaises(ValueError): c.read_file(path, 3, original)
            path.write_bytes(b"")
            with self.assertRaises(ValueError): c.read_file(path)

    def test_fresh_human_and_original_pcm_player_deadline_thresholds(self):
        c = self.common
        now = datetime(2026, 10, 21, 12, tzinfo=timezone.utc)
        value = {"schema": 1, "decision": "ready", "ready_for_diagnostic": c.MODE, "diagnostic_mode": c.MODE,
            "stages": ["pcm16", "player120"], "ui_mode": "background", "window_policy": "hidden",
            "maximum_operator_seconds": 960, "plan_sha256": "a" * 64,
            "recorded_at_utc": (now - timedelta(seconds=100)).isoformat(), "question_item_id": "future-item",
            "human_question": "Fixed conditions?", "human_reply": "Ready",
            **{k: True for k in ("AC_power", "lid_open", "Codex_minimized", "other_work_paused", "controls_untouched", "no_suspend")}}
        clock = types.SimpleNamespace(fromisoformat=datetime.fromisoformat, now=lambda _tz: now)
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "human.json"
            for change in (None, "stale", "future", "plan", "condition", "float_budget"):
                changed = dict(value)
                if change == "stale": changed["recorded_at_utc"] = (now - timedelta(seconds=960)).isoformat()
                elif change == "future": changed["recorded_at_utc"] = (now + timedelta(seconds=1)).isoformat()
                elif change == "plan": changed["plan_sha256"] = "b" * 64
                elif change == "condition": changed["controls_untouched"] = False
                elif change == "float_budget": changed["maximum_operator_seconds"] = 960.0
                path.write_text(json.dumps(changed))
                with self.subTest(change=change), mock.patch.object(c, "HUMAN", path), \
                     mock.patch.object(c, "datetime", clock), mock.patch.object(c.time, "monotonic", return_value=1000):
                    if change is None:
                        ready = c.readiness(path, {"sha256": "a" * 64})
                        self.assertEqual((ready["age_seconds"], ready["sampled_monotonic"]), (100, 1000))
                        self.assertIn("identity", ready["pin"])
                    else:
                        with self.assertRaises(ValueError): c.readiness(path, {"sha256": "a" * 64})
        player = self.wrapped_player()
        for phase, age, limit in (("pcm", 120, 300), ("player", 480, 480)):
            ready = {"age_seconds": age, "sampled_monotonic": 1000}
            budget = player.operator_budget(ready, 1000, 1000, phase=phase)
            self.assertEqual(budget["permitted_seconds"], limit)
            with self.assertRaises(RuntimeError): player.operator_budget({**ready, "age_seconds": age + .001}, 1000, 1000, phase=phase)
        later = player.operator_budget({"age_seconds": 0, "sampled_monotonic": 1300}, 1300, 1300)
        retained = player.retain_original_budget(later, {"original_operator_deadline_monotonic": 1860}, 1300)
        self.assertEqual(retained["operator_deadline_monotonic"], 1860)
        with self.assertRaises(RuntimeError): player.retain_original_budget(later, {"original_operator_deadline_monotonic": 1860}, 1381)

    def test_fixed_cache_parent_seed_paths_and_environment_without_population(self):
        cache = load(HERE / "cache_support.py")
        seed_parent = HERE.parents[3] / "benchmarks-local/background-player-01/request-trace-candidate/cache-pair"
        self.assertEqual(cache.SEED_PARENT, seed_parent)
        self.assertEqual(cache.SEED_CACHE, seed_parent / "driver-cache-01")
        self.assertEqual(cache.PHASE_CACHES, {"pcm": HERE / "driver-cache-pcm-01", "player": HERE / "driver-cache-player-01"})
        for arm in ("pcm", "player"):
            value = cache.cache_environment({"KEEP": "unchanged"}, arm)
            self.assertEqual(value, {"KEEP": "unchanged", "MESA_SHADER_CACHE_DIR": str(cache.PHASE_CACHES[arm]), "MESA_SHADER_CACHE_MAX_SIZE": "128M"})
        with self.assertRaises(ValueError): cache.cache_environment({}, "baseline")
        with self.assertRaises(ValueError): cache.cache_environment({"MESA_SHADER_CACHE_DIR": "/other"}, "pcm")
        with tempfile.TemporaryDirectory() as temporary:
            parent = Path(temporary); parent.chmod(0o700)
            with mock.patch.object(cache, "PARENT", parent):
                self.assertEqual(cache.capture_cache_parent()["mode"], 0o700)
                parent.chmod(0o755)
                with self.assertRaises(ValueError): cache.capture_cache_parent()

    def test_actual_wrapped_logger_and_profiled_pcm_gate_reject_shortcuts(self):
        c = self.common; player = self.wrapped_player()
        with mock.patch.dict(os.environ, {"PATH": "/usr/bin"}, clear=True):
            value = player.logger_environment({"KEEP": "yes"})
            self.assertEqual({k: value[k] for k in c.LOGGER}, c.LOGGER)
            self.assertEqual(value["QT_QUICK_BACKEND"], "software")
            with self.assertRaises(RuntimeError): player.logger_environment({"GGML_VK_PERF_LOGGER_CONCURRENT": "1"})
            args = types.SimpleNamespace(output=c.OUTPUT, seconds=120, live_stems=True, live_stems_hour=False,
                background=True, service=c.ASSETS["service"], worker=c.ASSETS["worker"])
            player.logger_contract(args)
            for key, bad in (("output", c.BASE / "old-output"), ("seconds", 121), ("service", c.A / "service_drm.py")):
                changed = types.SimpleNamespace(**{**vars(args), key: bad})
                with self.assertRaises(ValueError): player.logger_contract(changed)
            with mock.patch.dict(os.environ, {"CONFLUX_PRIVATE_ROUTING_CHECK": "1"}):
                with self.assertRaises(ValueError): player.logger_contract(args)
        proof = {"capture": {"complete": True}, "attention_series": {"passed": True}, "stdout_protocol": {"passed": True}}
        for key in (None, "capture", "attention_series", "stdout_protocol"):
            changed = copy.deepcopy(proof)
            if key: changed[key]["complete" if key == "capture" else "passed"] = False
            with self.subTest(key=key), mock.patch.object(c, "read_json", return_value=(changed, {})):
                if key:
                    with self.assertRaises(ValueError): player.validate_pcm_gate({}, {}, {})
                else:
                    self.assertEqual(player.validate_pcm_gate({}, {}, {}), {"pcm_result_pin": {"synthetic": True}})

    def test_only_fixed_pcm_result_default_cap_allows_complete_profile_report(self):
        c = self.common
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            pcm = directory / "pcm-result"; pcm.mkdir()
            target = pcm / "result.json"
            payload = b'{"payload":"' + b"x" * (3 * 1024**2) + b'"}'
            target.write_bytes(payload)
            other = directory / "other.json"; other.write_bytes(payload)
            with mock.patch.object(c, "PCM_OUTPUT", pcm):
                player = self.wrapped_player()
                value, actual = player.bounded_json(target)
                self.assertEqual(len(value["payload"]), 3 * 1024**2)
                self.assertEqual(actual["sha256"], pin(target)["sha256"])
                # No general cap relaxation: unrelated JSON and explicit
                # smaller requests still use the original strict reader.
                with self.assertRaises(RuntimeError): player.bounded_json(other)
                with self.assertRaises(RuntimeError): player.bounded_json(target, 1024**2)
                target.write_bytes(b'{"payload":"' + b"x" * (8 * 1024**2) + b'"}')
                with self.assertRaises(RuntimeError): player.bounded_json(target)


if __name__ == "__main__":
    unittest.main()
