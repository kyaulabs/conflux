"""Prepared CPU-only wrapper seam checks; no process, host, audio or model calls."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
CASE_IDS = tuple(f"{track}:{start}" for track in
    ("club_xl", "when_the_light_breaks", "under_my_skin", "stfu") for start in (0, 257985, 515970, 773955))


def pin(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "truncated": False}


class PcmWrapperChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path = HERE / "run_profile_pcm.py"
        raw = path.read_bytes()
        if len(raw) > 65536:
            raise RuntimeError("Bounded new driver source required")
        spec = importlib.util.spec_from_file_location("profile_pcm_fixture_driver", path)
        cls.driver = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = cls.driver
        exec(compile(raw, str(path), "exec"), cls.driver.__dict__)

    def protocol(self):
        ready = {"event": "ready", "pid": 9001,
                 "process_environment": {"OMP_WAIT_POLICY": "PASSIVE", "GOMP_SPINCOUNT": "0"}}
        requests = [{"request_id": i, "case_id": case, "completed": True, "exact_pcm_match": True,
            "native_metrics": {"event": "result", "id": i, "frames": 343980, "stems": 4,
                               "elapsed_ms": i + .25}} for i, case in enumerate(CASE_IDS, 1)]
        packets = [{k: v for k, v in ready.items() if k != "process_environment"}]
        packets += [r["native_metrics"] for r in requests]
        raw = b"".join((json.dumps(r) + "\n").encode() for r in packets)
        return ready, requests, packets, raw

    def good_report(self):
        ready, requests, _, _ = self.protocol()
        return {"status": "passed", "cleanup_complete": True, "pins_unchanged": True,
            "guard_before": {"same": 1}, "guard_after": {"same": 1}, "errors": [], "watchdog_errors": [],
            "requests": requests, "ready": ready,
            "native_trace": {"passed": True, "request_ids": list(range(1, 17))},
            "shader_cache": {"inventory_complete": True}, "capture": {"complete": True},
            "attention_series": {"passed": True, "request_ids": list(range(1, 17))},
            "stdout_protocol": {"passed": True}, "native_stderr": {"truncated": False},
            "native_stdout": {"truncated": False}}

    def test_dry_default_never_loads_common_or_helpers(self):
        text = io.StringIO()
        with mock.patch.object(sys, "argv", ["run_profile_pcm.py"]), \
             mock.patch.object(self.driver, "load_common", side_effect=AssertionError("helper imported")), \
             mock.patch.object(self.driver.subprocess, "Popen", side_effect=AssertionError("child launched")), \
             contextlib.redirect_stdout(text):
            self.assertEqual(self.driver.main(), 0)
        result = json.loads(text.getvalue())
        self.assertEqual((result["cases"], result["maximum_seconds"], result["combined_original_seconds"]), (16, 300, 960))
        self.assertFalse(result["host_queried"])
        self.assertFalse(result["native_started"])

    def test_run_requires_plan_then_fresh_human_before_player_or_run(self):
        for fail in (None, "plan", "human"):
            with self.subTest(fail=fail):
                calls = []
                plan, plan_pin, human, player = {}, {"sha256": "a" * 64}, {"fresh": True}, object()
                common = types.SimpleNamespace(HUMAN=Path("/fixed/future-human.json"))
                def load_plan():
                    calls.append("plan")
                    if fail == "plan": raise ValueError("unarmed")
                    return plan, plan_pin
                def readiness(path, pinned):
                    self.assertEqual(path, common.HUMAN); self.assertIs(pinned, plan_pin); calls.append("human")
                    if fail == "human": raise ValueError("missing human")
                    return human
                def load_player(value):
                    self.assertIs(value, plan); calls.append("player"); return player
                def run(*args):
                    self.assertEqual(args, (player, plan, plan_pin, human, common)); calls.append("run"); return 7
                common.load_plan, common.readiness, common.load_player = load_plan, readiness, load_player
                with mock.patch.object(sys, "argv", ["run_profile_pcm.py", "--run"]), \
                     mock.patch.object(self.driver, "load_common", return_value=common), \
                     mock.patch.object(self.driver, "run", side_effect=run):
                    if fail:
                        with self.assertRaises(ValueError): self.driver.main()
                    else: self.assertEqual(self.driver.main(), 7)
                self.assertEqual(calls, ["plan"] if fail == "plan" else ["plan", "human"] if fail else ["plan", "human", "player", "run"])

    def test_common_loader_uses_verified_fixed_bytes_and_rejects_alias_or_unarmed(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "profile_launch.py"
            path.write_text("VALUE = 17\n")
            expected = hashlib.sha256(path.read_bytes()).hexdigest()
            with mock.patch.object(self.driver, "COMMON", path), mock.patch.object(self.driver, "COMMON_SHA", expected):
                self.assertEqual(self.driver.load_common().VALUE, 17)
                path.write_text("raise AssertionError('changed source executed')\n")
                with self.assertRaisesRegex(ValueError, "pin changed"): self.driver.load_common()
            path.unlink(); target = path.parent / "target.py"; target.write_text("VALUE = 17\n"); path.symlink_to(target)
            with mock.patch.object(self.driver, "COMMON", path), mock.patch.object(self.driver, "COMMON_SHA", expected):
                with self.assertRaises(OSError): self.driver.load_common()
            with mock.patch.object(self.driver, "COMMON_SHA", "PENDING_UNARMED"), \
                 mock.patch.object(self.driver.os, "open", side_effect=AssertionError("file opened before freeze")):
                with self.assertRaisesRegex(ValueError, "unarmed"): self.driver.load_common()

    def test_all_sixteen_cases_are_required_in_original_order(self):
        rows = [{"id": x, "samples": object()} for x in CASE_IDS]
        self.assertEqual(list(self.driver.select_cases(rows, CASE_IDS)), list(CASE_IDS))
        for altered in (rows[:-1], rows + [rows[-1]], rows[::-1], rows[:-1] + [rows[0]]):
            with self.subTest(count=len(altered)):
                with self.assertRaises(ValueError): self.driver.select_cases(altered, CASE_IDS)

    def test_exact_seventeen_stdout_objects_match_all_sixteen_saved_metrics(self):
        ready, requests, packets, raw = self.protocol()
        self.assertEqual(self.driver.validate_stdout(raw, ready, requests),
                         {"passed": True, "events": 17, "request_ids": list(range(1, 17))})
        for altered in (packets[:-1], packets + [packets[-1]], packets[:3] + packets[4:]):
            with self.assertRaises(ValueError):
                self.driver.validate_stdout(b"".join((json.dumps(x) + "\n").encode() for x in altered), ready, requests)
        changed = copy.deepcopy(requests); changed[7]["native_metrics"]["elapsed_ms"] += 1
        with self.assertRaises(ValueError): self.driver.validate_stdout(raw, ready, changed)
        with self.assertRaises(ValueError): self.driver.validate_stdout(raw[:-1], ready, requests)

    def finalization_fixture(self, output):
        report = self.good_report()
        output.mkdir(mode=0o700); trace = output / "drm-traces"; trace.mkdir(mode=0o700)
        _, _, _, raw = self.protocol()
        for path, data in ((output / "native.stdout", raw), (output / "native.stderr", b"retained metadata\n"),
                           (trace / "native-drm.jsonl", b'{"schema":2}\n')):
            path.write_bytes(data)
        report["native_stdout"], report["native_stderr"] = pin(output / "native.stdout"), pin(output / "native.stderr")
        report["native_trace"]["pin"] = pin(trace / "native-drm.jsonl")
        report.update(native_identity={"pid": 9001, "start_ticks": 123456, "group": 9001, "session": 9001},
            native_shutdown={"exit_code": 0, "graceful_complete": True}, cleanup={"native_resources_closed": True})
        consumer_path = output.parent / "attention_series.py"
        plan = {"source_pins": {"profile_consumer": {"path": str(consumer_path), "sha256": "b" * 64}}}
        consumer = types.SimpleNamespace(parse_series=mock.Mock(return_value={
            "passed": True, "request_ids": list(range(1, 17)), "request_count": 16}))
        def read(path, maximum, expected):
            path = Path(path); data = path.read_bytes()
            self.assertLessEqual(len(data), maximum)
            self.assertEqual({k: expected[k] for k in ("path", "bytes", "sha256")},
                             {k: pin(path)[k] for k in ("path", "bytes", "sha256")})
            return data, pin(path)
        common = types.SimpleNamespace(SOURCES={"profile_consumer": consumer_path},
            read_file=mock.Mock(side_effect=read), load_module=mock.Mock(return_value=consumer))
        return report, plan, common, consumer

    def test_finalizer_reads_exact_retained_paths_after_cleanup_and_passes_actual_proof(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "pcm-equivalence-01"
            report, plan, common, consumer = self.finalization_fixture(output)
            with mock.patch.object(self.driver.time, "monotonic", return_value=10):
                self.driver.finalize_series(report, output, plan, common, 20)
            self.assertEqual([x.args[0] for x in common.read_file.call_args_list],
                [output / "native.stderr", output / "native.stdout", output / "drm-traces/native-drm.jsonl"])
            call = consumer.parse_series.call_args
            self.assertEqual(call.kwargs["capture"]["kind"], "standalone_pcm_capture_v1")
            self.assertIs(call.kwargs["capture"]["capture"], report["capture"])
            self.assertIs(call.kwargs["capture"]["native_shutdown"], report["native_shutdown"])
            self.assertIs(call.kwargs["capture"]["native_resources_closed"], True)
            self.assertEqual(call.kwargs["native_identity"], {"pid": 9001, "start_ticks": 123456})
            self.assertEqual(call.kwargs["run_id"], "pcm-equivalence-01")
            common.load_module.assert_called_once_with("profile_pcm_series", common.SOURCES["profile_consumer"], "b" * 64)

    def test_finalizer_refuses_precleanup_wrong_path_incomplete_series_and_expired_original_clock(self):
        for change in ("cleanup", "native", "before_deadline", "after_deadline", "path", "count"):
            with self.subTest(change=change), tempfile.TemporaryDirectory() as temporary:
                output = Path(temporary) / "pcm-equivalence-01"
                report, plan, common, consumer = self.finalization_fixture(output)
                if change == "cleanup": report["cleanup_complete"] = False
                elif change == "native": report["native_trace"]["passed"] = False
                elif change == "path": plan["source_pins"]["profile_consumer"]["path"] = "/unplanned/consumer.py"
                elif change == "count": consumer.parse_series.return_value["request_count"] = 1
                times = [20] if change == "before_deadline" else [10, 20] if change == "after_deadline" else [10, 10]
                with mock.patch.object(self.driver.time, "monotonic", side_effect=times):
                    with self.assertRaises(ValueError): self.driver.finalize_series(report, output, plan, common, 20)
                if change in ("cleanup", "native", "before_deadline"):
                    common.read_file.assert_not_called(); common.load_module.assert_not_called()
                if change == "path": common.load_module.assert_not_called()

    def test_final_gate_never_promotes_old_failure_one_case_or_expired_clock(self):
        for change in (None, "prior_failed", "expired", "one_case", "series", "case_order"):
            with self.subTest(change=change):
                report = self.good_report()
                if change == "prior_failed": report["status"] = "failed"
                elif change == "one_case": report["requests"] = report["requests"][:1]
                elif change == "series": report["attention_series"]["passed"] = False
                elif change == "case_order": report["requests"].reverse()
                with mock.patch.object(self.driver.time, "monotonic", return_value=30 if change == "expired" else 10):
                    self.driver.apply_final_gates(report, CASE_IDS, 0, 20)
                self.assertEqual(report["status"], "passed" if change is None else "failed")


if __name__ == "__main__":
    unittest.main()
