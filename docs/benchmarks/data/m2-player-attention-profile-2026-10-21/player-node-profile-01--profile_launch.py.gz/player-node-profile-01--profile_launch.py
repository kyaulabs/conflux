"""Fixed private PCM16/player120 launch bindings; no work at import time."""
import hashlib
import importlib.util
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import re
import stat
import sys
import time

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
A = BASE.parent
P = A/'per-node-profile-01'
PLAN, HUMAN = BASE/'player-node-plan-01.json', BASE/'human-readiness-01.json'
MODE = 'baseline-node-pcm16-player120-01'
PLAYER = A/'run_drm_player_retry02.py'
PLAYER_SHA = '05e35bfb723136d430e090c1515163c60bcce7a05f570fcbc6842b4c41e048fb'
SUPPORT = P/'run_attention_pcm.py'
SUPPORT_SHA = '4c766f139ecca6fce0e44bfaa69122492b08eaafce6e7cbdc05c5ec358be7902'
RUNTIME = P/'baseline-stem-runtime'
RUNTIME_SHA = 'edfa1b9469ba5298d4b99978bdf79f10bf7269c15abcbdf6b97c36b48f4da6f2'
LOGGER = {'GGML_VK_PERF_LOGGER':'1','GGML_VK_PERF_LOGGER_FREQUENCY':'1'}
PCM_OUTPUT, OUTPUT = BASE/'pcm-equivalence-01', BASE/'short-live-profile-01'
INTERSTAGE_AUDIT = BASE/'interstage-root-audit-01.json'
ASSETS = {'binary':ROOT/'build/live-drain/conflux-manual-playback-soak',
    'track_a':ROOT/'benchmarks-local/user-tracks-2026-10-17/assets/club_xl-30s-23p4s.wav',
    'track_b':ROOT/'benchmarks-local/m1-handoff-2026-10-17/quiet-soak-1.wav',
    'python':Path('/usr/bin/python3.14'),'exporter':ROOT/'tools/stems/export.py',
    'worker':ROOT/'tools/stems/worker.py','service':BASE/'service_profile.py',
    'runtime':RUNTIME,'model':Path('/tmp/conflux-stem-m0/models/htdemucs-f16.gguf'),
    'guard_script':Path('/home/kyau/.local/bin/thermal-guard'),
    'guard_unit':Path('/home/kyau/.config/systemd/user/thermal-guard.service')}
SOURCES = {'launch_common':BASE/'profile_launch.py','player_runner':BASE/'run_profile_player.py',
    'pcm_driver':BASE/'run_profile_pcm.py','profile_capture':BASE/'native_profile_capture.py',
    'profile_consumer':BASE/'attention_series.py','service_entrypoint':BASE/'service_profile.py',
    'base_player':PLAYER,'standalone_support':SUPPORT,'standalone_capture':P/'native_capture.py',
    'context_helper':A/'context_capture.py','private_service':A/'service_drm.py',
    'trace_validator':A/'drm_trace_validation.py','cache':BASE/'cache_support.py',
    'trace_helper':ROOT/'benchmarks-local/background-player-01/request-trace-candidate/trace_sidecar.py',
    'trace_parser':ROOT/'benchmarks-local/background-player-01/request-trace-candidate/parse_trace.py',
    'original_service':ROOT/'tools/stems/service.py'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read_file(path, maximum=2*1024**2, expected=None):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True)==path,'Canonical private file required')
    fd = os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_uid==os.getuid() and before.st_nlink==1
            and 0 < before.st_size <= maximum,'Unsafe or oversized private file')
        data = bytearray()
        while len(data)<before.st_size:
            block = os.read(fd,min(1024**2,before.st_size-len(data)))
            require(block,'Truncated private file');data.extend(block)
        signature = lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        require(signature(before)==signature(os.fstat(fd))==signature(path.lstat()),'Private file changed')
        pin = {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'identity':list(signature(before))}
        if expected is not None:
            require(all(pin[k]==expected.get(k) for k in ('path','bytes','sha256'))
                and ('identity' not in expected or pin['identity']==expected['identity']),'Private file pin differs')
        return bytes(data),pin
    finally:
        os.close(fd)


def read_json(path, maximum=2*1024**2, expected=None):
    raw,pin = read_file(path,maximum,expected)
    return json.loads(raw),pin


def load_module(name,path,digest):
    raw,_ = read_file(path,256*1024,{'path':str(path),'bytes':Path(path).stat().st_size,'sha256':digest})
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module


def support():
    return load_module('profile_standalone_support',SUPPORT,SUPPORT_SHA)


def load_plan(path=PLAN):
    require(path==PLAN,'Only the fixed baseline profiling plan is permitted')
    plan,pin = read_json(path,256*1024)
    require(type(plan.get('schema')) is int and plan['schema']==1
        and plan.get('status')=='frozen_pending_fresh_player_node_readiness'
        and plan.get('mode')==MODE and plan.get('consent') is None and plan.get('qualified') is False
        and plan.get('physical_execution') is False and plan.get('timing_qualification') is False
        and plan.get('source_root')==str(ROOT) and re.fullmatch('[0-9a-f]{40}',plan.get('source_head',''))
        and all(type(plan.get(k)) is int for k in ('seconds','operator_seconds','pcm_seconds',
            'phase_seconds','interstage_seconds','strict_service_target_ms','native_schema'))
        and plan.get('stages')==['pcm16','player120'] and plan.get('seconds')==120
        and plan.get('operator_seconds')==960 and plan.get('pcm_seconds')==300
        and plan.get('phase_seconds')==480 and plan.get('interstage_seconds')==60
        and plan.get('strict_service_target_ms')==4095 and plan.get('window_policy')=='hidden'
        and plan.get('native_schema')==2 and plan.get('native_mode')=='passive_drm_owned_client_set_v1'
        and all(type(v) is int for v in plan.get('native_trace_limits',{}).values())
        and plan.get('native_trace_limits')=={'record_bytes':16384,'file_bytes':1048576,'requests':64,'physical_rows':82}
        and plan.get('drm_device')=={'driver':'i915','pdev':'0000:00:02.0'}
        and plan.get('logger_environment')==LOGGER
        and plan.get('cache_policy')=='identical-verified-private-seed-copies-128M'
        and plan.get('review',{}).get('status')=='passed','Unarmed or out-of-scope profiling plan')
    require(set(plan.get('assets',{}))==set(ASSETS)
        and all(plan['assets'][k].get('path')==str(v) for k,v in ASSETS.items()),'Fixed profiling assets differ')
    require(plan['assets']['runtime'].get('sha256')==RUNTIME_SHA
        and plan['assets']['binary'].get('sha256')=='64158dfce52d03c319585459bd35571f8872faeb0bf5ab0bf5211451ac033bce'
        and plan['assets']['model'].get('sha256')=='f8c54ba35df95aafea7881eac214b58ec18a73cbcb6ff5a90f4b762631a286b6'
        and plan.get('reference_runtime_sha256')=='6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53'
        and plan.get('build_result',{}).get('path')==str(P/'build-admission-01.json')
        and plan.get('cache_helper',{}).get('path')==str(BASE/'cache_support.py'),'Fixed runtime/model/build/cache differs')
    for name,path in SOURCES.items():
        require(plan.get('source_pins',{}).get(name,{}).get('path')==str(path),'Required source absent: '+name)
    for row in [*plan['assets'].values(),*plan['source_pins'].values(),*plan.get('runtimes',{}).values(),
                *[plan.get(k,{}) for k in ('build_result','cache_helper','gpu_helper','package_helper','seed_proof','review')]]:
        require(type(row) is dict and Path(row.get('path','')).is_absolute()
            and type(row.get('bytes')) is int and row['bytes']>0
            and re.fullmatch('[0-9a-f]{64}',row.get('sha256','')),'Incomplete fixed file pin')
    read_file(Path(__file__).resolve(),256*1024,plan['source_pins']['launch_common'])
    require(plan['source_pins']['base_player']['sha256']==PLAYER_SHA
        and plan['source_pins']['standalone_support']['sha256']==SUPPORT_SHA,'Frozen runner/support changed')
    support().validate_build(plan)
    return plan,pin


def readiness(path,plan_pin):
    require(path==HUMAN,'Only the original combined readiness record is permitted')
    value,pin = read_json(path,16384)
    issued = datetime.fromisoformat(value.get('recorded_at_utc',''))
    sampled = time.monotonic()
    age = (datetime.now(timezone.utc)-issued).total_seconds() if issued.tzinfo else -1
    require(type(value.get('schema')) is int and value['schema']==1 and value.get('decision')=='ready'
        and value.get('ready_for_diagnostic')==MODE and value.get('diagnostic_mode')==MODE
        and value.get('stages')==['pcm16','player120'] and value.get('ui_mode')=='background'
        and value.get('window_policy')=='hidden' and type(value.get('maximum_operator_seconds')) is int
        and value.get('maximum_operator_seconds')==960
        and value.get('plan_sha256')==plan_pin['sha256'] and 0<=age<960
        and all(value.get(k) is True for k in ('AC_power','lid_open','Codex_minimized',
            'other_work_paused','controls_untouched','no_suspend'))
        and all(type(value.get(k)) is str and 0<len(value[k])<=8192
            for k in ('question_item_id','human_question','human_reply')),
        'Fresh actual combined conditions required; no prior-window reuse')
    return {'record':value,'pin':pin,'age_seconds':age,'maximum_age_seconds':960,
        'sampled_monotonic':sampled}


def load_player(plan):
    player = load_module('baseline_profile_player',PLAYER,PLAYER_SHA)
    player.PLAN,player.HUMAN,player.MODE = PLAN,HUMAN,MODE
    player.OUTPUT,player.PCM_OUTPUT,player.INTERSTAGE_AUDIT = OUTPUT,PCM_OUTPUT,INTERSTAGE_AUDIT
    player.ASSET_PATHS = ASSETS
    player.CACHE_HELPER = BASE/'cache_support.py'
    player.CACHE_HELPER_SHA256 = plan['cache_helper']['sha256']
    player.MANDATORY_SOURCES = {k:Path(v['path']) for k,v in plan['source_pins'].items()}
    player.load_plan = load_plan
    player.readiness = readiness
    player.validate_build_result = support().validate_build
    original_bounded_json = player.bounded_json
    def bounded_json(path,maximum=2*1024**2):
        if path==PCM_OUTPUT/'result.json' and maximum==2*1024**2:
            maximum = 8*1024**2
        return original_bounded_json(path,maximum)
    player.bounded_json = bounded_json
    original_environment = player.logger_environment
    def logger_environment(inherited):
        value = original_environment(inherited)
        value.update(LOGGER)
        return value
    player.logger_environment = logger_environment
    def logger_contract(args):
        require(args.output==OUTPUT and args.seconds==120 and args.live_stems
            and not args.live_stems_hour and args.background and args.service==ASSETS['service']
            and args.worker==ASSETS['worker'] and not os.environ.get('CONFLUX_PRIVATE_ROUTING_CHECK')
            and os.environ.get('QT_QPA_PLATFORM') not in ('offscreen','minimal'),'Only the fixed hidden player profiler is allowed')
        logger_environment(os.environ)
    player.logger_contract = logger_contract
    original_gate = player.validate_pcm_gate
    def validate_pcm_gate(plan,plan_pin,human):
        checked = original_gate(plan,plan_pin,human)
        value,_ = read_json(PCM_OUTPUT/'result.json',8*1024**2,checked['pcm_result_pin'])
        require(value.get('capture',{}).get('complete') is True
            and value.get('attention_series',{}).get('passed') is True
            and value.get('stdout_protocol',{}).get('passed') is True,'New exact-runtime full-profile PCM proof required')
        return checked
    player.validate_pcm_gate = validate_pcm_gate
    original_finalizer = player.finalize_logger_result
    original_free = player.live_required_free_bytes
    player.live_required_free_bytes = lambda seconds,hour:original_free(seconds,hour)+12*1024**2+128*1024+65536
    def finalize(result,args,deadline):
        original_finalizer(result,args,deadline)
        try:
            require(result.get('cleanup_proven') is True and result.get('native_trace',{}).get('passed') is True
                and result.get('request_trace',{}).get('passed') is True,'Owned cleanup and native/context traces required')
            player.verify_plan_files(args.plan,deadline)
            parent = OUTPUT/player.TRACE_DIRECTORY_NAME
            capture,_ = read_json(parent/'native-profiler.capture.json',65536)
            stderr,_ = read_file(parent/'native-profiler.stderr',8*1024**2)
            stdout,_ = read_file(parent/'native-profiler.stdout',128*1024)
            native,_ = read_file(parent/player.NATIVE_TRACE_NAME,1024**2)
            context,_ = read_file(parent/'native-request-trace.jsonl',4*1024**2)
            consumer = load_module('baseline_profile_series',SOURCES['profile_consumer'],args.plan['source_pins']['profile_consumer']['sha256'])
            result['attention_series'] = consumer.consume_player_series(stderr,stdout,capture=capture,
                native_bytes=native,native_validation=result['native_trace'],run_id=OUTPUT.name,
                native_identity=result['native_trace']['native'],context_bytes=context,
                context_validation=result['request_trace'])
            require(result['attention_series'].get('passed') is True,'Incomplete player operation profile')
            result['profile_sources_unchanged'] = True
            result['gpu_query_trace_available'] = True
            result['gpu_query_trace_scope'] = 'All40 final attention inputs/Flash plus remaining query intervals per complete serial native attempt; instrumentation affects scheduling.'
        except Exception as error:
            result['profile_error'] = str(error)
            result['functional_passed'] = result['passed'] = False
            result['gpu_query_trace_available'] = False
        result['qualified'] = result['timing_qualification'] = False
        result['scope'] = 'Instrumented baseline player diagnosis; unchanged4095ms reporting, no latency, visible-UI, thermal-duration or hard-cancel qualification.'
    player.finalize_logger_result = finalize
    return player
