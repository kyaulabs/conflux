"""Prepared stdlib-only series consumer fixtures; no process/device/model calls."""
import copy
import hashlib
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
SEMANTICS = HERE.parent / "per-node-profile-01/parser_checks_01.py"
SEMANTICS_SHA = "e206eb26a810e6e7c134e99a35af0c42107e2534a96c8bac58c1c1d0fb527fd0"
RUN = "player-node-cpu-fixture"
NATIVE = {"pid": 9001, "start_ticks": 123456}
PARENT = "/private/fixture/drm-traces"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def wire(rows):
    return b"".join((json.dumps(x, separators=(",", ":"), allow_nan=False) + "\n").encode() for x in rows)


def load_source(path, expected=None):
    raw = path.read_bytes()
    if len(raw) > 65536 or (expected and sha(raw) != expected):
        raise RuntimeError("Exact CPU fixture/source pin differs")
    scope = {"__name__": "series_fixture_import", "__file__": str(path)}
    exec(compile(raw, str(path), "exec"), scope)
    return scope


class SeriesChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module = load_source(HERE / "attention_series.py")
        # Reuse the already-reviewed independent tensor metadata declarations,
        # not the selector implementation or any generated hardware output.
        cls.semantic = load_source(SEMANTICS, SEMANTICS_SHA)

    def fixture(self, count=3):
        m = self.module
        ready = {"event": "ready", **{k: v for k, v in NATIVE.items() if k == "pid"},
            "backend": "vulkan", "threads": 2, "weight_storage": "native", "fence_wait_mode": "blocking",
            "sample_rate": 44100, "channels": 2, "segment_frames": 343980,
            "stems": ["drums", "bass", "other", "vocals"]}
        shutdown = {"requested_quit": True, "quit_write_complete": True, "killed": False, "exit_code": 0,
            "process_reaped": True, "within_same_shutdown_budget": True, "graceful_complete": True}
        stdout = [ready] + [{"event": "result", "id": i, "frames": 343980, "stems": 4,
            "elapsed_ms": 101.25 + i, "graph_compute_ms": 100 + i} for i in range(1, count + 1)]
        metadata = self.semantic["startup"](1)
        sequence = 1
        for i in range(count):
            sequence += 1
            metadata += self.semantic["full_graph"](False, sequence)
            if i == 0:
                sequence += 1
                metadata += self.semantic["startup"](sequence, timed=True)
        sequence += 1
        metadata += self.semantic["startup"](sequence)
        stderr = b"unrelated diagnostics before any graph\n" + self.semantic["wire"](metadata)
        context = [{"schema": 1, "event": "run_begin", "run_id": RUN,
                    "pins": [{"sha256": "a" * 64}]}]
        checked = []
        for i in range(1, count + 1):
            original = {"request_id": i, "generation": 7 if i <= 2 else 8,
                "window_start_frame": (i % 3) * 257985, "source_id": "a" * 64,
                "preroll": i == 1, "timestamp": 50.0 + i}
            state = {"generation": 8 if i >= 2 else 7, "closed": False}
            context += [{"schema": 1, "event": "request_begin", "context": original, "native": NATIVE},
                {"schema": 1, "event": "request_complete", "request_id": i,
                 "gpu_trace": {"schema": 1, "kind": "passive_drm_request_binding", "run_id": RUN,
                               "native": NATIVE, "request_id": i}, "worker_at_return": state}]
            checked.append({"context": original, "native": NATIVE, "worker_at_return": state,
                "validated_hop": None if i <= 2 else {"request_id": i, "generation": 8, "input_first": original["window_start_frame"]}})
        context += [{"schema": 1, "event": "native_shutdown", "native": NATIVE, **shutdown},
            {"schema": 1, "event": "run_end", "complete": True, "worker_joined": True,
             "started": count, "completed": count, "failed": 0, "pending_request_id": None, "failure": None}]
        common = {"schema": 2, "mode": "passive_drm_owned_client_set_v1", "run_id": RUN,
                  "native_pid": str(NATIVE["pid"]), "start_ticks": str(NATIVE["start_ticks"])}
        native = [{**common, "event": "setup"}] + [{**common, "event": "inference", "request_id": str(i),
            "status": "returned", "call_begin_ns": str(1000 + i * 100), "call_end_ns": str(1050 + i * 100)}
            for i in range(1, count + 1)] + [{**common, "event": "footer", "status": "complete"}]
        result = {"stderr_bytes": stderr, "stdout_bytes": wire(stdout), "context_bytes": wire(context),
            "native_bytes": wire(native), "run_id": RUN, "native_identity": NATIVE,
            # These synthetic summaries stand in for already-required external
            # validators. This suite does not claim to retest DRM arithmetic.
            "context_validation": {"passed": True, "path": PARENT + "/native-request-trace.jsonl",
                "completed_requests": count, "requests": checked},
            "native_validation": {"passed": True, "native": NATIVE, "native_schema": 2,
                "native_mode": "passive_drm_owned_client_set_v1", "request_ids": list(range(1, count + 1)),
                "completed_requests": count, "pin": {"path": PARENT + "/native-drm.jsonl"}},
            "capture": {"schema": 1, "kind": "player_node_capture_v1", "run_id": RUN,
                "native": NATIVE, "complete": True, "parent_valid": True, "errors": [],
                "native_shutdown": shutdown, "streams": {}}}
        return self.refresh(result)

    def refresh(self, value):
        value["context_validation"].update(bytes=len(value["context_bytes"]), sha256=sha(value["context_bytes"]))
        value["native_validation"]["pin"].update(bytes=len(value["native_bytes"]), sha256=sha(value["native_bytes"]))
        for name, limit in (("stderr", 8388608), ("stdout", 131072)):
            raw = value[name + "_bytes"]
            value["capture"]["streams"][name] = {"path": PARENT + "/native-profiler." + name,
                "limit_bytes": limit, "received_bytes": len(raw), "written_bytes": len(raw), "sha256": sha(raw),
                "eof": True, "overflow": False, "read_errors": 0, "write_errors": 0, "close_errors": 0}
        return value

    def player(self, value):
        return self.module["consume_player_series"](**value)

    def core(self, value):
        return self.module["parse_series"](**{k: v for k, v in value.items()
            if k not in ("context_bytes", "context_validation")})

    def standalone(self, value):
        old = value["capture"]
        counters = {"complete": True, "overflow": False, "first_error": "", "read_errors": 0, "write_errors": 0}
        result = {"schema": 1, "kind": "standalone_pcm_capture_v1", "run_id": RUN, "native": NATIVE,
                  "native_shutdown": old["native_shutdown"], "native_resources_closed": True, "capture": counters}
        for name in ("stderr", "stdout"):
            raw = value[name + "_bytes"]
            counters.update({name + "_received": len(raw), name + "_written": len(raw), name + "_eof": True})
            result["native_" + name] = {"path": "/private/fixture/native." + name,
                "bytes": len(raw), "sha256": sha(raw), "truncated": False}
        value["capture"] = result
        return value

    def rejected(self, value, message="."):
        with self.assertRaisesRegex(ValueError, message):
            self.player(value)

    def test_pcm_core_sixteen_results_needs_no_player_context(self):
        result = self.core(self.standalone(self.fixture(16)))
        self.assertEqual(result["request_ids"], list(range(1, 17)))
        self.assertEqual(result["request_count"], 16)
        self.assertEqual(result["non_target_graphs"], 3)
        self.assertEqual(sum(len(x["targets"]) for x in result["graphs"]), 16 * 40)
        self.assertNotIn("context", result["raw_pins"])
        self.assertFalse(result["qualified"])

    def test_standalone_proof_is_explicit_and_never_player_fallback(self):
        self.rejected(self.standalone(self.fixture()))
        for change in ("resources", "counter", "hash", "eof", "error", "truncated"):
            with self.subTest(change=change):
                v = self.standalone(self.fixture())
                if change == "resources": v["capture"]["native_resources_closed"] = False
                elif change == "counter": v["capture"]["capture"]["stderr_received"] -= 1
                elif change == "hash": v["capture"]["native_stderr"]["sha256"] = "0" * 64
                elif change == "eof": v["capture"]["capture"]["stdout_eof"] = False
                elif change == "error": v["capture"]["capture"]["read_errors"] = 1
                else: v["capture"]["native_stdout"]["truncated"] = True
                with self.assertRaises(ValueError): self.core(v)

    def test_player_all_preroll_stale_and_tail_rows_join_by_ordinal_not_seq(self):
        result = self.player(self.fixture())
        self.assertEqual([x["seq"] for x in result["graphs"]], [1, 2, 3, 4, 5, 6])
        self.assertEqual([x["graph_seq"] for x in result["requests"]], [2, 4, 5])
        self.assertEqual([x["request_id"] for x in result["requests"]], [1, 2, 3])
        self.assertTrue(result["requests"][0]["context"]["preroll"])
        self.assertIsNone(result["requests"][0]["validated_hop"])
        self.assertIsNone(result["requests"][1]["validated_hop"])
        self.assertEqual(result["requests"][1]["context"]["generation"], 7)
        self.assertEqual(result["requests"][1]["worker_at_return"]["generation"], 8)
        self.assertEqual(result["requests"][2]["validated_hop"]["request_id"], 3)
        for graph in result["graphs"]:
            if graph["status"] == "complete":
                self.assertEqual((len(graph["targets"]), graph["head_cont_ns"], graph["flash_ns"], graph["rest_ns"]),
                                 (40, 3570, 1210, 128000000000))
                self.assertTrue(all(t["seq"] == graph["seq"] for t in graph["targets"]))
            else:
                self.assertEqual(graph["targets"], [])

    def test_player_context_is_mandatory_and_exact_raw_proof(self):
        for change in ("absent", "failed", "hash", "count", "parent", "summary"):
            with self.subTest(change=change):
                v = self.fixture()
                if change == "absent": v["context_validation"] = None
                elif change == "failed": v["context_validation"]["passed"] = False
                elif change == "hash": v["context_validation"]["sha256"] = "0" * 64
                elif change == "count": v["context_validation"]["completed_requests"] = 2
                elif change == "parent": v["context_validation"]["path"] = "/elsewhere/native-request-trace.jsonl"
                else:
                    v["context_validation"] = copy.deepcopy(v["context_validation"])
                    v["context_validation"]["requests"][1]["context"]["generation"] = 9
                self.rejected(v)

    def test_capture_partial_errors_overflow_counter_and_hash_fail(self):
        for key, bad in (("eof", False), ("overflow", True), ("received_bytes", 0), ("written_bytes", 0),
                         ("sha256", "0" * 64), ("read_errors", 1), ("write_errors", 1), ("close_errors", 1),
                         ("limit_bytes", 8388609), ("path", "/wrong/native-profiler.stderr")):
            with self.subTest(key=key):
                v = self.fixture(); v["capture"]["streams"]["stderr"][key] = bad; self.rejected(v)
        for key, bad in (("complete", False), ("parent_valid", False), ("errors", ["failure"]),
                         ("run_id", "different"), ("native", {"pid": 9002, "start_ticks": 123456})):
            with self.subTest(key=key):
                v = self.fixture(); v["capture"][key] = bad; self.rejected(v)

    def test_runtime_normal_exit_and_close_are_mandatory(self):
        for key, bad in (("exit_code", -15), ("exit_code", False), ("killed", True), ("requested_quit", False),
                         ("process_reaped", False), ("within_same_shutdown_budget", False), ("graceful_complete", False)):
            with self.subTest(key=key, bad=bad):
                v = self.fixture(); v["capture"]["native_shutdown"][key] = bad; self.rejected(v)

    def test_raw_protocol_ids_errors_duplicate_ready_and_nonfinite_fail(self):
        for change in ("duplicate_id", "missing_result", "extra_result", "error", "duplicate_ready", "wrong_pid", "wrong_threads", "partial", "duplicate_field", "nonfinite"):
            with self.subTest(change=change):
                v = self.fixture(); rows = [json.loads(x) for x in v["stdout_bytes"].splitlines()]
                if change == "duplicate_id": rows[2]["id"] = 1
                elif change == "missing_result": rows.pop()
                elif change == "extra_result": rows.append({**rows[-1], "id": 4})
                elif change == "error": rows[-1] = {"event": "error", "id": 3, "message": "after graph"}
                elif change == "duplicate_ready": rows.insert(1, rows[0])
                elif change == "wrong_pid": rows[0]["pid"] = 9002
                elif change == "wrong_threads": rows[0]["threads"] = 1
                v["stdout_bytes"] = wire(rows)
                if change == "partial": v["stdout_bytes"] = v["stdout_bytes"][:-1]
                elif change == "duplicate_field": v["stdout_bytes"] = v["stdout_bytes"].replace(b'"id":1', b'"id":1,"id":1', 1)
                elif change == "nonfinite": v["stdout_bytes"] = v["stdout_bytes"].replace(b'"elapsed_ms":102.25', b'"elapsed_ms":1e999', 1)
                self.rejected(self.refresh(v))

    def test_graphs_partial_missing_extra_and_sequence_gaps_fail(self):
        for change in ("partial", "missing_full", "extra_full", "sequence", "unknown_version", "duplicate_field", "bad_layout"):
            with self.subTest(change=change):
                v = self.fixture(); raw = v["stderr_bytes"]
                if change == "partial": raw = raw[:-1]
                elif change == "missing_full": raw = raw.replace(self.semantic["wire"](self.semantic["full_graph"](False, 5)), b"")
                elif change == "extra_full": raw += self.semantic["wire"](self.semantic["full_graph"](False, 7))
                elif change == "sequence": raw = raw.replace(b"seq=4", b"seq=9")
                elif change == "unknown_version": raw = b"conflux_vk_attention_v2 end seq=0\n" + raw
                elif change == "duplicate_field": raw = raw.replace(b"status=complete reason=none", b"status=complete status=complete reason=none", 1)
                else: raw = raw.replace(b"source_nb=4,2048,256,2752512", b"source_nb=4,4096,256,2752512", 1)
                v["stderr_bytes"] = raw; self.rejected(self.refresh(v))

    def test_startup_envelope_cannot_hide_targets_bad_totals_or_unsupported(self):
        for change in ("selected", "rest", "unsupported", "target", "footer"):
            with self.subTest(change=change):
                v = self.fixture(); raw = v["stderr_bytes"]
                if change == "selected": raw = raw.replace(b"selected=0", b"selected=1", 1)
                elif change == "rest": raw = raw.replace(b"total_ns=0", b"total_ns=1", 1)
                elif change == "unsupported": raw = raw.replace(b"status=not_target_graph", b"status=unsupported", 1)
                elif change == "target": raw = raw.replace(b"conflux_vk_attention_v1 end seq=1", b"conflux_vk_attention_v1 target seq=1\nconflux_vk_attention_v1 end seq=1", 1)
                else: raw = raw.replace(b"end seq=1 records=0 complete=1", b"end seq=1 records=0 complete=0", 1)
                v["stderr_bytes"] = raw; self.rejected(self.refresh(v))

    def test_native_validation_and_raw_attempt_lifetime_sets_fail_closed(self):
        for change in ("validator", "hash", "ids", "raw_id", "run", "start", "status", "footer"):
            with self.subTest(change=change):
                v = self.fixture()
                if change == "validator": v["native_validation"]["passed"] = False
                elif change == "hash": v["native_validation"]["pin"]["sha256"] = "0" * 64
                elif change == "ids": v["native_validation"]["request_ids"] = [1, 3]
                else:
                    rows = [json.loads(x) for x in v["native_bytes"].splitlines()]
                    if change == "raw_id": rows[2]["request_id"] = "1"
                    elif change == "run": rows[2]["run_id"] = "different"
                    elif change == "start": rows[2]["start_ticks"] = "123457"
                    elif change == "status": rows[2]["status"] = "inconclusive"
                    else: rows[-1]["status"] = "failed"
                    v["native_bytes"] = wire(rows); self.refresh(v)
                self.rejected(v)

    def test_context_failures_or_identity_mismatch_cannot_be_filtered(self):
        for change in ("request_failed", "missing_pair", "pending", "failed_count", "wrong_generation", "wrong_binding", "wrong_native", "shutdown"):
            with self.subTest(change=change):
                v = self.fixture(); rows = [json.loads(x) for x in v["context_bytes"].splitlines()]
                if change == "request_failed": rows[4]["event"] = "request_failed"
                elif change == "missing_pair": rows[3:5] = []
                elif change == "pending": rows[-1]["pending_request_id"] = 3
                elif change == "failed_count": rows[-1]["failed"] = 1
                elif change == "wrong_generation": rows[3]["context"]["generation"] = 9
                elif change == "wrong_binding": rows[4]["gpu_trace"]["request_id"] = 3
                elif change == "wrong_native": rows[3]["native"]["start_ticks"] = 123457
                else: rows[-2]["exit_code"] = -15
                v["context_bytes"] = wire(rows); self.rejected(self.refresh(v))

    def test_request_and_input_byte_caps_reject_before_passing_prefix(self):
        self.rejected(self.fixture(65))
        for name, count in (("stderr_bytes", 8388609), ("stdout_bytes", 131073)):
            with self.subTest(name=name):
                v = self.fixture(); v[name] = b"x" * count; self.rejected(self.refresh(v))
        v = self.fixture(); v["stderr_bytes"] += b"conflux_vk_attention_v1 " + b"x" * 1025 + b"\n"
        self.rejected(self.refresh(v))

    def test_global_graph_and_row_caps_are_not_reset_per_parser_call(self):
        for change in ("graphs", "rows"):
            with self.subTest(change=change):
                v = self.fixture()
                if change == "graphs":
                    rows = [entry for seq in range(1, 257) for entry in self.semantic["startup"](seq)]
                    rows += self.semantic["full_graph"](False, 257)
                else:
                    rows = [entry for seq in range(1, 99) for entry in self.semantic["full_graph"](False, seq)]
                v["stderr_bytes"] = self.semantic["wire"](rows)
                self.rejected(self.refresh(v), "cap")

    def test_large_integer_query_totals_keep_exact_precision(self):
        v = self.fixture(1)
        rows = self.semantic["full_graph"](False, 1)
        rows[0][1]["rest_ns"] = str((1 << 53) + 12345)
        self.semantic["totals"](rows)
        v["stderr_bytes"] = self.semantic["wire"](rows)
        result = self.player(self.refresh(v))
        self.assertEqual(result["graphs"][0]["rest_ns"], (1 << 53) + 12345)
        self.assertEqual(result["graphs"][0]["total_ns"], (1 << 53) + 12345 + 4780)


if __name__ == "__main__":
    unittest.main()
