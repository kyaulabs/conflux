"""Bounded saved-data consumer for one serial baseline native profiler lifetime.

Existing context and DRM validators remain mandatory. Graph/request association
uses the pinned serial adapter's one-full-graph-per-completed-call contract and
complete ordered streams, never cross-pipe timestamps or graph sequence == ID.
"""
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat

PARSER = Path(__file__).resolve().parent.parent / "per-node-profile-01/parse_attention.py"
PARSER_SHA = "e2f420e4da5c2edbbbc65edb8e14fd1b35d7a4a55e5b1b3ca0f456cb96b596fa"
STDERR_LIMIT = 8 * 1024 * 1024
STDOUT_LIMIT = 128 * 1024
MAX_REQUESTS = 64
MAX_INTEGER = (1 << 53) - 1


def require(value, message):
    if not value:
        raise ValueError(message)


def integer(value, low=0, high=MAX_INTEGER):
    return type(value) is int and low <= value <= high


def identity(value):
    return (type(value) is dict and set(value) == {"pid", "start_ticks"}
            and all(integer(x, 1) for x in value.values()))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def parser_module():
    # Read/execute exactly the frozen bytes, not a second pathname import.
    fd = os.open(PARSER, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= 65536,
                "Frozen single-graph parser type/size differs")
        raw = bytearray()
        while len(raw) < before.st_size:
            block = os.read(fd, before.st_size - len(raw))
            require(bool(block), "Frozen single-graph parser truncated")
            raw.extend(block)
        signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        require(signature(before) == signature(os.fstat(fd))
                == signature(os.stat(PARSER, follow_symlinks=False))
                and digest(raw) == PARSER_SHA, "Frozen single-graph parser changed")
    finally:
        os.close(fd)
    module = {"__name__": "frozen_attention_series_parser", "__file__": str(PARSER)}
    exec(compile(bytes(raw), str(PARSER), "exec"), module)
    return module


def json_rows(raw, *, byte_limit, line_limit, row_limit):
    require(type(raw) is bytes and 0 < len(raw) <= byte_limit, "JSON stream byte bound differs")
    lines = raw.splitlines(keepends=True)
    require(0 < len(lines) <= row_limit and all(x.endswith(b"\n") and len(x) <= line_limit for x in lines),
            "JSON stream is partial or exceeds line/count bound")
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "Duplicate JSON field")
            result[key] = value
        return result
    def finite(value):
        if type(value) is float:
            return math.isfinite(value)
        if type(value) is list:
            return all(finite(x) for x in value)
        if type(value) is dict:
            return all(finite(x) for x in value.values())
        return True
    result = [json.loads(x, object_pairs_hook=unique,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON"))) for x in lines]
    require(all(type(x) is dict and finite(x) for x in result), "Invalid/nonfinite JSON object")
    return result


def normal_shutdown(row, native):
    require(type(row) is dict and row.get("requested_quit") is True
            and row.get("quit_write_complete") is True and row.get("killed") is False
            and type(row.get("exit_code")) is int and row["exit_code"] == 0
            and row.get("process_reaped") is True and row.get("within_same_shutdown_budget") is True
            and row.get("graceful_complete") is True and row.get("native", native) == native,
            "Capture/context lacks observed normal idle close and reap")


def checked_graphs(stderr):
    parser = parser_module()
    blocks, current, row_count, offset = [], None, 0, 0
    for raw in stderr.splitlines(keepends=True):
        begin, offset = offset, offset + len(raw)
        if not raw.startswith(b"conflux_vk_attention_"):
            continue
        require(raw.startswith(parser["PREFIX"]) and raw.endswith(b"\n"),
                "Unknown or partial attention metadata")
        row_count += 1
        require(row_count <= 4096, "Attention series row cap exhausted")
        kind, fields = parser["fields"](raw[:-1])
        sequence = parser["number"](fields.get("seq"))
        if kind == "begin":
            require(current is None and len(blocks) < 256 and sequence == len(blocks) + 1,
                    "Attention series nesting/sequence/graph cap differs")
            current = {"seq": sequence, "status": fields.get("status"), "raw": [], "byte_begin": begin}
        require(current is not None and sequence == current["seq"], "Attention graph sequence differs")
        current["raw"].append(raw)
        if kind == "end":
            current["byte_end"] = offset
            blocks.append(current)
            current = None
    require(current is None and blocks, "Missing/truncated attention graph series")
    full = [x for x in blocks if x["status"] == "complete"]
    require(1 <= len(full) <= MAX_REQUESTS, "Attention full-model count differs")
    def normalized(block, sequence):
        return b"".join(re.sub(rb"(?<= )seq=[^ \n]+", b"seq=" + str(sequence).encode(), row)
                        for row in block["raw"])
    checked = {}
    for block in full:
        checked[block["seq"]] = parser["parse_attention_output"](normalized(block, 1), packed=False)["full_model"]
    # The frozen parser intentionally requires one full model. Check the small
    # non-target envelope explicitly, without inventing a full graph for it.
    startup = [x for x in blocks if x["status"] != "complete"]
    for block in startup:
        require(len(block["raw"]) == 2, "Non-target graph contains target/extra records")
        begin_kind, first = parser["fields"](block["raw"][0][:-1])
        end_kind, last = parser["fields"](block["raw"][-1][:-1])
        require(begin_kind == "begin" and end_kind == "end"
                and set(first) == {"seq", "status", "reason", "graph_nodes", "queries", "flash_count", "selected",
                                  "total_ns", "head_cont_ns", "flash_ns", "rest_ns"}
                and first["status"] == "not_target_graph" and first["reason"] == "none"
                and set(last) == {"seq", "records", "complete"}, "Non-target graph fields/status differ")
        numeric = {k: parser["number"](v) for k, v in first.items() if k not in ("status", "reason")}
        require(0 < numeric["graph_nodes"] <= 262144 and numeric["queries"] <= numeric["graph_nodes"]
                and all(numeric[k] == 0 for k in ("flash_count", "selected", "head_cont_ns", "flash_ns"))
                and numeric["total_ns"] == numeric["rest_ns"]
                and parser["number"](last["seq"]) == numeric["seq"]
                and parser["number"](last["records"]) == 0 and last["complete"] == "1",
                "Non-target graph extent/timing/footer differs")
        checked[block["seq"]] = {**numeric, "status": "not_target_graph", "targets": []}
    graphs = []
    for block in blocks:
        graph = checked[block["seq"]]
        graph["seq"] = block["seq"]
        for target in graph["targets"]:
            target["seq"] = block["seq"]
        graph.update(stderr_byte_begin=block["byte_begin"], stderr_byte_end=block["byte_end"],
                     metadata_sha256=digest(b"".join(block["raw"])))
        graphs.append(graph)
    return graphs


def parse_series(stderr_bytes, stdout_bytes, *, capture, native_bytes,
                 native_validation, run_id, native_identity):
    """Core PCM/player series; requires native validation, never player lineage."""
    require(type(stderr_bytes) is bytes and 0 < len(stderr_bytes) <= STDERR_LIMIT
            and type(stdout_bytes) is bytes and 0 < len(stdout_bytes) <= STDOUT_LIMIT,
            "Raw profiler stream byte bound differs")
    require(type(run_id) is str and re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", run_id)
            and identity(native_identity), "Invalid run/native identity")
    require(type(native_validation) is dict and native_validation.get("passed") is True
            and identity(native_validation.get("native"))
            and native_validation.get("native") == native_identity
            and native_validation.get("native_schema") == 2
            and type(native_validation.get("native_schema")) is int
            and native_validation.get("native_mode") == "passive_drm_owned_client_set_v1",
            "Existing native validator must pass first")
    require(type(native_bytes) is bytes, "Raw native bytes required")
    require(type(native_validation.get("pin")) is dict
            and type(native_validation["pin"].get("bytes")) is int
            and native_validation["pin"].get("bytes") == len(native_bytes)
            and native_validation["pin"].get("sha256") == digest(native_bytes),
            "Existing validation does not bind these exact native bytes")
    require(type(native_validation["pin"].get("path")) is str, "Native capture path is missing")
    parent = str(PurePosixPath(native_validation["pin"]["path"]).parent)
    require(parent.startswith("/") and ".." not in PurePosixPath(parent).parts,
            "Native capture parent differs")
    require(type(capture) is dict and type(capture.get("schema")) is int and capture["schema"] == 1
            and capture.get("kind") in ("player_node_capture_v1", "standalone_pcm_capture_v1")
            and capture.get("run_id") == run_id and identity(capture.get("native"))
            and capture.get("native") == native_identity,
            "Profiler capture belongs to another producer/lifetime")
    normal_shutdown(capture.get("native_shutdown"), native_identity)
    if capture["kind"] == "standalone_pcm_capture_v1":
        # Exact observations from the frozen P CapturedNativeRuntime. It has
        # aggregate counters and no player parent/close-error attestations.
        c = capture.get("capture")
        require(type(c) is dict and c.get("complete") is True and c.get("overflow") is False
                and c.get("first_error") == "" and capture.get("native_resources_closed") is True
                and all(type(c.get(k)) is int and c[k] == 0 for k in ("read_errors", "write_errors"))
                and PurePosixPath(parent).name == "drm-traces", "Standalone capture is incomplete")
        output_parent = str(PurePosixPath(parent).parent)
        for name, raw in (("stderr", stderr_bytes), ("stdout", stdout_bytes)):
            item = capture.get("native_" + name)
            require(c.get(name + "_eof") is True
                    and all(type(c.get(name + "_" + k)) is int and c[name + "_" + k] == len(raw)
                            for k in ("received", "written"))
                    and type(item) is dict and item.get("path") == output_parent + "/native." + name
                    and type(item.get("bytes")) is int and item["bytes"] == len(raw)
                    and item.get("sha256") == digest(raw) and item.get("truncated") is False,
                    "Standalone retained stream/counters/hash differs")
    else:
        require(capture.get("complete") is True and capture.get("parent_valid") is True
                and capture.get("errors") == [] and type(capture.get("streams")) is dict
                and set(capture["streams"]) == {"stderr", "stdout"}, "Both complete player streams are required")
        for name, raw, limit in (("stderr", stderr_bytes, STDERR_LIMIT), ("stdout", stdout_bytes, STDOUT_LIMIT)):
            item = capture["streams"][name]
            require(type(item) is dict and item.get("path") == parent + "/native-profiler." + name
                    and type(item.get("limit_bytes")) is int and item["limit_bytes"] == limit
                    and all(type(item.get(k)) is int and item[k] == len(raw) for k in ("received_bytes", "written_bytes"))
                    and item.get("sha256") == digest(raw) and item.get("eof") is True
                    and item.get("overflow") is False
                    and all(type(item.get(k)) is int and item[k] == 0 for k in ("read_errors", "write_errors", "close_errors")),
                    "Player stream ownership/completion/counters/hash differs")
    stdout = json_rows(stdout_bytes, byte_limit=STDOUT_LIMIT, line_limit=32768, row_limit=65)
    ready = stdout[0]
    require(ready.get("event") == "ready" and type(ready.get("pid")) is int
            and ready["pid"] == native_identity["pid"] and ready.get("backend") == "vulkan"
            and type(ready.get("threads")) is int and ready["threads"] == 2
            and ready.get("weight_storage") == "native" and ready.get("fence_wait_mode") == "blocking"
            and all(type(ready.get(k)) is int and ready[k] == value for k, value in
                    (("sample_rate", 44100), ("channels", 2), ("segment_frames", 343980)))
            and ready.get("stems") == ["drums", "bass", "other", "vocals"],
            "Raw native ready identity/configuration differs")
    results = stdout[1:]
    require(1 <= len(results) <= MAX_REQUESTS, "Raw native result count differs")
    ids = list(range(1, len(results) + 1))
    for request_id, result in zip(ids, results, strict=True):
        require(result.get("event") == "result" and type(result.get("id")) is int
                and result["id"] == request_id and type(result.get("frames")) is int
                and result["frames"] == 343980 and type(result.get("stems")) is int and result["stems"] == 4,
                "Native result/error/request sequence differs")
    require(type(native_validation.get("request_ids")) is list
            and all(type(x) is int for x in native_validation["request_ids"])
            and native_validation["request_ids"] == ids
            and type(native_validation.get("completed_requests")) is int
            and native_validation["completed_requests"] == len(ids), "Native validated request set differs")
    native = json_rows(native_bytes, byte_limit=1048576, line_limit=16384, row_limit=82)
    for row in native:
        require(type(row.get("schema")) is int and row["schema"] == 2
                and row.get("mode") == "passive_drm_owned_client_set_v1" and row.get("run_id") == run_id
                and row.get("native_pid") == str(native_identity["pid"])
                and row.get("start_ticks") == str(native_identity["start_ticks"]),
                "Native raw run/lifetime binding differs")
    attempts = [x for x in native if x.get("event") == "inference"]
    require([x.get("request_id") for x in attempts] == [str(x) for x in ids]
            and all(x.get("status") == "returned" for x in attempts)
            and native[-1].get("event") == "footer" and native[-1].get("status") == "complete",
            "Native actual attempt set/footer differs")
    graphs = checked_graphs(stderr_bytes)
    full = [x for x in graphs if x["status"] == "complete"]
    require(len(full) == len(ids), "Exactly one full graph per actual native attempt is required")
    joined = [{"request_id": request_id, "graph_seq": graph["seq"], "raw_result": result,
               "native_call_begin_ns": attempt.get("call_begin_ns"),
               "native_call_end_ns": attempt.get("call_end_ns")}
              for request_id, graph, result, attempt in zip(ids, full, results, attempts, strict=True)]
    output = {"schema": 1, "passed": True, "qualified": False, "mode": "baseline_attention_series_v1",
        "run_id": run_id, "native": native_identity, "ready": ready, "request_ids": ids,
        "request_count": len(ids), "startup_graphs": len(graphs) - len(full), "graphs": graphs, "requests": joined,
        "raw_pins": {"stderr": {"bytes": len(stderr_bytes), "sha256": digest(stderr_bytes)},
                     "stdout": {"bytes": len(stdout_bytes), "sha256": digest(stdout_bytes)},
                     "native": {"bytes": len(native_bytes), "sha256": digest(native_bytes)}},
        "parser_sha256": PARSER_SHA,
        "binding": "Full-graph ordinal joins serial raw-result/native-call ordinal under the pinned one-call/one-full-graph adapter; graph sequence is not request ID. No cross-pipe clock alignment.",
        "scope": "Every actual native call. Core parsing alone provides no player generation/publication, PCM reference equality, exclusive-kernel or latency qualification."}
    require(len(json.dumps(output, allow_nan=False).encode()) <= 4 * 1024 * 1024,
            "Attention series result bound exhausted")
    return output


def consume_player_series(stderr_bytes, stdout_bytes, *, capture, context_bytes, native_bytes,
                          context_validation, native_validation, run_id, native_identity):
    """Strict player entry point: context is always required, including stale calls."""
    require(type(capture) is dict and capture.get("kind") == "player_node_capture_v1",
            "Player requires its own complete capture producer, never standalone fallback")
    output = parse_series(stderr_bytes, stdout_bytes, capture=capture, native_bytes=native_bytes,
                          native_validation=native_validation, run_id=run_id, native_identity=native_identity)
    require(type(context_validation) is dict and context_validation.get("passed") is True
            and type(context_bytes) is bytes and type(context_validation.get("bytes")) is int
            and context_validation.get("bytes") == len(context_bytes)
            and context_validation.get("sha256") == digest(context_bytes),
            "Existing context validator must bind these exact bytes")
    require(type(context_validation.get("path")) is str, "Player context path is missing")
    require(str(PurePosixPath(context_validation.get("path", "")).parent)
            == str(PurePosixPath(native_validation["pin"]["path"]).parent), "Player context/native parents differ")
    ids = output["request_ids"]
    context = json_rows(context_bytes, byte_limit=4 * 1024 * 1024, line_limit=32768, row_limit=258)
    require(len(context) == 3 + len(ids) * 2
            and all(type(x.get("schema")) is int and x["schema"] == 1 for x in context),
            "Context attempt count/schema differs")
    header, shutdown, final = context[0], context[-2], context[-1]
    require(header.get("event") == "run_begin" and header.get("run_id") == run_id,
            "Context run identity differs")
    require(shutdown.get("event") == "native_shutdown" and shutdown.get("native") == native_identity,
            "Context native close identity differs")
    normal_shutdown(shutdown, native_identity)
    require(final.get("event") == "run_end" and final.get("complete") is True
            and final.get("worker_joined") is True and final.get("pending_request_id") is None
            and final.get("failure") is None and type(final.get("failed")) is int and final["failed"] == 0
            and all(type(final.get(k)) is int and final[k] == len(ids) for k in ("started", "completed")),
            "Context finalization is incomplete")
    joined = output["requests"]
    for request_id in ids:
        begin, complete = context[request_id * 2 - 1:request_id * 2 + 1]
        original = begin.get("context", {})
        require(begin.get("event") == "request_begin" and identity(begin.get("native"))
                and begin.get("native") == native_identity
                and complete.get("event") == "request_complete" and type(complete.get("request_id")) is int
                and complete["request_id"] == request_id and type(original) is dict
                and set(original) == {"request_id", "generation", "window_start_frame", "source_id", "preroll", "timestamp"}
                and type(original.get("request_id")) is int and original["request_id"] == request_id
                and integer(original.get("generation"), 1) and integer(original.get("window_start_frame"))
                and original["window_start_frame"] % 257985 == 0 and type(original.get("preroll")) is bool
                and type(original.get("source_id")) is str and re.fullmatch(r"[0-9a-f]{64}", original["source_id"])
                and type(original.get("timestamp")) in (int, float) and math.isfinite(original["timestamp"])
                and original["timestamp"] >= 0, "Original request context differs")
        state = complete.get("worker_at_return", {})
        binding = complete.get("gpu_trace", {})
        require(type(state) is dict and set(state) == {"generation", "closed"}
                and integer(state.get("generation")) and type(state.get("closed")) is bool
                and type(binding) is dict and identity(binding.get("native"))
                and type(binding.get("schema")) is int and type(binding.get("request_id")) is int
                and binding == {"schema": 1, "kind": "passive_drm_request_binding", "run_id": run_id,
                                "native": native_identity, "request_id": request_id},
                "Context return binding differs")
        joined[request_id - 1].update(context=original, worker_at_return=state)
    expected_context = context_validation.get("requests")
    require(type(expected_context) is list and len(expected_context) == len(ids)
            and type(context_validation.get("completed_requests")) is int
            and context_validation["completed_requests"] == len(ids), "Validated context request count differs")
    for row, checked in zip(joined, expected_context, strict=True):
        require(type(checked) is dict and checked.get("context") == row["context"]
                and identity(checked.get("native")) and checked.get("native") == native_identity
                and checked.get("worker_at_return") == row["worker_at_return"],
                "Raw context differs from existing validated binding")
        # Keep publication evidence if supplied, including None for preroll/stale.
        row["validated_hop"] = checked.get("validated_hop")
    output.update(mode="baseline_player_attention_series_v1",
        binding="Full-graph ordinal joins agreeing serial raw-result/context/native-call ordinal under the pinned one-call/one-full-graph adapter; graph sequence is not request ID. No cross-pipe clock alignment.",
        scope="All actual attempts, including preroll, stale/discarded and tail; no exclusive-kernel, cancellation-deadline, quality or latency qualification.")
    output["raw_pins"]["context"] = {"bytes": len(context_bytes), "sha256": digest(context_bytes)}
    require(len(json.dumps(output, allow_nan=False).encode()) <= 4 * 1024 * 1024,
            "Attention series result bound exhausted")
    return output
