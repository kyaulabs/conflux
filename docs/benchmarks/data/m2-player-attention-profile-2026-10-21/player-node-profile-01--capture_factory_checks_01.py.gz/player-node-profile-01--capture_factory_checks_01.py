"""Prepared CPU-only actual service/factory checks; no model/GPU/audio backend."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock,patch

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('profile_service_checks',HERE/'service_profile.py')
entry=importlib.util.module_from_spec(spec);spec.loader.exec_module(entry)
service,profile,context=entry.load_service()

FAKE_NATIVE=r'''import argparse,json,os,pathlib,sys,time
p=argparse.ArgumentParser();p.add_argument('--model');p.add_argument('--backend');p.add_argument('--threads',type=int);a=p.parse_args()
mode=MODE
start=pathlib.Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]
pathlib.Path(__file__).with_suffix('.identity.json').write_text(json.dumps({'pid':os.getpid(),'start_ticks':start}))
print(json.dumps({'event':'ready','sample_rate':44100,'channels':2,'segment_frames':343980,'stems':['drums','bass','other','vocals'],
 'backend':a.backend,'threads':a.threads,'revision':'a'*40,'weight_storage':'native','fence_wait_mode':'blocking','pid':os.getpid(),
 'fixture_parent':os.getppid(),'fixture_group':os.getpgrp()}),flush=True)
for line in sys.stdin:
 request=json.loads(line)
 if request.get('command')=='quit':
  sys.stderr.buffer.write(b'q'*(8388609 if mode=='overflow' else 262144));sys.stderr.flush()
  sys.exit(7 if mode=='exit7' else 0)
 if mode=='hang':time.sleep(10)
 with open(request['output'],'wb') as stream:stream.truncate(4*343980*2*4)
 print(json.dumps({'event':'result','id':request['id'],'frames':343980,'stems':4}),flush=True)
'''


class RunningService:
    def __init__(self,case,mode):
        self.case=case;self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.job=self.root/'job';self.job.mkdir(mode=0o700)
        self.trace=self.root/'trace';self.trace.mkdir(mode=0o700)
        self.source=self.job/'input.f32';self.source.write_bytes(__import__('struct').pack('<ff',.1,-.1)*211)
        self.model=self.root/'model';self.model.write_bytes(b'CPU fixture model identity only')
        self.runtime=self.root/'runtime.py';self.runtime.write_text('#!'+sys.executable+'\n'+FAKE_NATIVE.replace('mode=MODE','mode='+repr(mode)));self.runtime.chmod(0o700)
        env=os.environ.copy();env.update(CONFLUX_DRM_CONTEXT_DIRECTORY=str(self.trace),CONFLUX_DRM_USAGE_RUN_ID='fixture-'+mode,
            CONFLUX_DRM_USAGE_TRACE=str(self.trace/'native-drm.jsonl'),PYTHONDONTWRITEBYTECODE='1')
        self.child=subprocess.Popen([sys.executable,'-B',str(HERE/'service_profile.py'),'--input',str(self.source),
            '--directory',str(self.job/'service'),'--runtime',str(self.runtime),'--model',str(self.model),'--backend','vulkan',
            '--threads','2','--max-seconds','8','--request-timeout','.25','--max-diagnostic-bytes','65536'],
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,bufsize=0,env=env)
        self.buffer=bytearray();self.pending=[];self.next_id=1
        case.addCleanup(self.cleanup)
    def event(self,kind):
        deadline=time.monotonic()+6
        while True:
            for i,row in enumerate(self.pending):
                if row.get('event')==kind:return self.pending.pop(i)
            while b'\n' in self.buffer:
                line,_,rest=self.buffer.partition(b'\n');self.buffer=bytearray(rest)
                self.case.assertLessEqual(len(line),16384);self.pending.append(json.loads(line))
            if any(row.get('event')==kind for row in self.pending):continue
            self.case.assertLess(time.monotonic(),deadline,'No bounded service event '+kind)
            ready,_,_=select.select([self.child.stdout],[],[],.05)
            if ready:
                raw=os.read(self.child.stdout.fileno(),8192)
                self.case.assertTrue(raw,'Service exited before '+kind);self.buffer.extend(raw)
    def send(self,command,**fields):
        row={'v':1,'id':self.next_id,'command':command,**fields};self.next_id+=1
        wire=(json.dumps(row)+'\n').encode();self.case.assertEqual(self.child.stdin.write(wire),len(wire));return row['id']
    def load(self):
        first=self.event('ready');self.case.assertEqual(first['describe']['service_sha256'],hashlib.sha256((HERE/'service_profile.py').read_bytes()).hexdigest())
        self.send('load',frame=0);self.event('accepted')
    def completed(self):
        self.load();self.event('runtime');chunk=self.event('chunk');self.case.assertEqual(chunk['frames'],211)
        raw=json.loads((self.trace/'native-profiler.stdout').read_bytes().splitlines()[0])
        self.case.assertEqual(raw['fixture_parent'],self.child.pid)
        self.case.assertEqual(raw['fixture_group'],self.child.pid,'Native escaped the actual caller-owned service session')
        self.case.assertEqual({p.name for p in (self.job/'service'/'native').iterdir()}, {'input.f32','output.f32','runtime.stderr'})
        self.case.assertLessEqual((self.job/'service'/'native'/'runtime.stderr').stat().st_size,65536)
        self.send('ack',**{k:chunk[k] for k in ('slot','sequence','generation','source_id','model_id')});self.event('accepted')
        self.event('complete');return raw
    def close_request(self):self.send('close');self.event('accepted')
    def summary(self):return json.loads((self.trace/'native-profiler.capture.json').read_text())
    def cleanup(self):
        if self.child.poll() is None:
            try:os.killpg(self.child.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:self.child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try:os.killpg(self.child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                self.child.wait(timeout=2)
        # A broken factory could create a different group; bind the fixture's
        # own PID/start marker before terminating such a retained child.
        marker=self.runtime.with_suffix('.identity.json')
        try:
            row=json.loads(marker.read_text());pid=row['pid']
            current=Path(f'/proc/{pid}/stat').read_text().rsplit(') ',1)[1].split()[19]
            if type(pid) is int and pid>1 and current==row['start_ticks']:os.kill(pid,signal.SIGKILL)
        except (OSError,ValueError,KeyError,IndexError):pass
        for pipe in (self.child.stdin,self.child.stdout,self.child.stderr):pipe.close()
        self.temp.cleanup()


class ActualFactoryChecks(unittest.TestCase):
    def test_wrapper_describe_binds_actual_wrapper_and_original_ROOT(self):
        self.assertEqual(service.__file__,str(HERE/'service_profile.py'))
        self.assertEqual(service.ORIGINAL_ROOT,HERE.parents[3])
        self.assertIs(service.context_capture.ContextNativeRuntime,profile.ProfileNativeRuntime)
        completed=subprocess.run([sys.executable,'-B',str(HERE/'service_profile.py'),'--describe'],capture_output=True,timeout=5,check=True)
        self.assertEqual(json.loads(completed.stdout)['service_sha256'],hashlib.sha256((HERE/'service_profile.py').read_bytes()).hexdigest())
    def test_actual_factory_inherited_group_and_close_local_selector_drains_late_flood(self):
        h=RunningService(self,'normal');raw_ready=h.completed();h.close_request();h.event('closed')
        self.assertEqual(h.child.wait(timeout=5),0)
        summary=h.summary();self.assertTrue(summary['complete']);self.assertTrue(summary['parent_valid'])
        self.assertFalse((h.job/'service'/'native').exists(),'Parent spool cleanup must run before capture completes')
        self.assertEqual(summary['native']['pid'],raw_ready['pid'])
        self.assertEqual(summary['native_shutdown']['exit_code'],0);self.assertTrue(summary['native_shutdown']['graceful_complete'])
        self.assertEqual(summary['errors'],[])
        for name in ('stdout','stderr'):
            stream=summary['streams'][name];raw=(h.trace/('native-profiler.'+name)).read_bytes()
            self.assertTrue(stream['eof']);self.assertEqual(stream['received_bytes'],len(raw));self.assertEqual(stream['written_bytes'],len(raw))
            self.assertEqual(stream['sha256'],hashlib.sha256(raw).hexdigest())
        self.assertEqual(summary['streams']['stderr']['received_bytes'],262144)
        self.assertEqual(len((h.trace/'native-profiler.stdout').read_bytes().splitlines()),2)
        self.assertNotIn(b'q'*4096,h.child.stderr.read(65537),'Native profile must never flood Qt/service stderr')
    def test_real_after_quit_overflow_fails_without_deadlock_or_oversized_file(self):
        h=RunningService(self,'overflow');h.completed();h.close_request()
        self.assertNotEqual(h.child.wait(timeout=5),0)
        summary=h.summary();self.assertFalse(summary['complete'])
        stderr=summary['streams']['stderr'];self.assertTrue(stderr['eof']);self.assertTrue(stderr['overflow'])
        self.assertEqual(stderr['received_bytes'],8388609);self.assertEqual(stderr['written_bytes'],8388608)
        self.assertEqual((h.trace/'native-profiler.stderr').stat().st_size,8388608)
        self.assertTrue(summary['native_shutdown']['process_reaped'])
    def test_real_nonzero_native_exit_remains_failure(self):
        h=RunningService(self,'exit7');h.completed();h.close_request();self.assertNotEqual(h.child.wait(timeout=5),0)
        summary=h.summary();self.assertFalse(summary['complete']);self.assertEqual(summary['native_shutdown']['exit_code'],7)
        self.assertTrue(summary['native_shutdown']['process_reaped'])
    def test_real_request_timeout_keeps_failed_capture_and_reaps(self):
        h=RunningService(self,'hang');h.load();self.assertNotEqual(h.child.wait(timeout=6),0)
        summary=h.summary();self.assertFalse(summary['complete']);self.assertTrue(summary['native_shutdown']['process_reaped'])
        self.assertFalse(summary['native_shutdown']['graceful_complete'])


class FailureChecks(unittest.TestCase):
    def test_stream_close_error_is_incomplete_and_all_owned_descriptors_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            parent=Path(temp);fd=os.open(parent,os.O_RDONLY|os.O_DIRECTORY)
            n=profile.ProfileNativeRuntime.__new__(profile.ProfileNativeRuntime)
            n._profile_trace=SimpleNamespace(parent=parent,parent_fd=fd,_check_parent=lambda:None,mark_failure=Mock(),
                native_shutdown={'graceful_complete':True,'exit_code':0,'process_reaped':True})
            n._profile_run='fixture';n._profile_native={'pid':12,'start_ticks':34};n._closed=True;n._shutdown_deadline=time.monotonic()+2
            n._profile_done=False;n._profile_success=False;n._profile_parent_valid=True;n._profile_errors=[]
            n._profile_fds={};n._profile_rows={};n._profile_hashes={}
            n._profile_summary_fd=os.open(parent/profile.SUMMARY,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            for name,(filename,limit) in profile.STREAMS.items():
                target=os.open(parent/filename,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.write(target,b'x')
                n._profile_fds[name]=target;n._profile_hashes[name]=hashlib.sha256(b'x')
                n._profile_rows[name]={'path':str(parent/filename),'limit_bytes':limit,'received_bytes':1,'written_bytes':1,
                    'sha256':'','eof':True,'overflow':False,'read_errors':0,'write_errors':0,'close_errors':0}
            bad=n._profile_fds['stderr'];real_close=os.close
            def close(descriptor):
                real_close(descriptor)
                if descriptor==bad:raise OSError('synthetic close EIO')
            try:
                with patch.object(profile.os,'close',side_effect=close),self.assertRaises(RuntimeError):n._finish_profile(parent_closed=True)
                summary=json.loads((parent/profile.SUMMARY).read_text())
                self.assertFalse(summary['complete']);self.assertEqual(summary['streams']['stderr']['close_errors'],1)
                for descriptor in n._profile_fds.values():
                    with self.assertRaises(OSError):os.fstat(descriptor)
                with self.assertRaises(RuntimeError):n._finish_profile(parent_closed=True)
            finally:os.close(fd)
    def test_preexisting_raw_capture_never_adopted_or_native_started(self):
        with tempfile.TemporaryDirectory() as temp:
            parent=Path(temp)/'trace';parent.mkdir(mode=0o700);(parent/'native-profiler.stderr').write_bytes(b'preserve')
            fd=os.open(parent,os.O_RDONLY|os.O_DIRECTORY)
            trace=SimpleNamespace(parent=parent,parent_fd=fd,_check_parent=lambda:None,mark_failure=Mock(),native_shutdown=None)
            try:
                with patch('tools.stems.worker.subprocess.Popen') as popen,self.assertRaises(FileExistsError):
                    profile.ProfileNativeRuntime('/not/run','/not/model','vulkan',2,1,spool_directory=Path(temp)/'job'/'service'/'native',
                        max_stderr_bytes=65536,trace_sink=trace,worker=lambda:None,context_run_id='fixture')
                popen.assert_not_called();self.assertEqual((parent/'native-profiler.stderr').read_bytes(),b'preserve')
            finally:os.close(fd)
    def test_write_failure_drains_and_preserves_error_tail(self):
        n=profile.ProfileNativeRuntime.__new__(profile.ProfileNativeRuntime)
        n._profile_trace=SimpleNamespace(mark_failure=Mock());n._profile_errors=[];n._stderr_tail=bytearray()
        n._profile_rows={'stderr':{'limit_bytes':8388608,'received_bytes':0,'written_bytes':0,'write_errors':0,'read_errors':0,'eof':False,'overflow':False}}
        n._profile_fds={'stderr':44};n._profile_hashes={'stderr':hashlib.sha256()}
        pipe=SimpleNamespace(fileno=lambda:12);n.process=SimpleNamespace(stderr=pipe);key=SimpleNamespace(fileobj=pipe);selector=SimpleNamespace(unregister=Mock())
        with patch.object(profile.os,'read',side_effect=[b'raw bytes',b'']),patch.object(profile.os,'write',side_effect=OSError('synthetic disk full')):
            n._tee_read(key,selector);n._tee_read(key,selector)
        self.assertEqual(n._profile_rows['stderr']['received_bytes'],9);self.assertEqual(n._profile_rows['stderr']['written_bytes'],0)
        self.assertEqual(n._profile_rows['stderr']['write_errors'],1);self.assertTrue(n._profile_rows['stderr']['eof'])
        self.assertEqual(n._stderr_tail,b'raw bytes');selector.unregister.assert_called_once_with(pipe)


if __name__=='__main__':unittest.main(verbosity=2)
