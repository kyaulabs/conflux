#!/usr/bin/env python3
"""Verified private service entrypoint; original protocol/worker/C++ player unchanged."""
import hashlib
import importlib.util
import os
from pathlib import Path
import stat
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ORIGINAL=HERE.parent
CONTEXT_SHA='f48908d3966f8c35a8701543e7a1c381bc071690316e014e0bedd82794ece724'
SERVICE_SHA='50f5b94bbcee0ac4087dbd438deb8e1b0532502ad0d770b56bff20a2ff9b5586'
PROFILE_SHA='64afeea9eaccc801d2532459bc386da93e1e006566d4be2efee182d8b1bea1fc'


def _load(name,path,digest):
    if path.resolve(strict=True)!=path:raise ValueError('Canonical private source required')
    fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:
        before=os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or not 0<before.st_size<=1024**2:raise ValueError('Invalid private source')
        raw=bytearray()
        while len(raw)<before.st_size:
            part=os.read(fd,min(65536,before.st_size-len(raw)))
            if not part:raise ValueError('Truncated private source')
            raw.extend(part)
        signature=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        if signature(before)!=signature(os.fstat(fd)) or signature(before)!=signature(path.lstat()) or hashlib.sha256(raw).hexdigest()!=digest:
            raise ValueError('Verified private source changed')
    finally:os.close(fd)
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module


def load_service():
    context=_load('context_capture',ORIGINAL/'context_capture.py',CONTEXT_SHA)
    context._PROFILE_VERIFIED_SHA=CONTEXT_SHA
    profile=_load('native_profile_capture',HERE/'native_profile_capture.py',PROFILE_SHA)
    context.ContextNativeRuntime=profile.ProfileNativeRuntime
    service=_load('private_profile_service',ORIGINAL/'service_drm.py',SERVICE_SHA)
    # Original ROOT/import setup is initialized; runtime public source identity is
    # now the actual launched wrapper for describe() and serve_f32's source pin.
    service.__file__=str(Path(__file__).resolve())
    return service,profile,context


def main():
    service,_profile,_context=load_service()
    return service.main()


if __name__=='__main__':raise SystemExit(main())
