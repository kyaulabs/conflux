#!/usr/bin/env python3
"""Dry by default: fixed baseline profiler PCM16 prerequisite, no UI or playback."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
COMMON = BASE / "profile_launch.py"
# Root fills this only after the common source freeze; no armed run meanwhile.
COMMON_SHA = '9cd3f04f572e85602505f6f3db6c9d01576ea758e9cb9ae563bc7e534a378380'
REQUEST_SECONDS, PROFILE_SECONDS, READINESS_SECONDS, TOTAL_SECONDS, CLEANUP_SECONDS = 30, 60, 195, 300, 45
STDERR_LIMIT, STDOUT_LIMIT = 8 * 1024**2, 128 * 1024


def require(ok,message):
    if not ok:
        raise ValueError(message)


def load_common():
    require(re.fullmatch(r"[0-9a-f]{64}",COMMON_SHA),"Launch common is not frozen; wrapper unarmed")
    fd = os.open(COMMON,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        first = os.fstat(fd)
        require(stat.S_ISREG(first.st_mode) and first.st_uid == os.getuid() and first.st_nlink == 1
                and 0 < first.st_size <= 256*1024,"Unsafe launch common source")
        raw = bytearray()
        while len(raw) < first.st_size:
            block = os.read(fd,min(65536,first.st_size-len(raw)))
            require(block,"Launch common truncated");raw.extend(block)
        signature = lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        require(signature(first) == signature(os.fstat(fd)) == signature(COMMON.lstat())
                and hashlib.sha256(raw).hexdigest() == COMMON_SHA,"Launch common pin changed")
    finally:
        os.close(fd)
    spec = importlib.util.spec_from_file_location("profile_pcm_launch_common",COMMON)
    common = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = common
    exec(compile(bytes(raw),str(COMMON),"exec"),common.__dict__)
    return common


def select_cases(prepared,case_ids):
    require(type(prepared) is list and len(prepared) == len(case_ids) == 16
            and [row.get("id") for row in prepared] == list(case_ids)
            and len(set(case_ids)) == 16,"Prepared exact sixteen-case order/count differs")
    return {row["id"]:row for row in prepared}


def validate_stdout(raw,ready,requests):
    require(type(raw) is bytes and 0 < len(raw) <= STDOUT_LIMIT and raw.endswith(b"\n"),
            "Incomplete bounded native stdout")
    rows = [json.loads(line) for line in raw.splitlines()]
    require(len(rows) == 17 and len(requests) == 16 and all(type(row) is dict for row in rows)
            and rows[0] == {k:v for k,v in ready.items() if k != "process_environment"}
            and rows[0].get("event") == "ready","Raw PCM ready/protocol count differs")
    for request_id,(packet,request) in enumerate(zip(rows[1:],requests,strict=True),1):
        require(packet == request.get("native_metrics") and packet.get("event") == "result"
                and type(packet.get("id")) is int and packet["id"] == request_id
                and type(request.get("request_id")) is int and request["request_id"] == request_id,
                "Raw PCM result packet/request differs")
    return {"passed":True,"events":17,"request_ids":list(range(1,17))}


def finalize_series(report,output,plan,common,deadline):
    require(time.monotonic() < deadline and report.get("cleanup_complete") is True
            and report.get("native_trace",{}).get("passed") is True,
            "Profile parsing requires prior owned cleanup/native validation within original deadline")
    identity = {k:report["native_identity"][k] for k in ("pid","start_ticks")}
    stderr,_ = common.read_file(output/"native.stderr",STDERR_LIMIT,report["native_stderr"])
    stdout,_ = common.read_file(output/"native.stdout",STDOUT_LIMIT,report["native_stdout"])
    native_pin = report["native_trace"]["pin"]
    native,_ = common.read_file(Path(native_pin["path"]),1024**2,native_pin)
    report["stdout_protocol"] = validate_stdout(stdout,report["ready"],report["requests"])
    report["standalone_capture_proof"] = {"schema":1,"kind":"standalone_pcm_capture_v1",
        "run_id":output.name,"native":identity,"capture":report["capture"],
        "native_shutdown":report["native_shutdown"],
        "native_resources_closed":report["cleanup"]["native_resources_closed"],
        "native_stderr":report["native_stderr"],"native_stdout":report["native_stdout"]}
    row = plan["source_pins"]["profile_consumer"]
    require(Path(row["path"]) == common.SOURCES["profile_consumer"],"Fixed series consumer path differs")
    consumer = common.load_module("profile_pcm_series",Path(row["path"]),row["sha256"])
    report["attention_series"] = consumer.parse_series(stderr,stdout,
        capture=report["standalone_capture_proof"],native_bytes=native,native_validation=report["native_trace"],
        run_id=output.name,native_identity=identity)
    require(report["attention_series"].get("passed") is True
            and report["attention_series"].get("request_ids") == list(range(1,17))
            and type(report["attention_series"].get("request_count")) is int
            and report["attention_series"]["request_count"] == 16
            and time.monotonic() < deadline,"Incomplete PCM16 profile or exhausted finalization deadline")


def apply_final_gates(report,case_ids,started,deadline):
    report["finished_monotonic"] = time.monotonic()
    report["elapsed_seconds"] = report["finished_monotonic"]-started
    report["within_wall_budget"] = report["finished_monotonic"] <= deadline
    if not (report["status"] == "passed" and report["cleanup_complete"] and report["pins_unchanged"]
        and report.get("guard_after") == report.get("guard_before") and not report["errors"]
        and not report.get("watchdog_errors") and len(report["requests"]) == 16
        and [row.get("case_id") for row in report["requests"]] == list(case_ids)
        and [row.get("request_id") for row in report["requests"]] == list(range(1,17))
        and all(row.get("completed") is True and row.get("exact_pcm_match") is True for row in report["requests"])
        and report.get("native_trace",{}).get("passed") is True
        and report["native_trace"].get("request_ids") == list(range(1,17))
        and report["within_wall_budget"] and report.get("shader_cache",{}).get("inventory_complete") is True
        and report.get("capture",{}).get("complete") is True
        and report.get("attention_series",{}).get("passed") is True
        and report["attention_series"].get("request_ids") == list(range(1,17))
        and report.get("stdout_protocol",{}).get("passed") is True
        and report.get("native_stderr",{}).get("truncated") is False
        and report.get("native_stdout",{}).get("truncated") is False):
        report["status"] = "interrupted" if report["status"] == "interrupted" else "failed"


def run(player, plan, plan_pin, human, common):
    started = time.monotonic()
    budget = player.operator_budget(human, started, started, phase="pcm")
    deadline = min(started + TOTAL_SECONDS,budget["phase_deadline_monotonic"],budget["operator_deadline_monotonic"])
    before_native = min(started + READINESS_SECONDS,deadline - PROFILE_SECONDS - CLEANUP_SECONDS)
    support = common.support()
    output = player.PCM_OUTPUT
    output.mkdir(mode=0o700)
    admission = output / "admission"
    admission.mkdir(mode=0o700)
    trace_directory = output / player.TRACE_DIRECTORY_NAME
    trace_directory.mkdir(mode=0o700)
    report = {"schema":1,"status":"checking","mode":player.MODE,"qualified":False,"timing_qualification":False,
        "started_at_utc":datetime.now(timezone.utc).isoformat(),"started_monotonic":started,
        "boot_id":player.boot_identity(),"plan_pin":plan_pin,"human_pin":human["pin"],
        "source_head":plan["source_head"],"candidate_runtime":plan["assets"]["runtime"],"model":plan["assets"]["model"],
        "reference_runtime_sha256":player.FLASH_RUNTIME_SHA256,"operator_budget":budget,
        "requests":[],"errors":[],"pins_before":{},"pins_after":{},"pins_unchanged":False,
        "cleanup_complete":False,"cleanup":{},"native_started":False,"UI_load":False,"audio_load":False,
        "request_timeout_seconds":REQUEST_SECONDS,"profile_seconds":PROFILE_SECONDS,
        "readiness_seconds":READINESS_SECONDS,"cleanup_reserve_seconds":CLEANUP_SECONDS,"maximum_seconds":TOTAL_SECONDS}
    native = readiness_child = lock = helper = original = comparison = pcm_admission = admission_helper = None
    initialized = False
    handlers = {}
    specs = {}
    watchdog_stop, watchdog = threading.Event(), None
    watchdog_started = False
    watchdog_errors = []
    constructing = False
    def checkpoint():
        player.save(output / "result.json",report)
    def interrupted(signum,_frame):
        report["interruption_signal"] = signum
        if not constructing:
            raise KeyboardInterrupt
    def ac_lid(label):
        state = admission_helper.ac_lid()
        report.setdefault("AC_lid",[]).append({"phase":label,**state})
        player.require_trace(state["ready"], "AC/lid readiness changed: " + label)
    try:
        handlers = {sig:signal.signal(sig,interrupted) for sig in (signal.SIGINT,signal.SIGTERM)}
        checkpoint()
        player.verify_plan_files(plan,before_native)
        player.validate_build_result(plan)
        player.require_trace(player.read_command(["git","-C",str(player.SOURCE_ROOT),"rev-parse","HEAD"]) == plan["source_head"],
                             "PCM source HEAD differs")
        original = player.load_frozen_module("pcm_original",player.ORIGINAL_PCM,player.ORIGINAL_PCM_SHA256)
        for name,(path,digest) in original.HELPERS.items():
            player.require_trace(path.is_file() and path.stat().st_size <= 128*1024
                and hashlib.sha256(path.read_bytes()).hexdigest() == digest,"Original PCM helper changed: " + name)
        comparison = original.load("comparison",original.HELPERS["comparison"][0])
        comparison.DIAGNOSTIC = Path(plan["assets"]["runtime"]["path"])
        retained = original.load("retained",original.HELPERS["retained"][0])
        specs = support.original_specs(plan,player,original,comparison,retained)
        report["pins_before"] = support.capture_plan_pins(plan,player,comparison,specs,before_native)
        proof,reference_pin = player.bounded_json(player.REFERENCE)
        player.require_trace(reference_pin["sha256"] == player.REFERENCE_SHA256,"Immutable baseline proof changed")
        expected = original.validate_reference(proof,player.FLASH_MODEL_SHA256)
        np, _UnusedNativeRuntime, prepared = comparison.prepare_cases(comparison.load_track_plan(before_native),before_native)
        cases = select_cases(prepared,player.PCM_CASE_IDS)
        capture_pin = plan["source_pins"]["standalone_capture"]
        player.require_trace(Path(capture_pin["path"]) == common.SOURCES["standalone_capture"],"Fixed standalone capture path differs")
        capture_module = player.load_frozen_module("profile_pcm_capture",Path(capture_pin["path"]),capture_pin["sha256"])
        NativeRuntime = capture_module.CapturedNativeRuntime
        for case_id,case in cases.items():
            player.require_trace(all(case[k] == expected[case_id][k] for k in
                ("input_sha256","shape","dtype","valid_frames","normalization")),"Exact normalized input differs: " + case_id)
        report["cases"] = [{k:v for k,v in cases[key].items() if k != "samples"} for key in player.PCM_CASE_IDS]
        helper,_ = player.load_cache_support()
        lock = helper.acquire_cache_lock(helper.capture_cache_parent(),before_native)
        seed,seed_pin = player.bounded_json(Path(plan["seed_proof"]["path"]))
        player.require_trace(seed_pin["sha256"] == plan["seed_proof"]["sha256"] and seed.get("cleanup_proven") is True
            and seed.get("pins_unchanged") is True and seed.get("shader_cache",{}).get("inventory_complete") is True
            and seed["shader_cache"]["post"]["manifest_sha256"] == plan["seed_manifest_sha256"],"Immutable seed proof differs")
        report["shader_cache"] = helper.prepare_phase("pcm",seed["shader_cache"]["post"],before_native)
        # All substantial CPU reads precede the unchanged sampled-cool admission.
        report["full_hashes_before_readiness"] = support.capture_plan_pins(plan,player,comparison,specs,before_native)
        player.require_trace(report["full_hashes_before_readiness"] == report["pins_before"],"PCM setup changed planned pins")
        admission_helper = original.load("admission",retained.HELPERS["admission_source"][0])
        admission_helper.readiness_module()
        pcm_admission = original.load("pcm_admission",original.HELPERS["pcm_admission"][0])
        ac_lid("before_readiness")
        report["guard_before"] = player.guard_identity(Path(plan["assets"]["guard_script"]["path"]),Path(plan["assets"]["guard_unit"]["path"]))
        command = [plan["assets"]["python"]["path"],"-B","-c",
            "import runpy,sys;from pathlib import Path;sys.exit(runpy.run_path(sys.argv[1])['run']('admission',Path(sys.argv[2])))",
            str(original.HELPERS["pcm_admission"][0]),str(admission)]
        report["readiness_command"] = command
        with (admission / "stdout").open("x") as out,(admission / "stderr").open("x") as err:
            constructing = True
            try:
                readiness_child = subprocess.Popen(command,cwd=player.SOURCE_ROOT,stdout=out,stderr=err,start_new_session=True)
                report["readiness_identity"] = original.process_identity(readiness_child.pid,command)
            finally:
                constructing = False
            if "interruption_signal" in report:
                raise KeyboardInterrupt
            next_ac = 0
            while readiness_child.poll() is None:
                comparison.check_deadline(before_native)
                if time.monotonic() >= next_ac:
                    ac_lid("readiness")
                    next_ac = time.monotonic() + 45
                time.sleep(.25)
            player.require_trace(readiness_child.wait() == 0,"Original guarded PCM readiness failed")
        original.verify_pinned_metadata(comparison,report["full_hashes_before_readiness"],before_native)
        current_human = player.readiness(player.HUMAN,plan_pin)
        player.require_trace(current_human["pin"] == human["pin"],"Original combined approval changed")
        pcm_admission.validate_proof(json.loads((admission / "admission-pcm-ready.json").read_text()))
        report["admission"] = pcm_admission.fresh_admission(admission,admission_helper.ac_lid,before_native)
        player.require_trace(report["admission"].get("qualified") is False
            and report["admission"].get("admission_mode") == original.ADMISSION_MODE,"PCM admission scope differs")
        player.require_trace(player.guard_identity(Path(plan["assets"]["guard_script"]["path"]),Path(plan["assets"]["guard_unit"]["path"])) == report["guard_before"],"Guard changed before candidate launch")
        profile_started = time.monotonic()
        profile_deadline = min(deadline-CLEANUP_SECONDS,profile_started+PROFILE_SECONDS)
        environment = player.logger_environment(helper.cache_environment(os.environ,"pcm"))
        environment.update({player.TRACE_ENV_KEYS[0]:str(trace_directory / player.NATIVE_TRACE_NAME),
                            player.TRACE_ENV_KEYS[1]:output.name})
        changed = {k:v for k,v in environment.items() if os.environ.get(k) != v}
        saved = {k:os.environ.get(k) for k in changed}
        constructing = True
        report["native_construction_attempted"] = True
        try:
            try:
                os.environ.update(changed)
                native = NativeRuntime.__new__(NativeRuntime)
                NativeRuntime.__init__(native,comparison.DIAGNOSTIC,comparison.MODEL,"vulkan",2,
                    min(REQUEST_SECONDS,comparison.check_deadline(profile_deadline)),passive_openmp=True,
                    spool_directory=output / "native-spool",max_stderr_bytes=STDERR_LIMIT)
                initialized = True
            finally:
                for key,value in saved.items():
                    if value is None: os.environ.pop(key,None)
                    else: os.environ[key] = value
        finally:
            constructing = False
            report["native_started"] = getattr(native,"process",None) is not None
            report["native_construction_completed"] = initialized
        if "interruption_signal" in report:
            raise KeyboardInterrupt
        report["native_identity"] = original.process_identity(native.process.pid,
            [str(comparison.DIAGNOSTIC),"--model",str(comparison.MODEL),"--backend","vulkan","--threads","2"])
        def watch_native():
            while not watchdog_stop.wait(.05):
                try:
                    comparison.check_deadline(profile_deadline)
                    player.require_trace(not native.capture["overflow"] and not native.capture["read_errors"]
                        and not native.capture["write_errors"],"Native full capture failed")
                except Exception as error:
                    watchdog_errors.append(str(error));native.abort();return
        watchdog = threading.Thread(target=watch_native,name="drm-pcm-deadline",daemon=True)
        watchdog.start()
        watchdog_started = True
        ready = native.start()
        report["ready"] = ready
        player.require_trace(ready.get("backend") == "vulkan" and ready.get("threads") == 2
            and ready.get("pid") == native.process.pid and ready.get("fence_wait_mode") == "blocking"
            and ready.get("weight_storage") == "native" and ready.get("revision") == comparison.REVISION
            and ready.get("model") == str(comparison.MODEL)
            and ready.get("process_environment") == {"OMP_WAIT_POLICY":"PASSIVE","GOMP_SPINCOUNT":"0"},"Candidate ready context differs")
        for request_id,case_id in enumerate(player.PCM_CASE_IDS,1):
            ac_lid("before_request_" + str(request_id))
            native.timeout = min(REQUEST_SECONDS,comparison.check_deadline(profile_deadline))
            row = {"request_id":request_id,"case_id":case_id,"completed":False}
            report["requests"].append(row);checkpoint()
            try:
                produced,metrics = native.infer(cases[case_id]["samples"],request_id)
                player.require_trace(not watchdog_errors,"Native watchdog failed")
                for key in comparison.COMMON_TIMINGS+comparison.PHASE_TIMINGS:
                    comparison.validate_number(metrics,key)
                for key in comparison.SWITCH_COUNTS:
                    comparison.validate_number(metrics,key,integral=True)
                player.require_trace(produced.shape == (4,343980,2) and produced.dtype.str == "<f4"
                    and produced.flags.c_contiguous and np.isfinite(produced).all(),"Candidate PCM geometry/finite contract differs")
                input_pin,_ = comparison.inspect_file(native.root / "input.f32",343980*8,profile_deadline,
                    expected=expected[case_id]["input_sha256"])
                digest = hashlib.sha256(memoryview(produced)).hexdigest()
                original.verify_output_digest(digest,expected[case_id],case_id)
                row.update(input_sha256=input_pin["sha256"],output_sha256=digest,output_shape=list(produced.shape),
                    output_dtype=produced.dtype.str,output_bytes=produced.nbytes,completed=True,exact_pcm_match=True,
                    native_metrics=metrics)
                produced = None
            finally:
                original.cleanup_request(native,row);checkpoint()
            ac_lid("after_request_" + str(request_id))
        watchdog_stop.set();watchdog.join(timeout=min(2,comparison.check_deadline(deadline)))
        report["native_shutdown"] = native.idle_quit(completed_idle=True,deadline=min(deadline-15,time.monotonic()+2))
        player.require_trace(report["native_shutdown"]["graceful_complete"] is True,"Candidate did not quit/reap within original2s")
        report["capture"],captured = support.retain_captures(native,output,min(deadline-10,time.monotonic()+2))
        report["native_stderr"],report["native_stdout"] = captured["stderr"],captured["stdout"]
        player.require_trace(report["capture"]["complete"],"Native full capture incomplete")
        report["status"] = "passed"
    except KeyboardInterrupt:
        report["status"] = "interrupted"
    except Exception as error:
        report["status"] = "failed";report["errors"].append({"type":type(error).__name__,"message":str(error)[:8192]})
    finally:
        for sig in handlers:
            signal.signal(sig,signal.SIG_IGN)
        watchdog_stop.set()
        if watchdog_started:
            watchdog.join(timeout=max(0,min(2,deadline-time.monotonic())))
        report["watchdog_errors"] = watchdog_errors
        if readiness_child is not None:
            try:
                if readiness_child.poll() is None:
                    try: os.killpg(readiness_child.pid,signal.SIGKILL)
                    except ProcessLookupError: pass
                readiness_child.wait(timeout=max(0,min(3,deadline-time.monotonic())))
                report["cleanup"]["readiness_reaped"] = True
                report["cleanup"]["readiness_original_identity_absent"] = original.original_identity_absent(report["readiness_identity"])
            except Exception as error:
                report["errors"].append({"phase":"readiness_cleanup","message":str(error)})
        if native is not None and original is not None:
            try:
                captured = {k:report["native_"+k] for k in ("stderr","stdout") if "native_"+k in report}
                cleanup,stderr,errors,captured = support.cleanup_captured(native,initialized,output,original,deadline,captured)
                if hasattr(native,"capture"): report["capture"] = native.capture_status()
                for key,value in captured.items(): report["native_"+key] = value
                report["cleanup"].update(cleanup);report["errors"].extend(errors)
                if stderr is not None: report["native_stderr"] = stderr
                if "native_identity" in report:
                    report["cleanup"]["native_original_identity_absent"] = original.original_identity_absent(report["native_identity"])
                    identity = report["native_identity"]
                    player.require_trace(identity["pid"] == identity["group"] == identity["session"],"Owned native session identity differs")
                    try:
                        os.killpg(identity["pid"],0)
                        report["cleanup"]["native_owned_group_absent"] = False
                    except ProcessLookupError:
                        report["cleanup"]["native_owned_group_absent"] = True
            except Exception as error:
                report["errors"].append({"phase":"native_cleanup","message":str(error)})
        report["cleanup"]["watchdog_joined"] = watchdog is None or not watchdog.is_alive()
        try:
            if specs:
                report["pins_after"] = support.capture_plan_pins(plan,player,comparison,specs,deadline,verify=False)
                report["pins_unchanged"] = report["pins_before"] == report["pins_after"]
            if "guard_before" in report:
                report["guard_after"] = player.guard_identity(Path(plan["assets"]["guard_script"]["path"]),Path(plan["assets"]["guard_unit"]["path"]))
            player.require_trace(player.read_command(["git","-C",str(player.SOURCE_ROOT),"rev-parse","HEAD"]) == plan["source_head"],"PCM source HEAD changed")
            if helper is not None and "shader_cache" in report:
                prepared = report["shader_cache"]
                report["shader_cache"]["post"] = helper.inventory(Path(prepared["cache_path"]),prepared["parent"],deadline,prepared["cache_identity"])
                report["shader_cache"]["inventory_complete"] = True
            if initialized and report.get("native_shutdown",{}).get("graceful_complete"):
                row = plan["source_pins"]["trace_validator"]
                validator = player.load_frozen_module("trace_validation",Path(row["path"]),row["sha256"])
                identity = {k:report["native_identity"][k] for k in ("pid","start_ticks")}
                report["native_trace"] = validator.native_trace(trace_directory / player.NATIVE_TRACE_NAME,
                    run_id=output.name,native_identity=identity,exit_code=report["native_shutdown"]["exit_code"],
                    deadline=deadline,expected_device=plan["drm_device"])
                player.require_trace(report["native_trace"]["request_ids"] == list(range(1,17)),"Candidate trace does not cover all16cases")
        except Exception as error:
            report["errors"].append({"phase":"finalization","message":str(error)})
        finally:
            if lock is not None:
                try:
                    lock.close()
                except Exception as error:
                    report["errors"].append({"phase":"cache_lock_close","message":str(error)})
        cleanup = report["cleanup"]
        report["cleanup_complete"] = all(cleanup.get(k) is True for k in ("native_reaped","native_resources_closed",
            "temporary_directory_removed","native_original_identity_absent","readiness_reaped",
            "readiness_original_identity_absent","watchdog_joined","native_owned_group_absent"))
        if report.get("native_trace",{}).get("passed") is True and report["cleanup_complete"]:
            try:
                finalize_series(report,output,plan,common,deadline)
            except Exception as error:
                report["errors"].append({"phase":"profile_finalization","message":str(error)[:8192]})
        apply_final_gates(report,player.PCM_CASE_IDS,started,deadline)
        report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        checkpoint()
        for sig,handler in handlers.items():
            signal.signal(sig,handler)
    return 0 if report["status"] == "passed" else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run",action="store_true")
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({"status":"unarmed_dry_plan","host_queried":False,"native_started":False,
            "cases":16,"maximum_seconds":300,"combined_original_seconds":960,
            "player_requires_new_exact_PCM_proof":True,"requires_full_profile_of_all16":True}))
        return 0
    common = load_common()
    plan,plan_pin = common.load_plan()
    human = common.readiness(common.HUMAN,plan_pin)
    player = common.load_player(plan)
    return run(player,plan,plan_pin,human,common)


if __name__ == "__main__":
    raise SystemExit(main())
