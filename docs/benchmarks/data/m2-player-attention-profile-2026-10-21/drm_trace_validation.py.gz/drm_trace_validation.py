"""Bounded passive DRM JSONL validation. No process/hardware queries or imports."""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time


def require(value, message):
    if not value:
        raise RuntimeError(message)


def decimal(value, *, maximum=(1 << 64) - 1):
    require(type(value) is str and re.fullmatch(r"0|[1-9][0-9]{0,19}", value)
            and int(value) <= maximum, "Invalid decimal-string native counter/identity")
    return int(value)


def read_records(path, *, byte_limit, line_limit, row_limit, deadline):
    require(time.monotonic() < deadline, "Original trace validation deadline exhausted")
    path = Path(path)
    parent = path.parent
    parent_fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    descriptor = None
    signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    try:
        directory = os.fstat(parent_fd)
        require(stat.S_ISDIR(directory.st_mode) and directory.st_uid == os.getuid()
                and stat.S_IMODE(directory.st_mode) == 0o700
                and (parent.lstat().st_dev, parent.lstat().st_ino) == (directory.st_dev, directory.st_ino),
                "Trace parent is not the original owned0700 directory")
        descriptor = os.open(path.name, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent_fd)
        before = os.fstat(descriptor)
        require(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid() and before.st_nlink == 1
                and stat.S_IMODE(before.st_mode) == 0o600 and 0 < before.st_size <= byte_limit,
                "Unsafe or oversized private trace")
        raw = bytearray()
        while len(raw) < before.st_size:
            require(time.monotonic() < deadline, "Original trace validation deadline exhausted")
            block = os.read(descriptor, min(65536, before.st_size - len(raw)))
            require(bool(block), "Private trace truncated")
            raw.extend(block)
        require(signature(before) == signature(os.fstat(descriptor))
                == signature(os.stat(path.name, dir_fd=parent_fd, follow_symlinks=False))
                and (parent.lstat().st_dev, parent.lstat().st_ino) == (directory.st_dev, directory.st_ino),
                "Private trace changed during validation")
        final_directory = os.fstat(parent_fd)
        require(final_directory.st_uid == os.getuid() and stat.S_IMODE(final_directory.st_mode) == 0o700,
                "Trace parent ownership/mode changed")
    finally:
        if descriptor is not None:
            os.close(descriptor)
        os.close(parent_fd)
    lines = raw.splitlines(keepends=True)
    require(2 <= len(lines) <= row_limit and all(line.endswith(b"\n") and len(line) <= line_limit for line in lines),
            "Private trace line/count/completion bound differs")
    def unique(pairs):
        row = {}
        for key, value in pairs:
            require(key not in row, "Duplicate private trace JSON key")
            row[key] = value
        return row
    records = [json.loads(line, object_pairs_hook=unique,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite private JSON"))) for line in lines]
    require(all(type(row) is dict for row in records) and time.monotonic() < deadline,
            "Invalid private trace object or expired original budget")
    return records, {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                     "identity": list(signature(before))}


NATIVE_SCHEMA = 2
NATIVE_MODE = "passive_drm_owned_client_set_v1"
LIMITS = {"fd_bytes": 16384, "fd_entries": 128, "character_candidates": 16, "engines": 8,
          "requests": 64, "physical_rows": 82, "record_bytes": 16384, "file_bytes": 1048576,
          "footer_reason_bytes": 512}


def native_trace(path, *, run_id, native_identity, exit_code, deadline, expected_device):
    records, pinned = read_records(path, byte_limit=LIMITS["file_bytes"], line_limit=LIMITS["record_bytes"],
                                   row_limit=LIMITS["physical_rows"], deadline=deadline)
    require(type(native_identity) is dict and set(native_identity) == {"pid", "start_ticks"}
            and all(type(v) is int and v > 0 for v in native_identity.values())
            and type(exit_code) is int and exit_code == 0,
            "Native trace requires exact owned identity and observed exit0")
    for row in records:
        require(type(row.get("schema")) is int and row["schema"] == NATIVE_SCHEMA
                and row.get("mode") == NATIVE_MODE and row.get("run_id") == run_id and row.get("freshness") == "unknown"
                and decimal(row.get("native_pid")) == native_identity["pid"]
                and decimal(row.get("start_ticks")) == native_identity["start_ticks"] and "error" not in row,
                "Native trace run/lifetime/freshness differs")
    candidates = []
    while len(candidates) < len(records) and records[len(candidates)].get("event") == "discovery_candidate":
        candidates.append(records[len(candidates)])
    require(1 <= len(candidates) <= 16 and len(records) >= len(candidates) + 3,
            "Complete bounded initial client inventory is required")
    header, footer = records[len(candidates)], records[-1]
    require(header.get("event") == "setup" and header.get("backend") == "vulkan"
            and type(header.get("threads")) is int and header["threads"] == 2
            and header.get("fence_wait_mode") == "blocking" and header.get("limits") == LIMITS
            and all(type(header["limits"].get(key)) is int for key in LIMITS)
            and footer.get("event") == "footer" and footer.get("status") == "complete"
            and footer.get("reason") == "" and decimal(footer.get("reason_bytes")) == 0
            and footer.get("reason_truncated") is False,
            "Native trace setup/footer is incomplete")
    reservation = header.get("reservation", {})
    require(type(reservation) is dict and set(reservation) == {"request_row_max_bytes", "footer_max_bytes"}
            and all(type(v) is int and 0 < v <= LIMITS["record_bytes"] for v in reservation.values()),
            "Native full-set serialization reservation is invalid")
    encoded_size = lambda row: len(json.dumps(row, separators=(",", ":"), ensure_ascii=True).encode()) + 1
    require(encoded_size(footer) <= reservation["footer_max_bytes"], "Native footer exceeds reserved size")
    inventory = header.get("inventory")
    def check_inventory(value):
        require(type(value) is dict and set(value) == {"candidate_count", "fd_enumeration_complete", "candidate_scan_complete"}
                and type(value.get("candidate_count")) is int and value["candidate_count"] == len(candidates)
                and value.get("fd_enumeration_complete") is True and value.get("candidate_scan_complete") is True,
                "Initial native inventory is partial or mistyped")
    check_inventory(inventory)
    bound = None
    last_end = 0
    def fields(client):
        require(type(client) is dict and client.get("driver") == expected_device["driver"]
                and client.get("pdev") == expected_device["pdev"], "Native DRM device differs")
        owner = (client["driver"], client["pdev"], decimal(client.get("rdev")), decimal(client.get("client_id")))
        fd = decimal(client.get("fd"), maximum=2147483647)
        engines = client.get("engines")
        require(type(engines) is dict and 1 <= len(engines) <= 8, "Native engine coverage missing/oversized")
        values = {}
        for name, value in engines.items():
            require(type(name) is str and re.fullmatch(r"[A-Za-z0-9_.:-]{1,48}", name)
                    and type(value) is dict and set(value) == {"ns", "capacity"}, "Invalid native engine fields")
            values[name] = (decimal(value["ns"]), decimal(value["capacity"]))
            require(values[name][1] > 0, "Native engine capacity is zero")
        return owner, fd, values

    def snapshot(item):
        nonlocal bound, last_end
        require(type(item) is dict and item.get("status") == "observed" and item.get("reason") == "",
                "Native counter snapshot is inconclusive")
        require(item.get("fd_enumeration_complete") is True and item.get("candidate_scan_complete") is True,
                "Native boundary enumeration or candidate scan is incomplete")
        begin, end = decimal(item.get("read_begin_ns")), decimal(item.get("read_end_ns"))
        require(last_end <= begin <= end, "Native snapshot read brackets overlap/regress")
        last_end = end
        clients = item.get("clients")
        require("client" not in item and type(clients) is list and 1 <= len(clients) <= 16,
                "Native full client set is missing/oversized or scalar")
        values, shape, brackets, all_fds = {}, {}, [], set()
        order = []
        for client in clients:
            owner, fd, counters = fields(client)
            aliases = client.get("alias_fds")
            require(client.get("alias_policy") == "fixed_lowest_fd_per_owner_not_summed"
                    and type(aliases) is list and 1 <= len(aliases) <= 16, "Native alias membership missing/oversized")
            aliases = tuple(decimal(v, maximum=2147483647) for v in aliases)
            require(aliases == tuple(sorted(set(aliases))) and aliases[0] == fd
                    and not all_fds.intersection(aliases), "Native alias membership/representative is invalid")
            all_fds.update(aliases)
            read_begin, read_end = decimal(client.get("read_begin_ns")), decimal(client.get("read_end_ns"))
            require(begin <= read_begin <= read_end <= end, "Representative read lies outside global bracket")
            brackets.append((read_begin, read_end))
            require(owner not in values, "Duplicate native DRM owner")
            values[owner] = counters
            shape[owner] = (fd, aliases, {name: value[1] for name, value in counters.items()})
            order.append(owner)
        require(len(all_fds) <= 16 and order == sorted(order), "Native client set order/count differs")
        ordered_brackets = sorted(brackets)
        require(all(a[1] <= b[0] for a, b in zip(ordered_brackets, ordered_brackets[1:])),
                "Representative read brackets overlap")
        if bound is None:
            bound = shape
        require(shape == bound, "Native owner/alias/representative/engine capacity set changed")
        return begin, end, values
    setup_begin, setup_end, setup_values = snapshot(header.get("snapshot"))
    raw_by_owner, raw_by_fd = {}, {}
    last_candidate_end = setup_begin
    for ordinal, candidate in enumerate(candidates, 1):
        check_inventory(candidate.get("inventory"))
        require(candidate["inventory"] == inventory and type(candidate.get("ordinal")) is int
                and candidate["ordinal"] == ordinal and candidate.get("fd_identity_stable") is True,
                "Initial candidate order/stability differs")
        begin, end = decimal(candidate.get("read_begin_ns")), decimal(candidate.get("read_end_ns"))
        require(last_candidate_end <= begin <= end <= setup_end, "Initial candidate brackets overlap/regress")
        last_candidate_end = end
        raw = candidate.get("client")
        owner, fd, counters = fields(raw)
        require(raw.get("alias_policy") == "raw_per_fd_not_selected_or_summed" and fd not in raw_by_fd,
                "Initial candidate alias policy/FD differs")
        raw_by_fd[fd] = (owner, counters, begin, end)
        raw_by_owner.setdefault(owner, []).append(fd)
    require(set(raw_by_owner) == set(bound), "Setup drops or invents an initial DRM owner")
    for owner, (fd, aliases, shape) in bound.items():
        require(tuple(sorted(raw_by_owner[owner])) == aliases
                and all({name: value[1] for name, value in raw_by_fd[alias][1].items()} == shape for alias in aliases)
                and raw_by_fd[fd][1] == setup_values[owner], "Setup alias shape or raw representative differs")
        selected = next(c for c in header["snapshot"]["clients"] if fields(c)[0] == owner)
        require((decimal(selected["read_begin_ns"]), decimal(selected["read_end_ns"])) == raw_by_fd[fd][2:],
                "Setup representative bracket differs from retained raw candidate")
    history, requests = {}, []
    for row in records[len(candidates)+1:-1]:
        require(row.get("event") == "inference" and row.get("status") == "returned",
                "Native inference trace is failed/inconclusive")
        require(encoded_size(row) <= reservation["request_row_max_bytes"], "Native request exceeds reserved size")
        request_id = decimal(row.get("request_id"), maximum=(1 << 53) - 1)
        require(request_id == len(requests) + 1 and request_id <= 64, "Native request sequence/count differs")
        _, before_end, before = snapshot(row.get("before"))
        after_begin, _, after = snapshot(row.get("after"))
        call_begin, call_end = decimal(row.get("call_begin_ns")), decimal(row.get("call_end_ns"))
        require(before_end <= call_begin <= call_end <= after_begin, "Native call/read brackets differ")
        accounting = row.get("accounting")
        require(type(accounting) is list and len(accounting) == len(bound), "Native accounting client coverage differs")
        for owner, entry in zip(bound, accounting):
            require(type(entry) is dict and set(entry) == {"driver", "pdev", "rdev", "client_id", "engines"}
                    and (entry.get("driver"), entry.get("pdev"), decimal(entry.get("rdev")),
                         decimal(entry.get("client_id"))) == owner, "Native accounting owner/order differs")
            engines = entry["engines"]
            require(type(engines) is dict and set(engines) == set(bound[owner][2]), "Native accounting engines differ")
            for name in bound[owner][2]:
                a, b = before[owner][name][0], after[owner][name][0]
                key = (owner, name)
                prior = key in history
                first, previous, high, ever = history.get(key, (a, a, a, False))
                regressed = a < high or b < a
                ever = ever or regressed
                expected = {"within_call_delta_ns": str(b-a) if not regressed else None,
                    "between_call_delta_ns": str(a-previous) if prior and a >= high and previous >= high else None,
                    "cumulative_delta_ns": str(b-first) if not ever and b >= first else None,
                    "high_water_ns": str(max(high, a, b)), "regressed_or_below_high_water": regressed}
                require(type(engines[name]) is dict and type(engines[name].get("regressed_or_below_high_water")) is bool
                        and engines[name] == expected, "Per-client accounting differs from raw counter arithmetic")
                history[key] = (first, b, max(high, a, b), ever)
        requests.append(request_id)
    require(bool(requests) and time.monotonic() < deadline, "No native requests or expired validation budget")
    return {"passed": True, "qualified": False, "pin": pinned, "native": native_identity,
            "native_schema": NATIVE_SCHEMA, "native_mode": NATIVE_MODE,
            "request_ids": requests, "completed_requests": len(requests),
            "clients": [{"driver": owner[0], "pdev": owner[1], "rdev": str(owner[2]), "client_id": str(owner[3]),
                         "fd": str(value[0]), "alias_fds": [str(fd) for fd in value[1]], "engines": value[2]}
                        for owner, value in bound.items()], "freshness": "unknown",
            "scope": "Separate raw accounting for every observed bound client/engine; no sums, queue attribution or idle classification"}
