"""Offline behavioral and failure checks; no native player/model/audio starts."""
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('qml_capture_tests', Path(__file__).resolve().parents[1] / 'qml_capture.py')
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)


class CaptureTests(unittest.TestCase):
    def fixture(self, root):
        return capture.QmlCapture({'port':43385, 'capture_seconds':30}, ['/native','--fixture'], root/'profile', 200)

    def test_wrong_command_fails_before_launch(self):
        with tempfile.TemporaryDirectory() as name, patch.object(capture.subprocess, 'Popen') as popen:
            value = self.fixture(Path(name))
            with self.assertRaisesRegex(ValueError, 'exact native'):
                value.popen(['/other'])
            popen.assert_not_called()

    def test_existing_capture_directory_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as name, patch.object(capture.subprocess, 'Popen') as popen:
            value = self.fixture(Path(name)); value.directory.mkdir()
            with patch.object(capture.time, 'monotonic', return_value=100), self.assertRaisesRegex(ValueError, 'Fresh profiler'):
                value.popen(value.expected_command, start_new_session=True, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            popen.assert_not_called()

    def test_launch_without_owned_session_or_captured_pipes_is_rejected(self):
        with tempfile.TemporaryDirectory() as name, patch.object(capture.subprocess, 'Popen') as popen:
            value = self.fixture(Path(name))
            for options in ({}, {'start_new_session':False}, {'start_new_session':True,'stdout':None}):
                with self.subTest(options=options), self.assertRaisesRegex(ValueError, 'launch contract'):
                    value.popen(value.expected_command, **options)
            popen.assert_not_called()

    def test_attach_timeout_reaps_the_unreturned_native_handle(self):
        with tempfile.TemporaryDirectory() as name:
            value=self.fixture(Path(name));clock=[100.]
            native=SimpleNamespace(pid=15,returncode=None,stdout=io.BytesIO(),stderr=io.BytesIO())
            native.poll=lambda:native.returncode
            def wait(timeout):native.returncode=-9;return -9
            native.wait=wait
            with (patch.object(capture.subprocess,'Popen',return_value=native),
                  patch.object(capture.time,'monotonic',side_effect=lambda:clock[0]),
                  patch.object(capture.time,'sleep',side_effect=lambda s:clock.__setitem__(0,clock[0]+s)),
                  patch.object(capture,'listener_owned',return_value=False),
                  patch.object(capture.os,'killpg') as kill):
                with self.assertRaisesRegex(TimeoutError,'within 8 seconds'):
                    value.popen(value.expected_command,start_new_session=True,stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            self.assertEqual(native.returncode,-9)
            self.assertTrue(native.stdout.closed and native.stderr.closed)
            kill.assert_called_once_with(15,capture.signal.SIGKILL)

    def proc(self, root, address='0100007F', inode='1234', fd_inode='1234'):
        (root/'15/fd').mkdir(parents=True)
        (root/'15/fd/4').symlink_to('socket:['+fd_inode+']')
        (root/'net').mkdir()
        (root/'net/tcp').write_text('header\n 0: '+address+':A979 00000000:0000 0A 0 0 0 '+str(os.getuid())+' 0 '+inode+'\n')
        return root

    def test_only_the_targets_loopback_socket_is_admitted(self):
        with tempfile.TemporaryDirectory() as name:
            root=self.proc(Path(name)); self.assertTrue(capture.listener_owned(15,43385,root))
            self.assertFalse(capture.listener_owned(15,43386,root))
        with tempfile.TemporaryDirectory() as name:
            root=self.proc(Path(name),fd_inode='other')
            self.assertFalse(capture.listener_owned(15,43385,root))

    def test_wildcard_listener_is_rejected(self):
        with tempfile.TemporaryDirectory() as name:
            root=self.proc(Path(name),address='00000000')
            with self.assertRaisesRegex(ValueError, 'loopback only'):
                capture.listener_owned(15,43385,root)

    def test_descriptor_bound_prevents_unbounded_scan(self):
        with tempfile.TemporaryDirectory() as name:
            root=self.proc(Path(name))
            for index in range(5,1030): (root/'15/fd'/str(index)).symlink_to('socket:[1234]')
            with self.assertRaisesRegex(ValueError, 'descriptor bound'):
                capture.listener_owned(15,43385,root)

    def test_flush_happens_once_and_does_not_stop_the_native_player(self):
        with tempfile.TemporaryDirectory() as name:
            value=self.fixture(Path(name)); value.directory.mkdir()
            for suffix in ('stdout','stderr'): (value.directory/('client.'+suffix)).touch()
            value.child=SimpleNamespace(poll=lambda:None,stdin=io.BytesIO())
            value.started=100
            with patch.object(capture.time,'monotonic',return_value=129):value.monitor()
            self.assertEqual(value.child.stdin.getvalue(),b'')
            with patch.object(capture.time,'monotonic',return_value=131):value.monitor();value.monitor()
            self.assertEqual(value.child.stdin.getvalue(),b'flush\n')
            self.assertTrue(value.receipt['early_flush_sent'])

    def test_profiler_failure_is_reported_instead_of_ignored(self):
        with tempfile.TemporaryDirectory() as name:
            value=self.fixture(Path(name));value.directory.mkdir()
            value.child=SimpleNamespace(poll=lambda:1,returncode=1)
            with self.assertRaisesRegex(ValueError,'prematurely'):value.monitor()
            with self.assertRaisesRegex(ValueError,'successfully'):value.close()
            receipt=json.loads((Path(name)/'qml-profile-receipt.json').read_text())
            self.assertTrue(receipt['cleanup_complete']);self.assertFalse(receipt['connected'])
            self.assertEqual(receipt['client_exit'],1)

    def test_successful_close_keeps_raw_trace_and_defers_parsing_until_cleanup(self):
        with tempfile.TemporaryDirectory() as name:
            value=self.fixture(Path(name));value.directory.mkdir()
            value.child=SimpleNamespace(poll=lambda:0,returncode=0)
            (value.directory/'client.stdout').write_bytes(b'')
            (value.directory/'client.stderr').write_bytes(b'Connected to 127.0.0.1:43385.\n')
            self.xml(value.directory/'qml.qtd')
            with patch.object(capture,'trace_summary',side_effect=AssertionError('No XML analysis during host cleanup')):
                receipt=value.close()
            self.assertTrue(receipt['cleanup_complete'] and receipt['connected'])
            self.assertTrue(receipt['trace_analysis_deferred_until_after_host_cleanup'])
            self.assertEqual(receipt['trace_pin'],capture.pin(value.directory/'qml.qtd'))

    def test_final_stream_overflow_cannot_be_missed_between_host_polls(self):
        with tempfile.TemporaryDirectory() as name:
            value=self.fixture(Path(name));value.directory.mkdir()
            value.child=SimpleNamespace(poll=lambda:0,returncode=0)
            (value.directory/'client.stdout').write_bytes(b'x'*11)
            (value.directory/'client.stderr').write_bytes(b'')
            with patch.object(capture,'STREAM_LIMIT',10), self.assertRaisesRegex(ValueError,'final stream'):
                value.close()
            self.assertFalse(value.receipt['connected'])
            self.assertTrue(value.receipt['cleanup_complete'])

    def xml(self, path, ranges='<range startTime="10" duration="5" eventIndex="0"/>'):
        path.write_text('<trace version="1.02" traceStart="0" traceEnd="100">'
                        '<eventData><event index="0"><type>Javascript</type><details>work</details></event></eventData>'
                        '<profilerDataModel>'+ranges+'</profilerDataModel></trace>')

    def test_trace_retains_counts_and_nested_inclusive_wall_time(self):
        with tempfile.TemporaryDirectory() as name:
            path=Path(name)/'trace.qtd';self.xml(path,'<range startTime="10" duration="5" eventIndex="0"/>'
                                                  '<range startTime="11" duration="2" eventIndex="0"/>')
            value=capture.trace_summary(path)
            self.assertTrue(value['nested_events_are_not_additive'])
            self.assertEqual(value['events'][0]['inclusive_wall_ns'],7)
            self.assertEqual(value['events'][0]['count'],2)

    def test_trace_rejects_unknown_event_or_clock_outside_capture(self):
        with tempfile.TemporaryDirectory() as name:
            path=Path(name)/'trace.qtd'
            for row in ('<range startTime="10" duration="5" eventIndex="2"/>',
                        '<range startTime="99" duration="5" eventIndex="0"/>'):
                self.xml(path,row)
                with self.subTest(row=row),self.assertRaises(ValueError):capture.trace_summary(path)

    def test_trace_never_expands_entities_and_respects_size_bound(self):
        with tempfile.TemporaryDirectory() as name:
            path=Path(name)/'trace.qtd';path.write_text('<!DOCTYPE trace [<!ENTITY x SYSTEM "file:///private">]><trace>&x;</trace>')
            with self.assertRaisesRegex(ValueError,'entity declaration'):capture.trace_summary(path)
            self.xml(path)
            with patch.object(capture,'TRACE_LIMIT',10),self.assertRaisesRegex(ValueError,'over bound'):
                capture.trace_summary(path)


if __name__ == '__main__':
    unittest.main()
