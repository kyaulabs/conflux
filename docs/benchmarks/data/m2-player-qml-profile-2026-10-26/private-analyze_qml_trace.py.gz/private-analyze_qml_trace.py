#!/usr/bin/env python3
"""Stream the closed Qt trace after host cleanup; durations are inclusive wall time."""
import hashlib
import json
from pathlib import Path
import resource
import time
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent / 'player-qml-01'


def main():
    started = time.monotonic()
    resource.setrlimit(resource.RLIMIT_AS, (1024**3,) * 2)
    resource.setrlimit(resource.RLIMIT_CPU, (45, 45))
    finished = json.loads((BASE/'root-finished-01.json').read_text())
    receipt = json.loads((BASE/'qml-profile-receipt.json').read_text())
    assert finished['cleanup_complete'] and receipt['cleanup_complete'] and receipt['client_exit'] == 0
    path = Path(receipt['trace_pin']['path'])
    output = BASE/'root-qml-analysis-01.json'
    assert not output.exists() and path.stat().st_size <= 128*1024**2
    before = path.stat()
    digest = hashlib.sha256(); count = 0; tail = b''
    with path.open('rb') as stream:
        while block := stream.read(1024*1024):
            digest.update(block);count += len(block)
            assert b'<!DOCTYPE' not in tail+block and b'<!ENTITY' not in tail+block
            tail = block[-32:]
            assert time.monotonic()-started < 60
    assert count == receipt['trace_pin']['bytes'] and digest.hexdigest() == receipt['trace_pin']['sha256']
    definitions = {}; totals = {}; types = {}; invalid = []; stack = []
    events = 0; previous = -1; ordered = True; start = end = None
    for event, element in ET.iterparse(path, events=('start','end')):
        if event == 'start':
            stack.append(element)
            if len(stack) == 1:
                assert element.tag == 'trace' and element.get('version') == '1.02'
                start, end = int(element.attrib['traceStart']), int(element.attrib['traceEnd'])
                assert 0 <= start < end
            continue
        parent = stack[-2] if len(stack)>1 else None
        if element.tag == 'event':
            index = int(element.attrib['index'])
            assert index not in definitions and len(definitions) < 10000
            definitions[index] = {child.tag:child.text for child in element}
            parent.remove(element)
        elif element.tag == 'range':
            index = int(element.attrib['eventIndex']); assert index in definitions
            timestamp = int(element.attrib['startTime']); duration = int(element.get('duration','0'))
            assert duration >= 0
            if not start <= timestamp <= timestamp+duration <= end:
                if len(invalid)<16:invalid.append(dict(event_index=index,attributes=dict(element.attrib)))
            ordered = ordered and timestamp >= previous; previous = timestamp
            value = totals.setdefault(index,dict(count=0,inclusive_wall_ns=0,maximum_wall_ns=0))
            value['count']+=1;value['inclusive_wall_ns']+=duration
            value['maximum_wall_ns']=max(value['maximum_wall_ns'],duration)
            kind=definitions[index].get('type','Unknown');item=types.setdefault(kind,dict(count=0,inclusive_wall_ns=0))
            item['count']+=1;item['inclusive_wall_ns']+=duration
            events+=1;assert events <= 2000000
            if events%4096 == 0:assert time.monotonic()-started < 60
            parent.remove(element)
        stack.pop()
    after=path.stat()
    assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
    assert events>0
    rows=sorted([dict(index=index,**definitions[index],**value) for index,value in totals.items()],
                key=lambda row:row['inclusive_wall_ns'],reverse=True)
    result=dict(schema=1,qualified=False,scope='Closed first30s QML trace only. Inclusive wall ranges may nest and include C++ calls; no native CPU or causal heat attribution.',
                trace_pin=receipt['trace_pin'],trace_start_ns=start,trace_end_ns=end,trace_span_seconds=(end-start)/1e9,
                capture_flush_after_client_start_seconds=receipt['flush_sent_monotonic']-receipt['attach_started_monotonic'],
                event_count=events,definitions=len(definitions),ranges_ordered_by_start=ordered,range_boundary_errors=invalid,
                nested_inclusive_durations_are_not_additive=True,types=types,events_by_inclusive_wall=rows,
                root_cleanup_preceded_analysis=True,analysis_elapsed_seconds=time.monotonic()-started,
                analyzer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    with output.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['events_by_inclusive_wall','types']}))
    print(json.dumps(dict(types=types,top_events=rows[:16]),indent=2))


if __name__ == '__main__':
    main()
