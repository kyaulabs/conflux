"""Independently scan the aborted profiler run's WAV; preserve its failed verdict."""
from array import array
import hashlib
import json
import math
from pathlib import Path
import statistics
import struct
import sys

BASE = Path(__file__).resolve().parent / 'player-qml-01'
result = json.loads((BASE/'output-01/result.json').read_text())
native = result['native']
closure = json.loads((BASE/'root-finished-01.json').read_text())
assert closure['cleanup_complete'] and not closure['diagnostic_complete']
path = BASE/'output-01/master.wav'
wav = path.read_bytes()
assert wav[:4] == b'RIFF' and wav[8:12] == b'WAVE' and int.from_bytes(wav[4:8], 'little')+8 == len(wav)
offset, data, fmt = 12, None, None
while offset+8 <= len(wav):
    kind, size = wav[offset:offset+4], int.from_bytes(wav[offset+4:offset+8], 'little')
    start = offset+8
    assert start+size <= len(wav)
    if kind == b'fmt ': fmt = struct.unpack_from('<HHIIHH', wav, start)
    if kind == b'data': data = wav[start:start+size]
    offset = start+size+(size & 1)
assert offset == len(wav) and fmt[0] == 3 and fmt[1] == 2 and fmt[2] == 48000 and fmt[5] == 32
assert data is not None and len(data)%8 == 0
samples = array('f');samples.frombytes(data)
if sys.byteorder != 'little':samples.byteswap()
assert all(math.isfinite(value) for value in samples)
frames, nonzero = len(samples)//2, sum(value != 0 for value in samples)
peaks = [max(map(abs,samples[channel::2]),default=0) for channel in (0,1)]
expected, writer = native['recorded_audio'], native['recording']
assert frames == expected['frames'] == writer['acceptedFrames'] == writer['writtenFrames']
assert nonzero == expected['nonzero_samples'] and peaks == [expected['peak_left'],expected['peak_right']]
assert writer['overflowFrames'] == 0
observations = [json.loads(line) for line in (BASE/'output-01/observations.jsonl').read_text().splitlines()]
hops = [row for row in observations if row.get('hop_service_present')]
times = sorted(row['hop_service_ms'] for row in hops)
assert times
failure = native['window_failure']
profile = json.loads((BASE/'qml-profile-receipt.json').read_text())
last_frame_approximate_ns = failure['monotonic_ns']-failure['frame_age_ns']
out = dict(schema=1,qualified=False,complete_two_minute_workload=False,
           scope='Aborted instrumented run; observed chunk timings and WAV integrity only. No uninstrumented, complete-workload, sustained or physical-output latency qualification.',
           native_error=native['error'],measured_wall_ms=native['measured_wall_ms'],
           observed_hops=len(hops),observed_median_ms=statistics.median(times),observed_maximum_ms=max(times),
           observed_hops_at_or_above_4095_ms=sum(value>=4095 for value in times),
           strict_service_target_ms=4095,steady_starved_frames=native['steady_starved_frames'],
           control_starved_frames=native['control_starved_frames'],control_starved_seconds=native['control_starved_frames']/48000,
           peer_starved_frames=sum(row['starved_b'] for row in native['intervals']),
           controls_submitted=len(native['manual_controls']),controls_acknowledged=sum(row['acknowledged'] for row in native['manual_controls']),
           control_recoveries=native['controls'],UI=native['ui_coverage'],window_failure=failure,
           profiler_flush_monotonic_ns=round(profile['flush_sent_monotonic']*1e9),
           approximate_last_frame_after_flush_ms=(last_frame_approximate_ns-round(profile['flush_sent_monotonic']*1e9))/1e6,
           flush_temporal_association_is_not_causal_proof=True,
           callback_execution_deadline_misses=native['execution_deadline_misses'],invalid_buffers=native['invalid_buffers'],
           rejected_commands=native['rejected_commands'],source_read_failures=native['source_read_failures'],driver_timing=native['timing'],
           WAV=dict(path=str(path),bytes=len(wav),sha256=hashlib.sha256(wav).hexdigest(),frames=frames,samples=len(samples),
                    all_samples_finite=True,nonzero_samples=nonzero,peaks=peaks,sample_rate=48000,channels=2,
                    matches_native_counts_and_peaks=True,recording_overflow_frames=0),
           thermal_summary=result['thermal_summary'])
with (BASE/'root-audio-results-01.json').open('x') as stream:json.dump(out,stream,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps({key:out[key] for key in ['measured_wall_ms','observed_hops','observed_median_ms','observed_maximum_ms',
                 'observed_hops_at_or_above_4095_ms','control_starved_seconds','controls_submitted','controls_acknowledged',
                 'approximate_last_frame_after_flush_ms','WAV']}))
