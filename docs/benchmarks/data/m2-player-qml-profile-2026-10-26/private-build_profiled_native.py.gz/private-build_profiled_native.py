#!/usr/bin/env python3
"""Build only a private, profiler-enabled copy of the native diagnostic."""
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import shlex
import socket
import subprocess
import time

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
WORK = ROOT / 'build/m2-profile-reporting-worktree'
BUILD = ROOT / 'build/m2-flash-rows8-player-2026-10-25/build-01'
SOURCE = WORK / 'tools/experiments/manual_playback_soak.cpp'
HEAD = '119a579e4ca717a1d59d7a7a6f9752534d68dcaf'


def pin(path):
    path = Path(path).absolute()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    receipt_path = BASE / 'root-private-build-01.json'
    assert not receipt_path.exists()
    original_binary = BUILD / 'conflux-manual-playback-soak'
    original_source = SOURCE.read_bytes()
    assert subprocess.check_output(['git', 'show', HEAD + ':tools/experiments/manual_playback_soak.cpp'], cwd=WORK) == original_source
    compile_database = json.loads((BUILD / 'compile_commands.json').read_text())
    rows = [r for r in compile_database if r['file'] == str(SOURCE)]
    assert len(rows) == 1
    row = rows[0]
    assert row['directory'] == str(BUILD)
    original_compile = shlex.split(row['command'])
    original_link_text = subprocess.check_output(['ninja', '-t', 'commands', 'conflux-manual-playback-soak'], cwd=BUILD, text=True).splitlines()[-1]
    assert original_link_text.startswith(': && ') and original_link_text.endswith(' && :')
    original_link = shlex.split(original_link_text[5:-5])
    assert not any(x in (';', '&&', '||', '|', '>', '<') for x in original_link)
    native_object = 'CMakeFiles/conflux-manual-playback-soak.dir/tools/experiments/manual_playback_soak.cpp.o'
    assert original_compile.count(native_object) == original_link.count(native_object) == 1
    assert original_compile.count(str(SOURCE)) == 1
    assert original_link.count('-o') == 1
    assert original_link[original_link.index('-o') + 1] == original_binary.name
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(('127.0.0.1', 0))
        port = probe.getsockname()[1]
    source = original_source.decode()
    include = '#include <QQmlApplicationEngine>\n'
    anchor = '    QGuiApplication app(argc, argv);\n'
    assert source.count(include) == source.count(anchor) == 1
    source = source.replace(include, include + '#include <QtQml/qqmldebug.h>\n')
    source = source.replace(anchor, anchor + '''    // Private diagnostic only: profiler services on an owned loopback port.
    if (argc != 13 || QString::fromLocal8Bit(argv[1]) != "--live-stems-controls") return 2;
    QQmlDebuggingEnabler::enableDebugging(true);
    QQmlDebuggingEnabler::setServices(QQmlDebuggingEnabler::profilerServices());
    if (!QQmlDebuggingEnabler::startTcpDebugServer(PORT,
            QQmlDebuggingEnabler::WaitForClient, QStringLiteral("127.0.0.1"))) return 2;
'''.replace('PORT', str(port)))
    private_source = BASE / 'private_manual_playback_soak.cpp'
    private_source.write_bytes(source.encode())
    patch = ''.join(difflib.unified_diff(original_source.decode().splitlines(True), source.splitlines(True),
                                        fromfile=str(SOURCE), tofile=str(private_source)))
    (BASE / 'private-native-01.patch').write_text(patch)
    private_object = BASE / 'private-soak.o'
    private_binary = BASE / 'conflux-manual-playback-qml-profile'
    compile_argv = [str(private_object) if x == native_object else str(private_source) if x == str(SOURCE) else x
                    for x in original_compile]
    # Preserve quoted relative experiment includes after moving the single source.
    compile_argv[1:1] = ['-iquote', str(SOURCE.parent)]
    link_argv = [str(private_object) if x == native_object else
                 str(private_binary) if x == original_binary.name else
                 '-Wl,--dependency-file=' + str(BASE / 'private-link.d') if x.startswith('-Wl,--dependency-file=') else x
                 for x in original_link]
    assert original_link[0] == compile_argv[0] == '/bin/c++'
    dependency_paths = [BUILD / native_object, BUILD / 'compile_commands.json', BUILD / 'CMakeCache.txt', SOURCE,
                        original_binary, Path('/usr/include/qt6/QtQml/qqmldebug.h'),
                        Path('/usr/lib/qt6/bin/qmlprofiler')]
    for token in original_link[1:]:
        if token.startswith('-') or token == original_binary.name:
            continue
        path = Path(token) if Path(token).is_absolute() else BUILD / token
        if path.is_file():
            dependency_paths.append(path)
    before = [pin(path) for path in dict.fromkeys(dependency_paths)]
    receipt = dict(schema=1, status='started', source_head=HEAD, source_root=str(WORK),
                   scope='One private native diagnostic translation unit. Audio/model/runtime/QML source and original build inputs unchanged.',
                   qualified=False, timing_qualification=False, created_at_utc=datetime.now(timezone.utc).isoformat(),
                   port=port, bind_address='127.0.0.1', services='QQmlDebuggingEnabler::profilerServices()',
                   base_inputs=before, original_compile_argv=original_compile, original_link_argv=original_link,
                   compile_argv=compile_argv, link_argv=link_argv, private_source=pin(private_source),
                   source_patch=pin(BASE / 'private-native-01.patch'))
    started = time.monotonic()
    try:
        for phase, argv, limit in [('compile', compile_argv, 90), ('link', link_argv, 45)]:
            with (BASE / ('private-' + phase + '-01.stdout')).open('xb') as out, (BASE / ('private-' + phase + '-01.stderr')).open('xb') as err:
                result = subprocess.run(argv, cwd=BUILD, stdout=out, stderr=err, timeout=limit, check=False)
            receipt[phase + '_exit'] = result.returncode
            assert result.returncode == 0, phase + ' failed'
        assert [pin(row['path']) for row in before] == before, 'Original inputs changed'
        receipt.update(status='complete', private_object=pin(private_object), binary=pin(private_binary),
                       base_inputs_unchanged=True)
    except Exception as error:
        receipt.update(status='failed', error=dict(type=type(error).__name__, message=str(error)))
        raise
    finally:
        receipt['elapsed_seconds'] = time.monotonic() - started
        save(receipt_path, receipt)
    print(json.dumps({key: receipt[key] for key in ('status', 'port', 'binary', 'elapsed_seconds', 'base_inputs_unchanged')}))


if __name__ == '__main__':
    main()
