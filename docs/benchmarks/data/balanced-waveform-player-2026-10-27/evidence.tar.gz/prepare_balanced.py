"""Reuse the frozen waveform-only builds with a fresh, read-only Balanced packet."""
from pathlib import Path
import copy,hashlib,json,re,shutil
ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
BASE=Path(__file__).resolve().parent
OLD=ROOT/'build/m2-waveform-player-comparison-06'
def pin(path):
 raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
 with path.open('x') as f:f.write(json.dumps(value,indent=2,allow_nan=False)+'\n')
def replace(text,old,new,count=1):
 assert text.count(old)==count,(old,text.count(old));return text.replace(old,new)
def write(path,text):
 with path.open('x') as f:f.write(text)
root_files=['drm_usage.py','test_drm_usage.py','test_owner_entry.py','verify_owner_entry.py',
 'pair_clock.py','test_pair_clock.py','launch_case.py','test_failed_recovery_capture.py',
 'test_all_fresh_settling.py','check_desktop_entry.py','freeze_packet.py']
for name in root_files:
 text=(OLD/name).read_text()
 if name=='test_all_fresh_settling.py':
  text=text.replace('post-profile','pre-dispatch').replace("plan['requested_power_profile'] = 'performance'","plan['requested_power_profile'] = 'balanced'").replace("profile='performance', platform='performance', epp='performance'","profile='balanced', platform='balanced', epp='balance_performance'")
  first=text.index('    def test_actual_post_profile_spike_rejects_frozen_packet(self):')
  last=text.index('    def test_both_sensors_settle_at_all_four_phases_for_both_arms(self):',first)
  text=text[:first]+text[last:]
 if name=='freeze_packet.py':
  text=replace(text,"BASE = Path(__file__).resolve().parent","BASE = Path(__file__).resolve().parent\nORIGINAL = ROOT/'build/m2-waveform-player-comparison-06'")
  text=text.replace("BASE/arm/'source-manifest-01.json'","ORIGINAL/arm/'source-manifest-01.json'").replace("BASE/k/'source-manifest-01.json'","ORIGINAL/k/'source-manifest-01.json'")
  text=replace(text,"assert all(all(v.values()) for v in offline['arms'].values())","assert offline['passed'] is True and offline['root_offline']['passed'] is True\n    assert all(all(v.values()) for v in offline['arms'].values())")
  text=text.replace("authorized_profile_selection='performance',authorized_long_term_ceiling_uw=25000000","authorized_profile_selection=None,authorized_long_term_ceiling_uw=15000000")
  text=text.replace("authorized_long_term_ceiling_uw=25000000","authorized_long_term_ceiling_uw=15000000").replace("requested_power_profile='performance'","requested_power_profile='balanced',no_profile_or_cap_writes=True")
 write(BASE/name,text)
shutil.copyfile(OLD/'build-pair-receipt-01.json',BASE/'build-pair-receipt-01.json')
for arm in ['baseline','candidate']:
 before=OLD/'cases'/arm;case=BASE/'cases'/arm;case.mkdir(parents=True,exist_ok=False)
 for file in before.glob('*.py'):
  if file.name in ['profile_policy.py','test_profile_policy.py','test_profile_driver.py']:continue
  text=file.read_text()
  if file.name=='run_host_player.py':
   text=replace(text,f"m2-waveform-cache-performance25-visible-120-06-{arm}",f"m2-waveform-cache-balanced-visible-120-07-{arm}")
   text=replace(text,"constraint_0_power_limit_uw': 25000000","constraint_0_power_limit_uw': 15000000")
   text=replace(text,"plan.get('requested_power_profile') == 'performance'","plan.get('requested_power_profile') == 'balanced' and plan.get('allow_natural_power_saver_start') is False")
   text=replace(text,"require(requested in ('balanced','performance'),'Fixed power profile absent/differs')","require(requested == 'balanced','Fixed Balanced profile absent/differs')")
   text=replace(text,"    policy_row=plan['sources']['profile_policy']\n    policy=load_source('private_guarded_profile_policy',Path(policy_row['path']),policy_row['sha256'])\n",'')
   text=replace(text,"        report['profile_selection']=policy.select('performance',plan_pin,human_pin,admission['guard_before'],deadline)\n",'')
   start=text.index('        try:\n            report[\'profile_restoration\']')
   end=text.index("        try: sample_caps('after_workload')",start)
   text=text[:start]+text[end:]
   text=replace(text,"        if report.get('profile_restoration_failed'):report.update(status='failed',diagnostic_complete=False,passed=False)\n",'')
   text=replace(text,"'requested_power_profile':plan['requested_power_profile'],","'requested_power_profile':plan['requested_power_profile'],\n        'power_policy_changed_by_test':False,")
  if file.name=='test_host_player.py':
   text=replace(text,"power_profile='performance',selection_failure=False,restore_failure=False,owner_age_seconds=0,before_monitor=None):","owner_age_seconds=0,before_monitor=None):")
   text=replace(text,"        plan['requested_power_profile']=power_profile\n        plan['sources']={'profile_policy':{'path':'/offline/profile_policy.py','sha256':'f'*64}}\n",'')
   start=text.index('        def select(case,*args):');end=text.index('        oracle=SimpleNamespace',start);text=text[:start]+text[end:]
   text,n=re.subn(r"^[ \t]*if name=='private_guarded_profile_policy':return policy\n",'',text,flags=re.M);assert n==2
   start=text.index("        plan['requested_power_profile']='performance'",text.index('class CompletedRunCaptureTests'))
   end=text.index('        capture_helper=',start);text=text[:start]+text[end:]
  write(case/file.name,text)
 (case/'run_player_owned.py').chmod(0o755)
 owner=(case/'run_player_owned.py').read_text()
 owner,n=re.subn(r"LAUNCHER_SHA = '[0-9a-f]{64}'","LAUNCHER_SHA = '"+pin(case/'run_host_player.py')['sha256']+"'",owner,count=1);assert n==1
 (case/'run_player_owned.py').write_text(owner)
 for name in ['launch-command-01.txt','driver-cache-initial-01.json']:
  write(case/name,(before/name).read_text().replace(str(before),str(case)))
 shutil.copytree(before/'driver-cache',case/'driver-cache')
 plan=json.loads((before/'plan.json').read_text())
 for key in ['retired_reason','performance_cap_setup_scope']:plan.pop(key,None)
 plan.update(status='draft_unarmed_pending_root_review',mode=f'm2-waveform-cache-balanced-visible-120-07-{arm}',
  requested_power_profile='balanced',allow_natural_power_saver_start=False,
  power_policy_scope='Read-only Balanced/15 W start, natural thermal-guard reductions preserved; no profile or power-cap writes. Removed Performance limiter must remain absent.',
  source_reuse_scope='Same original Git-pinned 06 builds, no rebuild; the only product difference is waveform caching.')
 cap='/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_power_limit_uw'
 assert plan['power_limits'][cap]==25000000;plan['power_limits'][cap]=15000000
 plan['mesa_shader_cache']['path']=str(case/'driver-cache')
 obsolete={'profile_policy','profile_policy_tests','profile_driver_tests','performance_limiter_binding','packet_policy_patch',
  'patch_packet.py','update_fixtures.py','refresh_draft_pins.py','test_admission_setup_regression.py','test_performance_settling.py'}
 for key in list(plan['sources']):
  if key in obsolete:del plan['sources'][key];continue
  row=plan['sources'][key];path=Path(row['path'])
  if path.is_relative_to(before):
   candidate=case/path.relative_to(before)
   assert candidate.is_file(),str(candidate);plan['sources'][key]=pin(candidate)
  elif path.is_relative_to(OLD):
   candidate=BASE/path.relative_to(OLD)
   if candidate.is_file():plan['sources'][key]=pin(candidate)
 plan['sources']['balanced_packet_preparer']=pin(Path(__file__).resolve())
 for key,row in plan['helpers'].items():
  old=Path(row['path'])
  if old.is_relative_to(OLD) and (BASE/old.relative_to(OLD)).is_file():plan['helpers'][key]=pin(BASE/old.relative_to(OLD))
 save(case/'plan.json',plan)
 launch=json.loads((before/'root-launch-plan-01.json').read_text());oldunit=launch['unit'];unit=f'conflux-m2-waveform-cache-balanced-20261027-07-{arm}.service'
 launch.update(unit=unit,plan=pin(case/'plan.json'),no_profile_or_cap_writes=True,
  authorized_profile_selection=None,authorized_long_term_ceiling_uw=15000000,idle_inhibition_scope=str(case/'run_player_owned.py'))
 launch['command']=[x.replace(str(before),str(case)).replace(oldunit,unit) for x in launch['command']]
 save(case/'root-launch-plan-01.json',launch)
save(BASE/'packet-preparation-01.json',dict(schema=1,reused_build_receipt=pin(OLD/'build-pair-receipt-01.json'),
 retired_packet=pin(OLD/'retired-unarmed-01.json'),order=['baseline','candidate'],original_pair_operator_seconds=1200,
 no_retries=True,requested_profile='balanced',profile_or_cap_writes=False,ceiling_uw=15000000,
 unchanged_target_ms=4095,readiness_created=False,player_started=False,model_started=False,audio_output_started=False))
print('Fresh Balanced packet drafted; no readiness or physical test started.')
