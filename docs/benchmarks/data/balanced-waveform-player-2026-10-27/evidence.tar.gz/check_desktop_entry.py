"""Exercise real dry desktop entries; missing readiness must prevent any workload."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

BASE = Path(__file__).resolve().parent


def main():
    assert Path('/proc/1/comm').read_text().strip()=='systemd'
    report=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),arms={},
        player_started=False,model_started=False,audio_output_started=False,readiness_created=False)
    for arm in ['baseline','candidate']:
        case=BASE/'cases'/arm
        assert not (case/'readiness.json').exists()
        owner=case/'run_player_owned.py'
        prefix=['/usr/bin/kde-inhibit','--power','--screenSaver',str(owner)]
        dry=subprocess.run(prefix,cwd=BASE,capture_output=True,text=True,timeout=10)
        assert dry.returncode==0 and not dry.stderr
        value=json.loads(dry.stdout)
        assert value['status']=='unarmed_dry_owner' and value['native_started'] is False and value['host_queried'] is False
        missing=subprocess.run(prefix+['--run'],cwd=BASE,capture_output=True,text=True,timeout=10)
        assert not missing.stdout
        assert 'FileNotFoundError' in missing.stderr and str(case/'readiness.json') in missing.stderr
        assert 'Draft packet is unarmed' not in missing.stderr
        root_dry=subprocess.run(['/usr/bin/python3.14','-B',str(BASE/'launch_case.py'),'--arm',arm],
            cwd=BASE,capture_output=True,text=True,timeout=10)
        root_dry.check_returncode()
        assert json.loads(root_dry.stdout)['native_started'] is False
        root_missing=subprocess.run(['/usr/bin/python3.14','-B',str(BASE/'launch_case.py'),'--arm',arm,'--run'],
            cwd=BASE,capture_output=True,text=True,timeout=10)
        assert not root_missing.stdout and root_missing.returncode!=0
        assert 'FileNotFoundError' in root_missing.stderr and str(case/'readiness.json') in root_missing.stderr
        unit=json.loads((case/'root-launch-plan-01.json').read_text())['unit']
        state=subprocess.check_output(['systemctl','--user','show',unit,
            '--property=LoadState,MainPID,ControlGroup'],text=True,timeout=5)
        assert 'LoadState=not-found' in state and 'MainPID=0' in state
        assert not any((case/name).exists() for name in ['readiness.json','root-dispatch-reservation-01.json',
            'dispatch-01.json','root-unit-dispatch-01.json','output-01'])
        report['arms'][arm]=dict(dry_owner=value,owner_executable=True,
            real_armed_owner_reached_missing_readiness_boundary=True,
            root_dry_verified=True,root_run_reached_missing_readiness_boundary=True,
            unit_not_created=True,owner_missing_readiness_stderr=missing.stderr,
            root_missing_readiness_stderr=root_missing.stderr)
    command=['busctl','--user','--timeout=2s','--json=short','call',
        'org.kde.Solid.PowerManagement.PolicyAgent','/org/kde/Solid/PowerManagement/PolicyAgent',
        'org.kde.Solid.PowerManagement.PolicyAgent','ListInhibitions']
    inhibitors=json.loads(subprocess.check_output(command,text=True,timeout=5))
    assert inhibitors['type']=='aas'
    own={str(BASE/'cases'/arm/'run_player_owned.py') for arm in ['baseline','candidate']}
    assert not any(row[1] in own for row in inhibitors['data'][0])
    report['own_idle_inhibitions_remaining']=0
    report['verifier_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    with (BASE/'actual-desktop-entry-check-01.json').open('x') as stream:
        stream.write(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(arms_verified=list(report['arms']),readiness_created=False,
        player_started=False,model_started=False,own_idle_inhibitions_remaining=0)))


if __name__=='__main__':main()
