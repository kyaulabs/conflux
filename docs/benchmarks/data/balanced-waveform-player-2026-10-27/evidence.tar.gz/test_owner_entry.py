"""No hardware launch: executable gate, exited owners and retained dispatch failures."""
import importlib.util
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('offline_gpu_root_entry', BASE / 'launch_case.py')
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)


class RootEntryTests(unittest.TestCase):
    def fixture(self, base, executable=True):
        plan = base / 'plan.json'
        plan.write_text('{"status": "frozen_pending_fresh_readiness"}\n')
        (base / 'root-launch-plan-01.json').write_text(json.dumps(dict(
            no_retries=True, fresh_readiness_required=True, plan=entry.pin(plan))))
        (base / 'root-launch-clearance-01.json').write_text('{"pins": []}\n')
        owner = base / 'run_player_owned.py'
        owner.write_text('#!/usr/bin/python3\nraise SystemExit(0)\n')
        owner.chmod(0o755 if executable else 0o644)
        return owner

    def test_nonexecutable_owner_stops_before_readiness_or_host_query(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            self.fixture(base, executable=False)
            with patch.object(entry, 'CASE', base), patch.object(sys, 'argv', ['entry', '--run']), \
                    patch.object(entry, 'show') as show, patch.object(entry.subprocess, 'run') as run:
                with self.assertRaisesRegex(AssertionError, 'not executable'):
                    entry.main()
            show.assert_not_called()
            run.assert_not_called()
            self.assertFalse((base / 'root-dispatch-reservation-01.json').exists())

    def test_executable_entry_without_readiness_cannot_query_or_launch(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            self.fixture(base)
            with patch.object(entry, 'CASE', base), patch.object(sys, 'argv', ['entry', '--run']), \
                    patch.object(entry, 'show') as show, patch.object(entry.subprocess, 'run') as run:
                with self.assertRaises(FileNotFoundError):
                    entry.main()
            show.assert_not_called()
            run.assert_not_called()

    def test_draft_plan_cannot_reach_readiness_or_host_dispatch(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            self.fixture(base)
            plan = base / 'plan.json'
            plan.write_text('{"status": "draft_unarmed_pending_root_review"}\n')
            launch_path = base / 'root-launch-plan-01.json'
            launch = json.loads(launch_path.read_text())
            launch['plan'] = entry.pin(plan)
            launch_path.write_text(json.dumps(launch))
            with patch.object(entry, 'CASE', base), patch.object(sys, 'argv', ['entry', '--run']), \
                    patch.object(entry, 'show') as show, patch.object(entry.subprocess, 'run') as run:
                with self.assertRaisesRegex(AssertionError, 'must be frozen'):
                    entry.main()
            show.assert_not_called()
            run.assert_not_called()

    def test_consumed_dispatch_is_rejected_before_host_queries(self):
        for marker in ('root-dispatch-reservation-01.json', 'root-unit-dispatch-01.json', 'root-finished-01.json'):
            with self.subTest(marker=marker), tempfile.TemporaryDirectory() as directory:
                base = Path(directory)
                self.fixture(base)
                (base / marker).write_text('{}\n')
                with patch.object(entry, 'CASE', base), patch.object(sys, 'argv', ['entry', '--run']), \
                        patch.object(entry, 'show') as show, patch.object(entry.subprocess, 'run') as run:
                    with self.assertRaises(AssertionError):
                        entry.main()
                show.assert_not_called()
                run.assert_not_called()

    def dispatch(self, base, state, error=None, returncode=0):
        launch = dict(command=['offline-mocked-dispatch'], unit='offline-mock.service')
        record = dict(original_operator_seconds=1200, automatic_retries=False)
        result = SimpleNamespace(returncode=returncode, stdout='fixture', stderr='')
        with patch.object(entry, 'CASE', base), \
                patch.object(entry.subprocess, 'run', return_value=result) as run, \
                patch.object(entry, 'show', return_value=state, side_effect=error):
            try:
                entry.dispatch_once(launch, record)
            finally:
                self.assertEqual(run.call_count, 1)
        return json.loads((base / 'root-unit-dispatch-01.json').read_text())

    def test_disappeared_pid_retains_unit_and_unknown_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            state = dict(MainPID='987654321', ActiveState='active', SubState='running',
                InvocationID='fixture-invocation', ControlGroup='/fixture.scope')
            with self.assertRaisesRegex(AssertionError, 'running owner not proven'):
                self.dispatch(base, state)
            receipt = json.loads((base / 'root-unit-dispatch-01.json').read_text())
            self.assertEqual(receipt['unit_after_launch'], state)
            self.assertTrue(receipt['owner_identity_observation_error']['birth_ticks_unknown'])
            self.assertNotIn('owner_identity', receipt)
            self.assertFalse(receipt['automatic_retries'])

    def test_exited_zero_status_is_not_a_running_owner(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            state = dict(MainPID='0', ActiveState='active', SubState='exited', ControlGroup='')
            with self.assertRaisesRegex(AssertionError, 'running owner not proven'):
                self.dispatch(base, state)
            receipt = json.loads((base / 'root-unit-dispatch-01.json').read_text())
            self.assertEqual(receipt['launch_returncode'], 0)
            self.assertEqual(receipt['unit_after_launch'], state)
            self.assertNotIn('owner_identity', receipt)

    def test_unit_query_failure_after_dispatch_is_always_retained(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            with self.assertRaisesRegex(OSError, 'mock show failure'):
                self.dispatch(base, None, error=OSError('mock show failure'))
            receipt = json.loads((base / 'root-unit-dispatch-01.json').read_text())
            self.assertEqual(receipt['launch_returncode'], 0)
            self.assertEqual(receipt['dispatch_or_observation_error']['type'], 'OSError')
            self.assertFalse(receipt['automatic_retries'])

    def test_dispatch_timeout_is_retained_without_retry(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            with patch.object(entry, 'CASE', base), \
                    patch.object(entry.subprocess, 'run', side_effect=subprocess.TimeoutExpired('fixture', 10)) as run:
                with self.assertRaises(subprocess.TimeoutExpired):
                    entry.dispatch_once(dict(command=['offline-mock'], unit='fixture'),
                        dict(automatic_retries=False))
            self.assertEqual(run.call_count, 1)
            receipt = json.loads((base / 'root-unit-dispatch-01.json').read_text())
            self.assertEqual(receipt['dispatch_or_observation_error']['type'], 'TimeoutExpired')

    def test_running_owner_keeps_actual_birth_tick_and_unit(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            state = dict(MainPID=str(os.getpid()), ActiveState='active', SubState='running',
                InvocationID='fixture-invocation', ControlGroup='/fixture.scope')
            receipt = self.dispatch(base, state)
            fields = Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()
            self.assertEqual(receipt['owner_identity']['start_ticks'], int(fields[19]))
            self.assertEqual(receipt['owner_identity']['pid'], os.getpid())
            self.assertEqual(receipt['unit_after_launch'], state)


class ActualFrozenOwnerTests(unittest.TestCase):
    def test_actual_frozen_packet_passes_real_armed_entry_before_dispatch(self):
        case = BASE / 'cases/candidate'
        self.assertFalse((case / 'readiness.json').exists())
        spec = importlib.util.spec_from_file_location('offline_real_owner_boundary', case / 'run_player_owned.py')
        owner = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(owner)
        driver = owner.load_driver()  # Real fixed hash and source import; no host/model work.
        plan_pin, raw = driver.pin_read(driver.PLAN, maximum=256*1024, keep=True)
        self.assertEqual(driver.decode(raw)['status'], 'frozen_pending_fresh_readiness')
        now = datetime.now(timezone.utc)
        fixture = dict(schema=1,decision='ready',diagnostic_mode=driver.MODE,ready_for_run='output-01',
            plan_sha256=plan_pin['sha256'],maximum_operator_seconds=1200,maximum_command_seconds=540,
            ui_mode='visible',AC_power=True,lid_open=True,visible_window=True,screen_awake=True,
            Codex_minimized=True,other_work_paused=True,no_suspend=True,
            human_reply='Offline generated fixture only; no launch authorization',
            human_question='Offline generated fixture only',question_item_id='offline-generated-fixture',
            recorded_at_utc=now.isoformat(),recorded_at_monotonic=time.monotonic())
        fixture_raw = json.dumps(fixture).encode()
        fixture_pin = dict(path='/offline/readiness-fixture',bytes=len(fixture_raw),
            sha256=hashlib.sha256(fixture_raw).hexdigest())
        real_read, real_budget = driver.pin_read, driver.budget
        read_paths = []
        def read(path, *args, **kwargs):
            read_paths.append(str(path))
            if Path(path) == driver.HUMAN:
                return fixture_pin, fixture_raw
            return real_read(path, *args, **kwargs)
        class ReachedBudgetBeforeDispatch(Exception):
            pass
        def stop_at_budget(*args):
            clocks = real_budget(*args)
            self.assertGreater(clocks['operator_deadline']-time.monotonic(),1190)
            raise ReachedBudgetBeforeDispatch()
        with patch.object(owner,'load_driver',return_value=driver), \
                patch.object(driver,'pin_read',side_effect=read), \
                patch.object(driver,'budget',side_effect=stop_at_budget), \
                patch.object(owner.subprocess,'Popen',side_effect=AssertionError('Offline check cannot spawn')) as spawn, \
                patch.object(owner,'verify_idle_inhibition',side_effect=AssertionError('Offline check cannot query desktop')) as inhibit, \
                patch.object(sys,'argv',[str(case/'run_player_owned.py'),'--run']):
            with self.assertRaises(ReachedBudgetBeforeDispatch):
                owner.main()
        spawn.assert_not_called()
        inhibit.assert_not_called()
        self.assertIn(str(case/'run_player_owned.py'),read_paths)
        self.assertIn(str(driver.HUMAN),read_paths)
        self.assertFalse(any((case/name).exists() for name in ('readiness.json','dispatch-01.json','output-01')))


if __name__ == '__main__':
    unittest.main()
