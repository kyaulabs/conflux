"""Refresh only this new packet's unarmed support pins after verified edits."""
from pathlib import Path
import hashlib,json,re
BASE=Path(__file__).resolve().parent
def pin(path):
 raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
for arm in ['baseline','candidate']:
 case=BASE/'cases'/arm
 assert not any((case/n).exists() for n in ['readiness.json','output-01','dispatch-01.json'])
 owner=case/'run_player_owned.py';text,n=re.subn(r"LAUNCHER_SHA = '[0-9a-f]{64}'","LAUNCHER_SHA = '"+pin(case/'run_host_player.py')['sha256']+"'",owner.read_text(),count=1);assert n==1;owner.write_text(text)
 path=case/'plan.json';plan=json.loads(path.read_text());assert plan['status']=='draft_unarmed_pending_root_review'
 for section in ['sources','helpers']:
  for key,row in plan[section].items():
   p=Path(row['path'])
   if p.is_relative_to(BASE):plan[section][key]=pin(p)
 for p in [*BASE.glob('test_*.py'),BASE/'refresh_pins.py',BASE/'run_offline_checks.py',BASE/'freeze_packet.py',BASE/'check_desktop_entry.py']:
  plan['sources'][p.name]=pin(p)
 path.write_text(json.dumps(plan,indent=2)+'\n')
 path=case/'root-launch-plan-01.json';launch=json.loads(path.read_text());launch['plan']=pin(case/'plan.json');path.write_text(json.dumps(launch,indent=2)+'\n')
