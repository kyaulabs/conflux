"""Replay late guard recovery with a fake clock; never start host workloads."""
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('cache_admission_fixture',
    Path(__file__).resolve().with_name('test_host_player.py'))
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)


class LateGuardRecoveryTests(unittest.TestCase):
    exercise = fixture.ReportingAndOrderingTests.exercise

    def test_late_guard_recovery_keeps_full_cooldown_and_original_clocks(self):
        # Comparison-02 warned again during cooldown and recovered ~209s
        # after admission began. Polling at 10s sees this fixture at 220s.
        saved, events, clock, _, output = self.exercise(
            guard_spike_after=42, guard_recovered_after=211)
        admission = saved['admission-01.json']
        report = saved['diagnostic-assessment.json']
        self.assertTrue(output)
        self.assertIn('final_admission_returned', events)
        self.assertEqual(admission['cooldown_deadline'], 301)
        self.assertEqual(admission['cool_readiness'][-1]['consecutive_span_seconds'], 60)
        self.assertAlmostEqual(clock[0], 281.3)
        self.assertEqual(events.count('single_cooldown'), 1)
        self.assertEqual(admission['public_readiness_calls'], 2)
        self.assertEqual(report['operator_clock']['command_deadline'], 541)
        self.assertEqual(report['owner_clock']['term_monotonic'], 526)
        self.assertGreaterEqual(admission['native_budget_samples'][-1]['working_seconds_remaining'], 210)
        self.assertFalse(report['diagnostic_complete'])

    def test_late_recovery_cannot_consume_the_native_working_reserve(self):
        saved, events, _, _, output = self.exercise(
            guard_spike_after=42, guard_recovered_after=211, owner_age_seconds=40)
        self.assertFalse(output)
        self.assertNotIn('wrapper_entered', events)
        self.assertTrue(saved['admission-01.json']['cooldown_complete'])
        self.assertIn('210s native working room', saved['diagnostic-assessment.json']['errors'][0]['message'])
        self.assertEqual(saved['diagnostic-assessment.json']['owner_clock']['term_monotonic'], 486)

    def test_recovery_too_late_for_full_cooldown_stops_at_300s(self):
        saved, events, clock, _, output = self.exercise(
            guard_spike_after=42, guard_recovered_after=243)
        self.assertFalse(output)
        self.assertNotIn('wrapper_entered', events)
        self.assertEqual(clock[0], 301)
        self.assertFalse(saved['admission-01.json'].get('cooldown_complete', False))
        self.assertIn('Original bounded60s', saved['diagnostic-assessment.json']['errors'][0]['message'])
        self.assertEqual(saved['diagnostic-assessment.json']['owner_clock']['term_monotonic'], 526)


if __name__ == '__main__':
    unittest.main()
