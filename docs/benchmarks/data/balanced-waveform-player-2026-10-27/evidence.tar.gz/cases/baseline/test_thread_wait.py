"""Generated proc fixtures only; no actual runtime or client is launched."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import test_thread_cpu as cpu

driver, stat_line = cpu.driver, cpu.stat_line


class ThreadWaitTests(unittest.TestCase):
    def fixture(self, root):
        proc, binary, process = cpu.ThreadCpuTests().fixture(root)
        for tid in (15, 16):
            (proc / '15/task' / str(tid) / 'wchan').write_text('futex_wait_queue\n')
        return proc, binary, process

    def test_wait_symbols_are_sampled_without_claiming_runqueue_time(self):
        with tempfile.TemporaryDirectory() as path:
            proc, binary, process = self.fixture(Path(path))
            value = driver.capture_native_thread_cpu(process, None, proc, binary)
            self.assertTrue(value['complete'])
            for row in value['threads']:
                wait = row['wait_snapshot']
                self.assertEqual(wait['kernel_wait_symbol'], 'futex_wait_queue')
                self.assertTrue(wait['wait_symbol_available'])
                self.assertGreaterEqual(wait['finished_monotonic_ns'], wait['began_monotonic_ns'])

    def test_zero_and_unreadable_wait_symbols_are_unknown(self):
        with tempfile.TemporaryDirectory() as path:
            proc, binary, process = self.fixture(Path(path))
            (proc / '15/task/15/wchan').write_text('0')
            (proc / '15/task/16/wchan').unlink()
            value = driver.capture_native_thread_cpu(process, None, proc, binary)
            self.assertTrue(value['complete'])
            self.assertTrue(all(not row['wait_snapshot']['wait_symbol_available'] for row in value['threads']))
            self.assertIsNone(value['threads'][0]['wait_snapshot']['read_error'])
            self.assertEqual(value['threads'][1]['wait_snapshot']['read_error'], 'FileNotFoundError')

    def test_oversized_wait_symbol_is_not_accepted_as_valid_observation(self):
        with tempfile.TemporaryDirectory() as path:
            proc, binary, process = self.fixture(Path(path))
            (proc / '15/task/16/wchan').write_text('x' * 257)
            value = driver.capture_native_thread_cpu(process, None, proc, binary)
            self.assertFalse(value['complete'])
            self.assertEqual([row['pid'] for row in value['threads']], [15])
            self.assertIn('oversized', value['errors'][0]['message'])

    def test_tid_reuse_during_wait_read_rejects_the_combined_row(self):
        with tempfile.TemporaryDirectory() as path:
            proc, binary, process = self.fixture(Path(path))
            original = Path.open
            def replacing(target, *args, **kwargs):
                result = original(target, *args, **kwargs)
                if target == proc / '15/task/16/wchan':
                    with original(proc / '15/task/16/stat', 'w') as stream:
                        stream.write(stat_line(16, user=1, system=0, start=92))
                return result
            with patch.object(Path, 'open', replacing):
                value = driver.capture_native_thread_cpu(process, None, proc, binary)
            self.assertFalse(value['complete'])
            self.assertEqual([row['pid'] for row in value['threads']], [15])
            self.assertIn('Thread lifetime', value['errors'][0]['message'])

    def test_runtime_threads_require_the_expected_runtime_executable(self):
        with tempfile.TemporaryDirectory() as path:
            root = Path(path)
            proc, binary, process = self.fixture(root)
            runtime = root / 'conflux-stem-runtime'
            runtime.write_bytes(b'generated runtime fixture')
            directory = proc / '20'
            (directory / 'task/20').mkdir(parents=True)
            (directory / 'exe').symlink_to(runtime)
            for target in (directory / 'stat', directory / 'task/20/stat'):
                target.write_text(stat_line(20, runtime.name[:15], user=1, system=0, start=93))
            (directory / 'task/20/wchan').write_text('dma_fence_wait')
            with patch.object(driver, 'BINARY', binary), patch.object(driver, 'RUNTIME', runtime):
                value = driver.capture_process_cpu(None, proc)
            self.assertFalse(value['exact_runqueue_wait_measured'])
            self.assertEqual(len(value['runtime_thread_cpu']), 1)
            found = value['runtime_thread_cpu'][0]
            self.assertTrue(found['matched_expected_exe'])
            self.assertEqual(found['threads'][0]['wait_snapshot']['kernel_wait_symbol'], 'dma_fence_wait')


if __name__ == '__main__':
    unittest.main()
