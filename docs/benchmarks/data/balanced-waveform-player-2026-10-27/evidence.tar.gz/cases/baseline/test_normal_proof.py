"""Normal-runtime evidence validation only; no process or model execution."""
import copy
import json
from pathlib import Path
import unittest
from test_host_player import driver


class NormalProofTests(unittest.TestCase):
    def fixture(self):
        plan=json.loads(driver.PLAN.read_text())
        proof=json.loads(Path(driver.PCM_PREREQUISITE['path']).read_text())
        return plan,proof

    def test_complete_normal16_reference_is_accepted(self):
        plan,proof=self.fixture();driver.validate_normal_pcm_proof(plan,proof)

    def test_diagnostic_runtime_cannot_be_mislabelled_normal(self):
        plan,original=self.fixture()
        for mutate in (lambda p:p.update(runtime_sha256='c63b1299877d0f7f6df9d8ca688f0bd88be1406a5da1be71233bc01231b4a6c6'),
                       lambda p:p['runtimes'][0].update(executable='/offline/instrumented-runtime')):
            proof=copy.deepcopy(original);mutate(proof)
            with self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_missing_or_duplicate_window_is_rejected(self):
        plan,original=self.fixture()
        for mutate in (lambda rows:rows.pop(),lambda rows:rows.__setitem__(1,copy.deepcopy(rows[0]))):
            proof=copy.deepcopy(original);mutate(proof['runtimes'][0]['requests'])
            with self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_unverified_pcm_or_wrong_output_shape_is_rejected(self):
        plan,original=self.fixture()
        for key,value in [('finite',False),('input_sha_match',False),('output_matches_closed_B',False),
                          ('output_shape',[2,343980,2]),('output_bytes',1),('valid_frames',1)]:
            proof=copy.deepcopy(original);proof['runtimes'][0]['requests'][0][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_missing_or_nonfinite_native_timing_is_rejected(self):
        plan,original=self.fixture()
        for value in (None,float('nan'),float('inf'),-1,True):
            proof=copy.deepcopy(original);proof['runtimes'][0]['requests'][0]['native_metrics']['graph_compute_ms']=value
            with self.subTest(value=value),self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_failed_cleanup_or_changed_input_pins_is_rejected(self):
        plan,original=self.fixture()
        for mutate in (lambda p:p.update(cleanup_complete=False),lambda p:p.update(private_spool_removed=False),
                       lambda p:p['runtimes'][0]['cleanup'].update(reaped=False),
                       lambda p:p['pins_after']['model'].update(sha256='a'*64)):
            proof=copy.deepcopy(original);mutate(proof)
            with self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_precision_thread_or_backend_changes_are_rejected(self):
        plan,original=self.fixture()
        for key,value in [('backend','cpu'),('threads',1),('weight_storage','f16'),('fence_wait_mode','spin')]:
            proof=copy.deepcopy(original);proof['runtimes'][0]['ready'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)

    def test_wrong_normal_runtime_build_receipt_is_rejected(self):
        plan,proof=self.fixture();plan['helpers']['normal_runtime_build_receipt']['sha256']='a'*64
        with self.assertRaises(ValueError):driver.validate_normal_pcm_proof(plan,proof)


if __name__=='__main__':unittest.main()
