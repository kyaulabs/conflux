"""Current-source provenance checks only; no native process/model/host queries."""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch
from test_host_player import driver


class CurrentBuildTests(unittest.TestCase):
    def fixture(self):
        plan=json.loads(driver.PLAN.read_text())
        rows=[plan['build_receipt'],plan['source_build_attestation'],plan['helpers']['compile_commands'],
              plan['helpers']['build_cache'],plan['helpers']['exact_pcm_prerequisite'],
              plan['helpers']['normal_runtime_build_receipt']]
        data={row['path']:Path(row['path']).read_bytes() for row in rows}
        def read(path,*args,**kwargs):
            return {'sha256':'a'*64},data[str(path)] if kwargs.get('keep') else None
        return plan,data,read

    def test_current_build_and_actual_sources_pass_without_snapshot_aliases(self):
        plan,data,read=self.fixture()
        with patch.object(driver,'pin_read',side_effect=read) as reader:
            driver.verify_files(plan)
        paths={str(call.args[0]) for call in reader.call_args_list}
        self.assertTrue(all(row['path'] in paths for row in plan['source_pins']))
        self.assertIn(str(driver.W/'tools/experiments/WindowEventHistory.hpp'),paths)

    def test_stale_source_wrong_binary_or_changed_attestation_is_rejected(self):
        for label in ('source','binary','attestation'):
            plan,data,read=self.fixture()
            if label=='attestation':
                path=plan['source_build_attestation']['path'];value=json.loads(data[path]);value['source_pins'][0]['sha256']='a'*64
            else:
                path=plan['build_receipt']['path'];value=json.loads(data[path])
                if label=='source':value['source_head']='119a579e4ca717a1d59d7a7a6f9752534d68dcaf'
                else:value['binary']['sha256']='a'*64
            data[path]=json.dumps(value).encode()
            with self.subTest(label=label),patch.object(driver,'pin_read',side_effect=read),self.assertRaises(ValueError):
                driver.verify_files(plan)

    def test_optimization_or_instrumentation_flag_drift_is_rejected(self):
        for flag in ('-O3','--coverage','-ffast-math'):
            plan,data,read=self.fixture();path=plan['helpers']['compile_commands']['path'];value=json.loads(data[path])
            value[0]['command']+=' '+flag;data[path]=json.dumps(value).encode()
            with self.subTest(flag=flag),patch.object(driver,'pin_read',side_effect=read),self.assertRaises(ValueError):
                driver.verify_files(plan)

    def test_attested_source_cannot_escape_the_current_worktree(self):
        plan,data,read=self.fixture();old=plan['source_pins'][0]['path'];row=copy.deepcopy(plan['source_pins'][0]);row['path']='/outside/source.cpp'
        plan['source_pins'][0]=row;del plan['sources'][old];plan['sources'][row['path']]=row
        path=plan['source_build_attestation']['path'];value=json.loads(data[path]);value['source_pins']=plan['source_pins'];data[path]=json.dumps(value).encode()
        with patch.object(driver,'pin_read',side_effect=read),self.assertRaises(ValueError):driver.verify_files(plan)


if __name__=='__main__':unittest.main()
