import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cpu_trace_driver', BASE / 'run_host_player.py')
driver = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = driver
spec.loader.exec_module(driver)


def stat_line(pid, name='worker', *, user=10, system=4, threads=3, start=90):
    fields = ['0'] * 22
    fields[0] = 'S'
    for i, value in ((1, 2), (11, user), (12, system), (13, 99999), (14, 88888), (17, threads), (19, start)):
        fields[i] = str(value)
    return f'{pid} ({name}) ' + ' '.join(fields)


class ProcessCpuTests(unittest.TestCase):
    def test_process_totals_ignore_child_counters_and_accept_parenthesized_names(self):
        row = driver.parse_process_stat(stat_line(15, 'worker ) (busy)'), 15)
        self.assertEqual(row, {'pid': 15, 'comm': 'worker ) (busy)', 'ppid': 2,
                              'cpu_ticks': 14, 'threads': 3, 'start_ticks': 90})

    def test_malformed_mismatched_and_oversized_stat_is_rejected(self):
        for raw, pid in ((stat_line(15), 16), ('15 (x) S', 15), ('x' * 16385, 15),
                         (stat_line(15, user=-1), 15), (stat_line(15, threads=0), 15),
                         (stat_line(15, start=0), 15)):
            with self.subTest(raw=raw[:60]), self.assertRaises(ValueError):
                driver.parse_process_stat(raw, pid)

    def test_same_lifetime_rate_uses_process_cpu_and_elapsed_interval(self):
        before = driver.parse_process_stat(stat_line(15, user=100), 15)
        after = driver.parse_process_stat(stat_line(15, user=150), 15)
        self.assertEqual(driver.process_cpu_delta(before, after, 2_000_000_000, 100), .25)

    def test_first_seen_reused_regressed_and_invalid_intervals_have_no_rate(self):
        before = driver.parse_process_stat(stat_line(15), 15)
        for old, after, interval, hz in ((None, before, 2, 100),
                (before, {**before, 'start_ticks': 91}, 2, 100),
                (before, {**before, 'pid': 16}, 2, 100),
                (before, {**before, 'cpu_ticks': 0}, 2, 100),
                (before, before, 0, 100), (before, before, -1, 100),
                (before, before, 2, 0)):
            self.assertIsNone(driver.process_cpu_delta(old, after, interval, hz))

    def test_fixture_scan_preserves_lifetimes_and_observer_cost(self):
        with tempfile.TemporaryDirectory() as directory:
            proc = Path(directory)
            for pid in (15, 20):
                (proc / str(pid)).mkdir()
                (proc / str(pid) / 'stat').write_text(stat_line(pid))
            with (patch.object(driver.time, 'monotonic_ns', side_effect=[1_000_000_000, 1_010_000_000, 1_020_000_000, 1_030_000_000]),
                  patch.object(driver.time, 'thread_time_ns', side_effect=[1000, 1500]),
                  patch.object(driver.os, 'sysconf', return_value=100)):
                first = driver.capture_process_cpu(None, proc)
            self.assertEqual(first['scan_thread_cpu_ns'], 500)
            self.assertEqual(first['read_error_count'], 0)
            self.assertTrue(all(r['cpu_cores_since_previous_observation'] is None for r in first['processes']))
            (proc / '15/stat').write_text(stat_line(15, user=60))
            (proc / '20/stat').write_text(stat_line(20, user=60, start=100))
            with (patch.object(driver.time, 'monotonic_ns', side_effect=[3_000_000_000, 3_010_000_000, 3_020_000_000, 3_030_000_000]),
                  patch.object(driver.time, 'thread_time_ns', side_effect=[2000, 2700]),
                  patch.object(driver.os, 'sysconf', return_value=100)):
                second = driver.capture_process_cpu(first, proc)
            self.assertEqual(second['processes'][0]['cpu_cores_since_previous_observation'], .25)
            self.assertIsNone(second['processes'][1]['cpu_cores_since_previous_observation'])
            self.assertEqual(second['scan_thread_cpu_ns'], 700)

    def test_exited_or_unreadable_process_is_reported_without_invented_cpu(self):
        with tempfile.TemporaryDirectory() as directory:
            proc = Path(directory)
            (proc / '15').mkdir()
            (proc / 'self').mkdir()
            row = driver.capture_process_cpu(None, proc)
            self.assertEqual(row['processes'], [])
            self.assertEqual(row['read_error_count'], 1)
            self.assertEqual(row['read_error_examples'][0]['pid'], 15)

    def test_pid_bound_is_enforced_before_stat_reads(self):
        with patch.object(Path, 'iterdir', return_value=[Path('/fixture') / str(i) for i in range(4097)]):
            with self.assertRaisesRegex(ValueError, '4096 PID bound'):
                driver.capture_process_cpu(None, Path('/fixture'))


if __name__ == '__main__':
    unittest.main()
