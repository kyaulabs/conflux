"""Balanced packet rejects the retired policy and never requests a profile writer."""
import copy,json,unittest
from unittest.mock import patch
import test_host_player as fixtures
driver=fixtures.driver

class BalancedReadOnlyTests(unittest.TestCase):
 def test_real_plan_requires_balanced_and_rejects_retired_or_relaxed_policy(self):
  plan=json.loads(driver.PLAN.read_text());driver.validate_plan(plan)
  for changes in [{'requested_power_profile':'performance'},{'allow_natural_power_saver_start':True}]:
   with self.subTest(changes=changes),self.assertRaises(ValueError):driver.validate_plan({**plan,**changes})
 def test_25W_override_is_rejected_but_guard_reduction_is_preserved(self):
  path='/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_power_limit_uw'
  self.assertEqual(driver.CAP_CEILINGS[path],15000000)
  for watts in [15000000,7500000]:driver.validate_power_caps({**driver.CAP_CEILINGS,path:watts})
  for watts in [15000001,25000000,64000000]:
   with self.subTest(watts=watts),self.assertRaises(ValueError):driver.validate_power_caps({**driver.CAP_CEILINGS,path:watts})
 def test_complete_player_path_has_no_profile_selection_or_restoration(self):
  with patch.object(driver,'read_power_caps',return_value=copy.deepcopy(driver.CAP_CEILINGS)):
   code,report=fixtures.CompletedRunCaptureTests().exercise()
  self.assertEqual(code,0);self.assertTrue(report['diagnostic_complete'])
  self.assertFalse(report['power_policy_changed_by_test'])
  self.assertEqual(report['requested_power_profile'],'balanced')
  self.assertNotIn('profile_selection',report);self.assertNotIn('profile_restoration',report)

if __name__=='__main__':unittest.main()
