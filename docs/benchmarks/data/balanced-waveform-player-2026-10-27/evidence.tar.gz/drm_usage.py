"""Read-only DRM fdinfo capture for an exact owned process lifetime."""
from pathlib import Path
import os
import re
import time

KEY = re.compile(r'drm-(?:driver|pdev|client-id|engine-[A-Za-z0-9_-]+|cycles-[A-Za-z0-9_-]+|total-cycles-[A-Za-z0-9_-]+|maxfreq-[A-Za-z0-9_-]+)')
MAXIMUM_FDS = 256
MAXIMUM_BYTES_PER_FD = 65536


def fields(raw):
    if len(raw) > MAXIMUM_BYTES_PER_FD:
        raise ValueError('DRM fdinfo exceeds byte bound')
    result = {}
    lines = raw.decode('utf-8').splitlines()
    if len(lines) > 512:
        raise ValueError('DRM fdinfo exceeds line bound')
    for line in lines:
        key, separator, value = line.partition(':')
        if not separator or not KEY.fullmatch(key):
            continue
        value = value.strip()
        if key in result or not value or len(value) > 256:
            raise ValueError('Duplicate/empty/oversized DRM field')
        result[key] = value
    if 'drm-client-id' in result and not re.fullmatch(r'[0-9]+', result['drm-client-id']):
        raise ValueError('Invalid DRM client identity')
    return result


def capture(process, expected_exe, parse_stat, proc_root=Path('/proc')):
    began = time.monotonic_ns()
    report = dict(pid=process['pid'], process_start_ticks=process['start_ticks'],
        began_monotonic_ns=began, matched_expected_exe=False, complete=False,
        clients=[], missing_client_identity_fds=[], errors=[], error_count=0)
    directory = proc_root / str(process['pid'])
    def check_identity():
        if directory.stat().st_uid != os.getuid():
            raise ValueError('DRM process user differs')
        if (directory/'exe').resolve(strict=True) != expected_exe.resolve(strict=True):
            raise ValueError('DRM executable changed')
        with (directory/'stat').open('r') as stream:
            row = parse_stat(stream.read(16385), process['pid'])
        if row['start_ticks'] != process['start_ticks']:
            raise ValueError('DRM process lifetime changed')
    try:
        if (directory/'exe').resolve(strict=True) != expected_exe.resolve(strict=True):
            return report
        report['matched_expected_exe'] = True
        check_identity()
        paths = sorted((p for p in (directory/'fdinfo').iterdir() if p.name.isdecimal()), key=lambda p:int(p.name))
        if len(paths) > MAXIMUM_FDS:
            raise ValueError('DRM descriptor count exceeds bound')
        grouped = {}
        for path in paths:
            try:
                with path.open('rb') as stream:
                    value = fields(stream.read(MAXIMUM_BYTES_PER_FD+1))
                if not value:
                    continue
                if 'drm-driver' not in value or 'drm-client-id' not in value:
                    report['missing_client_identity_fds'].append(int(path.name))
                    continue
                # Per kernel ABI, IDs are device scoped when pdev is supplied,
                # otherwise global. Keep duplicates as observations of ONE
                # client, never as additive engine usage.
                key = (value['drm-driver'], value.get('drm-pdev'), value['drm-client-id'])
                if key not in grouped:
                    grouped[key] = dict(driver=key[0], pdev=key[1], client_id=key[2], observations=[])
                grouped[key]['observations'].append(dict(fd=int(path.name),
                    observed_monotonic_ns=time.monotonic_ns(), fields=value))
            except (OSError, ValueError, UnicodeError) as error:
                report['error_count'] += 1
                if len(report['errors']) < 8:
                    report['errors'].append(dict(fd=int(path.name), type=type(error).__name__, message=str(error)[:256]))
        check_identity()
        report['clients'] = list(grouped.values())
        report['descriptor_count'] = len(paths)
        report['complete'] = report['error_count'] == 0 and not report['missing_client_identity_fds']
    except (OSError, ValueError) as error:
        report['clients'] = []
        report['error_count'] += 1
        report['errors'].append(dict(type=type(error).__name__, message=str(error)[:256]))
    finally:
        report['finished_monotonic_ns'] = time.monotonic_ns()
        report['scope'] = ('Raw driver-exported per-client fields with original units. Duplicate FDs are observations of one client, not additive usage. Missing fields are unavailable, not zero. Counter regressions must retain the prior high-water value in later analysis. Busy time is not frequency-normalized or an exact request/kernel/queue duration. No kernel, scheduling or power settings changed.')
    return report
