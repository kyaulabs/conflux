from pathlib import Path
import gzip,hashlib,io,json,tarfile
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
original=BASE.parent/'m2-waveform-player-comparison-06'
paths=[p for p in BASE.rglob('*') if p.is_file() and not p.is_symlink() and p.suffix in ['.py','.json','.jsonl','.log','.txt'] and not set(p.relative_to(BASE).parts).intersection({'driver-cache','publication-input'})]
assert not (BASE/'publication-input').exists()
inputs=BASE/'publication-input';inputs.mkdir()
members={str(p.relative_to(BASE)):p.read_bytes() for p in paths}
for relative in ['build-pair-receipt-01.json','baseline/source-manifest-01.json','candidate/source-manifest-01.json','cases/baseline/build-receipt-01.json','cases/candidate/build-receipt-01.json','cases/baseline/source-build-attestation-01.json','cases/candidate/source-build-attestation-01.json']:
 members['original-builds/'+relative]=(original/relative).read_bytes()
selection=dict(scope='Complete current packet text, including failed setup checks, both full service observations, host samples, native/result/capture logs, cleanup, source manifests and analysis. Excludes WAV/audio, model/binary and driver-cache payloads. No measurement rows filtered.',excluded_payloads=['*.wav','driver-cache/**'],source_commits={'baseline':'c3105dfd7f3ad0d710f51fba594f7847e32e3906','candidate':'894bcda423b75debc2f3a07d761d63b5083e5729'})
members['publication-selection.json']=(json.dumps(selection,indent=2)+'\n').encode()
rows=[]
for name,raw in sorted(members.items()):
 assert not name.startswith('/') and '..' not in Path(name).parts;raw.decode('utf-8')
 p=inputs/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);rows.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
manifest=dict(schema=1,source='M2 Balanced waveform comparison 07, 2026-10-27',files=rows,selection=selection)
raw=(json.dumps(manifest,indent=2)+'\n').encode();(inputs/'manifest.json').write_bytes(raw)
archive=BASE/'evidence-01.tar.gz'
with archive.open('xb') as stream:
 with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for name,data in sorted({**members,'manifest.json':raw}.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert all(x.isfile() for x in tar.getmembers())
 for row in rows:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt=dict(files=len(rows),plaintext_bytes=sum(x['bytes'] for x in rows),archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),all_members_verified=True)
(BASE/'evidence-verification-01.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
