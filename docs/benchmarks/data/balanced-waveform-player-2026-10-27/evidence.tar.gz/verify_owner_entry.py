"""Actual desktop wrapper, dry owner only: no readiness, player, model or audio."""
from datetime import datetime, timezone
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
CASE = BASE / 'cases/candidate'
UNIT = 'conflux-m2-gpu-client-usage-20261026-03.service'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    assert not (CASE / 'readiness.json').exists()
    owner = CASE / 'run_player_owned.py'
    assert owner.stat().st_mode & 0o111 and os.access(owner, os.X_OK)
    args = ['/usr/bin/kde-inhibit', '--power', '--screenSaver']
    result = subprocess.run(args + [str(owner)], cwd=BASE, capture_output=True, text=True, timeout=10)
    result.check_returncode()
    dry = json.loads(result.stdout)
    assert dry['status'] == 'unarmed_dry_owner' and dry['native_started'] is False
    assert dry['host_queried'] is False and not result.stderr
    # Exercise the real armed entry through KDE too. With no human file it
    # must pass frozen-plan/owner bindings and stop at the readiness read,
    # which precedes dispatch, inhibition queries, player and model startup.
    armed_without_human = subprocess.run(args + [str(owner), '--run'], cwd=BASE,
        capture_output=True, text=True, timeout=10)
    assert armed_without_human.stdout == ''
    assert 'FileNotFoundError' in armed_without_human.stderr
    assert str(CASE / 'readiness.json') in armed_without_human.stderr
    assert 'Draft packet is unarmed' not in armed_without_human.stderr
    # Prove this KDE wrapper's observed zero exit did not establish child exec.
    fixture = BASE / 'dry-permission-fixture.py'
    with fixture.open('x') as stream:
        stream.write('#!/usr/bin/python3.14 -I\nprint("harmless dry fixture executed")\n')
    fixture.chmod(0o644)
    denied = subprocess.run(args + [str(fixture)], capture_output=True, text=True, timeout=10)
    assert denied.stdout == ''
    fixture.chmod(0o755)
    allowed = subprocess.run(args + [str(fixture)], capture_output=True, text=True, timeout=10)
    allowed.check_returncode()
    assert allowed.stdout == 'harmless dry fixture executed\n' and not allowed.stderr
    fixture.chmod(0o644)
    spec = importlib.util.spec_from_file_location('verified_dry_gpu_entry', BASE / 'launch_case.py')
    entry = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(entry)
    output = io.StringIO()
    with patch.object(sys, 'argv', ['launch_case.py']), contextlib.redirect_stdout(output):
        entry.main()
    assert json.loads(output.getvalue())['native_started'] is False
    with patch.object(sys, 'argv', ['launch_case.py', '--run']), \
            patch.object(entry, 'show', side_effect=AssertionError('Unexpected host query')) as show, \
            patch.object(entry.subprocess, 'run', side_effect=AssertionError('Unexpected launch')) as run, \
            patch.object(entry.subprocess, 'check_output', side_effect=AssertionError('Unexpected host query')) as check:
        try:
            entry.main()
        except FileNotFoundError as error:
            assert Path(error.filename) == CASE / 'readiness.json'
        else:
            raise AssertionError('Unarmed actual entry did not require fresh readiness')
    assert show.call_count == run.call_count == check.call_count == 0
    command = ['busctl', '--user', '--timeout=2s', '--json=short', 'call',
        'org.kde.Solid.PowerManagement.PolicyAgent', '/org/kde/Solid/PowerManagement/PolicyAgent',
        'org.kde.Solid.PowerManagement.PolicyAgent', 'ListInhibitions']
    inhibition = json.loads(subprocess.check_output(command, text=True, timeout=4))
    assert inhibition['type'] == 'aas'
    assert not any(row[1] in (str(owner), str(fixture)) for row in inhibition['data'][0])
    unit = subprocess.check_output(['systemctl', '--user', 'show', UNIT,
        '--property=LoadState,MainPID,ControlGroup'], text=True, timeout=4)
    assert 'LoadState=not-found' in unit and 'MainPID=0' in unit
    assert not any((CASE / name).exists() for name in
        ('readiness.json', 'root-dispatch-reservation-01.json', 'dispatch-01.json', 'output-01'))
    report = dict(schema=1, verified_at_utc=datetime.now(timezone.utc).isoformat(),
        wrapper_dry_owner=dry, direct_owner_mode=oct(owner.stat().st_mode), owner=pin(owner),
        nonexecutable_harmless_fixture=dict(returncode=denied.returncode, stdout=denied.stdout, stderr=denied.stderr),
        executable_harmless_fixture=dict(returncode=allowed.returncode, stdout=allowed.stdout, stderr=allowed.stderr),
        root_default_dry_verified=True, root_run_without_readiness_stops_before_host_query_or_launch=True,
        real_owner_armed_entry_reaches_required_fresh_readiness_boundary=True,
        armed_owner_without_human=dict(returncode=armed_without_human.returncode,
            stderr=armed_without_human.stderr),
        root_launcher=pin(BASE / 'launch_case.py'), plan=pin(CASE / 'plan.json'),
        own_idle_inhibitions_remaining=0, unit_not_created=True, native_started=False,
        audio_started=False, GPU_started=False, old_readiness_reused=False,
        verification=pin(Path(__file__).resolve()))
    with (BASE / 'actual-owner-entry-check-01.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(dry_owner_executed=True, permission_failure_reproduced=True,
        root_unarmed_entry_verified=True, native_started=False, own_idle_inhibitions_remaining=0)))


if __name__ == '__main__':
    main()
