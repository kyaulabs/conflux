"""Draft tests and offscreen native checks, before any frozen entry or readiness."""
from pathlib import Path
import json,subprocess,time
BASE=Path(__file__).resolve().parent
ORIGINAL=BASE.parent/'m2-waveform-player-comparison-06'
report=dict(schema=1,arms={},details={},readiness_created=False,player_or_model_benchmark_started=False)
def run(name,command):
 start=time.monotonic();path=BASE/(name+'.log')
 with path.open('x') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 row=dict(passed=r.returncode==0,exit=r.returncode,seconds=time.monotonic()-start,log=str(path))
 print(json.dumps(dict(name=name,**row)),flush=True)
 if r.returncode:print(path.read_text()[-4500:],flush=True)
 return row
for arm in ['baseline','candidate']:
 case=BASE/'cases'/arm;report['arms'][arm]={};report['details'][arm]={}
 row=run(arm+'-offline-core-02',['python','-B','-m','unittest','discover','-s',str(case),'-p','test_*.py','-v'])
 report['arms'][arm]['offline_core']=row['passed'];report['details'][arm]['offline_core']=row
 row=run(arm+'-file-verification-02',['python','-B',str(case/'run_host_player.py'),'--verify-files'])
 report['arms'][arm]['file_verification']=row['passed'];report['details'][arm]['file_verification']=row
 if not all(report['arms'][arm].values()):break
if len(report['arms'])==2 and all(all(v.values()) for v in report['arms'].values()):
 code="import pathlib,sys,unittest;p=pathlib.Path(sys.argv[1]);sys.path.insert(0,str(p));s=unittest.defaultTestLoader.discover(str(p),pattern='test_*.py');filter_suite=lambda t:unittest.TestSuite(filter_suite(x) for x in t if not (isinstance(x,unittest.TestCase) and x.__class__.__name__=='ActualFrozenOwnerTests')) if isinstance(t,unittest.TestSuite) else t;r=unittest.TextTestRunner(verbosity=2).run(filter_suite(s));raise SystemExit(0 if r.wasSuccessful() else 1)"
 row=run('draft-root-offline-02',['python','-B','-c',code,str(BASE)]);report['root_offline']=row
 if row['passed']:
  for arm in ['baseline','candidate']:
   row=run(arm+'-native-offscreen-02',['ctest','--test-dir',str(ORIGINAL/arm/'native'),'--output-on-failure','-R','^(deck-controller|manual-ui)$'])
   report['arms'][arm]['native_offscreen']=row['passed'];report['details'][arm]['native_offscreen']=row
report['passed']=(set(report['arms'])=={'baseline','candidate'} and all(set(v)=={'offline_core','file_verification','native_offscreen'} and all(v.values()) for v in report['arms'].values()) and report.get('root_offline',{}).get('passed',False))
with (BASE/'offline-build-checks-02.json').open('x') as f:f.write(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if report['passed'] else 1)
