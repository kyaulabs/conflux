"""Exercise clock renewal, incomplete-arm and cleanup rejection without hardware."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

from pair_clock import validate_pair, validate_initial_cache


class PairClockTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.shared = dict(schema=1, order=['baseline','candidate'], operator_seconds=1200,
            retries=False, original_readiness_monotonic=100., operator_deadline_monotonic=1300.,
            original_readiness_utc='2026-10-27T00:00:00+00:00',
            question_item_id='offline-generated-fixture', human_reply='ready for both')
        self.human = dict(recorded_at_utc=self.shared['original_readiness_utc'],
            recorded_at_monotonic=100., question_item_id=self.shared['question_item_id'],
            human_reply=self.shared['human_reply'])
        self.write(self.base/'pair-readiness-received-01.json', self.shared)
        first=self.base/'cases/baseline';first.mkdir(parents=True)
        self.closed=dict(cleanup_complete=True, requested120s_complete=True,
            operator_deadline_monotonic=1300., original_readiness_monotonic=100.,
            original_readiness_utc=self.shared['original_readiness_utc'], root_verification_monotonic=350.)
        self.write(first/'root-finished-01.json',self.closed)
        self.write(first/'diagnostic-assessment.json',dict(diagnostic_complete=True))

    def write(self,path,value):
        path.write_text(json.dumps(value)+'\n')

    def test_both_arms_keep_original_origin_and_deadline(self):
        before=(self.base/'pair-readiness-received-01.json').read_bytes()
        for arm,now in [('baseline',100.),('candidate',400.)]:
            self.assertEqual(validate_pair(self.base,self.human,arm,now),self.shared)
        self.assertEqual(before,(self.base/'pair-readiness-received-01.json').read_bytes())

    def test_conservatively_shortened_baseline_deadline_allows_candidate(self):
        self.write(self.base/'cases/baseline/root-finished-01.json',
            {**self.closed,'operator_deadline_monotonic':1299.853332219})
        self.assertEqual(validate_pair(self.base,self.human,'candidate',400.),self.shared)

    def test_renewed_origin_extended_deadline_or_late_cleanup_blocks_candidate(self):
        for change in [dict(original_readiness_monotonic=101.),
                dict(original_readiness_utc='2026-10-27T00:00:01+00:00'),
                dict(operator_deadline_monotonic=1300.000001),
                dict(operator_deadline_monotonic=349.999),
                dict(root_verification_monotonic=99.),
                dict(operator_deadline_monotonic=float('nan'))]:
            self.write(self.base/'cases/baseline/root-finished-01.json',{**self.closed,**change})
            with self.subTest(change=change),self.assertRaises(AssertionError):
                validate_pair(self.base,self.human,'candidate',400.)

    def test_candidate_cannot_gain_time_by_replacing_its_timestamp(self):
        for key,value in [('recorded_at_utc','2026-10-27T00:05:00+00:00'),
                ('recorded_at_monotonic',400.),('question_item_id','another-reply'),
                ('human_reply','ready again')]:
            human={**self.human,key:value}
            with self.subTest(key=key),self.assertRaises(AssertionError):
                validate_pair(self.base,human,'candidate',400.)

    def test_old_or_future_pair_is_rejected(self):
        for now in [99.,700.001,1301.]:
            with self.subTest(now=now),self.assertRaises(AssertionError):
                validate_pair(self.base,self.human,'candidate',now)

    def test_missing_or_incomplete_baseline_blocks_candidate(self):
        path=self.base/'cases/baseline/root-finished-01.json'
        for key in ['cleanup_complete','requested120s_complete']:
            self.write(path,{**self.closed,key:False})
            with self.subTest(key=key),self.assertRaises(AssertionError):
                validate_pair(self.base,self.human,'candidate',400.)
        path.unlink()
        with self.assertRaises(FileNotFoundError):
            validate_pair(self.base,self.human,'candidate',400.)

    def test_latency_failure_can_be_compared_when_evidence_and_cleanup_complete(self):
        self.write(self.base/'cases/baseline/diagnostic-assessment.json',
            dict(diagnostic_complete=True,passed=False))
        self.assertEqual(validate_pair(self.base,self.human,'candidate',400.),self.shared)

    def test_changed_order_retry_or_deadline_is_rejected(self):
        for change in [dict(order=['candidate','baseline']),dict(retries=True),
                dict(operator_deadline_monotonic=1400.)]:
            self.write(self.base/'pair-readiness-received-01.json',{**self.shared,**change})
            with self.subTest(change=change),self.assertRaises(AssertionError):
                validate_pair(self.base,self.human,'baseline',100.)

    def test_cache_change_extra_file_and_symlink_are_rejected(self):
        case=self.base/'cases/baseline';cache=case/'driver-cache';cache.mkdir()
        self.write(case/'driver-cache-initial-01.json',dict(files=[]))
        validate_initial_cache(case)
        file=cache/'shader';file.write_bytes(b'generated cache fixture')
        with self.assertRaisesRegex(AssertionError,'cache changed'):
            validate_initial_cache(case)
        file.unlink();file.symlink_to(case/'driver-cache-initial-01.json')
        with self.assertRaisesRegex(AssertionError,'regular private files'):
            validate_initial_cache(case)


if __name__=='__main__':unittest.main()
