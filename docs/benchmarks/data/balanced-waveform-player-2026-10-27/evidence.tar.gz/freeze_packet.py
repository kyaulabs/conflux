"""Freeze verified files; no readiness, host mutation, player or model launch."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
ORIGINAL = ROOT/'build/m2-waveform-player-comparison-06'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path,value):
    with path.open('x') as stream:
        stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def main():
    offline=json.loads((BASE/'offline-build-checks-02.json').read_text())
    assert offline['passed'] is True and offline['root_offline']['passed'] is True
    final_python=json.loads((BASE/'final-python-checks-03.json').read_text())
    assert set(final_python)=={'baseline','candidate'}
    assert all(set(v)=={'core','files'} and all(r['passed'] is True for r in v.values()) for v in final_python.values())
    assert all(all(v.values()) for v in offline['arms'].values())
    build=json.loads((BASE/'build-pair-receipt-01.json').read_text())
    assert set(build['production_differences'])=={
        'qml/DeckSurface.qml','src/ui/DeckController.cpp','src/ui/DeckController.hpp'}
    first_cache=None
    for arm in ['baseline','candidate']:
        case=BASE/'cases'/arm
        assert not any((case/name).exists() for name in ['readiness.json','output-01',
            'root-unit-dispatch-01.json','dispatch-01.json'])
        manifest=json.loads((ORIGINAL/arm/'source-manifest-01.json').read_text())
        for row in manifest['files']:
            actual=pin(Path(row['path']))
            assert all(actual[k]==row[k] for k in actual),row['path']
        assert pin(Path(build['arms'][arm]['binary']['path']))==build['arms'][arm]['binary']
        cache=json.loads((case/'driver-cache-initial-01.json').read_text())['files']
        if first_cache is None:first_cache=cache
        else:assert cache==first_cache
        for p in case.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
        owner=case/'run_player_owned.py'
        assert owner.stat().st_mode&0o111
        assert re.search(r"LAUNCHER_SHA = '([0-9a-f]{64})'",owner.read_text())[1]==pin(case/'run_host_player.py')['sha256']
        path=case/'plan.json';plan=json.loads(path.read_text())
        assert plan['status']=='draft_unarmed_pending_root_review'
        assert plan['seconds']==120 and plan['operator_seconds']==1200 and plan['command_seconds']==540
        plan['status']='frozen_pending_fresh_readiness'
        path.write_text(json.dumps(plan,indent=2)+'\n')
        path=case/'root-launch-plan-01.json';launch=json.loads(path.read_text())
        launch['plan']=pin(case/'plan.json')
        path.write_text(json.dumps(launch,indent=2)+'\n')
        paths=[BASE/'launch_case.py',BASE/'pair_clock.py',BASE/'test_pair_clock.py',
            BASE/'check_desktop_entry.py',BASE/'freeze_packet.py',
            BASE/'build-pair-receipt-01.json',ORIGINAL/arm/'source-manifest-01.json',
            BASE/'offline-build-checks-02.json',BASE/'final-python-checks-03.json',
            BASE/'user-gate-decision-01.json',case/'plan.json',case/'root-launch-plan-01.json',
            case/'driver-cache-initial-01.json',case/'run_host_player.py',owner,
            case/'close_case.py',case/'launch-command-01.txt']
        save(case/'root-launch-clearance-01.json',dict(schema=1,pins=[pin(p) for p in paths],
            native_started=False,readiness_created=False,one_factor_verified=True,
            source_snapshot_complete_and_binary_build_verified=True,
            original_pair_seconds=1200,no_direct_powercap_writes=True,
            authorized_profile_selection=None,authorized_long_term_ceiling_uw=15000000))
    save(BASE/'freeze-verification-01.json',dict(schema=1,
        status='frozen_pending_real_entry_checks_and_fresh_human_conditions',
        build_receipt=pin(BASE/'build-pair-receipt-01.json'),
        source_files_verified={k:len(json.loads((ORIGINAL/k/'source-manifest-01.json').read_text())['files']) for k in ['baseline','candidate']},
        production_differences=build['production_differences'],same_initial_driver_cache_files=len(first_cache),
        fixed_best_runtime=True,authorized_long_term_ceiling_uw=15000000,
        requested_power_profile='balanced',no_profile_or_cap_writes=True,thermal_guard_unchanged=True,
        player_started=False,model_started=False,readiness_created=False,
        hard_cancellation_exercised=False,qualified=False))
    print('Both arms frozen. No readiness recorded; real entry checks remain.')


if __name__=='__main__':main()
