"""Replay the real pre-dispatch 72C failure at every dispatch boundary offline."""
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
PHASES = ('cooldown_complete', 'before_dispatch',
          'public_readiness_before_setup', 'public_readiness_before_Popen')


def fixture(directory, name):
    spec = importlib.util.spec_from_file_location(name, directory / 'test_host_player.py')
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


class FreshTemperatureTests(unittest.TestCase):
    def exercise(self, module, phase, *, sensor='observed_temps', persistent=False,
                 mutation=None, working_deadline=None):
        plan, clock, state, timing, loader = module.AdmissionTests.setup_mock(self, temp=50000)
        plan['requested_power_profile'] = 'balanced'
        report = {}
        error = result = None
        with patch.object(module.driver, 'load_source', side_effect=loader), \
                patch.object(module.driver, 'time', timing):
            fresh, recovery, cooldown = module.driver.prepare_admission(plan, report, 500, 1, lambda: None)
            recovery(); cooldown()
            state.update(profile='balanced', platform='balanced', epp='balance_performance',
                         temp=50000, observed_temp=50000)
            if persistent:
                state['observed_temp' if sensor == 'observed_temps' else 'temp'] = 72000
            else:
                state[sensor] = [72000, 50000]
            if mutation:
                state.update(mutation)
            try:
                result = fresh(phase, thermal_work_deadline=working_deadline)
            except ValueError as problem:
                error = str(problem)
        return report, clock[0], error, result

    def test_both_sensors_settle_at_all_four_phases_for_both_arms(self):
        for arm in ['baseline', 'candidate']:
            current = fixture(BASE / 'cases' / arm, 'current_fresh_' + arm)
            for phase in PHASES:
                for sensor in ['capture_temps', 'observed_temps']:
                    with self.subTest(arm=arm, phase=phase, sensor=sensor):
                        report, clock, error, result = self.exercise(current, phase, sensor=sensor)
                        self.assertIsNone(error)
                        self.assertTrue(result['accepted'])
                        self.assertEqual(clock, 62)
                        first, second = report['fresh_admissions']
                        self.assertEqual(first['rejection_kind'], 'temperature_only')
                        self.assertFalse(first['accepted'])
                        self.assertTrue(second['accepted'])
                        self.assertEqual(report['cooldown_deadline'], 301)

    def test_persistent_heat_fails_within_original_five_seconds_at_every_phase(self):
        current = fixture(BASE / 'cases/baseline', 'persistent_fresh')
        for phase in PHASES:
            with self.subTest(phase=phase):
                report, clock, error, result = self.exercise(current, phase, persistent=True)
                self.assertIsNone(result)
                self.assertIn('heat-only', error)
                self.assertLessEqual(clock, 66)
                self.assertLessEqual(len(report['fresh_admissions']), 6)
                self.assertTrue(all(not row['accepted'] for row in report['fresh_admissions']))

    def test_nonthermal_faults_are_fatal_without_waiting_for_heat(self):
        current = fixture(BASE / 'cases/baseline', 'fatal_fresh')
        changes = [{'invocation': 'b' * 32}, {'ac': False}, {'lid': False},
                   {'holds': 'other hold'}, {'epp': 'power'}, {'profile': 'power-saver'},
                   {'read_errors': {'temperature': 'read failed'}},
                   {'observer_errors': [{'error': 'read failed'}]}]
        for phase in PHASES:
            for change in changes:
                with self.subTest(phase=phase, change=change):
                    report, clock, error, result = self.exercise(current, phase, mutation=change)
                    self.assertIsNotNone(error)
                    self.assertIsNone(result)
                    self.assertEqual(clock, 61)
                    self.assertEqual(len(report['fresh_admissions']), 1)
                    self.assertEqual(report['fresh_admissions'][0]['rejection_kind'], 'fatal')

    def test_settling_cannot_extend_native_work_reserve(self):
        current = fixture(BASE / 'cases/baseline', 'reserve_fresh')
        for phase in PHASES:
            with self.subTest(phase=phase):
                report, clock, error, result = self.exercise(current, phase,
                    persistent=True, working_deadline=61.5)
                self.assertIsNone(result)
                self.assertIn('native working room', error)
                self.assertEqual(clock, 61.5)
                self.assertFalse(any(row['accepted'] for row in report['fresh_admissions']))

    def test_all_four_checks_share_the_original_clock_and_retain_every_hot_sample(self):
        current = fixture(BASE / 'cases/baseline', 'sequential_fresh')
        plan, clock, state, timing, loader = current.AdmissionTests.setup_mock(self, temp=50000)
        plan['requested_power_profile'] = 'balanced'
        report = {}
        with patch.object(current.driver, 'load_source', side_effect=loader), \
                patch.object(current.driver, 'time', timing):
            fresh, recovery, cooldown = current.driver.prepare_admission(plan, report, 500, 1, lambda: None)
            recovery(); cooldown()
            state.update(profile='balanced', platform='balanced', epp='balance_performance', observed_temp=50000)
            for phase in PHASES:
                state['capture_temps'] = [72000] * 4 + [50000]
                self.assertTrue(fresh(phase, thermal_work_deadline=290)['accepted'])
        self.assertEqual(clock[0], 77)
        self.assertEqual(len(report['fresh_admissions']), 20)
        self.assertEqual(sum(row['accepted'] for row in report['fresh_admissions']), 4)
        self.assertEqual(report['cooldown_deadline'], 301)
        self.assertTrue(report['final_temperature_settle']['accepted'])


if __name__ == '__main__':
    unittest.main()
