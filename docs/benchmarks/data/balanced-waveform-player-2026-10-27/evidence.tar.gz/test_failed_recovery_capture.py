"""A completed failed run can be compared; missing hops/close cannot qualify."""
from pathlib import Path
import importlib.util
import unittest

BASE=Path(__file__).resolve().parent
PRIMARY='Playback/EOF/replay or last scheduled recovery incomplete'


def fixture(arm):
    spec=importlib.util.spec_from_file_location('failed_recovery_'+arm,BASE/'cases'/arm/'test_host_player.py')
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value


def pending(output,result):
    native=result['native'];result.update(passed=False,native_exit=1,error=PRIMARY)
    native.update(passed=False,error=PRIMARY,measurement_completion_error=PRIMARY,last_recovery_complete=False)
    native['diagnostic_tail']={'status':'Failed','raw_complete':True,'converter_complete':True,'render_eof':True,
        'drain_state':2,'measured_wall_ms_begin':native['measured_wall_ms'],'measured_wall_ms_end':native['measured_wall_ms'],
        'measured_output_end_begin':native['measurement_end_output_frame'],'measured_output_end_end':native['measurement_end_output_frame'],
        'recording_written_frames_begin':native['recording']['writtenFrames'],'recording_written_frames_end':native['recording']['writtenFrames']}


class FailedRecoveryCaptureTests(unittest.TestCase):
    def test_complete_failed_recovery_stays_failed_with_usable_full_population(self):
        for arm in ['baseline','candidate']:
            with self.subTest(arm=arm):
                module=fixture(arm);case=module.CompletedRunCaptureTests()
                code,report=case.exercise(pending)
                self.assertEqual(code,1)
                self.assertTrue(report['diagnostic_complete'])
                self.assertTrue(report['workload_evidence_complete'])
                self.assertTrue(report['cleanup_complete'])
                self.assertFalse(report['passed'])
                self.assertFalse(report['qualified'])
                self.assertFalse(report['ordinary_assessment']['functional_passed'])
                self.assertIsNotNone(report['ordinary_assessment']['nearest_rank_p99_ms'])
                self.assertFalse(report['measurement']['recovery_completed_within_measurement'])
                self.assertEqual(report['workload_error']['message'],PRIMARY)

    def test_pending_without_completed_tail_or_fixed_boundaries_blocks_comparison(self):
        module=fixture('baseline');case=module.CompletedRunCaptureTests()
        changes=[lambda n:n.pop('measurement_completion_error'),
            lambda n:n.update(passed=True),lambda n:n.update(last_recovery_complete=None),
            lambda n:n['diagnostic_tail'].update(raw_complete=False),
            lambda n:n['diagnostic_tail'].update(converter_complete=False),
            lambda n:n['diagnostic_tail'].update(render_eof=False),
            lambda n:n['diagnostic_tail'].update(drain_state=1),
            lambda n:n['diagnostic_tail'].update(measured_wall_ms_end=123000),
            lambda n:n['diagnostic_tail'].update(measured_output_end_end=9000000),
            lambda n:n['diagnostic_tail'].update(recording_written_frames_end=0),
            lambda n:n['diagnostic_tail'].update(recording_written_frames_begin=0,recording_written_frames_end=0)]
        for change in changes:
            def mutation(output,result):
                pending(output,result);change(result['native'])
            with self.subTest(change=change):
                code,report=case.exercise(mutation)
                self.assertEqual(code,1);self.assertFalse(report['diagnostic_complete'])
                self.assertFalse(report.get('passed',False));self.assertFalse(report['qualified'])

    def test_missing_final_service_close_still_blocks_comparison(self):
        module=fixture('baseline');case=module.CompletedRunCaptureTests()
        def mutation(output,result):
            pending(output,result)
            result['observations']['service_telemetry_loss'].pop()
        code,report=case.exercise(mutation)
        self.assertEqual(code,1);self.assertFalse(report['diagnostic_complete'])
        self.assertFalse(report.get('passed',False));self.assertFalse(report['qualified'])


if __name__=='__main__':unittest.main()
