"""Generated filesystem checks; no player, GPU context, model or audio."""
from pathlib import Path
import importlib.util
import tempfile
import unittest
from unittest.mock import patch

import drm_usage

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
SPEC = importlib.util.spec_from_file_location('wait_driver_drm_fixture',
    ROOT/'build/m2-gpu-completion-client-01/cases/candidate/run_host_player.py')
driver = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(driver)


def stat_line(start=90):
    fields = ['S'] + ['0'] * 19
    fields[17] = '1'
    fields[19] = str(start)
    return '15 (fixture) ' + ' '.join(fields)


class DrmUsageTests(unittest.TestCase):
    def fixture(self, root):
        directory = root/'proc/15'
        (directory/'fdinfo').mkdir(parents=True)
        binary = root/'binary'
        binary.write_bytes(b'generated nonexecutable')
        (directory/'exe').symlink_to(binary)
        (directory/'stat').write_text(stat_line())
        (directory/'fdinfo/0').write_text('pos:\t0\nflags:\t0100000\n')
        (directory/'fdinfo/7').write_text('drm-driver:\ti915\ndrm-pdev:\t0000:00:02.0\ndrm-client-id:\t9\ndrm-engine-render:\t200 ns\ndrm-cycles-render:\t75\n')
        return root/'proc', binary, dict(pid=15, start_ticks=90)

    def test_retains_units_without_claiming_exact_wait(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc, exe, process = self.fixture(Path(tmp))
            result = drm_usage.capture(process, exe, driver.parse_process_stat, proc)
            self.assertTrue(result['complete'])
            self.assertEqual(len(result['clients']), 1)
            self.assertEqual(result['clients'][0]['observations'][0]['fields']['drm-engine-render'], '200 ns')

    def test_duplicate_descriptors_are_one_client_with_both_raw_observations(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc, exe, process = self.fixture(Path(tmp))
            raw = (proc/'15/fdinfo/7').read_text()
            (proc/'15/fdinfo/8').write_text(raw.replace('200 ns','230 ns'))
            result = drm_usage.capture(process, exe, driver.parse_process_stat, proc)
            self.assertTrue(result['complete'])
            self.assertEqual(len(result['clients']), 1)
            self.assertEqual(len(result['clients'][0]['observations']), 2)

    def test_equal_client_ids_on_different_devices_are_separate(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc, exe, process = self.fixture(Path(tmp))
            raw = (proc/'15/fdinfo/7').read_text()
            (proc/'15/fdinfo/8').write_text(raw.replace('0000:00:02.0','0000:01:00.0'))
            result = drm_usage.capture(process, exe, driver.parse_process_stat, proc)
            self.assertEqual(len(result['clients']), 2)

    def test_wrong_executable_is_not_sampled(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc, exe, process = self.fixture(Path(tmp))
            other = Path(tmp)/'other'; other.write_bytes(b'other')
            value = drm_usage.capture(process, other, driver.parse_process_stat, proc)
            self.assertFalse(value['matched_expected_exe'])
            self.assertEqual(value['clients'], [])

    def test_wrong_user_is_rejected_before_fd_collection(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc, exe, process = self.fixture(Path(tmp))
            actual_uid = drm_usage.os.getuid()
            with patch.object(drm_usage.os, 'getuid', return_value=actual_uid+1):
                result = drm_usage.capture(process, exe, driver.parse_process_stat, proc)
            self.assertFalse(result['complete'])
            self.assertEqual(result['clients'], [])
            self.assertIn('user differs', result['errors'][0]['message'])

    def test_process_reuse_during_fd_reads_discards_all_client_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc, exe, process = self.fixture(Path(tmp))
            original = Path.open
            def reused(target, *args, **kwargs):
                if target == proc/'15/fdinfo/7':
                    with original(proc/'15/stat', 'w') as stream:stream.write(stat_line(91))
                return original(target, *args, **kwargs)
            with patch.object(Path, 'open', reused):
                result = drm_usage.capture(process, exe, driver.parse_process_stat, proc)
            self.assertFalse(result['complete'])
            self.assertEqual(result['clients'], [])
            self.assertIn('lifetime', result['errors'][0]['message'])

    def test_missing_identity_is_not_a_zero_usage_client(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc, exe, process = self.fixture(Path(tmp))
            (proc/'15/fdinfo/7').write_text('drm-driver: i915\ndrm-engine-render: 9 ns\n')
            result = drm_usage.capture(process, exe, driver.parse_process_stat, proc)
            self.assertFalse(result['complete'])
            self.assertEqual(result['clients'], [])
            self.assertEqual(result['missing_client_identity_fds'], [7])

    def test_malformed_and_oversized_records_fail_closed(self):
        for raw in (b'drm-driver: i915\ndrm-client-id: x', b'drm-driver: i915\ndrm-driver: xe',
                    b'x' * 65537, b'\xff'):
            with self.assertRaises((ValueError, UnicodeError)):
                drm_usage.fields(raw)

    def test_descriptor_bound_precedes_all_fd_reads(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc, exe, process = self.fixture(Path(tmp))
            for i in range(257):(proc/'15/fdinfo'/str(i)).touch()
            result = drm_usage.capture(process, exe, driver.parse_process_stat, proc)
            self.assertFalse(result['complete'])
            self.assertEqual(result['clients'], [])
            self.assertIn('bound',result['errors'][0]['message'])

    def test_clock_snapshot_keeps_missing_fields_unavailable(self):
        with tempfile.TemporaryDirectory() as tmp:
            first, missing = Path(tmp)/'actual_mhz', Path(tmp)/'missing_mhz'
            first.write_text('600\n')
            with patch.object(driver, 'GPU_CLOCK_FIELDS', (str(first),str(missing))):
                result = driver.capture_gpu_clocks()
            self.assertEqual(result['values'], {str(first):600})
            self.assertEqual(result['read_errors'], {str(missing):'FileNotFoundError'})
            self.assertGreaterEqual(result['finished_monotonic_ns'],result['began_monotonic_ns'])

    def test_clock_snapshot_rejects_malformed_or_oversized_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'clock'
            for text in ('unknown','1'*129):
                path.write_text(text)
                with patch.object(driver, 'GPU_CLOCK_FIELDS', (str(path),)):
                    result = driver.capture_gpu_clocks()
                self.assertEqual(result['values'], {})
                self.assertEqual(result['read_errors'], {str(path):'ValueError'})


if __name__ == '__main__':
    unittest.main()
