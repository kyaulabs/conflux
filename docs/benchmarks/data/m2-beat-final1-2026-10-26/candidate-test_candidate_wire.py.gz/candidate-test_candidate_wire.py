"""Candidate bytes remain bound to source clocks and never become native acceptance."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

BASE=Path(__file__).resolve().parent


def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


s=load(BASE/'score_candidate.py','final1_candidate_scoring_tested')
worker=load(BASE/'analyze_bpm_final1_capture.py','final1_candidate_encoding_tested')


class CandidateWireTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.helpers=s.m.helpers(json.loads((BASE/'plan.json').read_text()))

    def setUp(self):
        guard=patch('subprocess.Popen',side_effect=AssertionError('No model or child in pure candidate tests'))
        guard.start();self.addCleanup(guard.stop)
        self.source={'id':1,'prepared_frames':96000,'pcm_sha256':'b'*64,
                     'wav_pin':{'path':'/oracle/source.wav','bytes':123,'sha256':'a'*64}}
        self.seconds=[0.,.5,1.,1.5]
        self.raw=worker.encode_result(96000,'b'*64,120.,self.seconds,[0.])
        self.native={'source':'/oracle/source.wav','source_sha256':'a'*64,'source_bytes':123,
            'prepared_frames':96000,'prepared_bytes':96000*8,'pcm_sha256':'b'*64,'prepared_rate_hz':48000,
            'cache_hit':False,'passed':False,'analysis_status':'Failed',
            'analysis_error':'BPM result identity or schema differs','beats':[]}
        from decimal import Decimal
        self.truth={'reference_seconds_text':['0','.5','1','1.5'],
            'reference_seconds':tuple(Decimal(x) for x in ['0','.5','1','1.5'])}

    def test_exact_candidate_events_keep_source_time_and_native_rejection(self):
        header,events,seconds=s.candidate_wire(self.raw,self.source,worker)
        self.assertEqual(seconds,self.seconds);self.assertEqual(header['recipe'],worker.RECIPE)
        result=s.score_case(self.source,self.native,self.raw,self.truth,self.helpers,worker)
        self.assertTrue(result['per_item_accuracy_screen']);self.assertEqual(result['full']['f1'],1)
        self.assertFalse(result['native_recipe_accepted']);self.assertEqual(result['downbeat_accuracy'],'Unavailable')

    def test_foreign_recipe_hash_clock_summary_and_noncanonical_records_fail(self):
        values=[json.loads(line) for line in self.raw.splitlines()]
        for key,value in [('schema',True),('recipe','beat-this-final0-linear-mel-v1'),
                          ('pcm_sha256','a'*64),('frames',96001),('bpm',140.)]:
            changed=[dict(row) for row in values];changed[0][key]=value
            raw=('\n'.join(json.dumps(row,separators=(',',':')) for row in changed)+'\n').encode()
            with self.subTest(key=key),self.assertRaises(ValueError):s.candidate_wire(raw,self.source,worker)
        for raw in [self.raw[:-1],self.raw.replace(b'"schema":2',b'"schema":2,"schema":2',1),
                    self.raw.replace(b'"frame":24000',b'"frame":0',1)]:
            with self.assertRaises(ValueError):s.candidate_wire(raw,self.source,worker)

    def test_missing_unknown_or_wrong_native_context_cannot_be_dropped_or_passed(self):
        unknown=worker.encode_result(96000,'b'*64,None,[],[])
        result=s.score_case(self.source,self.native,unknown,self.truth,self.helpers,worker)
        self.assertEqual(result['status'],'CandidateUnknown');self.assertFalse(result['per_item_accuracy_screen'])
        self.assertEqual(result['full']['reference_beats'],4)
        for native,raw in [(None,self.raw),(self.native,None),(dict(self.native,passed=True),self.raw),
                           (dict(self.native,pcm_sha256='c'*64),self.raw)]:
            result=s.score_case(self.source,native,raw,self.truth,self.helpers,worker)
            self.assertEqual(result['id'],1);self.assertEqual(result['status'],'Failed')
            self.assertFalse(result['per_item_accuracy_screen'])

    def test_capture_preserves_exact_bytes_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as directory,patch.object(worker,'CANDIDATE_CAPTURE_DIRECTORY',directory):
            Path(directory).chmod(0o700)
            worker.retain_candidate_prediction(self.raw)
            file=Path(directory)/('b'*64+'.jsonl');self.assertEqual(file.read_bytes(),self.raw)
            with self.assertRaises(FileExistsError):worker.retain_candidate_prediction(self.raw)
            self.assertEqual(file.read_bytes(),self.raw)
            with self.assertRaisesRegex(ValueError,'digest invalid'):
                worker.retain_candidate_prediction(b'{"pcm_sha256":"../../outside"}\n')


if __name__=='__main__':unittest.main()
