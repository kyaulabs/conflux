"""Retained numerical scoring requires the exact failed run and separate absence proof."""
import copy
import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('final1_retained_context',Path(__file__).with_name('score_candidate_retained.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class RetainedContextTests(unittest.TestCase):
    def fixture(self):
        plan={'sha256':'a'*64};pin={'sha256':'b'*64}
        errors=[{'phase':'run','type':'ValueError','message':'Live owned RSS missing'}]
        execution=dict(plan_pin=plan,complete=False,native_completed=True,native_operational_failed_cases=24,
            complete_capture=True,inputs_reverified=True,returncode=1,errors=errors,
            within_original_command_budget=True,maximum_sampled_owned_rss_bytes=500000000,rss_limit_bytes=2147483648)
        closure=dict(execution_pin=pin,source_plan_pin=plan,cleanup_complete=True,
            all_owned_lifetimes_absent=True,all_owned_groups_absent=True,inputs_reverified=True,
            all24_native_private_recipe_rejections_confirmed=True,original_execution_complete=False,
            original_execution_errors=errors,root_verification_within_original600s=True)
        return execution,plan,pin,closure

    def test_failed_execution_is_not_reclassified_by_valid_root_absence(self):
        execution,plan,pin,closure=self.fixture();before=copy.deepcopy(execution)
        m.verify_retained_execution(execution,plan,pin,closure)
        self.assertEqual(execution,before);self.assertFalse(execution['complete'])

    def test_incomplete_source_capture_unproven_cleanup_changed_errors_or_budget_are_rejected(self):
        for target,key,value in [('execution','native_completed',False),('execution','inputs_reverified',False),
            ('execution','complete_capture',False),('execution','errors',[]),('execution','returncode',-15),
            ('execution','maximum_sampled_owned_rss_bytes',2147483649),
            ('closure','cleanup_complete',False),('closure','all_owned_groups_absent',False),
            ('closure','execution_pin',{'sha256':'c'*64}),('closure','root_verification_within_original600s',False)]:
            execution,plan,pin,closure=self.fixture()
            (execution if target=='execution' else closure)[key]=value
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'numerical-only execution'):
                m.verify_retained_execution(execution,plan,pin,closure)


if __name__=='__main__':unittest.main()
