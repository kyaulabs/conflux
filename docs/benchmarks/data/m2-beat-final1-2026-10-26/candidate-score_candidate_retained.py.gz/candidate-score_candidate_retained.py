"""Score exact private Final1 captures; never label native recipe rejection accepted."""
import argparse
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

BASE = Path(__file__).resolve().parent


def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value


m=load(BASE/'production_24.py','final1_production_input_runner')


def candidate_wire(raw,source,worker):
    m.require(type(raw) is bytes and 0<len(raw)<=worker.MAX_OUTPUT_BYTES and raw.endswith(b'\n'),
              'Candidate capture bound or completion differs')
    values=[m.decode(line) for line in raw.splitlines()]
    header=values[0]
    m.require(type(header) is dict and set(header)=={'schema','recipe','frames','pcm_sha256','bpm','beat_count'} and
        type(header['schema']) is int and header['schema']==2 and header['recipe']==worker.RECIPE and
        type(header['frames']) is int and header['frames']==source['prepared_frames'] and
        header['pcm_sha256']==source['pcm_sha256'] and type(header['beat_count']) is int and
        0<=header['beat_count']<=4096 and len(values)==header['beat_count']+1,
        'Candidate source/recipe/count differs')
    events=values[1:];previous=-1
    for event in events:
        m.require(type(event) is dict and set(event)=={'frame','downbeat'} and
            type(event['frame']) is int and previous<event['frame']<source['prepared_frames'] and
            type(event['downbeat']) is bool,'Candidate event clock or type differs')
        previous=event['frame']
    seconds=[event['frame']/48000 for event in events]
    downbeats=[event['frame']/48000 for event in events if event['downbeat']]
    canonical=worker.encode_result(source['prepared_frames'],source['pcm_sha256'],header['bpm'],seconds,downbeats)
    m.require(raw==canonical,'Candidate bytes are not canonical worker output')
    m.require(worker.summarize_beats(seconds,source['prepared_frames'])[0]==header['bpm'],
        'Candidate summary differs from retained events')
    return header,events,seconds


def score_case(source,native,raw,truth,helpers,worker):
    if native is None or raw is None:return m.failed_case(source['id'],'Missing native case or raw candidate capture')
    try:
        m.require(native['source']==source['wav_pin']['path'] and native['source_sha256']==source['wav_pin']['sha256'] and
            native['source_bytes']==source['wav_pin']['bytes'] and native['prepared_frames']==source['prepared_frames'] and
            native['prepared_bytes']==source['prepared_frames']*8 and native['pcm_sha256']==source['pcm_sha256'] and
            native['prepared_rate_hz']==48000 and native['cache_hit'] is False,'Actual native prepared source differs')
        m.require(native['passed'] is False and native['analysis_status']=='Failed' and
            native['analysis_error']=='BPM result identity or schema differs' and native['beats']==[],
            'Unchanged native parser did not retain expected private-recipe rejection')
        header,events,seconds=candidate_wire(raw,source,worker)
        intervals=helpers['admission']['source_intervals'](seconds,source['prepared_frames'],48000)
        metrics=helpers['challenge']['item_metrics'](SimpleNamespace(metrics=helpers['common']['metrics']),
            truth,seconds,intervals,[])
        return dict(id=source['id'],status='CandidateEstimated' if header['bpm'] is not None else 'CandidateUnknown',
            **metrics,confidence='Unknown',downbeat_accuracy='Unavailable',raw_beats=events,
            source_pcm_sha256=source['pcm_sha256'],native_recipe_accepted=False,
            native_analysis_error=native['analysis_error'])
    except (KeyError,TypeError,ValueError,ZeroDivisionError) as error:
        return m.failed_case(source['id'],str(error))


def verify_retained_execution(execution,plan_pin,execution_pin,closure):
    expected=[{'phase':'run','type':'ValueError','message':'Live owned RSS missing'}]
    m.require(execution.get('plan_pin')==plan_pin and execution.get('complete') is False and
        execution.get('native_completed') is True and execution.get('native_operational_failed_cases')==24 and
        execution.get('complete_capture') is True and execution.get('inputs_reverified') is True and
        execution.get('returncode')==1 and execution.get('errors')==expected and
        execution.get('within_original_command_budget') is True and
        execution.get('maximum_sampled_owned_rss_bytes',2**64)<=execution.get('rss_limit_bytes',-1)==2147483648 and
        closure.get('execution_pin')==execution_pin and closure.get('source_plan_pin')==plan_pin and
        closure.get('cleanup_complete') is True and closure.get('all_owned_lifetimes_absent') is True and
        closure.get('all_owned_groups_absent') is True and closure.get('inputs_reverified') is True and
        closure.get('all24_native_private_recipe_rejections_confirmed') is True and
        closure.get('original_execution_complete') is False and closure.get('original_execution_errors')==expected and
        closure.get('root_verification_within_original600s') is True,
        'Retained numerical-only execution/closure context differs')


def run():
    plan,plan_pin=m.plan_at(BASE/'plan.json')
    auth=m.decode((BASE/'root-retained-scoring-authorization.json').read_bytes())
    m.require(auth.get('plan_sha256')==plan_pin['sha256'] and auth.get('scorer_sha256')==m.file_pin(Path(__file__))['sha256'] and
        auth.get('authorized_once') is True,'Exact candidate scoring authorization missing')
    execution=m.decode(m.read_pin(m.file_pin(BASE/'execution.json'),maximum=m.STREAM_MAX))
    closure_pin=auth['root_closure'];closure=m.decode(m.read_pin(closure_pin,maximum=65536))
    verify_retained_execution(execution,plan_pin,m.file_pin(BASE/'execution.json'),closure)
    analysis_plan=m.decode(m.read_pin(auth['analysis_plan'],maximum=65536))
    m.require(analysis_plan['source_plan']==plan_pin and analysis_plan['root_closure']==closure_pin and
        analysis_plan['execution']==m.file_pin(BASE/'execution.json') and
        analysis_plan['original_scorer']==plan['candidate_scorer'], 'Retained analysis provenance differs')
    for captured in analysis_plan['captured_predictions']:m.read_pin(captured,maximum=4194304)
    rows,terminal=m.parse_rows(m.read_pin(execution['captures']['stdout']['pin'],maximum=m.STREAM_MAX))
    m.require(len(rows)==24 and terminal['mode']=='analysis' and terminal['complete'] is True,'All24 native cases required')
    worker_raw=m.read_pin(plan['worker_pin'],maximum=65536)
    scope={'__name__':'private_candidate_encoder','__file__':plan['worker_pin']['path']}
    exec(compile(worker_raw,plan['worker_pin']['path'],'exec'),scope)
    worker=SimpleNamespace(**scope)
    m.require(worker.RECIPE==plan['candidate_recipe']=='beat-this-final1-linear-mel-v1','Candidate recipe differs')
    helpers=m.helpers(plan);header=m.decode(m.read_pin(plan['original_header_pin']))
    headers={row['id']:row for row in header['tracks']}
    results=[];capture_pins=[]
    # Verify/capture all predictions before opening the first ground-truth CSV.
    captured={}
    expected={source['pcm_sha256']+'.jsonl' for source in plan['cases']}
    actual={p.name for p in (BASE/'predictions').iterdir()}
    m.require(len(expected)==24 and actual<=expected,'Unexpected captured prediction file')
    missing=[]
    for source in plan['cases']:
        path=BASE/'predictions'/(source['pcm_sha256']+'.jsonl')
        if path.name not in actual:
            captured[source['id']]=None;missing.append(source['id']);continue
        pin=m.file_pin(path)
        captured[source['id']]=m.read_pin(pin,maximum=worker.MAX_OUTPUT_BYTES);capture_pins.append(pin)
    for source,native in zip(plan['cases'],rows):
        truth=helpers['admission']['admit_artbeat_track'](headers[source['id']],m.read_pin(source['CSV_pin']).decode())
        results.append(score_case(source,native,captured[source['id']],truth,helpers,worker))
    baseline=m.decode(m.read_pin(plan['baseline_production_scores']))
    m.require(baseline['denominator']==24 and len(baseline['cases'])==24 and baseline['items_passing_numeric_screen']==9,
        'Retained current production48k numerical baseline differs')
    passing=sum(result['per_item_accuracy_screen'] for result in results)
    summary=dict(schema=1,status='completed_candidate_diagnostic',qualified=False,denominator=24,
        plan_pin=plan_pin,execution_pin=m.file_pin(BASE/'execution.json'),captures=capture_pins,missing_capture_ids=missing,
        operational_pass=False,original_execution_complete=False,original_execution_errors=execution['errors'],
        root_current_absence_proof=closure_pin,postrun_analysis_plan=auth['analysis_plan'],
        candidate_recipe=worker.RECIPE,model_pin=plan['model_pin'],cases=results,
        items_passing_numeric_screen=passing,all24_numeric_screens_pass=passing==24,
        baseline_production_numeric_passes=9,baseline_production_scores=plan['baseline_production_scores'],
        baseline_original_execution_complete=False,whole_beat_gate_pass=False,automatic_use=False,
        production_recipe_accepted=False,downbeat_accuracy='Unavailable',training_independence='Unknown',
        scope='Exposed24 full-denominator accuracy diagnostic on native-prepared48k PCM. No acceptance bypass, threshold/shift/octave fitting, production integration, held-out, phrase/key/cue, latency or M2 qualification.')
    m.save(BASE/'candidate-retained-scores.json',summary)
    print(json.dumps({key:summary[key] for key in ('status','denominator','items_passing_numeric_screen',
        'baseline_production_numeric_passes','qualified','production_recipe_accepted')}))


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--score',action='store_true')
    args=parser.parse_args()
    if not args.score:print('Unarmed candidate scoring; no source, model, labels or output read.');return
    run()


if __name__=='__main__':main()
