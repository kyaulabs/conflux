"""Prove exit-state handling without hiding unavailable live RSS or PID reuse."""
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import Mock,patch

spec=importlib.util.spec_from_file_location('final1_rss_runner',Path(__file__).with_name('production_24.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class RssObservationTests(unittest.TestCase):
    def sample(self,statuses,identities=None):
        expected=dict(pid=42,start_ticks=9,group=42,session=42,ppid=1)
        process=Mock(side_effect=identities) if identities else Mock(return_value=expected)
        owner={'live_owned':lambda owned,failures:owned,'process_record':process,
            'same_identity':lambda a,b:all(a[k]==b[k] for k in ('pid','start_ticks','group','session'))}
        file=Mock();file.read_bytes.side_effect=statuses
        root=Mock();root.__truediv__=Mock(return_value=root);root.read_bytes=file.read_bytes
        with patch.object(m,'Path',return_value=root):result=m.sampled_rss(owner,{(42,9):expected},[])
        return result,process.call_count,file.read_bytes.call_count

    def test_rss_disappearing_between_live_state_and_exit_is_not_a_live_failure(self):
        result,calls,reads=self.sample([b'State:\tR (running)\n',b'State:\tZ (zombie)\n'])
        self.assertEqual(result,(0,1));self.assertEqual((calls,reads),(3,2))

    def test_a_live_missing_rss_still_fails(self):
        with self.assertRaisesRegex(ValueError,'Live owned RSS missing'):
            self.sample([b'State:\tR (running)\n',b'State:\tS (sleeping)\n'])

    def test_live_rss_and_proved_zombie_are_distinct(self):
        self.assertEqual(self.sample([b'State:\tS (sleeping)\nVmRSS:\t123 kB\n'])[0],(123*1024,0))
        self.assertEqual(self.sample([b'State:\tZ (zombie)\n'])[0],(0,1))

    def test_pid_reuse_even_during_zombie_observation_is_rejected(self):
        expected=dict(pid=42,start_ticks=9,group=42,session=42,ppid=1)
        with self.assertRaisesRegex(ValueError,'lifetime changed'):
            self.sample([b'State:\tZ (zombie)\n'],[expected,dict(expected,start_ticks=10)])

    def test_gone_process_and_malformed_live_rss_do_not_invent_memory(self):
        self.assertEqual(self.sample([FileNotFoundError()])[0],(0,0))
        for value in [b'-1',b'NaN',b'12.5']:
            with self.subTest(value=value),self.assertRaisesRegex(ValueError,'RSS malformed'):
                self.sample([b'State:\tS (sleeping)\nVmRSS:\t'+value+b' kB\n'])


if __name__=='__main__':unittest.main()
