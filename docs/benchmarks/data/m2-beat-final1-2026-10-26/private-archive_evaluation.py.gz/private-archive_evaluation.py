"""Preserve the rejected model comparison and failed owner without media or weights."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

BASE=Path(__file__).resolve().parent
RUN=BASE/'evaluation-01'
OLD=BASE.parent/'production-artbeat-draft-04'
WORK=BASE.parent.parent/'m2-profile-reporting-worktree'
DEST=WORK/'docs/benchmarks/data/m2-beat-final1-2026-10-26'
RAW=BASE/'archive-raw-01'


def sha(raw):return hashlib.sha256(raw).hexdigest()


def main():
    assert not DEST.exists() and not RAW.exists()
    scores=json.loads((RUN/'candidate-retained-scores.json').read_text())
    closed=json.loads((RUN/'root-finished-01.json').read_text())
    execution=json.loads((RUN/'execution.json').read_text())
    assert scores['denominator']==24 and len(scores['cases'])==24 and scores['items_passing_numeric_screen']==8
    assert not scores['operational_pass'] and not execution['complete'] and not execution['cleanup_proven']
    assert closed['cleanup_complete'] and closed['root_verification_within_original600s']
    sources=[(path,'candidate-'+path.name) for path in RUN.iterdir()
             if path.is_file() and path.suffix in ('.json','.py','.log')]
    sources += [(path,'prediction-'+path.name) for path in (RUN/'predictions').iterdir() if path.is_file()]
    sources += [(RUN/'output'/name,'candidate-output-'+name) for name in ('stdout.log','stderr.log')]
    sources += [(BASE/name,'model-'+name) for name in ('root-safe-tensor-validation-02.json',
        'root-validation-owner-02.json','acquisition-01.json','acquisition-02.json','UPSTREAM-LICENSE.txt','analyze_bpm_final1.py')]
    sources += [(OLD/name,'baseline-'+name) for name in ('plan.json','execution.json','production-scores.json',
        'extracted-manifest.json','prepared-manifest.json','root-native-build-attestation-01.json')]
    sources += [(OLD/'draft-files/tools/experiments/prepare_audio_check.cpp','native-prepare_audio_check.cpp'),
                (Path(__file__),'private-archive_evaluation.py')]
    assert len({name for _,name in sources})==len(sources)
    RAW.mkdir(mode=0o700);rows=[]
    for path,name in sorted(sources,key=lambda row:row[1]):
        assert path.resolve(strict=True)==path and path.stat().st_size<4*1024**2
        raw=path.read_bytes();raw.decode('utf-8')
        if path.suffix=='.json':json.loads(raw)
        if path.suffix=='.jsonl':
            assert raw.endswith(b'\n')
            for line in raw.splitlines():json.loads(line)
        (RAW/name).write_bytes(raw)
        rows.append(dict(original_path=str(path),raw_file=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
    scanner=shutil.which('gitleaks');assert scanner
    command=[scanner,'dir','--no-banner','--redact','--max-target-megabytes','4',str(RAW)]
    with (BASE/'archive-gitleaks-01.log').open('xb') as stream:
        result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
    log=(BASE/'archive-gitleaks-01.log').read_bytes();assert result.returncode==0,'Raw secret scan failed'
    count=re.search(rb'scanned ~(\d+) bytes',log);total=sum(row['raw_bytes'] for row in rows)
    assert count and int(count[1])==total,'Raw secret scan coverage differs'
    DEST.mkdir()
    for row in rows:
        raw=(RAW/row['raw_file']).read_bytes();archive=gzip.compress(raw,compresslevel=9,mtime=0)
        assert gzip.decompress(archive)==raw and sha(raw)==row['raw_sha256']
        name=row['raw_file']+'.gz';(DEST/name).write_bytes(archive)
        row.update(archive_file=name,archive_bytes=len(archive),archive_sha256=sha(archive))
    baseline=json.loads((OLD/'production-scores.json').read_text())
    passing=lambda value:[row['id'] for row in value['cases'] if row['per_item_accuracy_screen']]
    manifest=dict(schema=1,qualified=False,production_model_changed=False,automatic_use=False,
        candidate_recipe=scores['candidate_recipe'],denominator=24,baseline_numeric_passes=9,candidate_numeric_passes=8,
        baseline_passing_ids=passing(baseline),candidate_passing_ids=passing(scores),
        baseline_original_execution_complete=False,candidate_original_execution_complete=False,
        candidate_original_errors=execution['errors'],root_current_absence_verified=closed['cleanup_complete'],
        native_private_recipe_accepted=False,all24_candidate_bytes_retained=True,
        source_clock_decoder_frontend_thresholds_and_denominator_unchanged=True,
        operational_qualification=False,downbeat_accuracy='Unavailable',training_independence='Unknown',
        milestone_or_release_gate_changed=False,
        scope='Retained24 Final1 numerical diagnostic on actual prepared48k PCM. Both original RSS failures remain. No operational, production, held-out, phrase/key/cue, latency or M2 qualification.',
        files=rows,total_raw_bytes=total,total_archive_bytes=sum(row['archive_bytes'] for row in rows),
        gzip_roundtrip_and_original_hashes_verified=True,
        no_audio_models_executables_PCM_or_cache_published=True,
        raw_secret_scan=dict(command=command,exit=0,scanned_bytes=int(count[1]),log_sha256=sha(log)),
        created_at_utc=datetime.now(timezone.utc).isoformat())
    with (DEST/'verification.json').open('x') as stream:json.dump(manifest,stream,indent=2,allow_nan=False);stream.write('\n')
    for row in rows:
        compressed=(DEST/row['archive_file']).read_bytes();raw=gzip.decompress(compressed)
        assert sha(compressed)==row['archive_sha256'] and len(raw)==row['raw_bytes'] and sha(raw)==row['raw_sha256']
    print(json.dumps(dict(files=len(rows),raw_bytes=total,gzip_bytes=manifest['total_archive_bytes'],
        all_raw_bytes_secret_scanned=True,all_round_trips_verified=True,verification=str(DEST/'verification.json'))))


if __name__=='__main__':main()
