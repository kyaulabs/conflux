"""Pure scoring/entry tests: synthetic records only, no child, model or ART audio."""
import contextlib
from decimal import Decimal
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('private_production24_tested',BASE/'production_24.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def load(name,path):
    namespace={'__name__':'private_oracle_'+name,'__file__':str(path)}
    exec(compile(path.read_bytes(),str(path),'exec'),namespace);return namespace


class ScoringChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        old=m.ROOT/'benchmarks-local/m2-beat-evaluation-2026-10-20'
        cls.h={name:load(name,old/p) for name,p in {'admission':'artbeat-admission-14/admission_14.py',
            'challenge':'artbeat-challenge-15/challenge_15.py','common':'qm-evaluation-02/score.py'}.items()}

    def setUp(self):
        patch=mock.patch('subprocess.Popen',side_effect=AssertionError('No real processes in scoring tests'))
        patch.start();self.addCleanup(patch.stop)
        self.source={'id':1,'wav_pin':{'path':'/oracle/01.wav','bytes':123,'sha256':'a'*64},
            'prepared_frames':96000,'pcm_sha256':'b'*64}
        self.row={'schema':1,'kind':'production-bpm-case','ordinal':0,'source':'/oracle/01.wav',
            'source_sha256':'a'*64,'source_bytes':123,'prepared_frames':96000,'prepared_bytes':96000*8,
            'pcm_sha256':'b'*64,'prepared_rate_hz':48000,'passed':True,'analysis_status':'Estimated',
            'analysis_error':'','cache_hit':False,'analysis_frames':96000,'analysis_pcm_sha256':'b'*64,
            'summary_bpm':300.,'beats':[{'frame':f,'downbeat':f==0} for f in (0,24000,48000)]}
        self.truth={'reference_seconds_text':['0','0.5','1'],'reference_seconds':tuple(Decimal(x) for x in ('0','.5','1'))}

    def test_actual_frame_events_score_without_summary_or_shift(self):
        result=m.score_case(self.source,self.row,self.truth,self.h)
        self.assertTrue(result['per_item_accuracy_screen']);self.assertEqual(result['full']['f1'],1)
        self.assertEqual(result['median_relative_adjacent_BPM_error'],0)
        self.assertEqual(result['downbeat_accuracy'],'Unavailable')
        self.row['beats']=[{'frame':f+7200,'downbeat':False} for f in (0,24000,48000)]
        result=m.score_case(self.source,self.row,self.truth,self.h)
        self.assertFalse(result['per_item_accuracy_screen']);self.assertEqual(result['full']['matched_beats'],0)

    def test_missing_failed_and_unknown_never_disappear(self):
        self.assertFalse(m.score_case(self.source,None,self.truth,self.h)['per_item_accuracy_screen'])
        self.row['analysis_status']='Unknown';self.row['beats']=[];self.row['summary_bpm']=None
        result=m.score_case(self.source,self.row,self.truth,self.h)
        self.assertEqual(result['status'],'Unknown');self.assertFalse(result['per_item_accuracy_screen'])
        self.assertEqual(result['full']['reference_beats'],3)
        self.row['analysis_status']='Failed';self.row['passed']=False
        self.assertEqual(m.score_case(self.source,self.row,self.truth,self.h)['status'],'Failed')

    def test_source_clock_digest_cache_and_raw_order_fail_closed(self):
        for field,value in (('source_sha256','x'*64),('prepared_frames',95999),('pcm_sha256','x'*64),
            ('prepared_rate_hz',44100),('analysis_frames',96001),('cache_hit',True),
            ('beats',[{'frame':0,'downbeat':True},{'frame':0,'downbeat':False}])):
            row={**self.row,field:value};result=m.score_case(self.source,row,self.truth,self.h)
            self.assertEqual(result['status'],'Failed',field);self.assertFalse(result['per_item_accuracy_screen'])

    def test_wire_rejects_duplicate_keys_bool_schema_and_incomplete_tail(self):
        for raw in (b'{"x":1,"x":2}',b'{"x":1e400}',b'{"x":NaN}'):
            with self.assertRaises(ValueError):m.decode(raw)
        terminal={'schema':1,'kind':'production-bpm-complete','mode':'analysis','completed':1,'expected':24,'complete':False,'passed':False}
        raw=(json.dumps(self.row)+'\n'+json.dumps(terminal)+'\n').encode();rows,last=m.parse_rows(raw)
        self.assertEqual(len(rows),1);self.assertFalse(last['complete'])
        for change in ({'schema':True},{'ordinal':True},{'ordinal':2}):
            with self.assertRaises(ValueError):m.parse_rows((json.dumps({**self.row,**change})+'\n'+json.dumps(terminal)+'\n').encode())
        with self.assertRaises(ValueError):m.parse_rows(raw[:-1])

    def test_full_score_keeps24_with_unknown_and_missing_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'output').mkdir()
            csv=root/'oracle.csv';csv.write_text('0\n0.5\n1\n')
            headers=[];sources=[];rows=[]
            for ordinal,identifier in enumerate(m.IDS):
                member=f'ARTBeaT_Dataset/Audio/{identifier:02d}_ARTBeaT_oracle.wav'
                headers.append({'id':identifier,'member':member,'frames':88200,'container':'RIFF',
                    'data_ends_at_member_boundary':True,'ZIP_uncompressed_bytes':352844,
                    'data':{'offset':44,'bytes':352800},'CSV_reference_file':Path(member).stem+'_gt.csv',
                    'fmt':{'format_tag':1,'actual_format_tag':1,'channels':2,'sample_rate':44100,
                        'byte_rate':176400,'block_align':4,'bits_per_sample':16}})
                source={**self.source,'id':identifier,'CSV_pin':m.file_pin(csv)}
                source['wav_pin']={**self.source['wav_pin'],'path':f'/oracle/{identifier:02d}.wav'}
                sources.append(source)
                if ordinal<23:
                    row={**self.row,'ordinal':ordinal,'source':source['wav_pin']['path']}
                    if ordinal:row.update(analysis_status='Unknown',beats=[],summary_bpm=None)
                    rows.append(row)
            header=root/'header.json';header.write_text(json.dumps({'tracks':headers}))
            terminal={'schema':1,'kind':'production-bpm-complete','mode':'analysis','completed':23,
                'expected':24,'complete':False,'passed':False}
            (root/'output/stdout.log').write_text(''.join(json.dumps(r)+'\n' for r in rows+[terminal]))
            old=m.ROOT/'benchmarks-local/m2-beat-evaluation-2026-10-20/artbeat-challenge-15/scores-15.json'
            plan={'cases':sources,'original_header_pin':m.file_pin(header),'old_scores_pin':m.file_pin(old)}
            with mock.patch.object(m,'BASE',root),mock.patch.object(m,'helpers',return_value=self.h):
                m.score(plan,{'sha256':'oracle-non-model'})
                result=json.loads((root/'production-scores.json').read_text())
                self.assertEqual(result['denominator'],24);self.assertEqual(len(result['cases']),24)
                self.assertEqual(result['items_passing_numeric_screen'],1)
                self.assertEqual(result['cases'][-1]['reason'],'Missing native case')
                self.assertFalse(result['qualified']);self.assertFalse(result['whole_beat_gate_pass'])
                self.assertFalse(result['operational_pass'])
                self.assertEqual(result['scored_stream_pin'],m.file_pin(root/'output/stdout.log'))
                with self.assertRaises(FileExistsError):m.score(plan,{'sha256':'oracle-non-model'})

    def test_preflight_primary_failure_is_saved_without_child_or_fake_cleanup(self):
        with tempfile.TemporaryDirectory() as directory,mock.patch.object(m,'BASE',Path(directory)), \
            mock.patch.object(m,'authorization',return_value=({'model_forward':True},{'sha256':'oracle'})), \
            mock.patch.object(m,'measurement_inputs',side_effect=ValueError('Changed exact source pin')):
            result=m.run({}, {'sha256':'oracle'})
            self.assertFalse(result['native_launched']);self.assertFalse(result['cleanup_proven'])
            self.assertEqual(result['failure_phase'],'preflight')
            self.assertIn('Changed exact source pin',result['errors'][0]['message'])
            self.assertTrue((Path(directory)/'execution.json').exists())
            self.assertFalse((Path(directory)/'output').exists())

    def test_actual_owner_loop_preserves600s_deadline_and585s_term(self):
        class Pipe:
            def close(self):pass
        child=SimpleNamespace(pid=42,returncode=None,stdout=Pipe(),stderr=Pipe())
        child.poll=lambda:child.returncode
        child.wait=lambda timeout=None:child.returncode
        clock=SimpleNamespace(now=0.)
        identity={'pid':42,'start_ticks':9,'group':42,'session':42,'ppid':1}
        deadlines=[]
        def remember(p,i,owned,groups,deadline):deadlines.append(deadline)
        def send(p,i,owned,number,sent,failures):
            child.returncode=-int(number);return [42] if 42 not in sent else []
        owner={'process_record':lambda pid:identity,'remember_owned':remember,'signal_owned':send,
            'live_owned':lambda owned,errors:owned if child.returncode is None else {},
            'absent_groups':lambda groups:{str(g):True for g in groups}}
        class Selector:
            def __init__(self):self.map={}
            def register(self,p,event,name):self.map[name]=SimpleNamespace(fd=11,fileobj=p,data=name)
            def unregister(self,p):
                for key,value in list(self.map.items()):
                    if value.fileobj is p:del self.map[key]
            def select(self,timeout):
                clock.now+=1
                return [(next(iter(self.map.values())),1)] if self.map else []
            def get_map(self):return self.map
            def close(self):pass
        plan={'native_binary_pin':{'path':'/oracle/native'},'python_invocation':'/oracle/python',
            'source_directory':'/oracle/source','model_pin':{'path':'/oracle/model'},
            'worker_pin':{'path':'/oracle/worker'},'cases':[{'wav_pin':{'path':f'/oracle/{i}.wav'}} for i in m.IDS]}
        with tempfile.TemporaryDirectory() as directory,mock.patch.object(m,'BASE',Path(directory)), \
            mock.patch.object(m,'authorization',return_value=({'model_forward':True},{'sha256':'oracle'})), \
            mock.patch.object(m,'measurement_inputs',return_value=owner), \
            mock.patch.object(m.time,'monotonic',side_effect=lambda:clock.now), \
            mock.patch.object(m,'sampled_rss',return_value=(1234,0)), \
            mock.patch.object(m.subprocess,'Popen',return_value=child), \
            mock.patch.object(m.selectors,'DefaultSelector',Selector), \
            mock.patch.object(m.os,'read',return_value=b''),mock.patch.object(m.signal,'signal',return_value=0):
            result=m.run(plan,{'sha256':'oracle'})
            self.assertTrue(deadlines);self.assertEqual(set(deadlines),{600.})
            self.assertEqual(result['deadline_monotonic'],600.)
            self.assertEqual(result['signals'][0]['elapsed_seconds'],585.)
            self.assertEqual(result['stop_reason'],'original_whole_command_budget')
            self.assertLess(result['elapsed_seconds'],600.)
            self.assertFalse(result['complete']);self.assertFalse(result['native_completed'])

    def test_final_setup_cancellation_and_original_clock_admission_prevent_popen(self):
        for mode,elapsed,message in (('signal',0.,'Operator cancellation before native dispatch'),
            ('deadline',600.,'Original command deadline exhausted')):
            with self.subTest(mode=mode):
                clock=SimpleNamespace(now=0.);handlers={}
                def handler(number,callback):
                    previous=handlers.get(number,0);handlers[number]=callback;return previous
                class Selector:
                    def __init__(self):
                        clock.now=elapsed
                        if mode=='signal':handlers[m.signal.SIGTERM](m.signal.SIGTERM,None)
                    def get_map(self):return {}
                    def close(self):pass
                owner={'live_owned':lambda owned,errors:{},'absent_groups':lambda groups:{}}
                plan={'native_binary_pin':{'path':'/oracle/native'},'python_invocation':'/oracle/python',
                    'source_directory':'/oracle/source','model_pin':{'path':'/oracle/model'},
                    'worker_pin':{'path':'/oracle/worker'},'cases':[{'wav_pin':{'path':f'/oracle/{i}.wav'}} for i in m.IDS]}
                with tempfile.TemporaryDirectory() as directory,mock.patch.object(m,'BASE',Path(directory)), \
                    mock.patch.object(m,'authorization',return_value=({'model_forward':True},{'sha256':'oracle'})), \
                    mock.patch.object(m,'measurement_inputs',return_value=owner), \
                    mock.patch.object(m.time,'monotonic',side_effect=lambda:clock.now), \
                    mock.patch.object(m.selectors,'DefaultSelector',Selector),mock.patch.object(m.signal,'signal',side_effect=handler), \
                    mock.patch.object(m.subprocess,'Popen',side_effect=AssertionError('No child may launch')) as popen:
                    result=m.run(plan,{'sha256':'oracle'})
                    popen.assert_not_called();self.assertFalse(result['complete']);self.assertIsNone(result['returncode'])
                    self.assertFalse(result['cleanup_proven']);self.assertIn(message,result['errors'][0]['message'])
                    self.assertEqual(result['deadline_monotonic'],600.)
                    if mode=='signal':self.assertEqual(result['operator_signal'],m.signal.SIGTERM)

    def complete_run_fixture(self,directory,*,cancel_on_exit=False,final_verification_elapsed=0.):
        """Execute the actual run loop with pipe/owner doubles; never create a child."""
        clock=SimpleNamespace(now=0.);handlers={};cancelled=False;reads={11:0,12:0};calls=0
        rows=[{**self.row,'ordinal':i} for i in range(24)]
        terminal={'schema':1,'kind':'production-bpm-complete','mode':'analysis',
            'completed':24,'expected':24,'complete':True,'passed':True}
        raw=(''.join(json.dumps(x)+'\n' for x in rows+[terminal])).encode()
        class Pipe:
            def close(self):pass
        child=SimpleNamespace(pid=42,returncode=0,stdout=Pipe(),stderr=Pipe())
        def poll():
            nonlocal cancelled
            if cancel_on_exit and not cancelled:
                cancelled=True;handlers[m.signal.SIGTERM](m.signal.SIGTERM,None)
            return 0
        child.poll=poll;child.wait=lambda timeout=None:0
        class Selector:
            def __init__(self):self.map={}
            def register(self,p,event,name):self.map[name]=SimpleNamespace(fd=11 if name=='stdout' else 12,fileobj=p,data=name)
            def unregister(self,p):
                for k,v in list(self.map.items()):
                    if v.fileobj is p:del self.map[k]
            def select(self,timeout):return [(v,1) for v in self.map.values()]
            def get_map(self):return self.map
            def close(self):pass
        def read(fd,count):
            reads[fd]+=1
            return raw if fd==11 and reads[fd]==1 else b''
        def handler(number,callback):
            previous=handlers.get(number,0);handlers[number]=callback;return previous
        identity={'pid':42,'start_ticks':9,'group':42,'session':42,'ppid':1}
        owner={'process_record':lambda pid:identity,'live_owned':lambda owned,errors:{},
            'signal_owned':lambda child,identity,owned,number,sent,errors:[],
            'absent_groups':lambda groups:{str(g):True for g in groups}}
        def inputs(plan,deadline):
            nonlocal calls
            calls+=1
            if calls==2:clock.now=final_verification_elapsed
            return owner
        plan={'native_binary_pin':{'path':'/oracle/native'},'python_invocation':'/oracle/python',
            'source_directory':'/oracle/source','model_pin':{'path':'/oracle/model'},
            'worker_pin':{'path':'/oracle/worker'},'cases':[{'wav_pin':{'path':f'/oracle/{i}.wav'}} for i in m.IDS]}
        with mock.patch.object(m,'BASE',directory),mock.patch.object(m,'authorization',return_value=(
            {'model_forward':True},{'sha256':'oracle'})), \
            mock.patch.object(m,'measurement_inputs',side_effect=inputs), \
            mock.patch.object(m.time,'monotonic',side_effect=lambda:clock.now), \
            mock.patch.object(m.subprocess,'Popen',return_value=child) as popen, \
            mock.patch.object(m.selectors,'DefaultSelector',Selector),mock.patch.object(m.os,'read',side_effect=read), \
            mock.patch.object(m.signal,'signal',side_effect=handler):
            result=m.run(plan,{'sha256':'oracle'});popen.assert_called_once();return result

    def test_cancel_at_native_exit_never_reports_complete_without_sent_signal(self):
        with tempfile.TemporaryDirectory() as directory:
            result=self.complete_run_fixture(Path(directory),cancel_on_exit=True)
            self.assertTrue(result['native_completed']);self.assertTrue(result['cleanup_proven'])
            self.assertEqual(result['signals'],[]);self.assertEqual(result['operator_signal'],m.signal.SIGTERM)
            self.assertFalse(result['complete'])

    def test_final_verification_time_counts_in_original_budget_and_final_elapsed(self):
        for elapsed,success in ((599.,True),(600.,False)):
            with self.subTest(elapsed=elapsed),tempfile.TemporaryDirectory() as directory:
                result=self.complete_run_fixture(Path(directory),final_verification_elapsed=elapsed)
                self.assertTrue(result['native_completed']);self.assertEqual(result['elapsed_seconds'],elapsed)
                self.assertEqual(result['deadline_monotonic'],600.);self.assertEqual(result['complete'],success)
                self.assertEqual(result['within_original_command_budget'],success)

    def test_score_parses_exact_verified_capture_without_reopening_changed_path(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'output').mkdir();csv=root/'oracle.csv';csv.write_text('0\n0.5\n1\n')
            headers=[];sources=[];rows=[]
            for ordinal,identifier in enumerate(m.IDS):
                member=f'ARTBeaT_Dataset/Audio/{identifier:02d}_ARTBeaT_oracle.wav'
                headers.append({'id':identifier,'member':member,'frames':88200,'container':'RIFF',
                    'data_ends_at_member_boundary':True,'ZIP_uncompressed_bytes':352844,
                    'data':{'offset':44,'bytes':352800},'CSV_reference_file':Path(member).stem+'_gt.csv',
                    'fmt':{'format_tag':1,'actual_format_tag':1,'channels':2,'sample_rate':44100,
                        'byte_rate':176400,'block_align':4,'bits_per_sample':16}})
                source={**self.source,'id':identifier,'CSV_pin':m.file_pin(csv)}
                source['wav_pin']={**self.source['wav_pin'],'path':f'/oracle/{identifier:02d}.wav'};sources.append(source)
                row={**self.row,'ordinal':ordinal,'source':source['wav_pin']['path']}
                if ordinal:row.update(analysis_status='Unknown',beats=[],summary_bpm=None)
                rows.append(row)
            header=root/'header.json';header.write_text(json.dumps({'tracks':headers}))
            terminal={'schema':1,'kind':'production-bpm-complete','mode':'analysis',
                'completed':24,'expected':24,'complete':True,'passed':True}
            stdout=root/'output/stdout.log';stdout.write_text(''.join(json.dumps(x)+'\n' for x in rows+[terminal]))
            capture_pin=m.file_pin(stdout);plan_pin={'sha256':'oracle-non-model'}
            (root/'execution.json').write_text(json.dumps({'plan_pin':plan_pin,'complete':True,'cleanup_proven':True,
                'inputs_reverified':True,'captures':{'stdout':{'pin':capture_pin}}}))
            old=m.ROOT/'benchmarks-local/m2-beat-evaluation-2026-10-20/artbeat-challenge-15/scores-15.json'
            plan={'cases':sources,'original_header_pin':m.file_pin(header),'old_scores_pin':m.file_pin(old)}
            original=m.read_pin;capture_reads=[]
            def verified(pin,*args,**kwargs):
                raw=original(pin,*args,**kwargs)
                if pin['path']==str(stdout):
                    capture_reads.append(pin);stdout.write_text('changed after verified read\n')
                return raw
            with mock.patch.object(m,'BASE',root),mock.patch.object(m,'helpers',return_value=self.h), \
                mock.patch.object(m,'read_pin',side_effect=verified):m.score(plan,plan_pin)
            result=json.loads((root/'production-scores.json').read_text())
            self.assertTrue(result['operational_pass']);self.assertEqual(result['items_passing_numeric_screen'],1)
            self.assertEqual(result['scored_stream_pin'],capture_pin);self.assertEqual(len(capture_reads),1)
            self.assertIsNone(result['native_stream_error']);self.assertFalse(result['qualified'])

    def test_default_entry_is_dry(self):
        with mock.patch.object(sys,'argv',['production_24']),mock.patch.object(m,'plan_at') as plan,contextlib.redirect_stdout(io.StringIO()):m.main()
        plan.assert_not_called()

    def test_all24_denominator_and_original_gates_stay_fixed(self):
        self.assertEqual(m.IDS,tuple(i for i in range(1,26) if i!=21));self.assertEqual(len(m.IDS),24)
        self.assertNotIn(21,m.IDS)


if __name__=='__main__':unittest.main()
