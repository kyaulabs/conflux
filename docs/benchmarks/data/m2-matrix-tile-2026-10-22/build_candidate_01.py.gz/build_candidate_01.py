"""One CPU-only private candidate build; never invokes the runtime/model/GPU."""
import datetime,hashlib,importlib.util,json,os,shutil,signal,stat,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
C=Path(__file__).resolve().parent
N=C.parent/'matrix-dispatch-metadata-01'
EXPECTED_SOURCE='2916433c16ac193b47d48cb2d13cce1351ac1fd84358f7be3c9701c29add5e9f'
def require(ok,message):
    if not ok: raise ValueError(message)
def load_helpers():
    p=N/'root_cpu_build_01.py';raw=p.read_bytes()
    require(hashlib.sha256(raw).hexdigest()=='c687c842de8daddb9ac9ea534087162ff020b07932e1486afbba84a39a0b0fad','Build helper changed')
    spec=importlib.util.spec_from_file_location('frozen_cpu_build_helpers',p)
    m=importlib.util.module_from_spec(spec);exec(compile(raw,str(p),'exec'),m.__dict__);return m

def main():
    h=load_helpers();raw=(N/'build_recipe.json').read_bytes()
    require(hashlib.sha256(raw).hexdigest()=='7f019030aad99c7c11e425f740e8c110a30ac21153bbc960437cb0244d8b37b2','Parent recipe changed')
    r=json.loads(raw);require(stat.S_IMODE(C.stat().st_mode)==0o700 and C.stat().st_uid==os.getuid(),'Private owned0700 required')
    require(shutil.disk_usage(C).free>512*1024**2,'Build space insufficient')
    outputs=['dependencies-before.d','ggml-vulkan.cpp.o','ggml-vulkan.cpp.d','libggml-vulkan.a','link-baseline.d','candidate-stem-runtime','build-receipt-01.json']
    require(all(not os.path.lexists(C/n) for n in outputs),'Existing candidate output; no silent retry')
    sources=[h.pin(C/n) for n in ('ggml-vulkan.cpp','matrix_trace.hpp','ggml-vulkan.patch')]
    require(sources[0]['sha256']==EXPECTED_SOURCE and sources[1]['sha256']=='95b5f78ac7d8775fb8cff317574068728d4c8780dcd4b4f744bbf8b1b794389a','Candidate source/header differs')
    require(sources[2]['sha256']=='77442711a3f7b708c8113cfc18361cc4a4e73923bd1eaec76f6a043f748ac88d','Reviewed patch differs')
    fixture=h.pin(N/'root-fixture-result-01.json');require(fixture['sha256']=='84bd9a437253e5cfc25c8916fe5d659a9b6c25f5195b1679a62e558ada3c581f','Inherited trace fixture changed')
    review=json.loads((C/'source-review-02.json').read_text());require(review['static_review_passed'] is True and review['source_sha256']==EXPECTED_SOURCE,'Candidate static review missing')
    proof={'schema':1,'passed':False,'scope':'CPU-only compilation/link proof. Existing unchanged trace-header fixture reused; candidate tile policy has static review, not an execution or equivalence claim.','native_model_GPU_executed':False,'compiler_jobs_max':1,'sources':sources,'executor':h.pin(__file__),'parent_executor':h.pin(N/'root_cpu_build_01.py'),'parent_recipe':h.pin(N/'build_recipe.json'),'source_review':h.pin(C/'source-review-02.json'),'inherited_trace_header_fixture':fixture,'candidate_policy_exercised':False,'exact_PCM_required':True,'historical_transitive_header_equivalence_proven':False,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
    began=time.monotonic();deadline=began+900
    def argv(key):
        return [x.replace(str(N),str(C)).replace('baseline-stem-runtime','candidate-stem-runtime') for x in r[key]]
    def run(label,key):
        command=argv(key);seconds=min(r['command_limits_seconds'][label],int(deadline-time.monotonic())-10)
        require(seconds>0,'CPU build deadline exhausted');out=C/(label+'.stdout.log');err=C/(label+'.stderr.log')
        require(not out.exists() and not err.exists(),'Existing command log')
        row={'label':label,'argv':command,'timeout_seconds':seconds};start=time.monotonic();child=None
        try:
            with out.open('xb') as stdout,err.open('xb') as stderr:
                child=subprocess.Popen(['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(seconds)+'s',*command],cwd=r['working_directory'],stdout=stdout,stderr=stderr,start_new_session=True)
                row['exit_code']=child.wait(timeout=seconds+15)
        finally:
            if child is not None and child.poll() is None:
                try:os.killpg(child.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                try:child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    try:os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    child.wait(timeout=5)
                row['exit_code']=child.returncode
            row.update(elapsed_seconds=time.monotonic()-start,stdout=h.pin(out),stderr=h.pin(err));proof['commands'].append(row)
        require(row['exit_code']==0,'CPU command failed: '+label)
    try:
        proof['inherited_inputs_before']=[h.verify(x) for x in r['unchanged_input_pins']]
        proof['baseline_source_before']=[h.verify(x) for x in r['source_pins']]
        run('dependencies-before','dependencies_before_argv')
        deps=h.dependencies(C/'dependencies-before.d');require(str(C/'ggml-vulkan.cpp') in deps and str(C/'matrix_trace.hpp') in deps,'Private source/header missing')
        proof['dependencies_before']=[h.pin(p) for p in deps]
        run('compile-backend','compile_backend_argv')
        require(h.dependencies(C/'ggml-vulkan.cpp.d')==deps,'Compiler dependency set changed')
        proof['dependencies_after']=[h.pin(p) for p in deps];require(proof['dependencies_before']==proof['dependencies_after'],'Dependency bytes changed')
        original=Path(r['archive_copy']['source']);h.verify(r['archive_copy']['source_pin']);old=h.members(original)
        with original.open('rb') as src,(C/'libggml-vulkan.a').open('xb') as dst:shutil.copyfileobj(src,dst)
        run('replace-backend-member','archive_replace_argv');run('index-backend-archive','archive_index_argv')
        new=h.members(C/'libggml-vulkan.a');member=r['archive_member']
        require([x['name'] for x in old]==[x['name'] for x in new] and sum(x['name']==member for x in old)==1,'Archive member layout differs')
        require(all(a==b for a,b in zip(old,new,strict=True) if a['name']!=member),'Unrelated archive member changed')
        obj=h.pin(C/'ggml-vulkan.cpp.o');replacement=next(x for x in new if x['name']==member)
        require(all(replacement[k]==obj[k] for k in ('bytes','sha256')),'Object replacement mismatch')
        proof['archive_members_before']=old;proof['archive_members_after']=new
        links=sorted({x['canonical_path'] for x in r['unchanged_link_input_pins']}|{str(C/'libggml-vulkan.a')})
        proof['link_inputs_before']=[h.pin(p) for p in links];run('link-baseline','link_baseline_argv')
        require(h.dependencies(C/'link-baseline.d')==links,'Link dependency set differs')
        proof['link_inputs_after']=[h.pin(p) for p in links];require(proof['link_inputs_before']==proof['link_inputs_after'],'Link bytes changed')
        proof['inherited_inputs_after']=[h.verify(x) for x in r['unchanged_input_pins']]
        proof['baseline_source_after']=[h.verify(x) for x in r['source_pins']]
        require(proof['inherited_inputs_before']==proof['inherited_inputs_after'] and proof['baseline_source_before']==proof['baseline_source_after'],'Inherited input changed')
        require(sources==[h.pin(C/n) for n in ('ggml-vulkan.cpp','matrix_trace.hpp','ggml-vulkan.patch')],'Candidate source changed')
        proof['artifacts']={name:h.pin(C/name) for name in ('ggml-vulkan.cpp.o','libggml-vulkan.a','candidate-stem-runtime')}
        require(time.monotonic()<deadline,'CPU build deadline exceeded');proof['passed']=True
    except BaseException as error:proof['error']=repr(error);raise
    finally:
        proof['elapsed_seconds']=time.monotonic()-began
        with (C/'build-receipt-01.json').open('x') as out:json.dump(proof,out,indent=2);out.write('\n')
        print(json.dumps({k:proof.get(k) for k in ('passed','elapsed_seconds','error')}),flush=True)

if __name__=='__main__':main()
