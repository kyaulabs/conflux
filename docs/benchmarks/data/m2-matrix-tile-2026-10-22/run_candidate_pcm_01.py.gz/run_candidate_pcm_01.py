#!/usr/bin/env python3
"""Dry default. One fixed candidate PCM16/route check; no player dispatch."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
import time

sys.dont_write_bytecode = True
C = Path(__file__).resolve().parent
N = C.parent / 'matrix-dispatch-metadata-01'
ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
PLAN, HUMAN = C/'candidate-pcm-plan-01.json', C/'human-readiness-pcm-01.json'
OUTPUT = C/'pcm-equivalence-candidate-01'
MODE = 'matrix-shape-large-candidate-pcm16-01'
RUNTIME_SHA = '7b97326b805bde89087aedfc525d86bbbdf163f7d9813bc1b26e5c6811de9f3f'
COMMON_SHA = 'b7b276273ea2f9829aca51c119d8dfe9abacd52df09ebc47f5d545631abde33e'
PCM_SHA = '29d244a7f56cffe02147cd9049671bd4c995f5b349cc9376b0e7602e07d59e7e'
CACHE_SHA = '5e2687a17648c305607983e56263435984e64b744036960cf29517d8fd9b6371'
BASELINE_RESULT_SHA = '02f6581bf861eaad2e4b40e546265723591fb8c08cde4b3ca4b5878201a85f81'
BASELINE_STDERR_SHA = '1927d2c5e378e936cece8fac721ca27f398f5a9ac0988dd635c9254360c73b6d'
BASELINE_PLAN_SHA = 'e82d421e793c9787c403e330e517d3bf7919d38a198ab207d4914b261501cc19'
REQUIRED_LOCAL = ('run_candidate_pcm_01.py', 'candidate_build.py', 'tile_activation.py',
                  'cache_support.py', 'build_candidate_01.py', 'source-review-02.json',
                  'ggml-vulkan.cpp', 'matrix_trace.hpp', 'ggml-vulkan.patch',
                  'ggml-vulkan.cpp.o', 'libggml-vulkan.a')
PCM_EXCLUDED_UI_ROLES = ('workload_qml_main', 'workload_qml_deck', 'workload_qml_mixer', 'workload_qml_button',
    'workload_qml_window_actions', 'workload_qml_knob', 'workload_qml_meter',
    'workload_brand_module', 'workload_brand_theme', 'workload_font_body', 'workload_font_display',
    'workload_font_mono', 'workload_logo_dark', 'workload_logo_light')
PCM_SCOPE = ('Exact16 silent candidate PCM outputs and exact-shape activation comparison against immutable N03 evidence; '
    'no UI, audio-output, player, timing or latency qualification;4095ms unchanged and unassessed.')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def private_bytes(path, maximum=256*1024, *, expected_sha=None, allow_empty=False):
    """Bootstrap verified-buffer imports; zero is allowed only for build logs."""
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path, 'Canonical private input required')
    fd = os.open(path, os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        first = os.fstat(fd)
        require(stat.S_ISREG(first.st_mode) and first.st_uid == os.getuid() and first.st_nlink == 1
                and int(not allow_empty) <= first.st_size <= maximum, 'Private input size/type differs')
        raw = bytearray()
        while len(raw) < first.st_size:
            part = os.read(fd, min(1024*1024, first.st_size-len(raw)))
            require(part, 'Private input truncated'); raw.extend(part)
        signature = lambda s: (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        require(signature(first) == signature(os.fstat(fd)) == signature(path.lstat()), 'Private input changed')
        pin = {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
        require(expected_sha is None or pin['sha256'] == expected_sha, 'Private source hash differs')
        return bytes(raw), pin
    finally:
        os.close(fd)


def load_verified(name, path, digest):
    raw, _ = private_bytes(path, expected_sha=digest)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def validate_readiness(value, pinned, plan_pin, utc_now, sampled_monotonic, boot_id):
    issued = datetime.fromisoformat(value.get('recorded_at_utc',''))
    age = (utc_now-issued).total_seconds() if issued.tzinfo else -1
    require(type(value.get('schema')) is int and value['schema'] == 1 and value.get('decision') == 'ready'
        and value.get('ready_for_diagnostic') == value.get('diagnostic_mode') == MODE
        and value.get('stages') == ['pcm16'] and value.get('UI_load') is False and value.get('audio_load') is False
        and type(value.get('maximum_operator_seconds')) is int and value['maximum_operator_seconds'] == 300
        and value.get('plan_sha256') == plan_pin['sha256'] and value.get('boot_id') == boot_id
        and 0 <= age < 300 and all(value.get(k) is True for k in
            ('AC_power','lid_open','Codex_minimized','other_work_paused','manual_player_closed','no_suspend'))
        and all(type(value.get(k)) is str and 0 < len(value[k]) <= 8192 for k in
            ('question_item_id','human_question','human_reply')), 'Fresh actual PCM-only readiness required')
    return {'record':value,'pin':pinned,'age_seconds':age,'sampled_monotonic':sampled_monotonic,
            'maximum_age_seconds':300,'boot_id':boot_id}


def operator_budget(ready, now_monotonic, phase_started, phase='pcm'):
    require(phase == 'pcm', 'This packet cannot dispatch a player phase')
    age, sampled = ready['age_seconds'], ready['sampled_monotonic']
    require(all(type(x) in (int,float) and math.isfinite(x) for x in
                (age,sampled,now_monotonic,phase_started)) and 0 <= age <= 120
            and 0 <= sampled <= phase_started <= now_monotonic, 'Initial PCM readiness is stale or invalid')
    end = sampled + 300-age
    remaining = end-now_monotonic
    require(remaining > 105, 'Original PCM window lacks profile and cleanup reserve')
    return {'phase':'pcm','age_seconds':age,'approval_sample_monotonic':sampled,
        'remaining_operator_seconds':remaining,'permitted_seconds':min(300,remaining),
        'operator_deadline_monotonic':end,'phase_deadline_monotonic':end,
        'external_INT_after_seconds':remaining-30,'external_kill_grace_seconds':30,
        'scope':'One original300s human UTC/monotonic PCM window; no player or deadline renewal'}


def same_pin(a, b):
    return (type(a) is dict and type(b) is dict and all(a.get(k) == b.get(k) for k in ('path','bytes','sha256'))
            and a.get('canonical_path',a.get('path')) == b.get('canonical_path',b.get('path')))


def pcm_sources(baseline):
    """Only the explicit, unconsumed UI rows leave the current PCM closure."""
    sources = baseline['source_pins']
    require(all(key in sources for key in PCM_EXCLUDED_UI_ROLES), 'Historical UI source roles absent')
    return {key:row for key,row in sources.items() if key not in PCM_EXCLUDED_UI_ROLES}


def validate_historical_result(value, history):
    require(value.get('status') == 'passed' and value.get('cleanup_complete') is True
        and value.get('attention_series',{}).get('passed') is True
        and value.get('matrix_series',{}).get('passed') is True, 'Historical comparison proof did not pass')
    require(same_pin(value.get('plan_pin'),history['plan'])
        and same_pin(value.get('candidate_runtime'),history['runtime'])
        and same_pin(value.get('model'),history['model'])
        and value.get('reference_runtime_sha256') == history['reference_runtime_sha256']
        and value.get('source_head') == history['source_head'], 'Historical result provenance differs')


def validate_plan_structure(plan, parent):
    raw,baseline_pin = private_bytes(N/'matrix-player-plan-03.json',expected_sha=BASELINE_PLAN_SHA)
    baseline = json.loads(raw)
    require(type(plan.get('schema')) is int and plan['schema'] == 1
        and plan.get('status') == 'frozen_pending_fresh_candidate_pcm_readiness'
        and plan.get('mode') == MODE and plan.get('consent') is None
        and plan.get('qualified') is False and plan.get('physical_execution') is False
        and plan.get('timing_qualification') is False and plan.get('stages') == ['pcm16']
        and type(plan.get('operator_seconds')) is int and plan['operator_seconds'] == 300
        and type(plan.get('pcm_seconds')) is int and plan['pcm_seconds'] == 300
        and plan.get('UI_load') is False and plan.get('audio_load') is False
        and all(type(plan.get(k)) is int and plan[k] == value for k,value in
                (('request_seconds',30),('profile_seconds',60),('readiness_seconds',195),('cleanup_seconds',45)))
        and plan.get('source_root') == str(ROOT) and re.fullmatch('[0-9a-f]{40}',plan.get('source_head',''))
        and plan.get('drm_device') == {'driver':'i915','pdev':'0000:00:02.0'}
        and plan.get('logger_environment') == parent.LOGGER
        and type(plan.get('strict_service_target_ms')) is int and plan['strict_service_target_ms'] == 4095
        and plan.get('reference_runtime_sha256') == '6f4dca329ee158ad4c1abe963cd9d0940d63ba8a309afdc8b4cd1b7259edbc53'
        and plan.get('cache_policy') == 'identical-verified-private-seed-copies-128M', 'Unarmed or out-of-scope candidate plan')
    require(not any(key in plan for key in ('root_dispatch','seconds','phase_seconds','interstage_seconds',
        'window_policy','build_scope','offline_preparation')) and plan.get('scope') == PCM_SCOPE,
        'Inherited player/dispatch or stale scope metadata is not PCM-only')
    assets = dict(parent.ASSETS); assets['runtime'] = C/'candidate-stem-runtime'
    require(set(plan.get('assets',{})) == set(assets)
        and all(plan['assets'][k].get('path') == str(p) for k,p in assets.items())
        and plan['assets']['runtime'].get('sha256') == RUNTIME_SHA
        and plan['assets']['model'].get('sha256') == 'f8c54ba35df95aafea7881eac214b58ec18a73cbcb6ff5a90f4b762631a286b6', 'Fixed assets differ')
    require(type(plan.get('runtimes')) is dict and set(plan['runtimes']) == {'candidate'}
        and same_pin(plan['runtimes']['candidate'],plan['assets']['runtime']), 'Candidate runtime identity differs')
    require(all(same_pin(plan['assets'][k],v) for k,v in baseline['assets'].items() if k != 'runtime')
        and all(same_pin(plan.get(k),baseline[k]) for k in ('gpu_helper','package_helper','seed_proof'))
        and plan.get('seed_manifest_sha256') == baseline['seed_manifest_sha256'], 'Inherited assets/seed/observers differ')
    sources = plan.get('source_pins',{})
    require(type(sources) is dict and all(type(row) is dict for row in sources.values()), 'Source closure absent')
    paths = {row.get('path'):row for row in sources.values()}
    changed_roles = {'matrix_source':C/'ggml-vulkan.cpp','matrix_header':C/'matrix_trace.hpp',
                     'backend_object':C/'ggml-vulkan.cpp.o','backend_archive':C/'libggml-vulkan.a'}
    require(not any(key in sources for key in PCM_EXCLUDED_UI_ROLES), 'Unconsumed UI role reintroduced into PCM closure')
    for key,row in pcm_sources(baseline).items():
        require(key in sources and (sources[key].get('path') == str(changed_roles[key]) if key in changed_roles
            else same_pin(sources[key],row)), 'Inherited source/consumer role differs: '+key)
    for path in [*(C/name for name in REQUIRED_LOCAL), N/'run_profile_pcm.py', N/'profile_launch.py',
                 N/'matrix_series.py', N/'build_recipe.json', N/'root_cpu_build_01.py',
                 N/'root-fixture-result-01.json', N/'pcm-equivalence-01/result.json',
                 N/'pcm-equivalence-01/native.stderr', N/'matrix-player-plan-03.json']:
        require(str(path) in paths, 'Mandatory candidate/reference source absent: '+str(path))
    require(paths[str(N/'profile_launch.py')]['sha256'] == COMMON_SHA
        and paths[str(N/'run_profile_pcm.py')]['sha256'] == PCM_SHA
        and paths[str(N/'pcm-equivalence-01/result.json')]['sha256'] == BASELINE_RESULT_SHA
        and paths[str(N/'pcm-equivalence-01/native.stderr')]['sha256'] == BASELINE_STDERR_SHA
        and plan['cache_helper'].get('path') == str(C/'cache_support.py')
        and plan['cache_helper'].get('sha256') == CACHE_SHA
        and plan['build_result'].get('path') == str(C/'build-receipt-01.json')
        and plan['review'].get('path') == str(C/'candidate-pcm-preparation-review-01.json')
        and plan['review'].get('status') == 'passed', 'Fixed candidate proof binding differs')
    history = plan.get('historical_reference',{})
    require(type(history) is dict and set(history) == {'plan','pcm_result','matrix_stderr','runtime','model',
        'reference_runtime_sha256','source_head'}
        and same_pin(history.get('plan'),baseline_pin)
        and same_pin(history['plan'],paths[str(N/'matrix-player-plan-03.json')])
        and same_pin(history.get('pcm_result'),paths[str(N/'pcm-equivalence-01/result.json')])
        and same_pin(history.get('matrix_stderr'),paths[str(N/'pcm-equivalence-01/native.stderr')])
        and same_pin(history.get('runtime'),baseline['assets']['runtime'])
        and same_pin(history.get('model'),baseline['assets']['model'])
        and history.get('reference_runtime_sha256') == baseline['reference_runtime_sha256']
        and history.get('source_head') == baseline['source_head'], 'Immutable historical reference differs')
    require(plan.get('native_schema') == 2 and type(plan['native_schema']) is int
        and plan.get('native_mode') == 'passive_drm_owned_client_set_v1'
        and plan.get('native_trace_limits') == {'record_bytes':16384,'file_bytes':1048576,'requests':64,'physical_rows':82}
        and plan.get('profile_limits') == baseline['profile_limits'],
        'Capture/native protocol limits differ')
    for row in [*sources.values(),*plan['assets'].values(),*[plan[k] for k in
                ('cache_helper','gpu_helper','package_helper','seed_proof','build_result','review')]]:
        require(type(row.get('path')) is str and Path(row['path']).is_absolute()
            and type(row.get('bytes')) is int and row['bytes'] > 0
            and re.fullmatch('[0-9a-f]{64}',row.get('sha256','')), 'Incomplete positive file pin')


def validate_review(plan, parent):
    review,_ = parent.read_json(C/'candidate-pcm-preparation-review-01.json',256*1024,plan['review'])
    require(type(review.get('schema')) is int and review['schema'] == 1 and review.get('status') == 'passed'
        and review.get('physical_execution') is False, 'Actual preparation review did not pass')
    declared = {row['path']:row for row in plan['source_pins'].values()}
    reviewed = review.get('source_pins',[])
    require(type(reviewed) is list and len({row.get('path') for row in reviewed}) == len(reviewed),
        'Actual review source pins are invalid')
    indexed = {row['path']:row for row in reviewed}
    for name in ('run_candidate_pcm_01.py','candidate_build.py','tile_activation.py','cache_support.py',
                 'test_candidate_driver.py','test_candidate_build.py','test_tile_activation.py',
                 'prepare_candidate_plan_01.py'):
        path = str(C/name)
        require(path in indexed and path in declared and same_pin(indexed[path],declared[path]),
            'Preparation review omitted or changed '+name)
    result_pin = review.get('cpu_checks',{})
    require(result_pin.get('path') == str(C/'cpu-check-result-01.json')
        and same_pin(result_pin,declared.get(result_pin['path'])), 'Actual CPU check pin absent')
    result,_ = parent.read_json(C/'cpu-check-result-01.json',256*1024,result_pin)
    require(result.get('passed') is True and type(result.get('exit_code')) is int and result['exit_code'] == 0
        and result.get('GPU_or_native_runtime_executed') is False, 'Actual CPU checks did not pass')
    tested = {row['path']:row for row in result.get('source_pins',[])}
    require(all(same_pin(indexed[str(C/name)],tested.get(str(C/name))) for name in
        ('run_candidate_pcm_01.py','candidate_build.py','tile_activation.py','test_candidate_driver.py',
         'test_candidate_build.py','test_tile_activation.py')), 'Tested and reviewed sources differ')


def bind(plan, parent):
    """Bind fresh module instances only; all frozen N source files stay unchanged."""
    parent.BASE, parent.PLAN, parent.HUMAN, parent.MODE = C, PLAN, HUMAN, MODE
    parent.PCM_OUTPUT = OUTPUT
    parent.OUTPUT, parent.INTERSTAGE_AUDIT = C/'unused-player', C/'unused-interstage.json'
    parent.ASSETS = {k:Path(v['path']) for k,v in plan['assets'].items()}
    parent.SOURCES = {k:Path(v['path']) for k,v in plan['source_pins'].items()}
    indexed = {v['path']:v for v in plan['source_pins'].values()}
    old,_ = parent.read_json(N/'pcm-equivalence-01/result.json',8*1024**2,indexed[str(N/'pcm-equivalence-01/result.json')])
    validate_historical_result(old,plan['historical_reference'])
    def module(name, path):
        row = indexed[str(path)]; return load_verified(name,path,row['sha256'])
    build_module = module('candidate_build_gate', C/'candidate_build.py')
    activation = module('candidate_tile_activation', C/'tile_activation.py')
    def verify_logs(deadline):
        for row in plan['build_log_pins']:
            require(time.monotonic() < deadline, 'Build-log verification budget exhausted')
            _, current = private_bytes(Path(row['path']),1024*1024,allow_empty=True)
            require(same_pin(current,row), 'Actual build command log changed')
    def validate_build(candidate_plan):
        value,_ = parent.read_json(C/'build-receipt-01.json',2*1024**2,candidate_plan['build_result'])
        recipe,_ = parent.read_json(N/'build_recipe.json',256*1024,indexed[str(N/'build_recipe.json')])
        review,_ = parent.read_json(C/'source-review-02.json',65536,indexed[str(C/'source-review-02.json')])
        return build_module.validate_build(value,recipe,candidate_plan,review)
    parent.validate_build = validate_build
    def readiness(path, pin):
        require(path == HUMAN, 'Only this candidate PCM readiness record is allowed')
        value,pinned = parent.read_json(path,16384)
        boot = (Path('/proc/sys/kernel/random/boot_id').read_text()).strip()
        return validate_readiness(value,pinned,pin,datetime.now(timezone.utc),time.monotonic(),boot)
    parent.readiness = readiness
    # N's captured-default load_plan and combined readiness must never be used.
    parent.load_plan = lambda path=PLAN: (_ for _ in ()).throw(ValueError('Use the candidate entry gate'))
    player = parent.load_player(plan)
    player.operator_budget = operator_budget
    original_verify = player.verify_plan_files
    def verify_files(candidate_plan, deadline):
        original_verify(candidate_plan,deadline); verify_logs(deadline)
    player.verify_plan_files = verify_files
    runner = load_verified('candidate_pcm_run',N/'run_profile_pcm.py',PCM_SHA)
    original_finalize, original_gates = runner.finalize_series, runner.apply_final_gates
    def finalize(report, output, candidate_plan, common, deadline):
        original_finalize(report,output,candidate_plan,common,deadline)
        require(time.monotonic() < deadline, 'Activation comparison budget exhausted')
        old,_ = parent.read_json(N/'pcm-equivalence-01/result.json',8*1024**2,indexed[str(N/'pcm-equivalence-01/result.json')])
        validate_historical_result(old,candidate_plan['historical_reference'])
        parser = module('candidate_matrix_parser',N/'matrix_series.py')
        old_raw,old_pin = parent.read_file(N/'pcm-equivalence-01/native.stderr',40*1024**2,indexed[str(N/'pcm-equivalence-01/native.stderr')])
        new_raw,new_pin = parent.read_file(output/'native.stderr',40*1024**2,report['native_stderr'])
        graphs_a = parser.parse_series(old_raw,expected_graphs=16)['graphs']
        graphs_b = parser.parse_series(new_raw,expected_graphs=16)['graphs']
        report['tile_activation'] = activation.compare_activation(graphs_a,graphs_b,old['requests'],report['requests'],
            baseline_raw_pin={k:old_pin[k] for k in ('path','bytes','sha256')},
            candidate_raw_pin={k:new_pin[k] for k in ('path','bytes','sha256')})
        verify_files(candidate_plan,deadline)
        validate_build(candidate_plan)
        again = player.readiness(HUMAN,report['plan_pin'])
        require(again['pin'] == report['human_pin'], 'Original PCM readiness changed during finalization')
        require(time.monotonic() < deadline, 'Activation/build finalization exhausted original deadline')
    def gates(report, case_ids, started, deadline):
        original_gates(report,case_ids,started,deadline)
        if not (report.get('tile_activation',{}).get('passed') is True
                and report['tile_activation'].get('activations') == 16):
            report['status'] = 'interrupted' if report['status'] == 'interrupted' else 'failed'
            report['errors'].append({'phase':'tile_activation','message':'Sixteen exact tile activations required'})
    runner.finalize_series,runner.apply_final_gates = finalize,gates
    return player,runner


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true')
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({'status':'unarmed_dry_plan','cases':16,'maximum_seconds':300,
            'host_queried':False,'native_started':False,'player_dispatch':False})); return 0
    require(PLAN.is_file() and HUMAN.is_file(), 'Final reviewed plan and fresh actual readiness are missing')
    parent = load_verified('candidate_parent_common',N/'profile_launch.py',COMMON_SHA)
    plan,pin = parent.read_json(PLAN,256*1024)
    validate_plan_structure(plan,parent)
    validate_review(plan,parent)
    player,runner = bind(plan,parent)
    human = player.readiness(HUMAN,pin)
    return runner.run(player,plan,pin,human,parent)


if __name__ == '__main__':
    raise SystemExit(main())
