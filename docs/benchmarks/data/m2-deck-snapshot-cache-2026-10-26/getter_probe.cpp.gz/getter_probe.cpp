// Private CPU probe: no audio session, window, media or model is opened.
#include "ui/DeckController.hpp"
#include <QCoreApplication>
#include <QCryptographicHash>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>
#include <chrono>
#include <ctime>
#include <iostream>
#include <stdexcept>

static std::int64_t cpuNs()
{
    timespec value{};
    if (clock_gettime(CLOCK_THREAD_CPUTIME_ID, &value) != 0)
        throw std::runtime_error("CPU clock failed");
    return std::int64_t(value.tv_sec) * 1000000000 + value.tv_nsec;
}

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName("conflux-private-getter-probe");
    QTemporaryDir data;
    if (!data.isValid()) return 2;
    qputenv("XDG_DATA_HOME", data.path().toUtf8());
    qputenv("XDG_CACHE_HOME", data.path().toUtf8());
    conflux::DeckController controller;
    const auto before = controller.decks();
    if (before.size() != 2 || controller.outputReady()) return 3;
    QJsonArray samples;
    for (int repeat = 0; repeat < 3; ++repeat) {
        const auto cpu = cpuNs();
        const auto wall = std::chrono::steady_clock::now();
        for (int index = 0; index < 5000; ++index) {
            const auto rows = controller.decks();
            if (rows.size() != 2 || rows[0].toMap()["loaded"].toBool()) return 4;
        }
        samples.append(QJsonObject{{"calls", 5000}, {"thread_cpu_ns", qint64(cpuNs() - cpu)},
            {"wall_ns", qint64(std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now() - wall).count())}});
    }
    if (controller.decks() != before || controller.outputReady()) return 5;
    const auto serialized = QJsonDocument(QJsonArray::fromVariantList(before)).toJson(QJsonDocument::Compact);
    controller.shutdown();
    std::cout << QJsonDocument(QJsonObject{{"schema", 1}, {"passed", true},
        {"deck_snapshot_sha256", QString::fromLatin1(QCryptographicHash::hash(serialized, QCryptographicHash::Sha256).toHex())},
        {"samples", samples}, {"audio_started", false}, {"model_started", false},
        {"scope", "Empty-deck repeated GUI-thread reads only; not QML, loaded playback, thermal or latency qualification"}})
        .toJson(QJsonDocument::Compact).constData() << '\n';
}
