"""Compile and run one isolated empty-deck CPU comparison, without host audio."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
HERE = Path(__file__).resolve().parent


def pin(path):
    with path.open('rb') as stream:
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': value}


def main():
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    flags = shlex.split(subprocess.check_output(['pkg-config', '--cflags', '--libs',
        'Qt6Core', 'Qt6Gui', 'Qt6Concurrent', 'taglib', 'sndfile', 'samplerate',
        'rubberband', 'libpipewire-0.3'], text=True, timeout=10))
    results = []
    for name, source, build in (
        ('baseline', ROOT / 'build/m2-profile-reporting-worktree', ROOT / 'build/m2-hour-history-01/current-native-build-01'),
        ('candidate', Path('/home/kyau/.codex/worktrees/deck-state-cache/conflux'), HERE / 'native-build-01')):
        binary = HERE / ('getter-probe-' + name)
        archives = [build / ('lib' + lib + '.a') for lib in
            ('conflux-ui', 'conflux-library', 'conflux-audio-live', 'conflux-audio')]
        command = ['/usr/bin/c++', '-std=c++20', '-O2', '-DNDEBUG', '-fPIC',
            '-I' + str(source / 'src'), str(HERE / 'getter_probe.cpp'),
            *(str(path) for path in archives), *flags, '-o', str(binary)]
        subprocess.run(command, capture_output=True, check=True, timeout=90)
        output = subprocess.run([str(binary)], capture_output=True, check=True, timeout=20)
        assert len(output.stdout) < 16384 and len(output.stderr) < 16384
        value = json.loads(output.stdout)
        assert value['passed'] and not value['audio_started'] and not value['model_started']
        results.append({'name': name, 'compile_command': command, 'result': value,
            'binary': pin(binary), 'archive_pins': [pin(path) for path in archives],
            'source_pins': [pin(source / p) for p in ('src/ui/DeckController.cpp', 'src/ui/DeckController.hpp')],
            'stderr': output.stderr.decode()})
    assert results[0]['result']['deck_snapshot_sha256'] == results[1]['result']['deck_snapshot_sha256']
    cpu = [sum(row['thread_cpu_ns'] for row in value['result']['samples']) for value in results]
    report = {'schema': 1, 'passed': True, 'same_deck_snapshot': True,
        'probe': pin(HERE / 'getter_probe.cpp'), 'results': results,
        'candidate_to_baseline_thread_CPU_ratio': cpu[1] / cpu[0],
        'scope': 'Offline empty-deck repeated reads only; no QML, playback, thermal, loaded-deck or service-latency qualification.'}
    with (HERE / 'getter-probe-results-01.json').open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({'passed': True, 'same_deck_snapshot': True, 'calls_per_arm': 15000,
        'baseline_thread_CPU_ms': cpu[0] / 1e6, 'candidate_thread_CPU_ms': cpu[1] / 1e6,
        'candidate_to_baseline_ratio': cpu[1] / cpu[0]}))


if __name__ == '__main__':
    main()
