"""Move one reported failed-hour recording after byte/hash verification."""
from pathlib import Path
import ast,hashlib,json,os,subprocess
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent.parent.parent
SOURCE=ROOT/'build/m2-onedrive-player-hour-01/laptop-results-01/candidate/output-01/master.wav'
DEST='/srv/conflux-tests/work/retained-hour-audio-20261029-01/m2-onedrive-player-hour-01-master.wav'
PART=DEST+'.partial-20261029-01'
m=ast.parse((BASE.parent/'observe_both.py').read_text());ssh=ast.literal_eval(next(n.value for n in m.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SSH' for t in n.targets)))
def pin(p):
 assert p.is_file() and not p.is_symlink();st=p.stat()
 with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=st.st_size,sha256=digest,device=st.st_dev,inode=st.st_ino,mtime_ns=st.st_mtime_ns)
assert not Path(str(SOURCE)+'.apollo-archive.json').exists()
summary=json.loads((ROOT/'build/m2-onedrive-player-hour-01/analysis-01/results-summary-01.json').read_text())
assert summary['hosts']['laptop']['recording']['integrity_complete']
source=pin(SOURCE);assert source['bytes']==1384464472
intent=dict(schema=1,source=source,destination=DEST,temporary_destination=PART,reason='User requested benchmark disk cleanup; preserve already reported failed-hour WAV on dedicated Apollo archive',reports_and_failure_results_preserved=True)
intent_path=BASE/'hour-audio-move-intent-01.json'
if intent_path.exists():assert json.loads(intent_path.read_text())==intent
else:
 with intent_path.open('x') as f:f.write(json.dumps(intent,indent=2)+'\n')
code='DEST='+repr(DEST)+'\nPART='+repr(PART)+'\nSIZE='+repr(source['bytes'])+'\n'+"""from pathlib import Path
import json,os,shutil
p=Path(DEST);part=Path(PART)
assert p.parent.is_dir() and not p.parent.is_symlink() and p.parent.stat().st_uid==1000
assert not p.exists() and not p.is_symlink() and not part.exists() and not part.is_symlink()
assert shutil.disk_usage(p.parent).free>=SIZE+1024**3
print(json.dumps({'ready':True,'bytes':SIZE}))
"""
r=subprocess.run(ssh+['python3 -'],input=code,text=True,capture_output=True,timeout=20);assert r.returncode==0,r.stderr
print('Copying the retained failed-hour recording to the dedicated Apollo archive.',flush=True)
with SOURCE.open('rb') as stream:r=subprocess.run(ssh+['dd conv=excl oflag=nofollow status=none of='+PART],stdin=stream,capture_output=True,timeout=180)
assert r.returncode==0,r.stderr.decode(errors='replace')
code='DEST='+repr(DEST)+'\nPART='+repr(PART)+'\nEXPECTED='+repr(source)+'\n'+"""from pathlib import Path
import hashlib,json,os
p=Path(DEST);part=Path(PART);assert part.is_file() and not part.is_symlink()
with part.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
assert part.stat().st_size==EXPECTED['bytes'] and digest==EXPECTED['sha256']
os.link(part,p,follow_symlinks=False)
assert p.stat().st_ino==part.stat().st_ino
part.unlink()
print(json.dumps({'destination':str(p),'bytes':p.stat().st_size,'sha256':digest,'partial_absent':not part.exists(),'copy_verified':True}))
"""
r=subprocess.run(ssh+['python3 -'],input=code,text=True,capture_output=True,timeout=30);assert r.returncode==0,r.stderr
verified=json.loads(r.stdout);assert pin(SOURCE)==source
pointer=dict(source=source,**verified,freed_bytes=source['bytes'],local_original_removed_after_verified_copy=True)
SOURCE.unlink();Path(str(SOURCE)+'.apollo-archive.json').write_text(json.dumps(pointer,indent=2)+'\n')
with (BASE/'hour-audio-move-complete-01.json').open('x') as f:f.write(json.dumps(pointer,indent=2)+'\n')
print(json.dumps({'archive_verified':True,'freed_bytes':source['bytes'],'local_pointer':str(SOURCE)+'.apollo-archive.json'}),flush=True)
