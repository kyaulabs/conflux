"""Verify owned settings restored, preserving lower external guard limits."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess
BASE=Path(__file__).resolve().parent.parent

def show(unit,user=False):
 return dict(s.split('=',1) for s in subprocess.check_output(['systemctl']+(['--user'] if user else [])+['show',unit,'--property=LoadState,ActiveState,SubState,MainPID,InvocationID,ControlGroup'],text=True,timeout=5).splitlines())
g=json.loads((BASE/'guarded-outcome.json').read_text());receipt=g['cap_cleanup']['root_receipt']
root=show('conflux-m2-short-cap-20261029-03.service');assert root['MainPID']=='0' and root['ActiveState']=='inactive',root
local=show('conflux-m2-short-cap-laptop-20261029-03.service',True);assert local['MainPID']=='0' and local['ActiveState']=='inactive'
onedrive=show('onedrive.service',True);assert onedrive['ActiveState']=='active' and int(onedrive['MainPID'])>0
assert Path('/proc',onedrive['MainPID'],'exe').resolve()==Path('/usr/bin/onedrive')
constraints={p:int(Path(p).read_text()) for p in receipt['constraints_before']};external_lower={}
for p,before in receipt['constraints_before'].items():
 current=constraints[p]
 if p.endswith('power_limit_uw'):
  assert 0<current<=before,(p,before,current)
  if current<before:external_lower[p]={'before':before,'after':current}
 else:assert current==before,(p,before,current)
assert constraints[receipt['cap']]==64000000
assert hashlib.sha256(Path('/home/kyau/.local/bin/thermal-guard').read_bytes()).hexdigest()=='6e2ebbe97e3fc4a679c16b347b67fe99f9daf88391cb68aa3ca8924fd65886d6'
assert hashlib.sha256(Path('/home/kyau/.config/systemd/user/thermal-guard.service').read_bytes()).hexdigest()=='e5c6c89f2b186b976379b2ee4ffb0d3e044e1cf9b1fca3a0cf60cc600c9b2d8f'
guard=show('thermal-guard.service',True);assert guard['ActiveState']=='active'
inhibitions=json.loads(subprocess.check_output(['busctl','--user','--timeout=2s','--json=short','call','org.kde.Solid.PowerManagement.PolicyAgent','/org/kde/Solid/PowerManagement/PolicyAgent','org.kde.Solid.PowerManagement.PolicyAgent','ListInhibitions'],text=True));assert 'conflux' not in json.dumps(inhibitions).lower()
out=dict(schema=1,utc=datetime.now(timezone.utc).isoformat(),owned_laptop_unit=local,root_cap_unit=root,onedrive=onedrive,onedrive_executable_verified=True,constraints_after=constraints,cap_uw=constraints[receipt['cap']],thermal_guard=guard,thermal_guard_pins_unchanged=True,kde_inhibitions_after=inhibitions,owned_inhibitions_released=True,free_bytes=shutil.disk_usage(BASE).free,owned_setting_restored=True,external_lower_limits_preserved=external_lower,no_host_writes_during_final_verification=True)
with (BASE/'final-host-restoration-01.json').open('x') as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({'settings_restored':True,'OneDrive':'active','guard':'active','owned_inhibitions_released':True,'free_bytes':out['free_bytes'],'lower_limits_preserved':external_lower}))
