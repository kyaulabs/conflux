"""Reject insufficient storage before dispatch, sync pause or administrator action."""
import shutil

MINIMUM_FREE_BYTES = 3 * 1024**3


def verify(path):
    free = shutil.disk_usage(path).free
    if free < MINIMUM_FREE_BYTES:
        raise OSError('At least 3 GiB free space is required before benchmark host actions')
    return dict(free_bytes=free, minimum_free_bytes=MINIMUM_FREE_BYTES)
