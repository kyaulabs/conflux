"""Capture bounded terminal evidence and retire only bound completed test units."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,subprocess
BASE=Path(__file__).resolve().parent
BIND=json.loads((BASE/'owner-binding-01.json').read_text())
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
COMMON=r'''
from pathlib import Path
import hashlib,json,subprocess
base=Path(BASE)
def show(unit):
 return dict(line.split('=',1) for line in subprocess.check_output(['systemctl']+(['--user'] if LOCAL else [])+['show',unit,'--property=LoadState,ActiveState,SubState,MainPID,InvocationID,ControlGroup,Result,ExecMainStatus'],text=True,timeout=10).splitlines())
def empty(path):
 p=Path('/sys/fs/cgroup')/path.lstrip('/')
 return not p.exists() or all(not f.read_text().strip() for f in p.rglob('cgroup.procs'))
unit=BIND['unit'];before=show(unit)
assert before['InvocationID']==BIND['InvocationID'] and before['MainPID']=='0',before
assert before['ActiveState']=='active' and before['SubState']=='exited',before
assert empty(BIND['ControlGroup']), 'Owned cgroup is not empty'
if LOCAL:
 pair=json.loads((base/'laptop-results-01/pair-result.json').read_text())
 guard=json.loads((base/'guarded-outcome.json').read_text())
 assert pair['completed'] and pair['cleanup_complete'] and guard['passed'] and guard['restore_complete']
 root=guard['cap_cleanup']['root_receipt']
 assert root['finished'] and root['restoration_complete'] and root['after_restore_uw']==64000000
else:
 pair=json.loads((base/'pair-result-01.json').read_text())
 assert pair['pair_complete'] and pair['cleanup_complete']
subprocess.run(['systemctl','--user','stop',unit] if LOCAL else ['sudo','-n','systemctl','stop',unit],check=True,capture_output=True,text=True,timeout=30)
after=show(unit)
assert after['MainPID']=='0' and after['ActiveState']=='inactive',after
out={'before':before,'after':after,'original_cgroup_absent_or_empty':empty(BIND['ControlGroup'])}
assert out['original_cgroup_absent_or_empty']
if not LOCAL:
 docker=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
 ids=subprocess.check_output(docker+['ps','-a','--filter','label=org.kyaulabs.conflux.run=short-cap-player-20261029-03','--format','{{.ID}}'],text=True,timeout=10).splitlines()
 assert not ids,ids
 out['matching_containers_remaining']=0
 files=['pair-result-01.json','cases/candidate/receipt.json','cases/candidate/private-player-01/result.json','cases/candidate/private-player-01/recordings/actual-player/assessment.json','cases/candidate/private-player-01/recordings/actual-player/native-result.json','cases/candidate/private-player-01/recordings/actual-player/observation-summary.json']
 out['capture']={};out['pins']={}
 for name in files:
  path=base/name;assert path.is_file() and not path.is_symlink();raw=path.read_bytes();assert len(raw)<=1048576
  out['capture'][name]=json.loads(raw);out['pins'][name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
print(json.dumps(out))
'''
def run(host):
 local=host=='laptop'
 header='LOCAL='+repr(local)+'\nBASE='+repr(str(BASE) if local else '/srv/conflux-tests/work/short-cap-player-20261029-03')+'\nBIND='+repr(BIND[host])+'\n'
 r=subprocess.run(['python3','-'] if local else SSH+['python3 -'],input=header+COMMON,text=True,capture_output=True,timeout=60)
 assert r.returncode==0,(host,r.stderr)
 return json.loads(r.stdout)
with ThreadPoolExecutor(max_workers=2) as pool:
 a=pool.submit(run,'laptop');b=pool.submit(run,'apollo');result={'laptop':a.result(),'apollo':b.result()}
remote=result['apollo'].pop('capture');pins=result['apollo'].pop('pins')
for name,value in [('apollo-final-capture-01.json',remote),('apollo-capture-pins-01.json',pins)]:
 with (BASE/name).open('x') as f:f.write(json.dumps(value,indent=2)+'\n')
result.update(utc=datetime.now(timezone.utc).isoformat(),owned_units_retired=True,hardware_test_retried=False)
with (BASE/'owner-retirement-01.json').open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
