"""User-side lease request/cleanup; no privileged write without explicit activation."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time

BASE = Path(__file__).resolve().parent
ROOT_DIRECTORY = Path('/run/conflux-m2-short-cap-20261029-03')
STATE = ROOT_DIRECTORY / 'state.json'
STOP = BASE / 'burst-cap-stop'
INTENT = BASE / 'burst-cap-intent.json'
UNIT = 'conflux-m2-short-cap-20261029-03.service'
CAP = Path('/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_1_power_limit_uw')


def write_new(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def root_state():
    directory = ROOT_DIRECTORY.lstat()
    info = STATE.lstat()
    if (not stat.S_ISDIR(directory.st_mode) or directory.st_uid != 0 or directory.st_mode & 0o022 or
        not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022 or info.st_size > 65536):
        raise PermissionError('The cap cleanup receipt must be root-owned and non-writable by users')
    return json.loads(STATE.read_text())


def show():
    raw = subprocess.check_output(['systemctl', 'show', UNIT,
        '--property=LoadState,ActiveState,MainPID,InvocationID,Result'], text=True, timeout=5)
    return dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)


def start(human, plan):
    if not human.get('temporary_burst_cap_approved'):
        raise PermissionError('Fresh readiness must acknowledge the approved cap comparison')
    if INTENT.exists() or os.path.lexists(STOP) or ROOT_DIRECTORY.exists():
        raise FileExistsError('Never reuse an earlier cap lease')
    for key, name in (('burst_policy', 'burst_cap.py'), ('burst_installer', 'install_cap.py'),
                      ('burst_client', 'cap_client.py')):
        row = plan['pins'][key]
        path = BASE / name
        if path.is_symlink() or row['path'] != str(path) or path.stat().st_size != row['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
            raise ValueError('Cap helper identity changed: ' + name)
    # Reserve 90 seconds on the original operator clock for both services to stop.
    deadline = human['operator_deadline_monotonic'] - 90
    if not 300 <= deadline - time.monotonic() <= 1110:
        raise TimeoutError('No time for the player and bounded root cleanup')
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    write_new(INTENT, dict(schema=1, original_operator_deadline_monotonic=human['operator_deadline_monotonic'],
        deadline_monotonic=deadline, boot_id=boot, unit=UNIT, question_item_id=human['question_item_id']))
    command = ['/usr/bin/pkexec', '/usr/bin/python3.14', '-I', '-B', str(BASE / 'install_cap.py'),
        '--install', '--deadline', str(deadline), '--boot-id', boot]
    result = subprocess.run(command, capture_output=True, text=True, timeout=90)
    write_new(BASE / 'burst-cap-install-result.json', dict(exit=result.returncode, stdout=result.stdout, stderr=result.stderr))
    result.check_returncode()
    confirmation = json.loads(result.stdout)
    state = root_state()
    if not confirmation['applied'] or state.get('phase') != 'applied' or int(CAP.read_text()) != 15000000:
        raise RuntimeError('The root owner did not prove the single cap apply')
    return confirmation


def verify_held():
    state = root_state()
    if (state.get('phase') != 'applied' or state.get('finished') or
        time.monotonic() >= state['deadline_monotonic'] or int(CAP.read_text()) != 15000000):
        raise RuntimeError('The temporary short-term cap is no longer held')
    return state


def release():
    if not INTENT.exists():
        return dict(not_requested=True, restoration_complete=True)
    if not os.path.lexists(STOP):
        write_new(STOP, dict(stop_requested=True, monotonic=time.monotonic()))
    intent = json.loads(INTENT.read_text())
    until = min(time.monotonic() + 35, intent['original_operator_deadline_monotonic'] - 50)
    while time.monotonic() < until:
        service = show()
        if STATE.exists():
            state = root_state()
            if state.get('finished') and service['MainPID'] == '0':
                if not state.get('restoration_complete'):
                    raise RuntimeError('Root helper retained an uncertain limit; rollback is not proven')
                result = dict(root_receipt=state, terminal_service=service, restoration_complete=True)
                path = BASE / 'burst-cap-release-result.json'
                if not path.exists():
                    write_new(path, result)
                return result
        elif not ROOT_DIRECTORY.exists() and service['LoadState'] == 'not-found' and service['MainPID'] == '0':
            # Authentication may not have happened. The fixed stop flag prevents
            # a late pkexec request from applying; the original clock is unchanged.
            return dict(no_root_install=True, late_apply_blocked=True, restoration_complete=True)
        time.sleep(.25)
    raise TimeoutError('Root cap rollback/owner exit not proven within the original cleanup budget')
