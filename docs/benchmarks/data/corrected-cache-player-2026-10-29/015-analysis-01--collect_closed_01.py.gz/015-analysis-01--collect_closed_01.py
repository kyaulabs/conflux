"""Read only bounded evidence from this completed CONFLUX attempt."""
from pathlib import Path
import ast,hashlib,json,subprocess
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent
m=ast.parse((ROOT/'observe_both.py').read_text());ssh=ast.literal_eval(next(n.value for n in m.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SSH' for t in n.targets)))
code="""from pathlib import Path
import json,hashlib
b=Path('/srv/conflux-tests/work/short-cap-player-20261029-03')
names=['pair-result-01.json','cases/candidate/receipt.json','cases/candidate/private-player-01/result.json','cases/candidate/private-player-01/recordings/actual-player/assessment.json','cases/candidate/private-player-01/recordings/actual-player/native-result.json','cases/candidate/private-player-01/recordings/actual-player/observation-summary.json','cases/candidate/private-player-01/recordings/actual-player/observations.jsonl','cases/candidate/private-player-01/recordings/actual-player/player.stderr.log','cases/candidate/private-player-01/recordings/actual-player/player.stdout.log','unit.stdout.log','unit.stderr.log']
out={}
for n in names:
 p=b/n;assert p.is_file() and not p.is_symlink();raw=p.read_bytes();assert len(raw)<=2*1024**2
 out[n]={'text':raw.decode(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
print(json.dumps(out))
"""
r=subprocess.run(ssh+['sudo -n python3 -'],input=code,text=True,capture_output=True,timeout=30);assert r.returncode==0,r.stderr
rows=json.loads(r.stdout)
for name,row in rows.items():
 p=BASE/'apollo'/name;p.parent.mkdir(parents=True,exist_ok=True);raw=row.pop('text').encode();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'];p.write_bytes(raw)
(BASE/'apollo-text-capture-pins-01.json').write_text(json.dumps(rows,indent=2)+'\n')
unit=json.loads((ROOT/'owner-binding-01.json').read_text())['laptop']['unit']
for label,unit_name in [('native-unit-journal-01',unit),('guard-journal-01','thermal-guard.service')]:
 cmd=['journalctl','--user','-u',unit_name,'--since','2026-10-29 20:15:00 UTC','--until','2026-10-29 20:20:30 UTC','-o','json','--no-pager','-n','2000'];r=subprocess.run(cmd,capture_output=True,text=True,timeout=15);assert r.returncode==0,r.stderr;assert len(r.stdout.encode())<=4*1024**2
 (BASE/(label+'.jsonl')).write_text(r.stdout);(BASE/(label+'.stderr.log')).write_text(r.stderr)
print(json.dumps({'bounded_original_remote_files':len(rows),'journal_sets':2,'workload_started':False}))
