"""Associate completed hops with preceding same-host samples; no causal claim."""
from pathlib import Path
from collections import Counter
import bisect,json,math
BASE=Path(__file__).resolve().parent;P=BASE.parent/'laptop-results-01/candidate/output-01'
rows=[json.loads(s)for s in(P/'observations.jsonl').read_text().splitlines()]
hops=[r for r in rows if r['type']=='record'and r['kind']==5]
samples=[json.loads(s)for s in(P/'host-observations.jsonl').read_text().splitlines()]
clocks=[r['monotonic_ns']for r in samples];cap='/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_power_limit_uw'
joined=[]
for h in hops:
 i=bisect.bisect_right(clocks,h['observed_ns'])-1;assert i>=0;s=samples[i]
 joined.append(dict(ordinal=h['ordinal'],request_id=h['request_id'],generation=h['generation'],observed_ns=h['observed_ns'],hop_service_ms=h['hop_service_ms'],native_graph_compute_ms=h['native_graph_compute_ms'],
  preceding_host_sample_age_seconds=(h['observed_ns']-s['monotonic_ns'])/1e9,profile=s['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'],MMIO_long_term_limit_uw=s['configured_power_caps'][cap],maximum_sampled_C=max(s['temperatures_millidegrees_C'].values())/1000))
fields=('hop_service_ms','source_read_ms','request_ms','overlap_ms','native_inference_wall_ms','native_inference_cpu_ms','native_frontend_ms','native_graph_ms','native_graph_upload_ms','native_graph_compute_ms','native_graph_readback_ms','native_postprocess_ms')
p99={}
for field in fields:
 values=sorted(h[field]for h in hops);p99[field]=values[math.ceil(.99*len(values))-1]
worst=max(hops,key=lambda h:h['hop_service_ms']);w=json.loads((P/'result.json').read_text())
descriptors=[p for p in w['cleanup']['known_processes']if '--describe'in p.get('command',[])]
r=dict(schema=1,scope='Descriptive association with preceding two-second samples. Nested wall durations are not additive and do not identify a shader, clock, driver or policy as the cause.',
 complete_hops=len(hops),sampled_profile_counts=dict(Counter(r['profile']for r in samples for r in [dict(profile=r['profile_epp_read_only']['/sys/firmware/acpi/platform_profile'])])),
 cap_samples=dict(Counter(s['configured_power_caps'][cap]for s in samples)),phase_p99_ms=p99,
 completed_hops_by_preceding_sample={profile:dict(count=len(group:=[r for r in joined if r['profile']==profile]),misses=sum(r['hop_service_ms']>=4095 for r in group),minimum_ms=min(r['hop_service_ms']for r in group),maximum_ms=max(r['hop_service_ms']for r in group))for profile in sorted(set(r['profile']for r in joined))},
 maximum_host_sample_gap_seconds=max((b-a)/1e9 for a,b in zip(clocks,clocks[1:])),joined_hops=joined,worst_hop=worst,
 observed_descriptor_processes=descriptors,known_process_count=len(w['cleanup']['known_processes']),ownership_failures=w['cleanup']['ownership_failures'],
 prepared_continuation_miss_check='Only the expected initial exporter --describe process was observed; repeated continuation-miss descriptors did not recur in retained command history.',
 no_counterbalanced_causal_AB_claim=True)
with (BASE/'phase-profile-01.json').open('x')as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k]for k in ('phase_p99_ms','completed_hops_by_preceding_sample','cap_samples','maximum_host_sample_gap_seconds','prepared_continuation_miss_check')},indent=2))
