#!/usr/bin/env python3
"""Named text evidence for Best-quality stem conversion; dry plan by default."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
DEST = ROOT / 'docs/benchmarks/data/m2-best-quality-converter-2026-10-19'
MANIFEST = BASE / 'archive-best-quality-converter-inputs.json'
MANIFEST_SHA = '379f38215f33afdc8356e3fba9d5df7daca5eb723fe6daf577b1bc62c17013bc'
FREEZE = BASE / 'archive-best-quality-converter-freeze.json'
RECIPE = BASE / 'archive-best-quality-converter-recipe.json'
ORIGINAL = 'a3efd2c65dc845805ed2bc94ce280082b4c7fe1e'
CPP, HPP = 'src/audio/StemRateConverter.cpp', 'src/audio/StemRateConverter.hpp'
SOURCE = {CPP: '10cb293092678e6693c04e8e39059d751b487e95dc948087bb7c02f657c27960',
          HPP: 'c2e5b0749b2db3f60ef3c4e361a07e744be90bd77eabcb9d5e40069526e7c094'}
OLD = {CPP: '482c55e043847adb75b42bdd25fd8859cd97e106208d46170ba1f84c897f9294',
       HPP: 'fcb4d4282c17a286a20d09e496927593df42cc26f3a6c518931084d55075c988'}


def require(value, message):
    if not value:
        raise RuntimeError(message)


def meta(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read(path):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= 64 * 1024 * 1024,
            'Named input is not bounded regular text: ' + str(path))
    data = path.read_bytes()
    after = path.lstat()
    identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns)
    require(identity(before) == identity(after) and len(data) == before.st_size, 'Named input changed')
    require(b'\0' not in data, 'Binary payload prohibited')
    data.decode('utf-8')
    return data


def load(path):
    return json.loads(read(path))


def command(argv):
    result = subprocess.run(argv, cwd=ROOT, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    require(result.returncode == 0, 'Read-only metadata command failed: ' + repr(argv))
    return result.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--head', help='exact final valid signed source commit, supplied after it exists')
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({'status': 'draft_plan_only', 'destination': str(DEST),
            'pending': ['closed coverage02 and copied named reports', 'root report', 'exact signed source --head'],
            'scope': 'No evidence, Git, workload or host reads in dry mode'}))
        return 0
    require(bool(re.fullmatch('[0-9a-f]{40}', args.head or '')), 'Exact signed --head is required')
    manifest_data = read(MANIFEST)
    require(meta(manifest_data)['sha256'] == MANIFEST_SHA, 'Reviewed named manifest changed')
    manifest = json.loads(manifest_data)
    inputs = dict(manifest['closed_inputs'])
    for name in manifest['pending_inputs']:
        require(name not in inputs, 'Pending/closed input duplicated')
        inputs[name] = meta(read(ROOT / name))
    for name, pin in inputs.items():
        relative = Path(name)
        require(not relative.is_absolute() and '..' not in relative.parts and name not in ('', '.'), 'Unsafe named origin')
        require(meta(read(ROOT / name)) == pin, 'Named frozen/closed input changed: ' + name)
    freeze = load(FREEZE)
    for key, path in [('script', Path(__file__).resolve()), ('recipe', RECIPE), ('manifest', MANIFEST)]:
        require(meta(read(path)) == {field: freeze[key][field] for field in ('bytes', 'sha256')}, 'Archiver freeze differs')

    require(command(['git', 'rev-parse', 'HEAD']).decode().strip() == args.head, 'Current HEAD differs from requested signed source')
    signature = command(['git', 'show', '-s', '--format=%H %G? %GF %ae', args.head]).decode().strip()
    require(signature.split() == [args.head, 'G', 'F621F658D66098CBE9E5C55D66788CCBB5E215AC', 'kyau@kyau.net'],
            'Final source signature must be valid and by kyau')
    command(['git', 'merge-base', '--is-ancestor', ORIGINAL, args.head])
    require(command(['git', 'diff', args.head, '--', CPP, HPP]) == b'', 'Selected product differs from signed source')
    snapshots = {}
    for revision, expected, prefix in [(ORIGINAL, OLD, 'original'), (args.head, SOURCE, 'signed-product')]:
        for name, digest in expected.items():
            data = command(['git', 'show', revision + ':' + name])
            require(meta(data)['sha256'] == digest, 'Exact original/final source binding differs')
            snapshots[prefix + '-' + Path(name).name] = (data, {'git_commit': revision, 'git_path': name, **meta(data)})
    for name, digest in SOURCE.items():
        require(meta(read(ROOT / name))['sha256'] == digest, 'Current product changed')

    def evidence(name):
        return load(BASE / name)
    preference = evidence('stem-converter-listening-01-user-verdict.json')
    require(preference['verbatim_answer'] and 'SRC_SINC_BEST_QUALITY' in preference['production_decision'],
            'Actual user Best preference receipt differs')
    setup = evidence('best-packed-product-coverage-01/setup-failure.json')
    require(setup['shell_exit'] == 127 and setup['scope'] == 'Setup failure before coverage process/counter reset',
            'Coverage01 must remain a setup-only missing-interpreter failure')
    require(meta(read(BASE / 'best-packed-product-coverage-01/runner.log'))['sha256'] == setup['log_sha256'],
            'Coverage01 setup log differs')
    populations = {}
    for name, count in [('stem-converter-best-packed-series-01.json', 4),
                        ('stem-converter-best-packed-affinity-series-01.json', 6)]:
        value = evidence(name)
        require(value['completed'] is True and value['qualified'] is False and value['pins_unchanged'] is True and
                len(value['rows']) == count, 'CPU diagnostic population incomplete')
        for row in value['rows']:
            for path_key, hash_key in [('output', 'output_sha256'), ('log', 'log_sha256')]:
                require(row[path_key] in inputs and meta(read(ROOT / row[path_key]))['sha256'] == row[hash_key],
                        'CPU diagnostic result/log population differs')
        populations[name] = value['rows']
    regressions = evidence('stem-converter-best-packed-regressions-01.json')
    require(regressions['passed'] is True and regressions['pins_unchanged'] is True and
            [row['mode'] for row in regressions['rows']] == ['quad', 'octal'], 'Prototype regressions differ')
    for row in regressions['rows']:
        require(row['exit_code'] == 0 and meta(read(ROOT / row['log']))['sha256'] == row['log_sha256'], 'Regression log differs')

    normal = evidence('best-packed-product-normal-01/execution.json')
    parity = evidence('best-packed-product-parity-01/execution.json')
    strict = evidence('best-packed-product-strict-preparation-execution-01.json')
    for value in (normal, parity, strict):
        require(value['passed'] is True and value['qualified'] is False and value['pins_unchanged'] is True,
                'Actual product functional/parity execution is incomplete')
    require([row['name'] for row in normal['rows']] == ['build', 'ctest', 'smoke', 'routing', 'preparation'] and
        all(row['exit_code'] == 0 and row['timed_out'] is False for row in normal['rows']), 'Normal product stages failed')
    for name, digest in SOURCE.items():
        require(normal['pins_before'][name]['sha256'] == digest and parity['pins_before'][str(ROOT / name)]['sha256'] == digest,
                'Actual product checks were built from different selected source')
    for directory in ['best-packed-product-normal-01/routing', 'best-packed-product-normal-01/preparation',
                      'best-packed-product-strict-preparation-01']:
        result = evidence(directory + '/result.json')
        require(result['passed'] is True and result['check_exit'] == 0 and result['daemon_reaped'] is True and
            not result['cleanup']['remaining_nodes_or_links'], 'Private check/owned graph cleanup failed')
    product_parity = evidence('best-packed-product-parity-01/exact-best-parity.json')
    require(product_parity['passed'] is True and product_parity['qualified'] is False and
            product_parity['generated_full_seek_hashes_match_original'] is True and product_parity['files'],
            'Actual production exact Best parity differs')

    coverage = evidence('best-packed-product-coverage-02/reports/summary.json')
    coverage_execution = evidence('best-packed-product-coverage-02/execution.json')
    require(coverage_execution['closed_utc'] and coverage_execution['runner_exit'] == 0 and
        coverage_execution['passed'] is True and coverage_execution['pins_unchanged'] is True and
        coverage['execution_passed'] is True and not coverage['errors'] and coverage['private_routing_requested'] is True and
        all(row['exit'] == 0 for row in coverage['stages'].values()), 'Coverage02 has not closed successfully')
    coverage_prefix = str((BASE / 'best-packed-product-coverage-02').relative_to(ROOT)) + '/'
    for name, pin in inputs.items():
        if name.startswith(coverage_prefix + 'reports/'):
            require(coverage_execution['report_pins'][name.removeprefix(coverage_prefix)] == pin,
                    'Copied coverage report differs from closed execution pin')
    cpp_counts = evidence('best-packed-product-coverage-02/reports/cpp-summary.json')
    python_counts = evidence('best-packed-product-coverage-02/reports/python.json')['totals']
    require(coverage['cpp']['line']['covered'] == cpp_counts['line_covered'] and
        coverage['cpp']['line']['total'] == cpp_counts['line_total'] and
        coverage['python']['line']['covered'] == python_counts['covered_lines'] and
        coverage['python']['line']['total'] == python_counts['num_statements'], 'Raw coverage totals differ')
    coverage_plan = evidence('best-packed-product-coverage-02/plan.json')
    for name, digest in SOURCE.items():
        require(coverage_plan['pins'][name]['sha256'] == digest, 'Coverage source binding differs')
    for mode in ('private-routing', 'private-preparation'):
        result = evidence('best-packed-product-coverage-02/reports/' + mode + '/result.json')
        require(result['passed'] is True and result['check_exit'] == 0 and result['daemon_reaped'] is True and
            not result['cleanup']['remaining_nodes_or_links'] and result['execution_deadline_gate'] is False,
            'Instrumented private functionality/cleanup/mode differs')
    root_report = evidence('best-packed-product-report-01.json')
    require(root_report['source_head'] == args.head and root_report['m2_open'] is True and
            root_report['integrated_live_playback_qualified'] is False, 'Root report must preserve M2-open scope')

    stage, raw = BASE / 'best-quality-converter-archive-stage', BASE / 'best-quality-converter-archive-raw'
    require(not any(os.path.lexists(path) for path in (DEST, stage, raw)), 'Fresh canonical/staging/raw paths required')
    stage.mkdir(mode=0o700); raw.mkdir(mode=0o700)
    files, origins, uncompressed = {}, {}, {}
    total = 0
    def add(data, name, origin):
        nonlocal total
        require('/' not in name and name + '.gz' not in files and b'\0' not in data, 'Unsafe/duplicate/binary payload')
        data.decode('utf-8'); total += len(data)
        require(total <= 128 * 1024 * 1024, 'Named raw text exceeds128MiB')
        (raw / name).write_bytes(data)
        filename = name + '.gz'; packed = gzip.compress(data, mtime=0)
        (stage / filename).write_bytes(packed)
        files[filename], uncompressed[filename], origins[filename] = meta(packed), meta(data), origin
    for name, pin in inputs.items():
        add(read(ROOT / name), name.replace('/', '--'), {'path': name, **pin})
    for path in (Path(__file__).resolve(), MANIFEST, FREEZE, RECIPE):
        data = read(path); add(data, path.name, {'path': str(path.relative_to(ROOT)), **meta(data)})
    for name, (data, origin) in snapshots.items():
        add(data, name, origin)
    scan_log, scan_report = BASE / 'best-quality-converter-archive-gitleaks.log', BASE / 'best-quality-converter-archive-gitleaks-findings.json'
    require(not os.path.lexists(scan_log) and not os.path.lexists(scan_report), 'Fresh scan outputs required')
    scanned_bytes = total
    with scan_log.open('xb') as stream:
        scan = subprocess.run(['gitleaks', 'dir', str(raw), '--redact', '--no-color', '--report-format', 'json',
            '--report-path', str(scan_report)], cwd=ROOT, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, timeout=90)
    require(scan.returncode == 0 and load(scan_report) == [], 'Raw scan failed; no canonical publication')
    for path in (scan_log, scan_report):
        data = read(path); add(data, path.name, {'path': str(path.relative_to(ROOT)), **meta(data)})
    for name, pin in files.items():
        packed = (stage / name).read_bytes()
        require(meta(packed) == pin and meta(gzip.decompress(packed)) == uncompressed[name], 'Archive hash/roundtrip failed')
    for origin in origins.values():
        data = command(['git', 'show', origin['git_commit'] + ':' + origin['git_path']]) if 'git_commit' in origin else read(ROOT / origin['path'])
        require(meta(data) == {key: origin[key] for key in ('bytes', 'sha256')}, 'Origin changed during archive')
    require(command(['git', 'rev-parse', 'HEAD']).decode().strip() == args.head and
            command(['git', 'diff', args.head, '--', CPP, HPP]) == b'', 'Selected signed source changed during archive')
    verification = {'schema': 'conflux.m2-best-quality-converter.v1', 'source_head': args.head, 'source_signature': signature,
        'original_source_head': ORIGINAL, 'status': 'best_quality_conversion_functionality_and_parity_preserved',
        'm2_open': True, 'integrated_live_playback_qualified': False,
        'cpu_diagnostic_populations': populations, 'coverage02': coverage,
        'coverage01_scope': setup['scope'], 'raw_secret_scan_exit': 0, 'raw_scanned_input_bytes': scanned_bytes,
        'files': files, 'origins': origins, 'uncompressed': uncompressed,
        'limits': ['Best quality is retained; descriptive CPU series include their original power/thermal/affinity context.',
            'Finite exact parity fixtures support unchanged samples and frame/seek geometry; no universal equivalence claim.',
            'Private checks and instrumented coverage preserve their actual deadline gates and do not qualify physical or live service latency.',
            'Coverage01 stopped before the interpreter started; it is a setup failure, not a failed measurement.',
            'Numeric coverage is limited to measured C++/Python scopes; QML/native adapter exclusions remain in the retained summary.',
            'No binary, WAV/PCM, model, cache or HTML payloads; original local audio archive remains local.',
            'Raw scan covers named inputs before scanner outputs and generated verification packaging; no suppressions.',
            'No new actual-player or sustained4095ms qualification or CI result is inferred.']}
    (stage / 'verification.json').write_text(json.dumps(verification, indent=2, allow_nan=False) + '\n')
    require(not os.path.lexists(DEST), 'Canonical destination appeared')
    stage.rename(DEST)
    print(json.dumps({'status': verification['status'], 'destination': str(DEST), 'files': len(files) + 1, 'source_head': args.head}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
