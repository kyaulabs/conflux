from pathlib import Path
import gzip,hashlib,json,os,stat,subprocess,datetime
root=Path.cwd();base=root/'benchmarks-local/m2-live-delivery-2026-10-19';run='short-live-actual-model-03'
dest=root/'docs/benchmarks/data/m2-best-quality-converter-2026-10-19/native-retest';stage=base/'native-retest-archive-stage';rawdir=base/'native-retest-archive-raw'
assert not any(os.path.lexists(p) for p in (dest,stage,rawdir))
names=[run+'/'+n for n in ('result.json','native-result.json','observations.jsonl','host-observations.jsonl','progress.json','native.stdout.log','native.stderr.log','owned-pipewire-cleanup.json')]
names += [run+n for n in ('-readiness.json','-launch.json','-cool-start.json','-source-freeze.json','-thermal-guard.log','-thermal-guard.json','-report.json','-independent-crosscheck.json','-wait-launch.py','.stdout.json')]
names += ['archive_best_native_retest.py']
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):
 s=p.lstat(); assert stat.S_ISREG(s.st_mode) and s.st_size<=32*1024*1024
 b=p.read_bytes(); a=p.lstat(); assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)
 assert len(b)==s.st_size and b'\0' not in b;b.decode('utf-8');return b
report=json.loads(read(base/(run+'-report.json')));source=json.loads(read(base/(run+'-source-freeze.json')));independent=json.loads(read(base/(run+'-independent-crosscheck.json')))
assert report['source_head']=='408c2f39c93cec28ee62498f40a6d4014b05b4ff' and report['passed'] is False and report['qualified'] is False and source['pins_unchanged'] is True
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==report['source_head']
for n,expected in source['source_pins_after'].items():assert pin((root/n).read_bytes())==expected
stage.mkdir(mode=0o700);rawdir.mkdir(mode=0o700);files={};origins={};uncompressed={};total=0
for n in names:
 p=base/n;b=read(p);leaf=n.replace('/','--');assert leaf+'.gz' not in files;total+=len(b);assert total<=64*1024*1024
 (rawdir/leaf).write_bytes(b);packed=gzip.compress(b,mtime=0);name=leaf+'.gz';(stage/name).write_bytes(packed);files[name]=pin(packed);uncompressed[name]=pin(b);origins[name]={'path':str(p.relative_to(root)),**pin(b)}
scanlog=base/'native-retest-archive-gitleaks.log';scanreport=base/'native-retest-archive-gitleaks-findings.json';assert not scanlog.exists() and not scanreport.exists()
with scanlog.open('xb') as stream:
 scan=subprocess.run(['gitleaks','dir',str(rawdir),'--redact','--no-color','--report-format','json','--report-path',str(scanreport)],stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
assert scan.returncode==0 and json.loads(read(scanreport))==[]
for p in (scanlog,scanreport):
 b=read(p);name=p.name+'.gz';packed=gzip.compress(b,mtime=0);(stage/name).write_bytes(packed);files[name]=pin(packed);uncompressed[name]=pin(b);origins[name]={'path':str(p.relative_to(root)),**pin(b)}
for name,expected in files.items():
 packed=(stage/name).read_bytes();b=gzip.decompress(packed);o=origins[name];assert pin(packed)==expected and pin(b)==uncompressed[name]=={k:o[k] for k in ('bytes','sha256')};assert b==read(root/o['path'])
v={'schema':'conflux.m2-best-quality-native-retest.v1','source_head':report['source_head'],'parent_verification_sha256':pin(read(dest.parent/'verification.json'))['sha256'],'status':'completed_failed_service_and_steady_playback','qualified':False,'m2_open':True,'report':report,'files':files,'uncompressed':uncompressed,'origins':origins,'raw_secret_scan_exit':0,'raw_scanned_input_bytes':total,'limits':['Single120-second repeated excerpt diagnostic; no sustained percentile qualification.','Best quality/runtime/model/strict4095ms target unchanged; thermal guard active and unchanged.','Known descendant cleanup proof passed; no unknown escaped process guarantee.','No media/model/cache/binaries/HTML in canonical evidence.','All gzip payloads match source bytes and pins at publication.']}
(stage/'verification.json').write_text(json.dumps(v,indent=2,allow_nan=False)+'\n');assert not dest.exists();stage.rename(dest);print(json.dumps({'destination':str(dest),'files':len(files)+1,'status':v['status']}))
