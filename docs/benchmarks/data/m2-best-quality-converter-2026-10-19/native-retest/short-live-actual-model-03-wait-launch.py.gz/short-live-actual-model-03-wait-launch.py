from pathlib import Path
import datetime,json,os,subprocess,time
base=Path(__file__).resolve().parent
recipe=json.loads((base/'short-live-best-packed-next-run-recipe.json').read_text())
rows=[]; deadline=time.monotonic()+120
while True:
    values=[]
    for zone in Path('/sys/class/thermal').glob('thermal_zone*'):
        try:
            if (zone/'type').read_text().strip() in ('acpitz','TCPU','x86_pkg_temp'): values.append(int((zone/'temp').read_text()))
        except (OSError,ValueError): pass
    for hw in Path('/sys/class/hwmon').glob('hwmon*'):
        try:
            if (hw/'name').read_text().strip()=='coretemp': values.extend(int(p.read_text()) for p in hw.glob('temp*_input'))
        except (OSError,ValueError): pass
    profile=subprocess.check_output(['powerprofilesctl','get'],text=True,timeout=3).strip()
    row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'profile':profile,'maximum_millidegrees_C':max(values) if values else None};rows.append(row)
    ready=profile=='balanced' and values and 0<max(values)<=70000
    if ready or time.monotonic()>=deadline:
        (base/'short-live-actual-model-03-cool-start.json').write_text(json.dumps({'ready':bool(ready),'observations':rows,'scope':'Read-only bounded wait for natural balanced/cool recovery; guard and profile unchanged.'},indent=2)+'\n')
        if not ready: raise SystemExit('Natural cool/balanced start not reached within120s; no player launched')
        argv=recipe['root_only_argv_after_all_pending_items_are_satisfied']
        print('Natural cool/balanced start reached; launching confirmed120s diagnostic',flush=True)
        os.execv(argv[0],argv)
    time.sleep(2)
