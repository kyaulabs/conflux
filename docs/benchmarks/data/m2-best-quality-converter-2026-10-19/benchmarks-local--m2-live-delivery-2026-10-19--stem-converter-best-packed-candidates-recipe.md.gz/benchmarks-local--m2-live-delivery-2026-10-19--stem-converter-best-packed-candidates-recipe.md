# Packed-channel BEST converter diagnostics

Both ignored copies preserve production `SRC_SINC_BEST_QUALITY`, public API and the entire original source prefix through `countFrames` byte for byte. Quad uses two4-channel states for adjacent stereo roles (drums+bass, other+vocals); octal uses one8-channel state for all four stereo roles. The only difference between the two candidate files is `rolesPerState=2` versus4. Each uses fixed bounded packing buffers, the existing planar scratch and unchanged shape/alias/finite/coverage/preroll/terminal/EOF/discard checks. No thread, dependency, configuration or product source change.

The shared kernel is an exploratory inference from matching upstream libsamplerate0.2.2 source, not an equivalence or performance result. Existing installed package version reports0.2.2. The upstream source is https://raw.githubusercontent.com/libsndfile/libsamplerate/0.2.2/src/src_sinc.c . Compile and test the actual installed library; retain any failure without loosening geometry or float-bit gates.

```sh
conflux_task_root="$PWD"
conflux_task_base="$conflux_task_root/benchmarks-local/m2-live-delivery-2026-10-19"
for conflux_pack_mode in quad octal; do
  /bin/c++ -O2 -g -DNDEBUG -std=c++20 -Wall -Wextra -Wpedantic \
    -I"$conflux_task_root/src" $(pkg-config --cflags samplerate) \
    -c "$conflux_task_base/StemRateConverter-best-$conflux_pack_mode-candidate.cpp" \
    -o "$conflux_task_base/StemRateConverter-best-$conflux_pack_mode-candidate.o" || break
  # The candidate object precedes the archive, satisfying converter symbols;
  # the archive supplies AudioFile's unchanged independent BEST reference.
  /bin/c++ -O2 -g -DNDEBUG -std=c++20 -Wall -Wextra -Wpedantic \
    -I"$conflux_task_root/src" $(pkg-config --cflags sndfile samplerate) \
    "$conflux_task_root/tests/audio_stem_rate_converter_test.cpp" \
    "$conflux_task_base/StemRateConverter-best-$conflux_pack_mode-candidate.o" \
    "$conflux_task_root/build/dev/libconflux-audio.a" \
    $(pkg-config --libs sndfile samplerate) -pthread \
    -o "$conflux_task_base/audio-stem-rate-converter-best-$conflux_pack_mode-test" || break
  /bin/c++ -O2 -g -DNDEBUG -std=c++20 -Wall -Wextra -Wpedantic \
    -mno-direct-extern-access -D_REENTRANT -fno-strict-aliasing -fno-strict-overflow \
    -DQT_CORE_LIB -DQT_NO_DEBUG -I"$conflux_task_root/src" \
    $(pkg-config --cflags Qt6Core samplerate) \
    "$conflux_task_base/stem_converter_microprofile_v2.cpp" \
    "$conflux_task_base/StemRateConverter-best-$conflux_pack_mode-candidate.o" \
    $(pkg-config --libs Qt6Core samplerate) -pthread \
    -o "$conflux_task_base/stem-converter-microprofile-v2-best-$conflux_pack_mode" || break
  # Functional evidence first; source/binary/library pins and fresh log per mode.
  timeout --signal=TERM --kill-after=5s 180s \
    "$conflux_task_base/audio-stem-rate-converter-best-$conflux_pack_mode-test" \
    > "$conflux_task_base/audio-stem-rate-converter-best-$conflux_pack_mode-01.log" 2>&1 || break
done
```

Root should execute compile commands with explicit exit checking and avoid interpreting a partial loop as success. Preserve every compile/test log, failure and exact object/binary/library/source pin. The existing regression test compares every float bit against complete-file BEST preparation across full and mixed input/output partitions, temporary gaps, interior/EOF seeks, aliased input roles, headroom, finite/overlap/geometry rejection and terminal failures; count cancellation also remains exercised. Passing just the two fixed profiler scenarios is insufficient to replace this test.

After both unchanged regression executables pass, root may run the existing baseline v2 binary, quad, octal, then baseline again. Use the same timeout60s/kill-after5s guard and distinct fresh result paths, e.g. `stem-converter-best-packed-{baseline-before,quad,octal,baseline-after}-01.json`. Same immutable profiler source, generated input, N1031940, M1123201 and target0/280800 gates apply. Read power/profile and pin all artifacts before/after as in prior root diagnostics. No audio, service, model or UI workload is selected.

Before any timing claim, independently require all four profile results passed, input SHA256 identical and each candidate's `output_packet_role_order_sha256` exactly matches the corresponding baseline full and seek scenario. The already closed baseline hashes are full `f3eaa8218f08e3949a0981d8f26a18a9378831f1b2278f57eae4883ce59fdd9f` and seek `1a59e5873cf2c88a41fd693ea1554844a5971e3987950ff8d27d65d8231c21c4`; generated input is `4df0b5213f08c1722ddbf9f89563f90ae30d7c2e35e4bb3f754f6cd260806cbd`. Any count, progress, EOF, finite, mapping or bit mismatch is a blocker, not permission to update an oracle. Retain differing output evidence for analysis.

Compare process wall/thread CPU, envelope wall, first packet and reserve preparation separately. Packing adds copies and compiler/kernel paths differ, so no speedup or bit identity is guaranteed by source inspection. The scenario uses stereo dry-run counting, so count cost is intentionally unchanged. Profile-only improvements do not qualify the4095ms live service target or actual playback. Product adoption would still require meaningful regression, real-track exact parity and fresh integrated load tests. The author has not compiled, tested or executed any candidate.
