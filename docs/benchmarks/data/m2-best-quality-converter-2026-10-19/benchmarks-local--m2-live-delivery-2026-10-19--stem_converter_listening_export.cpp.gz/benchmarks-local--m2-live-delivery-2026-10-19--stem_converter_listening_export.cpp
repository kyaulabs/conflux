// SPDX-License-Identifier: AGPL-3.0-or-later
// Ignored offline export: four existing stem WAVs, no service/model or playback.
#include "audio/StemRateConverter.hpp"
#include <QCryptographicHash>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <sndfile.h>
#include <algorithm>
#include <array>
#include <bit>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <functional>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <sys/resource.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <vector>

namespace {
using Converter = conflux::audio::StemRateConverter;
using Bank = std::array<std::vector<float>, 4>;
using Clock = std::chrono::steady_clock;
constexpr std::uint64_t n = 1031940, m = 1123201, target = 280800;
constexpr std::uint64_t fileBound = 16ULL * 1024 * 1024;
constexpr std::uint64_t pcmBytes = (n + m + (m - target)) * 2 * 4 * sizeof(float);
static_assert(pcmBytes < 128ULL * 1024 * 1024);
constexpr std::array<const char*, 5> roles{"drums", "bass", "other", "vocals", "recombined"};
void require(bool value, const char* text) { if (!value) throw std::runtime_error(text); }
struct Fd {
    int value = -1; explicit Fd(int fd) : value(fd) {}
    ~Fd() { if (value >= 0) ::close(value); }
    Fd(const Fd&) = delete; Fd& operator=(const Fd&) = delete;
};
struct Audio {
    SNDFILE* value = nullptr; explicit Audio(SNDFILE* file) : value(file) {}
    ~Audio() { if (value) sf_close(value); }
    Audio(const Audio&) = delete; Audio& operator=(const Audio&) = delete;
    void close() { auto* file = value; value = nullptr; require(file && sf_close(file) == 0, "Audio close failed"); }
};
struct stat status(int fd)
{
    struct stat s{}; require(::fstat(fd, &s) == 0 && S_ISREG(s.st_mode) && s.st_size > 0 &&
        std::uint64_t(s.st_size) <= fileBound, "Audio file must be bounded, nonempty and regular"); return s;
}
bool same(const struct stat& a, const struct stat& b)
{
    return a.st_dev == b.st_dev && a.st_ino == b.st_ino && a.st_mode == b.st_mode && a.st_size == b.st_size &&
        a.st_mtim.tv_sec == b.st_mtim.tv_sec && a.st_mtim.tv_nsec == b.st_mtim.tv_nsec &&
        a.st_ctim.tv_sec == b.st_ctim.tv_sec && a.st_ctim.tv_nsec == b.st_ctim.tv_nsec;
}
QString hash(int fd, const struct stat& before)
{
    QCryptographicHash digest(QCryptographicHash::Sha256); std::array<char, 32768> bytes{};
    off_t offset = 0;
    while (offset < before.st_size) {
        const auto offered = std::size_t(std::min<off_t>(bytes.size(), before.st_size - offset));
        const auto count = ::pread(fd, bytes.data(), offered, offset);
        if (count < 0 && errno == EINTR) continue;
        require(count > 0 && std::size_t(count) <= offered, "Cannot hash complete retained audio descriptor");
        digest.addData(QByteArrayView(bytes.data(), qsizetype(count))); offset += count;
    }
    require(same(before, status(fd)), "Audio descriptor changed during hash"); return QString::fromLatin1(digest.result().toHex());
}
void budget(Clock::time_point start)
{ require(Clock::now() - start < std::chrono::seconds(115), "Offline export exceeded115s soft total budget"); }
QJsonObject geometry(const SF_INFO& info)
{ return {{"frames", qint64(info.frames)}, {"sample_rate", info.samplerate}, {"channels", info.channels}, {"format", info.format}}; }
QJsonObject readInput(const QString& path, std::vector<float>& pcm, Clock::time_point start)
{
    require(QFileInfo(path).isAbsolute(), "Input paths must be absolute");
    Fd fd(::open(QFile::encodeName(path).constData(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW));
    require(fd.value >= 0, "Cannot open regular input without following symlinks"); const auto before = status(fd.value);
    const auto beforeHash = hash(fd.value, before); SF_INFO info{}; Audio audio(sf_open_fd(fd.value, SFM_READ, &info, SF_FALSE));
    require(audio.value && info.frames == sf_count_t(n) && info.channels == 2 && info.samplerate == 44100 &&
        (info.format & SF_FORMAT_TYPEMASK) == SF_FORMAT_WAV && (info.format & SF_FORMAT_SUBMASK) == SF_FORMAT_FLOAT,
        "Input must be exactN stereo44100 float-WAV");
    pcm.resize(n * 2); std::uint64_t read = 0, nonzero = 0; std::array<double, 2> peak{};
    while (read < n) {
        budget(start); const auto offered = sf_count_t(std::min<std::uint64_t>(4096, n - read));
        const auto got = sf_readf_float(audio.value, pcm.data() + read * 2, offered);
        require(got > 0 && got <= offered, "Input WAV ended before its exact frame count");
        for (sf_count_t i = 0; i < got * 2; ++i) {
            const auto v = pcm[read * 2 + std::size_t(i)]; require(std::isfinite(v), "Input contains nonfinite PCM");
            peak[std::size_t(i) % 2] = std::max(peak[std::size_t(i) % 2], std::abs(double(v))); nonzero += v != 0.F;
        }
        read += std::uint64_t(got);
    }
    std::array<float, 2> extra{};
    require(sf_readf_float(audio.value, extra.data(), 1) == 0 && sf_error(audio.value) == SF_ERR_NO_ERROR, "Input WAV has unexpected trailing frames or read error");
    audio.close(); const auto afterHash = hash(fd.value, before); struct stat named{};
    require(::lstat(QFile::encodeName(path).constData(), &named) == 0 && same(before, named) && beforeHash == afterHash,
        "Input path/descriptor/content changed during read");
    auto result = geometry(info); result["path"] = path; result["sha256_before"] = beforeHash; result["sha256_after"] = afterHash;
    result["bytes"] = qint64(before.st_size); result["peak_left"] = peak[0]; result["peak_right"] = peak[1]; result["nonzero_samples"] = qint64(nonzero);
    return result;
}
struct Conversion { Bank pcm; QJsonObject report; };
Conversion convert(const Bank& input, Converter::FramePlan plan, std::uint64_t at, Clock::time_point start)
{
    const auto begin = Clock::now(); Converter converter(plan, at); Conversion result;
    const auto anchor = converter.inputStartFrame();
    require(anchor == (at ? 253281 : 0), "Converter anchor differs from fixed full/seek geometry");
    for (auto& role : result.pcm) role.reserve((m - at) * 2);
    std::array<std::array<float, 8192>, 4> scratch{};
    std::uint64_t cursor = anchor, visible = 0, calls = 0, eofCalls = 0, zeros = 0;
    bool finished = false;
    while (!finished) {
        budget(start); require(++calls <= 16384, "Converter exceeded fixed step count");
        const auto offered = std::size_t(std::min<std::uint64_t>(4096, n - cursor)); const bool eof = !offered;
        std::array<std::span<const float>, 4> in; std::array<std::span<float>, 4> out;
        for (std::size_t role = 0; role < 4; ++role) {
            in[role] = std::span<const float>(input[role]).subspan(cursor * 2, offered * 2); out[role] = scratch[role];
        }
        const auto step = converter.process(in, out, eof);
        require(step.inputFramesUsed <= offered && step.outputFrames <= 4096 && step.firstOutputFrame == at + visible &&
            step.outputFrames <= m - at - visible, "Converted prefix violates counted bounded geometry");
        for (std::size_t role = 0; role < 4; ++role) {
            const auto prefix = std::span<const float>(scratch[role]).first(step.outputFrames * 2);
            require(std::ranges::all_of(prefix, [](float v) { return std::isfinite(v); }), "Converter produced nonfinite PCM");
            result.pcm[role].insert(result.pcm[role].end(), prefix.begin(), prefix.end());
        }
        cursor += step.inputFramesUsed; visible += step.outputFrames; eofCalls += eof; finished = step.finished;
        zeros += !step.inputFramesUsed && !step.outputFrames && !finished;
        if (finished) require(eof && !step.outputFrames && cursor == n, "Conversion finished without actual zero-output EOF proof");
    }
    require(cursor == n && visible == m - at && std::ranges::all_of(result.pcm, [&](const auto& v) { return v.size() == visible * 2; }),
        "Final conversion input/visible counts differ from exact plan");
    result.report = {{"target_frame48000", qint64(at)}, {"input_anchor44100", qint64(anchor)}, {"input_consumed", qint64(cursor - anchor)},
        {"visible_frames", qint64(visible)}, {"expected_visible_frames", qint64(m - at)}, {"expected_hidden_preroll_frames", qint64(at ? 5120 : 0)},
        {"steps", qint64(calls)}, {"eof_calls", qint64(eofCalls)}, {"zero_progress_calls", qint64(zeros)}, {"finished", true},
        {"wall_ns", qint64(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - begin).count())}};
    return result;
}
float sample(const Bank& bank, std::size_t role, std::uint64_t index)
{
    if (role < 4) return bank[role][index];
    float value = bank[0][index]; value += bank[1][index]; value += bank[2][index]; value += bank[3][index]; return value;
}
QJsonObject writeSignal(int directory, const QString& name, const Bank& bank, std::size_t role, std::uint64_t frames, Clock::time_point start)
{
    Fd fd(::openat(directory, name.toUtf8().constData(), O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600));
    require(fd.value >= 0, "Output must be a fresh regular file; no overwrite or symlink following");
    SF_INFO info{}; info.channels = 2; info.samplerate = 48000; info.format = SF_FORMAT_WAV | SF_FORMAT_FLOAT;
    Audio writer(sf_open_fd(fd.value, SFM_WRITE, &info, SF_FALSE)); require(writer.value, "Cannot create float-WAV output");
    std::array<float, 8192> buffer{};
    for (std::uint64_t first = 0; first < frames;) {
        budget(start); const auto count = std::min<std::uint64_t>(4096, frames - first);
        for (std::uint64_t index = 0; index < count * 2; ++index) {
            buffer[index] = sample(bank, role, first * 2 + index); require(std::isfinite(buffer[index]), "Recombined output is nonfinite");
        }
        require(sf_writef_float(writer.value, buffer.data(), sf_count_t(count)) == sf_count_t(count) && sf_error(writer.value) == SF_ERR_NO_ERROR,
            "Cannot write exact float-WAV frame prefix"); first += count;
    }
    writer.close(); require(::fsync(fd.value) == 0 && ::lseek(fd.value, 0, SEEK_SET) == 0, "Cannot finalize/reopen retained output descriptor");
    const auto before = status(fd.value); SF_INFO readInfo{}; Audio reader(sf_open_fd(fd.value, SFM_READ, &readInfo, SF_FALSE));
    require(reader.value && readInfo.frames == sf_count_t(frames) && readInfo.channels == 2 && readInfo.samplerate == 48000 &&
        (readInfo.format & SF_FORMAT_TYPEMASK) == SF_FORMAT_WAV && (readInfo.format & SF_FORMAT_SUBMASK) == SF_FORMAT_FLOAT,
        "Reopened output has wrong frame/rate/format geometry");
    std::uint64_t checked = 0, nonzero = 0; std::array<double, 2> peak{};
    for (;;) {
        budget(start); const auto got = sf_readf_float(reader.value, buffer.data(), 4096); require(got >= 0 && got <= 4096, "Invalid output read count");
        if (!got) break;
        require(checked + std::uint64_t(got) <= frames, "Output read exceeds exact frame count");
        for (sf_count_t index = 0; index < got * 2; ++index) {
            const auto value = buffer[std::size_t(index)]; require(std::isfinite(value) &&
                std::bit_cast<std::uint32_t>(value) == std::bit_cast<std::uint32_t>(sample(bank, role, checked * 2 + std::uint64_t(index))),
                "Written WAV changed converted sample bits");
            peak[std::size_t(index) % 2] = std::max(peak[std::size_t(index) % 2], std::abs(double(value))); nonzero += value != 0.F;
        }
        checked += std::uint64_t(got);
    }
    require(checked == frames && sf_error(reader.value) == SF_ERR_NO_ERROR, "Output read did not cover finite exact frame count");
    reader.close(); const auto digest = hash(fd.value, before);
    return {{"file", name}, {"frames", qint64(frames)}, {"sample_rate", 48000}, {"channels", 2}, {"float32", true},
        {"finite", true}, {"readback_bits_match_memory", true}, {"sha256", digest}, {"bytes", qint64(before.st_size)},
        {"peak_left", peak[0]}, {"peak_right", peak[1]}, {"nonzero_samples", qint64(nonzero)}};
}
QJsonObject compareWritten(int directory, std::size_t role, Clock::time_point start)
{
    const auto fullName = QString("full-%1.wav").arg(roles[role]), seekName = QString("seek-%1.wav").arg(roles[role]);
    Fd fullFd(::openat(directory, fullName.toUtf8().constData(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW));
    Fd seekFd(::openat(directory, seekName.toUtf8().constData(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW));
    require(fullFd.value >= 0 && seekFd.value >= 0, "Cannot reopen own full/seek regular outputs");
    const auto fullBefore = status(fullFd.value), seekBefore = status(seekFd.value); SF_INFO fi{}, si{};
    Audio full(sf_open_fd(fullFd.value, SFM_READ, &fi, SF_FALSE)), selected(sf_open_fd(seekFd.value, SFM_READ, &si, SF_FALSE));
    require(full.value && selected.value && fi.frames == sf_count_t(m) && si.frames == sf_count_t(m - target) && fi.channels == 2 &&
        si.channels == 2 && fi.samplerate == 48000 && si.samplerate == 48000 && sf_seek(full.value, sf_count_t(target), SEEK_SET) == sf_count_t(target),
        "Cannot bind exact own full output tail to written seek file");
    std::array<float, 8192> a{}, b{}; std::uint64_t checked = 0, differences = 0; qint64 first = -1;
    double maximumDifference = 0;
    while (checked < m - target) {
        budget(start); const auto offered = sf_count_t(std::min<std::uint64_t>(4096, m - target - checked));
        const auto ac = sf_readf_float(full.value, a.data(), offered), bc = sf_readf_float(selected.value, b.data(), offered);
        require(ac == offered && bc == offered, "Own full/seek file comparison ended early");
        for (sf_count_t i = 0; i < offered * 2; ++i) {
            require(std::isfinite(a[std::size_t(i)]) && std::isfinite(b[std::size_t(i)]), "Written comparison contains nonfinite PCM");
            if (std::bit_cast<std::uint32_t>(a[std::size_t(i)]) != std::bit_cast<std::uint32_t>(b[std::size_t(i)])) {
                if (first < 0) first = qint64(checked * 2 + std::uint64_t(i));
                ++differences;
                maximumDifference = std::max(maximumDifference, std::abs(double(a[std::size_t(i)]) - b[std::size_t(i)]));
            }
        }
        checked += std::uint64_t(offered);
    }
    require(sf_readf_float(full.value, a.data(), 1) == 0 && sf_readf_float(selected.value, b.data(), 1) == 0 &&
        sf_error(full.value) == SF_ERR_NO_ERROR && sf_error(selected.value) == SF_ERR_NO_ERROR, "Own full/seek comparison has trailing frames or errors");
    full.close(); selected.close(); require(same(fullBefore, status(fullFd.value)) && same(seekBefore, status(seekFd.value)), "Own outputs changed during comparison");
    return {{"role", roles[role]}, {"full_tail_start_frame", qint64(target)}, {"compared_frames", qint64(checked)},
        {"compared_samples", qint64(checked * 2)}, {"different_float_bits", qint64(differences)}, {"first_different_tail_sample", first},
        {"maximum_absolute_difference", maximumDifference}, {"exact_bits", differences == 0}};
}
void saveResult(int directory, const QJsonObject& result)
{
    Fd fd(::openat(directory, "result.json", O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600));
    require(fd.value >= 0, "Result must be a fresh regular output"); const auto bytes = QJsonDocument(result).toJson(); qsizetype done = 0;
    while (done < bytes.size()) {
        const auto wrote = ::write(fd.value, bytes.constData() + done, std::size_t(bytes.size() - done));
        if (wrote < 0 && errno == EINTR) continue;
        require(wrote > 0, "Cannot write complete result"); done += wrote;
    }
    require(::fsync(fd.value) == 0, "Cannot finalize result");
}
} // namespace

int main(int argc, char** argv)
{
    if (argc != 6) { std::cerr << "Usage: exporter DRUMS.wav BASS.wav OTHER.wav VOCALS.wav FRESH_ABSOLUTE_DIRECTORY\n"; return 2; }
    const QString directory = QString::fromLocal8Bit(argv[5]);
    if (!QFileInfo(directory).isAbsolute() || ::mkdir(QFile::encodeName(directory).constData(), 0700) != 0) return 2;
    Fd output(::open(QFile::encodeName(directory).constData(), O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW));
    if (output.value < 0) return 2;
    const auto start = Clock::now(); QJsonObject result{{"schema", 1}, {"passed", false}, {"qualified", false},
        {"scope", "Offline continuous full/seek stem conversion and written-file exact-bit comparison. No inserted gaps, gains, signal switches or hardware playback; no musical acceptance."},
        {"binary_path_argument", QString::fromLocal8Bit(argv[0])}, {"input_frames44100", qint64(n)}, {"expected_output_frames48000", qint64(m)},
        {"seek_output_frame", qint64(target)}, {"declared_pcm_storage_bytes", qint64(pcmBytes)}, {"gain", 1.0},
        {"recombination", "Float32 left-to-right drums+bass+other+vocals, no scaling/clipping/normalization."},
        {"budgets", "115s soft between bounded operations; root hard timeout120s with kill-after5s. Four bounded inputs and ten fresh outputs; declared PCM storage below128MiB, observedRSS gate256MiB."}};
    QString failure;
    try {
        Bank input; QJsonArray inputs;
        for (std::size_t role = 0; role < 4; ++role) { inputs.append(readInput(QString::fromLocal8Bit(argv[role + 1]), input[role], start)); result["inputs"] = inputs; }
        budget(start); const auto countStart = Clock::now(); const auto plan = Converter::countFrames(n, 1200000);
        result["count_wall_ns"] = qint64(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - countStart).count());
        require(plan.inputFrames() == n && plan.outputFrames() == m, "Candidate count differs from unchangedN/M gate");
        auto full = convert(input, plan, 0, start), selected = convert(input, plan, target, start);
        result["full_conversion"] = full.report; result["seek_conversion"] = selected.report;
        QJsonArray outputs;
        for (std::size_t role = 0; role < 5; ++role) {
            outputs.append(writeSignal(output.value, QString("full-%1.wav").arg(roles[role]), full.pcm, role, m, start)); result["outputs"] = outputs;
            outputs.append(writeSignal(output.value, QString("seek-%1.wav").arg(roles[role]), selected.pcm, role, m - target, start)); result["outputs"] = outputs;
        }
        bool exact = true; QJsonArray comparisons;
        for (std::size_t role = 0; role < 5; ++role) { const auto v = compareWritten(output.value, role, start); exact = exact && v["exact_bits"].toBool(); comparisons.append(v); result["own_full_tail_vs_seek"] = comparisons; }
        require(exact, "Written seek differs from its own full output tail in float bits");
        rusage usage{}; require(::getrusage(RUSAGE_SELF, &usage) == 0 && usage.ru_maxrss > 0, "Cannot obtain bounded process memory evidence");
        result["maximum_resident_KiB"] = qint64(usage.ru_maxrss); require(usage.ru_maxrss < 256L * 1024, "Offline exporter exceeded256MiB resident-memory gate");
        result["passed"] = true;
    } catch (const std::exception& error) { failure = QString::fromUtf8(error.what()); }
    result["error"] = failure; result["elapsed_wall_ns"] = qint64(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
    try { saveResult(output.value, result); } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
    std::cout << QJsonDocument(QJsonObject{{"passed", result["passed"]}, {"qualified", false}, {"error", failure}, {"directory", directory}}).toJson(QJsonDocument::Compact).constData() << '\n';
    return result["passed"].toBool() ? 0 : 1;
}
