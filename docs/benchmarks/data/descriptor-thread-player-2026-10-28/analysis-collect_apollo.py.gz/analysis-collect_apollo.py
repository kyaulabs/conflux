"""Retrieve only bounded text evidence from the completed owned Apollo case."""
from pathlib import Path,PurePosixPath
import hashlib,io,json,subprocess,tarfile
BASE=Path(__file__).resolve().parent
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101','-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
CODE=r"""from pathlib import Path
import io,tarfile,hashlib,json,sys
base=Path('/srv/conflux-tests/work/description-threads-player-20261028-01')
files=[]
for name in ('pair-readiness-01.json','pair-reservation-01.json','unit-dispatch.json','pair-result-01.json','unit.stdout.log','unit.stderr.log','operations/binding.json','cases/candidate/dispatch.json','cases/candidate/receipt.json','cases/candidate/gpu-observations.csv','cases/candidate/container.log'):
 p=base/name
 assert p.is_file() and not p.is_symlink(),name
 files.append(p)
p=base/'cases/candidate/private-player-01'
for x in sorted(p.rglob('*')):
 if x.is_file() and not x.is_symlink() and 'cache' not in x.relative_to(p).parts and x.suffix in ('.json','.jsonl','.log','.csv'):files.append(x)
assert len(files)<=64
rows=[];total=0;buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as tar:
 for p in files:
  raw=p.read_bytes();total+=len(raw)
  assert len(raw)<=8*1024*1024 and total<=16*1024*1024
  name=str(p.relative_to(base));rows.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;tar.addfile(info,io.BytesIO(raw))
 raw=json.dumps(dict(remote_root=str(base),files=rows,total_bytes=total),indent=2).encode()
 info=tarfile.TarInfo('_manifest.json');info.size=len(raw);info.mode=0o600;tar.addfile(info,io.BytesIO(raw))
sys.stdout.buffer.write(buf.getvalue())
"""
r=subprocess.run(SSH+['sudo -n python3 -'],input=CODE.encode(),capture_output=True,timeout=45)
if r.returncode:raise RuntimeError(r.stderr.decode(errors='replace'))
assert len(r.stdout)<=8*1024*1024
(BASE/'apollo-text-01.tar.gz').write_bytes(r.stdout)
with tarfile.open(fileobj=io.BytesIO(r.stdout),mode='r:gz') as tar:
 m=json.load(tar.extractfile('_manifest.json'))
 assert len(m['files'])<=64 and m['total_bytes']<=16*1024*1024
 assert set(tar.getnames())==set(x['path'] for x in m['files'])|{'_manifest.json'}
 dest=BASE/'apollo';dest.mkdir(exist_ok=False)
 for row in m['files']:
  name=PurePosixPath(row['path']);assert not name.is_absolute() and '..' not in name.parts
  info=tar.getmember(str(name));assert info.isfile() and info.size==row['bytes']
  raw=tar.extractfile(info).read();assert hashlib.sha256(raw).hexdigest()==row['sha256']
  p=dest.joinpath(*name.parts);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
(BASE/'apollo-transfer-01.json').write_text(json.dumps(dict(manifest=m,archive_sha256=hashlib.sha256(r.stdout).hexdigest(),all_original_hashes_match=True,read_only_remote_collection=True),indent=2)+'\n')
print(json.dumps(dict(files=len(m['files']),text_bytes=m['total_bytes'],archive_bytes=len(r.stdout),all_original_hashes_match=True)))
