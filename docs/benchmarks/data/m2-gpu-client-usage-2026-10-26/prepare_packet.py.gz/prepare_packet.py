"""Freeze source/build/file bindings without authorizing or launching hardware."""
from pathlib import Path
import hashlib
import io
import json
import re
import subprocess

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
CASE = BASE / 'cases/candidate'
OLD = ROOT / 'build/m2-runtime-thread-wait-01'
HEAD = 'bb5db7af5490035778f8ba1772e42dbbed0917bd'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
    assert not (CASE / 'readiness.json').exists() and not (CASE / 'output-01').exists()
    script = CASE / 'run_host_player.py'
    source = re.sub(r"SOURCE_HEAD = '[0-9a-f]{40}'", 'SOURCE_HEAD = ' + repr(HEAD), script.read_text())
    script.write_text(source)
    outer = CASE / 'run_player_owned.py'
    outer.write_text(re.sub(r"LAUNCHER_SHA = '[0-9a-f]{64}'", 'LAUNCHER_SHA = ' + repr(pin(script)['sha256']), outer.read_text()))
    # kde-inhibit executes this fixed shebang entry directly, not through a shell.
    outer.chmod(0o755)
    plan = json.loads((CASE / 'plan.json').read_text())
    plan['source_head'] = plan['actual_checkout_head_at_preparation'] = HEAD
    for section in ('assets', 'helpers', 'sources'):
        for key, row in list(plan[section].items()):
            path = Path(row['path'])
            assert path.exists(), path
            plan[section][key] = pin(path)
    plan['helpers']['drm_usage'] = pin(BASE / 'drm_usage.py')
    plan['helpers']['gpu_clock_capability'] = pin(BASE / 'clock-capability-01.json')
    plan['sources'][str(BASE / 'drm_usage.py')] = pin(BASE / 'drm_usage.py')
    refs = [HEAD + ':' + str(Path(row['path']).relative_to(ROOT)) for row in plan['source_pins']]
    data = subprocess.run(['git', 'cat-file', '--batch'], input=('\n'.join(refs) + '\n').encode(), capture_output=True, check=True)
    stream = io.BytesIO(data.stdout)
    for row in plan['source_pins']:
        header = stream.readline().decode().split()
        assert len(header) == 3 and header[1] == 'blob'
        raw = stream.read(int(header[2]))
        assert stream.read(1) == b'\n'
        assert hashlib.sha256(raw).hexdigest() == row['sha256'] and pin(Path(row['path'])) == row
    commands = json.loads((ROOT / 'build/dev/compile_commands.json').read_text())
    assert len(commands) == 100
    receipt = json.loads((OLD / 'root-build-receipt-01.json').read_text())
    receipt.update(source_head=HEAD, binary=plan['assets']['binary'], cache=plan['helpers']['build_cache'],
        compile_commands=plan['helpers']['compile_commands'], build_refresh_log=pin(BASE / 'build-refresh-01.log'))
    assert pin(ROOT / 'build/dev/conflux-manual-playback-soak')['sha256'] == receipt['binary']['sha256']
    save(BASE / 'root-build-receipt-01.json', receipt)
    attestation = json.loads((OLD / 'root-source-build-attestation-01.json').read_text())
    attestation.update(source_head=HEAD, build_receipt_sha256=pin(BASE / 'root-build-receipt-01.json')['sha256'])
    save(BASE / 'root-source-build-attestation-01.json', attestation)
    plan['build_receipt'] = pin(BASE / 'root-build-receipt-01.json')
    plan['source_build_attestation'] = pin(BASE / 'root-source-build-attestation-01.json')
    plan['status'] = 'frozen_pending_fresh_readiness'
    save(CASE / 'plan.json', plan)
    launch = json.loads((CASE / 'root-launch-plan-01.json').read_text())
    launch.update(source_head=HEAD, plan=pin(CASE / 'plan.json'), read_only_GPU_client_and_clock_snapshots_enabled=True)
    save(CASE / 'root-launch-plan-01.json', launch)
    print('Verified 95 tracked source files and unchanged optimized player; packet is unarmed.')


if __name__ == '__main__':
    main()
