"""Exercise diagnostic admission with real helper predicates and offline clocks."""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'cases/candidate'))
import test_host_player as old
driver=old.driver


class NaturalGuardTests(unittest.TestCase):
    def fixture(self):
        plan,clock,state,timing,load=old.AdmissionTests().setup_mock(temp=45000)
        plan['allow_natural_power_saver_start']=True
        state.update(profile='power-saver',recovered=False,platform='low-power',epp='power')
        return plan,clock,state,timing,load

    def test_natural_power_saver_still_requires_full_cooldown(self):
        plan,clock,state,timing,load=self.fixture();report={}
        with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
            fresh,recovery,cooldown=driver.prepare_admission(plan,report,500,1,lambda:None)
            recovery();cooldown();fresh('before_dispatch')
        self.assertEqual(clock[0],61)
        self.assertTrue(report['cooldown_complete'])
        self.assertEqual(report['cool_readiness'][-1]['consecutive_span_seconds'],60)
        self.assertEqual(report['fresh_admissions'][-1]['profile'],'power-saver')

    def test_hot_samples_keep_original55C_stable_requirement(self):
        plan,clock,state,timing,load=self.fixture();report={}
        with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
            fresh,recovery,cooldown=driver.prepare_admission(plan,report,500,1,lambda:None)
            recovery();state['temp']=56000
            with self.assertRaisesRegex(ValueError,'Original bounded60s'):cooldown()
        self.assertEqual(clock[0],301)
        self.assertFalse(report.get('cooldown_complete',False))

    def test_fresh_checks_reject_profile_mismatch_holds_or_hot_package(self):
        for key,value in [('epp','performance'),('platform','balanced'),('holds','external hold'),('temp',71000)]:
            with self.subTest(key=key):
                plan,clock,state,timing,load=self.fixture();report={}
                with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
                    fresh,recovery,cooldown=driver.prepare_admission(plan,report,500,1,lambda:None)
                    recovery();state[key]=value
                    with self.assertRaises(ValueError):fresh('before_dispatch')
                self.assertFalse(report['fresh_admissions'][-1]['accepted'])

    def test_exact_guard_critical_message_allows_cool_protected_start(self):
        plan,clock,state,timing,load=self.fixture();report={}
        def critical_load(name,*args):
            module=load(name,*args)
            if name.endswith('_readiness'):
                capture=module.capture
                def critical_capture(*args):
                    row=capture(*args)
                    row['latest_guard_entry']['MESSAGE']='2026-10-27T02:40:00+00:00 critical: CPU/ACPI temperature 95.0C'
                    return row
                module.capture=critical_capture
            return module
        with patch.object(driver,'load_source',side_effect=critical_load),patch.object(driver,'time',timing):
            fresh,recovery,cooldown=driver.prepare_admission(plan,report,500,1,lambda:None)
            recovery();cooldown();fresh('before_dispatch')
        self.assertEqual(clock[0],61)
        self.assertTrue(report['cooldown_complete'])
        self.assertTrue(report['fresh_admissions'][-1]['accepted'])

    def test_guard_identity_and_journal_proof_remain_required(self):
        plan,clock,state,timing,load=self.fixture();report={}
        with patch.object(driver,'load_source',side_effect=load),patch.object(driver,'time',timing):
            fresh,recovery,cooldown=driver.prepare_admission(plan,report,500,1,lambda:None)
            recovery();row=report['initial_recovery_samples'][-1]
            host=report['host_observations'][-1]
            expected={'MainPID':'100','InvocationID':'a'*32}
            self.assertTrue(driver.guarded_context(row,host,expected,55000))
            for change in ({'journal_identity_matches_service':False},{'latest_guard_entry':{'MESSAGE':'unrelated'}},
                {'service_identity':{**row['service_identity'],'MainPID':'101'}}):
                self.assertFalse(driver.guarded_context({**row,**change},host,expected,55000))


if __name__=='__main__':unittest.main()
