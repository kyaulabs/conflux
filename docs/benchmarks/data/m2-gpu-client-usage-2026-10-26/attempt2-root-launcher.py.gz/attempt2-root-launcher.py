"""One fresh-readiness dispatch; no client starts without --run."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import time

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
CASE = BASE / 'cases/candidate'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def show(unit):
    raw = subprocess.check_output(['systemctl', '--user', 'show', unit,
        '--property=LoadState,ActiveState,SubState,InvocationID,MainPID,Result,ExecMainStatus,ControlGroup'],
        text=True, timeout=5)
    return dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)


def executable_owner():
    owner = CASE / 'run_player_owned.py'
    mode = owner.stat().st_mode
    assert stat.S_ISREG(mode) and mode & 0o111 and os.access(owner, os.X_OK), \
        'Direct owner entry is not executable; no unit may be dispatched'


def dispatch_once(launch, record):
    # Dispatch can succeed even if the process exits before /proc observation.
    # Always retain the unit receipt; never retry or invent a PID birth tick.
    try:
        result = subprocess.run(launch['command'], capture_output=True, text=True, timeout=10)
        record.update(launch_returncode=result.returncode, launch_stdout=result.stdout,
            launch_stderr=result.stderr)
        after = show(launch['unit'])
        record.update(unit_after_launch=after, original_owned_cgroup=after.get('ControlGroup', ''))
        if int(after.get('MainPID', '0')):
            pid = int(after['MainPID'])
            try:
                fields = Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()
                record['owner_identity'] = dict(pid=pid, start_ticks=int(fields[19]),
                    group=int(fields[2]), session=int(fields[3]), ppid=int(fields[1]))
            except (FileNotFoundError, ProcessLookupError) as error:
                record['owner_identity_observation_error'] = dict(type=type(error).__name__,
                    message=str(error), pid=pid, birth_ticks_unknown=True)
    except BaseException as error:
        record['dispatch_or_observation_error'] = dict(type=type(error).__name__, message=str(error))
        raise
    finally:
        save(CASE / 'root-unit-dispatch-01.json', record)
    assert (record['launch_returncode'] == 0 and after['ActiveState'] == 'active'
        and after['SubState'] == 'running' and record.get('owner_identity')), \
        'Unit dispatched but running owner not proven; retained receipt requires cleanup, not retry'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    launch = json.loads((CASE / 'root-launch-plan-01.json').read_text())
    clearance = json.loads((CASE / 'root-launch-clearance-01.json').read_text())
    for row in clearance['pins']:
        assert pin(Path(row['path'])) == row
    assert pin(CASE / 'plan.json') == launch['plan']
    assert launch['no_retries'] and launch['fresh_readiness_required']
    assert not any((CASE / name).exists() for name in (
        'root-dispatch-reservation-01.json', 'dispatch-01.json', 'root-unit-dispatch-01.json',
        'root-finished-01.json', 'output-01'))
    executable_owner()
    if not args.run:
        print(json.dumps(dict(verified=True, native_started=False,
            fresh_readiness_present=(CASE / 'readiness.json').exists())))
        return
    # Read the human record before any host query or process launch. The old
    # time-window grant is deliberately absent from this packet.
    human_path = CASE / 'readiness.json'
    human_pin = pin(human_path)
    human = json.loads(human_path.read_text())
    assert human['authorization_kind'] == 'fresh_async_user_reply'
    spec = importlib.util.spec_from_file_location('count_player_dispatch', CASE / 'run_host_player.py')
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    now = time.monotonic()
    clocks = driver.budget(human, launch['plan']['sha256'], datetime.now(timezone.utc), now)
    assert clocks['operator_deadline'] - now >= 600
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    ac = list(Path('/sys/class/power_supply').glob('*/online'))
    lids = list(Path('/proc/acpi/button/lid').glob('*/state'))
    assert ac and any(path.read_text().strip() == '1' for path in ac)
    assert lids and all(path.read_text().strip().endswith('open') for path in lids)
    assert shutil.disk_usage(BASE).free >= 2 * 1024**3
    plan = driver.validate_plan(json.loads((CASE / 'plan.json').read_text()))
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True, timeout=4).strip()
    assert head == plan['source_head']
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True, timeout=4) == ''
    before, guard = show(launch['unit']), show('thermal-guard.service')
    assert before['LoadState'] == 'not-found' and before['MainPID'] == '0'
    assert guard['ActiveState'] == 'active' and guard['SubState'] == 'running'
    driver.validate_power_caps(driver.read_power_caps())
    assert pin(human_path) == human_pin
    assert time.monotonic() - now <= 20
    record = dict(schema=1, unit=launch['unit'], command=launch['command'],
        original_readiness_utc=human['recorded_at_utc'],
        original_readiness_monotonic=human['recorded_at_monotonic'],
        operator_deadline_monotonic=clocks['operator_deadline'],
        original_operator_seconds=1200, human_pin=human_pin,
        unit_before=before, guard_before=guard,
        automatic_retries=False, original_store_authorization_reused=False)
    save(CASE / 'root-dispatch-reservation-01.json', dict(
        plan=launch['plan'], human=human_pin, started_monotonic=now))
    dispatch_once(launch, record)
    print(json.dumps(dict(status='dispatched_once_running_owner_observed', unit=launch['unit'],
        remaining_original_seconds=clocks['operator_deadline'] - time.monotonic())))


if __name__ == '__main__':
    main()
