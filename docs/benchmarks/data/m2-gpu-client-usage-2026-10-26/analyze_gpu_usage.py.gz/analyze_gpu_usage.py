"""Analyze retained per-client GPU counters; never query or modify the laptop."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import statistics

BASE = Path(__file__).resolve().parent
OUT = BASE / 'cases/candidate/output-01'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def counter_points(captures, engine):
    """One point per captured client; duplicate FDs never add busy time."""
    high = None
    regressions = 0
    points = []
    for capture in captures:
        available = []
        for observation in sorted(capture['observations'], key=lambda row: row['observed_monotonic_ns']):
            text = observation['fields'].get('drm-engine-' + engine)
            if text is None:
                continue
            match = re.fullmatch(r'([0-9]+) ns', text)
            assert match, ('Unexpected counter units', engine, text)
            capacity = observation['fields'].get('drm-engine-capacity-' + engine, '1')
            assert re.fullmatch(r'[0-9]+', capacity) and int(capacity) > 0
            value = int(match[1])
            if high is not None and value < high:
                regressions += 1
            high = value if high is None else max(high, value)
            available.append(dict(observed_ns=observation['observed_monotonic_ns'],
                raw_ns=value, high_water_ns=high, capacity=int(capacity)))
        if available:
            point = available[-1]
            assert all(row['capacity'] == point['capacity'] for row in available)
            point['duplicate_descriptor_observations'] = len(available) - 1
            points.append(point)
    assert all(a['observed_ns'] < b['observed_ns'] for a, b in zip(points, points[1:]))
    return points, regressions


def interval(points):
    if len(points) < 2:
        return dict(points=len(points), busy_seconds=None, observed_span_seconds=None,
            engine_active_time_ratio=None)
    assert len({p['capacity'] for p in points}) == 1
    span = (points[-1]['observed_ns'] - points[0]['observed_ns']) / 1e9
    busy = (points[-1]['high_water_ns'] - points[0]['high_water_ns']) / 1e9
    assert span > 0 and busy >= 0
    return dict(points=len(points), first_observed_ns=points[0]['observed_ns'],
        last_observed_ns=points[-1]['observed_ns'], busy_seconds=busy,
        observed_span_seconds=span, engine_capacity=points[0]['capacity'],
        engine_active_time_ratio=busy / span / points[0]['capacity'])


def main():
    host_path = OUT / 'host-observations.jsonl'
    assert host_path.stat().st_size <= 16 * 1024**2
    host = [json.loads(line) for line in host_path.read_text().splitlines()]
    waits = json.loads((BASE / 'wait-results-01.json').read_text())
    worst = waits['worst_hop']
    begin, end = (worst[k] for k in ('worker_hop_envelope_begin_ns', 'worker_hop_envelope_end_ns'))
    clients = defaultdict(list)
    owners = defaultdict(set)
    completeness = Counter()
    for sample in host:
        for role, key in (('player', 'native_thread_cpu'), ('runtime', 'runtime_thread_cpu')):
            for process in sample['process_cpu_read_only'][key]:
                if not process['matched_expected_exe']:
                    continue
                capture = process['drm_usage_read_only']
                assert capture['pid'] == process['pid']
                assert capture['process_start_ticks'] == process['process_start_ticks']
                completeness[(role, capture['complete'])] += 1
                if not capture['complete']:
                    continue
                for client in capture['clients']:
                    identity = (client['driver'], client['pdev'], client['client_id'])
                    clients[identity].append(client)
                    owners[identity].add((role, process['pid'], process['process_start_ticks']))
    summaries = []
    for identity, captures in sorted(clients.items()):
        # A shared client is one global record, even if two processes expose it.
        captures.sort(key=lambda row: min(o['observed_monotonic_ns'] for o in row['observations']))
        engines = sorted({key.removeprefix('drm-engine-') for capture in captures
            for observation in capture['observations'] for key in observation['fields']
            if key.startswith('drm-engine-') and not key.startswith('drm-engine-capacity-')})
        engine_rows = {}
        for engine in engines:
            points, regressions = counter_points(captures, engine)
            inside = [point for point in points if begin <= point['observed_ns'] <= end]
            engine_rows[engine] = dict(whole_observed_interval=interval(points),
                inside_worst_hop_envelope=interval(inside), counter_regression_observations=regressions,
                duplicate_FD_observations_not_added=sum(p['duplicate_descriptor_observations'] for p in points))
        summaries.append(dict(driver=identity[0], pdev=identity[1], client_id=identity[2],
            owner_lifetimes=[dict(role=role,pid=pid,start_ticks=start) for role,pid,start in sorted(owners[identity])],
            complete_client_captures=len(captures), engines=engine_rows))
    clocks = [row['gpu_clocks_read_only'] for row in host]
    assert all(not row['read_errors'] for row in clocks)
    fields = sorted(clocks[0]['values'])
    assert all(sorted(row['values']) == fields for row in clocks)
    inside_clocks = [row for row in clocks if begin <= row['began_monotonic_ns']
        and row['finished_monotonic_ns'] <= end]
    def clock_summary(rows):
        return {key: dict(samples=len(rows), minimum=min(row['values'][key] for row in rows),
            median=statistics.median(row['values'][key] for row in rows),
            maximum=max(row['values'][key] for row in rows),
            nonzero_samples=sum(row['values'][key] != 0 for row in rows)) for key in fields} if rows else {}
    peaks = []
    for row in host:
        maximum = max(row['temperatures_millidegrees_C'].values())
        if maximum >= 85000:
            peaks.append(dict(at_utc=row['at_utc'], monotonic_ns=row['monotonic_ns'],
                maximum_millidegrees_C=maximum))
    report = dict(schema=1, host_observations=pin(host_path), wait_analysis=pin(BASE/'wait-results-01.json'),
        analyzer=pin(Path(__file__).resolve()), host_samples=len(host),
        matched_DRM_process_capture_counts=[dict(role=role,complete=complete,count=count)
            for (role,complete),count in sorted(completeness.items())],
        globally_unique_device_client_count=len(summaries), clients=summaries,
        clock_point_observations=clock_summary(clocks), worst_hop=worst,
        clock_points_wholly_inside_worst_hop=clock_summary(inside_clocks),
        samples_at_or_above_85C=peaks,
        exact_kernel_or_queue_or_request_GPU_duration_measured=False,
        engine_active_time_is_frequency_normalized=False, sample_counts_are_duration_fractions=False,
        instrumented_diagnostic_only=True, qualified=False,
        scope='DRM counters use client/device identity and high-water values for regressions. Duplicate FDs are not additive. Busy deltas cover observed endpoints only; subsets inside a worker hop envelope omit both unsampled edges. Clock/throttle fields are point observations. Active-time ratios do not distinguish useful arithmetic, memory stalls, engine scheduling or contention and do not establish a throttling cause. No system or product setting changed.')
    with (BASE/'gpu-usage-results-01.json').open('x') as stream:
        stream.write(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(samples=len(host),clients=summaries,
        actual_freq=report['clock_point_observations']['/sys/class/drm/card1/gt_act_freq_mhz'],
        worst_actual_freq=report['clock_points_wholly_inside_worst_hop'].get('/sys/class/drm/card1/gt_act_freq_mhz'),
        hot_samples=peaks),indent=2))


if __name__ == '__main__':
    main()
