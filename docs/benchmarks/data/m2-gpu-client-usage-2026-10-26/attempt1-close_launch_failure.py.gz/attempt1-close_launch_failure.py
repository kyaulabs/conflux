"""Close the dispatched, immediately exited unit without inventing ownership proof."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
CASE = BASE / 'cases/candidate'
UNIT = 'conflux-m2-gpu-client-usage-20261026-01.service'
INVOCATION = '7ec91d56b14a4ea389864fc3ed06a034'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def command(args):
    result = subprocess.run(args, text=True, capture_output=True, timeout=6, check=True)
    assert len(result.stdout) <= 16 * 1024 * 1024
    return result.stdout


def show(unit):
    raw = command(['systemctl', '--user', 'show', unit, '--no-pager',
        '--property=LoadState,ActiveState,SubState,InvocationID,MainPID,ExecMainPID,Result,ExecMainStatus,ControlGroup,Slice'])
    return dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)


def main():
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    human = json.loads((CASE / 'readiness.json').read_text())
    reservation = json.loads((CASE / 'root-dispatch-reservation-01.json').read_text())
    plan = json.loads((CASE / 'plan.json').read_text())
    assert pin(CASE / 'readiness.json') == reservation['human']
    assert pin(CASE / 'plan.json') == reservation['plan']
    assert human['plan_sha256'] == reservation['plan']['sha256']
    deadline = human['recorded_at_monotonic'] + human['maximum_operator_seconds']
    assert time.monotonic() < deadline
    assert not any((CASE / name).exists() for name in
        ('root-unit-dispatch-01.json', 'dispatch-01.json', 'admission-01.json', 'output-01'))
    before = show(UNIT)
    assert before['InvocationID'] == INVOCATION
    assert before['ActiveState'] == 'active' and before['SubState'] == 'exited'
    assert before['MainPID'] == '0' and before['ExecMainPID'] == '1265984'
    assert before['ControlGroup'] == ''
    assert not Path('/proc/1265984').exists()
    runner = CASE / 'run_player_owned.py'
    runner_mode = runner.stat().st_mode
    assert runner_mode & 0o111 == 0 and not os.access(runner, os.X_OK)
    remaining, cgroup_members = [], []
    nonmatching_protected_executables = 0
    asset_executables = {'conflux-manual-playback-soak', 'conflux-stem-runtime'}
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            if entry.stat().st_uid != os.getuid():
                continue
            cgroup = (entry / 'cgroup').read_text()
            if UNIT in cgroup:
                cgroup_members.append(int(entry.name))
            argv = (entry / 'cmdline').read_bytes().split(b'\0')
            owned_path = any(value.decode(errors='replace') in
                (str(runner), str(CASE / 'run_host_player.py')) for value in argv)
            try:
                executable = (entry / 'exe').resolve(strict=True)
            except PermissionError:
                # Protected same-user services can deny exe readlink. Require
                # readable argv and comm that both exclude our targets instead.
                comm = (entry / 'comm').read_text().strip()
                assert argv and argv[0] and not owned_path
                assert not any(Path(value.decode(errors='replace')).name in asset_executables
                    for value in argv if value)
                assert not any(name.startswith(comm) for name in asset_executables)
                nonmatching_protected_executables += 1
                continue
            if executable.name in asset_executables or owned_path:
                remaining.append(dict(pid=int(entry.name), executable=str(executable)))
        except (FileNotFoundError, ProcessLookupError):
            continue
    assert not remaining and not cgroup_members
    inhibition = json.loads(command(['/usr/bin/busctl', '--user', '--timeout=2s', '--json=short',
        'call', 'org.kde.Solid.PowerManagement.PolicyAgent',
        '/org/kde/Solid/PowerManagement/PolicyAgent',
        'org.kde.Solid.PowerManagement.PolicyAgent', 'ListInhibitions']))
    assert inhibition['type'] == 'aas'
    own_inhibitions = sum(row[1] == str(runner) for row in inhibition['data'][0])
    assert own_inhibitions == 0
    audio = json.loads(command(['pw-dump', '-N']))
    own_audio = []
    for row in audio:
        props = row.get('info', {}).get('props', {})
        binary = str(props.get('application.process.binary', ''))
        if str(props.get('application.process.id', '')) == '1265984' or Path(binary).name in asset_executables:
            own_audio.append(row['id'])
    assert not own_audio
    guard = show('thermal-guard.service')
    assert guard['ActiveState'] == 'active' and guard['SubState'] == 'running'
    assert guard['MainPID'] == '128417'
    assert guard['InvocationID'] == '70897370eb6e477f8ab0911410cb5c60'
    guard_files = [
        (Path('/home/kyau/.local/bin/thermal-guard'),
         '0d693e7bc8e01d215089586f8dc78983398bcf028394b3d355f8762dba62bcb0'),
        (Path('/home/kyau/.config/systemd/user/thermal-guard.service'),
         'e5c6c89f2b186b976379b2ee4ffb0d3e044e1cf9b1fca3a0cf60cc600c9b2d8f')]
    for path, digest in guard_files:
        assert pin(path)['sha256'] == digest
    caps = {path: int(Path(path).read_text()) for path in plan['power_limits']}
    assert all(0 < caps[path] <= bound if path.endswith('power_limit_uw') else caps[path] == bound
        for path, bound in plan['power_limits'].items())
    # Only retire this exact exited invocation. Never signal an inferred PID/group.
    assert show(UNIT) == before
    command(['systemctl', '--user', 'stop', UNIT])
    after = show(UNIT)
    assert after['LoadState'] == 'not-found' and after['MainPID'] == '0'
    assert show('thermal-guard.service') == guard
    now = time.monotonic()
    receipt = dict(schema=1, status='launch_failed_before_owner_receipt_independently_closed',
        qualified=False, timed_workload_started=False, native_result_present=False,
        latency_ms=None, cancellation_result=None, audio_result=None,
        original_readiness=reservation['human'], original_plan=reservation['plan'],
        original_readiness_utc=human['recorded_at_utc'],
        original_readiness_monotonic=human['recorded_at_monotonic'],
        operator_deadline_monotonic=deadline, closed_at_utc=datetime.now(timezone.utc).isoformat(),
        closed_monotonic=now, elapsed_original_seconds=now-human['recorded_at_monotonic'],
        within_original_1200_seconds=now <= deadline, cleanup_complete=True,
        unit_before_stop=before, unit_after_stop=after,
        owner_exec_pid=1265984, owner_birth_ticks=None,
        owner_identity_limitation='Owner exited before /proc capture; no birth tick or group identity is invented.',
        remaining_matching_players_or_runners=remaining, remaining_unit_cgroup_members=cgroup_members,
        nonmatching_protected_executables=nonmatching_protected_executables,
        own_idle_inhibitions_remaining=own_inhibitions, own_audio_resources_remaining=own_audio,
        guard_matches_previous_frozen_identity_and_files=True, power_caps_within_frozen_limits=True,
        wrapper_executable_mode=oct(runner_mode), wrapper_executable=False,
        root_error=dict(type='FileNotFoundError', path='/proc/1265984/stat',
            phase='After systemd dispatch while observing exited owner; root receipt was not written.'),
        original_root_receipt_missing=True, automatic_retry=False, further_client_tests_authorized=False,
        closure_first_attempt_error='PermissionError reading /proc/128404/exe; stopped before mutation. Corrected by requiring readable nonmatching argv and comm for protected exe entries.',
        closure_helper=pin(Path(__file__).resolve()))
    assert receipt['within_original_1200_seconds']
    with (CASE / 'root-finished-01.json').open('x') as stream:
        stream.write(json.dumps(receipt, indent=2, allow_nan=False)+'\n')
    print(json.dumps({key: receipt[key] for key in ('status','cleanup_complete',
        'elapsed_original_seconds','within_original_1200_seconds','further_client_tests_authorized')}))


if __name__ == '__main__':
    main()
