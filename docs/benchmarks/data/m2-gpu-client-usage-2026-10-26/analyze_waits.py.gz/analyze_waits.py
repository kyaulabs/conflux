"""Summarize already captured task snapshots; no new host queries or workloads."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import math
import statistics

BASE = Path(__file__).resolve().parent
CASE = BASE / 'cases/candidate'
OUT = CASE / 'output-01'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def lines(path, maximum):
    assert path.stat().st_size <= maximum
    return [json.loads(line) for line in path.read_text().splitlines()]


def counts(rows):
    result = Counter((r['wait_snapshot']['state_before'], r['wait_snapshot']['state_after'],
                      r['wait_snapshot']['kernel_wait_symbol']) for r in rows)
    return [dict(state_before=before, state_after=after, kernel_wait_symbol=symbol, observations=count)
            for (before, after, symbol), count in result.most_common()]


def main():
    host_path, obs_path = OUT / 'host-observations.jsonl', OUT / 'observations.jsonl'
    host = lines(host_path, 16 * 1024**2)
    events = lines(obs_path, 4 * 1024**2)
    hops = [r for r in events if r.get('hop_service_present') is True]
    assert len(host) >= 2 and len(hops) == 17
    observed = {}
    for kind in ('native_thread_cpu', 'runtime_thread_cpu'):
        groups = defaultdict(list)
        snapshots = []
        errors = []
        for sample in host:
            scan = sample['process_cpu_read_only']
            assert scan['exact_runqueue_wait_measured'] is False
            assert scan['ticks_per_second'] == 100
            for process in scan[kind]:
                if not process['matched_expected_exe']:
                    continue
                snapshots.append(process)
                errors.extend(process['errors'])
                for task in process['threads']:
                    wait = task['wait_snapshot']
                    assert wait['began_monotonic_ns'] <= wait['finished_monotonic_ns']
                    assert wait['state_unchanged'] == (wait['state_before'] == wait['state_after'])
                    assert wait['wait_symbol_available'] == (wait['kernel_wait_symbol'] is not None)
                    key = (process['pid'], process['process_start_ticks'], task['pid'], task['start_ticks'])
                    groups[key].append(task)
        thread_rows = []
        for key, tasks in groups.items():
            assert all(a['observed_monotonic_ns'] < b['observed_monotonic_ns']
                       and a['cpu_ticks'] <= b['cpu_ticks'] for a, b in zip(tasks, tasks[1:]))
            elapsed = (tasks[-1]['observed_monotonic_ns'] - tasks[0]['observed_monotonic_ns']) / 1e9
            cpu = (tasks[-1]['cpu_ticks'] - tasks[0]['cpu_ticks']) / 100
            thread_rows.append(dict(process_pid=key[0], process_start_ticks=key[1], tid=key[2],
                tid_start_ticks=key[3], main_thread=key[0] == key[2], comm=tasks[0]['comm'],
                observations=len(tasks), first_observed_ns=tasks[0]['observed_monotonic_ns'],
                last_observed_ns=tasks[-1]['observed_monotonic_ns'],
                observed_cpu_seconds_between_first_and_last=cpu, observation_span_seconds=elapsed,
                average_observed_cpu_cores=cpu / elapsed if elapsed else None,
                wait_snapshots=counts(tasks)))
        observed[kind] = dict(matched_process_snapshots=len(snapshots),
            complete_process_snapshots=sum(r['complete'] for r in snapshots), errors=errors,
            unique_process_lifetimes=len({(r['pid'], r['process_start_ticks']) for r in snapshots}),
            threads=thread_rows)
    per_hop = []
    for hop in hops:
        end = round(hop['worker_ready_seconds'] * 1e9)
        begin = end - round(hop['hop_service_ms'] * 1e6)
        runtime_main = []
        for sample in host:
            for process in sample['process_cpu_read_only']['runtime_thread_cpu']:
                if not process['matched_expected_exe']:
                    continue
                for task in process['threads']:
                    wait = task['wait_snapshot']
                    if (task['pid'] == process['pid'] and begin <= wait['began_monotonic_ns']
                            and wait['finished_monotonic_ns'] <= end):
                        runtime_main.append(task)
        per_hop.append(dict(**{k: hop[k] for k in ('epoch', 'generation', 'request_id', 'lease_sequence',
            'input_first', 'hop_service_ms', 'source_read_ms', 'overlap_ms', 'native_inference_cpu_ms',
            'native_inference_wall_ms', 'native_graph_compute_ms')},
            worker_hop_envelope_begin_ns=begin, worker_hop_envelope_end_ns=end,
            runtime_main_snapshot_count=len(runtime_main), wait_snapshots=counts(runtime_main)))
    intervals = [(b['monotonic_ns'] - a['monotonic_ns']) / 1e9 for a, b in zip(host, host[1:])]
    assert min(intervals) > 0
    scans = [r['process_cpu_read_only'] for r in host]
    assert all(math.isfinite(h['hop_service_ms']) for h in hops)
    report = dict(schema=1, host_observations=pin(host_path), producer_observations=pin(obs_path),
        analyzer=pin(Path(__file__).resolve()), host_sample_count=len(host),
        host_poll_intervals_seconds=dict(minimum=min(intervals), median=statistics.median(intervals), maximum=max(intervals)),
        observer_total_scan_thread_cpu_seconds=sum(r['scan_thread_cpu_ns'] for r in scans) / 1e9,
        observer_scan_wall_seconds=dict(maximum=max((r['finished_monotonic_ns'] - r['began_monotonic_ns']) / 1e9
                                                     for r in scans)),
        process_snapshots=observed, completed_hop_envelopes=per_hop,
        worst_hop=max(per_hop, key=lambda r: r['hop_service_ms']),
        exact_runqueue_wait_measured=False, graphics_queue_or_kernel_duration_measured=False,
        sample_counts_are_duration_fractions=False, qualification=False,
        scope='Point snapshots only. Hop envelope is reconstructed from worker ready_at minus hop_service_ms; it includes source read, request and overlap, not isolated GPU compute boundaries. CPU counters cover each observed TID lifetime between first and last snapshots and omit unobserved lifetimes. Missing/zero wait symbols are unknown; running/runnable states do not establish CPU queue latency. DRM sync-object waits show graphics synchronization, not its cause. No product, kernel, power-profile, cap or thermal-guard changes.')
    with (BASE / 'wait-results-01.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps(dict(worst=report['worst_hop'], observer_scan_cpu_seconds=report['observer_total_scan_thread_cpu_seconds']), indent=2))


if __name__ == '__main__':
    main()
