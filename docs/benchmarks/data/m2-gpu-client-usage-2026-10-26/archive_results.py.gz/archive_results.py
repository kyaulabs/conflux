"""Retain bounded text evidence, original failures and relevant owned-process data."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
CASE = BASE / 'cases/candidate'
DEST = ROOT / 'docs/benchmarks/data/m2-gpu-client-usage-2026-10-26'
STAGE = BASE / 'archive-stage-01'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def filtered(value):
    if isinstance(value, list):
        return [filtered(row) for row in value]
    if not isinstance(value, dict):
        return value
    result = {}
    for key, data in value.items():
        if key == 'process_cpu_read_only':
            cpu = dict(data)
            if 'processes' in cpu:
                cpu['omitted_process_inventory_rows'] = len(cpu.pop('processes'))
                cpu['unrelated_process_inventory_omitted'] = True
            result[key] = filtered(cpu)
        else:
            result[key] = filtered(data)
    return result


def main():
    DEST.mkdir(exist_ok=False)
    STAGE.mkdir(exist_ok=False)
    selected = {}
    for name in ('analyze_results.py','analyze_waits.py','analyze_gpu_usage.py','archive_results.py',
            'drm_usage.py','test_drm_usage.py','test_gpu_analysis.py','test_owner_entry.py',
            'verify_owner_entry.py','test_natural_guard.py','prepare_packet.py','launch_case.py',
            'results-01.json','wait-results-01.json','gpu-usage-results-01.json',
            'capability-01.json','clock-capability-01.json','root-build-receipt-01.json',
            'root-source-build-attestation-01.json','source-readiness-01.json',
            'actual-owner-entry-check-01.json','previous-attempts-01.json',
            'offline-core-checks-01.log','offline-natural-checks-01.log',
            'offline-drm-checks-01.log','offline-owner-entry-checks-01.log',
            'gpu-analysis-checks-02.log','file-verification-01.log','source-scan-01.log'):
        selected[name] = BASE / name
    for name in ('plan.json','readiness.json','root-launch-plan-01.json','root-launch-clearance-01.json',
            'root-dispatch-reservation-01.json','root-unit-dispatch-01.json','dispatch-01.json',
            'admission-01.json','diagnostic-assessment.json','root-finished-01.json',
            'run_host_player.py','run_player_owned.py','close_case.py','unit.stderr.log'):
        selected['completed-'+name] = CASE / name
    for path in CASE.glob('test_*.py'):
        selected['completed-'+path.name] = path
    for name in ('native-result.json','native.stdout.log','native.stderr.log','observations.jsonl'):
        selected[name] = CASE / 'output-01' / name
    for number in (1,2):
        base = BASE.parent / f'm2-gpu-completion-client-{number:02d}'
        case = base / 'cases/candidate'
        names = ['plan.json','readiness.json','root-launch-plan-01.json','root-dispatch-reservation-01.json',
            'root-finished-01.json','run_player_owned.py','unit.stderr.log']
        if number == 1:
            names += ['root-single-entry-check-01.json']
        else:
            names += ['root-unit-dispatch-01.json']
            selected['attempt2-actual-owner-entry-check.json'] = base / 'actual-owner-entry-check-01.json'
        for name in names:
            selected[f'attempt{number}-'+name] = case / name
        selected[f'attempt{number}-root-launcher.py'] = base / 'launch_case.py'
        helper = 'close_launch_failure.py' if number == 1 else 'close_preflight_failure.py'
        selected[f'attempt{number}-'+helper] = base / helper
    entries = []
    for name,path in selected.items():
        original = path.read_bytes()
        assert len(original) <= 16 * 1024**2
        original.decode('utf-8')
        raw = original
        was_filtered = False
        if path.suffix == '.json':
            value = json.loads(original)
            clean = filtered(value)
            if clean != value:
                raw = (json.dumps(clean,indent=2,allow_nan=False)+'\n').encode()
                was_filtered = True
        packed = gzip.compress(raw,mtime=0)
        assert gzip.decompress(packed) == raw
        (STAGE/name).write_bytes(raw)
        target = DEST/(name+'.gz')
        target.write_bytes(packed)
        entries.append(dict(file=target.name,bytes=len(packed),sha256=digest(packed),
            text_bytes=len(raw),text_sha256=digest(raw),original_path=str(path),
            original_mode=oct(path.stat().st_mode),original_bytes=len(original),
            original_sha256=digest(original),filtered=was_filtered))
    host_path = CASE/'output-01/host-observations.jsonl'
    original = host_path.read_bytes()
    rows = [filtered(json.loads(line)) for line in original.splitlines()]
    raw = ''.join(json.dumps(row,allow_nan=False)+'\n' for row in rows).encode()
    name = 'host-task-GPU-observations-filtered.jsonl'
    (STAGE/name).write_bytes(raw)
    packed = gzip.compress(raw,mtime=0)
    assert gzip.decompress(packed) == raw
    (DEST/(name+'.gz')).write_bytes(packed)
    entries.append(dict(file=name+'.gz',bytes=len(packed),sha256=digest(packed),
        text_bytes=len(raw),text_sha256=digest(raw),original_path=str(host_path),
        original_bytes=len(original),original_sha256=digest(original),filtered=True))
    result_path = CASE/'output-01/result.json'
    original = result_path.read_bytes()
    result = filtered(json.loads(original))
    raw = (json.dumps(result,indent=2,allow_nan=False)+'\n').encode()
    name = 'wrapper-result-filtered.json'
    (STAGE/name).write_bytes(raw)
    packed = gzip.compress(raw,mtime=0)
    assert gzip.decompress(packed) == raw
    (DEST/(name+'.gz')).write_bytes(packed)
    entries.append(dict(file=name+'.gz',bytes=len(packed),sha256=digest(packed),
        text_bytes=len(raw),text_sha256=digest(raw),original_path=str(result_path),
        original_bytes=len(original),original_sha256=digest(original),filtered=True))
    metrics = json.loads((BASE/'results-01.json').read_text())['cases']['gpu_client_usage']
    manifest = dict(schema=1,source='bb5db7af5490035778f8ba1772e42dbbed0917bd',
        measured_wall_ms=metrics['measured_wall_ms'],service_p99_ms=metrics['observed_nearest_rank_p99_ms'],
        strict_target_ms=4095,native_passed=False,wrapper_passed=False,qualified=False,
        original_failures_retained=True,prior_two_attempts_closed_before_workload=True,
        completed_trace_independently_closed=True,quality='Best',power_ceiling_W=15,
        thermal_guard_unchanged=True,offline_launcher_checks_passed=110,GPU_analysis_checks_passed=5,
        entries=entries,compressed_text_files=len(entries),compressed_bytes=sum(row['bytes'] for row in entries),
        filtering='Recursively remove only process_cpu_read_only.processes; retain omission counts, matched player/runtime tasks, GPU clients, clocks and observer costs.',
        exclusions=['Audio','Models','Binaries','Driver caches','Unrelated process inventories'],
        scope='Instrumented read-only diagnostic; not a timing, sustained, musical, physical-touch or release qualification and not a gate waiver.')
    (DEST/'verification.json').write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:manifest[key] for key in ('compressed_text_files','compressed_bytes','qualified')}))


if __name__ == '__main__':
    main()
