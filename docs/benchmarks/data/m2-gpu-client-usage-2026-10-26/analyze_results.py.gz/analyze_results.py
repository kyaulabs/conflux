"""Derive bounded audio/latency summaries without rewriting failed native verdicts."""
from pathlib import Path
import hashlib
import json
import math
import struct
import numpy as np

ROOT=Path('/home/kyau/projects/kyaulabs/conflux')
BASE=Path(__file__).resolve().parent
CASES={'gpu_client_usage':BASE/'cases/candidate'}


def pin(path):
    raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def audio(path):
    length=path.stat().st_size;digest=hashlib.sha256();maximum=[0.,0.];nonzero=0
    with path.open('rb') as stream:
        header=stream.read(12)
        assert header[:4]==b'RIFF' and header[8:]==b'WAVE'
        assert struct.unpack('<I',header[4:8])[0]+8==length
        geometry=None;data=None
        for _ in range(32):
            chunk=stream.read(8);assert len(chunk)==8
            name,count=struct.unpack('<4sI',chunk);offset=stream.tell()
            assert offset+count<=length
            if name==b'fmt ':
                assert 16<=count<=128
                value=stream.read(count);geometry=struct.unpack('<HHIIHH',value[:16])
                assert geometry==(3,2,48000,384000,8,32)
            if name==b'data':data=(offset,count);break
            stream.seek(offset+count+(count%2))
        assert geometry and data and 0<data[1]<=512*1024**2 and data[1]%8==0
        remaining=data[1]
        while remaining:
            block=stream.read(min(1024**2,remaining));assert block
            remaining-=len(block);values=np.frombuffer(block,dtype='<f4').reshape(-1,2)
            assert np.isfinite(values).all();peaks=np.abs(values).max(axis=0)
            maximum=[max(old,float(new)) for old,new in zip(maximum,peaks)]
            nonzero+=int(np.count_nonzero(values))
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024**2),b''):digest.update(block)
    return dict(path=str(path),bytes=length,sha256=digest.hexdigest(),header_finalized=True,
        frames=data[1]//8,sample_rate=48000,channels=2,all_float_samples_finite=True,
        peak_left=maximum[0],peak_right=maximum[1],nonzero_samples=nonzero)


def summarize(path):
    result_path=path/'output-01/result.json';result=json.loads(result_path.read_text())
    assessment=json.loads((path/'diagnostic-assessment.json').read_text());n=result['native'];o=result['observations']
    values=[row['hop_service_ms'] for row in o['chunk_phases']['hops']]
    assert len(values)==o['service_hops']['count'] and all(math.isfinite(v) and v>=0 for v in values)
    p99=sorted(values)[math.ceil(len(values)*.99)-1];assert p99==o['service_hops']['nearest_rank_p99_ms']
    wav=audio(path/'output-01/master.wav');native_audio=n.get('recorded_audio')
    if native_audio:
        assert all(wav[key]==native_audio[key] for key in ('frames','sample_rate','channels','peak_left','peak_right','nonzero_samples'))
    closed=json.loads((path/'root-finished-01.json').read_text())
    controls=[dict(kind=c['kind'],recovered='recovered_cursor_observed_ns' in c,
        observed_recovery_seconds=(c['recovered_cursor_observed_ns']-c['issued_ns'])/1e9
            if 'recovered_cursor_observed_ns' in c else None) for c in n['controls']]
    telemetry=o['service_telemetry_loss'];snapshots=assessment['configured_power_cap_snapshots']
    cap='/sys/devices/virtual/powercap/intel-rapl-mmio/intel-rapl-mmio:0/constraint_0_power_limit_uw'
    cap_counts={}
    for row in snapshots:
        if row['phase']=='public_host_monitor':
            key=str(row['values'][cap]);cap_counts[key]=cap_counts.get(key,0)+1
    return dict(result=pin(result_path),assessment=pin(path/'diagnostic-assessment.json'),
        original_native_error=n['error'],original_native_passed=n['passed'],
        original_wrapper_passed=result['passed'],original_cleanup_proven=result['cleanup_proven'],
        independently_closed=closed['cleanup_complete'],measured_wall_ms=n['measured_wall_ms'],
        native_full120s=n['measured_wall_ms']>=120000 and n['measurement_intervals_closed'],
        observed_completed_hops=len(values),observed_nearest_rank_p99_ms=p99,
        strict_target_ms=4095,observed_at_or_above_target=sum(v>=4095 for v in values),
        original_observations_service_metrics_complete=o['service_metrics_complete'],
        final_ServiceClosed_observed=bool(telemetry) and telemetry[-1]['kind']=='ServiceClosed',
        dropped_service_events=sum(t['dropped'] for t in telemetry),
        finite_phase_fields={k:dict(count=v['count'],present_for_all_chunks=v['present_for_all_chunks']) for k,v in o['chunk_phases']['fields'].items()},
        manual_controls_complete=n['manual_controls_complete'],
        acknowledged_controls=sum(c.get('acknowledged') is True for c in n['manual_controls']),
        steady_starvation_seconds=n['steady_starved_frames']/48000,
        controlled_starvation_seconds=n['control_starved_frames']/48000,
        recovery_observations=controls,last_recovery_complete=n['last_recovery_complete'],
        observation_counters=n['observation_counters'],UI_coverage=n['ui_coverage'],
        recording_native_final_metadata_present=native_audio is not None,
        recording_native=n.get('recording'),audio=wav,diagnostic_tail=n.get('diagnostic_tail'),
        callback_deadline_misses=n['execution_deadline_misses'],source_read_failures=n['source_read_failures'],
        rejected_commands=n['rejected_commands'],invalid_buffers=n['invalid_buffers'],
        driver_timing=n['timing'],thermal_summary=result['thermal_summary'],
        sampled_MMIO_long_cap_counts_uW=cap_counts,qualified=False,
        scope='Observed complete-hop population; missing ServiceClosed or failed native/ownership/tail gates remain failures. Finite WAV data does not imply gap-free audio. Recovery times are polling observations, not hard GPU preemption or physical latency.')


def main():
    rows={name:summarize(path) for name,path in CASES.items()}
    report=dict(schema=1,cases=rows,strict_target_unchanged_ms=4095,quality='Best',
        power_ceiling_unchanged_W=15,thermal_guard_unchanged=True,
        no_causal_improvement_claim=True,goal_or_release_gate_changed=False,
        all_client_scopes_independently_closed=True,qualification=False,
        analyzer=pin(Path(__file__).resolve()))
    with (BASE/'results-01.json').open('x') as stream:stream.write(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({name:{key:row[key] for key in ('measured_wall_ms','observed_nearest_rank_p99_ms',
        'acknowledged_controls','steady_starvation_seconds','final_ServiceClosed_observed','recording_native_final_metadata_present')} for name,row in rows.items()},indent=2))


if __name__=='__main__':main()
