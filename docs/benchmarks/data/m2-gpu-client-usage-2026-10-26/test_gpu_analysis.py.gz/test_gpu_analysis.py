"""Generated checks for meaningful GPU-counter interpretation failures."""
import unittest

import analyze_gpu_usage as analysis


def sample(timestamp, values, capacity='1'):
    return {'observations': [dict(observed_monotonic_ns=timestamp+index,
        fields={'drm-engine-render': f'{value} ns', 'drm-engine-capacity-render': capacity})
        for index,value in enumerate(values)]}


class CounterChecks(unittest.TestCase):
    def test_duplicate_descriptors_are_not_additive(self):
        points, regressions = analysis.counter_points([
            sample(1, [10,10]), sample(1000000001, [500000010,500000010])], 'render')
        self.assertEqual(analysis.interval(points)['busy_seconds'], .5)
        self.assertEqual(sum(p['duplicate_descriptor_observations'] for p in points), 2)
        self.assertEqual(regressions, 0)

    def test_counter_regressions_retain_high_water_until_caught_up(self):
        points, regressions = analysis.counter_points([
            sample(1,[100]), sample(1000000001,[80]),
            sample(2000000001,[90]), sample(3000000001,[150])], 'render')
        self.assertEqual([p['high_water_ns'] for p in points], [100,100,100,150])
        self.assertEqual(regressions, 2)
        self.assertEqual(analysis.interval(points)['busy_seconds'], 50/1e9)

    def test_missing_counter_is_unknown(self):
        points, _ = analysis.counter_points([
            {'observations': [dict(observed_monotonic_ns=1, fields={})]}], 'render')
        self.assertEqual(points, [])
        self.assertIsNone(analysis.interval(points)['busy_seconds'])

    def test_engine_capacity_and_single_point(self):
        points, _ = analysis.counter_points([
            sample(1,[0],capacity='2'), sample(1000000001,[1000000000],capacity='2')], 'render')
        self.assertEqual(analysis.interval(points)['engine_active_time_ratio'], .5)
        self.assertIsNone(analysis.interval(points[:1])['engine_active_time_ratio'])

    def test_wrong_units_and_zero_capacity_fail(self):
        cases = [dict(observations=[dict(observed_monotonic_ns=1,
            fields={'drm-engine-render':'10 ms'})]), sample(1,[0],capacity='0')]
        for row in cases:
            with self.assertRaises(AssertionError):
                analysis.counter_points([row], 'render')


if __name__ == '__main__':
    unittest.main()
