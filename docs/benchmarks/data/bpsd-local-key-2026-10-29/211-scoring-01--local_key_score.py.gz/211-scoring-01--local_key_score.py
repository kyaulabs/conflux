"""Frozen Decimal overlap scoring for BPSD local keys; no inference or devices."""
from decimal import Decimal, localcontext
import importlib.util
from pathlib import Path

BASE = Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location('bpsd_' + name, BASE / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


overlap = load('decimal_overlap')
geometry = load('reference_geometry')
D = Decimal
STATES = ('Estimated', 'Unknown', 'Ambiguous', 'Failed')


def references(key_text, active_text):
    keys = geometry.parse('ann_audio_localkey', key_text)
    active = geometry.parse('ann_audio_startEnd', active_text)['values'][0]
    spans = [(D(row['start']) * 48000, D(row['end']) * 48000, overlap.key(row['label']))
        for row in keys['values']]
    first, end = D(active['start']) * 48000, D(active['end']) * 48000
    if any(a < first or b > end for a, b, _ in spans):
        raise ValueError('Key reference extends outside the publisher active interval')
    return spans, (first, end), keys['internal_unannotated_gaps']


def empty_value():
    return dict(known=D(0), correct=D(0), top_two=D(0),
        states={state: D(0) for state in STATES}, windows=[], source_maps=0,
        all_source_states={state: D(0) for state in STATES},
        unlabelled_states={state: D(0) for state in STATES})


def failed_value(spans):
    value = empty_value()
    value['known'] = sum((b - a for a, b, _ in spans), D(0))
    value['states']['Failed'] = value['known']
    return value


def checked_windows(windows, frames):
    if type(frames) is not int or not 0 < frames <= 33554432 or not isinstance(windows, list) or not windows:
        raise ValueError('Complete source window population is required')
    expected = 0
    for window in windows:
        a, b = window['first_frame'], window['end_frame']
        if type(a) is not int or type(b) is not int or a != expected or not a < b <= frames:
            raise ValueError('Source windows overlap, leave gaps or change the complete source extent')
        state, candidates = window['status'], window['candidates']
        if state not in ('Estimated', 'Unknown') or not isinstance(candidates, list):
            raise ValueError('Unexpected frozen classifier state')
        if len(candidates) != (1 if state == 'Estimated' else 0):
            raise ValueError('Top-one or Unknown candidate geometry differs')
        for candidate in candidates:
            if (set(candidate) != {'tonic', 'mode'} or type(candidate['tonic']) is not int or
                not 0 <= candidate['tonic'] < 12 or candidate['mode'] not in ('Major', 'Minor')):
                raise ValueError('Invalid exact tonic/mode class')
        expected = b
    if expected != frames:
        raise ValueError('Complete source tail is absent')
    return windows


def score_case(key_text, active_text, frames, windows, capture_failure=None):
    """Never clip references, replace a case, or turn Unknown into an estimate."""
    with localcontext() as context:
        context.prec = 50
        try:
            spans, active, gaps = references(key_text, active_text)
        except (ValueError, KeyError, TypeError) as error:
            return dict(status='ReferenceInvalid', failure=str(error), value=None,
                known_duration_unavailable=True, original_case_retained=True)
        if capture_failure is not None:
            return dict(status='CaptureFailed', failure=capture_failure, value=failed_value(spans),
                original_case_retained=True, unannotated_gaps=gaps)
        try:
            checked_windows(windows, frames)
            if active[1] > frames or any(b > frames for _, b, _ in spans):
                raise ValueError('Publisher reference extends beyond the complete prepared source')
            value = overlap.overlaps(windows, spans)
        except (ValueError, KeyError, TypeError) as error:
            return dict(status='SourceOrReferenceGeometryFailed', failure=str(error),
                value=failed_value(spans), original_case_retained=True, unannotated_gaps=gaps)
        return dict(status='Scored', value=value, original_case_retained=True, unannotated_gaps=gaps)


def combine(scored):
    with localcontext() as context:
        context.prec = 50
        total = empty_value()
        for item in scored:
            value = item['value']
            if value is None:
                continue
            for name in ('known', 'correct', 'top_two', 'source_maps'):
                total[name] += value[name]
            for name in ('states', 'all_source_states', 'unlabelled_states'):
                for state in STATES:
                    total[name][state] += value[name][state]
        return dict(metrics=overlap.ratios(total), case_denominator=len(scored),
            valid_reference_cases=sum(item['value'] is not None for item in scored),
            reference_failures=sum(item['value'] is None for item in scored),
            all_case_reference_durations_available=all(item['value'] is not None for item in scored),
            pooled_scope='Known seconds from all valid references; missing reference durations explicitly unavailable',
            confidence='Unknown', qualified=False)
