"""Check the frozen local-key scorer with generated data on both CPUs."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
SCORING = BASE / 'scoring-01'
spec = importlib.util.spec_from_file_location('bpsd_decode_settings', BASE / 'run_decode_both.py')
settings = importlib.util.module_from_spec(spec)
spec.loader.exec_module(settings)
FILES = {name: (SCORING / name).read_text() for name in (
    'local_key_score.py', 'decimal_overlap.py', 'reference_geometry.py', 'test_local_key_score.py')}


def laptop():
    result = subprocess.run(['/usr/bin/python3.14', '-B', str(SCORING / 'test_local_key_score.py')],
        capture_output=True, text=True, timeout=30)
    (SCORING / 'laptop-checks.stdout.log').write_text(result.stdout)
    (SCORING / 'laptop-checks.stderr.log').write_text(result.stderr)
    assert result.returncode == 0 and 'Ran 8 tests' in result.stderr and result.stderr.rstrip().endswith('OK')
    return dict(exit=result.returncode, generated_checks=8, child_reaped=True)


def apollo():
    code = 'FILES=' + repr(FILES) + '\nIMAGE=' + repr(settings.IMAGE) + '\n' + r'''
from pathlib import Path
import json,subprocess
base=Path('/srv/conflux-tests/work/bpsd-local-key-20261029-01/scoring-checks-01')
assert not base.exists();base.mkdir(mode=0o700)
for name,text in FILES.items():(base/name).write_text(text)
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
name='conflux-bpsd-local-key-score-checks-20261029-01';label='bpsd-local-key-score-checks-20261029-01'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
command=D+['run','--rm','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL',
 '--security-opt=no-new-privileges:true','--user=1000:1000','--memory=128m','--cpus=1','--pids-limit=128',
 '--label','org.kyaulabs.conflux.run='+label,'--tmpfs=/tmp:rw,nosuid,nodev,size=16m,mode=1777',
 '--mount','type=bind,src='+str(base)+',dst=/scoring,readonly',IMAGE,'python','-B','/scoring/test_local_key_score.py']
try:
 r=subprocess.run(command,capture_output=True,text=True,timeout=30)
 (base/'checks.stdout.log').write_text(r.stdout);(base/'checks.stderr.log').write_text(r.stderr)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  c=json.loads(found.stdout)[0];assert c['Image']==IMAGE and c['Config']['Labels']['org.kyaulabs.conflux.run']==label
  subprocess.run(D+['rm','--force',c['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
assert r.returncode==0 and 'Ran 8 tests' in r.stderr and r.stderr.rstrip().endswith('OK'),r.stderr
print(json.dumps(dict(exit=r.returncode,generated_checks=8,container_absent=True,stdout=r.stdout,stderr=r.stderr)))
'''
    result = subprocess.run(settings.SSH + ['python3 -'], input=code, capture_output=True, text=True, timeout=55)
    (SCORING / 'apollo-transport.stderr.log').write_text(result.stderr)
    result.check_returncode()
    return json.loads(result.stdout)


with ThreadPoolExecutor(max_workers=2) as pool:
    left = pool.submit(laptop)
    right = pool.submit(apollo)
    result = dict(laptop=left.result(), apollo=right.result(), submitted_concurrently=True,
        actual_corpus_labels_opened=False, model_or_audio_or_GPU_started=False)
with (SCORING / 'both-checks-01.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({host: result[host]['generated_checks'] for host in ('laptop', 'apollo')}))
