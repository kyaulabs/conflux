"""Archive the complete local-key screen as text, excluding audio and runtimes."""
from pathlib import Path
from decimal import Decimal
import gzip
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
TARGET = BASE / 'keycnn-01'
result = json.loads((BASE / 'scoring-01/results-summary-01.json').read_text())
closed = json.loads((TARGET / 'corpus-closed-before-scoring-01.json').read_text())
assert closed['both_units_retired'] and closed['apollo_container_absent']
assert all(host['receipt']['inferred'] == 8 for host in closed['hosts'].values())
stage = BASE / 'report-stage-01'
assert not stage.exists()
stage.mkdir(mode=0o700)
data, decoded = stage / 'data', stage / 'decoded'
data.mkdir(mode=0o700)
decoded.mkdir(mode=0o700)
candidates = []
excluded = {'media-01', 'native', 'numba-cache', '__pycache__', 'report-stage-01', 'publication-01'}
for path in sorted(BASE.rglob('*')):
    if not path.is_file() or path.is_symlink():
        continue
    relative = path.relative_to(BASE)
    if any(part in excluded for part in relative.parts):
        continue
    if path.suffix in ('.py', '.json', '.log', '.stderr', '.csv', '.cpp', '.hpp') or path.name == 'CMakeLists.txt':
        candidates.append((relative.as_posix(), path))
native = BASE / 'preparation-01/laptop/native'
for path in sorted(native.iterdir()):
    if path.is_file() and path.name in ('compile-commands.txt', 'CMakeCache.txt',
        'build-step-0.stdout.log', 'build-step-0.stderr.log', 'build-step-1.stdout.log',
        'build-step-1.stderr.log', 'protocol-tests.stdout.log', 'protocol-tests.stderr.log'):
        candidates.append((path.relative_to(BASE).as_posix(), path))
audit = ROOT / 'build/m2-bpsd-reference-audit-01'
for name in ('publisher-record-01.json', 'archive-index-01.json'):
    candidates.append(('publisher/' + name, audit / name))
members, aliases, seen = [], [], {}
total = 0
for name, path in sorted(candidates):
    raw = path.read_bytes()
    raw.decode('utf-8')
    assert len(raw) <= 8 * 1024**2
    total += len(raw)
    assert total <= 48 * 1024**2
    digest = hashlib.sha256(raw).hexdigest()
    identity = (len(raw), digest)
    if identity in seen:
        aliases.append(dict(source=name, member=seen[identity], bytes=len(raw), sha256=digest))
        continue
    member = f'{len(members):03d}-' + name.replace('/', '--') + '.gz'
    encoded = gzip.compress(raw, compresslevel=9, mtime=0)
    assert gzip.decompress(encoded) == raw
    (data / member).write_bytes(encoded)
    (decoded / member[:-3]).write_bytes(raw)
    seen[identity] = member
    members.append(dict(source=name, member=member, bytes=len(raw), sha256=digest,
        gzip_bytes=len(encoded), gzip_sha256=hashlib.sha256(encoded).hexdigest()))
manifest = dict(schema=1, members=members, aliases=aliases,
    source_audio_weights_binary_arrays_runtimes_or_generated_bytecode_included=False,
    upstream_numeric_model_source_bytes_redistributed=False,
    original_case_denominator=8, independent_compositions=4, candidate_promoted=False,
    annotations=dict(source='https://zenodo.org/records/18662551', license='CC-BY-3.0',
        creators=['Johannes Zeitler', 'Christof Weiß', 'Vlora Arifi-Müller', 'Meinard Müller'],
        selected_raw_annotation_CSVs_unchanged=True, source_audio_redistributed=False),
    unique_decoded_bytes=sum(row['bytes'] for row in members), total_source_text_bytes=total,
    gzip_bytes=sum(row['gzip_bytes'] for row in members), qualified=False)
(data / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
left, right = result['hosts']['laptop'], result['hosts']['apollo']
assert left['pooled']['metrics'] == right['pooled']['metrics']
def percent(value):
    return f'{Decimal(value) * 100:.2f}%'
rows = '\n'.join('| ' + ' | '.join((case['composition'].removeprefix('Beethoven_'),
    case['performance'], percent(case['metrics']['exact_top_one_full_denominator']))) + ' |'
    for case in left['cases'])
posterior = result['posterior_comparison']
known = Decimal(left['pooled']['metrics']['known_frame_units']) / 48000
report = f'''# Local-key screen on Beethoven performances

The unchanged dense Winterreise Key-CNN matched **{percent(left['pooled']['metrics']['exact_top_one_full_denominator'])} of annotated local-key time** on both hosts. All eight selected performances decoded and completed inference. Individual results ranged from 51.11% to 82.85%; the overall result does not justify enabling automatic key detection. Confidence remains Unknown, the production key backend stays disabled, and M2/M3 and release gates remain open.

| Check | Laptop | Apollo |
| --- | ---: | ---: |
| Complete source and inference cases | 8/8 | 8/8 |
| Exact tonic/mode duration | 66.81% | 66.81% |
| Estimated coverage of annotated duration | 99.99% | 99.99% |
| Source preparation wall time | 182.590 s | 249.578 s |
| CPU capture wall time, including preparation | 586.189 s | 551.918 s |

| Composition | Performance | Exact annotated duration |
| --- | --- | ---: |
{rows}

The [Beethoven Piano Sonata Dataset](https://zenodo.org/records/18662551) supplies time-resolved local-key annotations. Credit: Johannes Zeitler, Christof Weiß, Vlora Arifi-Müller and Meinard Müller; the selected annotation CSVs retain the publisher's CC-BY-3.0 attribution. The [dataset paper](https://doi.org/10.5334/tismir.196) describes the collection. This screen covers four compositions, each in versions AS35 and FG58. Eight performances are not eight independent compositions, and classical piano does not establish accuracy for the requested DJ genres.

Selection was fixed before new audio, labels or predictions were acquired. Composition filenames were ordered by SHA-256 with a recorded seed; the first four eligible works were retained. Eligibility required both fixed versions, matching local-key/active-interval files and an 18 MiB per-source bound. The previously inspected Op. 2 No. 1 pilot was excluded. Op. 109 was retained with the publisher's warning about partly incorrect harmonic/structure measure counts. It was not replaced or removed from the aggregate.

All eight original WAVs were acquired through bounded HTTPS ranges against the published ZIP directory. The admitted files retained their extent, ZIP CRC32 and SHA-256. The full archive MD5 was not computed. Both hosts then prepared each complete uncropped source as stereo 48 kHz float PCM; every frame count and complete PCM hash matched exactly. No source audio is redistributed here.

The checkpoint, legacy CQT, 60-frame centered contexts, boundary padding and hop-8 source partition are unchanged from the [earlier dense screen](independent-keycnn-2026-10-29.md). Each local cell uses its unthresholded top-one tonic/mode. The primary score measures Decimal overlap against all well-formed annotated intervals: {known:.3f} seconds across eight cases. Unknown or failed predictions retain the known-duration denominator; gaps remain unlabelled. No time shift, boundary tolerance, transposition, selected excerpt, setting or confidence threshold was fitted. The scoring algorithm and failure rules were frozen before inference; report execution glue was written after capture launch. This does not establish per-sample musical boundary accuracy or confidence calibration.

Eight generated scoring checks passed per host, covering fractional boundaries, unknown/failed outcomes, unlabelled gaps, invalid references, truncated/overlapping source windows and exact mode/enharmonic classes. Native rejection checks and seven decoder protocol checks passed per host; the existing classifier pipeline passed twenty-three generated protocol/lifecycle checks on each host. Both numerical runtime manifests matched before and after inference. No package or model was installed or changed.

All {posterior['compared_probabilities']:,} compared posterior elements stayed within the inherited `atol=2e-6, rtol=2e-6` descriptive bound; the maximum absolute difference was {posterior['maximum_absolute_difference']:.10g}. All projected local class decisions agree. This numerical agreement does not establish musical accuracy. Training membership remains unverified, and the earlier failed whole-track FMAK screens remain recorded separately.

Both CPU batches, their original cgroups and the private Apollo container were retired before scoring. Anonymous PCM spools were empty. These runs started no player, hardware sound output or GPU and changed no sync service, power policy, thermal rule or Best-quality stem setting. They do not qualify the primary laptop's strict p99 target below 4.095 seconds, hard cancellation or the current-player hour.

The [evidence manifest](data/bpsd-local-key-2026-10-29/manifest.json) binds {len(members)} unique gzip text members and {len(aliases)} byte-identical aliases, including complete predictions, raw selected annotations, frozen scoring code, acquisition/source/runtime pins, checks and owned cleanup. Audio, weights, binary arrays, installed runtimes and generated caches are excluded.
'''
(stage / 'report.md').write_text(report)
(stage / 'verification-01.json').write_text(json.dumps(dict(unique_members=len(members),
    aliases=len(aliases), unique_decoded_bytes=manifest['unique_decoded_bytes'],
    gzip_bytes=manifest['gzip_bytes'], all_gzip_members_reconstructed_exactly=True,
    audio_or_model_or_binary_payload_included=False), indent=2) + '\n')
print(json.dumps(dict(unique_members=len(members), aliases=len(aliases),
    decoded_bytes=manifest['unique_decoded_bytes'], gzip_bytes=manifest['gzip_bytes'])))
