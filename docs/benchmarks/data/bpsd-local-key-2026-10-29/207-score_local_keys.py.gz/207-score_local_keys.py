"""Report the frozen local-key overlap after both CPU capture owners retire."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
TARGET = BASE / 'keycnn-01'
SCORING = BASE / 'scoring-01'


def pin(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def verified(row):
    path = Path(row['path'])
    assert pin(path) == {key: row[key] for key in ('path', 'bytes', 'sha256')}
    return path.read_bytes()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--score', action='store_true')
    args = parser.parse_args()
    contract_path = SCORING / 'scoring-contract-01.json'
    contract = json.loads(contract_path.read_text())
    for row in contract['files']:
        verified(row)
    if not args.score:
        print(json.dumps(dict(unarmed=True, scoring_contract_verified=True,
            references_opened=False, starts_no_workload=True)))
        return
    closed_path = TARGET / 'corpus-closed-before-scoring-01.json'
    closed = json.loads(closed_path.read_text())
    assert closed['both_units_retired'] and closed['apollo_container_absent']
    assert closed['reference_labels_opened'] is False
    score = module('bpsd_frozen_scoring', SCORING / 'local_key_score.py')
    protocol = module('bpsd_frozen_capture_protocol', TARGET / 'laptop/protocol.py')
    admission = json.loads(verified(contract['source_admission']))
    sources = admission['sources']
    assert admission['fixed_denominator'] == len(sources) == 8
    expected_ids = [case['id'] for case in sources]
    assert len(set(expected_ids)) == 8 and len({case['composition'] for case in sources}) == 4
    hosts, validated_predictions = {}, {}
    for host, folder, plan_path in (
        ('laptop', TARGET / 'laptop', TARGET / 'laptop/music-plan-01.json'),
        ('apollo', TARGET / 'apollo-collected-01', TARGET / 'apollo-collected-01/operations/music-plan-01.json')):
        plan = json.loads(plan_path.read_text())
        assert [case['id'] for case in plan['cases']] == expected_ids
        output = folder / 'output-01'
        raw = (output / 'predictions-before-scoring.json').read_bytes()
        receipt = json.loads((output / 'prediction-receipt.json').read_text())
        assert hashlib.sha256(raw).hexdigest() == receipt['closed_capture_sha256'] == closed['hosts'][host]['capture_sha256']
        assert receipt['fixed_denominator'] == receipt['completed_captures'] == 8
        assert receipt['input_pins_unchanged'] and receipt['reference_labels_opened'] is False
        assert not receipt['PCM_persisted'] and not receipt['spool_artifacts']
        captures = json.loads(raw)
        assert [row['id'] for row in captures] == expected_ids
        rows, values, predictions = [], [], {}
        for source, case, capture in zip(sources, plan['cases'], captures, strict=True):
            identifier = source['id']
            assert capture == json.loads((output / (identifier + '-capture.json')).read_text())
            assert all(case['source'][key] == source['source'][key] for key in ('bytes', 'sha256'))
            key_text = verified(source['references']['ann_audio_localkey']).decode('utf-8-sig')
            active_text = verified(source['references']['ann_audio_startEnd']).decode('utf-8-sig')
            failure, prediction, windows = None, None, None
            if capture['status'] != 'PredictionCaptured' or not capture['complete']:
                failure = dict(capture_status=capture['status'], retained_error=capture.get('error'))
            else:
                try:
                    prediction_file = output / (identifier + '-prediction.json')
                    raw_prediction = prediction_file.read_bytes()
                    assert len(raw_prediction) <= 524288
                    assert hashlib.sha256(raw_prediction).hexdigest() == capture['prediction_sha256']
                    prediction = json.loads(raw_prediction)
                    metadata = json.loads((output / (identifier + '-source.json')).read_text())
                    windows = protocol.validate_prediction(prediction, metadata, case)
                    predictions[identifier] = prediction
                except (OSError, ValueError, KeyError, TypeError, AssertionError) as error:
                    failure = dict(capture_status='CaptureValidationFailed', error=str(error)[:1200])
            item = score.score_case(key_text, active_text, case.get('prepared_frames'), windows, failure)
            values.append(item)
            row = dict(id=identifier, composition=source['composition'], performance=source['performance'],
                capture_status=capture['status'], status=item['status'], failure=item.get('failure'),
                publisher_notes=source['known_publisher_reference_notes'],
                reference_pins=source['references'], confidence='Unknown', qualified=False)
            if item['value'] is not None:
                row['metrics'] = score.overlap.ratios(item['value'])
                row['window_overlaps'] = item['value']['windows']
                row['unannotated_gaps'] = item.get('unannotated_gaps', [])
            else:
                row['metrics'] = None
                row['known_reference_duration_unavailable'] = True
            rows.append(row)
        groups = {}
        for composition in sorted({source['composition'] for source in sources}):
            group = [value for source, value in zip(sources, values, strict=True) if source['composition'] == composition]
            groups[composition] = score.combine(group)
        hosts[host] = dict(cases=rows, pooled=score.combine(values), by_composition=groups,
            exact_global_accuracy_is_not_the_local_key_metric=True,
            captures=pin(output / 'predictions-before-scoring.json'), recipe=plan['recipe'])
        validated_predictions[host] = predictions
    posterior = dict(fixed_case_denominator=8, compared_cases=[], missing_or_invalid_cases=[],
        maximum_absolute_difference=0., outside_inherited_tolerance=0,
        compared_probabilities=0, projected_top_one_window_differences=0,
        atol=2e-6, rtol=2e-6, descriptive_only=True)
    for identifier in expected_ids:
        left = validated_predictions['laptop'].get(identifier)
        right = validated_predictions['apollo'].get(identifier)
        if left is None or right is None:
            posterior['missing_or_invalid_cases'].append(identifier)
            continue
        assert left['frames'] == right['frames'] and left['pcm_sha256'] == right['pcm_sha256']
        assert len(left['raw_predictions']) == len(right['raw_predictions'])
        for a, b in zip(left['raw_predictions'], right['raw_predictions'], strict=True):
            assert a['index'] == b['index'] and a['signal_nonzero'] == b['signal_nonzero']
            for x, y in zip(a['probabilities'], b['probabilities'], strict=True):
                difference = abs(x - y)
                posterior['compared_probabilities'] += 1
                posterior['maximum_absolute_difference'] = max(posterior['maximum_absolute_difference'], difference)
                posterior['outside_inherited_tolerance'] += difference > 2e-6 + 2e-6 * abs(y)
        assert len(left['windows']) == len(right['windows'])
        posterior['projected_top_one_window_differences'] += sum(a != b for a, b in zip(left['windows'], right['windows'], strict=True))
        posterior['compared_cases'].append(identifier)
    result = dict(schema=1, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
        scope='Eight performances of four Beethoven compositions; local-key diagnostic, no genre-wide qualification',
        fixed_case_denominator=8, independent_compositions=4, performances_per_composition=2,
        primary='Exact tonic/mode duration over all well-formed known reference seconds',
        scoring_contract=pin(contract_path), score_execution_glue=pin(Path(__file__)),
        score_execution_glue_written_after_capture_launch=True,
        overlap_algorithm_and_failure_rules_frozen_before_capture=True,
        corpus_owners_closed_before_scoring=pin(closed_path), hosts=hosts, posterior_comparison=posterior,
        prior_FMAK_global_failures_retained=True, training_independence_established=False,
        confidence='Unknown', thresholds_or_calibration_fitted=False,
        production_key_backend_enabled=False, musical_acceptance_or_latency_qualified=False,
        M2_complete=False, M3_complete=False, release_qualified=False)
    encoded = (json.dumps(result, indent=2, allow_nan=False) + '\n').encode()
    assert len(encoded) <= 4 * 1024**2
    with (SCORING / 'results-summary-01.json').open('xb') as stream:
        stream.write(encoded)
    print(json.dumps(dict(hosts={host: row['pooled'] for host, row in hosts.items()},
        maximum_posterior_difference=posterior['maximum_absolute_difference'],
        posterior_values_outside_tolerance=posterior['outside_inherited_tolerance'], qualified=False)))


if __name__ == '__main__':
    main()
