"""Stage fixed source bytes and decode-only operations; no references or models."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess

BASE=Path(__file__).resolve().parent
PREP=BASE/'preparation-01'
REMOTE='/srv/conflux-tests/work/bpsd-local-key-20261029-01'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
 '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
 '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']
SCP=['scp','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no',
 '-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
 '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-P','4222']
def pin(path):
    assert path.is_file()and not path.is_symlink()
    with path.open('rb')as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(bytes=path.stat().st_size,sha256=sha)
entries=[]
for path in sorted((PREP/'apollo').rglob('*')):
    if path.is_file():
        entries.append(dict(relative='preparation/'+str(path.relative_to(PREP/'apollo')),**pin(path)))
admission=json.loads((BASE/'source-admission-01.json').read_text())
assert admission['complete']
for case in admission['sources']:
    source=case['source'];path=Path(source['path'])
    assert pin(path)=={k:source[k]for k in ('bytes','sha256')}
    entries.append(dict(relative='media/'+path.name,**pin(path)))
assert len([e for e in entries if e['relative'].endswith('.wav')])==8
assert not any('reference' in e['relative']for e in entries)
spec=dict(schema=1,root=REMOTE,files=entries,source_bytes=sum(e['bytes']for e in entries),
          reference_labels_excluded=True,model_started=False)
with(PREP/'transfer-spec-01.json').open('x')as output:output.write(json.dumps(spec,indent=2)+'\n')
def ssh(code,timeout=30):
    return subprocess.check_output(SSH+['python3 -'],input=code.encode(),timeout=timeout).decode()
print(ssh('from pathlib import Path\nimport shutil\np=Path('+repr(REMOTE)+');assert not p.exists();assert shutil.disk_usage(p.parent).free>2*1024**3\np.mkdir(mode=0o700)\n(p/"preparation").mkdir(mode=0o700)\n(p/"media").mkdir(mode=0o700)\nprint("Created only the new CONFLUX source-preparation root")'),flush=True)
def copy(command,name):
    with(PREP/(name+'.stdout.log')).open('x')as out,(PREP/(name+'.stderr.log')).open('x')as err:
        child=subprocess.Popen(command,stdout=out,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True)
        try:
            code=child.wait(timeout=180)
        finally:
            if child.poll()is None:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
    assert code==0,(name,code)
copy(SCP+['-r',str(PREP/'apollo/source'),str(PREP/'apollo/operations'),
          'kyau@apollo.kyaulabs:'+REMOTE+'/preparation/'],'source-transfer')
copy(SCP+[str(Path(case['source']['path']))for case in admission['sources']]+
          ['kyau@apollo.kyaulabs:'+REMOTE+'/media/'],'media-transfer')
check='SPEC='+repr(spec)+'\n'+r'''
from pathlib import Path
import hashlib,json
base=Path(SPEC['root']);seen=[]
for row in SPEC['files']:
 relative=Path(row['relative']);assert not relative.is_absolute()and '..'not in relative.parts
 path=base/relative;assert path.is_file()and not path.is_symlink()and path.stat().st_size==row['bytes']
 with path.open('rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
 seen.append(row['relative'])
actual=sorted(str(path.relative_to(base))for directory in(base/'preparation',base/'media')for path in directory.rglob('*')if path.is_file())
assert actual==sorted(seen)
result=dict(all_hashes_verified=True,files=len(seen),reference_labels_excluded=True,decode_started=False,model_started=False)
with(base/'input-transfer-complete.json').open('x')as output:output.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
'''
closed=json.loads(ssh(check,60))
with(PREP/'apollo-staging-complete-01.json').open('x')as output:output.write(json.dumps(closed,indent=2)+'\n')
print(json.dumps(closed),flush=True)
