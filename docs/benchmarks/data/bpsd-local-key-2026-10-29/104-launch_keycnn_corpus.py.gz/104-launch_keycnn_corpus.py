"""Launch frozen CPU-only full-track classification on both hosts."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
import time
from prepare_keycnn import TARGET,pin,save
from stage_keycnn_runtime import REMOTE,SSH


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--launch',action='store_true');args=parser.parse_args()
    staged=json.loads((TARGET/'corpus-staged-01.json').read_text())
    assert staged['local_protocol_exit']==staged['apollo']['exit']==0 and staged['tests_per_host']==23
    for key in('local_plan','prospective','asset_manifest'):assert pin(Path(staged[key]['path']))==staged[key]
    plan=json.loads((TARGET/'laptop/music-plan-01.json').read_text())
    for row in plan['input_pins']:assert pin(Path(row['path']))=={key:row[key]for key in('path','bytes','sha256')}
    assert not(TARGET/'corpus-reservation-01.json').exists()
    if not args.launch:
        print(json.dumps(dict(unarmed=True,input_pins_verified=True,music_started=False)));return
    local=TARGET/'laptop';output=local/'output-01';assert not output.exists();output.mkdir(mode=0o700)
    for name in('unit.stdout.log','unit.stderr.log'):(local/name).touch(mode=0o600,exist_ok=False)
    entry='BASE='+repr(str(local))+'\n'+r'''
from pathlib import Path
import json,os
base=Path(BASE)
(base/'entry-binding.json').write_text(json.dumps(dict(pid=os.getpid(),invocation=os.environ['INVOCATION_ID'],cgroup=Path('/proc/self/cgroup').read_text().strip()),indent=2)+chr(10))
os.execv('/usr/bin/python3.14',['python3.14','-B',str(base/'run_corpus.py'),'--owned','--plan',str(base/'music-plan-01.json'),'--output',str(base/'output-01')])
'''
    (local/'entry.py').write_text(entry)
    state=subprocess.check_output(['systemctl','--user','show',plan['unit'],'--property=LoadState,MainPID'],text=True,timeout=5)
    assert'LoadState=not-found'in state and'MainPID=0'in state
    start=time.monotonic()
    save(TARGET/'corpus-reservation-01.json',dict(utc=datetime.now(timezone.utc).isoformat(),
        started_monotonic=start,deadline_monotonic=start+1520,no_retry=True,
        scope='Goal-authorized CPU correctness only; no GPU, sound output, client, power writes, sync pause or physical qualification'))
    local_command=['systemd-run','--user','--unit='+plan['unit'],'--property=Type=exec',
        '--property=RemainAfterExit=yes','--property=Restart=no','--property=KillMode=control-group',
        '--property=RuntimeMaxSec=1460s','--property=TimeoutStopSec=20s','--property=OOMPolicy=kill',
        '--property=MemoryMax=3G','--property=CPUQuota=100%','--property=TasksMax=128',
        '--property=Nice=19','--property=UMask=0077',
        '--property=StandardOutput=append:'+str(local/'unit.stdout.log'),
        '--property=StandardError=append:'+str(local/'unit.stderr.log'),'/usr/bin/python3.14','-B',str(local/'entry.py')]
    remote='BASE='+repr(REMOTE)+'\n'+r'''
from pathlib import Path
import json,subprocess
base=Path(BASE);folder=base/'corpus-01';plan=json.loads((folder/'operations/music-plan-01.json').read_text());unit=plan['unit']
check=json.loads((folder/'protocol-receipt-01.json').read_text())
assert check['exit']==0 and check['container_absent']and check['plan']==plan
assert not(folder/'owner.py').exists()and not any((folder/'output-01').iterdir())
state=subprocess.check_output(['systemctl','show',unit,'--property=LoadState,MainPID'],text=True,timeout=5)
assert'LoadState=not-found'in state and'MainPID=0'in state
owner=r"""
from pathlib import Path
import json,os,signal,subprocess,time
base=Path(BASE);folder=base/'corpus-01'
(folder/'entry-binding.json').write_text(json.dumps(dict(pid=os.getpid(),invocation=os.environ['INVOCATION_ID'],cgroup=Path('/proc/self/cgroup').read_text().strip()),indent=2)+chr(10))
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
image='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
name='conflux-bpsd-keycnn-corpus-20261029-01';label='bpsd-keycnn-corpus-20261029-01'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
def interrupted(number,frame):raise InterruptedError('Owned CPU music capture stopped')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
decode=Path('/srv/conflux-tests/work/bpsd-local-key-20261029-01/preparation')
assets=json.loads((folder/'operations/asset-manifest.json').read_text())['container_asset_root']
command=D+['run','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL',
 '--security-opt=no-new-privileges:true','--user=1000:1000','--memory=3g','--cpus=1','--pids-limit=128',
 '--env','CONFLUX_PRIVATE_KEYCNN=1','--env','PYTHONDONTWRITEBYTECODE=1',
 '--label','org.kyaulabs.conflux.run='+label,'--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777',
 '--mount','type=bind,src='+'/srv/conflux-tests/work/fmak-independent-keycnn-20261029-01/assets'+',dst='+assets+',readonly',
 '--mount','type=bind,src='+str(folder/'operations')+',dst=/operations,readonly',
 '--mount','type=bind,src='+str(folder/'output-01')+',dst=/operations/output-01',
 '--mount','type=bind,src='+str(decode.parent/'media')+',dst=/media,readonly',
 '--mount','type=bind,src='+str(decode/'native/prepare-independent-source')+',dst=/prepare/prepare-independent-source,readonly',
 image,'python','-B','/operations/run_corpus.py','--owned','--plan','/operations/music-plan-01.json','--output','/operations/output-01']
first=time.monotonic();result=None;error=None
try:result=subprocess.run(command,timeout=1420)
except BaseException as exception:error=dict(type=type(exception).__name__,message=str(exception)[:1000])
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  value=json.loads(found.stdout)[0]
  assert value['Image']==image and value['Config']['Labels']['org.kyaulabs.conflux.run']==label
  subprocess.run(D+['rm','--force',value['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
 (folder/'container-closed.json').write_text(json.dumps(dict(container_absent=True,exit=None if result is None else result.returncode,error=error,elapsed_seconds=time.monotonic()-first),indent=2)+chr(10))
raise SystemExit(0 if result is not None and result.returncode==0 and error is None else 1)
"""
path=folder/'owner.py';path.write_text('BASE='+repr(BASE)+'\n'+owner);compile(path.read_text(),'fixed-keycnn-owner','exec')
command=['sudo','-n','systemd-run','--unit='+unit,'--uid=1000','--gid=1000',
 '--property=Type=exec','--property=RemainAfterExit=yes','--property=Restart=no',
 '--property=KillMode=control-group','--property=RuntimeMaxSec=1460s','--property=TimeoutStopSec=20s',
 '--property=MemoryMax=4G','--property=TasksMax=256','--property=Nice=19','--property=UMask=0077',
 '--property=StandardOutput=append:'+str(folder/'unit.stdout.log'),
 '--property=StandardError=append:'+str(folder/'unit.stderr.log'),'/usr/bin/python3','-B',str(path)]
r=subprocess.run(command,capture_output=True,text=True,timeout=15)
(folder/'dispatch.json').write_text(json.dumps(dict(command=command,exit=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2)+chr(10))
print(json.dumps(dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)));r.check_returncode()
'''
    compile(remote,'fixed-keycnn-dispatch','exec')
    def dispatch(host,command,data=None):
        r=subprocess.run(command,input=data,capture_output=True,text=True,timeout=30)
        result=dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
        save(TARGET/('corpus-'+host+'-dispatch-01.json'),result);return result
    with ThreadPoolExecutor(max_workers=2)as pool:
        left=pool.submit(dispatch,'laptop',local_command);right=pool.submit(dispatch,'apollo',SSH+['python3 -'],remote)
        results=dict(laptop=left.result(),apollo=right.result())
    save(TARGET/'corpus-dispatched-01.json',dict(hosts=results,concurrent=True,physical_readiness_consumed=False))
    print(json.dumps(dict(dispatched={host:row['exit']for host,row in results.items()},CPU_correctness_only=True)))
    assert all(row['exit']==0 for row in results.values())


if __name__=='__main__':main()
