"""Observe existing decode jobs, retain every outcome, and retire exact owners."""
import base64
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import time

BASE=Path(__file__).resolve().parent
PREP=BASE/'preparation-01'
spec=importlib.util.spec_from_file_location('owned_decode_launch',BASE/'run_decode_both.py')
launch=importlib.util.module_from_spec(spec);spec.loader.exec_module(launch)
reservation=json.loads((PREP/'decode-reservation-01.json').read_text())
dispatched=json.loads((PREP/'decode-dispatched-01.json').read_text())
local_dispatch=dispatched['hosts']['laptop']
remote_dispatch=json.loads(dispatched['hosts']['apollo']['stdout'])
local_inv=re.search('invocation ID: ([0-9a-f]{32})',local_dispatch['stderr']).group(1)
remote_inv=re.search('invocation ID: ([0-9a-f]{32})',remote_dispatch['stderr']).group(1)


def save(path,value):
    with path.open('x')as stream:stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def local_snapshot():
    state=launch.show(launch.LOCAL_UNIT)
    assert state['InvocationID']==local_inv
    root=PREP/'laptop/decode-results'
    result=root/'preparation.json'
    return dict(state=state,receipts=len(list(root.glob('*.receipt.json'))),
        result=json.loads(result.read_text())if result.exists()else None)


def remote_snapshot():
    code='BASE='+repr(launch.REMOTE)+'\nUNIT='+repr(launch.REMOTE_UNIT)+'\nINVOCATION='+repr(remote_inv)+'\n'+r'''
from pathlib import Path
import json,subprocess
base=Path(BASE)
raw=subprocess.check_output(['systemctl','show',UNIT,'--property=LoadState,MainPID,InvocationID,ControlGroup,ActiveState,SubState,Result,ExecMainStatus'],text=True,timeout=5)
state=dict(line.split('=',1)for line in raw.splitlines()if '='in line)
assert state['InvocationID']==INVOCATION
root=base/'decode-results/cases';path=root/'preparation.json'
print(json.dumps(dict(state=state,receipts=len(list(root.glob('*.receipt.json'))),result=json.loads(path.read_text())if path.exists()else None)))
'''
    result=subprocess.run(launch.SSH+['python3 -'],input=code,capture_output=True,text=True,timeout=15)
    result.check_returncode()
    return json.loads(result.stdout)


last=None
sequence=0
group=json.loads((PREP/'decode-owner-bindings-01.json').read_text())['laptop']['ControlGroup']
while True:
    try:
        snapshots=dict(laptop=local_snapshot(),apollo=remote_snapshot())
    except subprocess.SubprocessError as error:
        sequence+=1
        save(PREP/f'decode-observation-{sequence:03d}.json',dict(query_error=str(error),terminal_not_inferred=True))
        if time.monotonic()>reservation['deadline_monotonic']:
            raise
        time.sleep(10)
        continue
    group=group or snapshots['laptop']['state'].get('ControlGroup')
    compact={host:dict(state=value['state'],receipts=value['receipts'],result_present=value['result']is not None)
        for host,value in snapshots.items()}
    if compact!=last:
        sequence+=1
        save(PREP/f'decode-observation-{sequence:03d}.json',dict(observed_at_utc=datetime.now(timezone.utc).isoformat(),hosts=snapshots))
        print(json.dumps(compact),flush=True)
        last=compact
    if all(value['state']['MainPID']=='0'for value in snapshots.values()):
        break
    if time.monotonic()>reservation['deadline_monotonic']:
        raise TimeoutError('Decode owner remains live; inspect this exact job, never restart from an observation timeout')
    time.sleep(10)

local_retired=launch.retire_local(local_inv,group)
save(PREP/'laptop/decode-unit-closed-01.json',local_retired)

code='BASE='+repr(launch.REMOTE)+'\nUNIT='+repr(launch.REMOTE_UNIT)+'\nINVOCATION='+repr(remote_inv)+'\nIMAGE='+repr(launch.IMAGE)+'\nOWNED_GROUP='+repr(json.loads((PREP/'decode-owner-bindings-01.json').read_text())['apollo']['ControlGroup'])+'\n'+r'''
from pathlib import Path
import base64,hashlib,json,re,subprocess
base=Path(BASE)
def show():
 raw=subprocess.check_output(['systemctl','show',UNIT,'--property=LoadState,MainPID,InvocationID,ControlGroup,ActiveState,SubState,Result,ExecMainStatus'],text=True,timeout=5)
 return dict(line.split('=',1)for line in raw.splitlines()if '='in line)
before=show();assert before['InvocationID']==INVOCATION and before['MainPID']=='0'
group=OWNED_GROUP
subprocess.run(['sudo','-n','systemctl','stop',UNIT],check=True,capture_output=True,timeout=25)
after=show()
if after['LoadState']!='not-found':
 assert after['MainPID']=='0'
 subprocess.run(['sudo','-n','systemctl','reset-failed',UNIT],check=True,capture_output=True,timeout=5)
 after=show()
assert after['LoadState']=='not-found'and after['MainPID']=='0'
if group:
 cgroup=Path('/sys/fs/cgroup'+group)
 assert not cgroup.exists()or not any(path.read_text().strip()for path in cgroup.rglob('cgroup.procs'))
D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
name='conflux-bpsd-decode-20261029-01';forced=False
found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
if found.returncode==0:
 container=json.loads(found.stdout)[0]
 assert container['Image']==IMAGE and container['Config']['Labels']['org.kyaulabs.conflux.run']=='bpsd-decode-20261029-01'
 subprocess.run(D+['rm','--force',container['Id']],capture_output=True,check=True,timeout=10);forced=True
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
artifacts=[str(path.relative_to(base))for path in (base/'decode-results/cases').glob('spool-*')if path.is_dir()for path in path.rglob('*')if path.is_file()or path.is_symlink()]
retired=dict(unit=UNIT,invocation=INVOCATION,before_stop=before,after_stop=after,cgroup_absent_or_empty=True,container_absent=True,forced_container_cleanup=forced,spool_artifacts=artifacts)
(base/'decode-unit-closed-01.json').write_text(json.dumps(retired,indent=2)+chr(10))
paths=[base/'decode-unit-closed-01.json',base/'execution/execution-plan.json']
for name in ('decode-container-closed-01.json',):
 if (base/name).is_file():paths.append(base/name)
for path in (base/'decode-results').rglob('*'):
 if not path.is_file()or path.is_symlink():continue
 rel=path.relative_to(base/'decode-results')
 if len(rel.parts)==1 and str(rel)in('protocol-tests.stdout.log','protocol-tests.stderr.log'):paths.append(path)
 elif rel.parent==Path('cases')and (rel.name=='preparation.json'or re.fullmatch(r'[0-9]{6}\.(?:stdout\.json|stderr\.log|receipt\.json)',rel.name)):paths.append(path)
total=sum(path.stat().st_size for path in paths);assert total<2*1024**2
files=[]
for path in paths:
 raw=path.read_bytes();assert len(raw)<128*1024
 files.append(dict(file=str(path.relative_to(base)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),raw_base64=base64.b64encode(raw).decode()))
print(json.dumps(dict(retired=retired,files=files)))
'''
remote=subprocess.run(launch.SSH+['python3 -'],input=code,capture_output=True,text=True,timeout=60)
(PREP/'decode-remote-collect.stderr.log').write_text(remote.stderr)
remote.check_returncode()
collected=json.loads(remote.stdout)
destination=PREP/'apollo-collected-01';destination.mkdir(mode=0o700)
for row in collected['files']:
    path=Path(row['file']);assert not path.is_absolute()and '..'not in path.parts
    raw=base64.b64decode(row['raw_base64'],validate=True)
    assert len(raw)==row['bytes']and hashlib.sha256(raw).hexdigest()==row['sha256']
    target=destination/path;target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    target.write_bytes(raw)
save(PREP/'apollo-collected-manifest-01.json',dict(retired=collected['retired'],
    files=[{key:value for key,value in row.items()if key!='raw_base64'}for row in collected['files']]))
local=snapshots['laptop']['result'];apollo=snapshots['apollo']['result']
assert local is not None and apollo is not None
assert len(local['cases'])==len(apollo['cases'])==8
matches=[];mismatches=[];failures=[]
for left,right in zip(local['cases'],apollo['cases'],strict=True):
    assert left['id']==right['id']
    if left['status']==right['status']=='PreparedMetadataMeasured':
        if left['prepared_frames']==right['prepared_frames']and left['pcm_sha256']==right['pcm_sha256']:
            matches.append(left['id'])
        else:mismatches.append(dict(id=left['id'],laptop=left,apollo=right))
    else:failures.append(dict(id=left['id'],laptop=left,apollo=right))
local_spools=[str(path.relative_to(PREP/'laptop/decode-results'))for directory in (PREP/'laptop/decode-results').glob('spool-*')
    if directory.is_dir()for path in directory.rglob('*')if path.is_file()or path.is_symlink()]
summary=dict(schema=1,hosts={host:dict(prepared=sum(row['status']=='PreparedMetadataMeasured'for row in value['cases']),
    complete_case_receipts=len(value['cases']),all_sources_prepared=value['all_sources_prepared'],
    input_pins_unchanged=value['input_pins_unchanged'],PCM_persisted=value['PCM_persisted'],elapsed_seconds=value['elapsed_seconds'])
    for host,value in [('laptop',local),('apollo',apollo)]},
    fixed_denominator=8,exact_frame_and_PCM_matches=matches,mismatches=mismatches,source_failures_retained=failures,
    local_spool_artifacts=local_spools,apollo_spool_artifacts=collected['retired']['spool_artifacts'],
    both_units_retired=True,apollo_container_absent=True,model_inference_started=False,
    audio_output_started=False,physical_readiness_consumed=False,qualified=False)
save(PREP/'decode-comparison-01.json',summary)
print(json.dumps(dict(hosts=summary['hosts'],exact_frame_and_PCM_matches=len(matches),mismatches=len(mismatches),
    source_failures=len(failures),both_units_retired=True,model_inference_started=False,qualified=False)),flush=True)
