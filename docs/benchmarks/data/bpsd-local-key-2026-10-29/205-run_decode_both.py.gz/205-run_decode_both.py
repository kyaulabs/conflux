"""Run the fixed CPU-only decode corpus on both hosts and prove owned cleanup."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

BASE=Path(__file__).resolve().parent
PREP=BASE/'preparation-01'
REMOTE='/srv/conflux-tests/work/bpsd-local-key-20261029-01/preparation'
LOCAL_UNIT='conflux-bpsd-decode-laptop-20261029-01.service'
REMOTE_UNIT='conflux-bpsd-decode-apollo-20261029-01.service'
IMAGE='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
    '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
    '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']


def pin(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest)


def save(path,value):
    with path.open('x')as stream:stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n')


def show(unit):
    raw=subprocess.check_output(['systemctl','--user','show',unit,
        '--property=LoadState,MainPID,InvocationID,ControlGroup,ActiveState,SubState,Result,ExecMainStatus'],text=True,timeout=5)
    return dict(line.split('=',1)for line in raw.splitlines()if '='in line)


def retire_local(invocation,group):
    state=show(LOCAL_UNIT)
    assert state['InvocationID']==invocation
    subprocess.run(['systemctl','--user','stop',LOCAL_UNIT],check=True,capture_output=True,text=True,timeout=20)
    after=show(LOCAL_UNIT)
    if after['LoadState']!='not-found':
        assert after['MainPID']=='0'
        subprocess.run(['systemctl','--user','reset-failed',LOCAL_UNIT],check=True,capture_output=True,text=True,timeout=5)
        after=show(LOCAL_UNIT)
    assert after['LoadState']=='not-found'and after['MainPID']=='0'
    if group:
        cgroup=Path('/sys/fs/cgroup'+group)
        assert not cgroup.exists()or not any(path.read_text().strip()for path in cgroup.rglob('cgroup.procs'))
    return dict(unit=LOCAL_UNIT,invocation=invocation,before_stop=state,after_stop=after,cgroup_absent_or_empty=True)


def remote_setup(files):
    header='BASE='+repr(REMOTE)+'\nUNIT='+repr(REMOTE_UNIT)+'\nIMAGE='+repr(IMAGE)+'\nFILES='+repr(files)+'\n'
    return header+r'''
from pathlib import Path
import hashlib,json
base=Path(BASE);execution=base/'execution';assert not execution.exists();execution.mkdir(mode=0o700)
for name,text in FILES.items():(execution/name).write_text(text)
def pin(path,container_path):
 with path.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 return dict(path=container_path,bytes=path.stat().st_size,sha256=digest)
plan=json.loads((base/'operations/plan.json').read_text())
build=json.loads((base/'native/build-receipt-01.json').read_text());assert build['passed']and build['source_decoded']is False
binary=pin(base/'native/prepare-independent-source','/prepare/prepare-independent-source')
assert binary['bytes']==build['binary']['bytes']and binary['sha256']==build['binary']['sha256']
plan.update(status='frozen_decode_execution',unit=UNIT,binary=binary,physical_readiness_required=False)
plan['input_pins']=[binary]+[pin(execution/name,'/operations/'+name)for name in FILES]+[case['source']for case in plan['cases']]
(execution/'execution-plan.json').write_text(json.dumps(plan,indent=2)+chr(10))
owner=r"""
from pathlib import Path
import json,signal,subprocess,time
base=Path(BASE);D=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker','--host','unix:///srv/conflux-tests/daemon/docker.sock']
assert json.loads(subprocess.check_output(D+['info','--format','{{json .DockerRootDir}}']))=='/srv/conflux-tests/docker-data'
name='conflux-bpsd-decode-20261029-01'
assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
def interrupted(number,frame):raise InterruptedError('Owned decode service stopped')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
inside=("import os,subprocess\n"
 "r=subprocess.run(['python','-B','/operations/test_decode_cases.py'],capture_output=True,text=True,timeout=15)\n"
 "open('/output/protocol-tests.stdout.log','w').write(r.stdout)\n"
 "open('/output/protocol-tests.stderr.log','w').write(r.stderr)\n"
 "assert r.returncode==0 and 'Ran 7 tests'in r.stderr and r.stderr.rstrip().endswith('OK')\n"
 "os.execv('/usr/bin/python3',['python3','-B','/operations/decode_cases.py','--owned','--plan','/operations/execution-plan.json','--output','/output/cases'])\n")
command=D+['run','--name',name,'--runtime=runc','--init','--network=none','--read-only','--cap-drop=ALL',
 '--security-opt=no-new-privileges:true','--user=1000:1000','--memory=1g','--cpus=1','--pids-limit=128',
 '--tmpfs=/tmp:rw,nosuid,nodev,size=64m,mode=1777','--env','CONFLUX_PRIVATE_DECODE=1',
 '--label','org.kyaulabs.conflux.run=bpsd-decode-20261029-01',
 '--mount','type=bind,src='+str(base/'execution')+',dst=/operations,readonly',
 '--mount','type=bind,src='+str(base.parent/'media')+',dst=/media,readonly',
 '--mount','type=bind,src='+str(base/'native')+',dst=/prepare,readonly',
 '--mount','type=bind,src='+str(base/'decode-results')+',dst=/output',IMAGE,'python','-c',inside]
first=time.monotonic();result=None
try:result=subprocess.run(command,timeout=630)
finally:
 found=subprocess.run(D+['inspect',name],capture_output=True,text=True,timeout=5)
 if found.returncode==0:
  container=json.loads(found.stdout)[0]
  assert container['Image']==IMAGE and container['Config']['Labels']['org.kyaulabs.conflux.run']=='bpsd-decode-20261029-01'
  subprocess.run(D+['rm','--force',container['Id']],check=True,capture_output=True,timeout=10)
 assert subprocess.run(D+['inspect',name],capture_output=True,timeout=5).returncode!=0
 (base/'decode-container-closed-01.json').write_text(json.dumps(dict(container_absent=True,elapsed_seconds=time.monotonic()-first,exit=None if result is None else result.returncode),indent=2)+chr(10))
raise SystemExit(result.returncode)
"""
program='BASE='+repr(BASE)+'\nIMAGE='+repr(IMAGE)+'\n'+owner
(base/'run_decode_container.py').write_text(program)
(base/'decode-results').mkdir(mode=0o700)
print(json.dumps(dict(prepared=True,model_or_audio_started=False)))
'''


def main():
    builds=json.loads((PREP/'builds-complete-01.json').read_text())
    assert all(row['passed']for row in builds['hosts'].values())
    assert not (PREP/'decode-reservation-01.json').exists()
    root=PREP/'laptop';execution=root/'execution';execution.mkdir(mode=0o700)
    files={name:(PREP/'laptop/operations'/name).read_text()for name in ('decode_cases.py','test_decode_cases.py')}
    for name,text in files.items():(execution/name).write_text(text)
    plan=json.loads((root/'operations/plan.json').read_text())
    binary=builds['hosts']['laptop']['receipt']['binary'];assert pin(Path(binary['path']))==binary
    plan.update(status='frozen_decode_execution',unit=LOCAL_UNIT,binary=binary)
    plan['input_pins']=[binary]+[pin(execution/name)for name in files]+[case['source']for case in plan['cases']]
    save(execution/'execution-plan.json',plan)
    local_entry="""import os,subprocess
from pathlib import Path
base=Path(__file__).resolve().parent
r=subprocess.run(['/usr/bin/python3.14','-B',str(base/'test_decode_cases.py')],capture_output=True,text=True,timeout=15)
(base/'protocol-tests.stdout.log').write_text(r.stdout);(base/'protocol-tests.stderr.log').write_text(r.stderr)
assert r.returncode==0 and 'Ran 7 tests'in r.stderr and r.stderr.rstrip().endswith('OK')
os.execv('/usr/bin/python3.14',['python3.14','-B',str(base/'decode_cases.py'),'--owned','--plan',str(base/'execution-plan.json'),'--output',str(base.parent/'decode-results')])
"""
    (execution/'entry.py').write_text(local_entry)
    setup=subprocess.run(SSH+['python3 -'],input=remote_setup(files),capture_output=True,text=True,timeout=30)
    (PREP/'decode-apollo-setup.stdout.log').write_text(setup.stdout)
    (PREP/'decode-apollo-setup.stderr.log').write_text(setup.stderr)
    setup.check_returncode()
    assert show(LOCAL_UNIT)['LoadState']=='not-found'
    start=time.monotonic()
    save(PREP/'decode-reservation-01.json',dict(started_at_utc=datetime.now(timezone.utc).isoformat(),
        started_monotonic=start,deadline_monotonic=start+720,physical_readiness_consumed=False,
        source_decoding_only=True,no_retries=True))
    local=['systemd-run','--user','--unit='+LOCAL_UNIT,'--property=Type=exec','--property=RemainAfterExit=yes',
        '--property=Restart=no','--property=RuntimeMaxSec=660s','--property=TimeoutStopSec=15s',
        '--property=KillMode=control-group','--property=OOMPolicy=kill','--property=MemoryMax=1G',
        '--property=TasksMax=128','--property=CPUQuota=100%','--property=Nice=19','--property=UMask=0077',
        '--property=StandardOutput=append:'+str(root/'decode-unit.stdout.log'),
        '--property=StandardError=append:'+str(root/'decode-unit.stderr.log'),
        '/usr/bin/python3.14','-B',str(execution/'entry.py')]
    remote='BASE='+repr(REMOTE)+'\nUNIT='+repr(REMOTE_UNIT)+'\n'+r'''
from pathlib import Path
import json,subprocess
base=Path(BASE)
state=subprocess.check_output(['systemctl','show',UNIT,'--property=LoadState,MainPID'],text=True,timeout=5)
assert 'LoadState=not-found'in state and 'MainPID=0'in state
command=['sudo','-n','systemd-run','--unit='+UNIT,'--uid=1000','--gid=1000','--property=Type=exec',
 '--property=RemainAfterExit=yes','--property=Restart=no','--property=RuntimeMaxSec=660s',
 '--property=TimeoutStopSec=20s','--property=KillMode=control-group','--property=Nice=19',
 '--property=MemoryMax=1G','--property=TasksMax=128','--property=UMask=0077',
 '--property=StandardOutput=append:'+str(base/'decode-unit.stdout.log'),
 '--property=StandardError=append:'+str(base/'decode-unit.stderr.log'),
 '/usr/bin/python3','-B',str(base/'run_decode_container.py')]
r=subprocess.run(command,capture_output=True,text=True,timeout=10)
(base/'decode-dispatch-01.json').write_text(json.dumps(dict(command=command,exit=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2)+chr(10))
print(json.dumps(dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr)));r.check_returncode()
'''
    def dispatch(host,command,data=None):
        result=subprocess.run(command,input=data,capture_output=True,text=True,timeout=20)
        value=dict(exit=result.returncode,stdout=result.stdout,stderr=result.stderr)
        save(PREP/('decode-'+host+'-dispatch-01.json'),value)
        return value
    with ThreadPoolExecutor(max_workers=2)as pool:
        left=pool.submit(dispatch,'laptop',local)
        right=pool.submit(dispatch,'apollo',SSH+['python3 -'],remote)
        values=dict(laptop=left.result(),apollo=right.result())
    save(PREP/'decode-dispatched-01.json',dict(hosts=values,submitted_concurrently=True))
    print(json.dumps(dict(dispatched={host:row['exit']for host,row in values.items()},source_decoding_only=True)))
    assert all(row['exit']==0 for row in values.values())


if __name__=='__main__':
    main()
