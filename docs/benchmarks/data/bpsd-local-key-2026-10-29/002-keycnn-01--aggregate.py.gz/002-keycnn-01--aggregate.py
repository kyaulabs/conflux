import math

def global_class(rows):
    if not rows or not any(row['signal_nonzero'] for row in rows):
        return None, []
    means = [math.fsum(row['probabilities'][key] for row in rows)/len(rows) for key in range(24)]
    return max(range(24), key=lambda key:(means[key], -key)), means
