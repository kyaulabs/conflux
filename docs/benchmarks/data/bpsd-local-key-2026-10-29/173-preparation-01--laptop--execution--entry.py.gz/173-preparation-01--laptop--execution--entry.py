import os,subprocess
from pathlib import Path
base=Path(__file__).resolve().parent
r=subprocess.run(['/usr/bin/python3.14','-B',str(base/'test_decode_cases.py')],capture_output=True,text=True,timeout=15)
(base/'protocol-tests.stdout.log').write_text(r.stdout);(base/'protocol-tests.stderr.log').write_text(r.stderr)
assert r.returncode==0 and 'Ran 7 tests'in r.stderr and r.stderr.rstrip().endswith('OK')
os.execv('/usr/bin/python3.14',['python3.14','-B',str(base/'decode_cases.py'),'--owned','--plan',str(base/'execution-plan.json'),'--output',str(base.parent/'decode-results')])
