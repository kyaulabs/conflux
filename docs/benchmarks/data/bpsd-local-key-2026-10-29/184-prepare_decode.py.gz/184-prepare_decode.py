"""Prepare existing decoder checks for eight new fixed source paths."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
WORK = Path('/home/kyau/.codex/worktrees/player-startup-clock/conflux')
OLD = ROOT/'build/m2-fmak-independent-01/preparation-02/laptop'
DEST = BASE/'preparation-01'
def pin(path):
    raw=path.read_bytes()
    assert path.is_file() and not path.is_symlink()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
admission=json.loads((BASE/'source-admission-01.json').read_text())
assert admission['complete'] and admission['fixed_denominator']==8
assert all(row['status']=='SourceBytesAdmitted' for row in admission['sources'])
DEST.mkdir(mode=0o700)
for host in ('laptop','apollo'):
    target=DEST/host
    (target/'source/audio').mkdir(parents=True,mode=0o700)
    (target/'operations').mkdir(mode=0o700)
    for name in ('AudioFile.cpp','AudioFile.hpp','AudioSource.hpp','RenderCore.hpp','ChannelEq.hpp'):
        (target/'source/audio'/name).write_bytes((WORK/'src/audio'/name).read_bytes())
    for name in ('prepare_source.cpp','CMakeLists.txt'):
        (target/'source'/name).write_bytes((OLD/'source'/name).read_bytes())
    header='#pragma once\n#include <array>\n#include <cstdint>\n#include <string_view>\n'
    header+='struct Source { std::string_view id, sha, path; std::uint64_t bytes; };\ninline constexpr std::array<Source,8> sources{{\n'
    cases=[]
    for row in admission['sources']:
        source=row['source']
        assert pin(Path(source['path']))=={k:source[k]for k in ('bytes','sha256')}
        path=source['path'] if host=='laptop' else '/media/'+row['id']+'.wav'
        header+='    {'+', '.join(json.dumps(v) for v in (row['id'],source['sha256'],path))+', '+str(source['bytes'])+'},\n'
        cases.append(dict(id=row['id'],source=dict(path=path,bytes=source['bytes'],sha256=source['sha256'])))
    (target/'source/sources.hpp').write_text(header+'}};\n')
    for name in ('build_preparer.py','decode_cases.py','test_decode_cases.py'):
        text=(OLD/'operations'/name).read_text()
        if name=='build_preparer.py':
            text=text.replace('conflux-independent-preparer-build-laptop-20261029-02.service',
                'conflux-bpsd-preparer-build-laptop-20261029-01.service')
        elif name=='decode_cases.py':
            text=text.replace("len(plan['cases']) == 24", "len(plan['cases']) == 8").replace("}) == 24", "}) == 8")
            text=text.replace('began+1650','began+600').replace('fixed_denominator=24','fixed_denominator=8')
        elif name=='test_decode_cases.py':
            text=text.replace('range(24)','range(8)')
        compile(text,str(target/'operations'/name),'exec')
        (target/'operations'/name).write_text(text)
    source_files=[dict(file=str(p.relative_to(target)),**pin(p))for p in sorted((target/'source').rglob('*'))if p.is_file()]
    operation_files=[dict(file=str(p.relative_to(target)),**pin(p))for p in sorted((target/'operations').glob('*.py'))]
    plan=dict(schema=1,status='frozen_decode_correctness_only',host=host,cases=cases,fixed_denominator=8,
        source_files=source_files,operation_files=operation_files,physical_readiness_required=False,
        source_algorithm='Unchanged current CONFLUX AudioFile source with existing private input-whitelist helper; path/count bindings only.',
        reference_labels_in_runtime=False,model_started=False,qualified=False)
    (target/'operations/plan.json').write_text(json.dumps(plan,indent=2)+'\n')
binding=dict(schema=1,source_admission=pin(BASE/'source-admission-01.json'),
    host_plans={host:pin(DEST/host/'operations/plan.json') for host in ('laptop','apollo')},
    product_source_files={name:pin(WORK/'src/audio'/name)for name in ('AudioFile.cpp','AudioFile.hpp','AudioSource.hpp','RenderCore.hpp','ChannelEq.hpp')},
    source_decoded=False,model_started=False,reference_labels_in_runtime=False,physical_readiness_consumed=False)
(DEST/'preparation-binding-01.json').write_text(json.dumps(binding,indent=2)+'\n')
print(json.dumps(dict(prepared=True,hosts=['laptop','apollo'],sources=8,source_decoded=False,model_started=False)))
