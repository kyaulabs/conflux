"""Reuse the already verified CPU runtime; do not install or transfer packages."""
from run_decode_both import SSH

REMOTE = '/srv/conflux-tests/work/bpsd-local-key-20261029-01/keycnn'
ASSET_REMOTE = '/srv/conflux-tests/work/fmak-independent-keycnn-20261029-01/assets'
