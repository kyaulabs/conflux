"""Admit the fixed eight sources and their exact local-key references by range."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib
import importlib.util
import json
import resource
import shutil
import time
import zipfile
import zlib

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
plan_raw = (BASE/'selection-plan-01.json').read_bytes()
plan = json.loads(plan_raw)
prospective = json.loads((BASE/'prospective-01.json').read_text())
assert prospective['selection']['sha256']==hashlib.sha256(plan_raw).hexdigest()
assert plan['fixed_denominator']==8 and plan['composition_count']==4
reader_path = ROOT/'build/m2-fmak-independent-01/resume-last-01/range_media.py'
spec = importlib.util.spec_from_file_location('tested_bounded_range_reader',reader_path)
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
limits = prospective['acquisition_limits']
budget = reader.Budget(limits['seconds'],limits['network_bytes'])
source_dir = BASE/'media-01'
reference_dir = BASE/'references-01'
source_dir.mkdir(mode=0o700)
reference_dir.mkdir(mode=0o700)
results = [dict(id=c['id'],composition=c['composition'],performance=c['performance'],
                status='NotAttempted') for c in plan['cases']]
def admitted(archive,entry,target,limit):
    name = PurePosixPath(entry['name'])
    assert not name.is_absolute() and '..'not in name.parts and '\\'not in entry['name']
    matches = [i for i in archive.infolist() if i.filename==entry['name']]
    assert len(matches)==1
    member = matches[0]
    assert not member.is_dir() and not member.flag_bits&1
    assert ((member.external_attr>>16)&0o170000)!=0o120000
    assert member.compress_type in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED)
    assert member.file_size==entry['bytes'] and member.compress_size==entry['compressed_bytes']
    assert f'{member.CRC:08x}'==entry['CRC32'] and 0<member.file_size<=limit and member.compress_size<=limit
    with archive.open(member) as stream:
        raw = stream.read(limit+1)
    assert len(raw)==member.file_size and zlib.crc32(raw)==member.CRC
    if target.suffix=='.csv':
        raw.decode('utf-8-sig') # No reference label parsing before capture.
    assert shutil.disk_usage(BASE).free-len(raw)>=1024**3,'Preserve 1 GiB free source-filesystem reserve'
    with target.open('xb') as stream:
        stream.write(raw)
    budget.check()
    return dict(path=str(target),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
        archive_member=entry['name'],ZIP_CRC32=f'{member.CRC:08x}',ZIP_CRC_verified=True)
error = None
try:
    for row in plan['input_pins']:
        raw = Path(row['path']).read_bytes()
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    url='https://zenodo.org/records/18662551/files/'+plan['archive']+'?download=1'
    with reader.RangeFile(url,plan['archive_published_size'],budget) as remote,zipfile.ZipFile(remote) as archive:
        observed=[dict(name=i.filename,bytes=i.file_size,compressed_bytes=i.compress_size,
                       CRC32=f'{i.CRC:08x}',directory=i.is_dir()) for i in archive.infolist()]
        expected=json.loads(Path(plan['input_pins'][0]['path']).read_text())
        assert observed==expected,'Published ZIP index differs from the fixed selection'
        for offset,case in enumerate(plan['cases']):
            budget.check()
            source=admitted(archive,case['source'],source_dir/(case['id']+'.wav'),18*1024**2)
            refs={}
            for category,entry in case['references'].items():
                refs[category]=admitted(archive,entry,reference_dir/(case['id']+'-'+category+'.csv'),262144)
            results[offset]=dict(id=case['id'],composition=case['composition'],performance=case['performance'],
                status='SourceBytesAdmitted',source=source,references=refs,
                known_publisher_reference_notes=case['known_publisher_reference_notes'])
            print(json.dumps(dict(id=case['id'],composition=case['composition'],performance=case['performance'],
                admitted=offset+1,source_bytes=source['bytes'],transferred_bytes=budget.bytes)),flush=True)
except Exception as caught:
    error=dict(type=type(caught).__name__,detail=str(caught)[:1800])
receipt=dict(schema=1,recorded_at_utc=datetime.now(timezone.utc).isoformat(),complete=error is None,
    fixed_denominator=8,sources=results,error=error,plan_sha256=hashlib.sha256(plan_raw).hexdigest(),
    reader_sha256=hashlib.sha256(reader_path.read_bytes()).hexdigest(),
    audio_source_bytes=sum(r.get('source',{}).get('bytes',0) for r in results),
    transferred_bytes=budget.bytes,requests=budget.requests,elapsed_seconds=time.monotonic()-budget.started,
    full_archive_MD5_computed=False,source_time_alignment_qualified=False,
    audio_decoded=False,audio_played=False,model_or_GPU_started=False,
    physical_readiness_consumed=False,configuration_or_milestone_gate_changed=False)
with (BASE/'source-admission-01.json').open('x')as output:output.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k]for k in ('complete','fixed_denominator','audio_source_bytes','transferred_bytes','elapsed_seconds','error')}),flush=True)
assert receipt['complete']
