#pragma once
#include <array>
#include <cstdint>
#include <string_view>
struct Source { std::string_view id, sha, path; std::uint64_t bytes; };
inline constexpr std::array<Source,8> sources{{
    {"800001", "5f5b69f9cd569f26e5c540ea3d706c7108c1cf23afdd67440ad98d2b292474af", "/home/kyau/projects/kyaulabs/conflux/build/m2-bpsd-local-key-01/media-01/800001.wav", 11782976},
    {"800002", "b69d72ed2de566c37b8f05e96c4b7e68a5388c950805d646035ac6bee6d8f88f", "/home/kyau/projects/kyaulabs/conflux/build/m2-bpsd-local-key-01/media-01/800002.wav", 11532488},
    {"800003", "a28e2075ae6806e57b7bb52031f95324224e64f3954d0abf11e0ed1ca62e45c1", "/home/kyau/projects/kyaulabs/conflux/build/m2-bpsd-local-key-01/media-01/800003.wav", 10330028},
    {"800004", "1bf80eec00e382385b6d491a8658997f576d73f36ffa21f03da6ca40754bb950", "/home/kyau/projects/kyaulabs/conflux/build/m2-bpsd-local-key-01/media-01/800004.wav", 9353360},
    {"800005", "c8926bbad518da5743296072d357dee9c66cae7b4150bbe2d8f22ef81345c5c0", "/home/kyau/projects/kyaulabs/conflux/build/m2-bpsd-local-key-01/media-01/800005.wav", 17952272},
    {"800006", "1046b6ae8a11b9c97573af7c224a96b5b133b599485f38d7c140991ce30bd48b", "/home/kyau/projects/kyaulabs/conflux/build/m2-bpsd-local-key-01/media-01/800006.wav", 17375444},
    {"800007", "bb3e1b5838e9676f4fa882e327e6d857e9dfde43005b67638c33483ce28c3152", "/home/kyau/projects/kyaulabs/conflux/build/m2-bpsd-local-key-01/media-01/800007.wav", 13638116},
    {"800008", "a949ae566318db7c02f71a442b5cd0bb8b366056d8bc4a95bad4f4e4fb3bc98e", "/home/kyau/projects/kyaulabs/conflux/build/m2-bpsd-local-key-01/media-01/800008.wav", 13963868},
}};
