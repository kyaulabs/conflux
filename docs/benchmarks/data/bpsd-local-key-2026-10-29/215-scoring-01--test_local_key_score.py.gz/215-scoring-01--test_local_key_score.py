"""Generated overlap and failure checks; no corpus labels, audio or model."""
from decimal import Decimal as D
import importlib.util
from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parent
s = importlib.util.spec_from_file_location('local_key_scoring_under_test', BASE / 'local_key_score.py')
score = importlib.util.module_from_spec(s)
s.loader.exec_module(score)


def window(first, end, tonic=0, mode='Major', state='Estimated'):
    return dict(first_frame=first, end_frame=end, status=state,
        candidates=[dict(tonic=tonic, mode=mode)] if state == 'Estimated' else [])


class LocalKeyChecks(unittest.TestCase):
    def evaluate(self, keys, windows, frames=48000, active='0;1'):
        return score.score_case('start;end;localkey\n' + keys,
            'start;end\n' + active, frames, windows)

    def test_fractional_reference_boundaries_are_not_snapped(self):
        result = self.evaluate('0;0.00001;C:maj\n0.00001;1;D:maj',
            [window(0, 1), window(1, 48000, tonic=2)])
        self.assertEqual(result['status'], 'Scored')
        self.assertEqual(result['value']['known'], D(48000))
        self.assertEqual(result['value']['correct'], D('47999.48'))

    def test_unknown_keeps_primary_denominator_and_is_not_credited(self):
        result = self.evaluate('0;1;C:maj', [window(0, 24000), window(24000, 48000, state='Unknown')])
        metrics = score.combine([result])['metrics']
        self.assertEqual(D(metrics['exact_top_one_full_denominator']), D('.5'))
        self.assertEqual(D(metrics['estimated_coverage']), D('.5'))
        self.assertEqual(D(metrics['conditional_accuracy']), D(1))

    def test_unannotated_gap_and_source_edges_remain_unlabelled(self):
        result = self.evaluate('0.1;0.4;C:maj\n0.401;0.9;C:maj', [window(0, 48000)], active='0.1;0.9')
        value = result['value']
        self.assertEqual(value['known'], D('38352'))
        self.assertEqual(value['unlabelled_states']['Estimated'], D('9648'))
        self.assertEqual(result['unannotated_gaps'][0]['seconds'], '0.001')

    def test_failed_capture_keeps_all_known_seconds(self):
        good = self.evaluate('0;1;C:maj', [window(0, 48000)])
        failed = score.score_case('start;end;localkey\n0;1;C:maj', 'start;end\n0;1',
            None, None, capture_failure='Native preparation failed')
        combined = score.combine([good, failed])
        self.assertEqual(combined['case_denominator'], 2)
        self.assertEqual(D(combined['metrics']['exact_top_one_full_denominator']), D('.5'))
        self.assertEqual(D(combined['metrics']['state_frame_units']['Failed']), D(48000))

    def test_reference_outside_source_is_failed_without_trimming(self):
        result = self.evaluate('0;1;C:maj', [window(0, 24000)], frames=24000)
        self.assertEqual(result['status'], 'SourceOrReferenceGeometryFailed')
        self.assertEqual(result['value']['known'], D(48000))
        self.assertEqual(result['value']['states']['Failed'], D(48000))

    def test_malformed_references_are_explicitly_unscorable_and_not_removed(self):
        for keys in ('0;1;C:dorian', '0;NaN;C:maj', '0;0.7;C:maj\n0.6;1;D:maj'):
            result = self.evaluate(keys, [window(0, 48000)])
            combined = score.combine([result])
            self.assertEqual(result['status'], 'ReferenceInvalid')
            self.assertEqual(combined['case_denominator'], 1)
            self.assertEqual(combined['reference_failures'], 1)
            self.assertFalse(combined['all_case_reference_durations_available'])
            self.assertIsNone(combined['metrics']['exact_top_one_full_denominator'])

    def test_source_window_gap_overlap_truncation_and_boolean_class_are_failures(self):
        variants = [[window(1, 48000)], [window(0, 24001), window(24000, 48000)],
            [window(0, 47999)], [window(0, 48000, tonic=True)]]
        for windows in variants:
            result = self.evaluate('0;1;C:maj', windows)
            self.assertEqual(result['status'], 'SourceOrReferenceGeometryFailed')
            self.assertEqual(result['value']['states']['Failed'], D(48000))

    def test_exact_mode_and_enharmonic_tonic(self):
        enharmonic = self.evaluate('0;1;Db:min', [window(0, 48000, tonic=1, mode='Minor')])
        wrong_mode = self.evaluate('0;1;Db:min', [window(0, 48000, tonic=1, mode='Major')])
        self.assertEqual(enharmonic['value']['correct'], D(48000))
        self.assertEqual(wrong_mode['value']['correct'], D(0))


if __name__ == '__main__':
    unittest.main(verbosity=2)
