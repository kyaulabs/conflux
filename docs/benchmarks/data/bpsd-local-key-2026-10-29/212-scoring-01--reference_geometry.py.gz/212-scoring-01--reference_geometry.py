"""Strict BPSD annotation geometry; no audio alignment or musical inference."""
import csv
from decimal import Decimal, InvalidOperation
import io
import re

HEADERS = {
    'ann_audio_beat': ['time', 'beat'],
    'ann_audio_measure': ['time', 'measure'],
    'ann_audio_startEnd': ['start', 'end'],
    'ann_audio_syncInfo': ['time', 'measure'],
    'ann_audio_localkey': ['start', 'end', 'localkey'],
    'ann_audio_structureCoarse': ['start', 'end', 'structure'],
}

def number(value):
    try:
        result = Decimal(value)
    except (InvalidOperation, TypeError, ValueError) as error:
        raise ValueError('Invalid reference number') from error
    if not result.is_finite() or result < 0:
        raise ValueError('Reference numbers must be finite and nonnegative')
    return result

def key_class(label):
    match = re.fullmatch(r'([A-G])([b#]?):(maj|min)', label)
    if match is None:
        raise ValueError('Unsupported local-key reference label')
    letter, accidental, mode = match.groups()
    pitch = dict(C=0, D=2, E=4, F=5, G=7, A=9, B=11)[letter]
    pitch += {'': 0, '#': 1, 'b': -1}[accidental]
    return pitch % 12 + (12 if mode == 'min' else 0)

def parse(category, text):
    if category not in HEADERS or not isinstance(text, str) or len(text)>262144:
        raise ValueError('Unsupported or oversized reference')
    table = csv.reader(io.StringIO(text.removeprefix('\ufeff')), delimiter=';', strict=True)
    if next(table, None) != HEADERS[category]:
        raise ValueError('Reference header differs from the publisher format')
    rows = list(table)
    if not rows or len(rows)>20000 or any(len(row)!=len(HEADERS[category]) for row in rows):
        raise ValueError('Empty, oversized or malformed reference table')
    interval = 'start' in HEADERS[category]
    gaps = []
    normalized = []
    previous = None
    for row in rows:
        first, second = number(row[0]), number(row[1])
        if interval:
            if second<=first or (previous is not None and first<previous):
                raise ValueError('Overlapping, reversed or empty reference interval')
            if previous is not None and first>previous:
                gaps.append(dict(start=str(previous), end=str(first), seconds=str(first-previous)))
            item = dict(start=str(first), end=str(second))
            if category=='ann_audio_localkey':
                item.update(label=row[2], key_class=key_class(row[2]))
            elif category=='ann_audio_structureCoarse':
                if not row[2].strip() or len(row[2])>256:
                    raise ValueError('Empty or oversized structure label')
                item['label'] = row[2]
            previous = second
        else:
            # Physical time must advance; musical coordinates retain fractions.
            # Sync tuples may share physical time, but may never go backwards.
            if previous is not None and (first<previous or
                (first==previous and category!='ann_audio_syncInfo')):
                raise ValueError('Reference physical times are not ordered')
            item = dict(time=str(first), musical_coordinate=str(second))
            previous = first
        normalized.append(item)
    if category=='ann_audio_startEnd' and len(normalized)!=1:
        raise ValueError('An active interval must be a single start/end row')
    return dict(category=category, rows=len(normalized), values=normalized,
        internal_unannotated_gaps=gaps, gap_seconds=str(sum((number(g['seconds']) for g in gaps), Decimal(0))),
        units='Publisher physical seconds; musical coordinates retained without beat-unit interpretation',
        audio_alignment_qualified=False, musical_accuracy_qualified=False)
