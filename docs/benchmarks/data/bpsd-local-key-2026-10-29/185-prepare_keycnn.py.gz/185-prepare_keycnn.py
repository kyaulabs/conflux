"""Bind the unchanged dense Key-CNN to eight completely prepared BPSD sources."""
from pathlib import Path
import ast
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
TARGET = BASE / 'keycnn-01'
OLD = ROOT / 'build/m2-fmak-independent-01/keycnn-01'
DATA = ROOT / 'build/m2-keyfinder-assessment-01/key-cnn-source-audit-01/model-data-audit-01'


def pin(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    comparison = json.loads((BASE / 'preparation-01/decode-comparison-01.json').read_text())
    assert comparison['both_units_retired'] and comparison['apollo_container_absent']
    assert len(comparison['exact_frame_and_PCM_matches']) == 8 and not comparison['mismatches']
    assert not comparison['source_failures_retained']
    original = json.loads((BASE / 'prospective-01.json').read_text())
    for row in original['recipe_inputs']:
        assert pin(row['path']) == row
    scoring = BASE / 'scoring-01/scoring-contract-01.json'
    contract = json.loads(scoring.read_text())
    assert contract['frozen_before_new_model_capture']
    for row in contract['files']:
        assert pin(row['path']) == row
    assert not TARGET.exists()
    TARGET.mkdir(mode=0o700)
    (TARGET / 'asset-manifest-01.json').write_bytes((OLD / 'asset-manifest-01.json').read_bytes())
    # Reuse the completed numerical compatibility evidence for these exact assets.
    compatibility = json.loads((OLD / 'compatibility-complete-01.json').read_text())
    assert compatibility['passed'] and compatibility['both_units_retired'] and compatibility['apollo_container_absent']
    compatibility['reused_historical_evidence'] = pin(OLD / 'compatibility-complete-01.json')
    compatibility['new_corpus_inference_started'] = False
    save(TARGET / 'compatibility-complete-01.json', compatibility)
    names = ('run_corpus.py', 'protocol.py', 'aggregate.py', 'score_global.py',
        'test_global.py', 'test_protocol.py', 'test_lifecycle.py', 'test_pipeline.py')
    for name in names:
        text = (OLD / 'laptop' / name).read_text()
        if name == 'run_corpus.py':
            for before, after in (('len(plan[\'cases\'])==24', 'len(plan[\'cases\'])==8'),
                ('for row in plan[\'cases\']})==24', 'for row in plan[\'cases\']})==8'),
                ('completed_captures=24,fixed_denominator=24', 'completed_captures=8,fixed_denominator=8')):
                assert before in text, before
                text = text.replace(before, after)
        if name == 'test_lifecycle.py':
            text = text.replace('range(24)', 'range(8)').replace("receipt['fixed_denominator'],24", "receipt['fixed_denominator'],8")
        ast.parse(text)
        (TARGET / name).write_text(text)
    for host in ('laptop', 'apollo'):
        folder = TARGET / host
        folder.mkdir(mode=0o700)
        (folder / 'keycnn_worker.py').write_bytes((OLD / 'laptop/keycnn_worker.py').read_bytes())
        if host == 'laptop':
            prepared = BASE / 'preparation-01/laptop/decode-results/preparation.json'
            binary = json.loads((BASE / 'preparation-01/laptop/build-receipt-01.json').read_text())['binary']
        else:
            prepared = BASE / 'preparation-01/apollo-collected-01/decode-results/cases/preparation.json'
            binary = json.loads((BASE / 'preparation-01/apollo-collected-01/execution/execution-plan.json').read_text())['binary']
        result = json.loads(prepared.read_text())
        assert result['fixed_denominator'] == 8 and result['all_sources_prepared'] and result['input_pins_unchanged']
        cases = [dict(row, preparation_status=row['status']) for row in result['cases']]
        assert [row['id'] for row in cases] == comparison['exact_frame_and_PCM_matches']
        plan = dict(schema=1, status='frozen_CPU_correctness_only', host=host,
            recipe=original['recipe'], model_sha256=original['model_sha256'],
            cases=cases, preparer=binary, python=str(DATA / 'feature-compatibility-01/venv/bin/python'),
            worker=str(folder / 'keycnn_worker.py') if host == 'laptop' else '/operations/keycnn_worker.py',
            unit='conflux-bpsd-keycnn-' + host + '-20261029-01.service',
            physical_readiness_required=False, fixed_denominator=8,
            case_seconds=160, worker_CPU_seconds=80, worker_address_space_bytes=3 * 1024**3,
            inner_total_seconds=1400, reference_labels_in_runtime=False,
            confidence='Unknown', qualified=False)
        save(folder / 'music-plan-01.json', plan)
    save(TARGET / 'prospective-01.json', dict(schema=1, original=pin(BASE / 'prospective-01.json'),
        scoring_contract=pin(scoring), decoded_source_comparison=pin(BASE / 'preparation-01/decode-comparison-01.json'),
        unchanged_worker=pin(OLD / 'laptop/keycnn_worker.py'),
        unchanged_protocol=pin(OLD / 'laptop/protocol.py'),
        source_and_frame_count_bindings_only=True, fixed_denominator=8, composition_count=4,
        local_key_primary_score='Unshifted exact tonic/mode Decimal duration overlap; global posterior mean is descriptive only',
        source_labels_or_predictions_used_to_select_cases=False, training_independence_established=False,
        confidence='Unknown', production_backend_enabled=False, qualified=False,
        physical_readiness_consumed=False, inference_started=False))
    print(json.dumps(dict(prepared=True, fixed_sources=8, unchanged_dense_model=True, music_inference_started=False)))


if __name__ == '__main__':
    main()
