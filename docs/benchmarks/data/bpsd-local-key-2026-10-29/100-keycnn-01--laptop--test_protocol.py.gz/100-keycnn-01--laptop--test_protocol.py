"""Generated PCM/result binding failures; no corpus, feature model or devices."""
import copy
import hashlib
import importlib.util
import io
from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('checked_private_keycnn_protocol', BASE/'protocol.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


class ProtocolChecks(unittest.TestCase):
    def fixture(self):
        case = dict(id='generated', prepared_frames=48000, pcm_sha256='1'*64,
                    source=dict(bytes=384044, sha256='2'*64))
        raw = [dict(index=0, probabilities=[1./24]*24, signal_nonzero=True)]
        value = dict(schema=1, recipe=p.RECIPE, model_sha256=p.MODEL_SHA, frames=48000,
                     sample_rate=48000, channels=2, pcm_sha256=case['pcm_sha256'], CQT_columns=6,
                     raw_predictions=raw, window_count=2, windows=p.projection(48000, raw),
                     confidence='Unknown', qualified=False, audio_device_opened=False, GPU_started=False)
        metadata = dict(case='generated', complete=True, source_bytes=384044, source_sha256='2'*64,
                        prepared_frames=48000, prepared_pcm_sha256='1'*64, sample_rate=48000,
                        channels=2, audio_device_opened=False)
        return case, value, metadata

    def test_exact_PCM_extent_and_digest(self):
        raw = bytes(range(32))
        digest = hashlib.sha256(raw).hexdigest()
        self.assertEqual(p.read_pcm(io.BytesIO(raw), 4, digest), raw)
        for stream, sha in [(raw[:-1], digest), (raw+b'X', digest), (raw, '0'*64), (raw, 'invalid')]:
            with self.assertRaises(ValueError):
                p.read_pcm(io.BytesIO(stream), 4, sha)
        for frames in (True, 0, -1, 4., p.clock.MAX_SOURCE_FRAMES+1):
            with self.assertRaises(ValueError):
                p.read_pcm(io.BytesIO(raw), frames, digest)

    def test_valid_projection_retains_unknown_tail_and_source_identity(self):
        case, value, metadata = self.fixture()
        result = p.validate_prediction(value, metadata, case)
        self.assertEqual([(r['first_frame'], r['end_frame'], r['status']) for r in result],
                         [(0, 35665, 'Estimated'), (35665, 48000, 'Unknown')])
        self.assertEqual(result[0]['candidates'], [dict(tonic=0, mode='Major')])

    def test_zero_features_are_unknown_with_raw_distribution_retained(self):
        _, value, _ = self.fixture()
        value['raw_predictions'][0]['signal_nonzero'] = False
        result = p.projection(48000, value['raw_predictions'])
        self.assertTrue(all(r['status'] == 'Unknown' and r['candidates'] == [] for r in result))
        self.assertEqual(len(value['raw_predictions'][0]['probabilities']), 24)

    def test_probability_geometry_types_normalization_and_order(self):
        _, value, _ = self.fixture()
        raw = value['raw_predictions']
        variants = []
        for probabilities in ([float('nan')]+[0.]*23, [True]+[0.]*23, [-.1]+[1.1]+[0.]*22,
                              [1.]*24, [1./23]*23):
            altered = copy.deepcopy(raw);altered[0]['probabilities'] = probabilities;variants.append(altered)
        for key, data in [('index', True), ('index', 1), ('signal_nonzero', 1)]:
            altered = copy.deepcopy(raw);altered[0][key] = data;variants.append(altered)
        variants.append([])
        for altered in variants:
            with self.assertRaises(ValueError):
                p.projection(48000, altered)

    def test_forged_recipe_source_geometry_and_qualification_rejected(self):
        case, value, metadata = self.fixture()
        for name, data in [('schema', True), ('recipe', 'other'), ('model_sha256', '0'*64),
                           ('frames', 48001), ('frames', True), ('pcm_sha256', '0'*64),
                           ('CQT_columns', 7), ('qualified', True), ('GPU_started', True)]:
            altered = copy.deepcopy(value);altered[name] = data
            with self.subTest(name=name), self.assertRaises(ValueError):
                p.validate_prediction(altered, metadata, case)

    def test_forged_source_preparer_metadata_rejected(self):
        case, value, metadata = self.fixture()
        for name, data in [('source_sha256', '0'*64), ('prepared_pcm_sha256', '0'*64),
                           ('prepared_frames', 48001), ('case', 'other'), ('complete', False)]:
            altered = copy.deepcopy(metadata);altered[name] = data
            with self.assertRaises(ValueError):
                p.validate_prediction(value, altered, case)

    def test_forged_boundaries_and_boolean_tonic_rejected(self):
        case, value, metadata = self.fixture()
        for mutate in (lambda v:v['windows'][0].update(first_frame=False),
                       lambda v:v['windows'][0].update(end_frame=35666),
                       lambda v:v['windows'][0]['candidates'][0].update(tonic=False),
                       lambda v:v['windows'][1].update(status='Estimated')):
            altered = copy.deepcopy(value);mutate(altered)
            with self.assertRaises(ValueError):
                p.validate_prediction(altered, metadata, case)


if __name__ == '__main__':
    unittest.main()
