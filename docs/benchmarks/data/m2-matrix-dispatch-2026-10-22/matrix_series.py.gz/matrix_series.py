"""Bounded saved-data matrix graphs; no request association or runtime work."""
import re

PREFIX = b"conflux_vk_matrix_v1 "
MAX_GRAPHS = 64
MAX_GRAPH_BYTES = 512 * 1024
MAX_METADATA_BYTES = MAX_GRAPHS * MAX_GRAPH_BYTES
MAX_OTHER_BYTES = 8 * 1024 * 1024
MAX_BYTES = MAX_METADATA_BYTES + MAX_OTHER_BYTES
MAX_RECORD_BYTES = 4096
MAX_NODES, MAX_DECISIONS, MAX_DISPATCHES = 256, 512, 2048
MAX_GRAPH_NODES = 65536
UINT32_MAX, UINT64_MAX, INT32_MAX, INT64_MAX = (1 << 32) - 1, (1 << 64) - 1, (1 << 31) - 1, (1 << 63) - 1

BEGIN = {"seq", "status", "reason", "graph_nodes", "queries", "expected", "nodes", "decisions", "dispatches",
         "attempted_dispatches", "total_ns", "matrix_ns", "rest_ns"}
NODE = {"seq", "item", "query", "graph", "op", "precision", "lowering", "query_fused", "query_fusion",
        "applied_fusion", "applied_count", "write_mask", "interval_ns", "output_graph", "output_type",
        "output_ne", "output_nb", "output_view_offset"}
for _slot in range(3):
    NODE.update(f"t{_slot}_{suffix}" for suffix in ("type", "ne", "nb", "view_offset"))
PIPELINE = {"pipeline", "denoms", "align", "index64"}
DECISION = {"seq", "item", "node", "route", "flags", "kpad", "split_k", "padded_n", "ne", "buffer_types",
            "view_offsets", "layout"} | PIPELINE
DISPATCH = {"seq", "item", "node", "decision", "ordinal", "stage", "elements", "workgroups",
            "base_y", "base_z", "k_split"} | PIPELINE
ROUTES = {"matrix", "vector", "vector_p021", "vector_nc"}
PREPARE = {"materialize_x", "dequantize_x", "materialize_y", "quantize_y"}
STAGES = PREPARE | {"main", "split_main", "split_reduce"}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def number(value, maximum=UINT64_MAX, *, signed=False):
    pattern = r"0|-?[1-9][0-9]{0,19}" if signed else r"0|[1-9][0-9]{0,19}"
    require(type(value) is str and re.fullmatch(pattern, value) is not None, "Noncanonical metadata integer")
    parsed = int(value)
    require((-maximum - 1 if signed else 0) <= parsed <= maximum, "Metadata integer overflow")
    return parsed


def token(value, capacity):
    require(type(value) is str and 0 < len(value) < capacity
            and re.fullmatch(r"[A-Za-z0-9_.-]+", value) is not None, "Invalid metadata token")
    return value


def vector(value, length, maximum=UINT64_MAX, *, positive=False):
    parts = value.split(",")
    require(len(parts) == length, "Metadata vector extent differs")
    result = tuple(number(x, maximum) for x in parts)
    require(not positive or all(result), "Zero metadata geometry")
    return result


def fields(raw):
    require(raw.endswith(b"\n") and len(raw) <= MAX_RECORD_BYTES, "Unterminated/oversized metadata record")
    try:
        words = raw[:-1].decode("ascii").split(" ")
    except UnicodeDecodeError as error:
        raise ValueError("Non-ASCII metadata") from error
    require(len(words) >= 3 and words[0] == "conflux_vk_matrix_v1", "Metadata prefix differs")
    row = {}
    for word in words[2:]:
        require(word.count("=") == 1, "Malformed metadata field")
        key, value = word.split("=", 1)
        require(key and value and key not in row, "Duplicate/empty metadata field")
        row[key] = value
    return words[1], row


def pipeline(row):
    return {"pipeline": token(row["pipeline"], 128),
            "denoms": vector(row["denoms"], 3, UINT32_MAX, positive=True),
            "align": number(row["align"], UINT32_MAX), "index64": number(row["index64"], 1)}


def tensor(row, prefix):
    return {prefix + "type": number(row[prefix + "type"], INT32_MAX),
            prefix + "ne": vector(row[prefix + "ne"], 4, INT64_MAX, positive=True),
            prefix + "nb": vector(row[prefix + "nb"], 4, positive=True),
            prefix + "view_offset": number(row[prefix + "view_offset"])}


def node(row):
    require(set(row) == NODE, "Node fields differ")
    result = {key: number(row[key], INT32_MAX) for key in ("item", "query", "graph", "op", "output_graph")}
    result.update({key: number(row[key], INT32_MAX, signed=True) for key in ("precision", "lowering")})
    result.update(seq=number(row["seq"]), query_fused=number(row["query_fused"], 1),
                  query_fusion=token(row["query_fusion"], 64), applied_fusion=token(row["applied_fusion"], 64),
                  applied_count=number(row["applied_count"], 11), write_mask=number(row["write_mask"], INT32_MAX),
                  interval_ns=number(row["interval_ns"]))
    count = result["applied_count"]
    require(bool(result["query_fused"]) == (result["query_fusion"] != "none"), "Raw query fusion differs")
    require(result["applied_fusion"] == (result["query_fusion"] if count else "none")
            and (not count or result["query_fused"]), "Applied fusion differs")
    require(0 < result["write_mask"] < (1 << (count + 1)) and result["write_mask"] & (1 << count),
            "Applied write mask differs")
    for prefix in ("t0_", "t1_", "t2_", "output_"):
        result.update(tensor(row, prefix))
    if not count:
        require(all(result["output_" + suffix] == result["t2_" + suffix]
                    for suffix in ("type", "ne", "nb", "view_offset")), "Unfused output differs")
    return result


def decision(row):
    require(set(row) == DECISION and row["route"] in ROUTES, "Decision fields/route differ")
    result = {key: number(row[key], UINT32_MAX) for key in ("item", "node", "flags", "kpad", "split_k", "padded_n")}
    result.update(seq=number(row["seq"]), route=row["route"], ne=vector(row["ne"], 12, INT64_MAX, positive=True),
                  buffer_types=vector(row["buffer_types"], 3, INT32_MAX),
                  view_offsets=vector(row["view_offsets"], 3), layout=vector(row["layout"], 16))
    require(result["flags"] <= 511, "Unknown decision flags")
    require(result["split_k"] >= 1 if result["route"] == "matrix" else
            result["split_k"] == result["kpad"] == result["padded_n"] == 0,
            "Route split/padding fields differ")
    result.update(pipeline(row))
    return result


def dispatch(row):
    require(set(row) == DISPATCH and row["stage"] in STAGES, "Dispatch fields/stage differ")
    result = {key: number(row[key], UINT32_MAX) for key in ("item", "node", "decision", "ordinal", "base_y", "base_z", "k_split")}
    result.update(seq=number(row["seq"]), stage=row["stage"],
                  elements=vector(row["elements"], 3, UINT32_MAX, positive=True),
                  workgroups=vector(row["workgroups"], 3, UINT32_MAX, positive=True))
    result.update(pipeline(row))
    require(all((size + denom - 1) // denom == count
                for size, denom, count in zip(result["elements"], result["denoms"], result["workgroups"])),
            "Dispatch workgroups differ")
    return result


def validate_graph(graph):
    summary, nodes, decisions, dispatches = (graph[x] for x in ("summary", "nodes", "decisions", "dispatches"))
    require(len(nodes) == summary["nodes"] and len(decisions) == summary["decisions"]
            and len(dispatches) == summary["dispatches"], "Graph record counts differ")
    require(sum(x["interval_ns"] for x in nodes) == summary["matrix_ns"], "Matrix timing sum differs")
    per_node = [[] for _ in nodes]
    per_decision = [[] for _ in decisions]
    for item in decisions:
        require(1 <= item["node"] <= len(nodes), "Decision node out of range")
        per_node[item["node"] - 1].append(item)
    ordinals = [0] * len(nodes)
    previous_decision = 0
    for item in dispatches:
        require(1 <= item["decision"] <= len(decisions), "Dispatch decision out of range")
        selected = decisions[item["decision"] - 1]
        require(item["node"] == selected["node"] and item["decision"] >= previous_decision,
                "Dispatch node/decision order differs")
        previous_decision = item["decision"]
        ordinals[item["node"] - 1] += 1
        require(item["ordinal"] == ordinals[item["node"] - 1], "Dispatch ordinal differs")
        per_decision[item["decision"] - 1].append(item)
    for entries in per_node:
        require(entries, "Node has no decision")
    for selected, entries in zip(decisions, per_decision):
        require(entries, "Decision has no dispatch")
        main = [x for x in entries if x["stage"] in ("main", "split_main")]
        require(main and all(all(x[k] == selected[k] for k in PIPELINE) for x in main),
                "Selected main pipeline differs")
        phase = 0
        for item in entries:
            next_phase = 0 if item["stage"] in PREPARE else 2 if item["stage"] == "split_reduce" else 1
            require(next_phase >= phase, "Dispatch stage order differs")
            phase = next_phase
        split = selected["route"] == "matrix" and selected["split_k"] > 1
        require(all(x["stage"] == ("split_main" if split else "main") for x in main)
                and sum(x["stage"] == "split_reduce" for x in entries) == (1 if split else 0),
                "Split/reduction dispatch completeness differs")


def parse_series(data, *, expected_graphs):
    require(type(data) is bytes and len(data) <= MAX_BYTES, "Bounded capture bytes required")
    require(type(expected_graphs) is int and 1 <= expected_graphs <= MAX_GRAPHS, "Explicit bounded graph count required")
    graphs, current, phase, graph_bytes, metadata_bytes, other_bytes = [], None, 0, 0, 0, 0
    start = 0
    while start < len(data):
        stop = data.find(b"\n", start)
        stop = len(data) if stop < 0 else stop + 1
        size = stop - start
        matrix = data.startswith(b"conflux_vk_matrix", start)
        if not matrix:
            other_bytes += size
            require(other_bytes <= MAX_OTHER_BYTES, "Original stderr bound exceeded")
            start = stop
            continue
        require(data.startswith(PREFIX, start), "Unknown matrix metadata version/prefix")
        metadata_bytes += size
        require(metadata_bytes <= MAX_METADATA_BYTES, "Metadata capture bound exceeded")
        require(size <= MAX_RECORD_BYTES, "Unterminated/oversized metadata record")
        kind, row = fields(data[start:stop])
        start = stop
        if kind == "begin":
            require(current is None and len(graphs) < expected_graphs, "Nested/excess graph")
            require(set(row) == BEGIN and row["status"] == "complete" and row["reason"] == "none",
                    "Unsupported graph or begin fields differ")
            summary = {key: number(value) for key, value in row.items() if key not in ("status", "reason")}
            require(summary["seq"] == len(graphs) + 1 and summary["graph_nodes"] <= MAX_GRAPH_NODES
                    and summary["queries"] <= summary["graph_nodes"], "Graph sequence/extent differs")
            require(summary["expected"] == summary["nodes"] <= min(MAX_NODES, summary["queries"])
                    and summary["nodes"] <= summary["decisions"] <= MAX_DECISIONS
                    and summary["decisions"] <= summary["dispatches"] <= MAX_DISPATCHES
                    and summary["attempted_dispatches"] == summary["dispatches"], "Graph declared counts differ")
            require(summary["matrix_ns"] + summary["rest_ns"] == summary["total_ns"], "Graph timing conservation differs")
            current = {"summary": summary, "nodes": [], "decisions": [], "dispatches": []}
            phase, graph_bytes = 0, size
        else:
            require(current is not None, "Record outside graph")
            graph_bytes += size
            require(graph_bytes <= MAX_GRAPH_BYTES, "Per-graph capture bound exceeded")
            summary = current["summary"]
            if kind in ("node", "decision", "dispatch"):
                next_phase = {"node": 0, "decision": 1, "dispatch": 2}[kind]
                require(next_phase >= phase, "Graph row order differs")
                phase = next_phase
                parsed = {"node": node, "decision": decision, "dispatch": dispatch}[kind](row)
                key = {"node": "nodes", "decision": "decisions", "dispatch": "dispatches"}[kind]
                previous = current[key]
                require(parsed["seq"] == summary["seq"] and parsed["item"] == len(previous) + 1
                        and len(previous) < summary[key], "Record sequence/count differs")
                if kind == "node":
                    require(1 <= parsed["query"] <= summary["queries"] and parsed["graph"] < summary["graph_nodes"]
                            and parsed["output_graph"] == parsed["graph"] + parsed["applied_count"] < summary["graph_nodes"]
                            and (not previous or (parsed["query"] > previous[-1]["query"]
                                                  and parsed["graph"] > previous[-1]["graph"])), "Node query/graph mapping differs")
                elif kind == "decision":
                    require(not previous or parsed["node"] >= previous[-1]["node"], "Decision node order differs")
                previous.append(parsed)
            elif kind == "end":
                require(set(row) == {"seq", "records", "complete"} and row["complete"] == "1"
                        and number(row["seq"]) == summary["seq"]
                        and number(row["records"]) == sum(summary[k] for k in ("nodes", "decisions", "dispatches")),
                        "Incomplete graph footer")
                validate_graph(current)
                current["metadata_bytes"] = graph_bytes
                graphs.append(current)
                current = None
            else:
                raise ValueError("Unknown matrix metadata record")
    require(current is None and len(graphs) == expected_graphs, "Missing/truncated graph series")
    return {"schema": 1, "passed": True, "qualified": False, "graphs": graphs,
            "metadata_bytes": metadata_bytes, "other_bytes": other_bytes,
            "scope": "Completed graph/query/decision/dispatch metadata only. Node intervals include all work in the query; "
                     "no per-dispatch duration, exclusive GPU time, request association or PCM proof."}


if __name__ == "__main__":
    import argparse
    import json
    import sys
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-graphs", type=int, required=True)
    arguments = parser.parse_args()
    print(json.dumps(parse_series(sys.stdin.buffer.read(MAX_BYTES + 1), expected_graphs=arguments.expected_graphs)))
