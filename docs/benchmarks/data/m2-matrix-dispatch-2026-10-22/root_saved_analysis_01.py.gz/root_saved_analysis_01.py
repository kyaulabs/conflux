"""Saved-data analysis only: no native runtime, model, audio or host queries."""
import hashlib, importlib.util, json, math, statistics, sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.dont_write_bytecode=True

def read(path):
    raw=path.read_bytes()
    return raw, {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def stats(values):
    values=sorted(values)
    return {'count':len(values),'minimum':min(values),'median':statistics.median(values),
            'p99_nearest_rank':values[math.ceil(.99*len(values))-1],'maximum':max(values)} if values else {'count':0}

raw,result_pin=read(BASE/'short-live-matrix-01/result.json'); result=json.loads(raw)
raw,pcm_pin=read(BASE/'pcm-equivalence-01/result.json'); pcm=json.loads(raw)
assert pcm['status']=='passed' and pcm['cleanup_complete'] and len(pcm['requests'])==16
assert all(r['exact_pcm_match'] for r in pcm['requests'])
assert result['cleanup_proven'] and result['profile_sources_unchanged'] and result['pins_unchanged']
assert result['native_trace']['passed'] and result['attention_series']['passed'] and result['matrix_series']['passed']
source,pin=read(BASE/'matrix_series.py')
assert pin['sha256']=='74a24f22fa1a888a58710fde896a875bf24acdb89a54b7ae306168354bcb8f15'
spec=importlib.util.spec_from_file_location('saved_matrix_parser',BASE/'matrix_series.py')
parser=importlib.util.module_from_spec(spec); exec(compile(source,str(BASE/'matrix_series.py'),'exec'),parser.__dict__)
raw,stderr_pin=read(BASE/'short-live-matrix-01/drm-traces/native-profiler.stderr')
assert stderr_pin['sha256']==result['matrix_series']['raw_stderr']['sha256']
parsed=parser.parse_series(raw,expected_graphs=result['matrix_series']['request_count'])
requests=result['attention_series']['requests']
assert len(requests)==len(parsed['graphs'])==22
rows=[]; by_node={}; signatures=[]
for graph,request,summary in zip(parsed['graphs'],requests,result['matrix_series']['graphs'],strict=True):
    s=graph['summary']; assert request['graph_seq']==s['seq']==summary['seq']
    assert request['request_id']==summary['request_id'] and s['total_ns']==summary['total_ns']
    dispatch_by_decision={d['item']:[x for x in graph['dispatches'] if x['decision']==d['item']] for d in graph['decisions']}
    slow=[]
    for node in graph['nodes']:
        decisions=[d for d in graph['decisions'] if d['node']==node['item']]
        ms=node['interval_ns']/1e6; identity=(node['graph'],node['query'],node['op'])
        by_node.setdefault(identity,[]).append(ms)
        slow.append({'graph_node':node['graph'],'query':node['query'],'op':node['op'],'interval_ms':ms,
                     'input0_ne':node['t0_ne'],'input1_ne':node['t1_ne'],'output_ne':node['output_ne'],
                     'decisions':[{'route':d['route'],'pipeline':d['pipeline'],'denoms':d['denoms'],
                                   'align':d['align'],'index64':d['index64'],'split_k':d['split_k'],
                                   'stages':[x['stage'] for x in dispatch_by_decision[d['item']]]} for d in decisions]})
    signature={'nodes':[{k:v for k,v in n.items() if k not in ('seq','interval_ns')} for n in graph['nodes']],
               'decisions':[{k:v for k,v in d.items() if k!='seq'} for d in graph['decisions']],
               'dispatches':[{k:v for k,v in d.items() if k!='seq'} for d in graph['dispatches']]}
    signatures.append(hashlib.sha256(json.dumps(signature,sort_keys=True).encode()).hexdigest())
    hop=request['validated_hop']; r=request['raw_result']
    rows.append({'request_id':request['request_id'],'graph_seq':s['seq'],'context':request['context'],
                 'validated':hop is not None,'hop_service_ms':hop['hop_service_ms'] if hop else None,
                 'native_elapsed_ms':r['elapsed_ms'],'graph_compute_ms':r['graph_compute_ms'],
                 'query_total_ms':s['total_ns']/1e6,'matrix_ms':s['matrix_ns']/1e6,
                 'rest_ms':s['rest_ns']/1e6,'attention_ms':result['attention_series']['graphs'][s['seq']-1]['flash_ns']/1e6,
                 'top_matrix_queries':sorted(slow,key=lambda r:r['interval_ms'],reverse=True)[:8]})
node_summary=sorted([{'graph_node':k[0],'query':k[1],'op':k[2],**stats(v)} for k,v in by_node.items()],key=lambda r:r['median'],reverse=True)
native=result['native']; controls=native['controls']
summary={'schema':1,'scope':'Actual saved matrix PCM16/player120 diagnostic. Instrumented, hidden and short; no normal latency, visible UI, musical accuracy, continuous thermal or hard-cancel qualification.',
         'source_result':result_pin,'source_pcm_result':pcm_pin,'source_stderr':stderr_pin,'parser':pin,
         'exact_PCM_cases':16,'player_functional_passed':result['functional_passed'],'service_target_met':result['service_target_met'],
         'service_hops':result['observations']['service_hops'],'controls':[{'kind':c['kind'],'generation_before':c['previous_generation'],'recovery_poll_upper_ms':(c['recovered_cursor_observed_ns']-c['issued_ns'])/1e6} for c in controls],
         'cancellation_scope':'Incomplete-generation seek exercised; old native attempt completed but had no validated hop. No direct hard-cancel/kill deadline measurement.',
         'audio':{k:native[k] for k in ('steady_starved_frames','control_starved_frames','invalid_buffers','source_read_failures','execution_deadline_misses','recording','recorded_audio','timing')},
         'thermal':result['thermal_summary'],'gpu_coverage':result['gpu_coverage'],'package_coverage':result['package_coverage'],
         'cleanup_proven':result['cleanup_proven'],'request_count':len(rows),
         'identical_matrix_geometry_and_routes':len(set(signatures))==1,
         'all_request_stats':{k:stats([r[k] for r in rows]) for k in ('native_elapsed_ms','graph_compute_ms','query_total_ms','matrix_ms','rest_ms','attention_ms')},
         'top_matrix_query_medians':node_summary[:12],'requests':rows}
output=BASE/'saved-analysis-01.json';output.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('service_hops','controls','request_count','identical_matrix_geometry_and_routes','all_request_stats')},indent=2))
print('Saved',output)
