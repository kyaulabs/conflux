"""Bind the successful desktop-entry, offline tests and immutable launch assets."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

BASE = Path(__file__).resolve().parent


def pin(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


entry = json.loads((BASE / 'actual-desktop-entry-check-01.json').read_text())
assert entry['passed'] and entry['real_desktop_dry_verified'] and entry['idle_inhibitions_released']
tests = (BASE / 'offline-checks-01.log').read_text()
count = re.search(r'Ran (\d+) tests', tests)
assert count and int(count.group(1)) >= 37 and tests.rstrip().endswith('OK')
plan = json.loads((BASE / 'laptop-plan.json').read_text())
assert plan['state'] == 'frozen_pending_fresh_readiness' and plan['arms'] == ['candidate']
assert plan['pins']['candidate'] == plan['pins']['baseline']
remote = json.loads((BASE / 'apollo-operations-binding-01.json').read_text())
assert remote['missing_readiness_prevents_host_queries'] and remote['hardware_started'] is False
names = ['source-binding-01.json', 'laptop-plan.json', 'run_laptop_pair.py', 'run_apollo_pair.py',
         'launch_both.py', 'observe_both.py', 'actual-desktop-entry-check-01.json', 'offline-checks-01.log',
         'apollo-operations-binding-01.json', 'local-build-receipt-01.json', 'apollo-build-accepted-01.json',
         'apollo_inside.py', 'apollo_player_check.py', 'private_sink.cpp', 'guard-installation-01.json', 'guard-policy-tests-01.json', 'prospective-scope-01.json', 'onedrive_pause.py', 'run_local_guarded.py', 'onedrive-proposal.json', 'candidate-publication-01.json', 'restoration-fix-verification-01.json', 'offline-count-01.json']
files = [pin(BASE / name) for name in names] + list(plan['pins'].values()) + [pin(path) for path in sorted(BASE.glob('test_*.py'))]
packet = dict(schema=1, state='frozen_pending_fresh_readiness', source_head=plan['source_head'],
              offline_checks_passed=True, hardware_started=False, host_tests_concurrent=True,
              no_retries=True, arms=['candidate'], seconds_per_arm=120, operator_seconds=1200,
              forced_redraw_interval_ms=16, quality='Best', strict_service_target_ms=4095,
              laptop_ceiling_W=15, power_profile_and_thermal_guard='Installed guard and 15 W ceiling unchanged; temporary sync pause requires explicit approval',
              local_files=files, remote_binding=remote['binding'], qualified=False,
              source_CI_clearance=plan['pins']['source_ci'], comparison_scope=plan['comparison_scope'],
              fresh_physical_conditions_required=True)
with (BASE / 'packet-pins.json').open('x') as stream:
    stream.write(json.dumps(packet, indent=2) + '\n')
result = subprocess.run(['/usr/bin/python3.14', '-B', str(BASE / 'launch_both.py')],
                        capture_output=True, text=True, timeout=20)
(BASE / 'packet-dry-check-01.log').write_text(result.stdout + result.stderr)
result.check_returncode()
assert json.loads(result.stdout)['hardware_started'] is False
assert not any((BASE / name).exists() for name in ('readiness.json', 'launch-reservation.json', 'both-dispatch.json', 'laptop-results-01'))
print(json.dumps(dict(packet=pin(BASE / 'packet-pins.json'), ready_for_fresh_conditions=True,
                      no_test_started=True, offline_launcher_tests=int(count.group(1)))))
