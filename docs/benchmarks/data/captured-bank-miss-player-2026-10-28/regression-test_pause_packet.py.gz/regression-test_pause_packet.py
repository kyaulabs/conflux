"""Catch a fully hashed but foreign service helper before host actions."""
from pathlib import Path
from types import SimpleNamespace
import copy,hashlib,importlib.util,json,sys,tempfile,time,unittest
from unittest.mock import Mock,patch
BASE=Path(__file__).resolve().parent

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
pair=load('binding_real_pair',BASE/'run_laptop_pair.py')
launch=load('binding_real_launcher',BASE/'launch_both.py')
guarded=load('binding_real_guarded',BASE/'run_local_guarded.py')

class PacketBindingTests(unittest.TestCase):
 def test_fully_pinned_foreign_helper_is_rejected_before_other_IO(self):
  p=json.loads((BASE/'laptop-plan.json').read_text())
  p['pins']['sync_pause_helper']['path']='/previous-packet/onedrive_pause.py'
  with patch.object(pair,'pin',side_effect=RuntimeError('file IO before binding validation')),self.assertRaisesRegex(AssertionError,'Pause helper must belong to this packet'):
   pair.verify(p)
 def test_fully_pinned_foreign_proposal_is_rejected_before_other_IO(self):
  p=json.loads((BASE/'laptop-plan.json').read_text())
  p['pins']['sync_pause_proposal']['path']='/previous-packet/onedrive-proposal.json'
  with patch.object(pair,'pin',side_effect=RuntimeError('file IO before binding validation')),self.assertRaisesRegex(AssertionError,'Pause proposal must belong to this packet'):
   pair.verify(p)
 def test_launcher_rejects_stale_helper_before_readiness_or_dispatch(self):
  with tempfile.TemporaryDirectory(dir=BASE)as d:
   b=Path(d);p=json.loads((BASE/'laptop-plan.json').read_text());p['pins']['sync_pause_helper']['path']='/previous-packet/onedrive_pause.py'
   (b/'laptop-plan.json').write_text(json.dumps(p))
   packet=dict(schema=1,offline_checks_passed=True,hardware_started=False,source_head='48b82030fcf6ab768c4f7b89d65021485cbf9b40',host_tests_concurrent=True,no_retries=True,local_files=[])
   (b/'packet-pins.json').write_text(json.dumps(packet))
   with patch.object(launch,'BASE',b),patch.object(launch.subprocess,'run')as run,self.assertRaisesRegex(AssertionError,'Pause helper must belong to this packet'):launch.verify()
   run.assert_not_called();self.assertFalse((b/'readiness.json').exists())
 def test_preexisting_same_packet_token_is_never_restored_or_overwritten(self):
  with tempfile.TemporaryDirectory(dir=BASE)as d:
   b=Path(d);driver=b/'run_laptop_pair.py';driver.write_text('# fixture')
   token=b/'onedrive-pause-state.json';original=b'{"restore_complete":false,"question_item_id":"previous"}\n';token.write_bytes(original)
   p=dict(pins=dict(driver=launch.pin(driver),sync_pause_helper={'fixture':True}))
   (b/'laptop-plan.json').write_text(json.dumps(p));(b/'readiness.json').write_text(json.dumps(dict(question_item_id='current',onedrive_pause_approved=True,operator_deadline_monotonic=time.monotonic()+1200)))
   helper=SimpleNamespace(TOKEN=token,PROPOSAL=b/'onedrive-proposal.json',pause=Mock(),verify_held=Mock(),restore=Mock())
   runner=SimpleNamespace(clock=Mock(),pin=Mock(return_value={'sha256':'fixture'}),verify=Mock(),load=Mock(return_value=helper),main=Mock(return_value=0))
   with patch.object(guarded,'BASE',b),patch.object(guarded,'load',return_value=runner),patch.object(sys,'argv',['fixture','--run']),self.assertRaisesRegex(AssertionError,'Previous pause token belongs to an earlier attempt'):guarded.main()
   helper.pause.assert_not_called();helper.restore.assert_not_called();runner.main.assert_not_called()
   self.assertEqual(token.read_bytes(),original);self.assertFalse((b/'guarded-outcome.json').exists())
 def test_real_guarded_import_path_uses_own_helper_and_stops_before_service_actions(self):
  with tempfile.TemporaryDirectory(dir=BASE)as d:
   b=Path(d)
   for name in ('run_laptop_pair.py','onedrive_pause.py','onedrive-proposal.json'):(b/name).write_bytes((BASE/name).read_bytes())
   p=json.loads((BASE/'laptop-plan.json').read_text())
   for key,name in [('driver','run_laptop_pair.py'),('sync_pause_helper','onedrive_pause.py'),('sync_pause_proposal','onedrive-proposal.json')]:p['pins'][key]=launch.pin(b/name)
   (b/'laptop-plan.json').write_text(json.dumps(p))
   from datetime import datetime,timezone
   human=dict(mode=pair.MODE,plan_sha256=launch.pin(b/'laptop-plan.json')['sha256'],recorded_at_utc=datetime.now(timezone.utc).isoformat(),operator_deadline_monotonic=time.monotonic()+1200,operator_seconds=1200,human_reply='Generated offline fixture; not human readiness',question_item_id='offline-only',onedrive_pause_approved=True)
   human.update({k:True for k in ('AC_power','lid_open','visible_window','screen_awake','Codex_minimized','other_work_paused','no_suspend')})
   (b/'readiness.json').write_text(json.dumps(human))
   original_load=guarded.load;seen=[]
   def imported(name,path):
    runner=original_load(name,path);actual_load=runner.load
    def helper_load(name,row):
     helper=actual_load(name,row)
     self.assertEqual(helper.TOKEN,b/'onedrive-pause-state.json');self.assertEqual(helper.PROPOSAL,b/'onedrive-proposal.json')
     seen.append(str(helper.TOKEN))
     helper.pause=Mock(side_effect=RuntimeError('Offline stop before any service action'))
     return helper
    runner.load=helper_load
    return runner
   with patch.object(guarded,'BASE',b),patch.object(guarded,'load',side_effect=imported),patch.object(sys,'argv',['fixture','--run']),patch('subprocess.run')as run,patch('subprocess.check_output')as query,self.assertRaisesRegex(RuntimeError,'Offline stop before any service action'):guarded.main()
   run.assert_not_called();query.assert_not_called();self.assertEqual(len(seen),1)
   self.assertFalse((b/'laptop-results-01').exists());self.assertFalse((b/'onedrive-pause-state.json').exists())
   outcome=json.loads((b/'guarded-outcome.json').read_text());self.assertIsNone(outcome['owner_exit']);self.assertFalse(outcome['passed'])

if __name__=='__main__':unittest.main(verbosity=2)
