"""Set up the existing unarmed private sink and invoke the private-audio owner."""
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import time

source=Path('/operations/private_sink.cpp')
assert source.is_file() and source.stat().st_size<64*1024
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','--libs','libpipewire-0.3'],text=True))
command=['c++','-std=c++20','-O2','-Wall','-Wextra',str(source),'-o','/results/private_sink']+flags
with Path('/results/sink-build.log').open('x') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
for name in ['tmp','home','desktop-cache']:Path('/results',name).mkdir(mode=0o700)
environment=dict(os.environ,QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software',QT_QUICK_CONTROLS_STYLE='Basic',
    TMPDIR='/results/tmp',HOME='/results/home',XDG_CACHE_HOME='/results/desktop-cache')
command=['/usr/bin/python','-B','/src/tools/experiments/private_routing_check.py','/operations/player_check.py',
    '/results/private-player-01','--functional-only']
began=time.monotonic()
with Path('/results/private-player-runner.log').open('x') as log:
    result=subprocess.run(command,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=260)
receipt=dict(exit=result.returncode,command=command,seconds=time.monotonic()-began,qualified=False,
    sink_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    sink_implementation='Repository Sink with enclosing deadline extended; constant-PCM oracle never armed')
Path('/results/inside-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(result.returncode)
