"""Prepare one unarmed current-player check on each host, preserving the prior results."""
from pathlib import Path
import ast,hashlib,json,subprocess,textwrap
ROOT=Path('/home/kyau/projects/kyaulabs/conflux');NEW=Path(__file__).resolve().parent
OLD=ROOT/'build/m2-onedrive-isolation-player-01';FIX=ROOT/'build/m2-hour-harness-fixes-01'
BASE=ROOT/'build/m2-prepared-miss-player-02'
REMOTE='/srv/conflux-tests/work/captured-bank-miss-20261028-02'
REMOTE_BUILD='/srv/conflux-tests/work/captured-bank-miss-20261028-01'
REMOTE_OLD='/srv/conflux-tests/work/onedrive-isolation-player-20261028-01'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
 '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
 '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs','python3 -']
def read(p):return json.loads(p.read_text())
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink(),str(p)
 with p.open('rb')as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=sha)
def save(p,value):
 with p.open('x')as f:f.write(json.dumps(value,indent=2)+'\n')
def copy_scripts(BASE,head):
 replacements={'m2-onedrive-isolation-player-20261028-01':'m2-prepared-miss-player-20261028-02',
  'conflux-m2-onedrive-player-':'conflux-m2-prepared-miss-',
  REMOTE_OLD:REMOTE,'dfff55ea78b6fcbe633a178e996371238803013d':head}
 for name in ['run_laptop_pair.py','run_apollo_pair.py','launch_both.py','observe_both.py',
  'check_desktop_entry.py','freeze_packet.py','test_launch_both.py','test_pair_support.py','test_apollo_pair.py']:
  text=(OLD/name).read_text()
  for old,new in replacements.items():text=text.replace(old,new)
  for host in ('laptop','apollo','offline-entry'):
   text=text.replace('conflux-m2-prepared-miss-'+host+'-20261028-01.service',
    'conflux-m2-prepared-miss-'+host+'-20261028-02.service')
  if name=='run_laptop_pair.py':
   text=text.replace('0<=age<=90','0<=age<=180').replace('deadline-time.monotonic()-45','deadline-time.monotonic()-150').replace('min(deadline-45,started+540)','min(deadline-150,started+540)')
   marker=" for row in plan['pins'].values():assert pin(row['path'])==row,row['path']"
   assert text.count(marker)==1
   text=text.replace(marker," assert Path(plan['pins']['sync_pause_helper']['path'])==BASE/'onedrive_pause.py','Pause helper must belong to this packet'\n assert Path(plan['pins']['sync_pause_proposal']['path'])==BASE/'onedrive-proposal.json','Pause proposal must belong to this packet'\n"+marker)
  if name=='launch_both.py':
   text=text.replace("str(int(remaining)-30)+'s','--property=TimeoutStopSec=15s'","str(int(remaining)-90)+'s','--property=TimeoutStopSec=60s'")
   assert text.count("str(int(remaining)-90)+'s','--property=TimeoutStopSec=60s'")==1
   marker=" for row in packet['local_files']:assert pin(row['path'])==row,row['path']"
   assert text.count(marker)==1
   text=text.replace(marker," plan=json.loads((BASE/'laptop-plan.json').read_text())\n assert Path(plan['pins']['sync_pause_helper']['path'])==BASE/'onedrive_pause.py','Pause helper must belong to this packet'\n assert Path(plan['pins']['sync_pause_proposal']['path'])==BASE/'onedrive-proposal.json','Pause proposal must belong to this packet'\n assert not(BASE/'onedrive-pause-state.json').exists(),'Previous pause token belongs to an earlier attempt'\n"+marker)
  if name=='run_apollo_pair.py':
   text=text.replace('/srv/conflux-tests/work/description-threads-player-20261028-01',REMOTE)
   text=text.replace("RUN='onedrive-isolation-player-20261028-01'","RUN='captured-bank-miss-20261028-02'")
   text=text.replace("Path('"+REMOTE+"/source')","Path(binding['source_root'])").replace("Path('"+REMOTE+"/native')","Path(binding['native_root'])")
  if name=='observe_both.py':
   marker=" if result.exists():out['pair']=read(result)"
   assert text.count(marker)==1
   text=text.replace(marker,marker+"\n if local and (base/'guarded-outcome.json').exists():out['guarded_outcome']=read(base/'guarded-outcome.json')")
  if name=='check_desktop_entry.py':text=text.replace('until=time.monotonic()+15','until=time.monotonic()+30')
  if name=='test_pair_support.py':
   text=text.replace('timedelta(seconds=91),2091','timedelta(seconds=181),2181')
   text=text.replace("BASE.parent/'m2-synchronized-redraw-comparison-01/cases/baseline/output-01/result.json'",
    "Path('/home/kyau/projects/kyaulabs/conflux/build/m2-synchronized-redraw-comparison-01/cases/baseline/output-01/result.json')")
  if name=='test_launch_both.py':
   marker="  (self.base/'laptop-plan.json').write_text('{}')"
   assert text.count(marker)==1
   text=text.replace(marker,"  helper=self.base/'onedrive_pause.py';helper.write_text('# offline fixture')\n  proposal=self.base/'onedrive-proposal.json';proposal.write_text('{}')\n  (self.base/'laptop-plan.json').write_text(json.dumps(dict(pins=dict(sync_pause_helper=launch.pin(helper),sync_pause_proposal=launch.pin(proposal)))))")
  if name=='test_apollo_pair.py':
   text=text.replace('files=[],driver_cache_seed=str(seed),','files=[],source_root=str(self.base/\'source\'),native_root=str(self.base/\'native\'),driver_cache_seed=str(seed),')
   marker="            self.assertIn('type=bind,src=/'+arm+',dst=/runtime,readonly',cmd)"
   assert text.count(marker)==1
   text=text.replace(marker,marker+"\n            for name,dest in [('source','/src'),('native','/player')]:self.assertIn('type=bind,src='+str(self.base/name)+',dst='+dest+',readonly',cmd)")
  if name=='freeze_packet.py':
   text=text.replace("assert re.search(r'Ran 37 tests', tests) and tests.rstrip().endswith('OK')",
    "count = re.search(r'Ran (\\d+) tests', tests)\nassert count and int(count.group(1)) >= 37 and tests.rstrip().endswith('OK')")
   text=text.replace("offline_launcher_tests=37","offline_launcher_tests=int(count.group(1))")
   text=text.replace("files = [pin(BASE / name) for name in names] + list(plan['pins'].values())",
    "files = [pin(BASE / name) for name in names] + list(plan['pins'].values()) + [pin(path) for path in sorted(BASE.glob('test_*.py'))]")
   text=text.replace("'onedrive-proposal.json']","'onedrive-proposal.json', 'candidate-publication-01.json', 'restoration-fix-verification-01.json', 'offline-count-01.json']")
  ast.parse(text);(BASE/name).write_text(text)
 for name in ['onedrive_pause.py','run_local_guarded.py','test_onedrive_pause.py','private_sink.cpp']:
  (BASE/name).write_bytes((FIX/name).read_bytes())
 text=(BASE/'run_local_guarded.py').read_text()
 marker="    outcome = dict(schema=1, owner_exit=None, passed=False,"
 assert text.count(marker)==1
 text=text.replace(marker,"    assert pause.TOKEN == BASE / 'onedrive-pause-state.json', 'Pause helper must belong to this packet'\n    assert pause.PROPOSAL == BASE / 'onedrive-proposal.json', 'Pause proposal must belong to this packet'\n    assert not pause.TOKEN.exists(), 'Previous pause token belongs to an earlier attempt'\n"+marker)
 (BASE/'run_local_guarded.py').write_text(text)
 text=(BASE/'test_onedrive_pause.py').read_text()
 text=text.replace("helper=SimpleNamespace(TOKEN=self.token,","helper=SimpleNamespace(TOKEN=self.token,PROPOSAL=self.root/'onedrive-proposal.json',")
 # These wrapper fixtures must create their own token during pause, never reuse one.
 text=text.replace("self.token = self.root / 'state.json'","self.token = self.root / 'onedrive-pause-state.json'")
 text=text.replace("        self.token.write_text(json.dumps(dict(pause_held_through_native_cleanup=True,restore_complete=False)))\n        helper=SimpleNamespace", "        def paused(*args):self.token.write_text(json.dumps(dict(pause_held_through_native_cleanup=True,restore_complete=False)))\n        helper=SimpleNamespace")
 text=text.replace("        self.token.write_text(json.dumps(dict(pause_held_through_native_cleanup=True,restore_complete=False)))\n        def restored():", "        def paused(*args):self.token.write_text(json.dumps(dict(pause_held_through_native_cleanup=True,restore_complete=False)))\n        def restored():")
 text=text.replace("PROPOSAL=self.root/'onedrive-proposal.json',pause=Mock(),verify_held=Mock()", "PROPOSAL=self.root/'onedrive-proposal.json',pause=Mock(side_effect=paused),verify_held=Mock()")
 ast.parse(text);(BASE/'test_onedrive_pause.py').write_text(text)
 for name in ['apollo_inside.py','apollo_player_check.py','onedrive-proposal.json','guard-installation-01.json','guard-policy-tests-01.json']:
  (BASE/name).write_bytes((OLD/name).read_bytes())

 (BASE/'test_cleanup_bounds.py').write_bytes((NEW/'test_cleanup_bounds.py').read_bytes())
 (BASE/'test_pause_packet.py').write_bytes((NEW/'test_pause_packet.py').read_bytes())

def prepare():
 publication=NEW/'publication-01/publication-complete-01.json';ci=read(publication);head=ci['source']
 assert ci['all_nine_CI_jobs_passed'] and ci['merge_tree_matches_source']
 builds=read(NEW/'player-builds-complete-01.json');assert builds['source']==head and all(v['passed'] and v['O2_without_coverage_or_fast_math']for v in builds['hosts'].values())
 for row in read(OLD/'packet-pins.json')['local_files']:assert pin(row['path'])==row,row['path']
 local=NEW/'player-build-01';binding=read(local/'source-binding-01.json');assert binding['source_head']==head
 assert pin(builds['hosts']['laptop']['binary']['path'])==builds['hosts']['laptop']['binary']
 assert not BASE.exists();BASE.mkdir(mode=0o700)
 copy_scripts(BASE,head)
 proposal=read(BASE/'onedrive-proposal.json')
 for name in ['unit_file','executable']:assert pin(proposal[name]['path'])==proposal[name],name
 text=(BASE/'apollo_inside.py').read_text().replace('Unmodified repository Sink class; constant-PCM oracle never armed',
  'Repository Sink with enclosing deadline extended; constant-PCM oracle never armed');(BASE/'apollo_inside.py').write_text(text)
 (BASE/'source-binding-01.json').write_bytes((local/'source-binding-01.json').read_bytes())
 (BASE/'local-build-receipt-01.json').write_bytes((local/'build-receipt-01.json').read_bytes())
 save(BASE/'apollo-build-accepted-01.json',builds['hosts']['apollo'])
 (BASE/'candidate-publication-01.json').write_bytes(publication.read_bytes())
 (BASE/'restoration-fix-verification-01.json').write_bytes((FIX/'verification-01.json').read_bytes())
 plan=read(OLD/'laptop-plan.json');plan.update(mode='m2-prepared-miss-player-20261028-02',
  source_head=head,source_root=str(local/'source'),source_files=binding['files'],
  comparison_scope='One current-player candidate check on each host. Compare descriptively with the preserved short run and failed hour; no fresh paired or counterbalanced causal claim.',
  changes_from_previous_player=['Captured-key cache miss before source/engine hashing or descriptor start'],
  only_laptop_host_policy_change='No new host policy; repeat the explicitly approved temporary OneDrive pause and restore it afterward.')
 plan['pins'].update(driver=pin(BASE/'run_laptop_pair.py'),binary=pin(local/'native/conflux-manual-playback-soak'),
  wrapper=pin(local/'source/tools/experiments/run_manual_playback_soak.py'),source_ci=pin(BASE/'candidate-publication-01.json'),
  sync_pause_helper=pin(BASE/'onedrive_pause.py'),sync_pause_proposal=pin(BASE/'onedrive-proposal.json'))
 save(BASE/'laptop-plan.json',plan)
 save(BASE/'prospective-scope-01.json',dict(schema=1,hardware_started=False,source=head,
  prior_short=pin(OLD/'analysis-01/results-summary-01.json'),
  prior_hour=pin(ROOT/'build/m2-onedrive-player-hour-01/analysis-01/results-summary-01.json'),
  only_measured_code_factor=plan['changes_from_previous_player'],
  model_runtime_exporter_worker_service_tracks_UI_cache_seed_power_caps_unchanged=True,
  compiler='O2 with debug information; no coverage or fast math',quality='Best',strict_target_ms=4095,
  seconds_per_host=120,total_operator_seconds=1200,host_tests_concurrent=True,retries=False,
  fresh_physical_conditions_required=True,explicit_onedrive_pause_approval_required=True,
  lifecycle_corrections=['Bounded post-start executable confirmation after the sole service start',
  'Restore service within original operator deadline','Private sink lifetime covers enclosing bounded player'],
  hard_worker_cancellation_exercised=False,no_milestone_or_release_gate_waived=True))
 ops={'apollo_inside.py':'inside.py','apollo_player_check.py':'player_check.py','private_sink.cpp':'private_sink.cpp','run_apollo_pair.py':'run_pair.py'}
 files={remote:(BASE/name).read_text()for name,remote in ops.items()}
 header='BASE='+repr(REMOTE)+'\nBUILD='+repr(REMOTE_BUILD)+'\nOLD='+repr(REMOTE_OLD)+'\nFILES='+repr(files)+'\nCI='+repr(ci)+'\nHEAD='+repr(head)+'\n'
 code=r'''
 from pathlib import Path
 import hashlib,json,subprocess
 base=Path(BASE);old=Path(OLD);build_base=Path(BUILD);base.mkdir(mode=0o700);ops=base/'operations';ops.mkdir(mode=0o700)
 def pin(p):
  assert p.is_file() and not p.is_symlink()
  with p.open('rb')as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
  return dict(path=str(p),bytes=p.stat().st_size,sha256=sha)
 binding=json.loads((old/'operations/binding.json').read_text())
 for row in binding['files']:assert pin(Path(row['path']))==row,row['path']
 source=json.loads((build_base/'source-binding-01.json').read_text());assert source['source_head']==HEAD
 build=json.loads((build_base/'build-receipt-01.json').read_text());assert build['passed'] and build['source_head']==HEAD and build['O2_without_coverage_or_fast_math']
 old_roots=[str(old/'operations')+'/',binding['source_root']+'/',binding['native_root']+'/']
 binding['files']=[row for row in binding['files']if not any(row['path'].startswith(prefix)for prefix in old_roots)]
 for name,text in FILES.items():(ops/name).write_text(text)
 (ops/'player_check.py').chmod(0o700)
 (ops/'exact-outputs.json').write_bytes((old/'operations/exact-outputs.json').read_bytes())
 (ops/'source-ci.json').write_text(json.dumps(CI,indent=2)+chr(10))
 for name in [*FILES,'exact-outputs.json','source-ci.json']:binding['files'].append(pin(ops/name))
 for row in source['files']:
  actual=pin(build_base/'source'/row['file']);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'];binding['files'].append(actual)
 player=pin(build_base/'native/conflux-manual-playback-soak');assert player['bytes']==build['binary']['bytes'] and player['sha256']==build['binary']['sha256']
 binding['files'].extend([player,pin(build_base/'source-binding-01.json'),pin(build_base/'build-receipt-01.json')])
 binding.update(source_head=HEAD,player=player,source_root=str(build_base/'source'),native_root=str(build_base/'native'),
  source_ci=str(ops/'source-ci.json'),exact_outputs=str(ops/'exact-outputs.json'),
  scope='Current captured-key player with unchanged Best runtime and private virtual audio; descriptive control, no laptop or physical qualification')
 (ops/'binding.json').write_text(json.dumps(binding,indent=2)+chr(10))
 dry=subprocess.run(['python3','-B',str(ops/'run_pair.py')],capture_output=True,text=True,timeout=30);assert dry.returncode==0,dry.stderr
 assert json.loads(dry.stdout)['GPU_started']is False
 missing=subprocess.run(['python3','-B',str(ops/'run_pair.py'),'--run'],capture_output=True,text=True,timeout=10)
 assert missing.returncode!=0 and 'FileNotFoundError' in missing.stderr and str(base/'pair-readiness-01.json')in missing.stderr
 assert not any((base/n).exists()for n in ['pair-readiness-01.json','pair-reservation-01.json','pair-result-01.json','cases'])
 print(json.dumps(dict(schema=1,binding=pin(ops/'binding.json'),binding_data=binding,dry=json.loads(dry.stdout),
  missing_readiness_prevents_host_queries=True,missing_readiness_stderr=missing.stderr,hardware_started=False)))
 '''
 code=textwrap.dedent(code)
 compile(header+code,'apollo-preparation','exec')
 r=subprocess.run(SSH,input=header+code,text=True,capture_output=True,timeout=60)
 (BASE/'remote-preparation.stdout.log').write_text(r.stdout);(BASE/'remote-preparation.stderr.log').write_text(r.stderr)
 r.check_returncode();remote=json.loads(r.stdout);save(BASE/'apollo-operations-binding-01.json',remote)
 print(json.dumps(dict(prepared=True,source=head,remote_files=len(remote['binding_data']['files']),hardware_started=False)))

if __name__=='__main__':prepare()
