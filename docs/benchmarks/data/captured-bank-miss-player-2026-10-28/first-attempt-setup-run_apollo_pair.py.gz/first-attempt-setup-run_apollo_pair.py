"""Own one unchanged 16 ms Apollo control; dry by default, original clock only."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time

BASE=Path('/srv/conflux-tests/work/captured-bank-miss-20261028-01')
OPS=BASE/'operations'
DOCKER=['sudo','-n','env','DOCKER_CONFIG=/srv/conflux-tests/docker-client','docker',
    '--host','unix:///srv/conflux-tests/daemon/docker.sock']
IMAGE='sha256:f413527ef82728332244bec1dab8ea99f62dc678514340e2c569f4ce97bae919'
RUN='onedrive-isolation-player-20261028-01'
ARMS=('candidate',)

def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:f.write(json.dumps(value,indent=2,allow_nan=False)+'\n')
def verify():
    binding=read(OPS/'binding.json')
    assert binding['schema']==1 and binding['source_head']=='48b82030fcf6ab768c4f7b89d65021485cbf9b40'
    for row in binding['files']:
        p=Path(row['path']);assert p.is_absolute() and not p.is_symlink()
        raw=p.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],str(p)
    proof=read(Path(binding['exact_outputs']))
    assert proof['correctness_complete_both_hosts'] and proof['timing_qualification'] is False
    for arm in ARMS:
        assert proof['hosts']['apollo']['arms']['baseline']['requests']==proof['hosts']['apollo']['arms']['baseline']['exact_outputs']==16
        assert all(binding['runtimes'][arm][k]==proof['runtime_identities']['apollo']['baseline'][k] for k in ('bytes','sha256'))
    assert binding['model']['sha256']==proof['runtime_identities']['apollo']['model']['sha256']
    clearance=read(Path(binding['source_ci']))
    assert clearance['source']=='48b82030fcf6ab768c4f7b89d65021485cbf9b40' and clearance['all_nine_CI_jobs_passed'] and clearance['merge_tree_matches_source']
    return binding

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true');args=parser.parse_args()
    if not args.run:
        verify();print(json.dumps(dict(verified=True,model_started=False,GPU_started=False,host_audio_opened=False)));return
    # No driver/container/host queries before current human conditions are read.
    human=read(BASE/'pair-readiness-01.json')
    assert human['schema']==1 and human['source_head']=='48b82030fcf6ab768c4f7b89d65021485cbf9b40'
    assert human['operator_seconds']==1200 and human['host_tests_concurrent'] and not human['retries']
    now=time.monotonic();deadline=human['apollo_deadline_monotonic']
    utc=datetime.datetime.now(datetime.timezone.utc)
    original=datetime.datetime.fromisoformat(human['original_readiness_utc'])
    age=(utc-original).total_seconds()
    assert 0<=age<120 and 650<=deadline-now<=1200-age+1
    assert human['human_reply'] and human['question_item_id'] and human['physical_conditions_confirmed']
    assert not (BASE/'pair-reservation-01.json').exists()
    binding=verify()
    assert binding['state']=='frozen_pending_fresh_readiness'
    assert human['binding_sha256']==hashlib.sha256((OPS/'binding.json').read_bytes()).hexdigest()
    assert json.loads(subprocess.check_output(DOCKER+['info','--format','{{json .DockerRootDir}}'],timeout=5))=='/srv/conflux-tests/docker-data'
    assert subprocess.check_output(DOCKER+['ps','-aq'],text=True,timeout=5).strip()==''
    assert subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader,nounits'],text=True,timeout=5).strip()==''
    for arm in ARMS:
        case=BASE/'cases'/arm
        assert not case.exists()
    save(BASE/'pair-reservation-01.json',dict(original_readiness_utc=human['original_readiness_utc'],deadline_monotonic=deadline,no_retries=True))
    report=dict(schema=1,pair_complete=False,cleanup_complete=False,qualified=False,arms={},errors=[],original_readiness_utc=human['original_readiness_utc'],
        original_deadline_monotonic=deadline,host_audio=False,protected_resources_changed=False,gpu_power_policy_changed=False)
    active=None;monitor=None;container_process=None
    def interrupted(signum,frame):raise InterruptedError('Owned pair received signal'+str(signum))
    signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
    def close_container():
        nonlocal active,container_process,monitor
        if active is not None:
            found=subprocess.run(DOCKER+['inspect',active],capture_output=True,text=True,timeout=5)
            if found.returncode==0:
                c=json.loads(found.stdout)[0]
                assert c['Image']==IMAGE and c['Config']['Labels'].get('org.kyaulabs.conflux.run')==RUN
                subprocess.run(DOCKER+['rm','--force',c['Id']],capture_output=True,check=True,timeout=15)
            assert subprocess.run(DOCKER+['inspect',active],capture_output=True,timeout=5).returncode!=0
        if container_process is not None:
            try:container_process.wait(timeout=5)
            except subprocess.TimeoutExpired:container_process.kill();container_process.wait(timeout=5)
        if monitor is not None:
            monitor.terminate()
            try:monitor.wait(timeout=5)
            except subprocess.TimeoutExpired:monitor.kill();monitor.wait(timeout=5)
        active=container_process=monitor=None
    try:
        for arm in ARMS:
            assert deadline-time.monotonic()>=350,'No room on original human clock for another arm'
            verify()
            case=BASE/'cases'/arm;case.mkdir(mode=0o700,parents=True)
            seed=Path(binding['driver_cache_seed'])
            shutil.copytree(seed,case/'driver-cache')
            name='conflux-'+RUN+'-'+arm
            assert subprocess.run(DOCKER+['inspect',name],capture_output=True,timeout=5).returncode!=0
            active=name
            command=DOCKER+['run','--rm','--name',name,'--init','--runtime=runc',
                '--label','org.kyaulabs.conflux.tests=1','--label','org.kyaulabs.conflux.run='+RUN,
                '--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges:true',
                '--user=1000:1000','--pids-limit=1024','--memory=8g',
                '--device','nvidia.com/gpu=GPU-c58fa4ef-cda8-be9f-eb37-caeb7cf7d42b',
                '--tmpfs=/tmp:rw,nosuid,nodev,size=256m,mode=1777',
                '--env','CONFLUX_STAGING_ARM='+arm,'--env','CONFLUX_EXPECTED_RUNTIME_SHA256='+binding['runtimes'][arm]['sha256'],'--env','__GL_SHADER_DISK_CACHE=1',
                '--env','__GL_SHADER_DISK_CACHE_PATH=/driver-cache']
            mounts=[(Path('/srv/conflux-tests/work/captured-bank-miss-20261028-01/source'),'/src',True),(Path('/srv/conflux-tests/work/captured-bank-miss-20261028-01/native'),'/player',True),
                (Path(binding['runtimes'][arm]['path']).parent,'/runtime',True),
                (Path('/srv/conflux-tests/work/htdemucs-f16.gguf'),'/model/htdemucs-f16.gguf',True),
                (Path(binding['inputs_root']),'/inputs',True),(OPS,'/operations',True),
                (case/'driver-cache','/driver-cache',False),(case,'/results',False)]
            for src,dst,ro in mounts:command+=['--mount','type=bind,src='+str(src)+',dst='+dst+(',readonly' if ro else '')]
            command+=[IMAGE,'timeout','--signal=TERM','--kill-after=5s','300','python','-B','/operations/inside.py']
            began=time.monotonic();save(case/'dispatch.json',dict(command=command,started_monotonic=began,deadline_monotonic=deadline,source_head=binding['source_head']))
            with (case/'gpu-observations.csv').open('x') as gpu,(case/'container.log').open('x') as log:
                monitor=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,temperature.gpu,power.draw,power.limit,utilization.gpu,memory.used',
                    '--format=csv,noheader,nounits','--loop-ms=1000'],stdout=gpu,stderr=gpu)
                container_process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
                exit_code=container_process.wait(timeout=min(315,deadline-time.monotonic()-30))
            close_container()
            routing=read(case/'private-player-01/result.json')
            assessed=read(case/'private-player-01/recordings/actual-player/assessment.json')
            verify()
            clean=routing.get('daemon_reaped') is True and routing.get('cleanup',{}).get('only_dummy_driver_remains') is True and assessed.get('sink_reaped') is True
            complete=assessed.get('measurement_complete') is True
            row=dict(exit=exit_code,elapsed_seconds=time.monotonic()-began,measurement_complete=complete,cleanup_complete=clean,
                native_passed=assessed.get('passed'),native_functional_passed=assessed.get('native_functional_passed'),routing_passed=routing.get('passed'),service_target_met=assessed.get('service_target_met'),
                service_hops=assessed.get('observations',{}).get('service_hops'),qualified=False,hard_cancellation_exercised=False)
            save(case/'receipt.json',row);report['arms'][arm]=row
            assert clean,'Private graph/daemon cleanup not proven'
            assert complete,'Incomplete first arm retained; no automatic retry or next arm'
        report['pair_complete']=True
    except BaseException as error:report['errors'].append(dict(type=type(error).__name__,message=str(error)[:2000]))
    finally:
        try:close_container()
        except BaseException as error:report['errors'].append(dict(phase='cleanup',type=type(error).__name__,message=str(error)[:2000]))
        report['cleanup_complete']=not report['errors'] or bool(report['arms']) and all(x['cleanup_complete'] for x in report['arms'].values()) and active is None
        report['finished_monotonic']=time.monotonic();report['within_original_operator_window']=report['finished_monotonic']<=deadline
        save(BASE/'pair-result-01.json',report)
    print(json.dumps(report,allow_nan=False),flush=True)
    raise SystemExit(0 if report['pair_complete'] and report['cleanup_complete'] else 1)

if __name__=='__main__':main()
