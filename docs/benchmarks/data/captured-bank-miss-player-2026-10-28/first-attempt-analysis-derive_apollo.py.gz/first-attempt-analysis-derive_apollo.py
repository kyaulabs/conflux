"""Recompute the completed secondary result without treating the skipped laptop as a pass."""
from pathlib import Path
import hashlib,json,math
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent
P=BASE/'apollo/cases/candidate/private-player-01/recordings/actual-player'
n=json.loads((P/'native-result.json').read_text());assessment=json.loads((P/'assessment.json').read_text())
rows=[json.loads(s)for s in (P/'observations.jsonl').read_text().splitlines()]
records=[r for r in rows if r['type']=='record'];chunks=[r for r in records if r['kind']==5]
assert [r['ordinal']for r in records]==list(range(1,len(records)+1))
assert len(records)==n['observation_counters']['attempted']==n['observation_counters']['retained']
assert n['observation_counters']['dropped']==n['observation_counters']['invalid_clock_reads']==0
assert all(r['hop_service_present']and math.isfinite(r['hop_service_ms'])and r['hop_service_ms']>=0 for r in chunks)
v=sorted(r['hop_service_ms']for r in chunks)
hops=dict(count=len(v),maximum_ms=v[-1],nearest_rank_p99_ms=v[math.ceil(.99*len(v))-1],strict_target_ms=4095,at_or_above_target=sum(x>=4095 for x in v),complete=True)
assert hops==assessment['observations']['service_hops']
assert n['measurement_intervals_closed']and all(not r['aborted']for r in n['intervals'])
steady=sum(r['starved_frames']for r in n['intervals']if r['kind']=='steady');controls=sum(r['starved_frames']for r in n['intervals']if r['kind']!='steady')
assert steady==n['steady_starved_frames']and controls==n['control_starved_frames']
assert sum(r['starved_b']for r in n['intervals'])==0
assert len(n['manual_controls'])==16 and all(r['acknowledged']for r in n['manual_controls'])
seek=next(r for r in n['controls']if r['kind']=='incomplete_generation_seek')
assert any(r['kind']==4 and r['generation']==seek['previous_generation']and r['observed_ns']<=seek['issued_ns']for r in records)
assert not any(r['kind']==8 and r['generation']==seek['previous_generation']and r['observed_ns']<=seek['issued_ns']for r in records)
assert all(r['recovered_cursor_observed_ns']>=r['issued_ns']for r in n['controls'])and n['last_recovery_complete']
rec=n['recording'];assert rec['status']=='Complete'and not rec['error']and rec['acceptedFrames']==rec['writtenFrames']==n['recorded_audio']['frames']and rec['overflowFrames']==0
for key in ('execution_deadline_misses','invalid_buffers','rejected_commands','source_read_failures'):assert n[key]==0
out=dict(schema=1,source='48b82030fcf6ab768c4f7b89d65021485cbf9b40',qualified=False,no_milestone_or_release_gate_closed=True,no_causal_AB_claim=True,
 laptop=dict(workload_started=False,latency_result=None,stop_reason='Frozen laptop plan selected the previous isolation packet sync_pause_helper and sync_pause_proposal, whose pause token already existed.',
 original_guarded_outcome=json.loads((ROOT/'guarded-outcome.json').read_text()),OneDrive_unchanged=True,old_token_flags_are_not_evidence_for_this_run=True),
 apollo=dict(measured_wall_ms=n['measured_wall_ms'],native_passed=n['passed'],service_hops=hops,steady_starved_frames=steady,steady_starved_seconds=steady/48000,
 control_starved_frames=controls,control_starved_seconds=controls/48000,peer_starved_frames=0,replays=n['replay_count'],stale_packet_discards=sum(r['kind']==7 for r in records),
 incomplete_generation_seek_proved=True,all_recoveries_complete=True,hard_worker_cancellation_exercised=False,manual_controls_acknowledged=16,
 callback_execution_deadline_misses=n['execution_deadline_misses'],driver_position_discontinuities=sum(t['driver_position_discontinuities']for t in n['timing']),
 driver_recovery_flags=sum(t['driver_recovery_flags']for t in n['timing']),source_read_failures=0,rejected_commands=0,invalid_buffers=0,
 recording_accepted_frames=rec['acceptedFrames'],recording_written_frames=rec['writtenFrames'],recording_overflow_frames=0,
 GUI_maximum_gap_ms=n['maximum_gui_heartbeat_gap_ns']/1e6,frame_maximum_gap_ms=n['maximum_frame_presentation_gap_ns']/1e6,
 tail_starved_frames=n['diagnostic_tail']['starved_a']+n['diagnostic_tail']['starved_b'],scope='Secondary offscreen UI/private virtual audio; no primary laptop or physical output qualification'))
assert out['apollo']['tail_starved_frames']==0
with (BASE/'results-summary-01.json').open('x')as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
