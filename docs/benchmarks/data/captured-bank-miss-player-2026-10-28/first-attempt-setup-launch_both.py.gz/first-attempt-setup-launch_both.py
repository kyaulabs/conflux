"""Start the frozen OneDrive-isolation laptop check and unchanged Apollo control together after one fresh human reply."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
LOCAL_UNIT='conflux-m2-prepared-miss-laptop-20261028-01.service'
REMOTE_UNIT='conflux-m2-prepared-miss-apollo-20261028-01.service'
REMOTE='/srv/conflux-tests/work/captured-bank-miss-20261028-01'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ForwardAgent=no','-o','ForwardX11=no',
 '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes','-o','HostName=10.4.20.101',
 '-o','HostKeyAlias=[apollo.kyaulabs]:4222','-p','4222','kyau@apollo.kyaulabs']

def pin(path):
 p=Path(path);assert p.is_file() and not p.is_symlink(),str(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h)
def save(path,value):
 with path.open('x') as f:f.write(json.dumps(value,indent=2,allow_nan=False)+'\n')
def verify():
 packet=json.loads((BASE/'packet-pins.json').read_text())
 assert packet['schema']==1 and packet['offline_checks_passed'] and packet['hardware_started'] is False
 assert packet['source_head']=='48b82030fcf6ab768c4f7b89d65021485cbf9b40' and packet['host_tests_concurrent'] and packet['no_retries']
 for row in packet['local_files']:assert pin(row['path'])==row,row['path']
 assert not any((BASE/n).exists() for n in ('readiness.json','launch-reservation.json','both-dispatch.json','laptop-results-01'))
 return packet

def local_command(unit, *, live, remaining=1200):
 return ['systemd-run','--user','--unit='+unit,'--property=Type=exec','--property=RemainAfterExit=yes',
  '--property=Restart=no','--property=RuntimeMaxSec='+str(int(remaining)-90)+'s','--property=TimeoutStopSec=60s',
  '--property=KillMode=control-group','--property=MemoryMax=8G','--property=TasksMax=256','--property=UMask=0077',
  '--property=ExecStopPost=/usr/bin/python3.14 -B '+str(BASE/'onedrive_pause.py')+' --restore',
  '--property=WorkingDirectory='+str(ROOT),
  '--property=StandardOutput=append:'+str(BASE/('unit.stdout.log' if live else 'offline-unit.stdout.log')),
  '--property=StandardError=append:'+str(BASE/('unit.stderr.log' if live else 'offline-unit.stderr.log')),
  '/usr/bin/kde-inhibit','--power','--screenSaver','/usr/bin/python3.14','-B',str(BASE/'run_local_guarded.py')]+(['--run'] if live else [])

def remote_script(packet,human):
 header='REMOTE='+repr(REMOTE)+'\nBINDING='+repr(packet['remote_binding'])+'\nHUMAN='+repr(human)+'\nUNIT='+repr(REMOTE_UNIT)+'\n'
 return header+r'''
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time
base=Path(REMOTE);binding=BINDING;human=HUMAN;unit=UNIT
raw=Path(binding['path']).read_bytes();assert len(raw)==binding['bytes'] and hashlib.sha256(raw).hexdigest()==binding['sha256']
age=(datetime.now(timezone.utc)-datetime.fromisoformat(human['original_readiness_utc'])).total_seconds()
remaining=1200-age;assert 0<=age<60 and remaining>=1100
human['apollo_deadline_monotonic']=time.monotonic()+remaining
human['binding_sha256']=binding['sha256']
state=subprocess.check_output(['systemctl','show',unit,'--property=LoadState,MainPID'],text=True,timeout=5)
assert 'LoadState=not-found' in state and 'MainPID=0' in state
assert not any((base/n).exists() for n in ('pair-readiness-01.json','pair-reservation-01.json','pair-result-01.json','cases'))
with (base/'pair-readiness-01.json').open('x') as f:f.write(json.dumps(human,indent=2)+'\n')
command=['sudo','-n','systemd-run','--unit='+unit,'--uid=1000','--gid=1000','--property=Type=exec',
 '--property=RemainAfterExit=yes','--property=Restart=no','--property=RuntimeMaxSec='+str(int(remaining)-30)+'s',
 '--property=TimeoutStopSec=15s','--property=KillMode=control-group','--property=MemoryMax=8G','--property=TasksMax=1024',
 '--property=UMask=0077','--property=WorkingDirectory='+str(base),
 '--property=StandardOutput=append:'+str(base/'unit.stdout.log'),'--property=StandardError=append:'+str(base/'unit.stderr.log'),
 '/usr/bin/python3','-B',str(base/'operations/run_pair.py'),'--run']
r=subprocess.run(command,capture_output=True,text=True,timeout=15)
receipt=dict(command=command,exit=r.returncode,stdout=r.stdout,stderr=r.stderr,original_readiness_utc=human['original_readiness_utc'],deadline_monotonic=human['apollo_deadline_monotonic'])
with (base/'unit-dispatch.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));assert r.returncode==0
'''

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--launch',action='store_true');args=parser.parse_args()
 packet=verify()
 if not args.launch:
  print(json.dumps(dict(verified=True,unarmed=True,hardware_started=False,local_command=local_command(LOCAL_UNIT,live=True))));return 0
 raw=sys.stdin.read(32769);assert len(raw)<=32768
 reply=json.loads(raw)
 conditions=('AC_power','lid_open','visible_window','screen_awake','Codex_minimized','other_work_paused','no_suspend')
 assert reply['physical_conditions_confirmed'] is True and all(reply.get(k) is True for k in conditions)
 assert reply.get('onedrive_pause_approved') is True,'Explicit temporary sync-pause approval is required'
 assert all(isinstance(reply.get(k),str) and 0<len(reply[k])<=8192 for k in ('question_item_id','human_question','human_reply'))
 original_utc=datetime.now(timezone.utc).isoformat();original_mono=time.monotonic();deadline=original_mono+1200
 # The accepted hot-cue trial is closed; it does not supply benchmark readiness.
 old=subprocess.check_output(['systemctl','--user','show','conflux-hotcue-user-trial-20261028-01.service','--property=MainPID','--value'],text=True,timeout=5).strip()
 assert old=='0','Close the user-trial client before the separate benchmark'
 state=subprocess.check_output(['systemctl','--user','show',LOCAL_UNIT,'--property=LoadState,MainPID'],text=True,timeout=5)
 assert 'LoadState=not-found' in state and 'MainPID=0' in state
 human=dict(schema=1,mode='m2-prepared-miss-player-20261028-01',operator_seconds=1200,
  recorded_at_utc=original_utc,original_readiness_utc=original_utc,operator_deadline_monotonic=deadline,
  plan_sha256=pin(BASE/'laptop-plan.json')['sha256'],**reply)
 save(BASE/'readiness.json',human)
 save(BASE/'launch-reservation.json',dict(original_readiness_utc=original_utc,original_monotonic=original_mono,
  deadline_monotonic=deadline,retries=False))
 forwarded=dict(schema=1,source_head=packet['source_head'],operator_seconds=1200,host_tests_concurrent=True,retries=False,
  original_readiness_utc=original_utc,**reply)
 remote=remote_script(packet,forwarded)
 def dispatch(host,command,data=None):
  with (BASE/(host+'-dispatch.stdout.log')).open('x') as out,(BASE/(host+'-dispatch.stderr.log')).open('x') as err:
   try:
    result=subprocess.run(command,input=data,text=True,stdout=out,stderr=err,timeout=30);return dict(exit=result.returncode)
   except BaseException as error:return dict(error=type(error).__name__+': '+str(error),outcome_requires_unit_observation=True)
 assert time.monotonic()-original_mono<45
 with ThreadPoolExecutor(max_workers=2) as pool:
  local=pool.submit(dispatch,'laptop',local_command(LOCAL_UNIT,live=True,remaining=deadline-time.monotonic()))
  other=pool.submit(dispatch,'apollo',SSH+['python3 -'],remote)
  receipt=dict(laptop=local.result(),apollo=other.result(),original_readiness_utc=original_utc,
   deadline_monotonic=deadline,hosts_submitted_concurrently=True,retries=False)
 save(BASE/'both-dispatch.json',receipt);print(json.dumps(receipt))
 return 0 if all(receipt[k].get('exit')==0 for k in ('laptop','apollo')) else 1

if __name__=='__main__':raise SystemExit(main())
