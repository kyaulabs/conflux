"""Offline launch-boundary checks; no systemd, input media or native probe."""
from datetime import datetime, timedelta, timezone
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('private_preparation_runner',BASE/'run_once.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)


class EntryChecks(unittest.TestCase):
    def test_actual_run_without_human_stops_before_host_query(self):
        plan=driver.local_plan()
        self.assertFalse(driver.HUMAN.exists())
        with patch.object(driver,'host') as host,patch.object(driver,'show') as show,patch.object(driver.subprocess,'run') as run:
            with self.assertRaises(FileNotFoundError):driver.launch(plan)
        host.assert_not_called();show.assert_not_called();run.assert_not_called()

    def test_actual_owned_entry_without_human_cannot_open_source(self):
        plan=driver.local_plan()
        with patch.object(driver,'host') as host,patch.object(driver.subprocess,'Popen') as child:
            with self.assertRaises(FileNotFoundError):driver.owned(plan)
        host.assert_not_called();child.assert_not_called()

    def fixture(self):
        now=datetime(2026,10,27,8,tzinfo=timezone.utc)
        plan=dict(mode='offline-fixture')
        human=dict(authorization_kind='fresh_async_user_reply',decision='ready',mode=plan['mode'],
            plan_sha256=driver.pin(driver.PLAN)['sha256'],AC_power=True,lid_open=True,
            other_work_paused=True,Codex_minimized=True,no_suspend=True,human_question='Offline fixture',
            human_reply='Offline fixture',question_item_id='offline-fixture',
            recorded_at_utc=now.isoformat(),recorded_at_monotonic=100.)
        return now,plan,human

    def test_original_clock_is_preserved(self):
        now,plan,human=self.fixture()
        for age in (0,20,60):
            self.assertEqual(driver.fresh_clock(plan,human,now+timedelta(seconds=age),100.+age),400.)

    def test_stale_future_or_disagreeing_clocks_rejected(self):
        now,plan,human=self.fixture()
        for age,mono in ((61,161),(-1,99),(0,104)):
            with self.assertRaises(AssertionError):driver.fresh_clock(plan,human,now+timedelta(seconds=age),mono)

    def test_wrong_plan_or_physical_conditions_fail(self):
        now,plan,human=self.fixture()
        for key,value in [('plan_sha256','0'*64),('mode','wrong'),('AC_power',False),('lid_open',False),
            ('Codex_minimized',False),('other_work_paused',False),('no_suspend',False),('human_reply','')]:
            with self.subTest(key=key):
                altered={**human,key:value}
                with self.assertRaises(AssertionError):driver.fresh_clock(plan,altered,now,100.)

    def test_caps_can_reduce_but_cannot_increase(self):
        key='/offline/constraint_0_power_limit_uw';ceiling={key:15000000,'/offline/enabled':1}
        self.assertTrue(driver.caps_valid({**ceiling,key:7500000},ceiling))
        for value in (0,-1,64000000):self.assertFalse(driver.caps_valid({**ceiling,key:value},ceiling))
        self.assertFalse(driver.caps_valid({key:15000000},ceiling))
        self.assertFalse(driver.caps_valid({**ceiling,'/offline/enabled':0},ceiling))

    def test_draft_plan_rejected_before_native_access(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'plan.json';path.write_text('{"status":"draft"}')
            with patch.object(driver,'PLAN',path),patch.object(driver.os,'access') as access:
                with self.assertRaises(AssertionError):driver.local_plan()
            access.assert_not_called()

    def test_changed_driver_pin_rejected(self):
        actual=json.loads(driver.PLAN.read_text());actual['assets']['driver']['sha256']='0'*64
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'plan.json';path.write_text(json.dumps(actual))
            with patch.object(driver,'PLAN',path):
                with self.assertRaises(AssertionError):driver.local_plan()


if __name__=='__main__':unittest.main()
