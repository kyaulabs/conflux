// Private source-preparation CPU probe. Existing functions; no model/device/UI.
#include "audio/AudioFile.hpp"
#include "library/PreparedTrackStore.hpp"
#include "library/StemEngineSupport.hpp"
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>
#include <QTemporaryFile>
#include <sndfile.h>
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <fcntl.h>
#include <iostream>
#include <span>
#include <stdexcept>
#include <stop_token>
#include <time.h>
#include <unistd.h>

namespace {
using namespace conflux;
using Clock = std::chrono::steady_clock;
void require(bool value,const char* message) { if (!value) throw std::runtime_error(message); }
qint64 cpuNow()
{
    timespec value{};
    require(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&value)==0,"Thread CPU clock unavailable");
    return qint64(value.tv_sec)*1000000000+value.tv_nsec;
}
template<class Function> auto measured(QJsonArray& rows,const char* name,Function&& function)
{
    const auto wall=Clock::now();const auto cpu=cpuNow();
    auto result=function();
    const auto elapsed=cpuNow()-cpu;
    const auto wallNs=std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-wall).count();
    require(elapsed>=0 && wallNs>=0,"Invalid CPU/wall span");
    rows.append(QJsonObject{{"stage",name},{"thread_cpu_ns",elapsed},{"wall_ns",qint64(wallNs)}});
    return result;
}
bool exactPeaks(std::span<const float> left,std::span<const float> right)
{
    if (left.size()!=right.size()) return false;
    for (std::size_t i=0;i<left.size();++i)
        if (std::bit_cast<std::uint32_t>(left[i])!=std::bit_cast<std::uint32_t>(right[i])) return false;
    return true;
}

QJsonObject profile(const QString& path,const QString& root)
{
    QJsonArray stages;
    library::detail::Descriptor source(open(QFile::encodeName(path).constData(),O_RDONLY|O_CLOEXEC|O_NONBLOCK));
    require(source.get()>=0,"Cannot open fixed source");
    const auto before=library::detail::statusOf(source.get());
    require(S_ISREG(before.st_mode) && before.st_size>0 && before.st_size<=1024LL*1024*1024,"Invalid bounded source");
    const auto raw=measured(stages,"source_sha256",[&] {
        return library::detail::scan(source.get(),std::uint64_t(before.st_size),{});
    });
    const auto spool=QDir(root).filePath("spool");
    require(QDir().mkpath(spool),"Cannot create private spool");
    auto direct=measured(stages,"decode_and_overview",[&] {
        return audio::prepareAudioFile(source.get(),audio::PreparedAudio::defaultMaxPreparedBytes,{},
            std::filesystem::path(QFile::encodeName(spool).constData()));
    });
    const auto bytes=direct.frames()*2*sizeof(float);
    const auto pcm=measured(stages,"PCM_finite_peak_and_hash_scan",[&] {
        return library::detail::scan(direct.descriptor(),bytes,{},direct.frames());
    });
    QTemporaryFile copied(QDir(root).filePath("copy-XXXXXX"));
    require(copied.open(),"Cannot open private copy");
    const auto copy=measured(stages,"PCM_copy_finite_peak_and_hash",[&] {
        return library::detail::scan(direct.descriptor(),bytes,{},direct.frames(),copied.handle());
    });
    measured(stages,"copy_fsync",[&] { require(fsync(copied.handle())==0,"Copy synchronization failed");return 0; });
    const auto verified=measured(stages,"PCM_copy_verification_scan",[&] {
        return library::detail::scan(copied.handle(),bytes,{},direct.frames());
    });
    library::PreparedTrackStore store(QDir(root).filePath("cache"));
    auto cold=measured(stages,"complete_store_cache_miss",[&] { return store.prepare(path); });
    auto hit=measured(stages,"complete_store_cache_hit",[&] { return store.prepare(path); });
    require(!cold.cacheHit && hit.cacheHit,"Fresh miss/hit cache state differs");
    require(cold.sourceSha256.toLatin1()==raw.sha256 && hit.sourceSha256==cold.sourceSha256,"Source digests differ");
    require(cold.audio.frames()==direct.frames() && hit.audio.frames()==direct.frames(),"Prepared frame counts differ");
    require(pcm.sha256==copy.sha256 && pcm.sha256==verified.sha256,"Copied PCM digest differs");
    require(exactPeaks(pcm.peaks,direct.peaks()) && exactPeaks(copy.peaks,direct.peaks()) &&
        exactPeaks(verified.peaks,direct.peaks()) && exactPeaks(cold.audio.peaks(),direct.peaks()) &&
        exactPeaks(hit.audio.peaks(),direct.peaks()),"Waveform bit patterns differ");
    const auto coldPCM=measured(stages,"cold_store_PCM_validation",[&] {
        return library::detail::scan(cold.audio.descriptor(),bytes,{},cold.audio.frames());
    });
    require(coldPCM.sha256==pcm.sha256,"Store and direct prepared PCM differ");
    measured(stages,"final_source_verification",[&] {
        library::detail::verifySource(source.get(),before,raw.sha256,{});return 0;
    });
    return {{"passed",true},{"stages",stages},{"frames",qint64(direct.frames())},
        {"source_sha256",QString::fromLatin1(raw.sha256)},{"PCM_sha256",QString::fromLatin1(pcm.sha256)},
        {"waveform_bins",qint64(direct.peaks().size())},{"exact_PCM_and_waveforms",true},
        {"source_unchanged",true},{"cache_miss_then_hit",true},
        {"scope","Separate synchronous calls over one source. Store spans include their own internal work; stages are not additive and cache/temperature conditions are not matched. Thread CPU is not service latency."}};
}
}

int main(int argc,char** argv)
{
    QCoreApplication app(argc,argv);
    if (argc==1) {
        std::cout << "{\"status\":\"unarmed_dry\",\"source_opened\":false,\"audio_started\":false,\"GPU_started\":false}\n";
        return 0;
    }
    const bool offline=argc==3 && QByteArray(argv[1])=="--offline-check";
    if (!offline && !(argc==4 && QByteArray(argv[1])=="--run")) return 2;
    const QString parent=QString::fromLocal8Bit(argv[offline?2:3]);
    if (!QDir(parent).exists()) return 2;
    QTemporaryDir scope(QDir(parent).filePath("preparation-XXXXXX"));
    if (!scope.isValid()) return 1;
    const auto scopePath=scope.path();
    QJsonObject report;
    try {
        QString source=offline?QDir(scope.path()).filePath("generated.wav"):QString::fromLocal8Bit(argv[2]);
        if (offline) {
            SF_INFO info{};info.samplerate=48000;info.channels=2;info.format=SF_FORMAT_WAV|SF_FORMAT_FLOAT;
            auto* file=sf_open(QFile::encodeName(source).constData(),SFM_WRITE,&info);
            require(file,"Cannot create generated fixture");
            std::array<float,1026> data{};
            for (std::size_t i=0;i<data.size();++i) data[i]=float(int(i%19)-9)/32.F;
            const bool wrote=sf_writef_float(file,data.data(),513)==513;
            const bool closed=sf_close(file)==0;
            require(wrote && closed,"Cannot finalize generated fixture");
        }
        report=profile(source,scope.path());
        if (offline) {
            require(report.value("frames").toInteger()==513 && report.value("waveform_bins").toInteger()==512,
                "Generated fixture geometry differs");
            library::PreparedTrackStore cancelled(QDir(scope.path()).filePath("cancelled"));
            std::stop_source stop;stop.request_stop();bool rejected=false;
            try { (void)cancelled.prepare(source,stop.get_token()); }
            catch (const std::exception&) { rejected=true; }
            require(rejected,"Already-cancelled preparation accepted");
            report.insert("already_cancelled_rejected",true);
        }
    } catch (const std::exception& error) {
        report={{"passed",false},{"error",error.what()}};
    }
    const bool removed=scope.remove() && !QDir(scopePath).exists();
    report.insert("private_files_removed",removed);
    report.insert("offline_generated_fixture",offline);
    report.insert("audio_output_opened",false);
    report.insert("GPU_started",false);
    report.insert("latency_qualified",false);
    std::cout << QJsonDocument(report).toJson(QJsonDocument::Compact).constData() << '\n';
    return report.value("passed").toBool() && removed?0:1;
}
