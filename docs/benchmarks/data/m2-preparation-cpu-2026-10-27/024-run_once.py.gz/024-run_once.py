"""One frozen, fresh-readiness, headless preparation CPU diagnostic; dry by default."""
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/home/kyau/projects/kyaulabs/conflux')
BASE = Path(__file__).resolve().parent
CASE = BASE / 'case-01'
HUMAN = BASE / 'readiness.json'
PLAN = BASE / 'plan.json'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False)+'\n')


def call(arguments, seconds=5):
    return subprocess.check_output(arguments, text=True, timeout=seconds)


def show(unit):
    raw = call(['/usr/bin/systemctl','--user','show',unit,
        '--property=LoadState,ActiveState,SubState,MainPID,InvocationID,Result,ExecMainStatus,ControlGroup'])
    return dict(line.split('=',1) for line in raw.splitlines() if '=' in line)


def local_plan():
    plan = json.loads(PLAN.read_text())
    assert plan['status'] == 'frozen_pending_fresh_readiness'
    assert plan['qualified'] is False and plan['no_retries'] is True
    assert plan['operator_seconds'] == 300 and plan['unit_seconds'] == 245
    assert plan['native_seconds'] == 30
    assert pin(Path(__file__).resolve()) == plan['assets']['driver']
    assert os.access(plan['assets']['native']['path'],os.X_OK)
    return plan


def fresh_clock(plan, human, now_utc, now_mono):
    assert human['authorization_kind'] == 'fresh_async_user_reply'
    assert human['decision'] == 'ready' and human['mode'] == plan['mode']
    assert human['plan_sha256'] == pin(PLAN)['sha256']
    assert all(human[key] is True for key in ('AC_power','lid_open','other_work_paused','Codex_minimized','no_suspend'))
    assert all(isinstance(human[key],str) and human[key] for key in ('human_question','human_reply','question_item_id'))
    issued = datetime.fromisoformat(human['recorded_at_utc'])
    assert issued.tzinfo is not None
    age = (now_utc-issued).total_seconds()
    mono_age = now_mono-human['recorded_at_monotonic']
    assert 0 <= age <= 60 and 0 <= mono_age <= 60 and abs(age-mono_age) < 2
    return human['recorded_at_monotonic']+300


def caps_valid(values, ceiling):
    return set(values) == set(ceiling) and all(
        0 < values[key] <= bound if key.endswith('power_limit_uw') else values[key] == bound
        for key,bound in ceiling.items())


def host(plan):
    online = list(Path('/sys/class/power_supply').glob('*/online'))
    lids = list(Path('/proc/acpi/button/lid').glob('*/state'))
    assert online and any(path.read_text().strip()=='1' for path in online)
    assert lids and all(path.read_text().strip().endswith('open') for path in lids)
    guard = show('thermal-guard.service')
    assert guard['ActiveState']=='active' and guard['SubState']=='running'
    assert all(guard[key]==plan['guard_identity'][key] for key in ('MainPID','InvocationID'))
    values = {key:int(Path(key).read_text()) for key in plan['power_caps']}
    assert caps_valid(values,plan['power_caps'])
    temperatures = {key:int(Path(key).read_text()) for key in plan['temperature_paths']}
    assert temperatures and all(0 <= value <= 130000 for value in temperatures.values())
    return dict(monotonic=time.monotonic(),guard=guard,power_caps=values,
        temperatures=temperatures,maximum_temperature=max(temperatures.values()),
        platform_profile=Path('/sys/firmware/acpi/platform_profile').read_text().strip())


def inhibitors(plan):
    value = json.loads(call(['/usr/bin/busctl','--system','--timeout=2s','--json=short','call',
        'org.freedesktop.login1','/org/freedesktop/login1','org.freedesktop.login1.Manager','ListInhibitors']))
    assert value['type']=='a(ssssuu)' and len(value['data'])==1
    matches = [row for row in value['data'][0] if row[1]==plan['inhibitor_who']]
    assert all(len(row)==6 and 'sleep' in row[0].split(':') and row[3]=='block'
        and row[4]==os.getuid() for row in matches)
    assert all(plan['unit'] in Path('/proc',str(row[5]),'cgroup').read_text() for row in matches)
    return [dict(who=row[1],uid=row[4],pid=row[5]) for row in matches]


def launch(plan):
    human = json.loads(HUMAN.read_text())  # Before any host query or launch.
    deadline = fresh_clock(plan,human,datetime.now(timezone.utc),time.monotonic())
    assert not CASE.exists() and not (BASE/'reservation-01.json').exists()
    for row in plan['assets'].values():
        assert pin(Path(row['path']))==row
    assert Path('/proc/1/comm').read_text().strip()=='systemd'
    assert call(['git','rev-parse','HEAD']).strip()==plan['source_head']
    assert call(['git','status','--porcelain'])==''
    assert shutil.disk_usage(BASE).free >= 2*1024**3
    assert show(plan['unit'])['LoadState']=='not-found'
    assert not inhibitors(plan)
    before = host(plan)
    reservation = dict(plan=pin(PLAN),human=pin(HUMAN),operator_deadline=deadline,
        guard_before=before['guard'],issued_monotonic=human['recorded_at_monotonic'])
    save(BASE/'reservation-01.json',reservation)
    CASE.mkdir(mode=0o700)
    record = dict(unit=plan['unit'],reservation=reservation,automatic_retries=False)
    try:
        result = subprocess.run(plan['command'],text=True,capture_output=True,timeout=10)
        record.update(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
        after = show(plan['unit'])
        record['unit_after_dispatch']=after
        if int(after['MainPID']):
            try:
                fields=Path('/proc',after['MainPID'],'stat').read_text().rsplit(')',1)[1].split()
                record['owner_identity']=dict(pid=int(after['MainPID']),start_ticks=int(fields[19]))
            except (FileNotFoundError,ProcessLookupError):
                record['owner_identity_unavailable_after_exit']=True
        assert result.returncode==0 and after['InvocationID']
    except BaseException as error:
        record['error']=dict(type=type(error).__name__,message=str(error))
        raise
    finally:
        save(BASE/'unit-dispatch-01.json',record)
    print(json.dumps(dict(status='dispatched_once',unit=plan['unit'],remaining_original_seconds=deadline-time.monotonic())))


def owned(plan):
    human = json.loads(HUMAN.read_text())
    deadline = fresh_clock(plan,human,datetime.now(timezone.utc),time.monotonic())
    reserved = json.loads((BASE/'reservation-01.json').read_text())
    assert reserved['plan']==pin(PLAN) and reserved['human']==pin(HUMAN)
    assert abs(reserved['operator_deadline']-deadline)<.001
    assert plan['unit'] in Path('/proc/self/cgroup').read_text()
    report = dict(status='incomplete',qualified=False,observations=[],errors=[],
        operator_deadline=deadline,native_started=False,automatic_retries=False)
    workspace = CASE/'workspace'
    child = None
    try:
        assert inhibitors(plan)
        quiet_since = None
        while time.monotonic() < human['recorded_at_monotonic']+180:
            row=host(plan);report['observations'].append(row)
            if row['maximum_temperature']<=55000:
                if quiet_since is None: quiet_since=row['monotonic']
                if row['monotonic']-quiet_since>=60: break
            else: quiet_since=None
            time.sleep(2)
        else: raise TimeoutError('Original 180-second quiet-readiness budget exhausted')
        assert deadline-time.monotonic()>=60
        for row in plan['assets'].values(): assert pin(Path(row['path']))==row
        assert host(plan)['maximum_temperature']<=70000
        workspace.mkdir(mode=0o700)
        command=[plan['assets']['native']['path'],'--run',plan['assets']['input']['path'],str(workspace)]
        report['native_started']=True
        with (CASE/'native.stdout.log').open('xb') as stdout,(CASE/'native.stderr.log').open('xb') as stderr:
            child=subprocess.Popen(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
            stop=min(deadline-30,time.monotonic()+30)
            while child.poll() is None:
                if time.monotonic()>=stop: raise TimeoutError('Native 30-second CPU probe deadline exhausted')
                report['observations'].append(host(plan));time.sleep(.5)
            report['native_exit_code']=child.returncode
        out=CASE/'native.stdout.log';err=CASE/'native.stderr.log'
        assert out.stat().st_size<=65536 and err.stat().st_size<=16384
        native=json.loads(out.read_text())
        report['native']=native
        assert child.returncode==0 and native['passed'] and native['private_files_removed']
        assert native['source_sha256']==plan['assets']['input']['sha256']
        assert native['exact_PCM_and_waveforms'] and native['cache_miss_then_hit']
        assert native['frames']==23040000 and not native['audio_output_opened'] and not native['GPU_started']
        assert not any(workspace.iterdir())
        for row in plan['assets'].values(): assert pin(Path(row['path']))==row
        report['status']='complete'
    except BaseException as error:
        report['errors'].append(dict(type=type(error).__name__,message=str(error)))
    finally:
        if child is not None and child.poll() is None:
            child.kill();child.wait(timeout=5)
        report['native_reaped']=child is None or child.poll() is not None
        report['finished_monotonic']=time.monotonic()
        report['within_original_300_seconds']=time.monotonic()<=deadline
        save(CASE/'result-01.json',report)
    return 0 if report['status']=='complete' and report['within_original_300_seconds'] else 1


def close(plan):
    dispatch=json.loads((BASE/'unit-dispatch-01.json').read_text())
    before=show(plan['unit'])
    assert before['MainPID']=='0' and before['InvocationID']==dispatch['unit_after_dispatch']['InvocationID']
    assert before['SubState'] in ('exited','failed','dead')
    assert not inhibitors(plan)
    call(['/usr/bin/systemctl','--user','stop',plan['unit']])
    after=show(plan['unit']);assert after['LoadState']=='not-found' and after['MainPID']=='0'
    original_cgroup=dispatch['unit_after_dispatch']['ControlGroup']
    if original_cgroup:
        assert original_cgroup.endswith('/'+plan['unit'])
        directory=Path('/sys/fs/cgroup')/original_cgroup.lstrip('/')
        assert not directory.exists() or all(not path.read_text().split() for path in directory.rglob('cgroup.procs'))
    else:
        assert before['ControlGroup']==''  # Explicit exited-unit proof, not an invented PID birth.
    assert not inhibitors(plan)
    observed=host(plan)
    for row in plan['assets'].values(): assert pin(Path(row['path']))==row
    assert all(observed['guard'][key]==dispatch['reservation']['guard_before'][key]
        for key in ('MainPID','InvocationID'))
    # Retire only this newly created private workspace after its unit is gone.
    workspace=CASE/'workspace'
    leftovers=[]
    if workspace.exists():
        for path in workspace.iterdir():
            assert path.is_dir() and not path.is_symlink() and path.name.startswith('preparation-')
            assert path.stat().st_uid==os.getuid()
            leftovers.append(path.name);shutil.rmtree(path)
        assert not any(workspace.iterdir())
    receipt=dict(cleanup_complete=True,unit_before_stop=before,unit_after_stop=after,
        own_sleep_inhibitions_remaining=0,removed_incomplete_owned_workspaces=leftovers,
        original_cgroup=original_cgroup or None,unit_cgroup_absent_or_empty=True,
        guard_identity_unchanged=True,power_caps_respected=True,
        original_operator_deadline=dispatch['reservation']['operator_deadline'],
        verified_monotonic=time.monotonic(),within_original_300_seconds=time.monotonic()<=dispatch['reservation']['operator_deadline'],
        qualified=False,further_tests_authorized=False)
    save(CASE/'closure-01.json',receipt)
    print(json.dumps(receipt))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--run',action='store_true');mode.add_argument('--owned',action='store_true');mode.add_argument('--close',action='store_true')
    args=parser.parse_args();plan=local_plan()
    if args.run: launch(plan)
    elif args.owned: return owned(plan)
    elif args.close: close(plan)
    else: print(json.dumps(dict(status='unarmed_dry',host_queried=False,native_started=False)))
    return 0


if __name__=='__main__': raise SystemExit(main())
