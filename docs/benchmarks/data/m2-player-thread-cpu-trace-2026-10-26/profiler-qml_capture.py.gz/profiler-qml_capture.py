"""Owned, loopback-only Qt profiling for one exact private native command."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time
import xml.etree.ElementTree as ET

FEATURES = 'javascript,binding,handlingsignal,scenegraph,animations,compiling,creating'
TRACE_LIMIT = 128 * 1024 * 1024
STREAM_LIMIT = 1024 * 1024


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def listener_owned(pid, port, proc=Path('/proc')):
    directory = proc / str(pid)
    require(directory.stat().st_uid == os.getuid(), 'Profiler target UID differs')
    inodes = set()
    entries = list((directory / 'fd').iterdir())
    require(len(entries) <= 1024, 'Profiler target descriptor bound exceeded')
    for entry in entries:
        try:
            value = os.readlink(entry)
        except FileNotFoundError:
            continue
        if value.startswith('socket:[') and value.endswith(']'):
            inodes.add(value[8:-1])
    with (proc / 'net/tcp').open('rb') as stream:
        raw = stream.read(4 * 1024 * 1024 + 1)
    require(len(raw) <= 4 * 1024 * 1024, 'Local TCP table exceeds bound')
    for line in raw.decode('ascii').splitlines()[1:]:
        values = line.split()
        require(len(values) >= 10, 'Malformed local TCP row')
        if values[3] == '0A' and values[9] in inodes:
            # A wildcard or other interface for this exact port is never admitted.
            address, encoded_port = values[1].split(':')
            if int(encoded_port, 16) == port:
                require(address == '0100007F', 'Profiler listener must bind IPv4 loopback only')
                return True
    return False


def client_limits():
    resource.setrlimit(resource.RLIMIT_AS, (1536 * 1024**2,) * 2)
    resource.setrlimit(resource.RLIMIT_FSIZE, (TRACE_LIMIT,) * 2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def trace_summary(path):
    path = Path(path)
    require(path.is_file() and 0 < path.stat().st_size <= TRACE_LIMIT, 'QML trace missing/over bound')
    # Qt emits XML without external entities. Reject any declaration before parsing.
    with path.open('rb') as stream:
        raw = stream.read(TRACE_LIMIT + 1)
    require(len(raw) <= TRACE_LIMIT, 'QML trace grew beyond bound')
    require(b'<!DOCTYPE' not in raw and b'<!ENTITY' not in raw, 'QML trace entity declaration forbidden')
    root = ET.fromstring(raw)
    require(root.tag == 'trace' and root.get('version') == '1.02', 'QML trace schema differs')
    start, end = int(root.attrib['traceStart']), int(root.attrib['traceEnd'])
    require(0 <= start < end, 'QML trace clock invalid')
    events = root.find('eventData')
    ranges = root.find('profilerDataModel')
    require(events is not None and ranges is not None, 'QML event tables missing')
    definitions = {int(row.attrib['index']): {v.tag: v.text for v in row} for row in events}
    require(len(definitions) == len(events), 'QML event index duplicated')
    aggregates = {}
    count = 0
    for row in ranges:
        require(row.tag == 'range' and int(row.attrib['eventIndex']) in definitions, 'QML range reference invalid')
        timestamp = int(row.attrib['startTime'])
        duration = int(row.get('duration', '0'))
        require(start <= timestamp <= end and duration >= 0 and timestamp + duration <= end,
                'QML range outside trace interval')
        index = int(row.attrib['eventIndex'])
        value = aggregates.setdefault(index, dict(count=0, inclusive_wall_ns=0, maximum_wall_ns=0))
        value['count'] += 1
        value['inclusive_wall_ns'] += duration
        value['maximum_wall_ns'] = max(value['maximum_wall_ns'], duration)
        count += 1
    require(count > 0, 'QML trace contains no events')
    return dict(trace_pin=pin(path), clock='Qt profiler-relative nanoseconds; wall durations, not thread CPU',
                nested_events_are_not_additive=True, start_ns=start, end_ns=end, event_count=count,
                definitions_count=len(definitions),
                events=sorted([dict(index=i, **definitions[i], **a) for i, a in aggregates.items()],
                              key=lambda row: row['inclusive_wall_ns'], reverse=True))


class QmlCapture:
    def __init__(self, config, expected_command, directory, deadline):
        self.config, self.expected_command = config, list(expected_command)
        self.directory, self.deadline = Path(directory), deadline
        self.child = self.native = None
        self.streams = []
        self.started = self.flushed_at = None
        self.receipt = dict(schema=1, scope='First 30 seconds of QML activity; no C++ attribution or latency qualification',
                            qualified=False, connected=False, early_flush_sent=False, cleanup_complete=False)

    def popen(self, command, **kwargs):
        require(self.native is None and list(command) == self.expected_command, 'Only one exact native command may be profiled')
        require(kwargs.get('start_new_session') is True and kwargs.get('stdin') == subprocess.DEVNULL and
                kwargs.get('stdout') == subprocess.PIPE and kwargs.get('stderr') == subprocess.PIPE,
                'Native ownership/capture launch contract differs')
        require(time.monotonic() + 8 < self.deadline, 'Insufficient original profiler attach budget')
        require(not self.directory.exists(), 'Fresh profiler directory required')
        self.directory.mkdir(mode=0o700)
        self.native = subprocess.Popen(command, **kwargs)
        self.receipt['native_pid'] = self.native.pid
        self.receipt['native_command'] = list(command)
        try:
            stop = min(self.deadline, time.monotonic() + 8)
            while time.monotonic() < stop:
                require(self.native.poll() is None, 'Native exited before profiler attach')
                if listener_owned(self.native.pid, self.config['port']):
                    break
                time.sleep(.05)
            else:
                raise TimeoutError('Owned loopback profiler listener absent within 8 seconds')
            executable = Path(self.config['client']['path'])
            require(pin(executable) == self.config['client'], 'Frozen profiler executable changed')
            trace = self.directory / 'qml.qtd'
            argv = [str(executable), '--attach', '127.0.0.1', '--port', str(self.config['port']),
                    '--output', str(trace), '--include', FEATURES, '--interactive']
            for name in ('stdout', 'stderr'):
                self.streams.append((self.directory / ('client.' + name)).open('xb'))
            self.child = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=self.streams[0], stderr=self.streams[1],
                                          start_new_session=True, preexec_fn=client_limits)
            self.started = time.monotonic()
            self.receipt.update(client_pid=self.child.pid, client_command=argv, attach_started_monotonic=self.started,
                                client_started=True, listener_ownership_verified=True)
            return self.native
        except BaseException:
            # The public caller has not received the native handle. Reap it here.
            if self.native.poll() is None:
                os.killpg(self.native.pid, signal.SIGKILL)
            self.native.wait(timeout=max(.1, min(2, self.deadline - time.monotonic())))
            for stream in (self.native.stdout, self.native.stderr):
                if stream is not None:
                    stream.close()
            raise

    def monitor(self):
        if self.child is None:
            return
        require(self.child.poll() is None, 'Profiler exited prematurely')
        for name in ('stdout', 'stderr'):
            require((self.directory / ('client.' + name)).stat().st_size <= STREAM_LIMIT, 'Profiler stream exceeds bound')
        trace = self.directory / 'qml.qtd'
        require(not trace.exists() or trace.stat().st_size <= TRACE_LIMIT, 'Profiler trace exceeds bound')
        if self.flushed_at is None and time.monotonic() - self.started >= self.config['capture_seconds']:
            self.child.stdin.write(b'flush\n')
            self.child.stdin.flush()
            self.flushed_at = time.monotonic()
            self.receipt.update(early_flush_sent=True, flush_sent_monotonic=self.flushed_at)

    def close(self):
        error = None
        try:
            if self.child is not None and self.child.poll() is None:
                # If playback failed before the 30-second mark, preserve the shorter trace.
                if self.flushed_at is None:
                    self.child.stdin.write(b'flush\n')
                    self.child.stdin.flush()
                    self.receipt['final_flush_sent'] = True
                self.child.stdin.write(b'quit\ny\n')
                self.child.stdin.flush()
                self.child.stdin.close()
                self.child.wait(timeout=max(.1, min(8, self.deadline - time.monotonic())))
            if self.child is not None:
                require(self.child.returncode == 0, 'Profiler did not exit successfully')
                require(all((self.directory / ('client.' + name)).stat().st_size <= STREAM_LIMIT
                            for name in ('stdout', 'stderr')), 'Profiler final stream exceeds bound')
                trace = self.directory / 'qml.qtd'
                require(trace.is_file() and 0 < trace.stat().st_size <= TRACE_LIMIT, 'Profiler trace missing/over bound')
                self.receipt['trace_pin'] = pin(trace)
                self.receipt['trace_analysis_deferred_until_after_host_cleanup'] = True
                connection = ('Connected to 127.0.0.1:' + str(self.config['port']) + '.').encode()
                with (self.directory / 'client.stderr').open('rb') as stream:
                    messages = stream.read(STREAM_LIMIT + 1)
                require(len(messages) <= STREAM_LIMIT and connection in messages, 'Profiler connection acknowledgement absent')
                self.receipt['connected'] = True
        except Exception as exception:
            error = exception
            self.receipt['error'] = dict(type=type(exception).__name__, message=str(exception)[:2048])
        finally:
            if self.child is not None and self.child.poll() is None:
                os.killpg(self.child.pid, signal.SIGKILL)
                self.child.wait(timeout=2)
            for stream in self.streams:
                stream.close()
            self.receipt.update(client_exit=None if self.child is None else self.child.returncode,
                                cleanup_complete=self.child is None or self.child.poll() is not None)
            with (self.directory.parent / 'qml-profile-receipt.json').open('x') as stream:
                json.dump(self.receipt, stream, indent=2, allow_nan=False)
                stream.write('\n')
        if error is not None:
            raise error
        return self.receipt
