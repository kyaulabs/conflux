#include <QGuiApplication>
#include <QQmlComponent>
#include <QQmlEngine>
#include <QTimer>
#include <QtQml/qqmldebug.h>
#include <iostream>

int main(int argc, char** argv)
{
    if (argc != 2) return 2;
    const int port = std::stoi(argv[1]);
    QGuiApplication app(argc, argv);
    QQmlDebuggingEnabler::enableDebugging(true);
    QQmlDebuggingEnabler::setServices(QQmlDebuggingEnabler::profilerServices());
    if (!QQmlDebuggingEnabler::startTcpDebugServer(port,
            QQmlDebuggingEnabler::WaitForClient, QStringLiteral("127.0.0.1"))) return 3;
    QQmlEngine engine;
    QQmlComponent component(&engine);
    component.setData(R"qml(import QtQml
QtObject {
    id: root
    property int checksum: 0
    property Timer pulse: Timer {
        interval: 25
        repeat: true
        running: true
        onTriggered: root.profiledWork()
    }
    function profiledWork() {
        let sum = 0
        for (let i = 0; i < 10000; ++i) sum += Math.sqrt(i + 1)
        checksum = Math.floor(sum)
    }
})qml", QUrl(QStringLiteral("file:///conflux-profiler-smoke.qml")));
    auto* object = component.create();
    if (!object) {
        for (const auto& error : component.errors()) std::cerr << error.toString().toStdString() << '\n';
        return 4;
    }
    QTimer::singleShot(1000, &app, &QCoreApplication::quit);
    const auto code = app.exec();
    delete object;
    return code;
}
