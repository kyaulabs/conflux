#include <atomic>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <thread>
#include <ctime>
#include <sys/wait.h>
#include <unistd.h>
std::atomic<std::uint64_t> sink{0};
std::uint64_t cpu_ns(){timespec t{};if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t)!=0)std::abort();return std::uint64_t(t.tv_sec)*1000000000+t.tv_nsec;}
[[gnu::noinline]] void main_work(std::uint64_t n){std::uint64_t x=19;for(std::uint64_t i=0;i<n;++i)x=x*6364136223846793005ULL+1;sink.fetch_xor(x,std::memory_order_relaxed);}
[[gnu::noinline]] void worker_work(std::uint64_t n){std::uint64_t x=73;for(std::uint64_t i=0;i<n;++i)x=(x^(x>>13))*2862933555777941757ULL+3037000493ULL;sink.fetch_xor(x,std::memory_order_relaxed);}
int main(int argc,char**argv){
 if(argc!=2)return 2;auto n=std::strtoull(argv[1],nullptr,10);std::uint64_t worker_ns=0;int worker_tid=0;
 std::thread worker([&]{worker_tid=gettid();auto begin=cpu_ns();worker_work(n);worker_ns=cpu_ns()-begin;});
 auto begin=cpu_ns();main_work(n);auto main_ns=cpu_ns()-begin;worker.join();
 auto child=fork();if(child==0){execl("/bin/true","true",nullptr);_exit(127);}if(child<0)return 3;
 int status=0;if(waitpid(child,&status,0)!=child)return 4;bool reaped=WIFEXITED(status)&&WEXITSTATUS(status)==0;
 std::cout<<"{\"pid\":"<<getpid()<<",\"worker_tid\":"<<worker_tid<<",\"child_pid\":"<<child<<",\"child_reaped\":"<<(reaped?"true":"false")<<",\"main_cpu_ns\":"<<main_ns<<",\"worker_cpu_ns\":"<<worker_ns<<"}\n";
 return reaped?0:5;}
