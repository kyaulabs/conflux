"""Recompute the failed trace without turning its partial hop population into a pass."""
from array import array
import hashlib
import json
import math
from pathlib import Path
import statistics
import struct
import sys

BASE = Path(__file__).resolve().parent


def read(name):
    return json.loads((BASE / name).read_text())


def pin(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(name, value):
    with (BASE / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


wrapper, assessment, closure = read('output-01/result.json'), read('diagnostic-assessment.json'), read('root-finished-01.json')
assert closure['cleanup_complete'] and not assessment['diagnostic_complete']
native = wrapper['native']
observations = [json.loads(line) for line in (BASE / 'output-01/observations.jsonl').read_text().splitlines()]
hops = [row for row in observations if row.get('hop_service_present')]
times = sorted(row['hop_service_ms'] for row in hops)
phases = ('source_read_ms', 'request_ms', 'overlap_ms', 'native_elapsed_ms', 'native_inference_wall_ms',
          'native_inference_cpu_ms', 'native_frontend_ms', 'native_graph_ms', 'native_graph_upload_ms',
          'native_graph_compute_ms', 'native_graph_readback_ms', 'native_postprocess_ms', 'native_graph_rebuild_ms')
assert times and all(all(k in row and math.isfinite(row[k]) and row[k] >= 0 for k in phases) for row in hops)

path = BASE / 'output-01/master.wav'
wav = path.read_bytes()
assert wav[:4] == b'RIFF' and wav[8:12] == b'WAVE' and int.from_bytes(wav[4:8], 'little') + 8 == len(wav)
offset, data, fmt = 12, None, None
while offset + 8 <= len(wav):
    kind, size = wav[offset:offset+4], int.from_bytes(wav[offset+4:offset+8], 'little')
    start = offset + 8
    assert start + size <= len(wav)
    if kind == b'fmt ': fmt = struct.unpack_from('<HHIIHH', wav, start)
    if kind == b'data': data = wav[start:start+size]
    offset = start + size + (size & 1)
assert offset == len(wav) and fmt[0] == 3 and fmt[1] == 2 and fmt[2] == 48000 and fmt[5] == 32
assert data is not None and len(data) % 8 == 0
samples = array('f'); samples.frombytes(data)
if sys.byteorder != 'little': samples.byteswap()
assert all(math.isfinite(value) for value in samples)
frames, nonzero = len(samples) // 2, sum(value != 0 for value in samples)
peaks = [max(map(abs, samples[channel::2]), default=0) for channel in (0, 1)]
expected, writer = native['recorded_audio'], native['recording']
assert frames == expected['frames'] == writer['acceptedFrames'] == writer['writtenFrames']
assert nonzero == expected['nonzero_samples'] and peaks == [expected['peak_left'], expected['peak_right']]
assert writer['overflowFrames'] == 0
controls = []
for action in native['controls']:
    recovered = action.get('recovered_cursor_observed_ns')
    controls.append(dict(kind=action['kind'], issued_ns=action['issued_ns'],
        recovered_cursor_observed_ns=recovered, recovered=recovered is not None,
        poll_observed_recovery_upper_seconds=(recovered-action['issued_ns'])/1e9 if recovered is not None else None))
audio = dict(schema=1, qualified=False, complete_service_population=False,
    original_ordinary_assessment=assessment['ordinary_assessment'],
    scope='Failed trace. Hop statistics cover retained observations only; no full-population p99, finite-tail, sustained, physical-output-latency or musical qualification.',
    observed_hops=len(hops), observed_median_ms=statistics.median(times),
    observed_nearest_rank_p99_ms=times[math.ceil(.99*len(times))-1], observed_maximum_ms=max(times),
    observed_hops_at_or_above_4095_ms=sum(value >= 4095 for value in times), all13_observed_service_fields_complete=True,
    measured_wall_ms=native['measured_wall_ms'], measured_intervals_closed=native['measurement_intervals_closed'],
    native_error=native['error'], finite_diagnostic_tail=native.get('diagnostic_tail'),
    steady_starved_frames=native['steady_starved_frames'], control_starved_frames=native['control_starved_frames'],
    control_starved_seconds=native['control_starved_frames']/48000,
    peer_starved_frames=sum(row['starved_b'] for row in native['intervals']),
    control_recoveries=controls, last_replay_measured_output_seconds=(native['measurement_end_output_frame']-native['controls'][-1]['output_begin'])/48000,
    manual_controls=len(native['manual_controls']), manual_acknowledgements=sum(row['acknowledged'] for row in native['manual_controls']),
    callback_execution_deadline_misses=native['execution_deadline_misses'], invalid_buffers=native['invalid_buffers'],
    rejected_commands=native['rejected_commands'], source_read_failures=native['source_read_failures'],
    driver_timing=native['timing'], UI=native['ui_coverage'],
    WAV=dict(**pin(path), frames=frames, samples=len(samples), all_samples_finite=True, nonzero_samples=nonzero,
        peaks=peaks, sample_rate=48000, channels=2, matches_native_counts_and_peaks=True, recording_overflow_frames=0),
    thermal_summary=wrapper['thermal_summary'])
save('root-audio-results-01.json', audio)

host = [json.loads(line) for line in (BASE / 'output-01/host-observations.jsonl').read_text().splitlines()]
threads, batches, scan_costs = {}, [], []
for observation in host:
    trace = observation['process_cpu_read_only']; hz = trace['ticks_per_second']
    scan_costs.append(dict(cpu_ns=trace['scan_thread_cpu_ns'], wall_ns=trace['finished_monotonic_ns']-trace['began_monotonic_ns']))
    for batch in trace['native_thread_cpu']:
        batches.append(batch)
        for row in batch['threads']:
            key = (batch['pid'], batch['process_start_ticks'], row['pid'], row['start_ticks'])
            item = threads.setdefault(key, dict(process_pid=batch['pid'], process_start_ticks=batch['process_start_ticks'],
                tid=row['pid'], thread_start_ticks=row['start_ticks'], comm=row['comm'], main_thread=row['pid']==batch['pid'],
                first_ticks=row['cpu_ticks'], first_ns=row['observed_monotonic_ns'], samples=0,
                peak_observed_interval_cpu_cores=0, ticks_per_second=hz))
            assert item['ticks_per_second'] == hz and row['cpu_ticks'] >= item['first_ticks']
            item.update(last_ticks=row['cpu_ticks'], last_ns=row['observed_monotonic_ns'], samples=item['samples']+1)
            item['peak_observed_interval_cpu_cores'] = max(item['peak_observed_interval_cpu_cores'], row['cpu_cores_since_previous_observation'] or 0)
for item in threads.values():
    item['observed_span_cpu_seconds'] = (item['last_ticks']-item['first_ticks'])/item['ticks_per_second']
    item['observed_span_wall_seconds'] = (item['last_ns']-item['first_ns'])/1e9
ordered = sorted(threads.values(), key=lambda row: row['observed_span_cpu_seconds'], reverse=True)
journal = read('root-guard-journal-01.json')
warnings = [row for row in journal['records'] if 'warning:' in row.get('MESSAGE', '')]
warning_ns = min((int(row['__MONOTONIC_TIMESTAMP'])*1000 for row in warnings), default=None)
cpu = dict(schema=1, qualified=False, native_thread_capture_batches=len(batches),
    complete_batches=sum(batch['complete'] for batch in batches), capture_errors=sum(len(batch['errors']) for batch in batches),
    scope='Sampled CPU deltas by exact native PID/TID lifetimes. Spans differ and exclude CPU before first/after last observations or after vanished threads. Names do not identify pooled functions or prove a thermal cause.',
    threads_by_observed_span_cpu=ordered,
    observer=dict(total_thread_cpu_seconds=sum(row['cpu_ns'] for row in scan_costs)/1e9,
        mean_thread_cpu_ms_per_observation=statistics.mean(row['cpu_ns'] for row in scan_costs)/1e6,
        maximum_thread_cpu_ms_per_observation=max(row['cpu_ns'] for row in scan_costs)/1e6,
        maximum_wall_ms_per_observation=max(row['wall_ns'] for row in scan_costs)/1e6),
    guard_messages=[row['MESSAGE'] for row in journal['records']], first_warning_monotonic_ns=warning_ns,
    observed_hop_validations_after_first_warning=sum(row['validated_ns'] >= warning_ns for row in hops) if warning_ns else None,
    inputs=[pin(BASE/name) for name in ('analyze_partial_trace.py', 'output-01/host-observations.jsonl',
        'output-01/observations.jsonl', 'output-01/result.json', 'root-guard-journal-01.json', 'root-finished-01.json')])
save('root-thread-cpu-analysis-01.json', cpu)
print(json.dumps(dict(observed_hops=len(hops), observed_maximum_ms=max(times),
    late_observed_hops=audio['observed_hops_at_or_above_4095_ms'], control_starved_seconds=audio['control_starved_seconds'],
    WAV_frames=frames, WAV_all_samples_finite=True, complete_native_thread_batches=cpu['complete_batches'],
    top_threads=[{k: row[k] for k in ('tid', 'comm', 'main_thread', 'observed_span_cpu_seconds')} for row in ordered[:4]],
    observer=cpu['observer'], original_assessment_preserved=True)))
