import unittest
from audit_annotations import parse
class AnnotationChecks(unittest.TestCase):
 def test_leading_second_beat_is_preserved(self):
  self.assertEqual(parse(b'0.025\t2\r\n0.760\t1\r\n'),(['0.025','0.760'],[2,1]))
 def test_duplicate_or_reversed_time_is_rejected(self):
  for raw in [b'1.0\t1\n1.0\t2\n',b'1.0\t1\n0.9\t2\n']:
   with self.assertRaises(ValueError):parse(raw)
 def test_unknown_or_zero_bar_position_is_rejected(self):
  for p in ['0','3','1.0','true']:
   with self.assertRaises(ValueError):parse(('0.1\t'+p+'\n').encode())
 def test_malformed_nonfinite_and_empty_inputs_are_rejected(self):
  for raw in [b'',b'NaN\t1\n',b'Infinity\t1\n',b'0.1 1\n',b'-1\t1\n',b'0.1\t1\textra\n']:
   with self.assertRaises(ValueError):parse(raw)
if __name__=='__main__':unittest.main(verbosity=2)
