"""Read-only comparison of all fixed BRID references with publisher ZIP members."""
from pathlib import Path
from decimal import Decimal
from collections import Counter
from zipfile import ZipFile
import hashlib,json,re,statistics
ROOT=Path(__file__).resolve().parent
PROTOCOL=Path('/srv/conflux-tests/laptop/runs/a1106/capture-01/original-protocol.json')
PROTOCOL_SHA='68e28485cb33dc78a2774e3d30a4a4eac2e619630abce9d380021221521bb34a'
ZIP_SHA='605ad57dd9ad86fb3dbb40368a961c7d0db91595a3574aa15b8eb0bbe35ac6dd'

def parse(raw):
 text=raw.decode('ascii');times=[];positions=[]
 for line in text.splitlines():
  fields=line.split('\t')
  if len(fields)!=2 or not re.fullmatch(r'[0-9]+(?:\.[0-9]+)?',fields[0])or fields[1]not in ['1','2']:
   raise ValueError('Expected seconds and one-based position1/2')
  time=Decimal(fields[0])
  if time<0 or times and time<=Decimal(times[-1]):raise ValueError('References must strictly increase')
  times.append(fields[0]);positions.append(int(fields[1]))
 if not times:raise ValueError('Empty annotation')
 return times,positions

def main():
 raw=PROTOCOL.read_bytes();assert hashlib.sha256(raw).hexdigest()==PROTOCOL_SHA
 p=json.loads(raw);assert p['fixed_denominator']==len(p['cases'])==93
 raw=(ROOT/'annotations.zip').read_bytes();assert hashlib.sha256(raw).hexdigest()==ZIP_SHA
 meta=json.loads((ROOT/'zenodo-record.json').read_text());advertised={f['key']:f['checksum'] for f in meta['files']}
 assert advertised['annotations.zip']=='md5:'+hashlib.md5(raw).hexdigest()
 pdf=(ROOT/'description.pdf').read_bytes();assert advertised['BRID - Description.pdf']=='md5:'+hashlib.md5(pdf).hexdigest()
 table={m.group(1):(m.group(2),int(m.group(3)))for m in re.finditer(r'^\s*(\d{4})\s+(M[234]-[0-9]+-[A-Z]+)\s+([234])\s+', (ROOT/'description.txt').read_text(), re.M)}
 assert len(table)==93
 rows=[];first=Counter();prefix=Counter();beats=downbeats=0
 with ZipFile(ROOT/'annotations.zip')as z:
  assert len(z.namelist())==len(set(z.namelist()))==186 and z.testzip()is None
  beat_names={n for n in z.namelist()if n.endswith('.beats')};assert len(beat_names)==93
  consumed=[]
  for index,case in enumerate(p['cases'],1):
   assert case['id']==index
   name='Annotations/beats/'+case['name']+'.beats';assert name in beat_names
   original=z.read(name);times,positions=parse(original);info=z.getinfo(name)
   assert times==case['reference_seconds_text'],case['name']+' timestamp mismatch'
   assert positions==case['bar_positions'],case['name']+' bar-label mismatch'
   assert len(times)==case['source']['reference_count'] and sum(v==1 for v in positions)==case['source']['position1_count']
   assert all(a!=b for a,b in zip(positions,positions[1:])),case['name']+' non-alternating reference'
   track=case['name'].split('] ',1)[1];gid=case['name'][1:5]
   assert table[gid]==(track,int(track[1])),case['name']+' instrument-count mismatch'
   first[positions[0]]+=1;prefix[track[1]]+=1;beats+=len(times);downbeats+=sum(v==1 for v in positions);consumed.append(name)
   tempo_name='Annotations/tempo/'+case['name']+'.bpm';tempo=Decimal(z.read(tempo_name).decode().strip());median=statistics.median(Decimal(60)/(Decimal(b)-Decimal(a))for a,b in zip(times,times[1:]))
   rows.append(dict(id=index,name=case['name'],annotation_member=name,annotation_sha256=hashlib.sha256(original).hexdigest(),ZIP_CRC32=f'{info.CRC:08x}',reference_events=len(times),position_one_events=sum(v==1 for v in positions),first_position=positions[0],instrument_count=table[gid][1],timestamps_identical=True,positions_identical=True,alternating_1_2=True,published_BPM=str(tempo),median_adjacent_BPM=str(median)))
  assert set(consumed)==beat_names
 result=dict(schema=1,protocol_sha256=PROTOCOL_SHA,annotation_archive_sha256=ZIP_SHA,fixed_denominator=93,cases_verified=93,beat_events=beats,position_one_downbeats=downbeats,first_position_counts=dict(first),instrument_count_counts=dict(prefix),all_timestamps_and_labels_identical=True,all_references_alternate_1_2=True,no_relabel_shift_filter_octave_or_threshold_change=True,no_predictions_rescored=True,no_model_or_GPU_started=True,production_changed=False,qualified=False,confidence='Unknown',publisher_Zenodo_license=meta['metadata']['license'],cases=rows)
 (ROOT/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='cases'}))
if __name__=='__main__':main()
